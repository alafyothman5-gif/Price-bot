# PriceBot V10 — Semantic Gemini Core

هذه النسخة تستبدل مطابقة V9 بالكامل بمسار V10:

1. النص أو النص المستخرج من الصورة يدخل كاستعلام كامل.
2. يتم فحص `semantic_memory` أولاً عبر pgvector.
3. إذا لم توجد ذاكرة كافية، يتم توليد embedding للاستعلام.
4. يتم استرجاع أقرب 10 منتجات من PostgreSQL/pgvector.
5. يتم إرسال الاستعلام + المرشحين إلى Gemini `google/gemini-2.5-flash-lite` عبر OpenRouter للتحقق النهائي.
6. السعر لا يظهر إلا إذا كانت ثقة Gemini `>= 0.85` أو كانت ذاكرة دلالية مؤكدة بتشابه `> 0.95`.
7. إذا كانت الثقة بين `0.60` و `0.85` يظهر زر: هل تقصد هذا؟
8. عند تأكيد الزبون يتم الحفظ في `semantic_memory`.

## الملفات الأساسية

- `app/semantic_matcher.py`: محرك V10 الجديد.
- `app/app.py`: مسار WhatsApp بعد ربطه بمحرك V10.
- `app/scripts/rebuild_semantic_index.py`: سكربت بناء embeddings للمنتجات.
- `app/.env.example`: مفاتيح وإعدادات V10.

## المهم

- PostgreSQL مع إضافة pgvector إلزامي.
- لا يوجد قرار مطابقة محلي بالـ fuzzy/tokens.
- `/health` يعرض:

```json
"matcher": "v10_semantic_gemini"
```

## أمر التشغيل

```bash
cd /opt/pricebot_whatsapp_gemini
source .venv/bin/activate
pip install -r requirements.txt
python scripts/rebuild_semantic_index.py --limit 10000
uvicorn app:app --host 127.0.0.1 --port 8090 --proxy-headers
```

## أمر systemd المعتاد

```bash
sudo systemctl restart pricebot-whatsapp-gemini
sudo journalctl -u pricebot-whatsapp-gemini -f
```

## سجلات يجب أن تظهر

- `SEMANTIC_SCHEMA_READY`
- `SEMANTIC_INDEX_READY`
- `SEMANTIC_MEMORY_HIT`
- `SEMANTIC_RETRIEVED`
- `GEMINI_VERIFIED`
