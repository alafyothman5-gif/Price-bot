# PriceBot V10 — Semantic Gemini Core

هذه نسخة كود فقط لتحديث V10 الحاسم. لا تحتوي قاعدة البيانات الفعلية ولا ملف `.env` الحقيقي ولا مفاتيح Meta/OpenRouter/OpenAI.

## الحالة الفنية

- الخدمة: `pricebot-whatsapp-gemini.service`
- المسار المتوقع: `/opt/pricebot_whatsapp_gemini`
- المنفذ: `127.0.0.1:8090`
- قاعدة البيانات المطلوبة: PostgreSQL مع pgvector
- Redis/Valkey: مطلوب للحالة والكاش
- المطابقة: `v10_semantic_gemini`

## مسار المطابقة الجديد

1. استقبال نص أو صورة.
2. الصورة تُقرأ عبر Gemini Vision، ثم النص الناتج يدخل نفس مسار النص.
3. البحث أولاً في `semantic_memory`.
4. إنشاء embedding للاستعلام.
5. استرجاع Top-10 من pgvector.
6. إرسال الاستعلام والمرشحين إلى Gemini عبر OpenRouter.
7. عرض السعر فقط إذا كانت الثقة `>= 0.85`.
8. إذا كانت الثقة بين `0.60` و `0.85` يظهر زر تأكيد.
9. عند تأكيد الزبون يتم حفظ الربط في `semantic_memory`.

## أوامر التشغيل الأساسية

```bash
cd /opt/pricebot_whatsapp_gemini
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python scripts/rebuild_semantic_index.py --limit 10000
uvicorn app:app --host 127.0.0.1 --port 8090 --proxy-headers
```

## فحص الصحة

```bash
curl -s http://127.0.0.1:8090/health | python3 -m json.tool
```

المطلوب أن يظهر:

```json
"matcher": "v10_semantic_gemini"
```
