from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

import httpx

import config_env
import database
from normalizer import normalize_text

MATCHER_NAME = "v10_semantic_gemini"
DEFAULT_VERIFICATION_MODEL = "google/gemini-2.5-flash-lite"
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
PRESCRIPTION_HINTS = {
    "rx", "prescription", "doctor", "patient", "diagnosis", "dose", "dosage", "clinic", "hospital",
    "روشتة", "روشته", "وصفة", "وصفه", "دكتور", "طبيب", "عيادة", "عياده", "مريض", "تشخيص", "جرعة", "الجرعة",
}


def product_name(product: Dict[str, Any]) -> str:
    return str(product.get("canonical_display_name") or product.get("name") or product.get("original_name") or "").strip()


def _plain_price(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        d = Decimal(text)
        out = format(d, "f")
        if "." in out:
            out = out.rstrip("0").rstrip(".")
        return out
    except Exception:
        return text


def product_price(product: Dict[str, Any], default_currency: str = "LYD") -> str:
    price = _plain_price(product.get("price"))
    currency = str(product.get("currency") or default_currency or "LYD").strip()
    return f"{price} {currency}".strip() if price else ""


def looks_like_prescription(text: Any) -> bool:
    value = normalize_text(text or "")
    return any(h in value for h in PRESCRIPTION_HINTS)


@dataclass
class SemanticDecision:
    action: str  # direct | confirm | unavailable
    product: Optional[Dict[str, Any]] = None
    product_id: int = 0
    confidence: float = 0.0
    similarity: float = 0.0
    source: str = ""
    reason: str = ""
    candidates: List[Dict[str, Any]] = field(default_factory=list)
    query_text: str = ""

    @property
    def matched(self) -> bool:
        return self.action in {"direct", "confirm"} and bool(self.product)


class SemanticMatcher:
    """PriceBot V10 matcher: pgvector retrieval + Gemini/OpenRouter verification.

    Product rows for indexing are read through database.load_product_rows(); live retrieval is
    handled by pgvector, and the final decision is made by Gemini only.
    """

    def __init__(self, ttl_seconds: int = 300) -> None:
        self.ttl_seconds = int(ttl_seconds or 300)
        self.embedding_dim = int(os.getenv("PRICEBOT_EMBEDDING_DIM", "1536") or 1536)
        self.top_k = int(os.getenv("PRICEBOT_SEMANTIC_TOP_K", "10") or 10)
        self.verify_top_k = int(os.getenv("PRICEBOT_GEMINI_VERIFY_TOP_K", "10") or 10)
        self.memory_direct_threshold = float(os.getenv("PRICEBOT_MEMORY_DIRECT_THRESHOLD", "0.95") or 0.95)
        self.memory_confirm_threshold = float(os.getenv("PRICEBOT_MEMORY_CONFIRM_THRESHOLD", "0.85") or 0.85)
        self.direct_confidence_threshold = float(os.getenv("PRICEBOT_GEMINI_DIRECT_CONFIDENCE", "0.85") or 0.85)
        self.confirm_confidence_threshold = float(os.getenv("PRICEBOT_GEMINI_CONFIRM_CONFIDENCE", "0.60") or 0.60)
        self.redis_ttl = int(os.getenv("PRICEBOT_SEMANTIC_REDIS_TTL_SECONDS", "604800") or 604800)
        self.schema_ready = False
        self.last_error = ""
        self.last_indexed_count = 0
        self.last_schema_ts = 0.0
        self.last_index_ts = 0.0
        self._log: Optional[Callable[..., None]] = None
        self._embedding_cache: Dict[str, List[float]] = {}
        self._cache_lock = asyncio.Lock()
        self._redis = None
        self._redis_checked = False

    def set_logger(self, logger: Callable[..., None]) -> None:
        self._log = logger

    def log(self, event: str, **kw: Any) -> None:
        if self._log:
            try:
                self._log(event, **kw)
                return
            except Exception:
                pass
        payload = {"ts": round(time.time(), 3), "event": event, **kw}
        print(json.dumps(payload, ensure_ascii=False, default=str), flush=True)

    @property
    def age_seconds(self) -> float:
        return max(0.0, time.time() - self.last_index_ts) if self.last_index_ts else 999999.0

    def _provider_config(self) -> Dict[str, str]:
        config_env.apply_openrouter_aliases()
        provider = str(os.getenv("PRICEBOT_EMBEDDING_PROVIDER", "")).strip().lower()
        if not provider:
            provider = "openai" if os.getenv("OPENAI_API_KEY", "").strip() else "openrouter"
        if provider == "openai":
            return {
                "provider": "openai",
                "api_key": os.getenv("OPENAI_API_KEY", "").strip(),
                "base_url": (os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").strip() or "https://api.openai.com/v1").rstrip("/"),
                "model": os.getenv("PRICEBOT_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL).strip() or DEFAULT_EMBEDDING_MODEL,
            }
        return {
            "provider": "openrouter",
            "api_key": config_env.resolve_openrouter_api_key(),
            "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
            "model": os.getenv("PRICEBOT_EMBEDDING_MODEL", os.getenv("OPENROUTER_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL)).strip() or DEFAULT_EMBEDDING_MODEL,
        }

    def embeddings_configured(self) -> bool:
        cfg = self._provider_config()
        return bool(cfg.get("api_key") and cfg.get("model"))

    def verification_model(self) -> str:
        return config_env.openrouter_gemini_model(["OPENROUTER_MODEL"], default=DEFAULT_VERIFICATION_MODEL)

    def _vector_literal(self, values: Sequence[float]) -> str:
        clean: List[str] = []
        for value in values:
            f = float(value)
            if not math.isfinite(f):
                f = 0.0
            clean.append(f"{f:.8g}")
        return "[" + ",".join(clean) + "]"

    def _product_embedding_text(self, product: Dict[str, Any]) -> str:
        fields = [
            "name", "original_name", "canonical_display_name", "brand", "company",
            "active_ingredient", "form", "strength", "size", "pack", "barcode",
        ]
        values: List[str] = []
        seen = set()
        for field in fields:
            value = re.sub(r"\s+", " ", str(product.get(field) or "")).strip()
            key = value.lower()
            if value and key not in seen:
                values.append(value)
                seen.add(key)
        return " | ".join(values)[:1800]

    async def _redis_client(self):
        if self._redis_checked:
            return self._redis
        self._redis_checked = True
        url = os.getenv("REDIS_URL", "").strip()
        if not url:
            return None
        try:
            import redis.asyncio as redis_async  # type: ignore
            self._redis = redis_async.from_url(url, decode_responses=True, socket_timeout=1.5, socket_connect_timeout=1.5)
            await self._redis.ping()
            return self._redis
        except Exception as exc:
            self.log("SEMANTIC_REDIS_CACHE_DISABLED", error=repr(exc))
            self._redis = None
            return None

    def _cache_key(self, prefix: str, text: str) -> str:
        digest = hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()
        return f"pricebot:v10:{prefix}:{digest}"

    async def _get_cached_embedding(self, text: str) -> Optional[List[float]]:
        key = self._cache_key("embedding", text)
        async with self._cache_lock:
            cached = self._embedding_cache.get(key)
            if cached:
                return list(cached)
        redis = await self._redis_client()
        if redis is not None:
            try:
                raw = await redis.get(key)
                if raw:
                    data = json.loads(raw)
                    if isinstance(data, list):
                        vector = [float(x) for x in data]
                        async with self._cache_lock:
                            self._embedding_cache[key] = vector
                        return vector
            except Exception:
                pass
        return None

    async def _set_cached_embedding(self, text: str, embedding: List[float]) -> None:
        key = self._cache_key("embedding", text)
        async with self._cache_lock:
            if len(self._embedding_cache) > 5000:
                self._embedding_cache.clear()
            self._embedding_cache[key] = list(embedding)
        redis = await self._redis_client()
        if redis is not None:
            try:
                await redis.set(key, json.dumps(embedding, separators=(",", ":")), ex=self.redis_ttl)
            except Exception:
                pass

    def _embedding_headers(self, cfg: Dict[str, str]) -> Dict[str, str]:
        headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
        if cfg.get("provider") == "openrouter":
            headers.setdefault("HTTP-Referer", os.getenv("OPENROUTER_SITE_URL", "https://pricebot.local"))
            headers.setdefault("X-Title", os.getenv("OPENROUTER_APP_NAME", "PriceBot"))
        return headers

    async def _request_embeddings(self, inputs: List[str]) -> List[List[float]]:
        cfg = self._provider_config()
        if not cfg.get("api_key"):
            raise RuntimeError(f"{cfg.get('provider')}_embedding_api_key_missing")
        payload = {"model": cfg["model"], "input": inputs}
        timeout = float(os.getenv("PRICEBOT_EMBEDDING_TIMEOUT_SECONDS", "15") or 15)
        attempts = int(os.getenv("PRICEBOT_EMBEDDING_RETRY_ATTEMPTS", "2") or 2)
        delay = 0.4
        last_error = ""
        async with httpx.AsyncClient(timeout=timeout) as client:
            for attempt in range(1, attempts + 1):
                try:
                    response = await client.post(f"{cfg['base_url']}/embeddings", headers=self._embedding_headers(cfg), json=payload)
                    if response.status_code < 400:
                        body = response.json()
                        rows = body.get("data") or []
                        rows = sorted(rows, key=lambda r: int(r.get("index", 0)))
                        vectors = [[float(x) for x in row.get("embedding", [])] for row in rows]
                        if len(vectors) != len(inputs) or any(not v for v in vectors):
                            raise RuntimeError("embedding_response_shape_invalid")
                        return vectors
                    last_error = f"status={response.status_code} body={response.text[:300]}"
                except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError, RuntimeError, ValueError, KeyError) as exc:
                    last_error = repr(exc)
                if attempt < attempts:
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 3.0)
        raise RuntimeError(f"embedding_request_failed:{last_error}")

    async def get_embedding(self, text: str) -> List[float]:
        query = re.sub(r"\s+", " ", str(text or "")).strip()
        if not query:
            raise ValueError("empty_embedding_text")
        cached = await self._get_cached_embedding(query)
        if cached:
            return cached
        vector = (await self._request_embeddings([query]))[0]
        if self.embedding_dim and len(vector) != self.embedding_dim:
            raise RuntimeError(f"embedding_dimension_mismatch expected={self.embedding_dim} got={len(vector)}")
        await self._set_cached_embedding(query, vector)
        return vector

    async def get_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        out: List[Optional[List[float]]] = [None] * len(texts)
        missing_idx: List[int] = []
        missing_texts: List[str] = []
        for i, text in enumerate(texts):
            cached = await self._get_cached_embedding(text)
            if cached:
                out[i] = cached
            else:
                missing_idx.append(i)
                missing_texts.append(text)
        if missing_texts:
            vectors = await self._request_embeddings(missing_texts)
            for i, vector in zip(missing_idx, vectors):
                if self.embedding_dim and len(vector) != self.embedding_dim:
                    raise RuntimeError(f"embedding_dimension_mismatch expected={self.embedding_dim} got={len(vector)}")
                out[i] = vector
                await self._set_cached_embedding(texts[i], vector)
        return [v or [] for v in out]

    async def initialize(self, *, auto_index: bool = True) -> Dict[str, Any]:
        if not database.IS_POSTGRES:
            self.schema_ready = False
            self.last_error = "postgres_required_for_pgvector"
            self.log("SEMANTIC_SCHEMA_SKIPPED", reason=self.last_error)
            return self.health()
        try:
            with database.connect() as conn:
                conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
                conn.execute(f"ALTER TABLE products ADD COLUMN IF NOT EXISTS embedding vector({self.embedding_dim})")
                conn.execute(f"""
                    CREATE TABLE IF NOT EXISTS semantic_memory (
                        id BIGSERIAL PRIMARY KEY,
                        query_text TEXT NOT NULL,
                        query_embedding vector({self.embedding_dim}) NOT NULL,
                        product_id BIGINT NOT NULL,
                        confidence_score DOUBLE PRECISION NOT NULL DEFAULT 0,
                        confirmed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_semantic_memory_product_id ON semantic_memory(product_id)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_semantic_memory_confirmed_at ON semantic_memory(confirmed_at DESC)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_products_embedding_hnsw ON products USING hnsw (embedding vector_cosine_ops)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_semantic_memory_embedding_hnsw ON semantic_memory USING hnsw (query_embedding vector_cosine_ops)")
            self.schema_ready = True
            self.last_schema_ts = time.time()
            self.last_error = ""
            self.log("SEMANTIC_SCHEMA_READY", matcher=MATCHER_NAME, embedding_dim=self.embedding_dim)
        except Exception as exc:
            self.schema_ready = False
            self.last_error = repr(exc)
            self.log("SEMANTIC_SCHEMA_ERROR", error=repr(exc))
            return self.health()
        if auto_index and str(os.getenv("PRICEBOT_SEMANTIC_INDEX_ON_STARTUP", "1")).lower() not in {"0", "false", "no", "off"}:
            try:
                limit = int(os.getenv("PRICEBOT_SEMANTIC_INDEX_STARTUP_LIMIT", "10000") or 10000)
                await self.rebuild_missing_embeddings(limit=limit)
            except Exception as exc:
                self.last_error = repr(exc)
                self.log("SEMANTIC_INDEX_STARTUP_WARNING", error=repr(exc))
        return self.health()

    def _missing_embedding_ids(self, limit: int) -> set[int]:
        if not database.IS_POSTGRES or not self.schema_ready:
            return set()
        with database.connect() as conn:
            rows = conn.execute("SELECT id FROM products WHERE embedding IS NULL ORDER BY id LIMIT %s", (int(limit),)).fetchall()
        ids: set[int] = set()
        for row in rows:
            try:
                ids.add(int(row[0] if not isinstance(row, dict) else row.get("id")))
            except Exception:
                pass
        return ids

    async def rebuild_missing_embeddings(self, *, limit: int = 10000, batch_size: Optional[int] = None) -> Dict[str, Any]:
        if not database.IS_POSTGRES:
            return {"ok": False, "reason": "postgres_required"}
        if not self.schema_ready:
            await self.initialize(auto_index=False)
        if not self.schema_ready:
            return {"ok": False, "reason": self.last_error or "schema_not_ready"}
        if not self.embeddings_configured():
            self.log("SEMANTIC_INDEX_SKIPPED", reason="embedding_api_key_missing")
            return {"ok": False, "reason": "embedding_api_key_missing"}
        limit = max(1, int(limit or 1))
        batch_size = max(1, int(batch_size or os.getenv("PRICEBOT_EMBEDDING_BATCH_SIZE", "64") or 64))
        missing_ids = self._missing_embedding_ids(limit)
        if not missing_ids:
            self.last_index_ts = time.time()
            return {"ok": True, "indexed": 0, "remaining_missing_sample": 0}
        products = [p for p in database.load_product_rows(visible_only=True) if int(p.get("id") or 0) in missing_ids]
        products = products[:limit]
        indexed = 0
        for start in range(0, len(products), batch_size):
            chunk = products[start:start + batch_size]
            texts = [self._product_embedding_text(p) or product_name(p) for p in chunk]
            vectors = await self.get_embeddings_batch(texts)
            with database.connect() as conn:
                for product, vector in zip(chunk, vectors):
                    if not vector:
                        continue
                    conn.execute(
                        "UPDATE products SET embedding = %s::vector WHERE id = %s",
                        (self._vector_literal(vector), int(product.get("id") or 0)),
                    )
                    indexed += 1
            self.log("SEMANTIC_INDEX_BATCH", indexed=indexed, batch=len(chunk), total=len(products))
        self.last_indexed_count = indexed
        self.last_index_ts = time.time()
        self.log("SEMANTIC_INDEX_READY", indexed=indexed, matcher=MATCHER_NAME)
        return {"ok": True, "indexed": indexed, "considered": len(products)}

    def _visible_product(self, product: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not product:
            return None
        if not database.product_visible(product, guided=False):
            return None
        return product

    def _memory_lookup(self, embedding: List[float]) -> Optional[SemanticDecision]:
        if not database.IS_POSTGRES or not self.schema_ready:
            return None
        vector = self._vector_literal(embedding)
        with database.connect() as conn:
            rows = conn.execute(
                """
                SELECT sm.product_id, sm.confidence_score,
                       1 - (sm.query_embedding <=> %s::vector) AS similarity,
                       p.*
                FROM semantic_memory sm
                JOIN products p ON p.id = sm.product_id
                ORDER BY sm.query_embedding <=> %s::vector
                LIMIT 1
                """,
                (vector, vector),
            ).fetchall()
        if not rows:
            return None
        row = dict(rows[0])
        similarity = float(row.get("similarity") or 0.0)
        product = self._visible_product(row)
        if not product:
            return None
        if similarity >= self.memory_direct_threshold:
            return SemanticDecision(action="direct", product=product, product_id=int(product.get("id") or 0), confidence=float(row.get("confidence_score") or 1.0), similarity=similarity, source="semantic_memory")
        if similarity >= self.memory_confirm_threshold:
            return SemanticDecision(action="confirm", product=product, product_id=int(product.get("id") or 0), confidence=float(row.get("confidence_score") or 0.8), similarity=similarity, source="semantic_memory_confirm")
        return None

    def _semantic_candidates(self, embedding: List[float], *, limit: int) -> List[Dict[str, Any]]:
        if not database.IS_POSTGRES or not self.schema_ready:
            return []
        vector = self._vector_literal(embedding)
        fetch_limit = max(int(limit or self.top_k) * 4, int(limit or self.top_k))
        with database.connect() as conn:
            rows = conn.execute(
                """
                SELECT *, 1 - (embedding <=> %s::vector) AS similarity
                FROM products
                WHERE embedding IS NOT NULL
                ORDER BY embedding <=> %s::vector
                LIMIT %s
                """,
                (vector, vector, fetch_limit),
            ).fetchall()
        out: List[Dict[str, Any]] = []
        for row in rows:
            product = dict(row)
            if not self._visible_product(product):
                continue
            try:
                product["similarity"] = float(product.get("similarity") or 0.0)
            except Exception:
                product["similarity"] = 0.0
            out.append(product)
            if len(out) >= limit:
                break
        return out

    def _candidate_payload(self, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for p in candidates[: self.verify_top_k]:
            out.append({
                "id": int(p.get("id") or 0),
                "name": product_name(p),
                "brand": str(p.get("brand") or ""),
                "active_ingredient": str(p.get("active_ingredient") or ""),
                "form": str(p.get("form") or p.get("medicine_form") or ""),
                "strength": str(p.get("strength") or ""),
                "size": str(p.get("size") or ""),
                "pack": str(p.get("pack") or ""),
                "similarity": round(float(p.get("similarity") or 0.0), 6),
            })
        return out

    def _parse_json_object(self, text: str) -> Dict[str, Any]:
        raw = str(text or "").strip()
        try:
            data = json.loads(raw)
            return data if isinstance(data, dict) else {}
        except Exception:
            pass
        match = re.search(r"\{.*\}", raw, flags=re.DOTALL)
        if not match:
            return {}
        try:
            data = json.loads(match.group(0))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    async def gemini_verify(self, query_text: str, candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
        config_env.apply_openrouter_aliases()
        api_key = config_env.resolve_openrouter_api_key()
        if not api_key:
            raise RuntimeError("OPENROUTER_API_KEY_missing_for_gemini_verification")
        candidate_payload = self._candidate_payload(candidates)
        system_prompt = (
            "You are PriceBot V10, a strict pharmacy product verification layer. "
            "You receive a customer query and a short list of available pharmacy products. "
            "Choose a product only when the query clearly matches it literally or semantically. "
            "Understand equivalent strengths and units naturally, for example 500mg equals 0.5g. "
            "Do not use category-only or generic requests as matches, such as painkiller, tablets, cream, shampoo, حبوب, مسكن, كريم. "
            "If the query is generic, ambiguous, only a category, or none of the candidates is a clear unique match, return match false. "
            "Return strict JSON only, with exactly this shape: "
            "{\"match\": boolean, \"product_id\": number, \"confidence\": number}. "
            "Do not include explanations or markdown."
        )
        user_payload = {
            "query": str(query_text or "")[:1000],
            "candidates": candidate_payload,
        }
        payload = {
            "model": self.verification_model(),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False, separators=(",", ":"))},
            ],
            "temperature": 0,
            "max_tokens": 80,
            "response_format": {"type": "json_object"},
        }
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": os.getenv("OPENROUTER_SITE_URL", "https://pricebot.local"),
            "X-Title": os.getenv("OPENROUTER_APP_NAME", "PriceBot"),
        }
        base_url = (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/")
        timeout = float(os.getenv("PRICEBOT_GEMINI_VERIFY_TIMEOUT_SECONDS", "10") or 10)
        attempts = int(os.getenv("PRICEBOT_GEMINI_VERIFY_RETRY_ATTEMPTS", "2") or 2)
        delay = 0.3
        last_error = ""
        async with httpx.AsyncClient(timeout=timeout) as client:
            for attempt in range(1, attempts + 1):
                try:
                    response = await client.post(f"{base_url}/chat/completions", headers=headers, json=payload)
                    if response.status_code < 400:
                        content = response.json().get("choices", [{}])[0].get("message", {}).get("content", "")
                        data = self._parse_json_object(content)
                        match = bool(data.get("match"))
                        pid = int(data.get("product_id") or 0)
                        confidence = max(0.0, min(1.0, float(data.get("confidence") or 0.0)))
                        valid_ids = {int(p.get("id") or 0) for p in candidates}
                        if not match or pid not in valid_ids:
                            return {"match": False, "product_id": 0, "confidence": confidence}
                        return {"match": True, "product_id": pid, "confidence": confidence}
                    last_error = f"status={response.status_code} body={response.text[:300]}"
                except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError, ValueError, KeyError) as exc:
                    last_error = repr(exc)
                if attempt < attempts:
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 3.0)
        raise RuntimeError(f"gemini_verification_failed:{last_error}")

    async def match(self, query_text: str, *, top_k: Optional[int] = None) -> SemanticDecision:
        query = re.sub(r"\s+", " ", str(query_text or "")).strip()
        if not query:
            return SemanticDecision(action="unavailable", reason="empty_query", query_text=query)
        if looks_like_prescription(query):
            return SemanticDecision(action="unavailable", reason="prescription_like", query_text=query)
        if not self.schema_ready:
            await self.initialize(auto_index=False)
        if not self.schema_ready:
            self.log("SEMANTIC_MATCHER_UNAVAILABLE", reason=self.last_error or "schema_not_ready")
            return SemanticDecision(action="unavailable", reason="semantic_schema_not_ready", query_text=query)
        try:
            query_embedding = await self.get_embedding(query)
        except Exception as exc:
            self.last_error = repr(exc)
            self.log("SEMANTIC_EMBEDDING_ERROR", query=query[:120], error=repr(exc))
            return SemanticDecision(action="unavailable", reason="embedding_failed", query_text=query)

        memory_decision = self._memory_lookup(query_embedding)
        if memory_decision:
            memory_decision.query_text = query
            self.log(
                "SEMANTIC_MEMORY_HIT",
                query=query[:120],
                product_id=memory_decision.product_id,
                similarity=round(memory_decision.similarity, 6),
                action=memory_decision.action,
            )
            return memory_decision

        candidates = self._semantic_candidates(query_embedding, limit=int(top_k or self.top_k))
        if not candidates:
            self.log("SEMANTIC_RETRIEVAL_EMPTY", query=query[:120])
            return SemanticDecision(action="unavailable", reason="no_semantic_candidates", query_text=query)
        self.log(
            "SEMANTIC_RETRIEVED",
            query=query[:120],
            count=len(candidates),
            top_product_id=int(candidates[0].get("id") or 0),
            top_similarity=round(float(candidates[0].get("similarity") or 0.0), 6),
        )
        try:
            verified = await self.gemini_verify(query, candidates)
        except Exception as exc:
            self.last_error = repr(exc)
            self.log("GEMINI_VERIFY_ERROR", query=query[:120], error=repr(exc))
            return SemanticDecision(action="unavailable", reason="gemini_failed", query_text=query, candidates=candidates)

        pid = int(verified.get("product_id") or 0)
        confidence = float(verified.get("confidence") or 0.0)
        product = next((p for p in candidates if int(p.get("id") or 0) == pid), None)
        self.log(
            "GEMINI_VERIFIED",
            query=query[:120],
            match=bool(verified.get("match")),
            product_id=pid,
            confidence=round(confidence, 6),
        )
        if not verified.get("match") or not product:
            return SemanticDecision(action="unavailable", reason="gemini_no_match", confidence=confidence, query_text=query, candidates=candidates)
        if confidence >= self.direct_confidence_threshold:
            return SemanticDecision(action="direct", product=product, product_id=pid, confidence=confidence, source="gemini_verified", query_text=query, candidates=candidates)
        if confidence >= self.confirm_confidence_threshold:
            return SemanticDecision(action="confirm", product=product, product_id=pid, confidence=confidence, source="gemini_low_confidence", query_text=query, candidates=candidates)
        return SemanticDecision(action="unavailable", reason="confidence_below_threshold", confidence=confidence, query_text=query, candidates=candidates)

    async def remember_confirmation(self, query_text: str, product_id: int, confidence: float = 1.0) -> Dict[str, Any]:
        query = re.sub(r"\s+", " ", str(query_text or "")).strip()
        if not query or not int(product_id or 0):
            return {"ok": False, "reason": "missing_query_or_product"}
        if not self.schema_ready:
            await self.initialize(auto_index=False)
        if not self.schema_ready:
            return {"ok": False, "reason": self.last_error or "schema_not_ready"}
        embedding = await self.get_embedding(query)
        vector = self._vector_literal(embedding)
        with database.connect() as conn:
            conn.execute(
                """
                INSERT INTO semantic_memory(query_text, query_embedding, product_id, confidence_score, confirmed_at)
                VALUES(%s, %s::vector, %s, %s, CURRENT_TIMESTAMP)
                """,
                (query[:1000], vector, int(product_id), float(confidence or 1.0)),
            )
        self.log("SEMANTIC_MEMORY_SAVED", query=query[:120], product_id=int(product_id), confidence=round(float(confidence or 1.0), 6))
        return {"ok": True, "product_id": int(product_id)}

    def health(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "matcher": MATCHER_NAME,
            "schema_ready": bool(self.schema_ready),
            "postgres_required": True,
            "database_is_postgres": bool(database.IS_POSTGRES),
            "embedding_dim": self.embedding_dim,
            "embedding_provider": self._provider_config().get("provider"),
            "embedding_model": self._provider_config().get("model"),
            "embedding_configured": self.embeddings_configured(),
            "verification_model": self.verification_model(),
            "memory_direct_threshold": self.memory_direct_threshold,
            "memory_confirm_threshold": self.memory_confirm_threshold,
            "gemini_direct_confidence": self.direct_confidence_threshold,
            "gemini_confirm_confidence": self.confirm_confidence_threshold,
            "last_error": self.last_error,
            "last_indexed_count": self.last_indexed_count,
            "index_age_seconds": round(self.age_seconds, 2),
        }
        if database.IS_POSTGRES and self.schema_ready:
            try:
                with database.connect() as conn:
                    total = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
                    indexed = conn.execute("SELECT COUNT(*) FROM products WHERE embedding IS NOT NULL").fetchone()[0]
                    memory = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
                data.update({"products_count": int(total), "embedded_products": int(indexed), "semantic_memory_count": int(memory)})
            except Exception as exc:
                data["health_count_error"] = repr(exc)
        return data
