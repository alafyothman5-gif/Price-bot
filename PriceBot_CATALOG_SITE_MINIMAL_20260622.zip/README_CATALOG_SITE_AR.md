# PriceBot Catalog Site - نسخة جاهزة

هذه النسخة تضيف موقع كتالوج منتجات فوق نفس مشروع PriceBot الحالي.

## ما الذي تغير؟

- إضافة ملف `catalog_web.py`.
- ربط الموقع داخل `app.py` عبر `catalog_web.router`.
- جعل `/` صفحة الكتالوج الرئيسية.
- إبقاء لوحة النظام القديمة على `/portal`.
- إضافة صفحات:
  - `/`
  - `/catalog`
  - `/products`
  - `/products?q=Panadol`
  - `/product/{id}`
  - `/catalog-health`

## الأمان

- الموقع يقرأ من قاعدة البيانات فقط.
- لا يغير `pricebot.db`.
- لا يلمس `.env`.
- سكربت التركيب يعمل Backup قبل نسخ الملفات.

## التركيب المختصر على السيرفر

```bash
cd /tmp
unzip PriceBot_CATALOG_SITE_READY_20260622.zip -d PriceBot_CATALOG_SITE_READY_20260622
cd PriceBot_CATALOG_SITE_READY_20260622
sudo bash INSTALL_CATALOG_SITE_SAFE.sh
```

بعدها افتح:

```text
https://46.101.148.246.sslip.io/catalog
https://46.101.148.246.sslip.io/products?q=Panadol
```

## التحقق

```bash
cd /opt/pricebot_clean
curl -s http://127.0.0.1:8090/catalog-health
```

أو:

```bash
sudo bash /opt/pricebot_clean/VERIFY_CATALOG_SITE.sh
```

## الرجوع للخلف عند وجود مشكلة

```bash
sudo bash /opt/pricebot_clean/ROLLBACK_CATALOG_SITE_LAST_BACKUP.sh
```

## ملاحظة

هذه المرحلة لا تبسط بوت واتساب بعد. الهدف الآن تشغيل الموقع بشكل مستقر. بعد التأكد من الموقع، يتم تعديل البوت ليُرسل روابط `/products?q=...` بدل عرض متجر كامل داخل واتساب.
