# PriceBot Final Consolidated Release

هذه النسخة تجمع آخر تحسينات المشروع في ملف واحد:

- واجهات Excel/merchant catalog/review.
- صفحات admin failed searches و image debug و synonyms.
- صفحة تعديل المنتج.
- OCR bridge للصور.
- ضغط الصور قبل Vision.
- timeout آمن للصور.
- queue محدود للـ Vision عبر semaphore.
- image cache آمن: exact hash فقط، ولا يحفظ إلا EXACT_MATCH بثقة عالية.
- تعطيل Celery افتراضيًا عند النشر النشط.
- لا تحتوي .env أو pricebot.db أو venv.

المسار النشط المطلوب على السيرفر: /opt/pricebot_clean
