#!/usr/bin/env bash
set -Eeuo pipefail

APP="/opt/pricebot_clean"
SERVICE="pricebot"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP="/root/pricebot_final_deploy_backups/$TS"
mkdir -p "$BACKUP"

[ -d "$APP" ] || { echo "ERROR: active app path missing: $APP"; exit 1; }
systemctl cat "$SERVICE" | grep -q "WorkingDirectory=$APP" || {
  echo "ERROR: service is not using $APP"
  systemctl cat "$SERVICE"
  exit 1
}

echo "== BACKUP ACTIVE APP =="
tar --exclude="pricebot_clean/venv" --exclude="pricebot_clean/__pycache__" --exclude="*/__pycache__" --exclude="*.pyc" \
  -czf "$BACKUP/pricebot_clean_before_final_deploy.tar.gz" -C /opt pricebot_clean

echo "== STOP SERVICE =="
systemctl stop "$SERVICE" || true

echo "== DEPLOY CODE ONLY =="
SRC="$(cd "$(dirname "$0")/.." && pwd)"
rsync -a --delete "$SRC"/ "$APP"/ \
  --exclude ".env" \
  --exclude "pricebot.db" \
  --exclude "*.db" \
  --exclude "venv" \
  --exclude ".git" \
  --exclude "__pycache__" \
  --exclude "uploads" \
  --exclude "backups" \
  --exclude "ACTIVE_VERSION_LOCK.txt"

cd "$APP"
if [ -f .env ]; then
  cp -a .env "$BACKUP/.env.before_final_deploy"
  sed -i '/^PRICEBOT_USE_CELERY=/d' .env
  sed -i '/^PRICEBOT_VISION_TIMEOUT_SECONDS=/d' .env
  sed -i '/^PRICEBOT_VISION_MAX_CONCURRENT=/d' .env
  sed -i '/^PRICEBOT_IMAGE_CACHE_EXACT_ONLY=/d' .env
  sed -i '/^PRICEBOT_IMAGE_CACHE_MIN_CONFIDENCE=/d' .env
  sed -i '/^PRICEBOT_IMAGE_CACHE_MAX_PHASH_DISTANCE=/d' .env
  sed -i '/^PRICEBOT_VISION_MAX_IMAGE_WIDTH=/d' .env
  sed -i '/^PRICEBOT_VISION_JPEG_QUALITY=/d' .env
  sed -i '/^PRICEBOT_OPENROUTER_TIMEOUT=/d' .env
  cat >> .env <<'EOF'

# PriceBot final safe image settings
PRICEBOT_USE_CELERY=0
PRICEBOT_VISION_TIMEOUT_SECONDS=8
PRICEBOT_VISION_MAX_CONCURRENT=2
PRICEBOT_IMAGE_CACHE_EXACT_ONLY=1
PRICEBOT_IMAGE_CACHE_MIN_CONFIDENCE=0.92
PRICEBOT_IMAGE_CACHE_MAX_PHASH_DISTANCE=0
PRICEBOT_VISION_MAX_IMAGE_WIDTH=1024
PRICEBOT_VISION_JPEG_QUALITY=78
PRICEBOT_OPENROUTER_TIMEOUT=8
EOF
fi

python3 -m venv venv
./venv/bin/pip install -U pip >/dev/null
./venv/bin/pip install -r requirements.txt >/dev/null
./venv/bin/python -m py_compile app.py vision_service.py services/vision/image_cache.py
find services routes repositories tasks -name "*.py" -print0 2>/dev/null | xargs -0 -r ./venv/bin/python -m py_compile

./venv/bin/python - <<'PY'
import os, sqlite3, sys
if not os.path.exists("pricebot.db"):
    print("ERROR: pricebot.db missing")
    sys.exit(1)
con = sqlite3.connect("pricebot.db")
cur = con.cursor()
for t in ["products","product_identity_registry","product_search_index","guided_catalog_index"]:
    cur.execute(f"select count(*) from {t}")
    print(t, cur.fetchone()[0])
con.close()
PY

echo "== START SERVICE =="
systemctl start "$SERVICE"
sleep 5
systemctl status "$SERVICE" --no-pager -l
curl -s https://46.101.148.246.sslip.io/health || true
echo

echo "PRICEBOT_FINAL_ACTIVE_DEPLOY_OK=1"
echo "BACKUP=$BACKUP/pricebot_clean_before_final_deploy.tar.gz"
