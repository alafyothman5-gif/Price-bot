# PriceBot Image Confirmation Mode Safe Fix

## What changed

This build changes the image policy from direct-selling to confirmation-first.

Image flow now:

1. Download WhatsApp image.
2. Check exact image cache.
3. If cache hit, show candidate confirmation only; no direct price.
4. If no cache hit, run Vision with timeout/preprocessing.
5. Run OCR cleaner + matcher.
6. If product candidates are found, ask the customer to confirm the product.
7. Show price/availability only after the customer selects the product.

## Why

This prevents dangerous variant mistakes such as:

- image says `Transition 4g Pediatrique`
- catalog contains `Transition 10g`
- old behavior: bot could answer `Transition 10g available`
- new behavior: bot asks confirmation and does not show price directly from image

## Safety rules

- Text search may still return direct prices when exact.
- Image search does not show direct prices; it asks for confirmation first.
- Image cache is safe because cache hits also require confirmation.
- Failed image results are not cached as product matches.

## Files changed

- app.py
- ui_flow.py

## Runtime requirements

Keep:

- PRICEBOT_USE_CELERY=0
- PRICEBOT_VISION_TIMEOUT_SECONDS around 7-10
- PRICEBOT_IMAGE_CACHE_EXACT_ONLY=1

## Smoke tests after deploy

1. Send image of Transition 4g Pediatrique.
   - Must not reply with Transition 10g price directly.
   - Must ask confirmation / show candidate without price.
2. Send image of Vichy Normaderm.
   - Must ask confirmation before price.
3. Send image of White Petroleum Jelly.
   - Must ask confirmation before price or if selected then show price.
4. Send text `WHITE PETROLEUM JELLY`.
   - Text exact search may return price directly.
5. Send text `Cipralex 10mg`.
   - Text exact search may return price directly.

