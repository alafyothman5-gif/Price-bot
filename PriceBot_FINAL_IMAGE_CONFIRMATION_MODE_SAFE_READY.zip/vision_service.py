import base64
import json
import os
from io import BytesIO
from typing import Dict, Tuple

import httpx
from PIL import Image, ImageOps

import config_env
from normalizer import normalize_text
from query_slots import build_vision_query


# PRICEBOT_FINAL_IMAGE_SPEED_V2
def _env_int(name: str, default: int, minimum: int = 1, maximum: int = 10000) -> int:
    try:
        value = int(os.getenv(name, str(default)) or default)
    except Exception:
        value = default
    return max(minimum, min(maximum, value))


def _env_float(name: str, default: float, minimum: float = 0.1, maximum: float = 60.0) -> float:
    try:
        value = float(os.getenv(name, str(default)) or default)
    except Exception:
        value = default
    return max(minimum, min(maximum, value))


def _prepare_image_for_vision(image_bytes: bytes, mime_type: str = "image/jpeg") -> Tuple[bytes, str]:
    """Resize/compress WhatsApp images before Vision.

    The original media is not modified. This only reduces bytes sent to the
    external Vision provider, making image search faster and less likely to
    timeout on mobile-uploaded photos.
    """
    if not image_bytes:
        return image_bytes, mime_type or "image/jpeg"
    max_width = _env_int("PRICEBOT_VISION_MAX_IMAGE_WIDTH", 1024, minimum=320, maximum=1600)
    quality = _env_int("PRICEBOT_VISION_JPEG_QUALITY", 78, minimum=55, maximum=90)
    try:
        img = Image.open(BytesIO(image_bytes))
        img = ImageOps.exif_transpose(img)
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        elif img.mode == "L":
            img = img.convert("RGB")

        width, height = img.size
        if width > max_width:
            new_height = max(1, int(height * (max_width / float(width))))
            img = img.resize((max_width, new_height), Image.LANCZOS)

        out = BytesIO()
        img.save(out, format="JPEG", quality=quality, optimize=True)
        prepared = out.getvalue()
        if prepared and len(prepared) < len(image_bytes):
            _log("VISION_IMAGE_PREPARED", original_bytes=len(image_bytes), prepared_bytes=len(prepared), max_width=max_width, quality=quality)
            return prepared, "image/jpeg"
    except Exception as exc:
        _log("VISION_IMAGE_PREPARE_WARNING", error=repr(exc))
    return image_bytes, mime_type or "image/jpeg"


GENERIC_IMAGE_WORDS = {
    "cream", "gel", "tube", "capsule", "capsules", "tablet", "tablets", "vitamin", "female", "face", "skin",
    "lotion", "syrup", "drops", "spray", "shampoo", "conditioner", "mg", "ml", "iu", "كريم", "جل", "حبوب",
    "فيتامين", "كبسولات", "شراب", "قطره", "بخاخ", "شامبو",
}


def _log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-flash-lite").strip() or "google/gemini-2.5-flash-lite",
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def build_query_from_slots(slots: Dict[str, str]) -> str:
    # Vision matching must use product identity slots, not raw package text.
    # Generic marketing words remain in visible_text but are excluded from query.
    return build_vision_query(slots)


def _is_weak_visual_query(query: str, slots: Dict[str, str]) -> bool:
    n = normalize_text(query)
    if not n:
        return True
    tokens = n.split()
    strong = [t for t in tokens if t not in GENERIC_IMAGE_WORDS and not t.isdigit() and len(t) >= 3]
    brand = normalize_text(slots.get("brand"))
    product_name = normalize_text(slots.get("product_name"))
    # A reliable image search needs either brand/product name, or at least two strong visible words.
    if brand and product_name and product_name not in GENERIC_IMAGE_WORDS:
        return False
    if len(strong) >= 2:
        return False
    return True


async def extract_product_from_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, str]:
    if not image_bytes:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    cfg = _openrouter_config()
    if not config_env.vision_enabled():
        reason = config_env.vision_disabled_reason()
        _log("VISION_DISABLED_REASON", reason=reason)
        return {"status": "IMAGE_UNCLEAR", "message": "فحص الصور غير مفعّل حاليًا. اكتب اسم المنتج كاملًا."}

    _log("VISION_START")
    _log("VISION_PROVIDER", provider="OpenRouter")
    _log("VISION_MODEL", model=cfg["model"])

    image_bytes, mime_type = _prepare_image_for_vision(image_bytes, mime_type)
    data_url = f"data:{mime_type};base64," + base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "Read the FRONT pharmacy product only. Return JSON only. Keys: "
        "brand, product_name, product_family, form, strength, size, pack, visible_text, confidence. "
        "No explanation. Ignore shelf/background products. Do not guess. "
        "If the product name is not readable, set confidence below 0.75."
    )
    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]}
        ],
        "temperature": 0,
        "max_tokens": 260,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=_env_float("PRICEBOT_OPENROUTER_TIMEOUT", 8.0, minimum=2.0, maximum=20.0)) as client:
            resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                _log("VISION_ERROR", provider="openrouter", status=resp.status_code)
                return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as exc:
        _log("VISION_ERROR", provider="openrouter", status=type(exc).__name__)
        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}

    try:
        start = content.find("{")
        end = content.rfind("}")
        data = json.loads(content[start:end + 1] if start >= 0 and end > start else content)
    except Exception:
        _log("VISION_ERROR", provider="openrouter", status="bad_json")
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    try:
        confidence = float(data.get("confidence") or 0)
    except Exception:
        confidence = 0.0
    query = build_query_from_slots(data)
    _log("VISION_EXTRACTED_NAME", value=query[:120])
    _log("VISION_CONFIDENCE", value=confidence)

    if confidence < 0.75 or _is_weak_visual_query(query, data):
        return {"status": "LOW_CONFIDENCE", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}
    data["status"] = "OK"
    data["query"] = query
    data["confidence"] = str(confidence)
    return data
