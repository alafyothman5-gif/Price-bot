from __future__ import annotations

"""Excel-native deterministic matcher for PriceBot.

This engine treats the pharmacy Excel/database as the source of truth.  It does
not use global fuzzy fallback.  It returns a price only after a product identity
is uniquely resolved; generic families such as Panadol/Flagyl/Gaviscon/MEBO ask
for clarification even when one row has the exact generic name.
"""

import json
import os
import re
import time
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import database
from normalizer import clean_query, compact_normalize, normalize_text, safe_price, split_multi
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths, normalize_measure
from search_engine import SearchResult
from services.catalog.identity_generation import (
    WEAK_TOKENS as CATALOG_WEAK_TOKENS,
    BrandFamilyNormalizer,
    CatalogAliasGenerator,
    generated_aliases_for_product,
)
from services.learning.suggestion_engine import suggest_learning_candidates
from services.matching.candidate_safety_filter import CandidateSafetyFilter
from services.whatsapp.result_formatter import clarification_message

WEAK_TOKENS: Set[str] = set(CATALOG_WEAK_TOKENS) | {
    "the", "and", "for", "with", "new", "plus", "extra", "advance", "advanced",
    "cream", "creme", "gel", "ointment", "lotion", "serum", "cleanser", "wash", "foam",
    "moisturizer", "moisturizing", "shampoo", "conditioner", "spray", "oil", "mask",
    "tablet", "tablets", "tab", "tabs", "capsule", "capsules", "cap", "caps", "syr", "syrup",
    "susp", "suspension", "supp", "drop", "drops", "inj", "amp", "solution", "sachet", "sachets",
    "skin", "face", "body", "hair", "care", "support", "supports", "health", "supplement", "food",
    "iron", "vitamin", "vitamins", "female", "male", "adult", "baby", "infant", "tube",
    "mg", "mcg", "ml", "g", "iu", "i", "u", "d", "k", "b", "c", "pro", "scar",
    "كريم", "جل", "مرهم", "لوشن", "سيروم", "غسول", "شامبو", "بلسم", "بخاخ", "زيت",
    "اقراص", "حبوب", "كبسولات", "كبسول", "شراب", "قطرات", "حقن", "اكياس",
    "فيتامين", "حديد", "مكمل", "صحه", "بشره", "وجه", "جسم", "شعر",
}
WEAK_TOKENS.discard("scar")
WEAK_TOKENS.discard("pro")

MEASURE_TOKENS = {"mg", "mcg", "ml", "g", "iu", "tab", "tabs", "tablet", "tablets", "cap", "caps", "capsule", "capsules", "sachet", "sachets"}

FORM_EQUIV = {
    "syrup": {"syrup", "suspension"},
    "suspension": {"syrup", "suspension"},
    "cleanser": {"cleanser"},
    "cream": {"cream"},
    "ointment": {"ointment"},
    "capsule": {"capsule"},
    "tablet": {"tablet"},
}
COSMETIC_HARD_FORMS: Set[str] = {"cleanser", "cream", "ointment", "gel", "lotion", "serum", "moisturizer", "sunscreen", "shampoo", "conditioner", "spray", "oil", "mask", "toner"}

def _load_catalog_corrections() -> Dict[str, Any]:
    """Load reviewed catalog/vision corrections from data, not code.

    Product aliases and OCR corrections must be maintained through the catalog,
    dynamic synonyms, Learning Inbox approvals, or this external corrections file.
    The matcher code itself must not contain product-specific hardcoded fixes.
    """
    path = Path(__file__).resolve().parents[2] / "data" / "catalog_corrections.json"
    try:
        if path.exists():
            with path.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}
    return {}


def _norm_map(data: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for k, v in (data or {}).items():
        nk = normalize_text(k)
        nv = normalize_text(v)
        if nk and nv:
            out[nk] = nv
    return out


CATALOG_CORRECTIONS = _load_catalog_corrections()
KNOWN_VISION_ALIASES = _norm_map(CATALOG_CORRECTIONS.get("known_vision_aliases") or {})
VISION_OCR_FRAGMENT_FIXES = _norm_map(CATALOG_CORRECTIONS.get("ocr_fragment_fixes") or {})
VISION_EXTRA_BRAND_TOKENS: Set[str] = {
    normalize_text(x) for x in (CATALOG_CORRECTIONS.get("extra_vision_brand_tokens") or []) if normalize_text(x)
}
VISION_PHRASE_RULES: List[Dict[str, Any]] = [
    r for r in (CATALOG_CORRECTIONS.get("vision_phrase_rules") or []) if isinstance(r, dict)
]


GENERIC_FAMILY_WORDS = {
    "panadol", "flagyl", "فلاجيل", "gaviscon", "mebo", "cerave", "amoclan", "janumet", "cipralex",
    "rilastil", "bioderma", "uriage", "eucerin", "photoblok", "daktarin", "gyno daktarin",
}

IMAGE_LOW_CONFIDENCE_PATTERNS = [
    {"remedica", "oral", "suspension"},
]

# Words that vision models often mislabel as a brand.  They are allowed to
# remain in the full OCR phrase, but must not be trusted as a brand-only query.
VISION_NON_BRAND_TOKENS: Set[str] = {
    "white", "black", "red", "blue", "green", "yellow", "petroleum", "cream", "creme",
    "gel", "jelly", "ointment", "lotion", "serum", "cleanser", "wash", "soap", "shampoo",
    "tablet", "capsule", "syrup", "suspension", "drops", "spray", "oil", "mask",
}

# PRICEBOT_V5_VISION_EVIDENCE_VALIDATOR_V1
# These fields are treated as OCR/evidence copied from the image.  Structured
# fields such as product_name/brand may be useful, but they are not enough by
# themselves because vision models can hallucinate a catalog-looking name.
VISION_STRICT_EVIDENCE_FIELDS: Tuple[str, ...] = (
    "visible_text",
    "raw_vision_text",
)
VISION_FALLBACK_EVIDENCE_FIELDS: Tuple[str, ...] = (
    "foreground_product_text",
    "main_visible_product",
)

# Marketing/background OCR words that commonly appear on packages and should not
# dominate image matching.  They are removed only while building image candidate
# queries; the original OCR is still stored in diagnostics/learning.
VISION_OCR_NOISE_TOKENS: Set[str] = {
    "laboratoires", "laboratoire", "laboratory", "laboratories", "dermatologique",
    "dermatological", "physiologic", "physiological", "physiologique", "purif",
    "purifying", "purifies", "daily", "deep", "cleansing", "cleaning", "foam",
    "normal", "oily", "imperfections", "imperfection", "acne", "prone", "skin",
    "face", "body", "oiliness", "shine", "confidence", "source", "text", "visible",
    "background", "front", "pack", "package", "box", "tube", "jar", "bottle",
    "orb", "zorb", "optizorb", "easy", "swallow", "caplets", "caplet", "tablets",
    "tablet", "paracetamol", "caffeine", "film", "coated", "advance", "advanced",
    "plus", "new", "original", "orginal", "egy", "irland", "tunsia", "laboratoires",
}

# OCR phrase/fragment corrections are loaded from data/catalog_corrections.json.
# Keep product-specific corrections outside code so Learning Inbox/catalog
# approvals can change behavior without source patches.



def _now() -> float:
    return time.time()


def _n(value: Any) -> str:
    return normalize_text(value)


def _compact(value: Any) -> str:
    return compact_normalize(value)


def _word_tokens(value: Any) -> List[str]:
    n = _n(value)
    return [t for t in n.split() if t]


def _strong_tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in _word_tokens(value):
        if t in WEAK_TOKENS:
            continue
        if len(t) <= 2 and not t.isdigit():
            continue
        if t.isdigit():
            # Standalone digits are weak unless part of a measure expression.
            continue
        if t not in out:
            out.append(t)
    return out


def _phrase_in(phrase: str, text: str) -> bool:
    phrase = _n(phrase)
    text = _n(text)
    if not phrase or not text:
        return False
    return f" {phrase} " in f" {text} "


def _vision_evidence_text(slots: Dict[str, Any], *, strict_only: bool = True) -> str:
    """Return text that is supposed to be copied from the package itself.

    The key safety distinction is intentional: product_name/brand/product_family
    are model inferences, while visible_text/raw_vision_text are OCR-like
    evidence.  foreground/main_visible are used only when primary OCR evidence
    is absent, because some vision models put their guessed product name there.
    A candidate generated from an image must be supported by this evidence
    whenever it is available.
    """
    primary = " ".join(str(slots.get(k) or "") for k in VISION_STRICT_EVIDENCE_FIELDS if str(slots.get(k) or "").strip()).strip()
    if primary or strict_only:
        base = primary
    else:
        base = " ".join(str(slots.get(k) or "") for k in VISION_FALLBACK_EVIDENCE_FIELDS if str(slots.get(k) or "").strip()).strip()
    if not strict_only:
        extra = " ".join(str(slots.get(k) or "") for k in ["brand", "product_name", "product_family", "form", "strength", "size", "pack"] if str(slots.get(k) or "").strip()).strip()
        return " ".join([base, extra]).strip()
    return base


def _token_supported_by_text(token: str, text_norm: str, text_compact: str) -> bool:
    token = _n(token)
    if not token:
        return False
    if f" {token} " in f" {text_norm} ":
        return True
    c = _compact(token)
    return bool(c and len(c) >= 4 and c in text_compact)


def _identity_tokens_for_evidence(text: Any) -> List[str]:
    """Strong-ish identity tokens used for OCR evidence validation.

    This is stricter than a normal search token list: form/marketing/generic
    words alone should not validate an image match, but real product/brand
    tokens such as hemazym, normaderm, petroleum/jelly, panadol, etc. should.
    """
    out: List[str] = []
    for t in _word_tokens(text):
        if t in MEASURE_TOKENS or t in VISION_OCR_NOISE_TOKENS:
            continue
        if t.isdigit() or len(t) <= 2:
            continue
        if re.search(r"\d", t) and normalize_measure(t):
            continue
        if t in WEAK_TOKENS and t not in VISION_EXTRA_BRAND_TOKENS:
            continue
        if t not in out:
            out.append(t)
    return out


def _query_supported_by_visible_evidence(query: Any, evidence: str) -> Tuple[bool, str]:
    """Reject hallucinated image candidates not backed by visible OCR text.

    Example: if Vision says product_name='high life hair cream' but the OCR
    evidence contains 'Hemazym Liposomal Iron 30 Capsules', the candidate is
    rejected before any catalog lookup.  If no evidence text exists, matching is
    not blocked here because some providers only return structured fields.
    """
    evidence_norm = _n(evidence)
    if not evidence_norm:
        return True, "no_evidence_text"
    evidence_compact = _compact(evidence_norm)
    qn = _n(query)
    if not qn:
        return False, "empty_candidate"
    if _phrase_in(qn, evidence_norm) or (_compact(qn) and _compact(qn) in evidence_compact):
        return True, "phrase_supported"
    q_tokens = _identity_tokens_for_evidence(qn)
    if not q_tokens:
        # Pure form/measure candidates are unsafe for images.
        return False, "candidate_has_no_identity_tokens"
    supported = [t for t in q_tokens if _token_supported_by_text(t, evidence_norm, evidence_compact)]
    if len(q_tokens) == 1 and supported:
        return True, "token_supported"
    if len(q_tokens) >= 2 and len(supported) >= 2 and (len(supported) / max(len(q_tokens), 1)) >= 0.50:
        return True, "tokens_supported"
    return False, "unsupported_by_visible_ocr"


def _product_supported_by_visible_evidence(product_text: Any, candidate_query: Any, evidence: str) -> Tuple[bool, str]:
    """Validate that the chosen catalog product has real support in image OCR."""
    evidence_norm = _n(evidence)
    if not evidence_norm:
        return True, "no_evidence_text"
    evidence_compact = _compact(evidence_norm)

    # Direct query support is enough when the candidate came from OCR/alias.
    ok, reason = _query_supported_by_visible_evidence(candidate_query, evidence_norm)
    if ok and reason != "no_evidence_text":
        return True, "candidate_" + reason

    pt = _n(product_text)
    product_tokens = _identity_tokens_for_evidence(pt)
    supported = [t for t in product_tokens if _token_supported_by_text(t, evidence_norm, evidence_compact)]
    if supported:
        return True, "product_token_supported"
    return False, "product_identity_not_visible"


def _measures(text: Any) -> Set[str]:
    vals = extract_strengths(text) + extract_sizes(text) + extract_packs(text)
    return {normalize_measure(x) for x in vals if normalize_measure(x)}


def _form_match(requested: str, product_form: str, product_text: str = "") -> bool:
    req = canonical_form(requested) or _n(requested)
    pf = canonical_form(product_form) or _n(product_form)
    if not req:
        return True
    if not pf and product_text:
        pf = canonical_form(product_text) or ""
    if req == pf:
        return True
    return bool(req in FORM_EQUIV and pf in FORM_EQUIV[req])


def _price_conflict(products: Sequence[Dict[str, Any]]) -> bool:
    prices = {safe_price(p.get("price")) for p in products if safe_price(p.get("price"))}
    return len(products) > 1 and len(prices) > 1


def _display_name(p: Dict[str, Any]) -> str:
    return str(p.get("canonical_display_name") or p.get("name") or p.get("original_name") or "").strip()


def _product_identity_key(p: Dict[str, Any]) -> Tuple[str, str, str, str, str, str, str]:
    return (
        _n(p.get("brand")) or (_word_tokens(p.get("name"))[0] if _word_tokens(p.get("name")) else ""),
        _n(p.get("product_family") or p.get("normalized_name") or p.get("name")),
        _n(p.get("category") or p.get("main_section") or p.get("section")),
        canonical_form(p.get("form") or p.get("medicine_form") or p.get("product_type") or p.get("name")) or "",
        normalize_measure(p.get("strength")),
        normalize_measure(p.get("size")),
        normalize_measure(p.get("pack")),
    )


@dataclass
class IndexedProduct:
    product: Dict[str, Any]
    product_id: int
    name: str
    brand: str
    family: str
    category: str
    form: str
    identity_text: str
    identity_compact: str
    exact_keys: Set[str] = field(default_factory=set)
    token_set: Set[str] = field(default_factory=set)
    strong_set: Set[str] = field(default_factory=set)
    measures: Set[str] = field(default_factory=set)
    identity_key: Tuple[str, str, str, str, str, str, str] = field(default_factory=tuple)


class ExcelNativeMatcher:
    def __init__(self) -> None:
        self.loaded_at = 0.0
        self.products: List[IndexedProduct] = []
        self.by_exact: Dict[str, List[IndexedProduct]] = {}
        self.by_brand: Dict[str, List[IndexedProduct]] = {}
        self.brand_names: Set[str] = set()
        self.identity_normalizer: Optional[BrandFamilyNormalizer] = None
        self.safety = CandidateSafetyFilter(WEAK_TOKENS)

    def invalidate(self) -> None:
        self.loaded_at = 0.0
        self.products = []
        self.by_exact = {}
        self.by_brand = {}
        self.brand_names = set()
        self.identity_normalizer = None

    def preload(self) -> int:
        self._load()
        return len(self.products)

    def _add_exact(self, key: str, ip: IndexedProduct) -> None:
        key = _n(key)
        if not key:
            return
        if len(key) <= 2:
            return
        toks = _word_tokens(key)
        if toks and not any((t not in WEAK_TOKENS and not t.isdigit() and len(t) > 2) for t in toks):
            return
        ip.exact_keys.add(key)
        self.by_exact.setdefault(key, []).append(ip)
        c = _compact(key)
        if c and c != key and len(c) >= 4:
            ip.exact_keys.add(c)
            self.by_exact.setdefault(c, []).append(ip)

    def _load(self) -> None:
        if self.loaded_at and self.products:
            return
        rows = database.load_product_rows(visible_only=True, guided=False)
        normalizer = BrandFamilyNormalizer(rows)
        generator = CatalogAliasGenerator(normalizer)
        self.identity_normalizer = normalizer
        products: List[IndexedProduct] = []
        self.by_exact = {}
        self.by_brand = {}
        self.brand_names = set()
        for raw_product in rows:
            p = normalizer.normalize_row(dict(raw_product))
            # Preserve operational columns while using brand-first identity fields.
            for k, v in raw_product.items():
                if k not in p or p.get(k) in {"", None}:
                    p[k] = v
            try:
                pid = int(p.get("id") or 0)
            except Exception:
                pid = 0
            if not pid:
                continue
            name = _display_name(p)
            if not name:
                continue
            brand = _n(p.get("brand"))
            if not brand or brand in {"unknown", "غير مصنف", "غير معروف", "unclassified"}:
                toks = _word_tokens(name)
                inferred = toks[0] if toks else ""
                # Do not create fake brands from generic OCR/display words such as WHITE or PETROLEUM.
                brand = inferred if inferred and inferred not in VISION_NON_BRAND_TOKENS else ""
            family = _n(p.get("product_family") or name)
            category = _n(p.get("category") or p.get("main_section") or p.get("section"))
            form = canonical_form(p.get("form") or p.get("medicine_form") or p.get("product_type") or name) or ""
            gen_aliases, gen_ocr = generator.identity_variations(p)
            generated_identity = gen_aliases + gen_ocr
            fields = [name, p.get("canonical_display_name"), p.get("normalized_name"), p.get("brand"), p.get("product_family"), p.get("active_ingredient"), p.get("aliases"), p.get("ocr_keywords"), p.get("barcode"), p.get("form"), p.get("strength"), p.get("size"), p.get("pack")] + generated_identity
            identity_text = _n(" ".join(str(x or "") for x in fields))
            token_set = set(_word_tokens(identity_text))
            strong_set = set(_strong_tokens(identity_text))
            measures = _measures(identity_text)
            ip = IndexedProduct(
                product=p,
                product_id=pid,
                name=name,
                brand=brand,
                family=family,
                category=category,
                form=form,
                identity_text=identity_text,
                identity_compact=_compact(identity_text),
                token_set=token_set,
                strong_set=strong_set,
                measures=measures,
                identity_key=_product_identity_key(p),
            )
            products.append(ip)
            if brand:
                self.brand_names.add(brand)
                self.by_brand.setdefault(brand, []).append(ip)
            # Exact resolvable names/aliases.  Single generic brand keys are
            # indexed but variant guard will force clarification when needed.
            self._add_exact(name, ip)
            self._add_exact(p.get("normalized_name"), ip)
            self._add_exact(p.get("brand"), ip)
            self._add_exact(p.get("product_family"), ip)
            self._add_exact(p.get("barcode"), ip)
            for field in [p.get("aliases"), p.get("ocr_keywords")]:
                for part in split_multi(field):
                    self._add_exact(part, ip)
            for part in generated_identity:
                self._add_exact(part, ip)
        # Remove duplicate references under same key/product.
        for key, vals in list(self.by_exact.items()):
            seen = set()
            dedup = []
            for ip in vals:
                if ip.product_id in seen:
                    continue
                seen.add(ip.product_id)
                dedup.append(ip)
            self.by_exact[key] = dedup
        self.products = products
        self.loaded_at = _now()

    def _record_learning(self, query: str, decision: str, reason: str, candidates: Sequence[IndexedProduct] = (), vision_text: str = "", slots: Optional[Dict[str, Any]] = None, rejected: Sequence[IndexedProduct] = (), candidate_payloads: Optional[Sequence[Dict[str, Any]]] = None) -> None:
        if str(os.getenv("PRICEBOT_LEARNING_ENABLED", "1")).lower() in {"0", "false", "no", "off"}:
            return
        try:
            database.record_learning_event(
                customer_query=query,
                vision_text=vision_text,
                candidate_products=list(candidate_payloads or [])[:15] if candidate_payloads is not None else [{"id": ip.product_id, "name": ip.name, "price": ip.product.get("price")} for ip in list(candidates)[:15]],
                rejected_candidates=[{"id": ip.product_id, "name": ip.name} for ip in list(rejected)[:20]],
                decision=decision,
                reason=reason,
                query_slots=slots or {},
            )
        except Exception:
            pass

    def _result(self, status: str, message: str = "", products: Sequence[IndexedProduct] = (), product: Optional[IndexedProduct] = None, diagnostics: Optional[Dict[str, Any]] = None, learn_query: str = "", learn_reason: str = "", vision_text: str = "") -> SearchResult:
        plist = [ip.product for ip in products]
        one = product.product if product else None
        res = SearchResult(status=status, message=message, products=plist, product=one, diagnostics=diagnostics or {})
        if status in {"NOT_AVAILABLE", "LOW_CONFIDENCE", "IMAGE_UNCLEAR"}:
            lq = learn_query or message
            suggestions = []
            if lq and not products and self.products:
                suggestions = suggest_learning_candidates(lq, [ip.product for ip in self.products], limit=5)
            self._record_learning(lq, status, learn_reason or status, products, vision_text=vision_text, slots=diagnostics or {}, candidate_payloads=suggestions or None)
        return res

    def _ask_message(self, products: Sequence[IndexedProduct], title: str = "🔎 وجدت أكثر من منتج قريب") -> str:
        return clarification_message([ip.product for ip in products[:10]], title=title)

    def _dedupe(self, items: Iterable[IndexedProduct], limit: int = 30) -> List[IndexedProduct]:
        out: List[IndexedProduct] = []
        seen: Set[int] = set()
        for ip in items:
            if ip.product_id in seen:
                continue
            seen.add(ip.product_id)
            out.append(ip)
            if len(out) >= limit:
                break
        return out

    def _sort_candidates(self, q: str, cands: Iterable[IndexedProduct]) -> List[IndexedProduct]:
        qn = _n(q)
        qs = set(_strong_tokens(qn))
        qmeasures = _measures(qn)
        qform = canonical_form(qn)
        scored = []
        for ip in cands:
            score = 0
            if _n(ip.name) == qn or qn in ip.exact_keys or _compact(qn) in ip.exact_keys:
                score += 1000
            if qn and _phrase_in(qn, ip.identity_text):
                score += 300
            score += 30 * len(qs & ip.strong_set)
            score += 10 * len(qmeasures & ip.measures)
            if qform and _form_match(qform, ip.form, ip.identity_text):
                score += 80
            # Prefer shorter identities when exact enough.
            score -= min(len(ip.token_set), 80) // 10
            scored.append((score, ip.name.lower(), ip))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [ip for score, _name, ip in scored if score > 0]

    def _variant_scope(self, qn: str, strong: List[str]) -> List[IndexedProduct]:
        # Brand/family scope uses full token matching only, never substring.
        if not strong:
            return []
        first = strong[0]
        scoped: List[IndexedProduct] = []
        if first in self.by_brand:
            scoped.extend(self.by_brand[first])
        # Full phrase at start of identity/family/name.
        for ip in self.products:
            if ip.product_id in {x.product_id for x in scoped}:
                continue
            if ip.brand == first or _n(ip.name).startswith(first + " ") or (ip.family == first or ip.family.startswith(first + " ")):
                scoped.append(ip)
            elif qn and (_n(ip.name) == qn or _n(ip.name).startswith(qn + " ") or _phrase_in(qn, ip.family)):
                scoped.append(ip)
        return self._dedupe(scoped, 50)

    def _generic_variant_guard(self, qn: str, qform: str, qmeasures: Set[str], candidates: Sequence[IndexedProduct]) -> Optional[SearchResult]:
        strong = _strong_tokens(qn)
        if not strong:
            return None
        # Query is general if it has only brand/family token(s), no measure and no form.
        q_is_general = not qform and not qmeasures and (len(_word_tokens(qn)) == 1 or qn in GENERIC_FAMILY_WORDS)
        if not q_is_general:
            return None
        scope = self._variant_scope(qn, strong)
        if len(scope) > 1:
            return self._result(
                "ASK_CLARIFICATION",
                self._ask_message(scope, "يوجد أكثر من نوع/شكل لهذا الاسم. لا أستطيع عرض السعر قبل تحديد المنتج."),
                products=scope,
                diagnostics={"engine": "excel_native", "stage": "generic_variant_guard", "query": qn},
            )
        if len(candidates) > 1:
            return self._result(
                "ASK_CLARIFICATION",
                self._ask_message(candidates, "يوجد أكثر من نتيجة بنفس الاسم. اختر المنتج المطلوب."),
                products=candidates,
                diagnostics={"engine": "excel_native", "stage": "generic_exact_guard", "query": qn},
            )
        return None

    def _duplicate_guard(self, candidates: Sequence[IndexedProduct], qn: str) -> Optional[SearchResult]:
        if not candidates:
            return None
        by_key: Dict[Tuple[str, str, str, str, str, str, str], List[IndexedProduct]] = {}
        for ip in candidates:
            by_key.setdefault(ip.identity_key, []).append(ip)
        conflict_group: List[IndexedProduct] = []
        for group in by_key.values():
            if _price_conflict([g.product for g in group]):
                conflict_group = group
                break
        if conflict_group:
            return self._result(
                "ASK_CLARIFICATION",
                self._ask_message(conflict_group, "هذا المنتج موجود بأكثر من سعر في الملف ويحتاج مراجعة قبل عرض السعر."),
                products=conflict_group,
                diagnostics={"engine": "excel_native", "stage": "duplicate_price_conflict", "query": qn},
            )
        return None

    def _requested_brand_from_query(self, qn: str, strong: Sequence[str]) -> str:
        for token in strong:
            if token in self.brand_names:
                return token
        if self.identity_normalizer:
            brand, _display = self.identity_normalizer.detect_brand({"name": qn})
            if brand in self.brand_names:
                return brand
        return ""

    def _requested_family_from_query(self, qn: str, requested_brand: str) -> str:
        family = qn
        if requested_brand:
            family = re.sub(r"(^|\s)" + re.escape(requested_brand) + r"(?=\s|$)", " ", family).strip()
        # Remove form and measure words from family lock; OCR marketing extras are handled by safety.
        toks = [t for t in _strong_tokens(family) if t != requested_brand]
        return " ".join(toks[:4])

    def _finalize_candidates(self, q: str, cands: Sequence[IndexedProduct], reason: str = "") -> SearchResult:
        qn = _n(q)
        qform = canonical_form(qn)
        qmeasures = _measures(qn)
        strong = _strong_tokens(qn)
        requested_brand = self._requested_brand_from_query(qn, strong)
        requested_family = self._requested_family_from_query(qn, requested_brand)
        exact_allowed = reason in {"exact_key", "barcode_exact", "known_vision_identity"}
        if not cands:
            return self._result("NOT_AVAILABLE", "لم أجد المنتج في قائمة الصيدلية حاليًا. إذا الاسم صحيح، سيتم تسجيله للمراجعة.", learn_query=q, learn_reason=reason or "no_candidates")
        cands = self._sort_candidates(qn, self._dedupe(cands, 50))
        safety = self.safety.filter(
            qn, cands,
            requested_brand=requested_brand,
            requested_family=requested_family if requested_brand else "",
            requested_form=qform,
            exact_allowed=exact_allowed,
            limit=5,
        )
        if safety.products:
            cands = safety.products
        elif not exact_allowed:
            if not safety.strong_tokens:
                return self._result("LOW_CONFIDENCE", "لم أتمكن من تحديد اسم المنتج بوضوح. اكتب الاسم كاملًا أو أرسل صورة أوضح للواجهة الأمامية.", learn_query=q, learn_reason="weak_tokens_only", diagnostics={"engine":"excel_native", "stage":"candidate_safety_filter", "rejected": safety.rejected})
            return self._result("NOT_AVAILABLE", "لم أجد المنتج في قائمة الصيدلية حاليًا. إذا الاسم صحيح، سيتم تسجيله للمراجعة.", learn_query=q, learn_reason="candidate_safety_rejected", diagnostics={"engine":"excel_native", "stage":"candidate_safety_filter", "rejected": safety.rejected})
        # Apply requested form and measures as hard filters when present.
        if qform:
            form_filtered = [ip for ip in cands if _form_match(qform, ip.form, ip.identity_text)]
            if form_filtered:
                cands = form_filtered
            elif requested_brand and len(strong) >= 2 and qform not in COSMETIC_HARD_FORMS and any(not ip.form for ip in cands):
                # Keep same-brand/family catalog entries whose old medicine/supplement rows lack form.
                # Cosmetic types are hard constraints: cleanser must not become serum/lotion/cream.
                cands = [ip for ip in cands if not ip.form]
            elif qform in {"capsule", "tablet"}:
                # Package OCR often reads "capsules/tablets" while the raw Excel
                # name has only the brand/strength. Do not reject an otherwise
                # exact supplement/medicine identity only because pack form is
                # missing from Excel. Syrup/cleanser/cream/etc remain hard filters.
                pass
            else:
                return self._result("NOT_AVAILABLE", "لم أجد نفس الشكل المطلوب في قائمة الصيدلية حاليًا.", learn_query=q, learn_reason="requested_form_not_found", diagnostics={"requested_form": qform})
        if qmeasures:
            measure_filtered = [ip for ip in cands if qmeasures <= ip.measures or any(m in ip.identity_compact for m in qmeasures)]
            if measure_filtered:
                cands = measure_filtered
            else:
                # Strength/size/pack is a hard identity field in V5.  A clear
                # request for 4g/200ml/500mg must never sell a 10g/400ml/250mg
                # row just because brand/family matched.  The UI may mention
                # nearby products from diagnostics, but no price/availability is
                # shown until the user searches or selects an exact catalog row.
                safe_nearby = [{"id": ip.product_id, "name": ip.name} for ip in list(cands)[:5]]
                return self._result(
                    "NOT_AVAILABLE",
                    "لم أجد نفس التركيز أو الحجم المطلوب بدقة في قائمة الصيدلية حاليًا.",
                    learn_query=q,
                    learn_reason="requested_measure_not_found",
                    diagnostics={
                        "engine": "excel_native",
                        "stage": "requested_measure_not_found",
                        "requested_measures": sorted(qmeasures),
                        "nearby_same_family": safe_nearby,
                    },
                )
        dup = self._duplicate_guard(cands, qn)
        if dup:
            return dup
        generic = self._generic_variant_guard(qn, qform, qmeasures, cands)
        if generic:
            return generic
        if len(cands) == 1:
            ip = cands[0]
            # If the match is weak (only one weak/generic token), refuse.
            qs = set(_strong_tokens(qn))
            if not qs and not qmeasures and not qform:
                return self._result("LOW_CONFIDENCE", "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل أو أرسل صورة أوضح.", learn_query=q, learn_reason="weak_single_candidate")
            return self._result("EXACT_MATCH", product=ip, products=[ip], diagnostics={"engine": "excel_native", "stage": reason or "exact"})
        # If all candidates are same identity and same price, choose one. Otherwise clarify.
        identity_keys = {ip.identity_key for ip in cands}
        prices = {safe_price(ip.product.get("price")) for ip in cands if safe_price(ip.product.get("price"))}
        if len(identity_keys) == 1 and len(prices) == 1:
            return self._result("EXACT_MATCH", product=cands[0], products=[cands[0]], diagnostics={"engine":"excel_native", "stage":"same_identity_same_price"})
        return self._result("ASK_CLARIFICATION", self._ask_message(cands, "وجدت أكثر من منتج قريب. اختر المنتج المطلوب قبل عرض السعر."), products=cands, diagnostics={"engine":"excel_native", "stage":"multiple_candidates", "query": qn})

    def match_text(self, query: str) -> SearchResult:
        self._load()
        raw = str(query or "").strip()
        qn = clean_query(raw)
        qn = _n(qn)
        if not qn:
            return self._result("LOW_CONFIDENCE", "اكتب اسم المنتج أو أرسل صورة واضحة.", learn_query=raw, learn_reason="empty_query")
        # barcode exact.
        if re.fullmatch(r"\d{8,14}", qn):
            return self._finalize_candidates(raw, self.by_exact.get(qn, []), "barcode_exact")
        qcompact = _compact(qn)
        exact = []
        exact.extend(self.by_exact.get(qn, []))
        if qcompact != qn:
            exact.extend(self.by_exact.get(qcompact, []))
        exact = self._dedupe(exact, 50)
        if exact:
            return self._finalize_candidates(raw, exact, "exact_key")
        strong = _strong_tokens(qn)
        qform = canonical_form(qn)
        qmeasures = _measures(qn)
        if not strong and qmeasures:
            return self._result("LOW_CONFIDENCE", "لم أتمكن من تحديد المنتج من الحجم أو التركيز فقط. اكتب اسم المنتج كاملًا.", learn_query=raw, learn_reason="measure_only")
        if not strong and (qform or not qmeasures):
            return self._result("ASK_CLARIFICATION", "اكتب اسم المنتج مع النوع أو الشكل. لا أستطيع البحث بكلمة عامة فقط.", learn_query=raw, learn_reason="generic_or_type_only")
        # Brand/family scoped candidate search.  No full catalog substring fallback.
        scoped = self._variant_scope(qn, strong)
        if strong and len(strong) == 1 and len(scoped) > 1 and not qform and not qmeasures:
            return self._result("ASK_CLARIFICATION", self._ask_message(scoped, "يوجد أكثر من منتج بهذا الاسم. اختر المطلوب."), products=scoped, diagnostics={"engine":"excel_native", "stage":"single_token_scope"})
        if not scoped:
            # If first token is not a known brand/family, safe token scan using full tokens only.
            token_hits: List[IndexedProduct] = []
            for ip in self.products:
                if strong and set(strong).issubset(ip.token_set):
                    token_hits.append(ip)
            scoped = self._dedupe(token_hits, 50)
        else:
            # Within safe scope, require all strong tokens where possible.
            narrowed = [ip for ip in scoped if set(strong).issubset(ip.token_set) or _phrase_in(qn, ip.identity_text) or qcompact in ip.identity_compact]
            if narrowed:
                scoped = narrowed
        if not scoped:
            return self._result("NOT_AVAILABLE", "لم أجد المنتج في قائمة الصيدلية حاليًا. إذا الاسم صحيح، سيتم تسجيله للمراجعة.", learn_query=raw, learn_reason="no_safe_scoped_candidate")
        return self._finalize_candidates(raw, scoped, "scoped_token_match")

    def _vision_query(self, slots: Dict[str, Any]) -> Tuple[str, str]:
        # Keep full OCR text available until the final decision.  Vision slots can
        # be weak or wrong (e.g. brand=WHITE, product_name=""), so structured fields
        # are preferred only when they contain real identity information.
        visible_candidates = [
            str(slots.get("visible_text") or ""),
            str(slots.get("raw_vision_text") or ""),
            str(slots.get("main_visible_product") or ""),
            str(slots.get("foreground_product_text") or ""),
            str(slots.get("product_name") or ""),
            str(slots.get("product_family") or ""),
            str(slots.get("brand") or ""),
        ]
        visible = " ".join(x for x in visible_candidates if x.strip()).strip()
        # Primary OCR evidence is checked before structured model guesses.  This
        # prevents a hallucinated product_name from overriding real words on the
        # package.
        evidence = _vision_evidence_text(slots, strict_only=True) or _vision_evidence_text(slots, strict_only=False)
        n = _n(visible)
        c = _compact(visible)
        evidence_norm = _n(evidence)
        evidence_compact = _compact(evidence_norm)
        # Partial Remedica package without actual product name must not become NOT_AVAILABLE or random exact.
        vtokens = set(_word_tokens(n))
        for pattern in IMAGE_LOW_CONFIDENCE_PATTERNS:
            if pattern <= vtokens and not any(x in n for x in ["zithro", "amoclan", "cefix", "paracetamol", "flagyl"]):
                return "", "low_confidence_partial_package"
        for key, target in KNOWN_VISION_ALIASES.items():
            # Prefer OCR evidence over structured fields.  If visible_text says
            # Hemazym but product_name says a different catalog item, Hemazym wins.
            if (evidence_norm and (_compact(key) in evidence_compact or key in evidence_norm)) or (_compact(key) in c or key in n):
                # Preserve measures to resolve variants.
                measures = extract_strengths(evidence or visible) + extract_sizes(evidence or visible) + extract_packs(evidence or visible)
                form = canonical_form(evidence or visible)
                return " ".join([target, form or ""] + measures).strip(), "known_vision_identity"

        product_bits = []
        for k in ["main_visible_product", "product_name", "product_family", "form", "strength", "size", "pack"]:
            val = str(slots.get(k) or "").strip()
            if val:
                product_bits.append(val)
        brand = str(slots.get("brand") or "").strip()
        brand_norm = _n(brand)
        structured_parts = ([brand] if brand else []) + product_bits
        structured = " ".join(structured_parts).strip()

        # If the structured output is brand-only, or the brand is actually a generic
        # package word, use the full OCR phrase first.  This fixes images like:
        # brand=WHITE, product_name="", visible_text="WHITE PETROLEUM JELLY".
        has_identity_slot = any(str(slots.get(k) or "").strip() for k in ["main_visible_product", "product_name", "product_family"])
        brand_only = bool(brand) and not product_bits and not has_identity_slot
        fake_brand_only = bool(brand_norm and brand_norm in VISION_NON_BRAND_TOKENS and not has_identity_slot)
        q = structured
        reason = "structured_vision_slots"
        if q and evidence_norm:
            supported, evidence_reason = _query_supported_by_visible_evidence(q, evidence_norm)
            if not supported:
                # Do not let hallucinated structured names drive catalog lookup.
                # Use visible OCR instead; if that is too weak, later guards will
                # return LOW_CONFIDENCE rather than unrelated suggestions.
                q = evidence_norm
                reason = f"structured_rejected_by_evidence:{evidence_reason}"
        if (brand_only or fake_brand_only or not _strong_tokens(structured)) and visible.strip() and not reason.startswith("structured_rejected_by_evidence"):
            q = visible.strip()
            reason = "full_ocr_phrase_fallback"

        if q and not _strong_tokens(q):
            return "", "vision_weak_tokens_only"
        if q and _measures(q) and not _strong_tokens(q):
            return "", "vision_measure_only"
        return q, reason

    def _clean_vision_ocr_tokens(self, text: str) -> List[str]:
        """Return stable OCR identity tokens for image candidate generation.

        Raw OCR often contains marketing/background words and cut fragments such
        as ``aderm`` or ``dol``.  The matcher is intentionally strict, so the
        image bridge must turn OCR into safe product-name candidates before
        matching.  This function does not decide matches; it only prepares
        candidate text while preserving the original OCR in diagnostics.
        """
        n = _n(text)
        if not n:
            return []
        raw_tokens = _word_tokens(n)
        ctx = set(raw_tokens)
        out: List[str] = []
        for token in raw_tokens:
            fixed = token
            if token in VISION_OCR_FRAGMENT_FIXES:
                replacement = VISION_OCR_FRAGMENT_FIXES[token]
                # Correct only inside a safe context.
                if replacement in ctx or replacement in n or (replacement == "normaderm" and "vichy" in ctx) or (replacement == "panadol" and {"extra", "advance", "advanced"} & ctx):
                    fixed = replacement
            if fixed in VISION_OCR_NOISE_TOKENS:
                continue
            if len(fixed) <= 1:
                continue
            if fixed not in out:
                out.append(fixed)
        return out

    def _append_candidate(self, candidates: List[Tuple[str, str]], query: str, reason: str) -> None:
        query = _n(query)
        if not query:
            return
        # Keep candidate strings usable.  Very long OCR text is reintroduced as
        # n-grams/brand candidates instead of one huge query.
        allowed_long_reasons = ("structured_vision_slots", "known_vision_identity", "full_ocr_phrase_fallback", "structured_rejected_by_evidence")
        if len(query.split()) > 8 and not any(str(reason or "").startswith(r) for r in allowed_long_reasons):
            return
        key = _compact(query)
        if not key:
            return
        if any(_compact(q) == key for q, _r in candidates):
            return
        candidates.append((query, reason))

    def _vision_candidate_queries(self, slots: Dict[str, Any], base_query: str = "", base_reason: str = "") -> List[Tuple[str, str]]:
        """Build ordered candidate queries from structured vision slots + OCR.

        Images should not be matched by a single raw OCR string.  This creates
        safe externally-reviewed candidate phrases from structured foreground
        OCR while ignoring marketing/background noise.
        """
        candidates: List[Tuple[str, str]] = []
        evidence = _vision_evidence_text(slots, strict_only=True) or _vision_evidence_text(slots, strict_only=False)

        def add_candidate(q: str, reason: str) -> None:
            ok, evidence_reason = _query_supported_by_visible_evidence(q, evidence)
            if not ok:
                return
            self._append_candidate(candidates, q, reason if evidence_reason == "no_evidence_text" else f"{reason}|evidence:{evidence_reason}")

        if base_query:
            add_candidate(base_query, base_reason or "base_vision_query")

        # Structured fields first when they contain real identity.
        brand = str(slots.get("brand") or "").strip()
        main = str(slots.get("main_visible_product") or "").strip()
        product_name = str(slots.get("product_name") or "").strip()
        family = str(slots.get("product_family") or "").strip()
        form = str(slots.get("form") or slots.get("product_type") or "").strip()
        measures = []
        for k in ["strength", "size", "pack"]:
            v = str(slots.get(k) or "").strip()
            if v:
                measures.append(v)
        structured_candidates: List[Tuple[str, str]] = [
            (main, "main_visible_product"),
            (product_name, "product_name"),
        ]
        # Never add a brand-only image candidate.  Brand-only exact matches hide
        # the useful OCR candidate and can pick/clarify the wrong product family
        # (e.g. Panadol image OCR should try Panadol Extra, not Panadol brand).
        if brand and product_name:
            structured_candidates.append((" ".join([brand, product_name] + measures).strip(), "brand_product_name"))
        if brand and (family or form or measures):
            structured_candidates.append((" ".join([brand, family, form] + measures).strip(), "brand_family_form"))
        if family and brand:
            structured_candidates.append((" ".join([family, brand] + measures).strip(), "family_brand"))
        for q, reason in structured_candidates:
            add_candidate(q, reason)

        visible = " ".join(str(slots.get(k) or "") for k in ["visible_text", "raw_vision_text", "background_text"] if slots.get(k)).strip()
        visible_norm = _n(visible)
        compact_visible = _compact(visible)

        # Externally reviewed OCR phrase rules.  No product-specific phrase is
        # hardcoded here; data/catalog_corrections.json owns these corrections.
        for rule in VISION_PHRASE_RULES:
            required = [normalize_text(x) for x in (rule.get("required") or []) if normalize_text(x)]
            queries = [str(x or "") for x in (rule.get("queries") or []) if str(x or "").strip()]
            reason = str(rule.get("reason") or "catalog_ocr_phrase_rule")
            if required and all(req in visible_norm.split() or req in compact_visible for req in required):
                for q in queries:
                    add_candidate(q, reason)

        tokens = self._clean_vision_ocr_tokens(visible)
        if tokens:
            cleaned = " ".join(tokens)
            add_candidate(cleaned, "cleaned_ocr")

            # Brand + nearby/important token candidates.  This is deliberately
            # scoped to known catalog brands to avoid global fuzzy matching.
            token_set = set(tokens)
            known_brands = [b for b in self.brand_names if len(b) > 2 and b not in VISION_OCR_NOISE_TOKENS and (b in token_set or _compact(b) in compact_visible)]
            # Add explicit brand-like tokens that may not be a catalog brand due
            # to old raw Excel rows but are part of exact OCR aliases.
            for b in sorted(VISION_EXTRA_BRAND_TOKENS):
                if b in token_set and b not in known_brands:
                    known_brands.append(b)
            for b in known_brands[:6]:
                important = [t for t in tokens if t != b and (t not in VISION_OCR_NOISE_TOKENS)]
                # Prefer stable product-family words immediately useful for the
                # current catalog.  We keep weak-looking words here because exact
                # aliases such as WHITE PETROLEUM JELLY need them.
                for width in [3, 2, 1]:
                    if len(important) >= width:
                        add_candidate(" ".join([b] + important[:width]), f"ocr_brand_plus_{width}")
                for t in important[:5]:
                    add_candidate(f"{b} {t}", "ocr_brand_token")
                    add_candidate(f"{t} {b}", "ocr_token_brand")

            # Sliding n-grams catch clean chunks even when OCR starts with a cut
            # fragment.  Longest chunks first.
            max_len = min(5, len(tokens))
            for width in range(max_len, 1, -1):
                for i in range(0, len(tokens) - width + 1):
                    gram = tokens[i:i + width]
                    if not gram:
                        continue
                    # Skip pure generic/form chunks unless they are exact phrase
                    # cases handled above.
                    allowed_ocr_terms = set(self.brand_names) | VISION_EXTRA_BRAND_TOKENS
                    if not any(t in allowed_ocr_terms for t in gram):
                        continue
                    add_candidate(" ".join(gram), f"ocr_ngram_{width}")

        return candidates[:40]


    # PRICEBOT_V5_IMAGE_CANDIDATE_SAFETY_FINAL
    def _vision_has_enough_identity(self, slots: Dict[str, Any], visible: str) -> bool:
        structured = " ".join(str(slots.get(k) or "") for k in ["foreground_product_text", "main_visible_product", "brand", "product_name", "product_family"]).strip()
        if len(_strong_tokens(structured)) >= 1 and any(str(slots.get(k) or "").strip() for k in ["brand", "product_name", "product_family", "main_visible_product", "foreground_product_text"]):
            return True
        # Reviewed catalog OCR phrase rules count as identity evidence without
        # hardcoding product names in code.  Example: externally-reviewed aliases
        # can make WHITE PETROLEUM JELLY safe while generic "cream tube 250g" stays weak.
        visible_norm = _n(visible)
        compact_visible = _compact(visible)
        for rule in VISION_PHRASE_RULES:
            required = [normalize_text(x) for x in (rule.get("required") or []) if normalize_text(x)]
            if required and all(req in visible_norm.split() or req in compact_visible for req in required):
                return True
        toks = []
        for t in _word_tokens(visible):
            if t in WEAK_TOKENS or t in VISION_OCR_NOISE_TOKENS or t in MEASURE_TOKENS:
                continue
            if normalize_measure(t):
                continue
            if t.isdigit() or len(t) <= 2:
                continue
            toks.append(t)
        # Allow exact multi-word package identities such as WHITE PETROLEUM JELLY,
        # but reject generic visual descriptions such as "cream tube 250g".
        return len(set(toks)) >= 2

    def _vision_exact_candidate_safe(self, slots: Dict[str, Any], result: SearchResult, candidate_query: str, visible: str) -> Tuple[bool, str]:
        if result.status != "EXACT_MATCH" or not result.product:
            return True, "not_exact"
        product = result.product
        product_text = " ".join(str(product.get(k) or "") for k in [
            "name", "canonical_display_name", "original_name", "brand", "product_family",
            "active_ingredient", "form", "medicine_form", "strength", "size", "pack", "aliases", "ocr_keywords",
        ])
        vision_text = " ".join(str(slots.get(k) or "") for k in [
            "foreground_product_text", "main_visible_product", "brand", "product_name", "product_family",
            "form", "strength", "size", "pack", "visible_text", "raw_vision_text",
        ]) + " " + str(candidate_query or "")

        # Evidence lock: exact image matches must be backed by OCR-like text from
        # the package, not only by a structured model guess.  This is the guard
        # that prevents a Hemazym photo from suggesting high life hair cream.
        evidence_text = _vision_evidence_text(slots, strict_only=True) or _vision_evidence_text(slots, strict_only=False)
        evidence_ok, evidence_reason = _product_supported_by_visible_evidence(product_text, candidate_query, evidence_text)
        if not evidence_ok:
            return False, evidence_reason

        # Brand lock: if Vision confidently extracted a brand, do not accept a different brand.
        requested_brand = _n(slots.get("brand"))
        if requested_brand and requested_brand not in VISION_NON_BRAND_TOKENS:
            pt = _n(product_text)
            if requested_brand not in pt and requested_brand not in _compact(product_text):
                return False, "brand_mismatch"

        # Hard form/type lock for cosmetics and dosage forms.  This prevents
        # Cerave Cleanser images from selecting serum/lotion/cream candidates.
        # However, form slots coming from a hallucinated product_name must not
        # override real OCR evidence.  Example: Hemazym image with a bad model
        # guess form=cream should still resolve as capsule because "cream" is
        # not visible while "30 capsules" is visible.
        raw_requested_form = str(slots.get("form") or slots.get("product_type") or "").strip()
        if raw_requested_form and evidence_text:
            form_ok, _form_reason = _query_supported_by_visible_evidence(raw_requested_form, evidence_text)
            if not form_ok:
                raw_requested_form = ""
        requested_form = canonical_form(raw_requested_form or candidate_query or evidence_text or vision_text)
        if requested_form in COSMETIC_HARD_FORMS or requested_form in {"tablet", "capsule", "syrup", "suspension", "suppository", "ointment"}:
            product_form = canonical_form(product.get("form") or product.get("medicine_form") or product_text)
            if not _form_match(requested_form, product_form, product_text):
                return False, "form_mismatch"
            # Extra lexical guard for common cosmetic cross-type mistakes when the
            # catalog form is missing but product name reveals a different type.
            pt = _n(product_text)
            incompatible = {
                "cleanser": {"serum", "lotion", "cream", "moisturizer", "shampoo", "conditioner", "toner"},
                "serum": {"cleanser", "lotion", "cream", "shampoo"},
                "lotion": {"serum", "cleanser", "shampoo"},
                "cream": {"cleanser", "serum", "shampoo"},
                "shampoo": {"cleanser", "serum", "lotion", "cream"},
            }
            if requested_form in incompatible and any(x in pt for x in incompatible[requested_form]) and requested_form not in pt:
                return False, "cosmetic_type_mismatch"

        # Size/strength hard guard: if both image and matched product contain
        # explicit measures, they must overlap.  If product has no measure, keep
        # it as a confirmation candidate rather than false-rejecting old catalog rows.
        requested_measures = _measures(vision_text)
        product_measures = set(getattr(next((ip for ip in self.products if ip.product_id == int(product.get("id") or -1)), None), "measures", set()) or set()) | _measures(product_text)
        if requested_measures and product_measures and not (requested_measures & product_measures):
            return False, "measure_mismatch"

        return True, "safe"

    # PRICEBOT_V5_IMAGE_CANDIDATE_SUGGESTION_GENERAL_V1
    def _vision_candidate_suggestion(self, slots: Dict[str, Any], visible: str, query: str, reason: str, stage: str) -> Optional[SearchResult]:
        """Return safe confirmation candidates for images without showing price.

        Price display requires complete/final identity. Image confirmation only
        needs enough foreground identity to suggest same-brand/same-family
        candidates without price. This prevents false price/availability while
        avoiding false rejection of readable images where size/form is unclear.
        """
        candidates = self._vision_candidate_queries(slots, query, reason)
        if not candidates:
            return None

        attempted: List[Dict[str, str]] = []
        collected: List[Dict[str, Any]] = []
        seen_ids: Set[int] = set()

        def add_products(products: Sequence[Dict[str, Any]]) -> None:
            for p in products or []:
                try:
                    pid = int(p.get("id") or 0)
                except Exception:
                    pid = 0
                if not pid or pid in seen_ids:
                    continue
                if not database.product_visible(p, guided=False):
                    continue
                seen_ids.add(pid)
                collected.append(p)

        for candidate_query, candidate_reason in candidates[:24]:
            result = self.match_text(candidate_query)
            attempted.append({"query": candidate_query, "reason": candidate_reason, "decision": result.status})

            if result.status == "EXACT_MATCH" and result.product:
                safe, safety_reason = self._vision_exact_candidate_safe(slots, result, candidate_query, visible)
                attempted[-1]["safety"] = safety_reason
                if safe:
                    add_products([result.product])
                else:
                    attempted[-1]["decision"] = "REJECTED_" + safety_reason
                continue

            if result.status in {"ASK_CLARIFICATION", "PRODUCT_LIST", "COSMETIC_ALTERNATIVES"} and result.products:
                add_products(result.products)
                if len(collected) >= 6:
                    break

        if not collected:
            return None

        visible_label = str(
            slots.get("foreground_product_text")
            or slots.get("main_visible_product")
            or slots.get("product_name")
            or slots.get("product_family")
            or query
            or visible
            or ""
        ).strip()
        if len(visible_label) > 120:
            visible_label = visible_label[:120].rstrip() + "…"

        msg = "تأكيد المنتج\n"
        if visible_label:
            msg += f"قرأت من الصورة: {visible_label}\n"
        msg += "وجدت منتجًا أو أكثر قريبًا. اختر المنتج من القائمة قبل عرض السعر."

        return self._result(
            "ASK_CLARIFICATION",
            msg,
            products=collected[:10],
            learn_query=query,
            learn_reason=f"vision_candidate_suggestion_{stage}",
            vision_text=visible,
            diagnostics={
                "engine": "excel_native",
                "stage": f"vision_candidate_suggestion_{stage}",
                "slots": slots,
                "vision_query": query,
                "vision_candidates": attempted[:24],
                "candidate_suggestion_without_price": True,
            },
        )

    def _vision_result_score(self, result: SearchResult) -> int:
        if result.status == "EXACT_MATCH" and result.product:
            return 100
        if result.status in {"PRODUCT_LIST", "COSMETIC_ALTERNATIVES"} and result.products:
            # Prefer more focused candidate lists over broad brand-only lists.
            return 70 - min(len(result.products), 30)
        if result.status == "ASK_CLARIFICATION" and result.products:
            return 60 - min(len(result.products), 30)
        if result.status == "LOW_CONFIDENCE":
            return 20
        return 0

    def match_vision_slots(self, slots: Dict[str, Any]) -> SearchResult:
        self._load()
        slots = slots or {}
        visible = str(slots.get("visible_text") or slots.get("raw_vision_text") or slots.get("main_visible_product") or "")
        try:
            conf = float(slots.get("confidence") or 1.0)
        except Exception:
            conf = 1.0
        query, reason = self._vision_query(slots)
        if conf < 0.60:
            return self._result("LOW_CONFIDENCE", "الصورة غير كافية لتحديد المنتج. أرسل صورة أوضح للواجهة الأمامية.", learn_query=query, learn_reason=reason or "vision_low_confidence", vision_text=visible, diagnostics={"engine":"excel_native", "stage": reason, "slots": slots})

        if not self._vision_has_enough_identity(slots, visible):
            suggestion = self._vision_candidate_suggestion(slots, visible, query, reason, "weak_identity")
            if suggestion:
                return suggestion
            return self._result("LOW_CONFIDENCE", "الصورة غير كافية لتحديد المنتج. أرسل صورة أوضح للواجهة الأمامية.", learn_query=query, learn_reason="vision_generic_or_measure_only", vision_text=visible, diagnostics={"engine":"excel_native", "stage":"vision_generic_or_measure_only", "slots": slots})

        # Fast hard measure guard for images: if the photo explicitly says 4g/200ml/etc.
        # and the catalog has the same identity words only with a different measure,
        # do not spend time on broad candidate scans and never sell the other size.
        measure_blob = " ".join(str(slots.get(k) or "") for k in ["foreground_product_text", "main_visible_product", "brand", "product_name", "product_family", "form", "strength", "size", "pack", "visible_text", "raw_vision_text"])
        requested_measures = _measures(measure_blob)
        if requested_measures:
            identity_text = " ".join(str(slots.get(k) or "") for k in ["brand", "product_name", "product_family", "main_visible_product", "foreground_product_text", "visible_text"])
            identity_tokens = [t for t in _strong_tokens(identity_text) if t not in requested_measures and not _measures(t)]
            if identity_tokens:
                scoped = [ip for ip in self.products if any(t in ip.token_set or t in ip.strong_set or t in ip.identity_text for t in identity_tokens)]
                if scoped and any(ip.measures for ip in scoped) and not any(requested_measures & ip.measures for ip in scoped):
                    return self._result(
                        "NOT_AVAILABLE",
                        "قرأت من الصورة حجم/تركيز غير موجود بدقة في القائمة. لن أعرض سعر منتج بحجم مختلف.",
                        learn_query=query,
                        learn_reason="vision_measure_mismatch_fast_guard",
                        vision_text=visible,
                        diagnostics={"engine":"excel_native", "stage":"vision_measure_mismatch_fast_guard", "requested_measures": sorted(requested_measures), "identity_tokens": identity_tokens[:8], "slots": slots},
                    )

        candidates = self._vision_candidate_queries(slots, query, reason)
        if not candidates:
            return self._result("LOW_CONFIDENCE", "الصورة غير كافية لتحديد المنتج. أرسل صورة أوضح للواجهة الأمامية.", learn_query=query, learn_reason=reason or "vision_no_candidates", vision_text=visible, diagnostics={"engine":"excel_native", "stage": reason, "slots": slots})

        best: Optional[SearchResult] = None
        best_query = ""
        best_reason = ""
        attempted: List[Dict[str, str]] = []
        for candidate_query, candidate_reason in candidates:
            result = self.match_text(candidate_query)
            attempted.append({"query": candidate_query, "reason": candidate_reason, "decision": result.status})
            if result.status == "EXACT_MATCH" and result.product:
                safe, safety_reason = self._vision_exact_candidate_safe(slots, result, candidate_query, visible)
                if not safe:
                    attempted[-1]["decision"] = "REJECTED_" + safety_reason
                    attempted[-1]["matched_product"] = str((result.product or {}).get("name") or "")
                    continue
                if result.diagnostics is None:
                    result.diagnostics = {}
                result.diagnostics.update({
                    "vision_query": candidate_query,
                    "vision_stage": candidate_reason,
                    "vision_candidates": attempted[:20],
                    "vision_candidate_safety": safety_reason,
                })
                return result
            if result.status in {"ASK_CLARIFICATION", "COSMETIC_ALTERNATIVES"} and result.products:
                if result.diagnostics is None:
                    result.diagnostics = {}
                result.diagnostics.update({
                    "vision_query": candidate_query,
                    "vision_stage": candidate_reason,
                    "vision_candidates": attempted[:20],
                    "vision_confirmation_fast_path": True,
                })
                return result
            if best is None or self._vision_result_score(result) > self._vision_result_score(best):
                best = result
                best_query = candidate_query
                best_reason = candidate_reason

        if best is None:
            return self._result("LOW_CONFIDENCE", "لم أتمكن من قراءة اسم المنتج بوضوح من الصورة. اكتب الاسم كاملًا أو أرسل صورة أوضح.", learn_query=query, learn_reason="vision_no_match_attempted", vision_text=visible, diagnostics={"engine":"excel_native", "stage":"vision_no_match_attempted", "slots": slots, "vision_candidates": attempted[:20]})

        # If a candidate produced clarification/list, return it instead of a false
        # NOT_AVAILABLE.  This is important for variant-heavy families such as
        # Panadol Extra where image OCR may omit pack/country/size.
        if best.status in {"ASK_CLARIFICATION", "PRODUCT_LIST", "COSMETIC_ALTERNATIVES"}:
            if best.diagnostics is None:
                best.diagnostics = {}
            best.diagnostics.update({
                "vision_query": best_query,
                "vision_stage": best_reason,
                "vision_candidates": attempted[:20],
            })
            return best

        if best.status in {"LOW_CONFIDENCE", "NOT_AVAILABLE", "IMAGE_UNCLEAR"}:
            suggestion = self._vision_candidate_suggestion(slots, visible, query, reason, "fallback_after_no_exact")
            if suggestion:
                return suggestion

        # For image-specific failures, persist raw visible text to learning inbox.
        self._record_learning(query=best_query or query, decision=best.status, reason="vision_candidates_failed", vision_text=visible, slots={**slots, "candidate_queries": attempted[:20]})
        if best.diagnostics is None:
            best.diagnostics = {}
        best.diagnostics.update({
            "vision_query": best_query or query,
            "vision_stage": best_reason or reason,
            "vision_candidates": attempted[:20],
        })
        return best


ENGINE = ExcelNativeMatcher()


def invalidate_memory_index() -> None:
    ENGINE.invalidate()


def preload_search_index() -> int:
    return ENGINE.preload()


def match_text(query: str) -> SearchResult:
    return ENGINE.match_text(query)


def match_vision_slots(slots: Dict[str, Any]) -> SearchResult:
    return ENGINE.match_vision_slots(slots)
