#!/usr/bin/env python3
import argparse
import sys
import traceback
from pathlib import Path
from typing import Dict, List, Tuple

from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from normalizer import normalize_text, safe_price
from search_engine import rebuild_search_index
from guided_commerce import rebuild_guided_index

HEADER_ROW = 3
DATA_START_ROW = 4
REQUIRED_COLUMNS = [
    "product_id", "name", "normalized_name", "brand", "company", "category", "section", "product_family", "form",
    "product_type", "active_ingredient", "strength", "size", "pack", "barcode", "aliases", "ocr_keywords",
    "use_case", "skin_type", "body_area", "age_group", "gender", "medicine_form", "medicine_route", "available",
    "price", "currency", "search_mode", "quality_status", "is_substitutable", "substitution_group_id",
    "review_status", "review_notes", "source_serial", "original_name",
]


def _cell_value(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        try:
            f = float(text)
            if f.is_integer():
                return str(int(f))
        except Exception:
            pass
    return text


def read_excel_rows(path: Path) -> Tuple[List[str], List[Dict[str, str]], int]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    max_row = ws.max_row
    max_col = ws.max_column
    header_values = next(ws.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW, max_col=max_col, values_only=True))
    headers = [_cell_value(v) for v in header_values]
    if not any(headers):
        wb.close()
        raise RuntimeError(f"HEADER_ROW_{HEADER_ROW}_EMPTY")
    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        wb.close()
        raise RuntimeError(f"MISSING_REQUIRED_COLUMNS: {missing}")
    rows: List[Dict[str, str]] = []
    for row_values in ws.iter_rows(min_row=DATA_START_ROW, max_row=max_row, max_col=max_col, values_only=True):
        item: Dict[str, str] = {}
        empty = True
        for header, value in zip(headers, row_values):
            if not header:
                continue
            val = _cell_value(value)
            if val:
                empty = False
            item[header] = val
        if empty:
            continue
        name = item.get("name") or item.get("original_name") or ""
        if not name:
            continue
        if not item.get("product_id"):
            item["product_id"] = f"AUTO-{len(rows)+1}"
        if not item.get("normalized_name"):
            item["normalized_name"] = normalize_text(name)
        if not item.get("currency"):
            item["currency"] = "LYD"
        item["price"] = safe_price(item.get("price"))
        rows.append({k: item.get(k, "") for k in REQUIRED_COLUMNS})
    wb.close()
    return headers, rows, max_row


def import_rows(rows: List[Dict[str, str]]) -> Dict[str, int]:
    inserted = 0
    updated = 0
    skipped = 0
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        existing_cols = set(database.table_columns(conn, "products"))
        cols = [c for c in REQUIRED_COLUMNS if c in existing_cols]
        now_cols = []
        if "updated_at" in existing_cols:
            now_cols.append("updated_at")
        for row in rows:
            if not row.get("name"):
                skipped += 1
                continue
            pid = row.get("product_id") or ""
            found = conn.execute("SELECT id FROM products WHERE product_id=? LIMIT 1", (pid,)).fetchone() if pid else None
            values = [row.get(c, "") for c in cols]
            if found:
                set_clause = ", ".join([f'"{c}"=?' for c in cols])
                if now_cols:
                    set_clause += ", updated_at=CURRENT_TIMESTAMP"
                conn.execute(f'UPDATE products SET {set_clause} WHERE id=?', (*values, int(found[0])))
                updated += 1
            else:
                insert_cols = cols[:]
                placeholders = ["?"] * len(insert_cols)
                if now_cols:
                    insert_cols.extend(now_cols)
                    placeholders.extend(["CURRENT_TIMESTAMP"] * len(now_cols))
                conn.execute(
                    f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})',
                    values,
                )
                inserted += 1
    return {"inserted": inserted, "updated": updated, "skipped": skipped}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Safely import products_master_v22_ready.xlsx into a chosen SQLite DB."
    )
    parser.add_argument("excel_path", help="Path to products_master_v22_ready.xlsx")
    parser.add_argument(
        "--db-path",
        default="",
        help="Explicit SQLite DB path. Recommended in production: /opt/pricebot/pricebot.db",
    )
    return parser.parse_args()


def _abort_if_project_db(db_path: Path) -> None:
    project_root = Path(__file__).resolve().parents[1]
    try:
        if db_path.resolve() == (project_root / "pricebot.db").resolve():
            raise RuntimeError(
                "REFUSING_PROJECT_LOCAL_DB: import_master_excel.py must not create or write "
                "pricebot.db inside the project ZIP/folder. Pass --db-path or set PRICEBOT_DB_PATH."
            )
    except FileNotFoundError:
        # resolve(strict=False) is default on modern Python, but keep this safe.
        pass


def main() -> int:
    args = parse_args()
    excel = Path(args.excel_path).expanduser().resolve()
    if not excel.exists():
        print(f"EXCEL_NOT_FOUND {excel}")
        return 2

    # Configure the database module before any DB read/write/init call.
    database.configure_db_path(args.db_path)
    db_path = database.get_db_path()
    _abort_if_project_db(db_path)

    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={db_path}")
    print(f"EXCEL_PATH={excel}")
    if not args.db_path:
        print("DB_PATH_NOTICE: --db-path was not provided; using resolved env/fallback path above before any write.")

    database.init_db(run_production_guard=False)
    before_integrity = database.integrity_check()
    before_count = database.count_products()
    print(f"BEFORE integrity={before_integrity} products={before_count}")
    if before_integrity not in {"ok", "missing"}:
        print("IMPORT_ABORTED: DB integrity is not ok before import")
        return 1

    backup = None
    try:
        if db_path.exists() and before_integrity == "ok":
            backup = database.backup_db("before_excel_import")
            print(f"BACKUP_OK {backup}")
        headers, rows, max_row = read_excel_rows(excel)
        print(f"EXCEL_HEADER_ROW={HEADER_ROW} DATA_START_ROW={DATA_START_ROW} excel_max_row={max_row} rows_to_import={len(rows)} columns={len(headers)}")
        stats = import_rows(rows)
        search_count = rebuild_search_index()
        guided_count = rebuild_guided_index()
        after_integrity = database.integrity_check()
        after_count = database.count_products()
        if str(after_integrity).lower() != "ok":
            raise RuntimeError(f"POST_IMPORT_INTEGRITY_FAILED: {after_integrity}")
        if after_count <= 0:
            raise RuntimeError("POST_IMPORT_PRODUCTS_ZERO")
        print(
            "IMPORT_MASTER_EXCEL_OK "
            f"inserted={stats['inserted']} updated={stats['updated']} skipped={stats['skipped']} "
            f"products_before={before_count} products_after={after_count} "
            f"search_index={search_count} guided_index={guided_count} integrity={after_integrity} "
            f"db_path={db_path}"
        )
        return 0
    except Exception as exc:
        print("IMPORT_MASTER_EXCEL_FAILED")
        print(f"ERROR={type(exc).__name__}: {exc}")
        traceback.print_exc()
        if backup:
            try:
                database.restore_db_from_backup(backup)
                print(f"DB_RESTORE_OK from={backup}")
            except Exception as restore_exc:
                print(f"DB_RESTORE_FAILED {type(restore_exc).__name__}: {restore_exc}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
