const CACHE_NAME='pricebot-catalog-security-ux-v1';
const STATIC_ASSETS=['/catalog-assets/app.css','/catalog-assets/app.js','/badr-logo.png','/favicon.ico','/manifest.webmanifest'];
const SAFE_PAGES=['/catalog','/categories'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(STATIC_ASSETS)).catch(()=>{}));
  self.skipWaiting();
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));
  self.clients.claim();
});
function isStaticPath(path){
  return path.startsWith('/catalog-assets/') || path==='/badr-logo.png' || path==='/favicon.ico' || path==='/manifest.webmanifest' || path.startsWith('/static/images/placeholders/');
}
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET'){return;}
  const url=new URL(req.url);
  if(url.origin!==location.origin){return;}
  if(url.pathname.startsWith('/merchant') || url.pathname.startsWith('/catalog-event') || url.pathname.startsWith('/order/') || url.pathname==='/catalog-health'){return;}
  if(isStaticPath(url.pathname)){
    event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{
      if(res && res.ok){const copy=res.clone(); caches.open(CACHE_NAME).then(cache=>cache.put(req,copy)).catch(()=>{});}
      return res;
    })).catch(()=>caches.match('/badr-logo.png')));
    return;
  }
  // لا نخزن صفحات المنتج أو نتائج البحث حتى لا تظهر أسعار/توفر قديم في الصيدلية.
  if(req.mode==='navigate' && SAFE_PAGES.includes(url.pathname) && !url.search){
    event.respondWith(fetch(req).then(res=>{
      if(res && res.ok && (res.headers.get('content-type')||'').includes('text/html')){
        const copy=res.clone(); caches.open(CACHE_NAME).then(cache=>cache.put(req,copy)).catch(()=>{});
      }
      return res;
    }).catch(()=>caches.match(req).then(cached=>cached||Response.redirect('/catalog'))));
  }
});
