#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%F_%H-%M-%S)"
BACKUP_DIR="$APP_DIR/backups/security-ux-final-v1-lite-$STAMP"
cd "$APP_DIR"

echo "===== Backup current catalog files ====="
mkdir -p "$BACKUP_DIR/static"
cp -a catalog_web.py "$BACKUP_DIR/catalog_web.py" 2>/dev/null || true
cp -a app.py "$BACKUP_DIR/app.py" 2>/dev/null || true
cp -a static/catalog_app.css "$BACKUP_DIR/static/catalog_app.css" 2>/dev/null || true
cp -a static/catalog_app.js "$BACKUP_DIR/static/catalog_app.js" 2>/dev/null || true
cp -a static/sw.js "$BACKUP_DIR/static/sw.js" 2>/dev/null || true

echo "===== Check Python syntax ====="
python3 -m py_compile "$SRC_DIR/catalog_web.py"

echo "===== Safety check: GET rebuild must not execute FTS ====="
SRC_DIR="$SRC_DIR" python3 - <<'INNERPY'
from pathlib import Path
import os, re, sys
s = Path(os.environ['SRC_DIR']).joinpath('catalog_web.py').read_text(encoding='utf-8', errors='ignore')
m = re.search(r'@router\.get\("/merchant/rebuild-search"[\s\S]*?(?=\n@router\.|\ndef\s|\Z)', s)
if m and 'rebuild_products_fts(' in m.group(0):
    print('ERROR: GET /merchant/rebuild-search still runs rebuild_products_fts')
    sys.exit(1)
print('GET rebuild safety ok')
INNERPY

echo "===== Install SECURITY UX FINAL V1 LITE files ====="
mkdir -p "$APP_DIR/static"
cp -a "$SRC_DIR/catalog_web.py" "$APP_DIR/catalog_web.py"
cp -a "$SRC_DIR/catalog_app.css" "$APP_DIR/static/catalog_app.css"
cp -a "$SRC_DIR/catalog_app.js" "$APP_DIR/static/catalog_app.js"
cp -a "$SRC_DIR/sw.js" "$APP_DIR/static/sw.js"

# Optional assets: keep existing server assets if not included in this LITE package.
for asset in badr_logo.png favicon.ico icon-192.png icon-512.png; do
  if [ -f "$SRC_DIR/$asset" ]; then
    cp -a "$SRC_DIR/$asset" "$APP_DIR/static/$asset"
  elif [ -f "$APP_DIR/$asset" ] && [ ! -f "$APP_DIR/static/$asset" ]; then
    cp -a "$APP_DIR/$asset" "$APP_DIR/static/$asset" || true
  fi
done

echo "===== Prepare analytics DB only, not pricebot.db ====="
python3 - <<'INNERPY'
import os, sqlite3
from pathlib import Path
try:
    import database
    db = os.getenv('PRICEBOT_DB_FILE') or os.getenv('PRICEBOT_DB_PATH') or str(getattr(database, 'DB_FILE', '') or '') or '/opt/pricebot_clean/pricebot.db'
except Exception:
    db = os.getenv('PRICEBOT_DB_FILE') or os.getenv('PRICEBOT_DB_PATH') or '/opt/pricebot_clean/pricebot.db'

db_path = Path(db).expanduser().resolve()
analytics = Path(os.getenv('PRICEBOT_ANALYTICS_DB_FILE') or os.getenv('PRICEBOT_ANALYTICS_DB_PATH') or db_path.with_name('catalog_analytics.db')).expanduser().resolve()
analytics.parent.mkdir(parents=True, exist_ok=True)
with sqlite3.connect(str(analytics), timeout=15) as conn:
    conn.execute('PRAGMA busy_timeout=15000')
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute("CREATE TABLE IF NOT EXISTS catalog_analytics_events (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, path TEXT, label TEXT, meta_json TEXT, referrer TEXT, user_agent TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')))")
    conn.execute('CREATE INDEX IF NOT EXISTS idx_catalog_analytics_type_time ON catalog_analytics_events(event_type, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_catalog_analytics_path_time ON catalog_analytics_events(path, created_at)')
    conn.commit()
print('analytics db ok:', analytics)
print('pricebot.db not modified by installer; FTS rebuild is manual POST-only with CSRF and file lock.')
INNERPY

echo "===== Ensure catalog router is included LAST and TrustedHostMiddleware is configured ====="
python3 - <<'INNERPY'
from pathlib import Path
import re
p = Path('/opt/pricebot_clean/app.py')
s = p.read_text(encoding='utf-8', errors='ignore')
changed = False

if not re.search(r'(?m)^\s*import\s+catalog_web\s*$', s) and 'from catalog_web import' not in s:
    matches = list(re.finditer(r'^(?:from\s+\S+\s+import\s+.+|import\s+.+)$', s, flags=re.M))
    if matches:
        pos = matches[-1].end()
        s = s[:pos] + '\nimport catalog_web' + s[pos:]
    else:
        s = 'import catalog_web\n' + s
    changed = True

# Add TrustedHostMiddleware safely after app is defined. Allows current public host and local health checks.
block = '''\n# PRICEBOT TRUSTED HOSTS PATCH START\ntry:\n    import os as _pricebot_os\n    from starlette.middleware.trustedhost import TrustedHostMiddleware as _PriceBotTrustedHostMiddleware\n    _pricebot_allowed_hosts = [h.strip() for h in _pricebot_os.getenv("PRICEBOT_TRUSTED_HOSTS", "46.101.148.246.sslip.io,127.0.0.1,localhost").split(",") if h.strip()]\n    app.add_middleware(_PriceBotTrustedHostMiddleware, allowed_hosts=_pricebot_allowed_hosts)\nexcept Exception:\n    pass\n# PRICEBOT TRUSTED HOSTS PATCH END\n'''
s2 = re.sub(r'\n# PRICEBOT TRUSTED HOSTS PATCH START[\s\S]*?# PRICEBOT TRUSTED HOSTS PATCH END\n', '\n', s)
if s2 != s:
    s = s2
    changed = True
if 'PRICEBOT TRUSTED HOSTS PATCH START' not in s:
    m = re.search(r'(?m)^\s*app\s*=\s*FastAPI\([^\n]*\)\s*$', s)
    if m:
        s = s[:m.end()] + block + s[m.end():]
        changed = True
    else:
        print('warning: could not find app = FastAPI(...); TrustedHostMiddleware not injected')

s2 = re.sub(r'^[ \t]*app\.include_router\(\s*catalog_web\.router\s*\)\s*(?:#.*)?\n?', '', s, flags=re.M)
s2 = re.sub(r'^[ \t]*app\.include_router\(\s*catalog_router\s*\)\s*(?:#.*)?\n?', '', s2, flags=re.M)
if s2 != s:
    s = s2
    changed = True

line = 'app.include_router(catalog_web.router)  # catalog website router: keep LAST to avoid shadowing merchant/webhook/API routes'
matches = list(re.finditer(r'^[ \t]*app\.include_router\([^\n]+\)\s*(?:#.*)?$', s, flags=re.M))
if matches:
    pos = matches[-1].end()
    s = s[:pos] + '\n' + line + s[pos:]
else:
    s = s.rstrip() + '\n\n# Catalog website router - keep last\n' + line + '\n'
changed = True

if changed:
    p.write_text(s, encoding='utf-8')
print('router ok: catalog_web.router included last')
INNERPY

echo "===== Safety checks: no catch-all in catalog_web.py ====="
if grep -q "full_path:path" "$APP_DIR/catalog_web.py"; then
  echo "ERROR: catch-all route still exists in catalog_web.py"
  exit 1
fi

echo "===== Restart PriceBot only ====="
sudo systemctl restart pricebot.service
sleep 8

echo "===== Local route checks ====="
for path in "/" "/catalog" "/products?q=panadol" "/product/1" "/product/not-a-product" "/contact?product_id=1&availability=inquiry" "/merchant" "/merchant/site-tools" "/merchant/rebuild-search" "/merchant/site-check" "/merchant/performance" "/merchant/site-analytics" "/sw.js" "/manifest.webmanifest" "/sitemap.xml" "/order/1" "/catalog-health"; do
  echo "--- $path"
  curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:8090$path" || true
done

echo "DONE. Open: /catalog?v=security-ux-final-v1-lite"
echo "Manual FTS confirmation page: /merchant/rebuild-search"
echo "Backup saved to: $BACKUP_DIR"
