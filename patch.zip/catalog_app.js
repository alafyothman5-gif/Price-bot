(function(){
  function qs(s,root){return (root||document).querySelector(s)}
  function qsa(s,root){return Array.prototype.slice.call((root||document).querySelectorAll(s))}
  function showLoading(){
    var el=qs('[data-loading]');
    if(el){
      el.classList.add('show');
      el.dataset.started=Date.now();
      if(el._timer){clearTimeout(el._timer)}
      el._timer=setTimeout(function(){el.classList.remove('show')},3500);
    }
  }
  function hideLoading(){var el=qs('[data-loading]'); if(el){if(el._timer){clearTimeout(el._timer)} el.classList.remove('show')}}
  function getStore(k){try{return localStorage.getItem(k)||''}catch(e){return ''}}
  function setStore(k,v){try{if(v){localStorage.setItem(k,v)}else{localStorage.removeItem(k)}}catch(e){}}
  function eventToken(){var m=qs('meta[name="catalog-event-token"]'); return m ? (m.getAttribute('content')||'') : ''}
  function sendEvent(type,data){
    try{
      var payload=JSON.stringify({event:type,token:eventToken(),data:data||{},path:location.pathname+location.search,title:document.title});
      if(payload.length>3900){return}
      if(navigator.sendBeacon){
        var ok=navigator.sendBeacon('/catalog-event', new Blob([payload],{type:'application/json'}));
        if(ok){return}
      }
      fetch('/catalog-event',{method:'POST',headers:{'Content-Type':'application/json'},body:payload,keepalive:true,credentials:'same-origin'}).catch(function(){});
    }catch(e){}
  }
  function systemPrefersDark(){try{return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches}catch(e){return false}}
  function applyTheme(theme){document.documentElement.classList.remove('theme-dark','theme-light'); if(theme){document.documentElement.classList.add('theme-'+theme)}}
  function updateThemeButton(btn,theme){
    if(!btn){return}
    var label='يتبع إعدادات جهازك';
    if(theme==='dark'){label='الوضع الليلي مفعّل'}
    if(theme==='light'){label='الوضع النهاري مفعّل'}
    btn.setAttribute('aria-label',label);
    btn.setAttribute('title',label);
    btn.setAttribute('aria-pressed',theme==='dark'?'true':'false');
    btn.dataset.themeState=theme||'auto';
    var moon=qs('[data-theme-moon]',btn), sun=qs('[data-theme-sun]',btn), txt=qs('[data-theme-label]',btn);
    if(txt){txt.textContent=label}
    if(moon && sun){
      var showSun = theme==='dark' || (!theme && systemPrefersDark());
      sun.hidden=!showSun;
      moon.hidden=showSun;
    }
  }
  var theme=getStore('pricebot-theme'); applyTheme(theme);
  window.addEventListener('load',hideLoading);
  window.addEventListener('pageshow',hideLoading);
  window.addEventListener('pagehide',hideLoading);
  document.addEventListener('visibilitychange',function(){if(!document.hidden){hideLoading()}});
  window.addEventListener('DOMContentLoaded',function(){
    hideLoading();
    sendEvent('page_view',{path:location.pathname+location.search,title:document.title});
    var resultBox=document.querySelector('[data-results-count]'); if(resultBox && resultBox.getAttribute('data-results-count')==='0'){sendEvent('zero_results',{q:(new URLSearchParams(location.search)).get('q')||'',path:location.pathname+location.search});}

    qsa('img').forEach(function(img){img.addEventListener('error',function(){var box=img.closest('.product-image,.image'); if(box){box.classList.add('img-failed')} img.remove();},{once:true});});
    qsa('form.search').forEach(function(f){f.addEventListener('submit',function(){sendEvent('search_submit',{q:(qs('input[name=q]',f)||{}).value||'',category:(qs('select[name=category]',f)||{}).value||'',brand:(qs('select[name=brand]',f)||{}).value||'',availability:(qs('select[name=availability]',f)||{}).value||'',price_range:(qs('select[name=price_range]',f)||{}).value||'',sort:(qs('select[name=sort]',f)||{}).value||''});showLoading();});});
    qsa('a').forEach(function(a){a.addEventListener('click',function(ev){var href=a.getAttribute('href')||''; if(href.indexOf('/order/')===0||href.indexOf('wa.me')>-1){sendEvent('order_or_whatsapp_click',{href:href,label:(a.textContent||'').trim()});} if(ev.metaKey||ev.ctrlKey||ev.shiftKey||ev.altKey){return} if(href && href.charAt(0)==='/' && !a.hasAttribute('target') && !a.hasAttribute('download') && href.indexOf('#')!==0 && href.indexOf('/catalog-assets/')!==0){showLoading();}});});
    qsa('select[data-autosubmit]').forEach(function(s){s.addEventListener('change',function(){sendEvent('filter_change',{name:s.name,value:s.value,path:location.pathname+location.search});showLoading(); s.form && s.form.submit();});});
    var btn=qs('[data-theme-toggle]'); if(btn){updateThemeButton(btn,theme); btn.addEventListener('click',function(){var cur=getStore('pricebot-theme'); var next=cur==='dark'?'light':(cur==='light'?'':'dark'); setStore('pricebot-theme',next); applyTheme(next); updateThemeButton(btn,next);});}
    qsa('[data-copy-url]').forEach(function(copyBtn){copyBtn.addEventListener('click',function(){var old=copyBtn.textContent; function done(txt){copyBtn.textContent=txt; setTimeout(function(){copyBtn.textContent=old},1800)} try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(location.href).then(function(){done('تم نسخ الرابط');sendEvent('copy_link',{});}).catch(function(){done('تعذر النسخ')});}else{done('انسخ الرابط من المتصفح')}}catch(e){done('تعذر النسخ')}});});
    qsa('[data-share]').forEach(function(shareBtn){shareBtn.addEventListener('click',function(){var old=shareBtn.textContent; sendEvent('share',{}); if(navigator.share){navigator.share({title:document.title,url:location.href}).catch(function(){});}else{try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(location.href).then(function(){shareBtn.textContent='تم نسخ الرابط';setTimeout(function(){shareBtn.textContent=old},1800)});}}catch(e){shareBtn.textContent='المشاركة غير متاحة';setTimeout(function(){shareBtn.textContent=old},1800)}}});});
    if('serviceWorker' in navigator && location.protocol==='https:'){
      navigator.serviceWorker.register('/sw.js').catch(function(){});
    }
  });
})();
