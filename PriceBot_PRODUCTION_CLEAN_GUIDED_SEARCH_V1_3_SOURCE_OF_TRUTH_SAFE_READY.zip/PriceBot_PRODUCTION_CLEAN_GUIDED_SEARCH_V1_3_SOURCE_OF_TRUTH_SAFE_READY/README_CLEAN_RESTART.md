# PriceBot Production Clean Guided Search V1.3

This release is a clean, source-of-truth catalog import build for PriceBot / WhatsApp Pharmacy Bot.

## Critical safety rules

- The ZIP contains no `pricebot.db`, no `.env`, no tokens, and no backups.
- `deploy_code_only.sh` does not import Excel, does not rebuild indexes, and does not write to the database.
- `tools/import_master_excel.py` refuses to run without explicit `--db-path`.
- `tools/verify_production.py` supports `--db-path` and is read-only.
- The importer treats `products_master_v22_ready.xlsx` as the source of truth.
- Stale products from an older DB are archived outside the active `products` table and are not visible to customers.

## Important note about Excel copying

`products_master_v22_ready.xlsx` is included in this ZIP and may be copied by `deploy_code_only.sh` as an inert source file only. The deploy script does not import it and does not rebuild indexes. Database import remains a separate manual command.

## Safe server commands

Upload the ZIP to `/tmp`, then run:

```bash
cd /tmp
unzip PriceBot_PRODUCTION_CLEAN_GUIDED_SEARCH_V1_3_SOURCE_OF_TRUTH_SAFE_READY.zip
cd PriceBot_PRODUCTION_CLEAN_GUIDED_SEARCH_V1_3_SOURCE_OF_TRUTH_SAFE_READY

./deploy_code_only.sh
```

Verify production DB before import:

```bash
cd /opt/pricebot
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot/pricebot.db --excel-path /opt/pricebot/products_master_v22_ready.xlsx
```

Dry-run the import plan:

```bash
cd /opt/pricebot
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_v22_ready.xlsx --db-path /opt/pricebot/pricebot.db --dry-run
```

Run the real source-of-truth import only after dry-run looks correct:

```bash
cd /opt/pricebot
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_v22_ready.xlsx --db-path /opt/pricebot/pricebot.db
```

Verify again:

```bash
cd /opt/pricebot
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot/pricebot.db --excel-path /opt/pricebot/products_master_v22_ready.xlsx
```

Restart service only after verification succeeds:

```bash
sudo systemctl restart pricebot
sudo systemctl status pricebot --no-pager -l
```

## Temporary DB acceptance test

Use this before touching production:

```bash
cd /tmp/PriceBot_PRODUCTION_CLEAN_GUIDED_SEARCH_V1_3_SOURCE_OF_TRUTH_SAFE_READY
cp /opt/pricebot/pricebot.db /tmp/pricebot_v1_3_test.sqlite
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
./venv/bin/python tools/import_master_excel.py products_master_v22_ready.xlsx --db-path /tmp/pricebot_v1_3_test.sqlite
./venv/bin/python tools/verify_production.py --db-path /tmp/pricebot_v1_3_test.sqlite --excel-path products_master_v22_ready.xlsx
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_v1_3_test.sqlite
```

Expected:

- integrity_check=ok
- products count≈5791
- search index built
- guided index built
- acceptance tests pass

## Tool DB path support

All listed tools support `--db-path`:

```bash
./venv/bin/python tools/verify_production.py --db-path /tmp/test.sqlite
./venv/bin/python tools/build_search_index.py --db-path /tmp/test.sqlite
./venv/bin/python tools/build_guided_catalog_index.py --db-path /tmp/test.sqlite
./venv/bin/python tools/backup_db.py --db-path /tmp/test.sqlite
./venv/bin/python tools/restore_last_good_db.py /path/to/backup.db --db-path /tmp/test.sqlite
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/test.sqlite
```

## Source-of-truth import behavior

The importer prints:

- old_products_count
- excel_products_count
- matched_by_product_id
- matched_by_barcode
- matched_by_normalized_name
- matched_any_existing
- new_products
- stale_old_products
- duplicate_product_ids
- duplicate_barcodes
- products_after_expected

Then it builds `products_new`, validates it, archives the old `products` table, renames `products_new` to `products`, rebuilds both indexes, and checks integrity.
