#!/usr/bin/env python3
import argparse
import sqlite3
import sys
import traceback
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from normalizer import normalize_text, safe_price
from search_engine import rebuild_search_index
from guided_commerce import rebuild_guided_index

HEADER_ROW = 3
DATA_START_ROW = 4
REQUIRED_COLUMNS = [
    "product_id", "name", "normalized_name", "brand", "company", "category", "section", "product_family", "form",
    "product_type", "active_ingredient", "strength", "size", "pack", "barcode", "aliases", "ocr_keywords",
    "use_case", "skin_type", "body_area", "age_group", "gender", "medicine_form", "medicine_route", "available",
    "price", "currency", "search_mode", "quality_status", "is_substitutable", "substitution_group_id",
    "review_status", "review_notes", "source_serial", "original_name",
]

INDEX_NAMES = [
    "idx_products_name", "idx_products_norm", "idx_products_product_id", "idx_products_barcode",
]


def _cell_value(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        try:
            f = float(text)
            if f.is_integer():
                return str(int(f))
        except Exception:
            pass
    return text


def read_excel_rows(path: Path) -> Tuple[List[str], List[Dict[str, str]], int]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    max_row = ws.max_row
    max_col = ws.max_column
    header_values = next(ws.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW, max_col=max_col, values_only=True))
    headers = [_cell_value(v) for v in header_values]
    if not any(headers):
        wb.close()
        raise RuntimeError(f"HEADER_ROW_{HEADER_ROW}_EMPTY")
    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        wb.close()
        raise RuntimeError(f"MISSING_REQUIRED_COLUMNS: {missing}")
    rows: List[Dict[str, str]] = []
    for row_values in ws.iter_rows(min_row=DATA_START_ROW, max_row=max_row, max_col=max_col, values_only=True):
        item: Dict[str, str] = {}
        empty = True
        for header, value in zip(headers, row_values):
            if not header:
                continue
            val = _cell_value(value)
            if val:
                empty = False
            item[header] = val
        if empty:
            continue
        name = item.get("name") or item.get("original_name") or ""
        if not name:
            continue
        if not item.get("product_id"):
            item["product_id"] = f"AUTO-{len(rows)+1}"
        if not item.get("normalized_name"):
            item["normalized_name"] = normalize_text(name)
        if not item.get("currency"):
            item["currency"] = "LYD"
        item["price"] = safe_price(item.get("price"))
        rows.append({k: item.get(k, "") for k in REQUIRED_COLUMNS})
    wb.close()
    return headers, rows, max_row


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Source-of-truth import for products_master_v22_ready.xlsx into an explicit SQLite DB."
    )
    parser.add_argument("excel_path", help="Path to products_master_v22_ready.xlsx")
    parser.add_argument(
        "--db-path",
        required=True,
        help="Required explicit SQLite DB path. Production example: /opt/pricebot/pricebot.db",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Read Excel and DB, print import plan, but do not write anything.",
    )
    return parser.parse_args()


def _abort_if_project_db(db_path: Path) -> None:
    project_root = Path(__file__).resolve().parents[1]
    if db_path.resolve() == (project_root / "pricebot.db").resolve():
        raise RuntimeError(
            "REFUSING_PROJECT_LOCAL_DB: import_master_excel.py must not create or write "
            "pricebot.db inside the project ZIP/folder. Pass an external --db-path."
        )


def _ensure_explicit_db_path(raw: str) -> None:
    if not str(raw or "").strip():
        raise RuntimeError(
            "EXPLICIT_DB_PATH_REQUIRED: this importer refuses to write using env/fallback DB paths. "
            "Use: ./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_v22_ready.xlsx --db-path /opt/pricebot/pricebot.db"
        )


def _db_counts_for_plan(rows: List[Dict[str, str]]) -> Dict[str, int]:
    excel_product_ids = {str(r.get("product_id") or "").strip() for r in rows if str(r.get("product_id") or "").strip()}
    excel_barcodes = {str(r.get("barcode") or "").strip() for r in rows if str(r.get("barcode") or "").strip()}
    excel_norms = {normalize_text(r.get("normalized_name") or r.get("name")) for r in rows if normalize_text(r.get("normalized_name") or r.get("name"))}
    duplicate_product_ids = sum(v - 1 for v in Counter([r.get("product_id", "") for r in rows if r.get("product_id", "")]).values() if v > 1)
    duplicate_barcodes = sum(v - 1 for v in Counter([r.get("barcode", "") for r in rows if r.get("barcode", "")]).values() if v > 1)

    old_count = 0
    matched_by_product_id = 0
    matched_by_barcode = 0
    matched_by_normalized_name = 0
    stale_old_products = 0
    with database.connect() as conn:
        if database.table_exists(conn, "products"):
            old_rows = conn.execute("SELECT product_id, barcode, normalized_name, name FROM products").fetchall()
            old_count = len(old_rows)
            for row in old_rows:
                pid = str(row[0] or "").strip()
                barcode = str(row[1] or "").strip()
                norm = normalize_text(row[2] or row[3] or "")
                matched = False
                if pid and pid in excel_product_ids:
                    matched_by_product_id += 1
                    matched = True
                if barcode and barcode in excel_barcodes:
                    matched_by_barcode += 1
                    matched = True
                if norm and norm in excel_norms:
                    matched_by_normalized_name += 1
                    matched = True
                if not matched:
                    stale_old_products += 1
    matched_any = min(old_count, old_count - stale_old_products)
    new_products = max(0, len(rows) - matched_by_product_id)
    return {
        "old_products_count": old_count,
        "excel_products_count": len(rows),
        "matched_by_product_id": matched_by_product_id,
        "matched_by_barcode": matched_by_barcode,
        "matched_by_normalized_name": matched_by_normalized_name,
        "matched_any_existing": matched_any,
        "new_products": new_products,
        "stale_old_products": stale_old_products,
        "duplicate_product_ids": duplicate_product_ids,
        "duplicate_barcodes": duplicate_barcodes,
        "products_after_expected": len(rows),
    }


def print_plan(plan: Dict[str, int]) -> None:
    print("DRY_RUN_IMPORT_PLAN")
    for key in [
        "old_products_count", "excel_products_count", "matched_by_product_id", "matched_by_barcode",
        "matched_by_normalized_name", "matched_any_existing", "new_products", "stale_old_products",
        "duplicate_product_ids", "duplicate_barcodes", "products_after_expected",
    ]:
        print(f"{key}={plan.get(key, 0)}")


def _create_products_new(conn: sqlite3.Connection, table_name: str) -> None:
    conn.execute(f'DROP TABLE IF EXISTS "{table_name}"')
    column_defs = ['"id" INTEGER PRIMARY KEY AUTOINCREMENT']
    for col in database.PRODUCT_COLUMNS:
        column_defs.append(f'"{col}" TEXT DEFAULT \'\'')
    column_defs.append('"created_at" TEXT')
    column_defs.append('"updated_at" TEXT')
    conn.execute(f'CREATE TABLE "{table_name}" ({", ".join(column_defs)})')


def _insert_rows_into_table(conn: sqlite3.Connection, table_name: str, rows: List[Dict[str, str]]) -> Dict[str, int]:
    inserted = 0
    skipped = 0
    cols = list(database.PRODUCT_COLUMNS)
    insert_cols = cols + ["created_at", "updated_at"]
    placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
    sql = f'INSERT INTO "{table_name}"({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})'
    for row in rows:
        if not row.get("name"):
            skipped += 1
            continue
        params = [row.get(c, "") for c in cols]
        conn.execute(sql, params)
        inserted += 1
    return {"inserted": inserted, "skipped": skipped}


def source_of_truth_import(rows: List[Dict[str, str]]) -> Dict[str, int | str]:
    database.init_db(run_production_guard=False)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    temp_table = "products_new"
    old_table = f"products_old_backup_{stamp}"
    with database.connect() as conn:
        _create_products_new(conn, temp_table)
        stats = _insert_rows_into_table(conn, temp_table, rows)
        temp_count = int(conn.execute(f'SELECT COUNT(*) FROM "{temp_table}"').fetchone()[0])
        if temp_count != len(rows):
            raise RuntimeError(f"PRODUCTS_NEW_COUNT_MISMATCH expected={len(rows)} actual={temp_count}")
        # Duplicate product_id/barcode are reported in dry-run. Product_id duplicates would make the
        # source-of-truth catalog ambiguous, so fail before replacing products.
        dup_pid = conn.execute(f'''
            SELECT product_id FROM "{temp_table}"
            WHERE product_id IS NOT NULL AND product_id!=''
            GROUP BY product_id HAVING COUNT(*) > 1 LIMIT 1
        ''').fetchone()
        if dup_pid:
            raise RuntimeError(f"DUPLICATE_PRODUCT_ID_IN_EXCEL: {dup_pid[0]}")
        dup_barcode = conn.execute(f'''
            SELECT barcode FROM "{temp_table}"
            WHERE barcode IS NOT NULL AND barcode!=''
            GROUP BY barcode HAVING COUNT(*) > 1 LIMIT 1
        ''').fetchone()
        if dup_barcode:
            raise RuntimeError(f"DUPLICATE_BARCODE_IN_EXCEL: {dup_barcode[0]}")

        for idx in INDEX_NAMES:
            conn.execute(f'DROP INDEX IF EXISTS "{idx}"')
        if database.table_exists(conn, "products"):
            conn.execute(f'ALTER TABLE "products" RENAME TO "{old_table}"')
        conn.execute(f'ALTER TABLE "{temp_table}" RENAME TO "products"')
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_norm ON products(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_product_id ON products(product_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)")
    return {"inserted": stats["inserted"], "skipped": stats["skipped"], "archived_old_table": old_table}


def main() -> int:
    args = parse_args()
    try:
        _ensure_explicit_db_path(args.db_path)
    except Exception as exc:
        print(f"IMPORT_REFUSED {type(exc).__name__}: {exc}")
        return 2

    excel = Path(args.excel_path).expanduser().resolve()
    if not excel.exists():
        print(f"EXCEL_NOT_FOUND {excel}")
        return 2

    database.configure_db_path(args.db_path)
    db_path = database.get_db_path()
    try:
        _abort_if_project_db(db_path)
    except Exception as exc:
        print(f"IMPORT_REFUSED {type(exc).__name__}: {exc}")
        return 2

    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={db_path}")
    print(f"EXCEL_PATH={excel}")
    print(f"DRY_RUN={1 if args.dry_run else 0}")

    backup = None
    try:
        headers, rows, max_row = read_excel_rows(excel)
        print(f"EXCEL_HEADER_ROW={HEADER_ROW} DATA_START_ROW={DATA_START_ROW} excel_max_row={max_row} rows_to_import={len(rows)} columns={len(headers)}")

        # Create/upgrade schema for temp DB tests only after explicit DB path is known.
        database.init_db(run_production_guard=False)
        before_integrity = database.integrity_check()
        before_count = database.count_products()
        print(f"BEFORE integrity={before_integrity} products={before_count}")
        if before_integrity not in {"ok", "missing"}:
            print("IMPORT_ABORTED: DB integrity is not ok before import")
            return 1

        plan = _db_counts_for_plan(rows)
        print_plan(plan)
        if args.dry_run:
            print("DRY_RUN_OK no_write_performed=1")
            return 0

        if db_path.exists() and before_integrity == "ok":
            backup = database.backup_db("before_excel_source_of_truth_import")
            print(f"BACKUP_OK {backup}")

        stats = source_of_truth_import(rows)
        after_count_pre_index = database.count_products()
        if after_count_pre_index != len(rows):
            raise RuntimeError(f"SOURCE_OF_TRUTH_COUNT_FAILED expected={len(rows)} actual={after_count_pre_index}")
        search_count = rebuild_search_index()
        guided_count = rebuild_guided_index()
        after_integrity = database.integrity_check()
        after_count = database.count_products()
        if str(after_integrity).lower() != "ok":
            raise RuntimeError(f"POST_IMPORT_INTEGRITY_FAILED: {after_integrity}")
        if after_count != len(rows):
            raise RuntimeError(f"POST_IMPORT_PRODUCTS_COUNT_MISMATCH expected={len(rows)} actual={after_count}")
        print(
            "IMPORT_MASTER_EXCEL_OK "
            f"mode=SOURCE_OF_TRUTH inserted={stats['inserted']} skipped={stats['skipped']} "
            f"products_before={before_count} products_after={after_count} expected={len(rows)} "
            f"stale_old_products={plan['stale_old_products']} stale_old_products_visible=0 "
            f"archived_old_table={stats['archived_old_table']} "
            f"search_index={search_count} guided_index={guided_count} integrity={after_integrity} "
            f"db_path={db_path}"
        )
        return 0
    except Exception as exc:
        print("IMPORT_MASTER_EXCEL_FAILED")
        print(f"ERROR={type(exc).__name__}: {exc}")
        traceback.print_exc()
        if backup:
            try:
                database.restore_db_from_backup(backup)
                print(f"DB_RESTORE_OK from={backup}")
            except Exception as restore_exc:
                print(f"DB_RESTORE_FAILED {type(restore_exc).__name__}: {restore_exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
