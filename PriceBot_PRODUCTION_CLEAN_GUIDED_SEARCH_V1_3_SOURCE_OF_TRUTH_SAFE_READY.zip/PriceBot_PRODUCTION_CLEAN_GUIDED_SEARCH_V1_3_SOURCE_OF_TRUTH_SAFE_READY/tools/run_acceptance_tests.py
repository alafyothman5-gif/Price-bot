#!/usr/bin/env python3
import argparse
import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database

PASS = 0
FAIL = 0


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run PriceBot smoke acceptance tests against a selected DB.")
    p.add_argument("--db-path", default="", help="SQLite DB path to test. Example: /tmp/test.sqlite")
    return p.parse_args()


def check(name, condition, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"PASS {name} {detail}")
    else:
        FAIL += 1
        print(f"FAIL {name} {detail}")


async def run_tests():
    # Import app/matcher after db path is configured.
    import app
    import matcher

    database.init_db(run_production_guard=False)
    phone = "ACCEPTANCE_TEST_PHONE"
    database.clear_state(phone)
    check("DB integrity", str(database.integrity_check()).lower() == "ok", database.integrity_check())
    check("products not zero", database.count_products() > 0, str(database.count_products()))

    r = await app.process_text(phone, "السلام عليكم")
    check("main menu", "تصفح الأقسام" in r and "بحث باسم منتج" in r)
    r = await app.process_text(phone, "1")
    check("browse sections", "أدوية" in r and "عناية بالبشرة" in r)
    r = await app.process_text(phone, "1")
    check("medicine sub sections", "مسكنات" in r and "معدة" in r)

    database.clear_state(phone)
    r = await app.process_text(phone, "غسول")
    check("generic cleanser no random search", "هل تقصد" in r or "عام" in r, r[:80])
    database.clear_state(phone)
    res = matcher.match_text("Photoblok 50+")
    check("Photoblok exact", res.status == "EXACT_MATCH", res.status)
    res = matcher.match_text("Zofran 4 mg")
    check("Zofran safe medicine search", res.status in {"EXACT_MATCH", "PRODUCT_LIST", "ASK_CLARIFICATION"}, res.status)
    res = matcher.match_text("Cerave")
    check("brand-only no random product", res.status == "ASK_CLARIFICATION", res.status)

    database.clear_state(phone)
    await app.process_text(phone, "السلام عليكم")
    await app.process_text(phone, "2")
    r = await app.process_text(phone, "Photoblok 50+")
    check("search flow details", "✅ المنتج متوفر" in r and "للحجز" in r)
    r = await app.process_text(phone, "نعم")
    check("reservation asks quantity", "كم الكمية" in r)
    r = await app.process_text(phone, "1")
    check("order created", "تم تسجيل طلبك" in r)

    print(f"ACCEPTANCE_RESULT pass={PASS} fail={FAIL}")
    return 0 if FAIL == 0 else 1


def main() -> int:
    args = parse_args()
    if args.db_path:
        database.configure_db_path(args.db_path)
    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={database.get_db_path()}")
    return asyncio.run(run_tests())


if __name__ == "__main__":
    raise SystemExit(main())
