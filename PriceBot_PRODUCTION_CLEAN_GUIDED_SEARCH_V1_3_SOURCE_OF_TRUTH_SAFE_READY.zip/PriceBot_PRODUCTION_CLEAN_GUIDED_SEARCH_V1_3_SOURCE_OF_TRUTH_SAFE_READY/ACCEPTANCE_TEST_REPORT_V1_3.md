# PriceBot V1.3 Acceptance Report

Release: `PriceBot_PRODUCTION_CLEAN_GUIDED_SEARCH_V1_3_SOURCE_OF_TRUTH_SAFE_READY.zip`

## Required safety checks

- NO_DB_IN_ZIP=OK
- NO_ENV_IN_ZIP=OK
- COMPILEALL_OK=OK
- IMPORT_REQUIRES_EXPLICIT_DB_PATH=OK
- ALL_TOOLS_SUPPORT_DB_PATH=OK
- VERIFY_READ_ONLY=OK
- SQLITE_MIGRATIONS_SAFE=OK
- DEPLOY_CODE_ONLY=OK
- DEPLOY_DOES_NOT_IMPORT=OK
- DEPLOY_DOES_NOT_REBUILD_INDEX=OK
- DEPLOY_DOES_NOT_TOUCH_DB=OK

## Import behavior

`tools/import_master_excel.py` now refuses to run without an explicit `--db-path`.

Allowed production command:

```bash
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_v22_ready.xlsx --db-path /opt/pricebot/pricebot.db
```

The importer is source-of-truth:

1. Reads `products_master_v22_ready.xlsx` using header row 3 and data start row 4.
2. Prints dry-run style plan before writing.
3. Builds `products_new` from Excel.
4. Validates row count and duplicates.
5. Backs up selected DB.
6. Archives old `products` as `products_old_backup_<timestamp>`.
7. Renames `products_new` to `products`.
8. Rebuilds `product_search_index` and `guided_catalog_index`.
9. Restores backup if import or post-import validation fails.

## Dry-run fields

The importer prints:

- old_products_count
- excel_products_count
- matched_by_product_id
- matched_by_barcode
- matched_by_normalized_name
- matched_any_existing
- new_products
- stale_old_products
- duplicate_product_ids
- duplicate_barcodes
- products_after_expected

## Local tests performed

### Test 1: missing explicit DB path

Command:

```bash
python3 tools/import_master_excel.py products_master_v22_ready.xlsx
```

Result:

- IMPORT_REQUIRES_EXPLICIT_DB_PATH=OK
- Exit code: 2
- No fallback write performed

### Test 2: empty temporary DB

Command:

```bash
python3 tools/import_master_excel.py products_master_v22_ready.xlsx --db-path /tmp/pricebot_v1_3_empty.sqlite
```

Result:

- IMPORT_ON_EMPTY_DB=OK
- products_before=0
- products_after=5791
- integrity=ok
- search_index=11990
- guided_index=5791

### Test 3: old DB with stale products

Setup: temporary DB with 10 products not present in Excel.

Command:

```bash
python3 tools/import_master_excel.py products_master_v22_ready.xlsx --db-path /tmp/pricebot_v1_3_old10.sqlite
```

Result:

- IMPORT_ON_OLD_DB_PRODUCTS_AFTER≈5791=OK
- old_products_count=10
- excel_products_count=5791
- stale_old_products=10
- products_after=5791
- stale old product rows remaining in active products table=0
- STALE_OLD_PRODUCTS_NOT_VISIBLE=OK
- PRAGMA integrity_check=ok
- SEARCH_INDEX_BUILT=OK
- GUIDED_INDEX_BUILT=OK

### Test 4: verify production supports DB path and is read-only

Command:

```bash
python3 tools/verify_production.py --db-path /tmp/pricebot_v1_3_old10.sqlite --excel-path products_master_v22_ready.xlsx
```

Result:

- VERIFY_READ_ONLY=OK
- DB_PATH_SOURCE=--db-path
- integrity_check=ok
- products count=5791
- search index count=11990
- guided index count=5791
- VERIFY_PRODUCTION_OK

### Test 5: all tools support --db-path

Confirmed for:

- tools/verify_production.py
- tools/build_search_index.py
- tools/build_guided_catalog_index.py
- tools/backup_db.py
- tools/restore_last_good_db.py
- tools/run_acceptance_tests.py

Result:

- ALL_TOOLS_SUPPORT_DB_PATH=OK

### Test 6: acceptance smoke tests

Command:

```bash
python3 tools/run_acceptance_tests.py --db-path /tmp/pricebot_v1_3_old10.sqlite
```

Result:

- ACCEPTANCE_TESTS_PASS=OK
- pass=12
- fail=0

## Final required flags

- NO_DB_IN_ZIP=OK
- IMPORT_REQUIRES_EXPLICIT_DB_PATH=OK
- ALL_TOOLS_SUPPORT_DB_PATH=OK
- VERIFY_READ_ONLY=OK
- IMPORT_ON_OLD_DB_PRODUCTS_AFTER≈5791=OK
- STALE_OLD_PRODUCTS_NOT_VISIBLE=OK
- SEARCH_INDEX_BUILT=OK
- GUIDED_INDEX_BUILT=OK
- ACCEPTANCE_TESTS_PASS=OK
