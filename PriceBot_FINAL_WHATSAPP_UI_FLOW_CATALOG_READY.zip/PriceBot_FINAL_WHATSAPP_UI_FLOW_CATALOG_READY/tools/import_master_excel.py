#!/usr/bin/env python3
"""Safe explicit Excel importer for PriceBot product catalog.

Rules enforced here:
- Never runs without --db-path.
- Supports the organized catalog columns requested for production.
- Does not DROP, DELETE, empty, replace, or rename the products table.
- Uses idempotent upsert by product_id, then barcode, then normalized_name.
- Hides stale old products not present in the Excel so they do not appear to customers.
- Provides --dry-run reporting before any production write.
"""
import argparse
import sqlite3
import sys
import traceback
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from normalizer import normalize_text, safe_price, truthy
from search_engine import rebuild_search_index
from guided_commerce import rebuild_guided_index

HEADER_ROW = 3
DATA_START_ROW = 4

# Minimum organized catalog contract requested by the owner.
REQUIRED_COLUMNS = [
    "product_id",
    "name",
    "brand",
    "product_family",
    "category",
    "subcategory",
    "active_ingredient",
    "form",
    "strength",
    "size",
    "pack",
    "barcode",
    "aliases",
    "ocr_keywords",
    "use_case",
    "skin_type",
    "available",
    "price",
    "substitution_group_id",
    "review_status",
    "review_notes",
]

# Older V22 files use section/product_type instead of subcategory.  Keep this
# backward-compatible for transition, but prefer explicit subcategory whenever it exists.
OPTIONAL_COMPAT_COLUMNS = [
    "normalized_name", "company", "section", "product_type", "body_area", "age_group", "gender",
    "medicine_form", "medicine_route", "currency", "search_mode", "quality_status", "is_substitutable",
    "source_serial", "original_name",
]

IDENTITY_COLUMNS = ["product_id", "barcode", "normalized_name"]


def _cell_value(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        try:
            f = float(text)
            if f.is_integer():
                return str(int(f))
        except Exception:
            pass
    return text


def _headers_from_sheet(ws) -> List[str]:
    max_col = ws.max_column
    header_values = next(ws.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW, max_col=max_col, values_only=True))
    return [_cell_value(v) for v in header_values]


def _missing_required(headers: List[str]) -> List[str]:
    present = set(headers)
    missing = [c for c in REQUIRED_COLUMNS if c not in present]
    # Compatibility for the previously generated v22 catalog: subcategory can be derived from section/product_type.
    if "subcategory" in missing and ("section" in present or "product_type" in present):
        missing.remove("subcategory")
    return missing


def _canonical_available(value: str) -> str:
    return "true" if truthy(value) else "false"


def _normalize_row(item: Dict[str, str], row_number: int) -> Dict[str, str]:
    name = item.get("name") or item.get("original_name") or ""
    normalized_name = item.get("normalized_name") or normalize_text(name)
    subcategory = item.get("subcategory") or item.get("section") or item.get("product_type") or ""
    product_id = item.get("product_id") or f"AUTO-{row_number}"
    row: Dict[str, str] = {c: item.get(c, "") for c in database.PRODUCT_COLUMNS}
    row.update({
        "product_id": product_id,
        "name": name,
        "normalized_name": normalized_name,
        "subcategory": subcategory,
        "currency": item.get("currency") or "LYD",
        "price": safe_price(item.get("price")),
        "available": _canonical_available(item.get("available")),
        "original_name": item.get("original_name") or name,
    })
    # Keep old section aligned for any legacy UI, but category/subcategory are the source of truth.
    if not row.get("section"):
        row["section"] = subcategory
    if not row.get("product_type"):
        row["product_type"] = item.get("form") or subcategory
    return row


def read_excel_rows(path: Path) -> Tuple[List[str], List[Dict[str, str]], Dict[str, object]]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    max_row = ws.max_row
    max_col = ws.max_column
    headers = _headers_from_sheet(ws)
    if not any(headers):
        wb.close()
        raise RuntimeError(f"HEADER_ROW_{HEADER_ROW}_EMPTY")
    missing = _missing_required(headers)
    if missing:
        wb.close()
        raise RuntimeError(f"MISSING_REQUIRED_COLUMNS: {missing}")

    rows: List[Dict[str, str]] = []
    rejected: List[Dict[str, str]] = []
    missing_data: List[Dict[str, str]] = []
    seen_product_ids = set()
    seen_barcodes = set()
    duplicate_product_ids = []
    duplicate_barcodes = []

    for excel_row_num, row_values in enumerate(ws.iter_rows(min_row=DATA_START_ROW, max_row=max_row, max_col=max_col, values_only=True), start=DATA_START_ROW):
        raw: Dict[str, str] = {}
        empty = True
        for header, value in zip(headers, row_values):
            if not header:
                continue
            val = _cell_value(value)
            if val:
                empty = False
            raw[header] = val
        if empty:
            continue

        name = raw.get("name") or raw.get("original_name") or ""
        if not name:
            rejected.append({"row": str(excel_row_num), "reason": "missing_name"})
            continue

        row = _normalize_row(raw, excel_row_num)
        pid = row.get("product_id", "").strip()
        barcode = row.get("barcode", "").strip()
        if pid and pid in seen_product_ids:
            duplicate_product_ids.append(pid)
            rejected.append({"row": str(excel_row_num), "reason": f"duplicate_product_id:{pid}"})
            continue
        if barcode and barcode in seen_barcodes:
            duplicate_barcodes.append(barcode)
            rejected.append({"row": str(excel_row_num), "reason": f"duplicate_barcode:{barcode}"})
            continue
        if pid:
            seen_product_ids.add(pid)
        if barcode:
            seen_barcodes.add(barcode)

        missing_fields = [c for c in ["category", "subcategory", "available", "price"] if not str(row.get(c) or "").strip()]
        if missing_fields:
            missing_data.append({"row": str(excel_row_num), "product_id": pid, "name": name, "missing": ",".join(missing_fields)})
        rows.append(row)
    wb.close()
    report = {
        "excel_max_row": max_row,
        "excel_max_col": max_col,
        "rejected": rejected,
        "missing_data": missing_data,
        "duplicate_product_ids": duplicate_product_ids,
        "duplicate_barcodes": duplicate_barcodes,
    }
    return headers, rows, report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Safe upsert import for organized PriceBot product Excel.")
    parser.add_argument("excel_path", help="Path to products_master_ready.xlsx or products_master_v22_ready.xlsx")
    parser.add_argument("--db-path", required=True, help="Required explicit SQLite DB path. Example: /opt/pricebot/pricebot.db")
    parser.add_argument("--dry-run", action="store_true", help="Print the import plan and do not write to the DB.")
    return parser.parse_args()


def _abort_if_project_db(db_path: Path) -> None:
    project_root = Path(__file__).resolve().parents[1]
    if db_path.resolve() == (project_root / "pricebot.db").resolve():
        raise RuntimeError("REFUSING_PROJECT_LOCAL_DB: pass an external --db-path, never project/pricebot.db")


def _existing_product_maps(conn: sqlite3.Connection):
    maps = {"product_id": {}, "barcode": {}, "normalized_name": {}}
    if not database.table_exists(conn, "products"):
        return maps, []
    rows = conn.execute("SELECT id, product_id, barcode, normalized_name, name FROM products").fetchall()
    for r in rows:
        db_id = int(r[0])
        pid = str(r[1] or "").strip()
        barcode = str(r[2] or "").strip()
        norm = normalize_text(r[3] or r[4] or "")
        if pid and pid not in maps["product_id"]:
            maps["product_id"][pid] = db_id
        if barcode and barcode not in maps["barcode"]:
            maps["barcode"][barcode] = db_id
        if norm and norm not in maps["normalized_name"]:
            maps["normalized_name"][norm] = db_id
    return maps, rows


def _match_existing(row: Dict[str, str], maps) -> Tuple[int, str]:
    pid = str(row.get("product_id") or "").strip()
    barcode = str(row.get("barcode") or "").strip()
    norm = normalize_text(row.get("normalized_name") or row.get("name"))
    # Product_id is authoritative. If the Excel row has a product_id and it is
    # not in the DB, create a new product instead of merging unrelated rows that
    # happen to share a normalized display name. Barcode may still match an old
    # product whose product_id was previously missing or changed.
    if pid:
        if pid in maps["product_id"]:
            return maps["product_id"][pid], "product_id"
        if barcode and barcode in maps["barcode"]:
            return maps["barcode"][barcode], "barcode"
        return 0, "new"
    if barcode:
        if barcode in maps["barcode"]:
            return maps["barcode"][barcode], "barcode"
        return 0, "new"
    if norm and norm in maps["normalized_name"]:
        return maps["normalized_name"][norm], "normalized_name"
    return 0, "new"


def build_plan(rows: List[Dict[str, str]], rejected_count: int) -> Dict[str, int]:
    with database.connect() as conn:
        maps, old_rows = _existing_product_maps(conn)
        old_count = len(old_rows)
        matched_by = Counter()
        matched_ids = set()
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            if db_id:
                matched_by[kind] += 1
                matched_ids.add(db_id)
            else:
                matched_by["new"] += 1
        stale_old = max(0, old_count - len(matched_ids))
    return {
        "old_products_count": old_count,
        "excel_products_count": len(rows),
        "matched_by_product_id": matched_by["product_id"],
        "matched_by_barcode": matched_by["barcode"],
        "matched_by_normalized_name": matched_by["normalized_name"],
        "new_products": matched_by["new"],
        "stale_old_products": stale_old,
        "rejected_products": rejected_count,
        "products_after_expected_minimum": old_count + matched_by["new"],
        "visible_excel_products_expected": len(rows),
    }


def print_plan(plan: Dict[str, int], meta: Dict[str, object]) -> None:
    print("IMPORT_DRY_RUN_OR_PLAN")
    for key in [
        "old_products_count", "excel_products_count", "matched_by_product_id", "matched_by_barcode",
        "matched_by_normalized_name", "new_products", "stale_old_products", "rejected_products",
        "products_after_expected_minimum", "visible_excel_products_expected",
    ]:
        print(f"{key}={plan.get(key, 0)}")
    print(f"missing_data_products={len(meta.get('missing_data') or [])}")
    print(f"duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])}")
    print(f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])}")


def _update_product(conn: sqlite3.Connection, db_id: int, row: Dict[str, str]) -> None:
    cols = list(database.PRODUCT_COLUMNS)
    assignments = ", ".join(f'"{c}"=?' for c in cols) + ', "updated_at"=datetime(\'now\')'
    params = [row.get(c, "") for c in cols] + [int(db_id)]
    conn.execute(f'UPDATE products SET {assignments} WHERE id=?', params)


def _insert_product(conn: sqlite3.Connection, row: Dict[str, str]) -> int:
    cols = list(database.PRODUCT_COLUMNS)
    insert_cols = cols + ["created_at", "updated_at"]
    placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
    sql = f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})'
    cur = conn.execute(sql, [row.get(c, "") for c in cols])
    return int(cur.lastrowid)


def safe_upsert_import(rows: List[Dict[str, str]], plan: Dict[str, int]) -> Dict[str, int]:
    database.init_db(run_production_guard=False)
    stats = Counter()
    excel_db_ids = set()
    with database.connect() as conn:
        maps, _old_rows = _existing_product_maps(conn)
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            if db_id:
                _update_product(conn, db_id, row)
                stats["updated"] += 1
            else:
                db_id = _insert_product(conn, row)
                stats["added"] += 1
                # Make following duplicate-free rows in same import able to match if needed.
                pid = str(row.get("product_id") or "").strip()
                barcode = str(row.get("barcode") or "").strip()
                norm = normalize_text(row.get("normalized_name") or row.get("name"))
                if pid:
                    maps["product_id"][pid] = db_id
                if barcode:
                    maps["barcode"][barcode] = db_id
                if norm:
                    maps["normalized_name"][norm] = db_id
            excel_db_ids.add(int(db_id))

        # Hide old products not present in the Excel source; do not delete them.
        if excel_db_ids:
            placeholders = ",".join("?" for _ in excel_db_ids)
            cur = conn.execute(
                f"""
                UPDATE products
                SET available='false', search_mode='hidden', review_status='stale_hidden', updated_at=datetime('now')
                WHERE id NOT IN ({placeholders})
                """,
                tuple(excel_db_ids),
            )
            stats["stale_hidden"] = int(cur.rowcount or 0)
        else:
            raise RuntimeError("REFUSING_TO_HIDE_ALL_PRODUCTS: Excel produced zero accepted rows")
    return dict(stats)


def write_report_file(db_path: Path, excel: Path, plan: Dict[str, int], meta: Dict[str, object], stats: Dict[str, int], search_count: int, guided_count: int, integrity: str, products_after: int) -> Path:
    report_path = db_path.parent / f"import_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    lines = [
        "PRICEBOT_IMPORT_REPORT",
        f"db_path={db_path}",
        f"excel_path={excel}",
        f"products_before={plan.get('old_products_count', 0)}",
        f"products_after={products_after}",
        f"products_added={stats.get('added', 0)}",
        f"products_updated={stats.get('updated', 0)}",
        f"products_rejected={plan.get('rejected_products', 0)}",
        f"stale_old_products_hidden={stats.get('stale_hidden', 0)}",
        f"missing_data_products={len(meta.get('missing_data') or [])}",
        f"duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])}",
        f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])}",
        f"search_index={search_count}",
        f"guided_index={guided_count}",
        f"integrity={integrity}",
    ]
    if meta.get("missing_data"):
        lines.append("MISSING_DATA_SAMPLE=" + repr((meta.get("missing_data") or [])[:20]))
    if meta.get("rejected"):
        lines.append("REJECTED_SAMPLE=" + repr((meta.get("rejected") or [])[:20]))
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report_path


def main() -> int:
    args = parse_args()
    excel = Path(args.excel_path).expanduser().resolve()
    if not excel.exists():
        print(f"EXCEL_NOT_FOUND {excel}")
        return 2
    database.configure_db_path(args.db_path)
    db_path = database.get_db_path()
    try:
        _abort_if_project_db(db_path)
    except Exception as exc:
        print(f"IMPORT_REFUSED {type(exc).__name__}: {exc}")
        return 2

    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={db_path}")
    print(f"EXCEL_PATH={excel}")
    print(f"DRY_RUN={1 if args.dry_run else 0}")

    backup = None
    try:
        headers, rows, meta = read_excel_rows(excel)
        print(f"EXCEL_HEADER_ROW={HEADER_ROW} DATA_START_ROW={DATA_START_ROW} excel_max_row={meta['excel_max_row']} rows_accepted={len(rows)} columns={len([h for h in headers if h])}")
        database.init_db(run_production_guard=False)
        before_integrity = database.integrity_check()
        before_count = database.count_products()
        print(f"BEFORE integrity={before_integrity} products={before_count}")
        if str(before_integrity).lower() not in {"ok", "missing"}:
            print("IMPORT_ABORTED: DB integrity is not ok before import")
            return 1
        plan = build_plan(rows, len(meta.get("rejected") or []))
        print_plan(plan, meta)
        if args.dry_run:
            print("DRY_RUN_OK no_write_performed=1")
            return 0
        if not rows:
            raise RuntimeError("NO_ACCEPTED_PRODUCTS_IN_EXCEL")
        if db_path.exists() and str(before_integrity).lower() == "ok":
            backup = database.backup_db("before_catalog_upsert_import")
            print(f"BACKUP_OK {backup}")
        stats = safe_upsert_import(rows, plan)
        search_count = rebuild_search_index()
        guided_count = rebuild_guided_index()
        after_integrity = database.integrity_check()
        after_count = database.count_products()
        if str(after_integrity).lower() != "ok":
            raise RuntimeError(f"POST_IMPORT_INTEGRITY_FAILED: {after_integrity}")
        report = write_report_file(db_path, excel, plan, meta, stats, search_count, guided_count, after_integrity, after_count)
        print(
            "IMPORT_MASTER_EXCEL_OK "
            f"mode=SAFE_UPSERT_NO_DELETE products_before={before_count} products_after={after_count} "
            f"added={stats.get('added',0)} updated={stats.get('updated',0)} rejected={plan['rejected_products']} "
            f"missing_data={len(meta.get('missing_data') or [])} duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])} "
            f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])} stale_hidden={stats.get('stale_hidden',0)} "
            f"search_index={search_count} guided_index={guided_count} integrity={after_integrity} report={report}"
        )
        return 0
    except Exception as exc:
        print("IMPORT_MASTER_EXCEL_FAILED")
        print(f"ERROR={type(exc).__name__}: {exc}")
        traceback.print_exc()
        if backup:
            try:
                database.restore_db_from_backup(backup)
                print(f"DB_RESTORE_OK from={backup}")
            except Exception as restore_exc:
                print(f"DB_RESTORE_FAILED {type(restore_exc).__name__}: {restore_exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
