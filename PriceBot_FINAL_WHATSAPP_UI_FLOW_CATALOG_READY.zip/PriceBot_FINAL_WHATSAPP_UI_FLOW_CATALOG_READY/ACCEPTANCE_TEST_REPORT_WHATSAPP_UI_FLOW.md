# PriceBot FINAL WhatsApp UI Flow Acceptance Report

Build name: `PriceBot_FINAL_WHATSAPP_UI_FLOW_READY.zip`

## Scope

This release changes the WhatsApp customer experience only:

- Adds state-machine driven conversation flow.
- Adds start screen and main menu.
- Adds search mode, image mode, category browsing, product page, product detail, quantity/order flow.
- Adds general commands: `القائمة`, `رجوع`, `إلغاء`, `مساعدة`.
- Adds WhatsApp interactive payload builders with text fallback.
- Keeps webhook routes `/webhook` and `/webhook/whatsapp`.

It does **not** import Excel automatically, does **not** rebuild indexes during deploy, and does **not** replace or delete `pricebot.db`.

## Safety checks

```text
NO_DB_IN_ZIP=OK
NO_ENV_IN_ZIP=OK
NO_SECRETS_IN_CODE=OK
DEPLOY_CODE_ONLY_NO_IMPORT=OK
DEPLOY_CODE_ONLY_NO_REBUILD=OK
WEBHOOK_ROUTES_KEPT=/webhook,/webhook/whatsapp
COMPILEALL_OK=OK
VERIFY_SUPPORTS_DB_PATH=OK
ALL_TOOLS_SUPPORT_DB_PATH=OK
```

## Local DB test

Test DB path: `/tmp/pricebot_ui_flow_test.sqlite`

```text
PRAGMA integrity_check=ok
products_count=5791
search_index_count=11990
guided_index_count=5791
```

## Index rebuild safety on temp DB only

```text
SEARCH_INDEX_REBUILD_OK entries=11990 products_before=5791 products_after=5791
GUIDED_INDEX_REBUILD_OK rows=5791 products_before=5791 products_after=5791
```

## WhatsApp UI acceptance tests

```text
ACCEPTANCE_RESULT pass=23 fail=0
```

Covered flows:

1. Greeting shows start message.
2. `ابدأ` shows main menu.
3. Main menu `1` enters product search state.
4. Search state receives `فلاجيل` and uses matcher/clarification instead of repeating menu.
5. `القائمة` resets to main menu.
6. Main menu `2` opens categories.
7. Category opens subcategories.
8. Skincare subcategory asks skin type.
9. Product page shows products from selected category only.
10. Numeric choice in product page opens selected product details.
11. `رجوع` returns one step.
12. `التالي` paginates product results.
13. Main menu `3` enters image mode.
14. Unclear image returns clear image message.
15. Interactive send failure falls back to text.
16. Brand-only `Cerave` does not return random exact product.
17. Type-only `غسول` does not return random product.
18. `Rilastil Xerolact PB` does not return random alternative.
19. Product count remains unchanged after UI tests.

## Production commands

Code deploy only:

```bash
cd /tmp
unzip PriceBot_FINAL_WHATSAPP_UI_FLOW_READY.zip
cd PriceBot_FINAL_WHATSAPP_UI_FLOW_READY
./deploy_code_only.sh
```

Verify production DB after deploy:

```bash
cd /opt/pricebot
./venv/bin/python -m compileall .
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot/pricebot.db
sudo systemctl restart pricebot
sudo systemctl status pricebot --no-pager -l
```

Webhook check:

```bash
TOKEN="$(grep -E '^META_VERIFY_TOKEN=' /opt/pricebot/.env | cut -d= -f2-)" && curl -i "https://46.101.148.246.sslip.io/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=${TOKEN}&hub.challenge=PING"
```

Expected:

```text
HTTP 200
PING
```

## Ambiguous search pricing rule

Search ambiguity pages do not show prices. Prices are shown only after an exact product detail is opened, or while browsing a concrete guided category page.
