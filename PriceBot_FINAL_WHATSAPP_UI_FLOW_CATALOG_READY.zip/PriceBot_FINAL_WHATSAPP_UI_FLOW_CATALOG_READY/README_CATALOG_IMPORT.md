# PriceBot Catalog Import + WhatsApp UI Flow

هذه النسخة تضيف دعم كتالوج منتجات منظم فوق واجهة واتساب الجديدة.

## الأعمدة المدعومة في Excel

الأعمدة الأساسية المدعومة:

- product_id
- name
- brand
- product_family
- category
- subcategory
- active_ingredient
- form
- strength
- size
- pack
- barcode
- aliases
- ocr_keywords
- use_case
- skin_type
- available
- price
- substitution_group_id
- review_status
- review_notes

الأعمدة التوافقية القديمة مثل `section`, `product_type`, `normalized_name`, `company`, `quality_status`, `search_mode` تبقى مدعومة، لكنها ليست بديلًا عن `category/subcategory` في الكتالوج الجديد.

## قواعد مهمة

- `deploy_code_only.sh` لا يستورد Excel ولا يعيد بناء الفهارس ولا يفرغ المنتجات.
- `tools/import_master_excel.py` لا يعمل إلا مع `--db-path` الصريح.
- الاستيراد يعمل Upsert آمن: إضافة/تحديث فقط.
- لا يوجد `DROP products` ولا `DELETE FROM products` ولا استبدال لقاعدة البيانات.
- أي منتج قديم غير موجود في Excel يتم إخفاؤه من العميل عبر `available=false`, `search_mode=hidden`, `review_status=stale_hidden` بدون حذفه.
- البحث يستخدم `name + aliases + ocr_keywords`.
- المطابقة تعتمد على `brand/product_family/form/strength/size` عند تحديد هوية المنتج.
- تصفح الأقسام يعتمد على `category/subcategory` بعد بناء `guided_catalog_index`.

## dry-run قبل الكتابة

```bash
cd /opt/pricebot
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_ready.xlsx --db-path /opt/pricebot/pricebot.db --dry-run
```

## الاستيراد الحقيقي

```bash
cd /opt/pricebot
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_ready.xlsx --db-path /opt/pricebot/pricebot.db
```

## التقرير بعد الاستيراد

الأداة تطبع وتكتب تقريرًا يحتوي:

- عدد المنتجات قبل
- عدد المنتجات بعد
- عدد المنتجات المضافة
- عدد المنتجات المحدثة
- عدد المنتجات المرفوضة
- المنتجات الناقصة بيانات
- التكرارات
- المنتجات القديمة التي تم إخفاؤها
- عدد search_index
- عدد guided_index
- integrity_check

## الفحص

```bash
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot/pricebot.db --excel-path /opt/pricebot/products_master_ready.xlsx
./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot/pricebot.db
```
