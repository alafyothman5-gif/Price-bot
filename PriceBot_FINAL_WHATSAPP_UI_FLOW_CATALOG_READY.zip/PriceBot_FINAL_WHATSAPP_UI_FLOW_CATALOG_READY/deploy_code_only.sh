#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot"
RELEASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_ROOT="/root/pricebot_backups/code_${STAMP}"

mkdir -p "$APP_DIR" "$BACKUP_ROOT"

if [ -f "$APP_DIR/pricebot.db" ]; then
  echo "Checking production DB before code deploy..."
  python3 - <<'PY'
import os, sqlite3, sys
path='/opt/pricebot/pricebot.db'
if not os.path.exists(path):
    print('DB_MISSING')
    sys.exit(1)
with open(path,'rb') as f:
    if f.read(16) != b'SQLite format 3\x00':
        print('DB_NOT_SQLITE')
        sys.exit(1)
con=sqlite3.connect(path)
try:
    integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
    count=con.execute('SELECT COUNT(*) FROM products').fetchone()[0]
    print(f'DB_OK integrity={integrity} products={count}')
    if integrity.lower()!='ok' or int(count)<=0:
        sys.exit(1)
finally:
    con.close()
PY
fi

echo "Backing up current code files to $BACKUP_ROOT"
rsync -a \
  --exclude 'pricebot.db' --exclude '*.db' --exclude '*.db-wal' --exclude '*.db-shm' \
  --exclude '.env' --exclude 'backups/' --exclude 'media/uploads/' --exclude 'venv/' --exclude '__pycache__/' \
  "$APP_DIR"/ "$BACKUP_ROOT"/ || true

echo "Deploying code only. DB/.env/backups/uploads are preserved. Excel may be copied only as inert import source; no import/rebuild is run."
rsync -a --delete \
  --exclude '.env' --exclude 'pricebot.db' --exclude '*.db' --exclude '*.db-wal' --exclude '*.db-shm' \
  --exclude 'backups/' --exclude 'media/uploads/' --exclude 'venv/' --exclude '__pycache__/' \
  "$RELEASE_DIR"/ "$APP_DIR"/

cd "$APP_DIR"
python3 -m venv venv
./venv/bin/pip install --upgrade pip >/dev/null
./venv/bin/pip install -r requirements.txt
./venv/bin/python -m py_compile app.py database.py matcher.py search_engine.py guided_commerce.py vision_service.py orders.py admin.py merchant.py ui_flow.py conversation_state.py category_browser.py whatsapp_interactive.py

echo "CODE_DEPLOY_OK"
echo "Next: ./venv/bin/python tools/verify_production.py --db-path /opt/pricebot/pricebot.db --excel-path /opt/pricebot/products_master_ready.xlsx"
