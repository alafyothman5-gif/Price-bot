# PriceBot WhatsApp UI Flow

This build adds a customer-facing state machine for WhatsApp:

```text
START
→ MAIN_MENU
→ WAITING_FOR_PRODUCT_SEARCH
→ WAITING_FOR_PRODUCT_IMAGE
→ BROWSING_CATEGORIES
→ BROWSING_SUBCATEGORY
→ BROWSING_PRODUCT_PAGE
→ WAITING_FOR_CLARIFICATION
→ PRODUCT_DETAIL
→ WAITING_FOR_QUANTITY
```

## Customer commands

These work from any state:

```text
القائمة  → main menu
رجوع     → one step back
إلغاء    → cancel current operation and return to main menu
مساعدة   → usage help
ابدأ     → main menu
```

## Main menu

```text
1. 🔎 البحث عن منتج
2. 🗂️ تصفح الأقسام
3. 📷 البحث بصورة
4. ℹ️ معلومات الصيدلية
```

## Safety

- No `.env` in release.
- No `pricebot.db` in release.
- Deploy is code-only.
- No Excel import during deploy.
- No DB replacement during deploy.
- Product matching remains strict; no random fuzzy fallback was added.

## Safe Excel import remains separate

This release keeps the V1.3 source-of-truth safe importer. It is not run by deploy.

Only run import explicitly when needed:

```bash
cd /opt/pricebot
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_v22_ready.xlsx --db-path /opt/pricebot/pricebot.db
```

For testing only:

```bash
cp /opt/pricebot/pricebot.db /tmp/pricebot_ui_flow_test.sqlite
./venv/bin/python tools/verify_production.py --db-path /tmp/pricebot_ui_flow_test.sqlite
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_ui_flow_test.sqlite
```
