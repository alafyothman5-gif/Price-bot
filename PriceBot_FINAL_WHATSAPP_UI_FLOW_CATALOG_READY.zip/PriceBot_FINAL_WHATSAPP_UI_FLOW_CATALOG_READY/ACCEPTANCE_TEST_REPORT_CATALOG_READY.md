# Acceptance Test Report — Catalog Ready UI Flow

NO_DB_IN_ZIP=OK
NO_ENV_IN_ZIP=OK
COMPILEALL_OK=OK
IMPORT_REQUIRES_EXPLICIT_DB_PATH=OK
DRY_RUN_SUPPORTED=OK
IMPORT_MODE=SAFE_UPSERT_NO_DELETE
PRODUCTS_TABLE_NOT_DROPPED=OK
PRODUCTS_TABLE_NOT_DELETED=OK
CATEGORY_SUBCATEGORY_GUIDED_INDEX=OK
SEARCH_USES_NAME_ALIASES_OCR_KEYWORDS=OK
MATCHING_IDENTITY_FIELDS=brand/product_family/form/strength/size
VERIFY_READ_ONLY=OK
ACCEPTANCE_TESTS_PASS=23/23

## Clean temp DB import

products_before=0
rows_accepted=5791
products_after=5791
added=5791
updated=0
rejected=0
missing_data=0
duplicate_product_ids=0
duplicate_barcodes=0
stale_hidden=0
search_index=23746
guided_index=5785
integrity=ok

## Old DB with 10 stale products

products_before=10
rows_accepted=5791
products_after=5801
added=5791
updated=0
stale_hidden=10
old_stale_visible=0
search_index=23746
guided_index=5785
integrity=ok

## WhatsApp UI flow

PASS greeting/start
PASS main menu
PASS search mode state
PASS category browsing
PASS subcategory browsing
PASS product detail numeric selection
PASS image mode state
PASS interactive fallback
PASS brand-only no random exact
PASS type-only no random exact
PASS no destructive product path
