import base64
import json
import os
import time
from io import BytesIO
from typing import Dict, Tuple

import httpx
from PIL import Image, ImageOps

import config_env
from normalizer import normalize_text
from query_slots import build_vision_query

GENERIC_IMAGE_WORDS = {
    "cream", "gel", "tube", "capsule", "capsules", "tablet", "tablets", "vitamin", "female", "face", "skin",
    "lotion", "syrup", "drops", "spray", "shampoo", "conditioner", "mg", "ml", "iu", "كريم", "جل", "حبوب",
    "فيتامين", "كبسولات", "شراب", "قطره", "بخاخ", "شامبو",
}


def _log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-flash-lite").strip() or "google/gemini-2.5-flash-lite",
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def build_query_from_slots(slots: Dict[str, str]) -> str:
    # Vision matching must use product identity slots, not raw package text.
    # Generic marketing words remain in visible_text but are excluded from query.
    return build_vision_query(slots)


def _is_weak_visual_query(query: str, slots: Dict[str, str]) -> bool:
    n = normalize_text(query)
    if not n:
        return True

    # PRICEBOT_V5_FOREGROUND_WEAK_QUERY_GUARD_V1
    # Do not trust structured brand/product_name alone.  The candidate must be
    # supported by foreground/OCR text copied from the package.  This prevents a
    # background word or hallucinated single-token product (e.g. Hemazym from the
    # shelf/background) from becoming a suggestion.
    evidence = normalize_text(_foreground_identity_text_from_slots(slots))
    if not evidence:
        evidence = n

    tokens = evidence.split()
    strong = [t for t in tokens if t not in GENERIC_IMAGE_WORDS and not t.isdigit() and len(t) >= 3]
    strong_unique = []
    for t in strong:
        if t not in strong_unique:
            strong_unique.append(t)

    # At least two foreground identity tokens are required for image candidates.
    # Examples accepted: VICHY NORMADERM, WHITE PETROLEUM JELLY, Transition Pediatrique.
    # Examples rejected: cream 250g, Hemazym 3, white, 100ml.
    if len(strong_unique) >= 2:
        return False
    return True



# PRICEBOT_V5_FAST_VISION_PREPROCESS_FINAL


# PRICEBOT_VISION_BAD_JSON_FALLBACK_V1


# PRICEBOT_V5_FOREGROUND_BAD_JSON_PARSER_V1
def _extract_jsonish_values(content: object) -> Dict[str, str]:
    """Extract useful foreground/OCR fields from malformed model JSON.

    Some providers return almost-JSON or prose despite response_format.  This
    parser is deliberately conservative: it reads only known fields and ignores
    background_text for identity.  It never creates a direct price match; the
    result is used only for Image Confirmation Mode.
    """
    import re
    text = str(content or "")
    if not text.strip():
        return {}
    keys = [
        "foreground_product_text", "main_visible_product", "raw_vision_text",
        "visible_text", "brand", "product_name", "product_family", "form",
        "strength", "size", "pack", "confidence", "background_text",
    ]
    out: Dict[str, str] = {}
    for key in keys:
        # quoted value: "key": "..."
        m = re.search(r'(?is)["\']?' + re.escape(key) + r'["\']?\s*[:=]\s*["\']([^"\']{0,260})["\']', text)
        if not m:
            # unquoted/simple value until comma/brace/newline
            m = re.search(r'(?is)["\']?' + re.escape(key) + r'["\']?\s*[:=]\s*([^,}\]\n\r]{0,220})', text)
        if m:
            val = (m.group(1) or "").strip().strip('"\' ,')
            # Unquoted malformed JSON sometimes captures the next key/value.
            # Cut at the next known key label to keep only the value for this field.
            for next_key in keys:
                if next_key == key:
                    continue
                for marker in [f" {next_key}:", f" {next_key}=", f" '{next_key}':", f' "{next_key}":']:
                    idx = val.lower().find(marker.lower())
                    if idx > 0:
                        val = val[:idx]
            val = re.sub(r"\s+", " ", val).strip()
            if val and val.lower() not in {"null", "none", "n/a", "unknown", "not visible"}:
                out[key] = val[:220]
    return out


def _foreground_identity_text_from_slots(slots: Dict[str, str]) -> str:
    """Foreground/evidence text only; background_text is excluded by design."""
    parts = []
    for key in [
        "foreground_product_text", "main_visible_product", "visible_text",
        "raw_vision_text", "brand", "product_name", "product_family",
        "form", "strength", "size", "pack",
    ]:
        val = str(slots.get(key) or "").strip()
        if val:
            parts.append(val)
    return " ".join(parts).strip()

def _clean_model_text_for_ocr_fallback(content: object) -> str:
    """Turn a non-JSON Vision response into usable foreground text.

    Vision providers sometimes return prose or fenced text despite the JSON
    instruction.  For Image Confirmation Mode this should not immediately fail
    if the response still contains readable product words.  The fallback never
    displays price directly; it only feeds safe candidates into confirmation.
    """
    text = str(content or "").strip()
    if not text:
        return ""
    # Remove common wrappers/fences while preserving product words.
    for token in ["```json", "```JSON", "```", "{", "}", "[", "]"]:
        text = text.replace(token, " ")
    text = text.replace('"', ' ').replace("'", " ")
    # Drop JSON-like labels and prose fragments that often appear around OCR.
    noisy = [
        "foreground_product_text", "main_visible_product", "product_name", "product_family",
        "visible_text", "background_text", "confidence", "brand", "form", "strength", "size", "pack",
        "the image shows", "image shows", "this appears to be", "appears to be", "json", "product",
    ]
    low = text.lower()
    for n in noisy:
        low = low.replace(n, " ")
    # Keep alphanumerics plus common units and accented latin/ar/space separators.
    import re
    low = re.sub(r"[^0-9a-zA-ZÀ-ÿ\u0600-\u06FF%./+-]+", " ", low)
    low = re.sub(r"\s+", " ", low).strip()
    return low[:260]


def _fallback_slots_from_bad_json(content: object) -> Dict[str, str]:
    # First try to recover structured foreground fields from malformed JSON.
    recovered = _extract_jsonish_values(content)
    foreground = _foreground_identity_text_from_slots(recovered)

    # If key recovery failed, fall back to conservative text cleanup.  This is
    # still treated as foreground only for confirmation, never for direct price.
    if not foreground:
        foreground = _clean_model_text_for_ocr_fallback(content)

    if not foreground:
        return {}

    slots = {
        "foreground_product_text": recovered.get("foreground_product_text") or recovered.get("main_visible_product") or foreground,
        "main_visible_product": recovered.get("main_visible_product") or recovered.get("foreground_product_text") or foreground,
        "product_name": recovered.get("product_name") or "",
        "product_family": recovered.get("product_family") or "",
        "visible_text": recovered.get("visible_text") or recovered.get("raw_vision_text") or foreground,
        "raw_vision_text": recovered.get("raw_vision_text") or recovered.get("visible_text") or foreground,
        "background_text": "",  # background is never used for identity in fallback
        "brand": recovered.get("brand") or "",
        "form": recovered.get("form") or "",
        "strength": recovered.get("strength") or "",
        "size": recovered.get("size") or "",
        "pack": recovered.get("pack") or "",
        "confidence": str(recovered.get("confidence") or "0.76"),
        "status": "OK",
    }
    slots["query"] = build_query_from_slots(slots)

    # At least two foreground identity tokens are needed for safe confirmation.
    if _is_weak_visual_query(slots.get("query", ""), slots):
        return {}
    return slots

def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)) or default)
    except Exception:
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(os.getenv(name, str(default)) or default))
    except Exception:
        return default


def _prepare_image_for_vision(image_bytes: bytes, mime_type: str = "image/jpeg") -> Tuple[bytes, str]:
    """Compress WhatsApp images before Vision to reduce latency.

    This never changes the original catalog or uploaded WhatsApp media. It only
    reduces the bytes sent to the Vision provider.
    """
    if not image_bytes:
        return image_bytes, mime_type or "image/jpeg"
    max_width = max(512, min(1600, _env_int("PRICEBOT_VISION_MAX_IMAGE_WIDTH", 1024)))
    quality = max(55, min(90, _env_int("PRICEBOT_VISION_JPEG_QUALITY", 78)))
    try:
        img = Image.open(BytesIO(image_bytes))
        img = ImageOps.exif_transpose(img)
        if img.mode not in {"RGB", "L"}:
            img = img.convert("RGB")
        elif img.mode == "L":
            img = img.convert("RGB")
        w, h = img.size
        if w > max_width:
            new_h = max(1, int(h * (max_width / float(w))))
            img = img.resize((max_width, new_h), Image.LANCZOS)
        out = BytesIO()
        img.save(out, format="JPEG", quality=quality, optimize=True)
        prepared = out.getvalue()
        if prepared and len(prepared) < len(image_bytes):
            _log(
                "VISION_IMAGE_PREPARED",
                original_bytes=len(image_bytes),
                prepared_bytes=len(prepared),
                max_width=max_width,
                quality=quality,
            )
            return prepared, "image/jpeg"
        return image_bytes, mime_type or "image/jpeg"
    except Exception as exc:
        _log("VISION_IMAGE_PREPARE_WARNING", error=repr(exc))
        return image_bytes, mime_type or "image/jpeg"

async def extract_product_from_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, str]:
    if not image_bytes:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    cfg = _openrouter_config()
    if not config_env.vision_enabled():
        reason = config_env.vision_disabled_reason()
        _log("VISION_DISABLED_REASON", reason=reason)
        return {"status": "IMAGE_UNCLEAR", "message": "فحص الصور غير مفعّل حاليًا. اكتب اسم المنتج كاملًا."}

    vision_t0 = time.perf_counter()
    _log("VISION_START")
    _log("VISION_PROVIDER", provider="OpenRouter")
    _log("VISION_MODEL", model=cfg["model"])

    image_bytes, mime_type = _prepare_image_for_vision(image_bytes, mime_type)
    data_url = f"data:{mime_type};base64," + base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "You are reading a pharmacy product package image. Return strict JSON only, no prose, with keys: "
        "foreground_product_text, main_visible_product, raw_vision_text, brand, product_name, product_family, form, strength, size, pack, visible_text, background_text, confidence. "
        "Focus only on the largest/front/central product. If other products, shelf labels, receipts, bags, or background text are visible, put them only in background_text and never in brand/product_name/product_family. "
        "raw_vision_text and visible_text must be copied from words actually visible on the package, not inferred. "
        "Do not invent or infer a brand/product name from memory or from the catalog. Do not use any word that is not visible on the package. "
        "Do not guess missing strength/size. If the front product name is not visible, set confidence below 0.75. "
        "Ignore generic words when no brand/product name is visible."
    )
    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]}
        ],
        "temperature": 0,
        "max_tokens": 260,
        "response_format": {"type": "json_object"},
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    try:
        timeout_s = _env_float("PRICEBOT_OPENROUTER_TIMEOUT", _env_float("PRICEBOT_VISION_TIMEOUT_SECONDS", 8.0))
        async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_s, connect=min(timeout_s, 5.0))) as client:
            resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                _log("VISION_ERROR", provider="openrouter", status=resp.status_code, elapsed_ms=int((time.perf_counter()-vision_t0)*1000))
                return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as exc:
        _log("VISION_ERROR", provider="openrouter", status=type(exc).__name__, elapsed_ms=int((time.perf_counter()-vision_t0)*1000))
        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}

    try:
        start = content.find("{")
        end = content.rfind("}")
        data = json.loads(content[start:end + 1] if start >= 0 and end > start else content)
    except Exception:
        elapsed = int((time.perf_counter()-vision_t0)*1000)
        _log("VISION_ERROR", provider="openrouter", status="bad_json", elapsed_ms=elapsed, content_preview=str(content or "")[:180])
        fallback = _fallback_slots_from_bad_json(content)
        if fallback and not _is_weak_visual_query(fallback.get("query", ""), fallback):
            _log("VISION_BAD_JSON_FALLBACK_OK", query=fallback.get("query", "")[:160], elapsed_ms=elapsed)
            fallback["bad_json_fallback"] = "1"
            fallback["confidence"] = str(fallback.get("confidence") or "0.76")
            return fallback
        _log("VISION_BAD_JSON_FALLBACK_REJECTED", elapsed_ms=elapsed)
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    try:
        confidence = float(data.get("confidence") or 0)
    except Exception:
        confidence = 0.0
    query = build_query_from_slots(data)
    _log("VISION_EXTRACTED_NAME", value=query[:120])
    _log("VISION_CONFIDENCE", value=confidence)
    _log("VISION_DONE", elapsed_ms=int((time.perf_counter()-vision_t0)*1000))

    if confidence < 0.75 or _is_weak_visual_query(query, data):
        return {"status": "LOW_CONFIDENCE", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}
    data["status"] = "OK"
    data["query"] = query
    data["confidence"] = str(confidence)
    return data
