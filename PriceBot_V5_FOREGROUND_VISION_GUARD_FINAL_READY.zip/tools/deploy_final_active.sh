#!/usr/bin/env bash
set -euo pipefail

ACTIVE_DIR="${PRICEBOT_ACTIVE_DIR:-/opt/pricebot_clean}"
SHORTCUT="${PRICEBOT_SHORTCUT:-/opt/pricebot}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
SRC_DIR="${PRICEBOT_RELEASE_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP_ROOT="${PRICEBOT_BACKUP_DIR:-$ACTIVE_DIR/backups}"
BACKUP_PATH="$BACKUP_ROOT/app_code_before_v5_$TS.tar.gz"

if [ "$ACTIVE_DIR" != "/opt/pricebot_clean" ]; then
  echo "DEPLOY_REFUSED: active path must be /opt/pricebot_clean, got $ACTIVE_DIR"
  exit 1
fi
if [ ! -d "$ACTIVE_DIR" ]; then
  echo "DEPLOY_REFUSED: active dir missing: $ACTIVE_DIR"
  exit 1
fi
if [ -L "$SHORTCUT" ]; then
  TARGET="$(readlink -f "$SHORTCUT")"
  if [ "$TARGET" != "$ACTIVE_DIR" ]; then
    echo "DEPLOY_REFUSED: $SHORTCUT points to $TARGET, expected $ACTIVE_DIR"
    exit 1
  fi
else
  echo "DEPLOY_REFUSED: $SHORTCUT must remain a symlink/shortcut to $ACTIVE_DIR"
  exit 1
fi
if [ ! -f "$ACTIVE_DIR/pricebot.db" ]; then
  echo "DEPLOY_REFUSED: production DB not found at $ACTIVE_DIR/pricebot.db"
  exit 1
fi
if [ ! -f "$ACTIVE_DIR/.env" ]; then
  echo "DEPLOY_REFUSED: .env not found at $ACTIVE_DIR/.env"
  exit 1
fi

mkdir -p "$BACKUP_ROOT"
tar -C "$ACTIVE_DIR" \
  --exclude='./venv' \
  --exclude='./backups' \
  --exclude='./uploads' \
  --exclude='./pricebot.db' \
  --exclude='./pricebot.db-*' \
  --exclude='./.env' \
  --exclude='./*.log' \
  -czf "$BACKUP_PATH" .
echo "BACKUP_OK=$BACKUP_PATH"

rsync -a --delete \
  --exclude='.env' \
  --exclude='pricebot.db' \
  --exclude='pricebot.db-*' \
  --exclude='venv/' \
  --exclude='backups/' \
  --exclude='uploads/' \
  --exclude='*.log' \
  --exclude='__pycache__/' \
  --exclude='.git/' \
  "$SRC_DIR/" "$ACTIVE_DIR/"

echo "CODE_DEPLOYED_TO=$ACTIVE_DIR"
cd "$ACTIVE_DIR"

# Safe production defaults for image speed and confirmation mode.
# Preserve all secrets; only normalize operational non-secret toggles.
if [ -f .env ]; then
  for k in PRICEBOT_USE_CELERY PRICEBOT_VISION_TIMEOUT_SECONDS PRICEBOT_VISION_TOTAL_TIMEOUT_SECONDS PRICEBOT_OPENROUTER_TIMEOUT PRICEBOT_VISION_MAX_IMAGE_WIDTH PRICEBOT_VISION_JPEG_QUALITY PRICEBOT_IMAGE_CACHE_CONFIRMATION_ONLY PRICEBOT_IMAGE_CACHE_EXACT_ONLY; do
    sed -i "/^${k}=/d" .env || true
  done
  cat >> .env <<'EOF'
PRICEBOT_USE_CELERY=0
PRICEBOT_VISION_TIMEOUT_SECONDS=8
PRICEBOT_VISION_TOTAL_TIMEOUT_SECONDS=10
PRICEBOT_OPENROUTER_TIMEOUT=8
PRICEBOT_VISION_MAX_IMAGE_WIDTH=1024
PRICEBOT_VISION_JPEG_QUALITY=78
PRICEBOT_IMAGE_CACHE_CONFIRMATION_ONLY=1
PRICEBOT_IMAGE_CACHE_EXACT_ONLY=1
EOF
fi

if [ ! -x ./venv/bin/python ]; then
  python3 -m venv venv
fi
./venv/bin/python -m pip install --upgrade pip >/dev/null
./venv/bin/pip install -r requirements.txt
./venv/bin/python -m compileall -q .

PRICEBOT_DB_PATH="$ACTIVE_DIR/pricebot.db" ./venv/bin/python - <<'PY'
import json
import database
counts = {
    "products": database.count_products(),
    "product_identity_registry": database.count_table("product_identity_registry"),
    "product_search_index": database.count_table("product_search_index"),
    "guided_catalog_index": database.count_table("guided_catalog_index"),
}
print("DB_COUNTS=" + json.dumps(counts, ensure_ascii=False))
if counts["products"] < 1:
    raise SystemExit("DEPLOY_REFUSED: products table is empty")
PY

systemctl restart "$SERVICE_NAME"
systemctl is-active --quiet "$SERVICE_NAME"

# PRICEBOT_DEPLOY_HEALTH_WAIT_FINAL_V1
HEALTH_URL="${PRICEBOT_HEALTH_URL:-http://127.0.0.1:8090/health}"
if command -v curl >/dev/null 2>&1; then
  echo "WAITING_HEALTH=$HEALTH_URL"
  ok=0
  for i in $(seq 1 30); do
    if curl -fsS "$HEALTH_URL" >/tmp/pricebot_health_v5_final.txt 2>/tmp/pricebot_health_v5_final.err; then
      echo "HEALTH_OK"
      cat /tmp/pricebot_health_v5_final.txt
      ok=1
      break
    fi
    echo "waiting health... $i"
    sleep 2
  done
  if [ "$ok" != "1" ]; then
    echo "HEALTH_FAILED"
    cat /tmp/pricebot_health_v5_final.err || true
    journalctl -u "$SERVICE_NAME" -n 180 --no-pager -l || true
    exit 1
  fi
fi

echo "DEPLOY_OK"
echo "ACTIVE_DIR=$ACTIVE_DIR"
echo "SERVICE_NAME=$SERVICE_NAME"
echo "DB_PRESERVED=$ACTIVE_DIR/pricebot.db"
echo "ENV_PRESERVED=$ACTIVE_DIR/.env"
