# PriceBot V5 Vision Evidence Validator Fix

## Problem fixed
A readable product image could be matched to an unrelated catalog product when the Vision model hallucinated a structured `product_name`. Example: a Hemazym package image was interpreted as `high life hair cream`, so the matcher suggested unrelated High Life products.

## Root cause
The image pipeline trusted model-inferred fields such as `product_name`, `brand`, and `form` without requiring support from OCR-like visible package text. This allowed a hallucinated catalog-looking name to enter deterministic matching.

## Implemented fix
- Added `PRICEBOT_V5_VISION_EVIDENCE_VALIDATOR_V1` in `services/matching/excel_native_matcher.py`.
- Image candidates are now validated against `visible_text` / `raw_vision_text` first.
- `foreground_product_text` / `main_visible_product` are used only as fallback evidence when primary OCR text is absent.
- A candidate with multiple identity tokens must have strong visible OCR support; one shared marketing word such as `high` is no longer enough.
- Exact image matches now require product identity evidence before acceptance.
- Unsupported hallucinated forms are ignored. Example: if Vision says `form=cream` but the visible text says `30 capsules`, the matcher does not reject Hemazym because of the hallucinated cream form.
- Image confirmation text in `app.py` now prefers `visible_text` / `raw_vision_text` before inferred `product_name`.
- Vision prompt in `vision_service.py` now asks for `raw_vision_text` and explicitly forbids invented/non-visible words.
- Added Hemazym OCR phrase rule in `data/catalog_corrections.json`.

## Regression test added
`tests/test_vision_evidence_validator.py`

Covers:
1. Hemazym visible text + hallucinated `product_name=high life hair cream` must return Hemazym only.
2. A real High Life image/text can still return High Life when `high life hair cream` is actually visible.

## Validation run
- `python -m py_compile` on all Python files: PASS
- `python tests/test_vision_evidence_validator.py`: PASS

See `VISION_EVIDENCE_VALIDATOR_TEST_RESULTS.txt`.
