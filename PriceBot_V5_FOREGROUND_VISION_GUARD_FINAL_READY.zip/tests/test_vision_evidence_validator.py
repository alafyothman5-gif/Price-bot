#!/usr/bin/env python3
from __future__ import annotations

"""Regression tests for image hallucination safety.

The important failure this covers: Vision may hallucinate a catalog-looking
product name (for example "high life hair cream") while the visible package OCR
contains a different product (for example Hemazym).  Image matching must trust
visible OCR evidence, not the hallucinated structured product_name.
"""

import os
from pathlib import Path


def _insert_product(con, **row):
    cols = list(row.keys())
    con.execute(
        "INSERT INTO products(" + ",".join(cols) + ") VALUES(" + ",".join(["?"] * len(cols)) + ")",
        [row[c] for c in cols],
    )


def _names(result):
    products = result.products or ([result.product] if result.product else [])
    return [str(p.get("name") or "") for p in products]


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    db_path = Path(os.getenv("PRICEBOT_TEST_DB", "/tmp/pricebot_vision_evidence_test.db"))
    if db_path.exists():
        db_path.unlink()
    os.environ["PRICEBOT_DB_PATH"] = str(db_path)
    os.environ.setdefault("PRICEBOT_MATCH_LOG", "0")
    os.environ.setdefault("PRICEBOT_LEARNING_ENABLED", "0")

    import sys
    sys.path.insert(0, str(root))
    import database

    database.configure_db_path(str(db_path))
    database.init_db(run_production_guard=False)
    with database.connect() as con:
        _insert_product(
            con,
            product_id="PL02448",
            name="Hemazym",
            normalized_name="hemazym",
            brand="Hemazym",
            company="Hemazym",
            category="supplement",
            section="مكملات وفيتامينات",
            product_family="Hemazym",
            form="capsule",
            product_type="capsule",
            pack="30 capsules",
            aliases="Hemazym | هيمازيم | Hemazym Iron | Liposomal Hemazym",
            ocr_keywords="Hemazym | Liposomal Iron | Iron Supplement | Folic Acid | Vitamin B12 | 30 capsules | حديد | كبسولات حديد | capsule",
            use_case="iron",
            available="true",
            price="114",
            currency="LYD",
            search_mode="searchable",
            quality_status="ready",
            review_status="approved",
            original_name="Hemazym",
        )
        for pid in ["PL02462", "PL02463"]:
            _insert_product(
                con,
                product_id=pid,
                name="high life hair cream",
                normalized_name="high life hair cream",
                brand="high",
                company="high",
                category="cosmetic",
                section="عناية بالشعر",
                product_family="high life hair cream",
                form="cream",
                product_type="cream",
                aliases="high life hair cream | high | highlifehaircream",
                ocr_keywords="high life hair cream | high | cream | life | hair",
                use_case="hair_treatment",
                available="true",
                price="12",
                currency="LYD",
                search_mode="searchable",
                quality_status="ready",
                review_status="needs_review",
                original_name="high life hair cream",
            )

    from services.matching.excel_native_matcher import invalidate_memory_index, match_vision_slots, preload_search_index

    invalidate_memory_index()
    preload_search_index()

    hallucinated_slots = {
        "product_name": "high life hair cream",
        "form": "cream",
        "visible_text": "Hemazym Liposomal Iron Supplement High Absorption Folic Acid Vitamin B12 30 Capsules",
        "confidence": 0.95,
    }
    result = match_vision_slots(hallucinated_slots)
    names = _names(result)
    assert result.status in {"EXACT_MATCH", "ASK_CLARIFICATION"}, (result.status, names, result.diagnostics)
    assert any("hemazym" in n.lower() for n in names), names
    assert all("high life" not in n.lower() for n in names), names

    real_high_life_slots = {
        "product_name": "high life hair cream",
        "form": "cream",
        "visible_text": "high life hair cream",
        "confidence": 0.95,
    }
    real_result = match_vision_slots(real_high_life_slots)
    real_names = _names(real_result)
    assert any("high life" in n.lower() for n in real_names), (real_result.status, real_names, real_result.diagnostics)

    print("VISION_EVIDENCE_VALIDATOR_TEST_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
