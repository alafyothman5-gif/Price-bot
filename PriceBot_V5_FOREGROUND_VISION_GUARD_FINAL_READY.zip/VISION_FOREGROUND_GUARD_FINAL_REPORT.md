# Vision Foreground Guard Final Fix

This release fixes the general image failure mode observed after V5:

1. Bad JSON from Vision is parsed conservatively from foreground/visible fields instead of being rejected immediately.
2. Background text is never used to create image candidates.
3. Image candidate suggestions require at least two foreground identity tokens, or reviewed catalog phrase rules.
4. Structured model guesses such as brand/product_name must be supported by foreground OCR evidence.
5. Image mode remains confirmation-only: no price/availability is displayed directly from a photo.
6. Deploy health check waits for port 8090 instead of failing immediately while Uvicorn starts.

Examples intended by this fix:
- Vichy Normaderm-like images should produce confirmation candidates if foreground words are readable.
- A background-only or single-token extraction such as Hemazym 3 is rejected as low-confidence instead of becoming a product candidate.
- Transition 4g must not sell Transition 10g.
