from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

import httpx

import config_env
import database
from normalizer import normalize_text

MATCHER_NAME = "v15_gemini_router_clean"
DEFAULT_VERIFICATION_MODEL = "google/gemini-2.5-flash-lite"
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
PRESCRIPTION_HINTS = {
    "rx", "prescription", "doctor", "patient", "diagnosis", "dose", "dosage", "clinic", "hospital",
    "روشتة", "روشته", "وصفة", "وصفه", "دكتور", "طبيب", "عيادة", "عياده", "مريض", "تشخيص", "جرعة", "الجرعة",
}


def product_name(product: Dict[str, Any]) -> str:
    return str(product.get("canonical_display_name") or product.get("name") or product.get("original_name") or "").strip()


def _plain_price(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        d = Decimal(text)
        out = format(d, "f")
        if "." in out:
            out = out.rstrip("0").rstrip(".")
        return out
    except Exception:
        return text


def product_price(product: Dict[str, Any], default_currency: str = "LYD") -> str:
    price = _plain_price(product.get("price"))
    currency = str(product.get("currency") or default_currency or "LYD").strip()
    return f"{price} {currency}".strip() if price else ""


def looks_like_prescription(text: Any) -> bool:
    value = normalize_text(text or "")
    return any(h in value for h in PRESCRIPTION_HINTS)


_QUERY_DROP_WORDS = {
    "السلام", "عليكم", "عليك", "مرحبا", "اهلا", "اهلاً", "أهلا", "أهلاً", "لو", "سمحت", "سمحتي",
    "متوفر", "موجود", "عندكم", "عندك", "لديكم", "في", "الصيدلية", "صيدلية", "نبي", "ابي", "أبي",
    "نبى", "اريد", "أريد", "سعر", "كم", "شن", "بكم", "هل", "ممكن", "بالله", "لو سمحت",
    "available", "price", "have", "do", "you", "please", "pharmacy", "how", "much", "is", "the", "a", "an",
}
_QUERY_ALIAS_MAP = {
    "اموكلان": "amoclan", "اموكلان": "amoclan", "أموكلان": "amoclan", "اموكلان": "amoclan",
    "باندول": "panadol", "بانادول": "panadol", "بنادول": "panadol",
    "لاروش": "la roche", "لا روش": "la roche", "لاروش بوزيه": "la roche posay", "لاروش بوزي": "la roche posay",
    "فيروكسيل": "ferroxyl", "هيمازيم": "hemazym", "هيموزيم": "hemazym",
}

@dataclass
class SemanticDecision:
    action: str  # direct | confirm | unavailable
    product: Optional[Dict[str, Any]] = None
    product_id: int = 0
    confidence: float = 0.0
    similarity: float = 0.0
    source: str = ""
    reason: str = ""
    candidates: List[Dict[str, Any]] = field(default_factory=list)
    query_text: str = ""

    @property
    def matched(self) -> bool:
        return self.action in {"direct", "confirm"} and bool(self.product)


class SemanticMatcher:
    """PriceBot V10 matcher: pgvector retrieval + Gemini/OpenRouter verification.

    Product rows for indexing are read through database.load_product_rows(); live retrieval is
    handled by pgvector, and the final decision is made by Gemini only.
    """

    def __init__(self, ttl_seconds: int = 300) -> None:
        self.ttl_seconds = int(ttl_seconds or 300)
        self.embedding_dim = int(os.getenv("PRICEBOT_EMBEDDING_DIM", "1536") or 1536)
        self.top_k = int(os.getenv("PRICEBOT_SEMANTIC_TOP_K", "50") or 50)
        self.verify_top_k = int(os.getenv("PRICEBOT_GEMINI_VERIFY_TOP_K", "50") or 50)
        self.memory_direct_threshold = float(os.getenv("PRICEBOT_MEMORY_DIRECT_THRESHOLD", "0.95") or 0.95)
        self.memory_confirm_threshold = float(os.getenv("PRICEBOT_MEMORY_CONFIRM_THRESHOLD", "0.85") or 0.85)
        self.enable_memory_decisions = str(os.getenv("PRICEBOT_ENABLE_SEMANTIC_MEMORY_DECISIONS", "0")).strip().lower() in {"1", "true", "yes", "on"}
        self.direct_confidence_threshold = float(os.getenv("PRICEBOT_GEMINI_DIRECT_CONFIDENCE", "0.99") or 0.99)
        self.confirm_confidence_threshold = float(os.getenv("PRICEBOT_GEMINI_CONFIRM_CONFIDENCE", "0.85") or 0.85)
        self.redis_ttl = int(os.getenv("PRICEBOT_SEMANTIC_REDIS_TTL_SECONDS", "604800") or 604800)
        self.schema_ready = False
        self.last_error = ""
        self.last_indexed_count = 0
        self.last_schema_ts = 0.0
        self.last_index_ts = 0.0
        self._log: Optional[Callable[..., None]] = None
        self._embedding_cache: Dict[str, List[float]] = {}
        self._cache_lock = asyncio.Lock()
        self._redis = None
        self._redis_checked = False

    def set_logger(self, logger: Callable[..., None]) -> None:
        self._log = logger

    def log(self, event: str, **kw: Any) -> None:
        if self._log:
            try:
                self._log(event, **kw)
                return
            except Exception:
                pass
        payload = {"ts": round(time.time(), 3), "event": event, **kw}
        print(json.dumps(payload, ensure_ascii=False, default=str), flush=True)

    @property
    def age_seconds(self) -> float:
        return max(0.0, time.time() - self.last_index_ts) if self.last_index_ts else 999999.0

    def _provider_config(self) -> Dict[str, str]:
        config_env.apply_openrouter_aliases()
        provider = str(os.getenv("PRICEBOT_EMBEDDING_PROVIDER", "")).strip().lower()
        if not provider:
            provider = "openai" if os.getenv("OPENAI_API_KEY", "").strip() else "openrouter"
        if provider == "openai":
            return {
                "provider": "openai",
                "api_key": os.getenv("OPENAI_API_KEY", "").strip(),
                "base_url": (os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").strip() or "https://api.openai.com/v1").rstrip("/"),
                "model": os.getenv("PRICEBOT_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL).strip() or DEFAULT_EMBEDDING_MODEL,
            }
        return {
            "provider": "openrouter",
            "api_key": config_env.resolve_openrouter_api_key(),
            "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
            "model": os.getenv("PRICEBOT_EMBEDDING_MODEL", os.getenv("OPENROUTER_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL)).strip() or DEFAULT_EMBEDDING_MODEL,
        }

    def embeddings_configured(self) -> bool:
        cfg = self._provider_config()
        return bool(cfg.get("api_key") and cfg.get("model"))

    def verification_model(self) -> str:
        return config_env.openrouter_gemini_model(["OPENROUTER_MODEL"], default=DEFAULT_VERIFICATION_MODEL)

    def _vector_literal(self, values: Sequence[float]) -> str:
        clean: List[str] = []
        for value in values:
            f = float(value)
            if not math.isfinite(f):
                f = 0.0
            clean.append(f"{f:.8g}")
        return "[" + ",".join(clean) + "]"

    def _product_embedding_text(self, product: Dict[str, Any]) -> str:
        fields = [
            "name", "original_name", "canonical_display_name", "brand", "company",
            "active_ingredient", "form", "strength", "size", "pack", "barcode",
        ]
        values: List[str] = []
        seen = set()
        for field in fields:
            value = re.sub(r"\s+", " ", str(product.get(field) or "")).strip()
            key = value.lower()
            if value and key not in seen:
                values.append(value)
                seen.add(key)
        return " | ".join(values)[:1800]

    async def _redis_client(self):
        if self._redis_checked:
            return self._redis
        self._redis_checked = True
        url = os.getenv("REDIS_URL", "").strip()
        if not url:
            return None
        try:
            import redis.asyncio as redis_async  # type: ignore
            self._redis = redis_async.from_url(url, decode_responses=True, socket_timeout=1.5, socket_connect_timeout=1.5)
            await self._redis.ping()
            return self._redis
        except Exception as exc:
            self.log("SEMANTIC_REDIS_CACHE_DISABLED", error=repr(exc))
            self._redis = None
            return None

    def _cache_key(self, prefix: str, text: str) -> str:
        digest = hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()
        return f"pricebot:v13lite:{prefix}:{digest}"

    async def _get_cached_embedding(self, text: str) -> Optional[List[float]]:
        key = self._cache_key("embedding", text)
        async with self._cache_lock:
            cached = self._embedding_cache.get(key)
            if cached:
                return list(cached)
        redis = await self._redis_client()
        if redis is not None:
            try:
                raw = await redis.get(key)
                if raw:
                    data = json.loads(raw)
                    if isinstance(data, list):
                        vector = [float(x) for x in data]
                        async with self._cache_lock:
                            self._embedding_cache[key] = vector
                        return vector
            except Exception:
                pass
        return None

    async def _set_cached_embedding(self, text: str, embedding: List[float]) -> None:
        key = self._cache_key("embedding", text)
        async with self._cache_lock:
            if len(self._embedding_cache) > 5000:
                self._embedding_cache.clear()
            self._embedding_cache[key] = list(embedding)
        redis = await self._redis_client()
        if redis is not None:
            try:
                await redis.set(key, json.dumps(embedding, separators=(",", ":")), ex=self.redis_ttl)
            except Exception:
                pass

    def _embedding_headers(self, cfg: Dict[str, str]) -> Dict[str, str]:
        headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
        if cfg.get("provider") == "openrouter":
            headers.setdefault("HTTP-Referer", os.getenv("OPENROUTER_SITE_URL", "https://pricebot.local"))
            headers.setdefault("X-Title", os.getenv("OPENROUTER_APP_NAME", "PriceBot"))
        return headers

    async def _request_embeddings(self, inputs: List[str]) -> List[List[float]]:
        cfg = self._provider_config()
        if not cfg.get("api_key"):
            raise RuntimeError(f"{cfg.get('provider')}_embedding_api_key_missing")
        payload = {"model": cfg["model"], "input": inputs}
        timeout = float(os.getenv("PRICEBOT_EMBEDDING_TIMEOUT_SECONDS", "15") or 15)
        attempts = int(os.getenv("PRICEBOT_EMBEDDING_RETRY_ATTEMPTS", "2") or 2)
        delay = 0.4
        last_error = ""
        async with httpx.AsyncClient(timeout=timeout) as client:
            for attempt in range(1, attempts + 1):
                try:
                    response = await client.post(f"{cfg['base_url']}/embeddings", headers=self._embedding_headers(cfg), json=payload)
                    if response.status_code < 400:
                        body = response.json()
                        rows = body.get("data") or []
                        rows = sorted(rows, key=lambda r: int(r.get("index", 0)))
                        vectors = [[float(x) for x in row.get("embedding", [])] for row in rows]
                        if len(vectors) != len(inputs) or any(not v for v in vectors):
                            raise RuntimeError("embedding_response_shape_invalid")
                        return vectors
                    last_error = f"status={response.status_code} body={response.text[:300]}"
                except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError, RuntimeError, ValueError, KeyError) as exc:
                    last_error = repr(exc)
                if attempt < attempts:
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 3.0)
        raise RuntimeError(f"embedding_request_failed:{last_error}")

    async def get_embedding(self, text: str) -> List[float]:
        query = re.sub(r"\s+", " ", str(text or "")).strip()
        if not query:
            raise ValueError("empty_embedding_text")
        cached = await self._get_cached_embedding(query)
        if cached:
            return cached
        vector = (await self._request_embeddings([query]))[0]
        if self.embedding_dim and len(vector) != self.embedding_dim:
            raise RuntimeError(f"embedding_dimension_mismatch expected={self.embedding_dim} got={len(vector)}")
        await self._set_cached_embedding(query, vector)
        return vector

    async def get_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        out: List[Optional[List[float]]] = [None] * len(texts)
        missing_idx: List[int] = []
        missing_texts: List[str] = []
        for i, text in enumerate(texts):
            cached = await self._get_cached_embedding(text)
            if cached:
                out[i] = cached
            else:
                missing_idx.append(i)
                missing_texts.append(text)
        if missing_texts:
            vectors = await self._request_embeddings(missing_texts)
            for i, vector in zip(missing_idx, vectors):
                if self.embedding_dim and len(vector) != self.embedding_dim:
                    raise RuntimeError(f"embedding_dimension_mismatch expected={self.embedding_dim} got={len(vector)}")
                out[i] = vector
                await self._set_cached_embedding(texts[i], vector)
        return [v or [] for v in out]

    async def initialize(self, *, auto_index: bool = True) -> Dict[str, Any]:
        if not database.IS_POSTGRES:
            self.schema_ready = False
            self.last_error = "postgres_required_for_pgvector"
            self.log("SEMANTIC_SCHEMA_SKIPPED", reason=self.last_error)
            return self.health()
        try:
            with database.connect() as conn:
                conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
                conn.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
                conn.execute(f"ALTER TABLE products ADD COLUMN IF NOT EXISTS embedding vector({self.embedding_dim})")
                conn.execute(f"""
                    CREATE TABLE IF NOT EXISTS semantic_memory (
                        id BIGSERIAL PRIMARY KEY,
                        query_text TEXT NOT NULL,
                        query_embedding vector({self.embedding_dim}) NOT NULL,
                        product_id BIGINT NOT NULL,
                        confidence_score DOUBLE PRECISION NOT NULL DEFAULT 0,
                        confirmed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_semantic_memory_product_id ON semantic_memory(product_id)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_semantic_memory_confirmed_at ON semantic_memory(confirmed_at DESC)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_products_embedding_hnsw ON products USING hnsw (embedding vector_cosine_ops)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_semantic_memory_embedding_hnsw ON semantic_memory USING hnsw (query_embedding vector_cosine_ops)")
                try:
                    cols = set(database.table_columns(conn, "products"))
                    for col in ["name", "normalized_name", "original_name", "brand", "product_family", "aliases"]:
                        if col in cols:
                            safe_col = re.sub(r"[^a-zA-Z0-9_]", "", col)
                            conn.execute(f"CREATE INDEX IF NOT EXISTS idx_products_{safe_col}_trgm ON products USING GIN ((CAST({safe_col} AS TEXT)) gin_trgm_ops)")
                except Exception as exc:
                    self.log("TRIGRAM_INDEX_WARNING", error=repr(exc))
            self.schema_ready = True
            self.last_schema_ts = time.time()
            self.last_error = ""
            self.log("SEMANTIC_SCHEMA_READY", matcher=MATCHER_NAME, embedding_dim=self.embedding_dim, hybrid="pgvector+pg_trgm")
        except Exception as exc:
            self.schema_ready = False
            self.last_error = repr(exc)
            self.log("SEMANTIC_SCHEMA_ERROR", error=repr(exc))
            return self.health()
        if auto_index and str(os.getenv("PRICEBOT_SEMANTIC_INDEX_ON_STARTUP", "1")).lower() not in {"0", "false", "no", "off"}:
            try:
                limit = int(os.getenv("PRICEBOT_SEMANTIC_INDEX_STARTUP_LIMIT", "10000") or 10000)
                await self.rebuild_missing_embeddings(limit=limit)
            except Exception as exc:
                self.last_error = repr(exc)
                self.log("SEMANTIC_INDEX_STARTUP_WARNING", error=repr(exc))
        return self.health()

    def _missing_embedding_ids(self, limit: int) -> set[int]:
        if not database.IS_POSTGRES or not self.schema_ready:
            return set()
        with database.connect() as conn:
            rows = conn.execute("SELECT id FROM products WHERE embedding IS NULL ORDER BY id LIMIT %s", (int(limit),)).fetchall()
        ids: set[int] = set()
        for row in rows:
            try:
                ids.add(int(row[0] if not isinstance(row, dict) else row.get("id")))
            except Exception:
                pass
        return ids

    async def rebuild_missing_embeddings(self, *, limit: int = 10000, batch_size: Optional[int] = None) -> Dict[str, Any]:
        if not database.IS_POSTGRES:
            return {"ok": False, "reason": "postgres_required"}
        if not self.schema_ready:
            await self.initialize(auto_index=False)
        if not self.schema_ready:
            return {"ok": False, "reason": self.last_error or "schema_not_ready"}
        if not self.embeddings_configured():
            self.log("SEMANTIC_INDEX_SKIPPED", reason="embedding_api_key_missing")
            return {"ok": False, "reason": "embedding_api_key_missing"}
        limit = max(1, int(limit or 1))
        batch_size = max(1, int(batch_size or os.getenv("PRICEBOT_EMBEDDING_BATCH_SIZE", "64") or 64))
        missing_ids = self._missing_embedding_ids(limit)
        if not missing_ids:
            self.last_index_ts = time.time()
            return {"ok": True, "indexed": 0, "remaining_missing_sample": 0}
        products = [p for p in database.load_product_rows(visible_only=True) if int(p.get("id") or 0) in missing_ids]
        products = products[:limit]
        indexed = 0
        for start in range(0, len(products), batch_size):
            chunk = products[start:start + batch_size]
            texts = [self._product_embedding_text(p) or product_name(p) for p in chunk]
            vectors = await self.get_embeddings_batch(texts)
            with database.connect() as conn:
                for product, vector in zip(chunk, vectors):
                    if not vector:
                        continue
                    conn.execute(
                        "UPDATE products SET embedding = %s::vector WHERE id = %s",
                        (self._vector_literal(vector), int(product.get("id") or 0)),
                    )
                    indexed += 1
            self.log("SEMANTIC_INDEX_BATCH", indexed=indexed, batch=len(chunk), total=len(products))
        self.last_indexed_count = indexed
        self.last_index_ts = time.time()
        self.log("SEMANTIC_INDEX_READY", indexed=indexed, matcher=MATCHER_NAME)
        return {"ok": True, "indexed": indexed, "considered": len(products)}

    def _visible_product(self, product: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not product:
            return None
        if not database.product_visible(product, guided=False):
            return None
        return product

    def _memory_lookup(self, embedding: List[float]) -> Optional[SemanticDecision]:
        if not database.IS_POSTGRES or not self.schema_ready:
            return None
        vector = self._vector_literal(embedding)
        with database.connect() as conn:
            rows = conn.execute(
                """
                SELECT sm.product_id, sm.confidence_score,
                       1 - (sm.query_embedding <=> %s::vector) AS similarity,
                       p.*
                FROM semantic_memory sm
                JOIN products p ON p.id = sm.product_id
                ORDER BY sm.query_embedding <=> %s::vector
                LIMIT 1
                """,
                (vector, vector),
            ).fetchall()
        if not rows:
            return None
        row = dict(rows[0])
        similarity = float(row.get("similarity") or 0.0)
        product = self._visible_product(row)
        if not product:
            return None
        if similarity >= self.memory_direct_threshold:
            return SemanticDecision(action="direct", product=product, product_id=int(product.get("id") or 0), confidence=float(row.get("confidence_score") or 1.0), similarity=similarity, source="semantic_memory")
        if similarity >= self.memory_confirm_threshold:
            return SemanticDecision(action="confirm", product=product, product_id=int(product.get("id") or 0), confidence=float(row.get("confidence_score") or 0.8), similarity=similarity, source="semantic_memory_confirm")
        return None

    def _semantic_candidates(self, embedding: List[float], *, limit: int) -> List[Dict[str, Any]]:
        if not database.IS_POSTGRES or not self.schema_ready:
            return []
        vector = self._vector_literal(embedding)
        fetch_limit = max(int(limit or self.top_k) * 4, int(limit or self.top_k))
        with database.connect() as conn:
            rows = conn.execute(
                """
                SELECT *, 1 - (embedding <=> %s::vector) AS similarity
                FROM products
                WHERE embedding IS NOT NULL
                ORDER BY embedding <=> %s::vector
                LIMIT %s
                """,
                (vector, vector, fetch_limit),
            ).fetchall()
        out: List[Dict[str, Any]] = []
        for row in rows:
            product = dict(row)
            if not self._visible_product(product):
                continue
            try:
                product["similarity"] = float(product.get("similarity") or 0.0)
            except Exception:
                product["similarity"] = 0.0
            out.append(product)
            if len(out) >= limit:
                break
        return out

    def _candidate_text(self, product: Dict[str, Any]) -> str:
        fields = ["name", "canonical_display_name", "original_name", "brand", "product_family", "active_ingredient", "form", "strength", "size", "pack"]
        parts: List[str] = []
        seen = set()
        for field in fields:
            value = re.sub(r"\s+", " ", str(product.get(field) or "")).strip()
            key = value.lower()
            if value and key not in seen:
                parts.append(value)
                seen.add(key)
        return " | ".join(parts)[:1000]

    def _clean_customer_query(self, query: Any) -> str:
        text = re.sub(r"\s+", " ", str(query or "").strip())
        if not text:
            return ""
        # Remove common customer/request words but keep product-like tokens.
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9\-]{1,}|[\u0600-\u06FF]{2,}|\d+(?:\.\d+)?", text)
        kept: List[str] = []
        for token in tokens:
            n = normalize_text(token)
            if not n or n in _QUERY_DROP_WORDS:
                continue
            kept.append(token)
        cleaned = " ".join(kept).strip()
        return cleaned or text

    def _query_variants(self, query: Any) -> List[str]:
        base = self._clean_customer_query(query)
        raw = re.sub(r"\s+", " ", str(query or "").strip())
        variants: List[str] = []
        for value in [base, raw]:
            value = value.strip()
            if value and normalize_text(value) not in {normalize_text(v) for v in variants}:
                variants.append(value)
        norm_base = normalize_text(base)
        for src, dst in _QUERY_ALIAS_MAP.items():
            if normalize_text(src) in norm_base and dst not in variants:
                variants.insert(0, dst)
        # Optional ops-defined aliases without code changes: {"arabic":"english", ...}
        try:
            custom = json.loads(os.getenv("PRICEBOT_QUERY_ALIASES_JSON", "{}") or "{}")
            if isinstance(custom, dict):
                for src, dst in custom.items():
                    if normalize_text(src) in norm_base and str(dst).strip() not in variants:
                        variants.insert(0, str(dst).strip())
        except Exception:
            pass
        return variants[:6]

    def _lexical_family_candidates(self, query: str, *, limit: int) -> List[Dict[str, Any]]:
        variants = self._query_variants(query)
        if not variants:
            return []
        rows = database.load_product_rows(visible_only=True)
        scored: List[tuple[float, int, Dict[str, Any]]] = []
        seen: set[int] = set()
        for variant in variants:
            vn = normalize_text(variant)
            if not vn or len(vn) < 3:
                continue
            vtoks = [t for t in re.findall(r"[a-z0-9]{3,}|[\u0600-\u06FF]{3,}", vn) if t not in _QUERY_DROP_WORDS]
            for p in rows:
                pid = int(p.get("id") or 0)
                if not pid or pid in seen:
                    continue
                txt = normalize_text(self._candidate_text(p))
                if not txt:
                    continue
                score = 0.0
                if vn == txt:
                    score = 10.0
                elif txt.startswith(vn):
                    score = 8.0
                elif vn in txt:
                    score = 6.0
                elif vtoks and all(t in txt for t in vtoks):
                    score = 5.0
                elif vtoks and any(len(t) >= 5 and t in txt for t in vtoks):
                    score = 3.5
                if score > 0:
                    item = dict(p)
                    item.setdefault("similarity", 0.0)
                    item["fuzzy_score"] = max(float(item.get("fuzzy_score") or 0.0), score / 10.0)
                    item["hybrid_text_score"] = max(float(item.get("hybrid_text_score") or 0.0), score)
                    item["retrieval_sources"] = "lexical_family"
                    scored.append((score, len(product_name(item)), item))
                    seen.add(pid)
        scored.sort(key=lambda x: (-x[0], x[1], product_name(x[2]).lower()))
        return [p for _, __, p in scored[:limit]]

    def _textual_candidates(self, query: str, *, limit: int) -> List[Dict[str, Any]]:
        """Return product candidates from pg_trgm/ILIKE text search.

        This is retrieval only. It never decides the final product.
        """
        if not database.IS_POSTGRES or not self.schema_ready:
            return []
        q = re.sub(r"\s+", " ", str(query or "")).strip()
        if len(normalize_text(q)) < 3:
            return []
        pattern = f"%{q}%"
        threshold = float(os.getenv("PRICEBOT_TRIGRAM_SIMILARITY_THRESHOLD", "0.18") or 0.18)
        fetch_limit = max(int(limit or self.top_k) * 3, int(limit or self.top_k))
        try:
            with database.connect() as conn:
                cols = set(database.table_columns(conn, "products"))
                search_cols = [c for c in ["name", "normalized_name", "original_name", "brand", "product_family", "aliases"] if c in cols]
                if not search_cols:
                    return []
                score_expr = "GREATEST(" + ", ".join([f"similarity(COALESCE(CAST({c} AS TEXT), ''), %s)" for c in search_cols]) + ")"
                where_parts = []
                params: List[Any] = []
                # score expression params for SELECT
                params.extend([q] * len(search_cols))
                for c in search_cols:
                    where_parts.append(f"COALESCE(CAST({c} AS TEXT), '') ILIKE %s")
                    params.append(pattern)
                    where_parts.append(f"similarity(COALESCE(CAST({c} AS TEXT), ''), %s) >= %s")
                    params.extend([q, threshold])
                exact_boost = "CASE WHEN LOWER(COALESCE(CAST(name AS TEXT), '')) = LOWER(%s) THEN 2.0 WHEN LOWER(COALESCE(CAST(name AS TEXT), '')) LIKE LOWER(%s) THEN 1.0 ELSE 0.0 END"
                params.extend([q, f"{q}%", fetch_limit])
                sql = f"""
                    SELECT *, {score_expr} AS fuzzy_score,
                           ({score_expr} + {exact_boost}) AS hybrid_text_score
                    FROM products
                    WHERE ({' OR '.join(where_parts)})
                    ORDER BY hybrid_text_score DESC, LENGTH(COALESCE(CAST(name AS TEXT), '')) ASC
                    LIMIT %s
                """
                # score_expr appears twice: SELECT fuzzy_score and hybrid_text_score.
                # Params must include the second score_expr set before exact_boost.
                first_score_params = [q] * len(search_cols)
                where_params: List[Any] = []
                for c in search_cols:
                    where_params.append(pattern)
                    where_params.extend([q, threshold])
                final_params = tuple(first_score_params + first_score_params + [q, f"{q}%"] + where_params + [fetch_limit])
                rows = conn.execute(sql, final_params).fetchall()
        except Exception as exc:
            self.log("TEXTUAL_RETRIEVAL_ERROR", query=q[:120], error=repr(exc))
            return []
        out: List[Dict[str, Any]] = []
        for row in rows:
            product = dict(row)
            if not self._visible_product(product):
                continue
            try:
                product["fuzzy_score"] = float(product.get("fuzzy_score") or 0.0)
                product["hybrid_text_score"] = float(product.get("hybrid_text_score") or 0.0)
            except Exception:
                product["fuzzy_score"] = 0.0
                product["hybrid_text_score"] = 0.0
            product.setdefault("similarity", 0.0)
            product["retrieval_sources"] = "trigram"
            out.append(product)
            if len(out) >= limit:
                break
        return out

    def _merge_candidates(self, semantic: List[Dict[str, Any]], textual: List[Dict[str, Any]], *, limit: int) -> List[Dict[str, Any]]:
        merged: Dict[int, Dict[str, Any]] = {}
        ranks: Dict[int, float] = {}

        def add(product: Dict[str, Any], source: str, rank: int) -> None:
            pid = int(product.get("id") or 0)
            if not pid:
                return
            existing = merged.get(pid)
            if existing is None:
                item = dict(product)
                item["retrieval_sources"] = source
                merged[pid] = item
                ranks[pid] = 0.0
            else:
                item = existing
                sources = set(str(item.get("retrieval_sources") or "").split("+"))
                sources.add(source)
                item["retrieval_sources"] = "+".join(sorted(s for s in sources if s))
                item["similarity"] = max(float(item.get("similarity") or 0.0), float(product.get("similarity") or 0.0))
                item["fuzzy_score"] = max(float(item.get("fuzzy_score") or 0.0), float(product.get("fuzzy_score") or 0.0))
                item["hybrid_text_score"] = max(float(item.get("hybrid_text_score") or 0.0), float(product.get("hybrid_text_score") or 0.0))
            # Reciprocal rank fusion with small source boosts.
            ranks[pid] += 1.0 / (60.0 + float(rank))
            ranks[pid] += 0.20 * float(product.get("similarity") or 0.0)
            ranks[pid] += 0.16 * float(product.get("fuzzy_score") or 0.0)
            if source == "semantic":
                ranks[pid] += 0.03
            if source == "trigram":
                ranks[pid] += 0.03

        for i, p in enumerate(semantic, start=1):
            add(p, "semantic", i)
        for i, p in enumerate(textual, start=1):
            add(p, "trigram", i)

        out = list(merged.values())
        out.sort(key=lambda p: ranks.get(int(p.get("id") or 0), 0.0), reverse=True)
        for p in out:
            pid = int(p.get("id") or 0)
            p["hybrid_score"] = round(ranks.get(pid, 0.0), 6)
        return out[:limit]

    def _hybrid_candidates(self, query: str, embedding: List[float], *, limit: int) -> List[Dict[str, Any]]:
        semantic = self._semantic_candidates(embedding, limit=max(limit, self.top_k))
        lexical = self._lexical_family_candidates(query, limit=max(limit, self.top_k))
        textual: List[Dict[str, Any]] = []
        seen_textual: set[int] = set()
        for variant in self._query_variants(query):
            for p in self._textual_candidates(variant, limit=max(limit, self.top_k)):
                pid = int(p.get("id") or 0)
                if pid and pid not in seen_textual:
                    textual.append(p)
                    seen_textual.add(pid)
        merged = self._merge_candidates(lexical + textual, semantic, limit=limit)
        self.log(
            "HYBRID_RETRIEVED",
            query=str(query or "")[:120],
            variants=self._query_variants(query),
            semantic_count=len(semantic),
            lexical_count=len(lexical),
            textual_count=len(textual),
            merged_count=len(merged),
            top_product_id=int(merged[0].get("id") or 0) if merged else 0,
            top_sources=str(merged[0].get("retrieval_sources") or "") if merged else "",
            top_similarity=round(float(merged[0].get("similarity") or 0.0), 6) if merged else 0.0,
            top_fuzzy=round(float(merged[0].get("fuzzy_score") or 0.0), 6) if merged else 0.0,
        )
        return merged

    def _generic_or_ambiguous_query(self, query: str, product: Dict[str, Any], candidates: List[Dict[str, Any]]) -> bool:
        nquery = normalize_text(query or "")
        tokens = [t for t in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}|[\u0600-\u06FF]{3,}", str(query or ""))]
        generic = {
            "cream", "gel", "tabs", "tablet", "tablets", "capsule", "capsules", "syrup", "spray", "drop", "drops",
            "كريم", "جل", "حبوب", "شراب", "بخاخ", "قطرة", "مرطب", "مسكن", "غسول",
        }
        if not tokens or nquery in generic:
            return True
        # Single-token brand/family searches are often ambiguous when multiple candidates contain the same token.
        if len(tokens) <= 2:
            contains = 0
            for c in candidates[:6]:
                ctext = normalize_text(self._candidate_text(c))
                if nquery and nquery in ctext:
                    contains += 1
            if contains >= 2:
                return True
        return False

    def _candidate_payload(self, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for p in candidates[: self.verify_top_k]:
            out.append({
                "id": int(p.get("id") or 0),
                "name": product_name(p),
                "canonical_display_name": str(p.get("canonical_display_name") or ""),
                "original_name": str(p.get("original_name") or ""),
                "brand": str(p.get("brand") or ""),
                "product_family": str(p.get("product_family") or ""),
                "aliases": str(p.get("aliases") or ""),
                "active_ingredient": str(p.get("active_ingredient") or ""),
                "form": str(p.get("form") or p.get("medicine_form") or ""),
                "strength": str(p.get("strength") or ""),
                "size": str(p.get("size") or ""),
                "pack": str(p.get("pack") or ""),
                "similarity": round(float(p.get("similarity") or 0.0), 6),
                "fuzzy_score": round(float(p.get("fuzzy_score") or 0.0), 6),
                "hybrid_score": round(float(p.get("hybrid_score") or 0.0), 6),
                "retrieval_sources": str(p.get("retrieval_sources") or "semantic"),
            })
        return out

    def _parse_json_object(self, text: str) -> Dict[str, Any]:
        raw = str(text or "").strip()
        try:
            data = json.loads(raw)
            return data if isinstance(data, dict) else {}
        except Exception:
            pass
        match = re.search(r"\{.*\}", raw, flags=re.DOTALL)
        if not match:
            return {}
        try:
            data = json.loads(match.group(0))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    async def gemini_verify(self, query_text: str, candidates: List[Dict[str, Any]], *, source_context: str = "text") -> Dict[str, Any]:
        config_env.apply_openrouter_aliases()
        candidate_payload = self._candidate_payload(candidates)

        # V14 verification cache: same user query + same candidate IDs should not
        # re-call Gemini repeatedly. Cache failures are deliberately non-fatal.
        redis = None
        cache_key = ""
        try:
            pid_list = sorted(int(p.get("id") or 0) for p in candidates if int(p.get("id") or 0))
            cache_key = "gemini_verify:" + hashlib.md5(
                ("v15|" + str(source_context or "text") + "|" + str(query_text or "") + json.dumps(pid_list, separators=(",", ":"))).encode("utf-8")
            ).hexdigest()
            redis = await self._redis_client()
            if redis is not None:
                cached = await redis.get(cache_key)
                if cached:
                    data = json.loads(cached)
                    if isinstance(data, dict):
                        return data
        except Exception as exc:
            self.log("GEMINI_VERIFY_CACHE_READ_WARNING", error=repr(exc))
            redis = None

        async def cache_result(result: Dict[str, Any]) -> Dict[str, Any]:
            if redis is not None and cache_key and result:
                try:
                    await redis.set(cache_key, json.dumps(result, ensure_ascii=False, separators=(",", ":")), ex=900)
                except Exception as exc:
                    self.log("GEMINI_VERIFY_CACHE_WRITE_WARNING", error=repr(exc))
            return result

        api_key = config_env.resolve_openrouter_api_key()
        if not api_key:
            raise RuntimeError("OPENROUTER_API_KEY_missing_for_gemini_verification")
        system_prompt = (
            "You are PriceBot V15 Gemini Router, the final matching layer for a pharmacy price bot. "
            "You receive a customer query in Arabic, English, Arabizi or OCR text, plus AVAILABLE database candidates only. "
            "Return strict JSON only. No markdown. "
            "Actions: direct, list, unavailable. "
            "direct: only when the request uniquely identifies one exact product/variant/strength/size. Example: Panadol Advance -> Panadol Advance only. "
            "list: when the request is a brand/family/base name that has multiple variants/sizes/forms. Example: Panadol or باندول -> all Panadol candidates; La Roche or لاروش -> relevant La Roche candidates. "
            "unavailable: when no candidate is the requested product. Never choose a nearest random medicine, category alternative, background item, or ingredient-only guess. "
            "For image/OCR context be stricter: if visible text does not clearly identify the same product candidate, return unavailable. "
            "Understand common transliteration and misspellings such as اموكلان/amoclan, باندول/panadol, لاروش/la roche. "
            "Do not match by category words only: مسكن, حبوب, كريم, شراب, skin, cream, tablets, supplement. "
            "For list, include only IDs from the same requested brand/family/name; do not mix unrelated products. "
            "JSON schema exactly: {\"action\":\"direct|list|unavailable\",\"product_id\":number,\"product_ids\":[numbers],\"confidence\":number}. "
            "direct: product_id is selected and product_ids=[product_id]. list: product_id=0 and product_ids has 2 to 10 IDs. unavailable: product_id=0 and product_ids=[]."
        )
        user_payload = {
            "source_context": str(source_context or "text")[:40],
            "query": str(query_text or "")[:1000],
            "cleaned_query": self._clean_customer_query(query_text)[:500],
            "query_variants": self._query_variants(query_text),
            "candidates": candidate_payload,
        }
        payload = {
            "model": self.verification_model(),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False, separators=(",", ":"))},
            ],
            "temperature": 0,
            "max_tokens": 512,
            "response_format": {"type": "json_object"},
        }
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": os.getenv("OPENROUTER_SITE_URL", "https://pricebot.local"),
            "X-Title": os.getenv("OPENROUTER_APP_NAME", "PriceBot"),
        }
        base_url = (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/")
        timeout = float(os.getenv("PRICEBOT_GEMINI_VERIFY_TIMEOUT_SECONDS", "10") or 10)
        attempts = int(os.getenv("PRICEBOT_GEMINI_VERIFY_RETRY_ATTEMPTS", "2") or 2)
        delay = 0.3
        last_error = ""
        async with httpx.AsyncClient(timeout=timeout) as client:
            for attempt in range(1, attempts + 1):
                try:
                    response = await client.post(f"{base_url}/chat/completions", headers=headers, json=payload)
                    if response.status_code < 400:
                        content = response.json().get("choices", [{}])[0].get("message", {}).get("content", "")
                        data = self._parse_json_object(content)
                        valid_ids = {int(p.get("id") or 0) for p in candidates}
                        confidence = max(0.0, min(1.0, float(data.get("confidence") or 0.0)))
                        action = str(data.get("action") or "").strip().lower()
                        if not action:
                            action = "direct" if bool(data.get("match")) else "unavailable"
                        try:
                            pid = int(data.get("product_id") or 0)
                        except Exception:
                            pid = 0
                        raw_ids = data.get("product_ids") or ([] if not pid else [pid])
                        product_ids: List[int] = []
                        if isinstance(raw_ids, list):
                            for x in raw_ids:
                                try:
                                    xid = int(x)
                                except Exception:
                                    continue
                                if xid in valid_ids and xid not in product_ids:
                                    product_ids.append(xid)
                        if action == "direct":
                            if pid not in valid_ids and product_ids:
                                pid = product_ids[0]
                            if pid in valid_ids:
                                return await cache_result({"action": "direct", "match": True, "product_id": pid, "product_ids": [pid], "confidence": confidence})
                            return await cache_result({"action": "unavailable", "match": False, "product_id": 0, "product_ids": [], "confidence": confidence})
                        if action == "list":
                            if len(product_ids) >= 2:
                                return await cache_result({"action": "list", "match": True, "product_id": 0, "product_ids": product_ids[:10], "confidence": confidence})
                            return await cache_result({"action": "unavailable", "match": False, "product_id": 0, "product_ids": [], "confidence": confidence})
                        return await cache_result({"action": "unavailable", "match": False, "product_id": 0, "product_ids": [], "confidence": confidence})
                    last_error = f"status={response.status_code} body={response.text[:300]}"
                except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError, ValueError, KeyError) as exc:
                    last_error = repr(exc)
                if attempt < attempts:
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 3.0)
        raise RuntimeError(f"gemini_verification_failed:{last_error}")

    async def match(self, query_text: str, *, top_k: Optional[int] = None, source_context: str = "text") -> SemanticDecision:
        query = re.sub(r"\s+", " ", str(query_text or "")).strip()
        if not query:
            return SemanticDecision(action="unavailable", reason="empty_query", query_text=query)
        if looks_like_prescription(query):
            return SemanticDecision(action="unavailable", reason="prescription_like", query_text=query)
        if not self.schema_ready:
            await self.initialize(auto_index=False)
        if not self.schema_ready:
            self.log("SEMANTIC_MATCHER_UNAVAILABLE", reason=self.last_error or "schema_not_ready")
            return SemanticDecision(action="unavailable", reason="semantic_schema_not_ready", query_text=query)
        retrieval_query = self._clean_customer_query(query) or query
        try:
            query_embedding = await self.get_embedding(retrieval_query)
        except Exception as exc:
            self.last_error = repr(exc)
            self.log("SEMANTIC_EMBEDDING_ERROR", query=query[:120], error=repr(exc))
            return SemanticDecision(action="unavailable", reason="embedding_failed", query_text=query)

        if self.enable_memory_decisions:
            memory_decision = self._memory_lookup(query_embedding)
            if memory_decision:
                memory_decision.query_text = query
                self.log(
                    "SEMANTIC_MEMORY_HIT",
                    query=query[:120],
                    product_id=memory_decision.product_id,
                    similarity=round(memory_decision.similarity, 6),
                    action=memory_decision.action,
                )
                return memory_decision

        candidates = self._hybrid_candidates(query, query_embedding, limit=max(int(top_k or self.top_k), int(self.verify_top_k)))
        if not candidates:
            self.log("HYBRID_RETRIEVAL_EMPTY", query=query[:120])
            return SemanticDecision(action="unavailable", reason="no_hybrid_candidates", query_text=query)
        self.log(
            "SEMANTIC_RETRIEVED",
            query=query[:120],
            count=len(candidates),
            top_product_id=int(candidates[0].get("id") or 0),
            top_similarity=round(float(candidates[0].get("similarity") or 0.0), 6),
            top_fuzzy=round(float(candidates[0].get("fuzzy_score") or 0.0), 6),
            top_sources=str(candidates[0].get("retrieval_sources") or ""),
        )
        try:
            verified = await self.gemini_verify(query, candidates, source_context=source_context)
        except Exception as exc:
            self.last_error = repr(exc)
            self.log("GEMINI_VERIFY_ERROR", query=query[:120], error=repr(exc))
            return SemanticDecision(action="unavailable", reason="gemini_failed", query_text=query, candidates=candidates)

        action = str(verified.get("action") or ("direct" if verified.get("match") else "unavailable")).strip().lower()
        pid = int(verified.get("product_id") or 0)
        confidence = float(verified.get("confidence") or 0.0)
        id_order: List[int] = []
        for x in verified.get("product_ids") or ([] if not pid else [pid]):
            try:
                xid = int(x)
            except Exception:
                continue
            if xid and xid not in id_order:
                id_order.append(xid)
        by_id = {int(p.get("id") or 0): p for p in candidates if int(p.get("id") or 0)}
        product = by_id.get(pid) if pid else None
        selected = [by_id[x] for x in id_order if x in by_id]
        self.log(
            "GEMINI_ROUTED",
            query=query[:120],
            cleaned_query=retrieval_query[:120],
            source_context=source_context,
            action=action,
            product_id=pid,
            product_ids=id_order[:10],
            confidence=round(confidence, 6),
        )
        if action == "list" and len(selected) >= 2 and confidence >= self.confirm_confidence_threshold:
            return SemanticDecision(action="confirm", product=selected[0], product_id=int(selected[0].get("id") or 0), confidence=confidence, source="gemini_variant_list", query_text=query, candidates=selected[:10])
        if action == "direct" and product and confidence >= self.direct_confidence_threshold and not self._generic_or_ambiguous_query(retrieval_query, product, selected or candidates):
            return SemanticDecision(action="direct", product=product, product_id=pid, confidence=confidence, source="gemini_direct_exact", query_text=query, candidates=[product])
        if action == "direct" and product and confidence >= self.confirm_confidence_threshold:
            return SemanticDecision(action="confirm", product=product, product_id=pid, confidence=confidence, source="gemini_direct_confirm", query_text=query, candidates=[product])
        return SemanticDecision(action="unavailable", reason="gemini_unavailable_or_low_confidence", confidence=confidence, query_text=query, candidates=[])

    async def remember_confirmation(self, query_text: str, product_id: int, confidence: float = 1.0) -> Dict[str, Any]:
        query = re.sub(r"\s+", " ", str(query_text or "")).strip()
        if not query or not int(product_id or 0):
            return {"ok": False, "reason": "missing_query_or_product"}
        if not self.schema_ready:
            await self.initialize(auto_index=False)
        if not self.schema_ready:
            return {"ok": False, "reason": self.last_error or "schema_not_ready"}
        embedding = await self.get_embedding(query)
        vector = self._vector_literal(embedding)
        with database.connect() as conn:
            conn.execute(
                """
                INSERT INTO semantic_memory(query_text, query_embedding, product_id, confidence_score, confirmed_at)
                VALUES(%s, %s::vector, %s, %s, CURRENT_TIMESTAMP)
                """,
                (query[:1000], vector, int(product_id), float(confidence or 1.0)),
            )
        self.log("SEMANTIC_MEMORY_SAVED", query=query[:120], product_id=int(product_id), confidence=round(float(confidence or 1.0), 6))
        return {"ok": True, "product_id": int(product_id)}

    def health(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "matcher": MATCHER_NAME,
            "schema_ready": bool(self.schema_ready),
            "postgres_required": True,
            "database_is_postgres": bool(database.IS_POSTGRES),
            "embedding_dim": self.embedding_dim,
            "embedding_provider": self._provider_config().get("provider"),
            "embedding_model": self._provider_config().get("model"),
            "embedding_configured": self.embeddings_configured(),
            "verification_model": self.verification_model(),
            "memory_direct_threshold": self.memory_direct_threshold,
            "memory_confirm_threshold": self.memory_confirm_threshold,
            "memory_decisions_enabled": self.enable_memory_decisions,
            "gemini_router": "v15",
            "gemini_direct_confidence": self.direct_confidence_threshold,
            "gemini_confirm_confidence": self.confirm_confidence_threshold,
            "last_error": self.last_error,
            "last_indexed_count": self.last_indexed_count,
            "index_age_seconds": round(self.age_seconds, 2),
        }
        if database.IS_POSTGRES and self.schema_ready:
            try:
                with database.connect() as conn:
                    total = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
                    indexed = conn.execute("SELECT COUNT(*) FROM products WHERE embedding IS NOT NULL").fetchone()[0]
                    memory = conn.execute("SELECT COUNT(*) FROM semantic_memory").fetchone()[0]
                data.update({"products_count": int(total), "embedded_products": int(indexed), "semantic_memory_count": int(memory)})
            except Exception as exc:
                data["health_count_error"] = repr(exc)
        return data
