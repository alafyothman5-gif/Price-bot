from __future__ import annotations

"""Operational observability helpers for PriceBot.

These tables are append-only diagnostics. They never decide product price,
availability, or matching outcome. They are safe to create on an existing DB.
"""

import hashlib
import json
import os
import time
from typing import Any, Dict, List, Optional

import database
from normalizer import normalize_text

FAILED_DECISIONS = {"NOT_AVAILABLE", "LOW_CONFIDENCE", "IMAGE_UNCLEAR", "VISION_FAILED"}
IMAGE_FAILED_DECISIONS = {"NOT_AVAILABLE", "LOW_CONFIDENCE", "IMAGE_UNCLEAR", "VISION_FAILED"}


def _json(value: Any) -> str:
    try:
        return json.dumps(value if value is not None else {}, ensure_ascii=False, default=str)
    except Exception:
        return "{}"


def _loads(value: Any, fallback: Any = None) -> Any:
    if value is None:
        return fallback
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value or ""))
    except Exception:
        return fallback


def _phone_hash(phone: str) -> str:
    raw = "".join(ch for ch in str(phone or "") if ch.isdigit())
    if not raw:
        return ""
    salt = os.getenv("PRICEBOT_OBSERVABILITY_SALT") or os.getenv("PRICEBOT_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD") or "pricebot"
    digest = hashlib.sha256((salt + ":" + raw).encode("utf-8")).hexdigest()
    return f"{raw[:4]}****{raw[-3:]}:{digest[:10]}"


def ensure_schema() -> None:
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        if database.table_exists(conn, "products"):
            database.add_column(conn, "products", "canonical_display_name", "TEXT DEFAULT ''")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS product_query_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                merchant_id INTEGER DEFAULT 1,
                customer_hash TEXT DEFAULT '',
                original_text TEXT DEFAULT '',
                cleaned_text TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matcher_decision TEXT DEFAULT '',
                matched_product_id INTEGER,
                matched_product_name TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                diagnostics_json TEXT DEFAULT '{}',
                response_ms INTEGER DEFAULT 0,
                status TEXT DEFAULT 'open'
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_query_log_decision ON product_query_log(matcher_decision, created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_query_log_status ON product_query_log(status, created_at)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS image_debug_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                merchant_id INTEGER DEFAULT 1,
                customer_hash TEXT DEFAULT '',
                media_id TEXT DEFAULT '',
                image_hash TEXT DEFAULT '',
                image_phash TEXT DEFAULT '',
                vision_provider TEXT DEFAULT '',
                raw_vision_response TEXT DEFAULT '',
                visible_text TEXT DEFAULT '',
                cleaned_ocr TEXT DEFAULT '',
                candidate_queries TEXT DEFAULT '[]',
                selected_candidate TEXT DEFAULT '',
                matcher_decision TEXT DEFAULT '',
                matched_product_id INTEGER,
                matched_product_name TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                status TEXT DEFAULT 'open'
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_image_debug_log_decision ON image_debug_log(matcher_decision, created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_image_debug_log_status ON image_debug_log(status, created_at)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS response_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                merchant_id INTEGER DEFAULT 1,
                channel TEXT DEFAULT 'whatsapp',
                message_type TEXT DEFAULT 'text',
                decision TEXT DEFAULT '',
                response_ms INTEGER DEFAULT 0,
                vision_call INTEGER DEFAULT 0,
                product_db_id INTEGER
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_response_metrics_created ON response_metrics(created_at)")


def record_text_match(phone: str, original_text: str, result: Any, *, response_ms: int = 0, merchant_id: int = 1) -> None:
    try:
        ensure_schema()
        decision = str(getattr(result, "status", "") or "")
        product = getattr(result, "product", None) or {}
        matched_id = int(product.get("id") or 0) if product else None
        matched_name = str(product.get("canonical_display_name") or product.get("name") or "") if product else ""
        diagnostics = getattr(result, "diagnostics", None) or {}
        reason = str(diagnostics.get("stage") or diagnostics.get("reason") or diagnostics.get("vision_stage") or decision)
        cleaned = normalize_text(original_text)
        with database.connect() as conn:
            conn.execute(
                """
                INSERT INTO product_query_log(
                    merchant_id, customer_hash, original_text, cleaned_text, extracted_slots,
                    matcher_decision, matched_product_id, matched_product_name, reason,
                    diagnostics_json, response_ms, status
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    int(merchant_id or 1), _phone_hash(phone), str(original_text or "")[:800], cleaned[:800],
                    _json(diagnostics.get("slots") or diagnostics.get("query_slots") or {}), decision,
                    matched_id, matched_name[:300], reason[:500], _json(diagnostics)[:4000], int(response_ms or 0),
                    "open" if decision in FAILED_DECISIONS else "ok",
                ),
            )
            conn.execute(
                "INSERT INTO response_metrics(merchant_id, message_type, decision, response_ms, vision_call, product_db_id) VALUES(?,?,?,?,0,?)",
                (int(merchant_id or 1), "text", decision, int(response_ms or 0), matched_id),
            )
    except Exception:
        pass


def record_image_debug(
    *,
    phone: str = "",
    media_id: str = "",
    image_hash: str = "",
    image_phash: str = "",
    extracted: Optional[Dict[str, Any]] = None,
    result: Any = None,
    decision: str = "",
    reason: str = "",
    response_ms: int = 0,
    vision_call: bool = True,
    merchant_id: int = 1,
) -> None:
    try:
        ensure_schema()
        extracted = extracted or {}
        diagnostics = getattr(result, "diagnostics", None) if result is not None else {}
        diagnostics = diagnostics or {}
        decision = decision or str(getattr(result, "status", "") or extracted.get("status") or "")
        product = getattr(result, "product", None) if result is not None else None
        product = product or {}
        matched_id = int(product.get("id") or 0) if product else None
        matched_name = str(product.get("canonical_display_name") or product.get("name") or "") if product else ""
        visible = " ".join(str(extracted.get(k) or "") for k in ["visible_text", "raw_vision_text", "main_visible_product", "product_name"] if extracted.get(k)).strip()
        cleaned = normalize_text(str(extracted.get("query") or visible or ""))
        candidate_queries = diagnostics.get("vision_candidates") or extracted.get("candidate_queries") or []
        selected_candidate = diagnostics.get("vision_query") or extracted.get("query") or ""
        reason = reason or str(diagnostics.get("vision_stage") or diagnostics.get("stage") or decision)
        with database.connect() as conn:
            conn.execute(
                """
                INSERT INTO image_debug_log(
                    merchant_id, customer_hash, media_id, image_hash, image_phash, vision_provider,
                    raw_vision_response, visible_text, cleaned_ocr, candidate_queries, selected_candidate,
                    matcher_decision, matched_product_id, matched_product_name, reason, status
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    int(merchant_id or 1), _phone_hash(phone), str(media_id or "")[:200], str(image_hash or "")[:128], str(image_phash or "")[:128],
                    os.getenv("OPENROUTER_MODEL", "OpenRouter")[:120], _json(extracted)[:8000], visible[:1500], cleaned[:1500],
                    _json(candidate_queries)[:5000], str(selected_candidate or "")[:500], decision, matched_id, matched_name[:300], reason[:500],
                    "open" if decision in IMAGE_FAILED_DECISIONS else "ok",
                ),
            )
            conn.execute(
                "INSERT INTO response_metrics(merchant_id, message_type, decision, response_ms, vision_call, product_db_id) VALUES(?,?,?,?,?,?)",
                (int(merchant_id or 1), "image", decision, int(response_ms or 0), 1 if vision_call else 0, matched_id),
            )
    except Exception:
        pass


def _rows(sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
    ensure_schema()
    with database.connect() as conn:
        return [database.dict_row(r) or {} for r in conn.execute(sql, params).fetchall()]


def list_failed_searches(limit: int = 200) -> List[Dict[str, Any]]:
    return _rows(
        """
        SELECT * FROM product_query_log
        WHERE matcher_decision IN ('NOT_AVAILABLE','LOW_CONFIDENCE','IMAGE_UNCLEAR') OR status='open'
        ORDER BY id DESC LIMIT ?
        """,
        (int(limit),),
    )


def list_image_debug(limit: int = 50) -> List[Dict[str, Any]]:
    rows = _rows("SELECT * FROM image_debug_log ORDER BY id DESC LIMIT ?", (int(limit),))
    for row in rows:
        row["candidate_queries_list"] = _loads(row.get("candidate_queries"), []) or []
    return rows


def update_failed_search_status(log_id: int, status: str = "ignored") -> None:
    ensure_schema()
    with database.connect() as conn:
        conn.execute("UPDATE product_query_log SET status=? WHERE id=?", (status, int(log_id)))


def update_image_debug_status(log_id: int, status: str = "ignored") -> None:
    ensure_schema()
    with database.connect() as conn:
        conn.execute("UPDATE image_debug_log SET status=? WHERE id=?", (status, int(log_id)))


def add_alias_from_failed_search(log_id: int, product_id: int, field: str = "aliases") -> None:
    ensure_schema()
    field = "ocr_keywords" if field == "ocr_keywords" else "aliases"
    with database.connect() as conn:
        row = database.dict_row(conn.execute("SELECT * FROM product_query_log WHERE id=?", (int(log_id),)).fetchone()) or {}
    value = str(row.get("original_text") or row.get("cleaned_text") or "").strip()
    if not value:
        raise ValueError("empty_alias")
    database.append_product_alias_or_ocr(int(product_id), value, field=field)
    update_failed_search_status(int(log_id), "linked")


def link_image_debug_to_product(log_id: int, product_id: int, field: str = "ocr_keywords") -> None:
    ensure_schema()
    with database.connect() as conn:
        row = database.dict_row(conn.execute("SELECT * FROM image_debug_log WHERE id=?", (int(log_id),)).fetchone()) or {}
    value = str(row.get("cleaned_ocr") or row.get("selected_candidate") or row.get("visible_text") or "").strip()
    if not value:
        raise ValueError("empty_ocr_keyword")
    database.append_product_alias_or_ocr(int(product_id), value, field="ocr_keywords" if field != "aliases" else "aliases")
    update_image_debug_status(int(log_id), "linked")


def dashboard_metrics() -> Dict[str, Any]:
    ensure_schema()
    now_window = "datetime('now','-1 day')"
    with database.connect() as conn:
        def one(sql: str, params: tuple = ()) -> int:
            row = conn.execute(sql, params).fetchone()
            try:
                return int(row[0] if row else 0)
            except Exception:
                return 0
        messages_today = one(f"SELECT COUNT(*) FROM response_metrics WHERE created_at >= {now_window}")
        images_today = one(f"SELECT COUNT(*) FROM response_metrics WHERE message_type='image' AND created_at >= {now_window}")
        image_success = one(f"SELECT COUNT(*) FROM response_metrics WHERE message_type='image' AND decision='EXACT_MATCH' AND created_at >= {now_window}")
        image_failed = one(f"SELECT COUNT(*) FROM response_metrics WHERE message_type='image' AND decision IN ('NOT_AVAILABLE','LOW_CONFIDENCE','IMAGE_UNCLEAR','VISION_FAILED') AND created_at >= {now_window}")
        vision_calls = one(f"SELECT COUNT(*) FROM response_metrics WHERE vision_call=1 AND created_at >= {now_window}")
        avg_ms_row = conn.execute(f"SELECT AVG(response_ms) FROM response_metrics WHERE response_ms > 0 AND created_at >= {now_window}").fetchone()
        avg_ms = int(avg_ms_row[0] or 0) if avg_ms_row and avg_ms_row[0] is not None else 0
        top_products = [database.dict_row(r) or {} for r in conn.execute(
            """
            SELECT matched_product_name AS name, COUNT(*) AS n
            FROM product_query_log
            WHERE matched_product_id IS NOT NULL AND matched_product_id>0
            GROUP BY matched_product_id, matched_product_name
            ORDER BY n DESC LIMIT 10
            """
        ).fetchall()]
        top_failed = [database.dict_row(r) or {} for r in conn.execute(
            """
            SELECT cleaned_text AS name, COUNT(*) AS n
            FROM product_query_log
            WHERE matcher_decision IN ('NOT_AVAILABLE','LOW_CONFIDENCE','IMAGE_UNCLEAR')
            GROUP BY cleaned_text ORDER BY n DESC LIMIT 10
            """
        ).fetchall()]
        top_failed_images = [database.dict_row(r) or {} for r in conn.execute(
            """
            SELECT cleaned_ocr AS name, COUNT(*) AS n
            FROM image_debug_log
            WHERE matcher_decision IN ('NOT_AVAILABLE','LOW_CONFIDENCE','IMAGE_UNCLEAR','VISION_FAILED')
            GROUP BY cleaned_ocr ORDER BY n DESC LIMIT 10
            """
        ).fetchall()]
        orders_today = one(f"SELECT COUNT(*) FROM orders WHERE created_at >= {now_window}") if database.table_exists(conn, "orders") else 0
    success_rate = round((image_success / images_today) * 100, 1) if images_today else 0
    fail_rate = round((image_failed / images_today) * 100, 1) if images_today else 0
    # Cost cannot be exact without provider pricing in env. Keep it explicit and non-authoritative.
    estimated_cost = "غير مضبوط" if not os.getenv("PRICEBOT_VISION_COST_PER_CALL") else round(vision_calls * float(os.getenv("PRICEBOT_VISION_COST_PER_CALL") or 0), 4)
    return {
        "messages_today": messages_today,
        "images_today": images_today,
        "image_success_rate": success_rate,
        "image_fail_rate": fail_rate,
        "vision_calls_today": vision_calls,
        "vision_estimated_cost": estimated_cost,
        "avg_response_ms": avg_ms,
        "orders_today": orders_today,
        "top_products": top_products,
        "top_failed": top_failed,
        "top_failed_images": top_failed_images,
    }
