from __future__ import annotations

"""Safe image cache for successful image-to-product matches.

Only successful EXACT_MATCH rows are reused.  Failed/uncertain vision results are
kept in Image Debug, not as long-lived cache decisions.
"""

import hashlib
from io import BytesIO
from typing import Any, Dict, Optional

from PIL import Image

import database


def ensure_schema() -> None:
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if database.table_exists(conn, table):
                database.add_column(conn, table, "image_phash", "TEXT DEFAULT ''")
                conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_phash ON {table}(image_phash, decision)")


def sha256_hash(image_bytes: bytes) -> str:
    return hashlib.sha256(image_bytes or b"").hexdigest() if image_bytes else ""


def average_hash(image_bytes: bytes, hash_size: int = 8) -> str:
    if not image_bytes:
        return ""
    try:
        img = Image.open(BytesIO(image_bytes)).convert("L").resize((hash_size, hash_size))
        pixels = list(img.getdata())
        avg = sum(pixels) / len(pixels)
        bits = "".join("1" if p >= avg else "0" for p in pixels)
        return f"{int(bits, 2):0{hash_size * hash_size // 4}x}"
    except Exception:
        return ""


def _hamming_hex(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except Exception:
        return 999


def _usable_success(row: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not row:
        return None
    if str(row.get("decision") or "") != "EXACT_MATCH":
        return None
    if not row.get("matched_product_id"):
        return None
    product = database.get_product(int(row.get("matched_product_id")))
    if product and database.product_visible(product, guided=False):
        row = dict(row)
        row["product"] = product
        return row
    return None


def lookup_success(image_hash: str = "", media_id: str = "", image_phash: str = "", max_hamming_distance: int = 5) -> Optional[Dict[str, Any]]:
    ensure_schema()
    exact = _usable_success(database.get_image_cache(image_hash=image_hash, media_id=media_id))
    if exact:
        exact["cache_hit_type"] = "exact"
        return exact
    if not image_phash:
        return None
    with database.connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if not database.table_exists(conn, table):
                continue
            rows = [database.dict_row(r) or {} for r in conn.execute(
                f"""
                SELECT * FROM {table}
                WHERE decision='EXACT_MATCH' AND matched_product_id IS NOT NULL AND image_phash <> ''
                ORDER BY updated_at DESC LIMIT 250
                """
            ).fetchall()]
            best = None
            best_dist = 999
            for row in rows:
                dist = _hamming_hex(image_phash, str(row.get("image_phash") or ""))
                if dist < best_dist:
                    best, best_dist = row, dist
            if best is not None and best_dist <= int(max_hamming_distance):
                usable = _usable_success(best)
                if usable:
                    usable["cache_hit_type"] = f"near_hash:{best_dist}"
                    return usable
    return None


def save_success(image_hash: str, media_id: str, image_phash: str, extracted_slots: Dict[str, Any], matched_product_id: int, confidence: str = "") -> None:
    if not image_hash or not matched_product_id:
        return
    ensure_schema()
    database.set_image_cache(image_hash, media_id, extracted_slots or {}, int(matched_product_id), "EXACT_MATCH", confidence or "")
    with database.connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if database.table_exists(conn, table):
                conn.execute("UPDATE " + table + " SET image_phash=?, updated_at=datetime('now') WHERE image_hash=?", (image_phash or "", image_hash))
