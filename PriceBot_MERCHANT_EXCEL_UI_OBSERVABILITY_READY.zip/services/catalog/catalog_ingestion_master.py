from __future__ import annotations

"""Final Catalog Ingestion workflow for weekly merchant Excel uploads.

Production rule: weekly Excel files are price lists, not the master catalog.
The upload pipeline writes raw rows to staging/review tables first, then updates
only already-known products after explicit approval.  New, ambiguous, dangerous
or conflicting rows stay in review and never enter sellable search silently.
"""

import json
import os
import re
import shutil
import sqlite3
import tempfile
import time
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import database
from normalizer import compact_normalize, normalize_text, safe_price, split_multi, truthy
try:
    from dynamic_synonyms import apply_synonyms as _apply_dynamic_synonyms
except Exception:  # pragma: no cover
    _apply_dynamic_synonyms = None
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths, normalize_measure
from services.catalog.excel_native_importer import detect_columns, find_header_row, read_matrix

DECISION_UPDATE_PRICE = "UPDATE_PRICE"
DECISION_NEW_PRODUCT_READY = "NEW_PRODUCT_READY"
DECISION_EXACT_DUPLICATE_MERGED = "EXACT_DUPLICATE_MERGED"
DECISION_NEEDS_REVIEW = "NEEDS_REVIEW"
DECISION_AMBIGUOUS_VARIANT = "AMBIGUOUS_VARIANT"
DECISION_PRICE_CONFLICT = "PRICE_CONFLICT"
DECISION_DANGEROUS_MATCH_REJECTED = "DANGEROUS_MATCH_REJECTED"
DECISION_MISSING_FROM_UPLOAD = "MISSING_FROM_UPLOAD"
WARNING_DUPLICATE_PRICE_LAST_VALUE_USED = "DUPLICATE_PRICE_LAST_VALUE_USED"
METRIC_PRICES_UNCHANGED = "PRICES_UNCHANGED"
METRIC_MISSING_REPORT_ONLY = "MISSING_FROM_UPLOAD_REPORT_ONLY"

BLOCKING_DECISIONS = {
    DECISION_NEEDS_REVIEW,
    DECISION_AMBIGUOUS_VARIANT,
    DECISION_PRICE_CONFLICT,
    DECISION_DANGEROUS_MATCH_REJECTED,
}

SPELLING_CORRECTIONS = {
    "petroleeum": "petroleum",
    "petrolleum": "petroleum",
    "petrolium": "petroleum",
    "moisturising": "moisturizing",
    "moisturiser": "moisturizer",
    "moisturising": "moisturizing",
    "cera ve": "cerave",
    "cera-ve": "cerave",
    "la roche": "laroche",
    "la-roche": "laroche",
    "la roche posay": "la roche-posay",
    "la roche-posay": "la roche-posay",
}

NON_BRAND_WORDS = {
    "white", "black", "red", "blue", "green", "yellow", "cream", "gel", "jelly", "petroleum",
    "lotion", "serum", "cleanser", "wash", "soap", "ointment", "shampoo", "conditioner", "spray",
    "tablet", "tablets", "capsule", "capsules", "syrup", "suspension", "drops", "injection",
    "mg", "mcg", "ml", "g", "iu", "skin", "face", "body", "baby", "adult", "kids",
    "ابيض", "اسود", "كريم", "جل", "مرهم", "لوشن", "غسول", "شامبو", "شراب", "حبوب", "كبسول",
}

KNOWN_BRANDS_SEED = {
    "cerave", "vichy", "laroche", "la roche-posay", "larocheposay", "bioderma", "uriage", "eucerin",
    "rilastil", "mebo", "panadol", "flagyl", "amoclan", "gaviscon", "daktarin", "dexeryl",
    "hemazym", "propoli", "ovanice", "uriage", "photoblok", "mari", "normaderm",
}

CATEGORY_MEDICINE_FORMS = {"tablet", "capsule", "syrup", "suspension", "drops", "injection", "suppository", "sachet", "solution"}
CATEGORY_COSMETIC_TYPES = {"cleanser", "cream", "ointment", "gel", "lotion", "serum", "moisturizer", "sunscreen", "shampoo", "conditioner", "spray", "oil", "mask", "toner"}


def catalog_normalize(value: object) -> str:
    text = str(value or "")
    for src, dst in sorted(SPELLING_CORRECTIONS.items(), key=lambda x: -len(x[0])):
        text = re.sub(rf"\b{re.escape(src)}\b", dst, text, flags=re.I)
    text = normalize_text(text)
    if _apply_dynamic_synonyms is not None:
        try:
            text = _apply_dynamic_synonyms(text)
        except Exception:
            pass
    text = re.sub(r"\b(\d+)\s*(m\s*l|ml)\b", r"\1ml", text)
    text = re.sub(r"\b(\d+)\s*(m\s*g|mg)\b", r"\1mg", text)
    text = re.sub(r"\b(\d+)\s*(i\s*u|iu)\b", r"\1iu", text)
    text = re.sub(r"\b(\d+)\s*(g)\b", r"\1g", text)
    return re.sub(r"\s+", " ", text).strip()


def catalog_compact(value: object) -> str:
    return catalog_normalize(value).replace(" ", "")


def canonical_display_name(value: object) -> str:
    """Customer-facing product name after safe spelling/measure normalization.

    The raw Excel name remains in original_name/audit tables; customer messages
    should prefer this canonical display to avoid showing obvious upload typos
    such as PETROLEEUM after correction.
    """
    text = catalog_normalize(value)
    return text.upper() if str(value or "").strip().isupper() else text


def _barcode(value: object) -> str:
    text = re.sub(r"\D+", "", str(value or ""))
    return text if 8 <= len(text) <= 14 else ""


def _price(value: object) -> str:
    return safe_price(value)


def _is_same_price(a: object, b: object) -> bool:
    return _price(a) == _price(b)


def _ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def ensure_schema() -> None:
    """Create all ingestion tables idempotently.  No products are deleted."""
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        database.add_column(conn, "products", "canonical_display_name", "TEXT DEFAULT ''")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_aliases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                alias TEXT NOT NULL,
                normalized_alias TEXT NOT NULL,
                source TEXT DEFAULT 'manual',
                approved INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id, normalized_alias)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_norm ON product_aliases(normalized_alias, approved)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_ocr_keywords (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                keyword TEXT NOT NULL,
                normalized_keyword TEXT NOT NULL,
                source TEXT DEFAULT 'manual',
                approved INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id, normalized_keyword)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_ocr_norm ON product_ocr_keywords(normalized_keyword, approved)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS merchant_inventory (
                merchant_id INTEGER NOT NULL DEFAULT 1,
                product_db_id INTEGER NOT NULL,
                price TEXT DEFAULT '',
                available INTEGER DEFAULT 1,
                missing_from_upload INTEGER DEFAULT 0,
                last_upload_job_id INTEGER,
                last_seen_at TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(merchant_id, product_db_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_merchant_inventory_avail ON merchant_inventory(merchant_id, available, missing_from_upload)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_upload_jobs (
                id INTEGER PRIMARY KEY,
                legacy_job_id INTEGER,
                merchant_id INTEGER DEFAULT 1,
                filename TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                status TEXT DEFAULT 'uploaded',
                detected_name_column TEXT DEFAULT '',
                detected_price_column TEXT DEFAULT '',
                rows_raw INTEGER DEFAULT 0,
                rows_staged INTEGER DEFAULT 0,
                updated_prices INTEGER DEFAULT 0,
                prices_unchanged INTEGER DEFAULT 0,
                new_products INTEGER DEFAULT 0,
                duplicates_merged INTEGER DEFAULT 0,
                duplicate_price_last_value_used INTEGER DEFAULT 0,
                need_review INTEGER DEFAULT 0,
                missing_report_only INTEGER DEFAULT 0,
                missing_marked_unavailable INTEGER DEFAULT 0,
                price_conflicts INTEGER DEFAULT 0,
                dangerous_rejected INTEGER DEFAULT 0,
                report_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                approved_at TEXT,
                approved_by TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_upload_jobs_status ON catalog_upload_jobs(status, created_at)")
        for col, ddl in {
            "prices_unchanged": "INTEGER DEFAULT 0",
            "duplicate_price_last_value_used": "INTEGER DEFAULT 0",
            "missing_report_only": "INTEGER DEFAULT 0",
        }.items():
            database.add_column(conn, "catalog_upload_jobs", col, ddl)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_staging_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER NOT NULL,
                merchant_id INTEGER DEFAULT 1,
                row_number INTEGER DEFAULT 0,
                raw_name TEXT DEFAULT '',
                raw_price TEXT DEFAULT '',
                raw_barcode TEXT DEFAULT '',
                raw_json TEXT DEFAULT '{}',
                normalized_name TEXT DEFAULT '',
                compact_name TEXT DEFAULT '',
                spelling_corrected_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                category TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                identity_key TEXT DEFAULT '',
                matched_product_db_id INTEGER,
                matched_by TEXT DEFAULT '',
                decision TEXT DEFAULT '',
                decision_reason TEXT DEFAULT '',
                duplicate_of_staging_id INTEGER,
                status TEXT DEFAULT 'staged',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_staging_job ON catalog_staging_items(job_id, decision, status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_staging_identity ON catalog_staging_items(identity_key, normalized_name)")

        # Existing versions already have catalog_review_items.  Add required columns safely.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_review_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                merchant_id INTEGER DEFAULT 1,
                issue_type TEXT DEFAULT '',
                severity TEXT DEFAULT 'review',
                row_json TEXT DEFAULT '{}',
                duplicate_key TEXT DEFAULT '',
                price_old TEXT DEFAULT '',
                price_new TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        for col, ddl in {
            "staging_item_id": "INTEGER",
            "matched_product_db_id": "INTEGER",
            "raw_name": "TEXT DEFAULT ''",
            "normalized_name": "TEXT DEFAULT ''",
            "suggested_brand": "TEXT DEFAULT ''",
            "suggested_family": "TEXT DEFAULT ''",
            "suggested_category": "TEXT DEFAULT ''",
            "suggested_form": "TEXT DEFAULT ''",
            "suggested_strength": "TEXT DEFAULT ''",
            "suggested_size": "TEXT DEFAULT ''",
            "suggested_pack": "TEXT DEFAULT ''",
            "suggested_aliases": "TEXT DEFAULT ''",
            "review_notes": "TEXT DEFAULT ''",
            "reviewed_by": "TEXT DEFAULT ''",
            "reviewed_at": "TEXT",
        }.items():
            database.add_column(conn, "catalog_review_items", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_review_pending ON catalog_review_items(job_id, status, severity)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_merge_map (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_product_db_id INTEGER,
                target_product_db_id INTEGER,
                staging_item_id INTEGER,
                job_id INTEGER,
                reason TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(source_product_db_id, target_product_db_id, job_id)
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                event TEXT NOT NULL,
                actor TEXT DEFAULT '',
                details_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_audit_job ON catalog_audit_log(job_id, event, created_at)")


def _audit(job_id: int, event: str, actor: str = "system", details: Any = None) -> None:
    try:
        with database.connect() as conn:
            conn.execute(
                "INSERT INTO catalog_audit_log(job_id, event, actor, details_json) VALUES(?,?,?,?)",
                (int(job_id), event, actor, json.dumps(details or {}, ensure_ascii=False, default=str)),
            )
    except Exception:
        pass


def _audit_conn(conn, job_id: int, event: str, actor: str = "system", details: Any = None) -> None:
    conn.execute(
        "INSERT INTO catalog_audit_log(job_id, event, actor, details_json) VALUES(?,?,?,?)",
        (int(job_id), event, actor, json.dumps(details or {}, ensure_ascii=False, default=str)),
    )


def _known_brands_from_db(conn) -> set[str]:
    brands = set(KNOWN_BRANDS_SEED)
    if database.table_exists(conn, "products"):
        for r in conn.execute("SELECT DISTINCT brand FROM products WHERE brand IS NOT NULL AND brand<>'' LIMIT 10000").fetchall():
            b = catalog_normalize(r[0])
            if b and b not in NON_BRAND_WORDS:
                brands.add(b)
        # Add first token only for known proper brand fields/product families, not generic words.
        for r in conn.execute("SELECT name, product_family FROM products LIMIT 20000").fetchall():
            name = catalog_normalize(r[0])
            fam = catalog_normalize(r[1])
            if fam and fam.split()[0] not in NON_BRAND_WORDS:
                brands.add(fam.split()[0])
            toks = name.split()
            if toks and toks[0] not in NON_BRAND_WORDS and len(toks[0]) > 2:
                # Add cautiously: only if it appears across multiple products or is seeded later by brand field.
                pass
    return brands


def _extract_slots(name: str, known_brands: Iterable[str]) -> Dict[str, str]:
    n = catalog_normalize(name)
    toks = n.split()
    known = sorted({catalog_normalize(b) for b in known_brands if catalog_normalize(b)}, key=len, reverse=True)
    brand = ""
    for b in known:
        if b in NON_BRAND_WORDS:
            continue
        if n == b or n.startswith(b + " "):
            brand = b
            break
    form = canonical_form(n)
    strengths = extract_strengths(n)
    sizes = extract_sizes(n)
    packs = extract_packs(n)
    category = "cosmetic" if form in CATEGORY_COSMETIC_TYPES else ""
    if form in CATEGORY_MEDICINE_FORMS:
        category = "medicine"
    identity_toks = []
    for t in toks:
        if t == brand or t in NON_BRAND_WORDS:
            continue
        if t in {"mg", "ml", "g", "iu"}:
            continue
        if re.fullmatch(r"\d+", t):
            continue
        identity_toks.append(t)
    family = " ".join(identity_toks[:5])
    return {
        "brand": brand,
        "product_family": family,
        "category": category,
        "form": form,
        "strength": strengths[0] if strengths else "",
        "size": sizes[0] if sizes else "",
        "pack": packs[0] if packs else "",
        "barcode": _barcode(name),
    }


def _identity_key(slots: Dict[str, Any]) -> str:
    parts = [
        catalog_normalize(slots.get("brand")),
        catalog_normalize(slots.get("product_family") or slots.get("normalized_name") or slots.get("name")),
        catalog_normalize(slots.get("category")),
        catalog_normalize(slots.get("form")),
        normalize_measure(slots.get("strength")),
        normalize_measure(slots.get("size")),
        normalize_measure(slots.get("pack")),
    ]
    return "|".join(parts)


def _excel_rows(path: str) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    matrix = read_matrix(path)
    if not matrix:
        raise RuntimeError("EXCEL_EMPTY")
    header_idx, headers = find_header_row(matrix)
    mapping = detect_columns(matrix, header_idx, headers)
    if "name" not in mapping or not ("box_price" in mapping or "strip_price" in mapping):
        raise RuntimeError(f"CANNOT_DETECT_NAME_PRICE_COLUMNS mapping={mapping} headers={headers[:20]}")
    name_idx = mapping["name"]
    price_idx = mapping.get("box_price", mapping.get("strip_price"))
    barcode_idx = None
    for i, h in enumerate(headers):
        hn = catalog_normalize(h)
        if hn in {"barcode", "bar code", "باركود"}:
            barcode_idx = i
            break
    rows: List[Dict[str, Any]] = []
    for row_number, vals in enumerate(matrix[header_idx + 1 :], start=header_idx + 2):
        name = vals[name_idx] if name_idx < len(vals) else ""
        price = vals[price_idx] if price_idx is not None and price_idx < len(vals) else ""
        barcode = vals[barcode_idx] if barcode_idx is not None and barcode_idx < len(vals) else ""
        raw_name = str(name or "").strip()
        if not raw_name:
            continue
        rows.append({
            "row_number": row_number,
            "raw_name": raw_name,
            "raw_price": _price(price),
            "raw_barcode": str(barcode or "").strip(),
            "raw_json": {"values": [str(v or "") for v in vals], "headers": headers},
        })
    return rows, {
        "header_row": header_idx + 1,
        "mapping": mapping,
        "detected_name_column": headers[name_idx] if name_idx < len(headers) else str(name_idx),
        "detected_price_column": headers[price_idx] if price_idx is not None and price_idx < len(headers) else str(price_idx),
        "rows_raw": len(rows),
    }


def _add_pipe(existing: object, *values: object) -> str:
    out: List[str] = []
    seen: set[str] = set()
    for value in (existing, *values):
        for part in split_multi(value):
            text = str(part or "").strip()
            norm = catalog_normalize(text)
            if text and norm and norm not in seen:
                seen.add(norm)
                out.append(text)
    return " | ".join(out)


def _insert_alias(conn, product_id: int, alias: str, source: str = "ingestion") -> None:
    alias = str(alias or "").strip()
    norm = catalog_normalize(alias)
    if not product_id or not norm:
        return
    conn.execute(
        "INSERT OR IGNORE INTO product_aliases(product_db_id, alias, normalized_alias, source, approved) VALUES(?,?,?,?,1)",
        (int(product_id), alias, norm, source),
    )
    row = conn.execute("SELECT aliases, ocr_keywords FROM products WHERE id=?", (int(product_id),)).fetchone()
    if row:
        conn.execute(
            "UPDATE products SET aliases=?, ocr_keywords=?, canonical_display_name=CASE WHEN COALESCE(canonical_display_name,'')='' THEN ? ELSE canonical_display_name END, updated_at=datetime('now') WHERE id=?",
            (_add_pipe(row[0], alias, norm, catalog_compact(alias)), _add_pipe(row[1], alias, norm), canonical_display_name(alias), int(product_id)),
        )


def _insert_ocr(conn, product_id: int, keyword: str, source: str = "ingestion") -> None:
    keyword = str(keyword or "").strip()
    norm = catalog_normalize(keyword)
    if not product_id or not norm:
        return
    conn.execute(
        "INSERT OR IGNORE INTO product_ocr_keywords(product_db_id, keyword, normalized_keyword, source, approved) VALUES(?,?,?,?,1)",
        (int(product_id), keyword, norm, source),
    )
    row = conn.execute("SELECT ocr_keywords FROM products WHERE id=?", (int(product_id),)).fetchone()
    if row:
        conn.execute("UPDATE products SET ocr_keywords=?, updated_at=datetime('now') WHERE id=?", (_add_pipe(row[0], keyword, norm), int(product_id)))


def _load_indexes(conn) -> Tuple[Dict[str, Dict[str, int]], Dict[int, Dict[str, Any]], Dict[str, List[int]], Dict[str, List[int]]]:
    maps: Dict[str, Dict[str, int]] = {
        "barcode": {}, "alias": {}, "ocr": {}, "identity_key": {}, "normalized_name": {}, "compact_name": {},
    }
    products: Dict[int, Dict[str, Any]] = {}
    by_brand: Dict[str, List[int]] = defaultdict(list)
    by_family: Dict[str, List[int]] = defaultdict(list)
    if not database.table_exists(conn, "products"):
        return maps, products, by_brand, by_family
    rows = [database.dict_row(r) or {} for r in conn.execute("SELECT * FROM products").fetchall()]
    norm_counts = Counter(catalog_normalize(r.get("normalized_name") or r.get("name")) for r in rows)
    key_counts = Counter(str(r.get("identity_key") or "").strip() or _identity_key(r) for r in rows)
    for p in rows:
        pid = int(p.get("id") or 0)
        if not pid:
            continue
        products[pid] = p
        bc = _barcode(p.get("barcode"))
        if bc:
            maps["barcode"].setdefault(bc, pid)
        ident = str(p.get("identity_key") or "").strip() or _identity_key(p)
        if ident and key_counts[ident] == 1:
            maps["identity_key"].setdefault(ident, pid)
        norm = catalog_normalize(p.get("normalized_name") or p.get("name"))
        if norm and norm_counts[norm] == 1:
            maps["normalized_name"].setdefault(norm, pid)
            maps["compact_name"].setdefault(norm.replace(" ", ""), pid)
        brand = catalog_normalize(p.get("brand"))
        family = catalog_normalize(p.get("product_family") or p.get("name"))
        if brand:
            by_brand[brand].append(pid)
        if family:
            by_family[family].append(pid)
        for alias in split_multi(p.get("aliases")):
            a = catalog_normalize(alias)
            if a:
                maps["alias"].setdefault(a, pid)
                maps["alias"].setdefault(a.replace(" ", ""), pid)
        for kw in split_multi(p.get("ocr_keywords")):
            k = catalog_normalize(kw)
            if k:
                maps["ocr"].setdefault(k, pid)
                maps["ocr"].setdefault(k.replace(" ", ""), pid)
    if database.table_exists(conn, "product_aliases"):
        for r in conn.execute("SELECT product_db_id, alias, normalized_alias FROM product_aliases WHERE approved=1").fetchall():
            pid = int(r[0] or 0)
            for val in [r[1], r[2]]:
                a = catalog_normalize(val)
                if a and pid:
                    maps["alias"].setdefault(a, pid)
                    maps["alias"].setdefault(a.replace(" ", ""), pid)
    if database.table_exists(conn, "product_ocr_keywords"):
        for r in conn.execute("SELECT product_db_id, keyword, normalized_keyword FROM product_ocr_keywords WHERE approved=1").fetchall():
            pid = int(r[0] or 0)
            for val in [r[1], r[2]]:
                k = catalog_normalize(val)
                if k and pid:
                    maps["ocr"].setdefault(k, pid)
                    maps["ocr"].setdefault(k.replace(" ", ""), pid)
    return maps, products, by_brand, by_family


def _safe_typo_match(item: Dict[str, Any], products: Dict[int, Dict[str, Any]], by_brand: Dict[str, List[int]], by_family: Dict[str, List[int]]) -> Tuple[int, str]:
    brand = catalog_normalize(item.get("brand"))
    family = catalog_normalize(item.get("product_family"))
    norm = catalog_normalize(item.get("normalized_name"))
    if not norm or not (brand or family):
        return 0, ""
    scoped_ids = set(by_brand.get(brand, [])) if brand else set()
    if family:
        for fid, p in products.items():
            pf = catalog_normalize(p.get("product_family") or p.get("name"))
            pb = catalog_normalize(p.get("brand"))
            if brand and pb and pb != brand:
                continue
            if family and (family in pf or pf in family or _ratio(family, pf) >= 0.94):
                scoped_ids.add(fid)
    best_pid, best_score = 0, 0.0
    for pid in scoped_ids:
        p = products.get(pid) or {}
        candidates = [p.get("normalized_name"), p.get("name"), p.get("product_family"), p.get("aliases"), p.get("ocr_keywords")]
        for c in candidates:
            for part in split_multi(c) or [c]:
                cn = catalog_normalize(part)
                if not cn:
                    continue
                score = max(_ratio(norm, cn), _ratio(norm.replace(" ", ""), cn.replace(" ", "")))
                if score > best_score:
                    best_score, best_pid = score, pid
    if best_pid and best_score >= 0.965:
        return best_pid, "safe_typo_same_brand_family"
    return 0, ""


def _match_item(item: Dict[str, Any], maps: Dict[str, Dict[str, int]], products: Dict[int, Dict[str, Any]], by_brand, by_family) -> Tuple[int, str, str]:
    bc = _barcode(item.get("barcode"))
    if bc and bc in maps["barcode"]:
        return maps["barcode"][bc], "barcode_exact", "barcode exact"
    norm = catalog_normalize(item.get("normalized_name"))
    compact = norm.replace(" ", "")
    for key in [norm, compact]:
        if key and key in maps["alias"]:
            return maps["alias"][key], "approved_alias_exact", "approved alias exact"
    for key in [norm, compact]:
        if key and key in maps["ocr"]:
            return maps["ocr"][key], "ocr_keyword_exact_phrase", "OCR keyword exact phrase"
    ident = str(item.get("identity_key") or "")
    if ident and ident in maps["identity_key"]:
        return maps["identity_key"][ident], "identity_key_exact", "identity key exact"
    if norm and norm in maps["normalized_name"]:
        return maps["normalized_name"][norm], "normalized_name_exact", "normalized name exact"
    if compact and compact in maps["compact_name"]:
        return maps["compact_name"][compact], "normalized_name_compact_exact", "compact normalized name exact"
    pid, reason = _safe_typo_match(item, products, by_brand, by_family)
    if pid:
        return pid, reason, "safe typo correction inside same brand/family"
    # Dangerous near match outside scope is deliberately rejected.
    best_any, best_score = 0, 0.0
    for pid, p in products.items():
        pn = catalog_normalize(p.get("normalized_name") or p.get("name"))
        sc = max(_ratio(norm, pn), _ratio(compact, pn.replace(" ", "")))
        if sc > best_score:
            best_score, best_any = sc, pid
    if best_any and 0.86 <= best_score < 0.965:
        return 0, "dangerous_match_rejected", f"near match outside strict scope score={best_score:.3f}"
    return 0, "new", "no safe match"


def _stage_insert(conn, job_id: int, merchant_id: int, item: Dict[str, Any]) -> int:
    cur = conn.execute(
        """
        INSERT INTO catalog_staging_items(
            job_id, merchant_id, row_number, raw_name, raw_price, raw_barcode, raw_json,
            normalized_name, compact_name, spelling_corrected_name, brand, product_family, category, form,
            strength, size, pack, barcode, identity_key, matched_product_db_id, matched_by,
            decision, decision_reason, duplicate_of_staging_id, status
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            job_id, merchant_id, item.get("row_number", 0), item.get("raw_name", ""), item.get("raw_price", ""), item.get("raw_barcode", ""),
            json.dumps(item.get("raw_json") or {}, ensure_ascii=False, default=str), item.get("normalized_name", ""), item.get("compact_name", ""), item.get("spelling_corrected_name", ""),
            item.get("brand", ""), item.get("product_family", ""), item.get("category", ""), item.get("form", ""), item.get("strength", ""),
            item.get("size", ""), item.get("pack", ""), item.get("barcode", ""), item.get("identity_key", ""), item.get("matched_product_db_id"),
            item.get("matched_by", ""), item.get("decision", ""), item.get("decision_reason", ""), item.get("duplicate_of_staging_id"), item.get("status", "staged"),
        ),
    )
    return int(cur.lastrowid)


def _create_review(conn, job_id: int, merchant_id: int, staging_id: int, item: Dict[str, Any], issue_type: str, severity: str, notes: str = "") -> None:
    payload = dict(item)
    payload.pop("raw_json", None)
    conn.execute(
        """
        INSERT INTO catalog_review_items(
            job_id, merchant_id, issue_type, severity, row_json, duplicate_key, price_old, price_new,
            status, staging_item_id, matched_product_db_id, raw_name, normalized_name, suggested_brand,
            suggested_family, suggested_category, suggested_form, suggested_strength, suggested_size,
            suggested_pack, suggested_aliases, review_notes
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            job_id, merchant_id, issue_type, severity, json.dumps(payload, ensure_ascii=False, default=str), item.get("identity_key", ""),
            str(item.get("price_old") or ""), str(item.get("raw_price") or ""), "pending", staging_id, item.get("matched_product_db_id"),
            item.get("raw_name", ""), item.get("normalized_name", ""), item.get("brand", ""), item.get("product_family", ""), item.get("category", ""),
            item.get("form", ""), item.get("strength", ""), item.get("size", ""), item.get("pack", ""), item.get("suggested_aliases", ""), notes,
        ),
    )


def create_ingestion_plan(job_id: int, excel_path: str, merchant_id: int = 1) -> Dict[str, Any]:
    ensure_schema()
    started = time.time()
    rows, meta = _excel_rows(excel_path)
    if not rows:
        raise RuntimeError("NO_STAGING_ROWS_FROM_EXCEL")
    stats = Counter()
    matched_product_ids: set[int] = set()
    examples: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    with database.connect() as conn:
        # Reset only this job's staging/review rows. No products are touched.
        conn.execute("DELETE FROM catalog_staging_items WHERE job_id=?", (int(job_id),))
        conn.execute("DELETE FROM catalog_review_items WHERE job_id=?", (int(job_id),))
        known_brands = _known_brands_from_db(conn)
        maps, products, by_brand, by_family = _load_indexes(conn)
        seen_in_upload: Dict[str, Tuple[int, str, int]] = {}
        staged_items_for_review: List[Tuple[int, Dict[str, Any]]] = []

        conn.execute(
            "INSERT OR REPLACE INTO catalog_upload_jobs(id, legacy_job_id, merchant_id, filename, file_path, status, detected_name_column, detected_price_column, rows_raw, report_json, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,datetime('now'))",
            (int(job_id), int(job_id), int(merchant_id), Path(excel_path).name, str(excel_path), "processing", meta.get("detected_name_column", ""), meta.get("detected_price_column", ""), int(meta.get("rows_raw") or len(rows)), "{}"),
        )

        for r in rows:
            corrected = catalog_normalize(r["raw_name"])
            slots = _extract_slots(corrected, known_brands)
            item: Dict[str, Any] = {
                **r,
                "normalized_name": corrected,
                "compact_name": corrected.replace(" ", ""),
                "spelling_corrected_name": corrected,
                **slots,
            }
            if _barcode(r.get("raw_barcode")):
                item["barcode"] = _barcode(r.get("raw_barcode"))
            item["identity_key"] = _identity_key({**item, "name": item["normalized_name"]})
            dup_key = item["identity_key"] or item["normalized_name"]
            if dup_key in seen_in_upload:
                prev_id, prev_price, prev_pid = seen_in_upload[dup_key]
                item["duplicate_of_staging_id"] = prev_id
                item["matched_product_db_id"] = prev_pid or None
                if _is_same_price(prev_price, item.get("raw_price")):
                    item["decision"] = DECISION_EXACT_DUPLICATE_MERGED
                    item["decision_reason"] = "same identity/name and same price inside upload"
                    item["matched_by"] = "upload_duplicate"
                    stats[DECISION_EXACT_DUPLICATE_MERGED] += 1
                elif prev_pid:
                    # Same known product appears multiple times in the weekly file with different prices.
                    # This is not a catalog conflict: the last row in the uploaded file wins.
                    item["decision"] = DECISION_UPDATE_PRICE
                    item["decision_reason"] = f"{WARNING_DUPLICATE_PRICE_LAST_VALUE_USED}: same identity/product repeated; latest row price will be used"
                    item["matched_by"] = "upload_duplicate_price_last_value_used"
                    stats[DECISION_UPDATE_PRICE] += 1
                    stats[WARNING_DUPLICATE_PRICE_LAST_VALUE_USED] += 1
                    matched_product_ids.add(int(prev_pid))
                else:
                    # Duplicate prices for an unknown or ambiguous identity cannot be safely promoted.
                    item["decision"] = DECISION_AMBIGUOUS_VARIANT
                    item["decision_reason"] = "duplicate rows with different prices but no safe product_id; identity needs review"
                    item["matched_by"] = "upload_duplicate_unclear_identity"
                    stats[DECISION_AMBIGUOUS_VARIANT] += 1
                sid = _stage_insert(conn, job_id, merchant_id, item)
                if item["decision"] in {DECISION_AMBIGUOUS_VARIANT, DECISION_NEEDS_REVIEW, DECISION_DANGEROUS_MATCH_REJECTED, DECISION_PRICE_CONFLICT}:
                    staged_items_for_review.append((sid, item))
                    _create_review(conn, job_id, merchant_id, sid, item, item["decision"].lower(), "blocking", item["decision_reason"])
                # Keep the latest uploaded row as the canonical duplicate representative.
                seen_in_upload[dup_key] = (sid, item.get("raw_price") or "", int(prev_pid or 0))
                if len(examples[item["decision"]]) < 5:
                    examples[item["decision"]].append({"row": item.get("row_number"), "name": item.get("raw_name"), "reason": item.get("decision_reason"), "warning": WARNING_DUPLICATE_PRICE_LAST_VALUE_USED if item.get("matched_by") == "upload_duplicate_price_last_value_used" else ""})
                continue

            pid, matched_by, reason = _match_item(item, maps, products, by_brand, by_family)
            item["matched_product_db_id"] = pid or None
            item["matched_by"] = matched_by
            item["decision_reason"] = reason
            if pid:
                p = products.get(pid) or {}
                item["price_old"] = safe_price(p.get("price"))
                # Price change on a safely matched known product is expected: this is the weekly file's purpose.
                item["decision"] = DECISION_UPDATE_PRICE
                if _is_same_price(item.get("price_old"), item.get("raw_price")):
                    item["decision_reason"] = "matched known product; price unchanged"
                    stats[METRIC_PRICES_UNCHANGED] += 1
                else:
                    item["decision_reason"] = f"matched known product; weekly price update old={item.get('price_old')} new={safe_price(item.get('raw_price'))}"
                    stats[DECISION_UPDATE_PRICE] += 1
                matched_product_ids.add(int(pid))
            elif matched_by == "dangerous_match_rejected":
                item["decision"] = DECISION_DANGEROUS_MATCH_REJECTED
                stats[DECISION_DANGEROUS_MATCH_REJECTED] += 1
            else:
                # Brand/family-only rows such as Flagyl or Cerave must not become
                # sellable products.  They need variant clarification/review.
                brand_only_known = bool(item.get("brand") and not item.get("product_family") and not item.get("form") and not item.get("strength") and not item.get("size") and by_brand.get(item.get("brand"), []))
                if brand_only_known:
                    item["decision"] = DECISION_AMBIGUOUS_VARIANT
                    item["decision_reason"] = "brand-only row; form/strength/size/family required before sellable update"
                else:
                    # New products are review-first. They are not inserted into production by job approval.
                    item["decision"] = DECISION_NEW_PRODUCT_READY if item.get("normalized_name") and item.get("raw_price") else DECISION_NEEDS_REVIEW
                stats[item["decision"]] += 1
            sid = _stage_insert(conn, job_id, merchant_id, item)
            seen_in_upload[dup_key] = (sid, item.get("raw_price") or "", int(pid or 0))
            if item["decision"] in {DECISION_NEW_PRODUCT_READY, DECISION_NEEDS_REVIEW, DECISION_AMBIGUOUS_VARIANT, DECISION_DANGEROUS_MATCH_REJECTED}:
                severity = "review" if item["decision"] == DECISION_NEW_PRODUCT_READY else "blocking"
                _create_review(conn, job_id, merchant_id, sid, item, item["decision"].lower(), severity, item["decision_reason"])
            if len(examples[item["decision"]]) < 5:
                examples[item["decision"]].append({"row": item.get("row_number"), "name": item.get("raw_name"), "matched_by": matched_by, "reason": reason})

        # Products missing from this upload are not deleted; they are listed for approval-time unavailable marking.
        existing_sellable = {pid for pid, p in products.items() if int(p.get("merchant_id") or 1) == int(merchant_id)}
        missing_ids = sorted(existing_sellable - matched_product_ids)
        for pid in missing_ids:
            p = products.get(pid) or {}
            item = {
                "row_number": 0,
                "raw_name": str(p.get("name") or ""),
                "raw_price": str(p.get("price") or ""),
                "normalized_name": catalog_normalize(p.get("normalized_name") or p.get("name")),
                "compact_name": catalog_compact(p.get("normalized_name") or p.get("name")),
                "brand": catalog_normalize(p.get("brand")),
                "product_family": catalog_normalize(p.get("product_family") or p.get("name")),
                "category": catalog_normalize(p.get("category")),
                "form": catalog_normalize(p.get("form") or p.get("product_type") or p.get("medicine_form")),
                "strength": catalog_normalize(p.get("strength")),
                "size": catalog_normalize(p.get("size")),
                "pack": catalog_normalize(p.get("pack")),
                "barcode": _barcode(p.get("barcode")),
                "identity_key": str(p.get("identity_key") or "") or _identity_key(p),
                "matched_product_db_id": pid,
                "matched_by": "missing_from_latest_upload",
                "decision": DECISION_MISSING_FROM_UPLOAD,
                "decision_reason": "product exists in master but was not present in the latest weekly Excel",
                "status": "pending_approval",
            }
            _stage_insert(conn, job_id, merchant_id, item)
        stats[DECISION_MISSING_FROM_UPLOAD] = len(missing_ids)

        report = {
            "job_id": int(job_id),
            "mode": "catalog_ingestion_master",
            "production_untouched": True,
            "excel_is_master_catalog": False,
            "master_catalog_policy": "weekly Excel may update price/availability only for matched known products; review queue handles new/ambiguous/conflict rows",
            "duration_seconds": round(time.time() - started, 3),
            "detected_columns": meta,
            "rows_raw": len(rows),
            "rows_staged": int(len(rows) + len(missing_ids)),
            "summary": {
                "prices_updated": int(stats[DECISION_UPDATE_PRICE]),
                "prices_unchanged": int(stats[METRIC_PRICES_UNCHANGED]),
                "updated_prices": int(stats[DECISION_UPDATE_PRICE]),
                "new_products_ready": int(stats[DECISION_NEW_PRODUCT_READY]),
                "new_products": int(stats[DECISION_NEW_PRODUCT_READY]),
                "exact_duplicates_merged": int(stats[DECISION_EXACT_DUPLICATE_MERGED]),
                "duplicates_merged": int(stats[DECISION_EXACT_DUPLICATE_MERGED]),
                "duplicate_rows_with_last_price_used": int(stats[WARNING_DUPLICATE_PRICE_LAST_VALUE_USED]),
                "items_needing_review": int(stats[DECISION_NEEDS_REVIEW] + stats[DECISION_AMBIGUOUS_VARIANT] + stats[DECISION_PRICE_CONFLICT] + stats[DECISION_DANGEROUS_MATCH_REJECTED] + stats[DECISION_NEW_PRODUCT_READY]),
                "need_review": int(stats[DECISION_NEEDS_REVIEW] + stats[DECISION_AMBIGUOUS_VARIANT] + stats[DECISION_PRICE_CONFLICT] + stats[DECISION_DANGEROUS_MATCH_REJECTED] + stats[DECISION_NEW_PRODUCT_READY]),
                "ambiguous_variants": int(stats[DECISION_AMBIGUOUS_VARIANT]),
                "missing_from_upload_report_only": int(stats[DECISION_MISSING_FROM_UPLOAD]),
                "missing_marked_unavailable": 0,
                "price_conflicts": int(stats[DECISION_PRICE_CONFLICT]),
                "dangerous_matches_rejected": int(stats[DECISION_DANGEROUS_MATCH_REJECTED]),
                "dangerous_rejected": int(stats[DECISION_DANGEROUS_MATCH_REJECTED]),
            },
            "decisions": dict(stats),
            "examples": dict(examples),
        }
        status = "ready_for_approval" if stats[DECISION_UPDATE_PRICE] or stats[METRIC_PRICES_UNCHANGED] or stats[DECISION_MISSING_FROM_UPLOAD] or stats[DECISION_EXACT_DUPLICATE_MERGED] else "requires_review"
        conn.execute(
            """
            UPDATE catalog_upload_jobs SET status=?, rows_staged=?, updated_prices=?, prices_unchanged=?, new_products=?, duplicates_merged=?,
                duplicate_price_last_value_used=?, need_review=?, missing_report_only=?, missing_marked_unavailable=?,
                price_conflicts=?, dangerous_rejected=?, report_json=?, updated_at=datetime('now')
            WHERE id=?
            """,
            (
                status,
                int(report["rows_staged"]),
                int(stats[DECISION_UPDATE_PRICE]),
                int(stats[METRIC_PRICES_UNCHANGED]),
                int(stats[DECISION_NEW_PRODUCT_READY]),
                int(stats[DECISION_EXACT_DUPLICATE_MERGED]),
                int(stats[WARNING_DUPLICATE_PRICE_LAST_VALUE_USED]),
                int(report["summary"]["need_review"]),
                int(stats[DECISION_MISSING_FROM_UPLOAD]),
                0,
                int(stats[DECISION_PRICE_CONFLICT]),
                int(stats[DECISION_DANGEROUS_MATCH_REJECTED]),
                json.dumps(report, ensure_ascii=False, indent=2, default=str),
                int(job_id),
            ),
        )
    database.update_catalog_import_job(
        job_id,
        status=status,
        job_type="catalog_ingestion_master",
        merchant_id=int(merchant_id),
        requires_approval=1,
        added=int(report["summary"]["new_products"]),
        updated=int(report["summary"]["updated_prices"]),
        duplicate_conflicts=int(report["summary"]["price_conflicts"]),
        needs_review=int(report["summary"]["need_review"]),
        verified=1,
        acceptance_passed=1 if status == "ready_for_approval" else 0,
        report_text=json.dumps(report, ensure_ascii=False, indent=2, default=str)[-8000:],
    )
    _audit(job_id, "plan_created", details=report["summary"])
    return report


def _approved_review_product_payload(row: Dict[str, Any]) -> Dict[str, str]:
    row_json = {}
    try:
        row_json = json.loads(row.get("row_json") or "{}")
    except Exception:
        row_json = {}
    raw_name = str(row.get("raw_name") or row_json.get("raw_name") or "").strip()
    brand = str(row.get("suggested_brand") or "").strip()
    family = str(row.get("suggested_family") or row.get("normalized_name") or raw_name).strip()
    category = str(row.get("suggested_category") or "").strip()
    form = str(row.get("suggested_form") or "").strip()
    strength = str(row.get("suggested_strength") or "").strip()
    size = str(row.get("suggested_size") or "").strip()
    pack = str(row.get("suggested_pack") or "").strip()
    price = safe_price(row.get("price_new") or row_json.get("raw_price") or "")
    normalized = catalog_normalize(raw_name)
    display_name = canonical_display_name(raw_name) or raw_name
    payload: Dict[str, str] = {c: "" for c in database.PRODUCT_COLUMNS}
    payload.update({
        "merchant_id": str(row.get("merchant_id") or 1),
        "product_id": "",
        "name": display_name,
        "original_name": raw_name,
        "normalized_name": normalized,
        "brand": brand,
        "product_family": family,
        "category": category,
        "main_section": category,
        "form": form,
        "product_type": form,
        "strength": strength,
        "size": size,
        "pack": pack,
        "price": price,
        "available": "true",
        "search_mode": "sellable",
        "quality_status": "approved",
        "review_status": "approved",
        "aliases": _add_pipe(row.get("suggested_aliases"), raw_name, normalized, catalog_compact(raw_name)),
        "ocr_keywords": _add_pipe(row.get("suggested_aliases"), raw_name, normalized),
    })
    payload["identity_key"] = _identity_key(payload)
    return payload


def approve_review_item(review_id: int, actor: str = "merchant", **fields: str) -> Dict[str, Any]:
    ensure_schema()
    backup = str(database.backup_db("before_catalog_review_approve")) if database.get_db_path().exists() and not database.IS_POSTGRES else ""
    product_db_id = 0
    row: Dict[str, Any] = {}
    try:
        with database.connect() as conn:
            row = database.dict_row(conn.execute("SELECT * FROM catalog_review_items WHERE id=?", (int(review_id),)).fetchone()) or {}
            if not row:
                raise RuntimeError("REVIEW_ITEM_NOT_FOUND")
            for k, v in fields.items():
                if k in {"suggested_brand", "suggested_family", "suggested_category", "suggested_form", "suggested_strength", "suggested_size", "suggested_pack", "suggested_aliases", "review_notes"}:
                    row[k] = str(v or "").strip()
            payload = _approved_review_product_payload(row)
            cols = list(database.PRODUCT_COLUMNS) + ["canonical_display_name"]
            payload["canonical_display_name"] = canonical_display_name(payload.get("name") or payload.get("original_name"))
            placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
            cur = conn.execute(
                f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in cols + ["created_at", "updated_at"])}) VALUES({", ".join(placeholders)})',
                [payload.get(c, "") for c in cols],
            )
            product_db_id = int(cur.lastrowid)
            aliases = _add_pipe(row.get("suggested_aliases"), row.get("raw_name"), row.get("normalized_name"), payload.get("canonical_display_name"))
            for alias in split_multi(aliases):
                _insert_alias(conn, product_db_id, alias, source="review_approved")
                _insert_ocr(conn, product_db_id, alias, source="review_approved")
            conn.execute(
                "UPDATE catalog_review_items SET status='approved', reviewed_by=?, reviewed_at=datetime('now'), matched_product_db_id=?, updated_at=datetime('now') WHERE id=?",
                (actor, product_db_id, int(review_id)),
            )
            conn.execute(
                "INSERT OR REPLACE INTO merchant_inventory(merchant_id, product_db_id, price, available, missing_from_upload, last_upload_job_id, last_seen_at, updated_at) VALUES(?,?,?,?,?,?,datetime('now'),datetime('now'))",
                (int(row.get("merchant_id") or 1), product_db_id, payload.get("price", ""), 1, 0, int(row.get("job_id") or 0)),
            )
        refresh = _post_catalog_write_refresh()
        _audit(int(row.get("job_id") or 0), "review_item_approved", actor=actor, details={"review_id": review_id, "product_db_id": product_db_id, **refresh})
        return {"ok": True, "review_id": int(review_id), "product_db_id": product_db_id, **refresh}
    except Exception:
        if backup and not database.IS_POSTGRES:
            database.restore_db_from_backup(Path(backup))
        _audit(int(row.get("job_id") or 0) if row else 0, "review_item_approval_rollback", actor=actor, details={"review_id": review_id, "backup": backup})
        raise

def reject_review_item(review_id: int, actor: str = "merchant", reason: str = "") -> Dict[str, Any]:
    ensure_schema()
    with database.connect() as conn:
        row = database.dict_row(conn.execute("SELECT * FROM catalog_review_items WHERE id=?", (int(review_id),)).fetchone())
        if not row:
            raise RuntimeError("REVIEW_ITEM_NOT_FOUND")
        conn.execute(
            "UPDATE catalog_review_items SET status='rejected', review_notes=?, reviewed_by=?, reviewed_at=datetime('now'), updated_at=datetime('now') WHERE id=?",
            (reason, actor, int(review_id)),
        )
    _audit(int(row.get("job_id") or 0), "review_item_rejected", actor=actor, details={"review_id": review_id, "reason": reason})
    return {"ok": True, "review_id": int(review_id)}


def _run_acceptance_checks() -> Dict[str, Any]:
    result: Dict[str, Any] = {"passed": True, "checks": {}}
    try:
        result["checks"]["integrity"] = database.integrity_check()
        result["checks"]["products_count"] = database.count_products()
        result["checks"]["search_index_count"] = database.count_table("product_search_index")
        result["checks"]["identity_count"] = database.count_table("product_identity_registry")
        if str(result["checks"].get("integrity", "")).lower() != "ok":
            result["passed"] = False
            result["error"] = "SQLITE_INTEGRITY_FAILED"
        if result["checks"].get("products_count", 0) <= 0:
            result["passed"] = False
            result["error"] = "NO_PRODUCTS_AFTER_APPROVAL"
    except Exception as exc:
        result["passed"] = False
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def _rebuild_indexes_or_raise() -> Dict[str, Any]:
    from services.catalog.excel_native_importer import fast_rebuild_guided_index, fast_rebuild_identity_registry, fast_rebuild_search_index
    report: Dict[str, Any] = {}
    report["search_index"] = fast_rebuild_search_index()
    report["product_identity_registry"] = fast_rebuild_identity_registry()
    try:
        report["guided_catalog_index"] = fast_rebuild_guided_index()
    except Exception as exc:
        # Guided browsing is secondary, but still report it.  Core exact search indexes above are mandatory.
        report["guided_catalog_index_warning"] = f"{type(exc).__name__}: {exc}"
    try:
        from services.matching import excel_native_matcher
        excel_native_matcher.invalidate_memory_index()
        report["excel_native_cache_invalidated"] = True
    except Exception as exc:
        report["excel_native_cache_warning"] = f"{type(exc).__name__}: {exc}"
    try:
        import search_engine
        search_engine.invalidate_memory_index()
        report["search_engine_cache_invalidated"] = True
    except Exception as exc:
        report["memory_index_warning"] = f"{type(exc).__name__}: {exc}"
    return report


def _approval_safety_metrics(rows: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    uploaded_rows = [r for r in rows if str(r.get("decision") or "") != DECISION_MISSING_FROM_UPLOAD]
    missing_rows = [r for r in rows if str(r.get("decision") or "") == DECISION_MISSING_FROM_UPLOAD]
    matched_rows = [r for r in uploaded_rows if str(r.get("decision") or "") in {DECISION_UPDATE_PRICE, DECISION_EXACT_DUPLICATE_MERGED}]
    blocking_rows = [r for r in uploaded_rows if str(r.get("decision") or "") in BLOCKING_DECISIONS]
    matched_ratio = (len(matched_rows) / len(uploaded_rows)) if uploaded_rows else 0.0
    missing_ratio = (len(missing_rows) / max(1, len(missing_rows) + len(matched_rows))) if (missing_rows or matched_rows) else 0.0
    return {
        "uploaded_rows": len(uploaded_rows),
        "matched_rows": len(matched_rows),
        "blocking_rows": len(blocking_rows),
        "missing_rows": len(missing_rows),
        "matched_ratio": round(matched_ratio, 4),
        "missing_ratio": round(missing_ratio, 4),
        "low_matched_ratio": bool(uploaded_rows and matched_ratio < 0.35),
        "large_missing_from_upload": bool(len(missing_rows) >= 500 or missing_ratio >= 0.25),
    }


def _post_catalog_write_refresh() -> Dict[str, Any]:
    reindex = _rebuild_indexes_or_raise()
    acceptance = _run_acceptance_checks()
    if not acceptance.get("passed"):
        raise RuntimeError("ACCEPTANCE_FAILED_AFTER_CATALOG_WRITE: " + json.dumps(acceptance, ensure_ascii=False))
    return {"reindex": reindex, "acceptance": acceptance}


def approve_ingestion_job(job_id: int, actor: str = "merchant", *, full_inventory_upload: bool = False, mark_missing_unavailable: bool = False) -> Dict[str, Any]:
    ensure_schema()
    job = database.get_catalog_import_job(job_id)
    if not job:
        raise RuntimeError("CATALOG_JOB_NOT_FOUND")
    if str(job.get("status")) not in {"ready_for_approval", "requires_review"}:
        raise RuntimeError(f"CATALOG_JOB_NOT_READY status={job.get('status')}")
    backup = str(database.backup_db("before_catalog_ingestion_approve")) if database.get_db_path().exists() and not database.IS_POSTGRES else ""
    stats = Counter()
    applied_product_ids: set[int] = set()
    started = time.time()
    try:
        with database.connect() as conn:
            rows = [database.dict_row(r) or {} for r in conn.execute("SELECT * FROM catalog_staging_items WHERE job_id=? ORDER BY id", (int(job_id),)).fetchall()]
            if not rows:
                raise RuntimeError("NO_STAGING_ITEMS_FOR_JOB")
            safety = _approval_safety_metrics(rows)
            allow_missing_unavailable = bool(full_inventory_upload or mark_missing_unavailable)
            if safety.get("low_matched_ratio"):
                raise RuntimeError("APPROVAL_SAFETY_GUARD_LOW_MATCHED_RATIO " + json.dumps(safety, ensure_ascii=False))
            conn.execute("BEGIN")
            for r in rows:
                decision = str(r.get("decision") or "")
                pid = int(r.get("matched_product_db_id") or 0)
                if decision == DECISION_UPDATE_PRICE and pid:
                    price = safe_price(r.get("raw_price"))
                    old_price = safe_price(r.get("price_old"))
                    unchanged = bool(old_price and old_price == price)
                    conn.execute(
                        """
                        UPDATE products SET price=?, available='true', search_mode='sellable',
                            canonical_display_name=CASE WHEN COALESCE(canonical_display_name,'')='' THEN ? ELSE canonical_display_name END,
                            review_status=CASE WHEN review_status IN ('', 'stale_missing_from_latest_excel') THEN 'approved' ELSE review_status END,
                            updated_at=datetime('now')
                        WHERE id=?
                        """,
                        (price, canonical_display_name(r.get("raw_name") or r.get("normalized_name")), pid),
                    )
                    conn.execute(
                        "INSERT OR REPLACE INTO merchant_inventory(merchant_id, product_db_id, price, available, missing_from_upload, last_upload_job_id, last_seen_at, updated_at) VALUES(?,?,?,?,?,?,datetime('now'),datetime('now'))",
                        (int(r.get("merchant_id") or 1), pid, price, 1, 0, int(job_id)),
                    )
                    _insert_alias(conn, pid, str(r.get("raw_name") or ""), source="weekly_upload")
                    _insert_alias(conn, pid, str(r.get("normalized_name") or ""), source="weekly_upload_canonical")
                    _insert_ocr(conn, pid, str(r.get("raw_name") or ""), source="weekly_upload")
                    _insert_ocr(conn, pid, str(r.get("normalized_name") or ""), source="weekly_upload_canonical")
                    _audit_conn(conn, int(job_id), "price_update" if not unchanged else "price_unchanged", actor=actor, details={
                        "product_db_id": pid,
                        "old_price": old_price,
                        "new_price": price,
                        "upload_id": int(job_id),
                        "source_row": int(r.get("row_number") or 0),
                        "warning": WARNING_DUPLICATE_PRICE_LAST_VALUE_USED if str(r.get("matched_by") or "") == "upload_duplicate_price_last_value_used" else "",
                    })
                    applied_product_ids.add(pid)
                    if unchanged:
                        stats["prices_unchanged"] += 1
                    else:
                        stats["updated_prices"] += 1
                    if str(r.get("matched_by") or "") == "upload_duplicate_price_last_value_used":
                        stats["duplicate_price_last_value_used"] += 1
                elif decision == DECISION_EXACT_DUPLICATE_MERGED:
                    stats["duplicates_merged"] += 1
                elif decision == DECISION_MISSING_FROM_UPLOAD and pid:
                    if allow_missing_unavailable:
                        conn.execute(
                            "UPDATE products SET available='false', review_status='missing_from_upload', updated_at=datetime('now') WHERE id=?",
                            (pid,),
                        )
                        conn.execute(
                            "INSERT OR REPLACE INTO merchant_inventory(merchant_id, product_db_id, price, available, missing_from_upload, last_upload_job_id, last_seen_at, updated_at) VALUES(?,?,?,?,?,?,datetime('now'),datetime('now'))",
                            (int(r.get("merchant_id") or 1), pid, str(r.get("raw_price") or ""), 0, 1, int(job_id)),
                        )
                        stats["missing_marked_unavailable"] += 1
                    else:
                        # Weekly price lists are not full inventory by default. Missing
                        # rows are reported only and do not make products unavailable.
                        stats["missing_report_only"] += 1
                elif decision == DECISION_NEW_PRODUCT_READY:
                    # Review queue only.  Product is not inserted silently.
                    stats["new_products"] += 1
                elif decision in BLOCKING_DECISIONS:
                    stats["need_review"] += 1
            conn.execute("UPDATE catalog_staging_items SET status='approved_applied', updated_at=datetime('now') WHERE job_id=? AND decision IN (?, ?)", (int(job_id), DECISION_UPDATE_PRICE, DECISION_EXACT_DUPLICATE_MERGED))
            if allow_missing_unavailable:
                conn.execute("UPDATE catalog_staging_items SET status='approved_applied', updated_at=datetime('now') WHERE job_id=? AND decision=?", (int(job_id), DECISION_MISSING_FROM_UPLOAD))
            else:
                conn.execute("UPDATE catalog_staging_items SET status='reported_only', updated_at=datetime('now') WHERE job_id=? AND decision=?", (int(job_id), DECISION_MISSING_FROM_UPLOAD))
            conn.execute("COMMIT")

        reindex = _rebuild_indexes_or_raise()
        acceptance = _run_acceptance_checks()
        if not acceptance.get("passed"):
            raise RuntimeError("ACCEPTANCE_FAILED_AFTER_APPROVAL: " + json.dumps(acceptance, ensure_ascii=False))
        summary = {
            "Updated prices": int(stats["updated_prices"]),
            "Prices unchanged": int(stats["prices_unchanged"]),
            "New products": int(stats["new_products"]),
            "Duplicates merged": int(stats["duplicates_merged"]),
            "Duplicate rows with last price used": int(stats["duplicate_price_last_value_used"]),
            "Need review": int(stats["need_review"]),
            "Missing marked unavailable": int(stats["missing_marked_unavailable"]),
            "Missing report only": int(stats["missing_report_only"]),
        }
        report = {
            "ok": True,
            "job_id": int(job_id),
            "backup": backup,
            "summary": summary,
            "reindex": reindex,
            "acceptance": acceptance,
            "approval_safety": safety,
            "full_inventory_upload": bool(full_inventory_upload),
            "mark_missing_unavailable": bool(mark_missing_unavailable),
            "duration_seconds": round(time.time() - started, 3),
        }
        database.update_catalog_import_job(job_id, status="approved", approval_user=actor, approved_at="datetime('now')", report_text=json.dumps(report, ensure_ascii=False, indent=2, default=str)[-8000:], acceptance_passed=1)
        with database.connect() as conn:
            conn.execute("UPDATE catalog_upload_jobs SET status='approved', approved_by=?, approved_at=datetime('now'), report_json=?, updated_at=datetime('now') WHERE id=?", (actor, json.dumps(report, ensure_ascii=False, indent=2, default=str), int(job_id)))
        _audit(job_id, "job_approved", actor=actor, details=summary)
        return report
    except Exception:
        if backup and not database.IS_POSTGRES:
            database.restore_db_from_backup(Path(backup))
        database.update_catalog_import_job(job_id, status="rollback_after_failed_approval", error_text="approval failed; backup restored")
        _audit(job_id, "job_approval_rollback", actor=actor, details={"backup": backup})
        raise


def reject_ingestion_job(job_id: int, actor: str = "merchant", reason: str = "") -> Dict[str, Any]:
    ensure_schema()
    database.update_catalog_import_job(job_id, status="rejected", report_text=f"REJECTED_BY={actor} REASON={reason}")
    with database.connect() as conn:
        conn.execute("UPDATE catalog_upload_jobs SET status='rejected', updated_at=datetime('now') WHERE id=?", (int(job_id),))
        conn.execute("UPDATE catalog_staging_items SET status='rejected', updated_at=datetime('now') WHERE job_id=?", (int(job_id),))
    _audit(job_id, "job_rejected", actor=actor, details={"reason": reason})
    return {"ok": True, "job_id": int(job_id)}


def job_report(job_id: int) -> Dict[str, Any]:
    ensure_schema()
    with database.connect() as conn:
        upload = database.dict_row(conn.execute("SELECT * FROM catalog_upload_jobs WHERE id=?", (int(job_id),)).fetchone()) or {}
        decisions = [database.dict_row(r) or {} for r in conn.execute("SELECT decision, COUNT(*) AS n FROM catalog_staging_items WHERE job_id=? GROUP BY decision ORDER BY n DESC", (int(job_id),)).fetchall()]
        examples = [database.dict_row(r) or {} for r in conn.execute("SELECT row_number, raw_name, raw_price, matched_product_db_id, matched_by, decision, decision_reason FROM catalog_staging_items WHERE job_id=? ORDER BY id LIMIT 100", (int(job_id),)).fetchall()]
        reviews = [database.dict_row(r) or {} for r in conn.execute("SELECT * FROM catalog_review_items WHERE job_id=? AND status='pending' ORDER BY severity DESC, id DESC LIMIT 200", (int(job_id),)).fetchall()]
    parsed_report: Dict[str, Any] = {}
    try:
        parsed_report = json.loads(upload.get("report_json") or upload.get("report_text") or "{}") if upload else {}
    except Exception:
        parsed_report = {}
    return {"upload": upload, "summary": parsed_report.get("summary", {}), "raw_report": parsed_report, "decisions": decisions, "examples": examples, "reviews": reviews}


def pending_reviews(job_id: Optional[int] = None, limit: int = 200) -> List[Dict[str, Any]]:
    ensure_schema()
    with database.connect() as conn:
        if job_id:
            rows = conn.execute("SELECT * FROM catalog_review_items WHERE job_id=? AND status='pending' ORDER BY severity DESC, id DESC LIMIT ?", (int(job_id), int(limit))).fetchall()
        else:
            rows = conn.execute("SELECT * FROM catalog_review_items WHERE status='pending' ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [database.dict_row(r) or {} for r in rows]
