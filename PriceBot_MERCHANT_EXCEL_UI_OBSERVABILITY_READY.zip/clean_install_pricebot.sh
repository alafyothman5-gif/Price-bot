#!/usr/bin/env bash
set -euo pipefail

RELEASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${PRICEBOT_TARGET_DIR:-/opt/pricebot_clean}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_clean_install_backups}"
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
OLD_ROLLBACK="${TARGET_DIR}_rollback_${STAMP}"
SERVICE_PATH="/etc/systemd/system/$SERVICE_NAME"
HEALTH_URL="${PRICEBOT_HEALTH_URL:-http://127.0.0.1:8090/health}"

if [[ "$EUID" -ne 0 ]]; then
  echo "ERROR: run with sudo" >&2
  exit 1
fi

if [[ "$RELEASE_DIR" == "$TARGET_DIR" ]]; then
  echo "ERROR: run this script from extracted ZIP directory, not from $TARGET_DIR" >&2
  exit 1
fi

mkdir -p "$BACKUP_DIR"

if [[ ! -f "$TARGET_DIR/.env" ]]; then
  echo "ERROR: missing $TARGET_DIR/.env. This safe installer preserves the existing runtime .env and does not create secrets." >&2
  exit 1
fi
if [[ ! -f "$TARGET_DIR/pricebot.db" ]]; then
  echo "ERROR: missing $TARGET_DIR/pricebot.db. This safe installer will not create or replace the production database." >&2
  exit 1
fi

cp -a "$TARGET_DIR/.env" "$BACKUP_DIR/.env"
cp -a "$TARGET_DIR/pricebot.db" "$BACKUP_DIR/pricebot.db"
cp -a "$TARGET_DIR/uploads" "$BACKUP_DIR/uploads" 2>/dev/null || true
if [[ -f "$SERVICE_PATH" ]]; then cp -a "$SERVICE_PATH" "$BACKUP_DIR/pricebot.service"; fi

echo "BACKUP_DIR=$BACKUP_DIR"
echo "ENV_BACKUP=OK"
echo "DB_BACKUP=OK"
echo "SAFE_DB_MODE=preserve_existing_db_no_rebuild"

rollback_on_error() {
  rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "SAFE_INSTALL_FAILED rc=$rc"
    systemctl stop "$SERVICE_NAME" || true
    if [[ -d "$OLD_ROLLBACK" ]]; then
      rm -rf "$TARGET_DIR"
      mv "$OLD_ROLLBACK" "$TARGET_DIR"
      echo "ROLLBACK_DIR_RESTORED=$TARGET_DIR"
    fi
    if [[ -f "$BACKUP_DIR/pricebot.service" ]]; then
      cp -a "$BACKUP_DIR/pricebot.service" "$SERVICE_PATH"
      systemctl daemon-reload || true
    fi
    systemctl start "$SERVICE_NAME" || true
  fi
  exit $rc
}
trap rollback_on_error ERR

systemctl stop "$SERVICE_NAME" || true

if [[ -d "$TARGET_DIR" ]]; then
  mv "$TARGET_DIR" "$OLD_ROLLBACK"
  echo "OLD_DIR_MOVED_TO=$OLD_ROLLBACK"
fi

mkdir -p "$TARGET_DIR"
# Copy only release files; runtime secrets/database/uploads are restored from backup.
tar \
  --exclude='./.env' \
  --exclude='./pricebot.db' \
  --exclude='./pricebot.db-*' \
  --exclude='./uploads' \
  --exclude='./venv' \
  --exclude='./__pycache__' \
  --exclude='./backups' \
  --exclude='./logs' \
  --exclude='*.pyc' \
  --exclude='*.pyo' \
  --exclude='*.db' \
  --exclude='*.sqlite' \
  --exclude='*.zip' \
  --exclude='*.tar.gz' \
  -C "$RELEASE_DIR" -cf - . | tar -C "$TARGET_DIR" -xf -

cp -a "$BACKUP_DIR/.env" "$TARGET_DIR/.env"
cp -a "$BACKUP_DIR/pricebot.db" "$TARGET_DIR/pricebot.db"
cp -a "$BACKUP_DIR/uploads" "$TARGET_DIR/uploads" 2>/dev/null || mkdir -p "$TARGET_DIR/uploads"
chmod 600 "$TARGET_DIR/.env" || true
chmod +x "$TARGET_DIR/start_pricebot.sh" "$TARGET_DIR/clean_install_pricebot.sh" || true
find "$TARGET_DIR" -type d -name __pycache__ -prune -exec rm -rf {} + || true
find "$TARGET_DIR" -type f \( -name '*.pyc' -o -name '*.pyo' -o -name '*.zip' -o -name '*.tar.gz' \) -delete || true

cd "$TARGET_DIR"
python3 -m venv venv
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
./venv/bin/python -m compileall -q .

# Apply additive schema migrations only. This must not rebuild or replace products.
PRICEBOT_DB_PATH="$TARGET_DIR/pricebot.db" ./venv/bin/python - <<'PY'
import database
from services import observability
try:
    from services.vision import image_cache
except Exception:
    image_cache = None
observability.ensure_schema()
if image_cache is not None:
    image_cache.ensure_schema()
with database.connect() as conn:
    for table in ['products','product_identity_registry','product_search_index','guided_catalog_index']:
        try:
            print(f'{table}=', conn.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0])
        except Exception as exc:
            print(f'{table}=ERROR:{exc}')
PY

cat > "$SERVICE_PATH" <<EOF_SERVICE
[Unit]
Description=PriceBot WhatsApp Pharmacy Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=$TARGET_DIR
ExecStart=$TARGET_DIR/start_pricebot.sh
Restart=always
RestartSec=5
User=root
Environment=PRICEBOT_APP_DIR=$TARGET_DIR
Environment=PRICEBOT_ENV_FILE=$TARGET_DIR/.env
Environment=PRICEBOT_DB_PATH=$TARGET_DIR/pricebot.db

[Install]
WantedBy=multi-user.target
EOF_SERVICE

systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
systemctl restart "$SERVICE_NAME"
sleep 3
systemctl status "$SERVICE_NAME" --no-pager -l || true
curl -fsS --max-time 5 "$HEALTH_URL" || true
printf '\nSAFE_INSTALL_OK=1\n'
echo "TARGET_DIR=$TARGET_DIR"
echo "DB_MODE=preserved_existing_pricebot_db"
echo "ROLLBACK_DIR=$OLD_ROLLBACK"

cat > "$TARGET_DIR/ROLLBACK_INFO.txt" <<EOF_INFO
Safe install timestamp: $STAMP
Backup directory: $BACKUP_DIR
Old rollback directory: $OLD_ROLLBACK
Database mode: preserved existing $TARGET_DIR/pricebot.db; no Excel rebuild; no product replace.
To rollback manually:
  sudo systemctl stop $SERVICE_NAME
  sudo cp -a $BACKUP_DIR/pricebot.service $SERVICE_PATH  # if file exists
  sudo rm -rf $TARGET_DIR
  sudo mv $OLD_ROLLBACK $TARGET_DIR
  sudo systemctl daemon-reload
  sudo systemctl start $SERVICE_NAME
Do not delete $OLD_ROLLBACK for at least 48 hours.
EOF_INFO
