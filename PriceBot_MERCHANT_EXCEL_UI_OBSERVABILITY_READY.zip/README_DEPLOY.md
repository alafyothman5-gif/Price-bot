# PriceBot deploy notes

النشر في السيرفر الحقيقي يجب أن يكون على المسار النشط فقط:

```bash
/opt/pricebot_clean
```

المسار `/opt/pricebot` يعتبر shortcut فقط ولا يُستخدم كمسار نشر مستقل.

## ممنوع قبل النشر

- لا تلمس MedMCQ.
- لا تحذف `/opt/pricebot_clean/pricebot.db`.
- لا تستبدل `.env`.
- لا ترفع `.env` أو `pricebot.db` إلى GitHub.
- لا تعمل replace كامل للمنتجات بدون backup وstaging.

## نشر ZIP جديد بأمان

استخدم السكربت المرفق من مجلد فك الضغط. السكربت يحافظ على `.env` و`pricebot.db` و`uploads`، ولا يعيد بناء قاعدة المنتجات من Excel.

```bash
set -e
cd /root
rm -rf /root/pricebot_release
mkdir -p /root/pricebot_release
unzip -q /root/PriceBot_MERCHANT_EXCEL_UI_OBSERVABILITY_READY.zip -d /root/pricebot_release
cd /root/pricebot_release
sudo PRICEBOT_TARGET_DIR=/opt/pricebot_clean PRICEBOT_SERVICE_NAME=pricebot.service ./clean_install_pricebot.sh
```

يجب أن تظهر في الخرج:

```text
SAFE_DB_MODE=preserve_existing_db_no_rebuild
SAFE_INSTALL_OK=1
DB_MODE=preserved_existing_pricebot_db
```

## فحص قاعدة البيانات بعد النشر

```bash
cd /opt/pricebot_clean
./venv/bin/python - <<'PY'
import sqlite3
conn = sqlite3.connect('/opt/pricebot_clean/pricebot.db')
for table in ['products','product_identity_registry','product_search_index','guided_catalog_index']:
    try:
        print(table, conn.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0])
    except Exception as e:
        print(table, 'ERROR', e)
conn.close()
PY
```

## رفع Excel من لوحة التاجر

- افتح `/merchant/catalog/upload` أو صفحة المنتجات.
- الافتراضي هو `تحديث أسعار فقط`.
- لا تختار `ملف كامل لكل منتجات الصيدلية` إلا عندما يكون الملف يحتوي كل منتجات الصيدلية.
- بعد التحليل افتح التقرير، ثم اضغط `اعتماد التحديث` أو افتح `مراجعة المنتجات المشكوك فيها`.

## صفحات الإدارة الجديدة

- `/admin/failed-searches`
- `/admin/image-debug`
- `/admin/synonyms`
- `/merchant/products/edit`
- `/merchant/catalog/review`
