# تقرير تسليم PriceBot_MERCHANT_EXCEL_UI_OBSERVABILITY_READY

## ما تم تنفيذه

تم تنفيذ حزمة تحسين آمنة فوق النسخة الشغالة الحالية، بدون تغيير مسار التشغيل، وبدون تضمين قاعدة البيانات أو ملف الأسرار.

### 1. واجهة رفع Excel مبسطة

- إضافة/تثبيت صفحة رفع واضحة عبر:
  - `/merchant/catalog/upload`
  - وصفحة الكتالوج الحالية في لوحة التاجر.
- الخيار الافتراضي دائمًا هو: `تحديث أسعار فقط`.
- خيار `ملف كامل لكل منتجات الصيدلية` لا يتم اختياره تلقائيًا، ومعه تحذير واضح.
- تقرير الرفع أصبح يعرض للتاجر أرقامًا مفهومة بدل المصطلحات التقنية.
- صفحة التقرير تحتوي أزرار: عرض التفاصيل، اعتماد التحديث، مراجعة المنتجات المشكوك فيها، إلغاء الرفع.

### 2. تثبيت منطق Excel المحافظ

- السعر الجديد لنفس المنتج الواضح يعتبر تحديث سعر طبيعي، وليس conflict.
- تكرار نفس المنتج بنفس السعر يتم دمجه تلقائيًا.
- تكرار نفس المنتج بسعر مختلف يعتمد آخر سعر إذا كانت الهوية واضحة، مع warning فقط.
- الأسماء الغامضة مثل `Flagyl` وحده تبقى للمراجعة ولا يتم تحديث السعر عشوائيًا.
- المنتجات التي لا تظهر في ملف أسبوعي تبقى report-only ولا تصبح unavailable تلقائيًا.
- تحويل المنتجات إلى unavailable يحتاج اختيار `Full inventory upload` صراحة عند الاعتماد.

### 3. صفحة مراجعة المنتجات المشكوك فيها

تمت إضافة صفحة:

- `/merchant/catalog/review`

تعرض عناصر المراجعة، الاسم الخام، السعر، سبب المراجعة، والاقتراحات إن وجدت، مع خيارات الحفظ/التجاهل حسب البيانات المتاحة في job report.

### 4. صفحة Failed Searches

تمت إضافة صفحة:

- `/admin/failed-searches`

تعرض آخر عمليات البحث التي لم تنتهِ بمطابقة ناجحة، مع:

- وقت الرسالة
- معرف عميل مخفي/hash
- النص الأصلي
- النص بعد التنظيف
- قرار المطابقة
- سبب الفشل
- المنتج المطابق إن وجد
- زر تجاهل
- زر إضافة alias وربطه بمنتج موجود

### 5. صفحة Image Debug

تمت إضافة صفحة:

- `/admin/image-debug`

تعرض آخر الصور الفاشلة أو LOW_CONFIDENCE، مع:

- وقت الصورة
- raw vision response
- visible_text
- cleaned OCR
- candidate queries
- selected candidate
- matcher decision
- matched_product_id
- سبب الفشل
- زر ربط الصورة بمنتج
- زر اعتبار الصورة غير واضحة/تجاهل

### 6. تحسين مسار الصور بدون كسر OCR bridge

تم الحفاظ على المسار المحافظ:

Vision → OCR Cleaner → Candidate Query Extraction → Excel Native Matcher → Decision

والإضافة الجديدة:

- عدم الاعتماد على raw visible_text الطويل وحده.
- تسجيل candidate queries وقرار المطابقة في Image Debug.
- عدم تحويل فشل Vision مباشرة إلى “لم أجد المنتج”.
- عند فشل/timeout Vision تظهر رسالة أوضح للزبون تطلب كتابة الاسم أو صورة أوضح.

### 7. Image Cache آمن

تمت إضافة Cache آمن للصور في:

- `services/vision/image_cache.py`

السلوك:

- يحفظ فقط الصور التي وصلت إلى `EXACT_MATCH`.
- يربط `image_hash / image_phash` مع `product_id`.
- لا يحفظ الفشل طويلًا أثناء التطوير.
- لا يستخدم الكاش إذا المنتج غير موجود أو غير متوفر في قاعدة البيانات.

### 8. Vision Queue وTimeout

تمت إضافة حماية للصور:

- `PRICEBOT_VISION_MAX_CONCURRENT` الافتراضي 2.
- `PRICEBOT_VISION_TIMEOUT_SECONDS` الافتراضي 10 ثوانٍ.
- إذا تأخر Vision، لا يعلق الطلب، ويرد برسالة واضحة.

### 9. صفحة تعديل منتج واحد

تمت إضافة صفحة:

- `/merchant/products/edit`

تسمح بالبحث عن منتج وتعديل:

- السعر
- التوفر
- aliases
- OCR keywords
- canonical_display_name

أي تعديل يعيد بناء فهارس المنتج قدر الإمكان ويُسجل في audit log.

### 10. canonical_display_name

تمت إضافة/تثبيت عمود:

- `canonical_display_name`

ويتم استخدامه في واجهة التعديل ويمكن استعماله لعرض اسم مصحح للزبون بدل raw Excel name.

### 11. قاموس التصحيحات والمرادفات

تمت إضافة صفحة:

- `/admin/synonyms`

وتطبيق dynamic synonyms على:

- Excel ingestion normalization
- Excel native matcher normalization

مثال: `PETROLEEUM → PETROLEUM` أو `Cera Ve → Cerave`.

### 12. Dashboard مبسط

تم تحسين لوحة الأدمن لإظهار:

- عدد الرسائل اليوم
- عدد الصور اليوم
- نسبة نجاح الصور
- متوسط زمن الرد
- عدد Vision calls
- تقدير تكلفة Vision عند توفر السعر من env
- أكثر المنتجات بحثًا
- أكثر عمليات البحث الفاشلة

### 13. Logging منظم

تمت إضافة خدمة:

- `services/observability.py`

وتسجل:

Text:
- original_text
- cleaned_text
- extracted_slots
- matcher_decision
- matched_product_id
- reason
- response_ms

Images:
- image_hash
- raw_visible_text
- cleaned_visible_text
- candidate_queries
- selected_candidate
- matcher_decision
- matched_product_id
- reason
- response_ms

Excel:
- report/job summary من نظام catalog ingestion الحالي.

## الملفات الأساسية التي تغيرت أو أضيفت

- `app.py`
- `admin.py`
- `merchant.py`
- `ui_flow.py`
- `README_DEPLOY.md`
- `services/observability.py`
- `services/vision/image_cache.py`
- `services/catalog/catalog_ingestion_master.py`
- `services/matching/excel_native_matcher.py`
- `templates/admin_dashboard.html`
- `templates/admin_failed_searches.html`
- `templates/admin_image_debug.html`
- `templates/admin_synonyms.html`
- `templates/merchant_catalog.html`
- `templates/merchant_catalog_job.html`
- `templates/merchant_review_items.html`
- `templates/merchant_edit_product.html`
- `templates/merchant_products.html`

## كيف ترفع Excel

1. افتح لوحة التاجر.
2. ادخل إلى `/merchant/catalog/upload`.
3. ارفع ملف Excel.
4. اترك الخيار الافتراضي `تحديث أسعار فقط` للرفع الأسبوعي.
5. بعد ظهور التقرير:
   - اضغط `اعتماد التحديث` إذا كل شيء واضح.
   - أو افتح `مراجعة المنتجات المشكوك فيها` إذا توجد عناصر تحتاج مراجعة.

## أين تجد الصفحات

- تقرير الرفع: `/merchant/catalog`
- مراجعة المنتجات المشكوك فيها: `/merchant/catalog/review`
- تعديل منتج واحد: `/merchant/products/edit`
- Failed Searches: `/admin/failed-searches`
- Image Debug: `/admin/image-debug`
- التصحيحات والمرادفات: `/admin/synonyms`
- Dashboard: `/admin`

## أوامر النشر على السيرفر

النشر يجب أن يكون فقط على:

```bash
/opt/pricebot_clean
```

ولا يتم استخدام `/opt/pricebot` كمسار نشر مستقل.

الأمر المختصر الآمن مذكور في `README_DEPLOY.md` داخل ZIP.

## نتائج الاختبارات

تم تشغيل:

```bash
python -m compileall -q .
PYTHONPATH=. PRICEBOT_DB_PATH=/tmp/pricebot_catalog_test.sqlite python tests/test_catalog_ingestion_master.py
PYTHONPATH=. PRICEBOT_DB_PATH=/tmp/pricebot_obs_test.sqlite python observability smoke test
```

النتيجة:

- compileall: PASS
- Catalog ingestion master: PASS
- Observability smoke test: PASS

ملاحظة: لم يتم اختبار واتساب الحقيقي أو قاعدة السيرفر الحقيقية داخل sandbox، لذلك لا يوجد ادعاء بأن النشر تم على السيرفر.

## تأكيدات السلامة

- لم يتم لمس MedMCQ.
- ZIP لا يحتوي `.env`.
- ZIP لا يحتوي `pricebot.db`.
- ZIP لا يحتوي `venv`.
- ZIP لا يحتوي backups أو logs كبيرة أو old ZIPs.
- التعديلات لا تضيف AI لاتخاذ قرار السعر أو التوفر.
- السعر والتوفر ما زالا من قاعدة البيانات فقط.
- لم يتم إرجاع legacy fuzzy/random matching.
- المسار المعتمد في تعليمات النشر هو `/opt/pricebot_clean`.
