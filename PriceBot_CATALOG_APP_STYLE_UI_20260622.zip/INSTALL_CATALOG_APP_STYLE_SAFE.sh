#!/usr/bin/env bash
set -euo pipefail

TARGET="${TARGET:-/opt/pricebot_clean}"
SERVICE="${SERVICE:-pricebot.service}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%F_%H-%M-%S)"
BACKUP_DIR="$TARGET/backups/catalog_app_style_$STAMP"
PY="$TARGET/venv/bin/python"

if [ ! -d "$TARGET" ]; then
  echo "ERROR: target project folder not found: $TARGET" >&2
  exit 1
fi

if [ ! -x "$PY" ]; then
  if [ -x "$TARGET/.venv/bin/python" ]; then
    PY="$TARGET/.venv/bin/python"
  else
    PY="python3"
  fi
fi

echo "===== Backup current catalog/app files ====="
mkdir -p "$BACKUP_DIR"
[ -f "$TARGET/app.py" ] && cp -a "$TARGET/app.py" "$BACKUP_DIR/app.py.bak"
[ -f "$TARGET/catalog_web.py" ] && cp -a "$TARGET/catalog_web.py" "$BACKUP_DIR/catalog_web.py.bak"
[ -f "$TARGET/.env" ] && cp -a "$TARGET/.env" "$BACKUP_DIR/.env.bak"
# Do NOT copy pricebot.db here: this is a UI-only patch and does not touch DB.
echo "Backup saved to: $BACKUP_DIR"

echo "===== Copy app-style catalog UI only ====="
cp -a "$SRC_DIR/catalog_web.py" "$TARGET/catalog_web.py"
[ -f "$SRC_DIR/VERIFY_CATALOG_SITE.sh" ] && cp -a "$SRC_DIR/VERIFY_CATALOG_SITE.sh" "$TARGET/VERIFY_CATALOG_SITE.sh"
[ -f "$SRC_DIR/ROLLBACK_CATALOG_SITE_LAST_BACKUP.sh" ] && cp -a "$SRC_DIR/ROLLBACK_CATALOG_SITE_LAST_BACKUP.sh" "$TARGET/ROLLBACK_CATALOG_SITE_LAST_BACKUP.sh"
[ -f "$SRC_DIR/README_CATALOG_APP_STYLE_AR.md" ] && cp -a "$SRC_DIR/README_CATALOG_APP_STYLE_AR.md" "$TARGET/README_CATALOG_APP_STYLE_AR.md"
chmod +x "$TARGET/VERIFY_CATALOG_SITE.sh" "$TARGET/ROLLBACK_CATALOG_SITE_LAST_BACKUP.sh" 2>/dev/null || true

echo "===== Ensure app.py includes catalog router idempotently ====="
"$PY" - <<'PY'
from pathlib import Path
p = Path('/opt/pricebot_clean/app.py')
s = p.read_text()
if 'import catalog_web' not in s:
    if 'import portal' in s:
        s = s.replace('import portal\n', 'import portal\nimport catalog_web\n', 1)
    else:
        lines = s.splitlines()
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith('import ') or line.startswith('from '):
                insert_at = i + 1
        lines.insert(insert_at, 'import catalog_web')
        s = '\n'.join(lines) + '\n'
if 'app.include_router(catalog_web.router)' not in s:
    if 'app.include_router(portal.router)' in s:
        s = s.replace('app.include_router(portal.router)\n', 'app.include_router(portal.router)\napp.include_router(catalog_web.router)\n', 1)
    else:
        first_router = s.find('app.include_router(')
        if first_router != -1:
            line_end = s.find('\n', first_router)
            s = s[:line_end+1] + 'app.include_router(catalog_web.router)\n' + s[line_end+1:]
        else:
            marker = 'app = FastAPI'
            idx = s.find(marker)
            if idx == -1:
                raise SystemExit('Could not find FastAPI app initialization')
            line_end = s.find('\n', idx)
            s = s[:line_end+1] + 'app.include_router(catalog_web.router)\n' + s[line_end+1:]
p.write_text(s)
PY

echo "===== Compile critical files ====="
"$PY" -m py_compile "$TARGET/app.py" "$TARGET/catalog_web.py"

echo "===== Restart service ====="
systemctl restart "$SERVICE"
sleep 5

echo "===== Catalog local health ====="
curl -s http://127.0.0.1:8090/catalog-health || true
echo

echo "DONE. Open: https://46.101.148.246.sslip.io/catalog?v=app2"
