# Master Identity Build Report

Status: code-level acceptance completed in sandbox.

Important note: the real server database `/opt/pricebot_clean/pricebot.db` with `products_count=5791` is not included in this ZIP, by design. Therefore the report spreadsheets in the ZIP are seed/placeholders. Run this on the server to generate the real 5791-product reports:

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/build_master_identity_catalog.py --output-dir identity_reports
```

Implemented:

- `products_master_identity` table.
- `identity_review_queue` table.
- `ocr_keywords` table.
- `product_identity_overlay` integration.
- `visual_product_memory` integration.
- `tools/build_master_identity_catalog.py`.
- Master identity enrichment inside `services/matching/excel_native_matcher.py`.
- Admin pages:
  - `/admin/identity`
  - `/admin/visual-training`

Safety:

- The builder does not edit `products.name` or Excel files.
- Prices remain sourced from `products` / weekly Excel approval only.
- Images still require user confirmation before price/availability.
- Weak/incomplete identities are sent to `NEEDS_IDENTITY_REVIEW`.
