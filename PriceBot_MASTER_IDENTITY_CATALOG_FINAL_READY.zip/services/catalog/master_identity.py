from __future__ import annotations

"""Master Product Identity Catalog for PriceBot.

This is a derived identity layer above the merchant Excel/products table.  It
never deletes products, never rewrites the merchant Excel name, and never
changes price by itself.  Search, image matching, and catalog review can use the
identity fields here for safer decisions while products remains the operational
source of price/availability.
"""

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import database
from normalizer import normalize_text, split_multi
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths, normalize_measure
from services.catalog.identity_generation import (
    KNOWN_BRAND_SEEDS,
    WEAK_TOKENS as IDENTITY_WEAK_TOKENS,
    BrandFamilyNormalizer,
    CatalogAliasGenerator,
)

DEFAULT_MERCHANT_ID = 1

GENERIC_IDENTITY_WORDS = set(IDENTITY_WEAK_TOKENS) | {
    "low", "ph", "daily", "normal", "oily", "dry", "sensitive", "acne", "anti", "age",
    "cleanser", "cream", "gel", "lotion", "serum", "wash", "shampoo", "spray", "drops",
    "syrup", "suspension", "tablet", "tablets", "capsule", "capsules", "solution",
    "غسول", "كريم", "جل", "لوشن", "شراب", "حبوب", "قطرة", "بخاخ", "محلول",
}

# Seed brands are generic catalog knowledge, not product-specific fixes.
KNOWN_BRANDS = {normalize_text(x) for x in KNOWN_BRAND_SEEDS if normalize_text(x)}


@dataclass
class IdentityBuildStats:
    total_products: int = 0
    auto_approved: int = 0
    needs_review: int = 0
    missing_brand: int = 0
    missing_form_strength_size: int = 0
    weak_names: int = 0
    duplicates: int = 0
    overlay_seeded: int = 0
    ocr_keywords: int = 0


def _n(value: Any) -> str:
    return normalize_text(value)


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple, set)):
        return " | ".join(_text(v) for v in value if v is not None)
    return str(value).strip()


def _tokens(value: Any) -> List[str]:
    return [t for t in _n(value).split() if t]


def _strong_tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in _tokens(value):
        if t in GENERIC_IDENTITY_WORDS:
            continue
        if len(t) <= 2 and not t.isdigit():
            continue
        if t.isdigit():
            continue
        if t not in out:
            out.append(t)
    return out


def _merge_parts(*values: Any, limit: int = 50) -> str:
    out: List[str] = []
    seen: set[str] = set()
    for value in values:
        parts = value if isinstance(value, (list, tuple, set)) else split_multi(value)
        if isinstance(value, str) and not any(sep in value for sep in ("|", ";", ",")):
            parts = [value]
        for part in parts:
            raw = _text(part)
            norm = _n(raw)
            if not raw or not norm or norm in seen:
                continue
            seen.add(norm)
            out.append(raw)
            if len(out) >= limit:
                return " | ".join(out)
    return " | ".join(out)


def _measure_first(values: Sequence[str]) -> str:
    for value in values:
        m = normalize_measure(value)
        if m:
            return m
    return ""


def _extract_strength(text: str) -> str:
    return _measure_first(extract_strengths(text))


def _extract_size(text: str) -> str:
    return _measure_first(extract_sizes(text))


def _extract_pack(text: str) -> str:
    return _measure_first(extract_packs(text))


def _known_brand_in_text(text: str) -> str:
    norm = f" {_n(text)} "
    for brand in sorted(KNOWN_BRANDS, key=len, reverse=True):
        if f" {brand} " in norm:
            return brand
    return ""


def _brand_display(brand: str, source: str = "") -> str:
    brand = _n(brand)
    if not brand:
        return ""
    for tok in str(source or "").replace("-", " ").split():
        if _n(tok) == brand:
            return tok.strip(" ,;/()[]")
    special = {"mebo": "MEBO", "prod3": "Pro-D3", "pro d3": "Pro-D3"}
    if brand in special:
        return special[brand]
    return " ".join(p.upper() if len(p) <= 3 and p.isalpha() else p.capitalize() for p in brand.split())


def _detect_brand(row: Dict[str, Any]) -> str:
    explicit = _n(row.get("brand") or row.get("company") or "")
    if explicit and explicit not in GENERIC_IDENTITY_WORDS:
        return explicit
    name = _text(row.get("canonical_display_name") or row.get("name") or row.get("original_name"))
    known = _known_brand_in_text(name)
    if known:
        return known
    return ""


def _family_from_name(row: Dict[str, Any], brand: str) -> str:
    explicit = _n(row.get("product_family") or "")
    if explicit and explicit not in GENERIC_IDENTITY_WORDS:
        return explicit
    name_norm = _n(row.get("canonical_display_name") or row.get("name") or row.get("original_name"))
    if brand:
        name_norm = re.sub(r"(^|\s)" + re.escape(brand) + r"(?=\s|$)", " ", name_norm)
    toks = [t for t in name_norm.split() if t and t not in GENERIC_IDENTITY_WORDS and not normalize_measure(t)]
    return " ".join(toks[:5]).strip()


def ensure_schema() -> None:
    """Create Master Identity Catalog tables only; do not mutate product rows."""
    with database.connect() as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS products_master_identity (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER NOT NULL,
                original_excel_name TEXT DEFAULT '',
                normalized_original_name TEXT DEFAULT '',
                canonical_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                category TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                active_ingredient TEXT DEFAULT '',
                cosmetic_type TEXT DEFAULT '',
                use_case TEXT DEFAULT '',
                skin_type TEXT DEFAULT '',
                aliases TEXT DEFAULT '',
                ocr_keywords TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                price TEXT DEFAULT '',
                available INTEGER DEFAULT 1,
                identity_status TEXT DEFAULT 'NEEDS_IDENTITY_REVIEW',
                review_status TEXT DEFAULT 'PENDING',
                notes TEXT DEFAULT '',
                source TEXT DEFAULT 'auto_enrichment',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(merchant_id, product_id)
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_master_identity_brand ON products_master_identity(merchant_id, brand, form, strength, size)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_master_identity_status ON products_master_identity(identity_status, review_status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_master_identity_original ON products_master_identity(merchant_id, normalized_original_name)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS identity_review_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER,
                original_excel_name TEXT DEFAULT '',
                normalized_original_name TEXT DEFAULT '',
                issue_type TEXT DEFAULT '',
                status TEXT DEFAULT 'PENDING',
                suggested_json TEXT DEFAULT '{}',
                notes TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                resolved_at TEXT,
                resolved_by TEXT DEFAULT ''
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_review_status ON identity_review_queue(status, issue_type, created_at)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS ocr_keywords (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER NOT NULL,
                keyword TEXT NOT NULL,
                keyword_normalized TEXT NOT NULL,
                source TEXT DEFAULT 'master_identity',
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(merchant_id, product_id, keyword_normalized)
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ocr_keywords_lookup ON ocr_keywords(merchant_id, keyword_normalized, is_active)")


def _load_overlays(merchant_id: int = DEFAULT_MERCHANT_ID) -> Dict[str, Dict[str, Any]]:
    with database.connect() as conn:
        try:
            rows = conn.execute(
                "SELECT * FROM product_identity_overlay WHERE merchant_id=? AND is_active=1",
                (int(merchant_id or DEFAULT_MERCHANT_ID),),
            ).fetchall()
        except Exception:
            return {}
    return {str(database.dict_row(r).get("normalized_excel_name") or ""): database.dict_row(r) for r in rows if r}


def identity_from_product(row: Dict[str, Any], overlays: Optional[Dict[str, Dict[str, Any]]] = None, merchant_id: int = DEFAULT_MERCHANT_ID) -> Dict[str, Any]:
    """Return a conservative derived identity for one products row."""
    overlays = overlays or {}
    source_name = _text(row.get("name") or row.get("original_name") or row.get("normalized_name"))
    normalized_original = _n(row.get("normalized_name") or source_name)
    overlay = overlays.get(normalized_original) or {}

    brand = _n(overlay.get("brand") or _detect_brand(row))
    brand_display = _text(overlay.get("brand") or _brand_display(brand, source_name))
    family = _n(overlay.get("product_family") or _family_from_name(row, brand))
    form = canonical_form(overlay.get("form") or row.get("form") or row.get("medicine_form") or row.get("product_type") or source_name) or _n(overlay.get("form") or row.get("form") or "")
    strength = normalize_measure(overlay.get("strength") or row.get("strength") or "") or _extract_strength(source_name)
    size = normalize_measure(overlay.get("size") or row.get("size") or "") or _extract_size(source_name)
    pack = normalize_measure(overlay.get("pack") or row.get("pack") or "") or _extract_pack(source_name)

    if overlay.get("canonical_name"):
        canonical = _text(overlay.get("canonical_name"))
        identity_status = "reviewed" if str(overlay.get("source") or "") == "manual" else "auto_enriched"
        review_status = "APPROVED"
    else:
        parts: List[str] = []
        if brand_display:
            parts.append(brand_display)
        elif source_name:
            # Keep raw name visible, but mark missing brand below.
            parts.append(source_name)
        if family and brand and family not in _n(" ".join(parts)):
            parts.append(" ".join(p.capitalize() for p in family.split()))
        for extra in [form, strength, size, pack]:
            if extra and _n(extra) not in _n(" ".join(parts)):
                parts.append(extra)
        canonical = re.sub(r"\s+", " ", " ".join(parts)).strip() or source_name
        identity_status = "auto_enriched"
        review_status = "APPROVED"

    active_ingredient = _text(row.get("active_ingredient") or row.get("ingredient") or "")
    cosmetic_type = form if form in {"cleanser", "cream", "gel", "lotion", "serum", "toner", "shampoo", "spray", "sunscreen", "moisturizer"} else _text(row.get("cosmetic_type") or "")
    category = _text(row.get("category") or row.get("main_section") or row.get("section") or "")

    aliases: List[str] = []
    ocr: List[str] = []
    generator = CatalogAliasGenerator(BrandFamilyNormalizer(()))
    try:
        gen_aliases, gen_ocr = generator.identity_variations({**row, "brand": brand_display, "product_family": family, "name": canonical, "form": form, "strength": strength, "size": size, "pack": pack})
        aliases.extend(gen_aliases)
        ocr.extend(gen_ocr)
    except Exception:
        pass
    aliases.extend([source_name, canonical, _text(row.get("aliases")), _text(overlay.get("original_excel_name"))])
    if brand_display and family:
        aliases.extend([f"{brand_display} {family}", f"{family} {form}" if form else family])
    if active_ingredient and brand_display:
        aliases.append(f"{active_ingredient} {brand_display} {form}".strip())
    ocr.extend([canonical, brand_display, family, _text(row.get("ocr_keywords")), _text(overlay.get("ocr_keywords"))])
    for extra in [strength, size, pack, form]:
        if extra:
            ocr.append(extra)

    issues: List[str] = []
    if not brand:
        issues.append("MISSING_BRAND")
    if not any([form, strength, size]):
        issues.append("MISSING_FORM_STRENGTH_SIZE")
    toks = _tokens(source_name)
    if len(toks) <= 2 or not _strong_tokens(source_name):
        issues.append("WEAK_NAME")
    if issues and not overlay:
        identity_status = "NEEDS_IDENTITY_REVIEW"
        review_status = "PENDING"
    notes = "; ".join(sorted(set(issues)))

    try:
        product_id = int(row.get("id") or row.get("product_id") or 0)
    except Exception:
        product_id = 0
    return {
        "merchant_id": int(merchant_id or DEFAULT_MERCHANT_ID),
        "product_id": product_id,
        "original_excel_name": source_name,
        "normalized_original_name": normalized_original,
        "canonical_name": canonical,
        "brand": brand_display or brand,
        "product_family": family,
        "category": category,
        "form": form,
        "strength": strength,
        "size": size,
        "pack": pack,
        "active_ingredient": active_ingredient,
        "cosmetic_type": cosmetic_type,
        "use_case": _text(row.get("use_case") or ""),
        "skin_type": _text(row.get("skin_type") or ""),
        "aliases": _merge_parts(aliases),
        "ocr_keywords": _merge_parts(ocr),
        "barcode": _text(row.get("barcode") or ""),
        "price": _text(row.get("price") or ""),
        "available": 1 if str(row.get("available", "1")).lower() not in {"0", "false", "no", "غير متوفر"} else 0,
        "identity_status": identity_status,
        "review_status": review_status,
        "notes": notes,
        "source": "overlay" if overlay else "auto_enrichment",
    }


def upsert_identity(identity: Dict[str, Any]) -> None:
    ensure_schema()
    fields = [
        "merchant_id", "product_id", "original_excel_name", "normalized_original_name", "canonical_name",
        "brand", "product_family", "category", "form", "strength", "size", "pack", "active_ingredient",
        "cosmetic_type", "use_case", "skin_type", "aliases", "ocr_keywords", "barcode", "price", "available",
        "identity_status", "review_status", "notes", "source",
    ]
    values = [identity.get(f, "") for f in fields]
    with database.connect() as conn:
        conn.execute(
            f"""
            INSERT INTO products_master_identity({','.join(fields)}, created_at, updated_at)
            VALUES({','.join(['?']*len(fields))}, datetime('now'), datetime('now'))
            ON CONFLICT(merchant_id, product_id) DO UPDATE SET
                original_excel_name=excluded.original_excel_name,
                normalized_original_name=excluded.normalized_original_name,
                canonical_name=excluded.canonical_name,
                brand=excluded.brand,
                product_family=excluded.product_family,
                category=excluded.category,
                form=excluded.form,
                strength=excluded.strength,
                size=excluded.size,
                pack=excluded.pack,
                active_ingredient=excluded.active_ingredient,
                cosmetic_type=excluded.cosmetic_type,
                use_case=excluded.use_case,
                skin_type=excluded.skin_type,
                aliases=excluded.aliases,
                ocr_keywords=excluded.ocr_keywords,
                barcode=excluded.barcode,
                price=excluded.price,
                available=excluded.available,
                identity_status=excluded.identity_status,
                review_status=excluded.review_status,
                notes=excluded.notes,
                source=excluded.source,
                updated_at=datetime('now')
            """,
            values,
        )
        if identity.get("review_status") == "PENDING":
            conn.execute(
                """
                INSERT INTO identity_review_queue(merchant_id, product_id, original_excel_name, normalized_original_name, issue_type, status, suggested_json, notes, created_at, updated_at)
                VALUES(?,?,?,?,?,'PENDING',?,?,datetime('now'),datetime('now'))
                """,
                (
                    identity.get("merchant_id", DEFAULT_MERCHANT_ID),
                    identity.get("product_id"),
                    identity.get("original_excel_name", ""),
                    identity.get("normalized_original_name", ""),
                    identity.get("notes") or "NEEDS_IDENTITY_REVIEW",
                    json.dumps(identity, ensure_ascii=False),
                    identity.get("notes") or "",
                ),
            )
        for kw in split_multi(identity.get("ocr_keywords")):
            norm = _n(kw)
            if norm:
                conn.execute(
                    """
                    INSERT OR IGNORE INTO ocr_keywords(merchant_id, product_id, keyword, keyword_normalized, source, is_active, created_at)
                    VALUES(?,?,?,?, 'master_identity', 1, datetime('now'))
                    """,
                    (identity.get("merchant_id", DEFAULT_MERCHANT_ID), identity.get("product_id"), kw, norm),
                )


def build_master_identity_catalog(rows: Optional[Sequence[Dict[str, Any]]] = None, merchant_id: int = DEFAULT_MERCHANT_ID, write_db: bool = True) -> Tuple[List[Dict[str, Any]], IdentityBuildStats]:
    ensure_schema()
    if rows is None:
        rows = database.load_product_rows(visible_only=False, guided=False)
    overlays = _load_overlays(merchant_id=merchant_id)
    identities: List[Dict[str, Any]] = []
    stats = IdentityBuildStats(total_products=len(rows))
    seen_keys: Dict[str, int] = {}
    for row in rows:
        ident = identity_from_product(row, overlays=overlays, merchant_id=merchant_id)
        key = _n(" ".join([ident.get("brand", ""), ident.get("product_family", ""), ident.get("form", ""), ident.get("strength", ""), ident.get("size", ""), ident.get("pack", "")]))
        if key:
            seen_keys[key] = seen_keys.get(key, 0) + 1
        identities.append(ident)
    for ident in identities:
        key = _n(" ".join([ident.get("brand", ""), ident.get("product_family", ""), ident.get("form", ""), ident.get("strength", ""), ident.get("size", ""), ident.get("pack", "")]))
        if key and seen_keys.get(key, 0) > 1:
            ident["review_status"] = "PENDING"
            ident["identity_status"] = "NEEDS_IDENTITY_REVIEW"
            ident["notes"] = _merge_parts(ident.get("notes"), "DUPLICATE_IDENTITY")
            stats.duplicates += 1
        if ident.get("review_status") == "APPROVED":
            stats.auto_approved += 1
        else:
            stats.needs_review += 1
        notes = set(_n(ident.get("notes")).split())
        if "missing_brand" in notes:
            stats.missing_brand += 1
        if "missing_form_strength_size" in notes:
            stats.missing_form_strength_size += 1
        if "weak_name" in notes:
            stats.weak_names += 1
        if ident.get("source") == "overlay":
            stats.overlay_seeded += 1
        stats.ocr_keywords += len([x for x in split_multi(ident.get("ocr_keywords")) if _n(x)])
        if write_db:
            upsert_identity(ident)
    return identities, stats


def load_master_identities(merchant_id: int = DEFAULT_MERCHANT_ID, approved_only: bool = True) -> List[Dict[str, Any]]:
    ensure_schema()
    where = "WHERE merchant_id=?"
    params: List[Any] = [int(merchant_id or DEFAULT_MERCHANT_ID)]
    if approved_only:
        where += " AND review_status='APPROVED'"
    with database.connect() as conn:
        rows = conn.execute(f"SELECT * FROM products_master_identity {where} ORDER BY id", params).fetchall()
    return [database.dict_row(r) for r in rows if r]


def enrich_product_rows(rows: Iterable[Dict[str, Any]], merchant_id: int = DEFAULT_MERCHANT_ID) -> List[Dict[str, Any]]:
    """Attach approved Master Identity fields to product rows in memory only."""
    rows_list = [dict(r) for r in rows]
    try:
        identities = load_master_identities(merchant_id=merchant_id, approved_only=True)
    except Exception:
        return rows_list
    by_pid = {int(i.get("product_id") or 0): i for i in identities if int(i.get("product_id") or 0)}
    if not by_pid:
        return rows_list
    for p in rows_list:
        try:
            pid = int(p.get("id") or 0)
        except Exception:
            pid = 0
        ident = by_pid.get(pid)
        if not ident:
            continue
        for src, dst in [
            ("canonical_name", "canonical_display_name"), ("brand", "brand"), ("product_family", "product_family"),
            ("category", "category"), ("form", "form"), ("strength", "strength"), ("size", "size"), ("pack", "pack"),
            ("active_ingredient", "active_ingredient"), ("cosmetic_type", "cosmetic_type"), ("use_case", "use_case"),
            ("skin_type", "skin_type"), ("barcode", "barcode"),
        ]:
            val = _text(ident.get(src))
            if val:
                p[dst] = val
        p["aliases"] = _merge_parts(p.get("aliases"), ident.get("aliases"), ident.get("canonical_name"))
        p["ocr_keywords"] = _merge_parts(p.get("ocr_keywords"), ident.get("ocr_keywords"), ident.get("canonical_name"))
        p["master_identity_id"] = ident.get("id")
        p["master_identity_status"] = ident.get("identity_status")
    return rows_list


def search_by_vision_slots(slots: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID, limit: int = 5) -> List[Dict[str, Any]]:
    """Find approved identities using strict visible image fields.

    This returns product dictionaries enriched from products_master_identity.  The
    caller must still run strict_image_candidate_validator and ask for user
    confirmation before displaying price.
    """
    ensure_schema()
    brand = _n(slots.get("brand"))
    form = canonical_form(slots.get("form") or "") or _n(slots.get("form"))
    strength = normalize_measure(slots.get("strength") or "")
    size = normalize_measure(slots.get("size") or "")
    title = _n(slots.get("primary_title") or slots.get("product_name") or slots.get("foreground_product_text") or slots.get("query") or "")
    if not brand and not _strong_tokens(title):
        return []
    identities = load_master_identities(merchant_id=merchant_id, approved_only=True)
    matched: List[Dict[str, Any]] = []
    for ident in identities:
        ident_text = _n(" ".join(_text(ident.get(k)) for k in ["canonical_name", "brand", "product_family", "form", "strength", "size", "pack", "aliases", "ocr_keywords"]))
        if brand and brand not in ident_text:
            continue
        if form and form != (canonical_form(ident.get("form") or "") or _n(ident.get("form"))):
            continue
        if strength and strength not in ident_text:
            continue
        if size and size not in ident_text:
            continue
        title_tokens = _strong_tokens(title)
        if title_tokens and not all(t in ident_text for t in title_tokens[:3]):
            # Require the strongest visible title evidence to be present.  This
            # prevents an active ingredient from outranking a brand/title.
            continue
        product = database.get_product(int(ident.get("product_id") or 0)) if ident.get("product_id") else None
        if not product:
            continue
        product = dict(product)
        product.update({
            "canonical_display_name": ident.get("canonical_name") or product.get("name"),
            "brand": ident.get("brand") or product.get("brand"),
            "product_family": ident.get("product_family") or product.get("product_family"),
            "form": ident.get("form") or product.get("form"),
            "strength": ident.get("strength") or product.get("strength"),
            "size": ident.get("size") or product.get("size"),
            "pack": ident.get("pack") or product.get("pack"),
            "aliases": _merge_parts(product.get("aliases"), ident.get("aliases")),
            "ocr_keywords": _merge_parts(product.get("ocr_keywords"), ident.get("ocr_keywords")),
            "master_identity_id": ident.get("id"),
        })
        matched.append(product)
        if len(matched) >= limit:
            break
    return matched


def approve_identity(product_id: int, canonical_name: str, brand: str = "", form: str = "", strength: str = "", size: str = "", pack: str = "", aliases: str = "", ocr_keywords: str = "", merchant_id: int = DEFAULT_MERCHANT_ID, actor: str = "admin") -> bool:
    ensure_schema()
    product = database.get_product(int(product_id))
    if not product:
        return False
    ident = identity_from_product(product, overlays={}, merchant_id=merchant_id)
    ident.update({
        "canonical_name": canonical_name or ident.get("canonical_name"),
        "brand": brand or ident.get("brand"),
        "form": form or ident.get("form"),
        "strength": normalize_measure(strength) or strength or ident.get("strength"),
        "size": normalize_measure(size) or size or ident.get("size"),
        "pack": normalize_measure(pack) or pack or ident.get("pack"),
        "aliases": _merge_parts(ident.get("aliases"), aliases),
        "ocr_keywords": _merge_parts(ident.get("ocr_keywords"), ocr_keywords, canonical_name),
        "identity_status": "reviewed",
        "review_status": "APPROVED",
        "notes": _merge_parts(ident.get("notes"), f"reviewed_by={actor}"),
        "source": "manual",
    })
    upsert_identity(ident)
    with database.connect() as conn:
        conn.execute(
            "UPDATE identity_review_queue SET status='RESOLVED', resolved_at=datetime('now'), resolved_by=?, updated_at=datetime('now') WHERE product_id=? AND merchant_id=? AND status='PENDING'",
            (actor, int(product_id), int(merchant_id or DEFAULT_MERCHANT_ID)),
        )
    return True


__all__ = [
    "ensure_schema",
    "identity_from_product",
    "build_master_identity_catalog",
    "load_master_identities",
    "enrich_product_rows",
    "search_by_vision_slots",
    "approve_identity",
]
