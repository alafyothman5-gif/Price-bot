# Deploy Safety Report

Target path: `/opt/pricebot_clean`

Health check: `http://127.0.0.1:8090/health`

The ZIP does not include:

- `.env`
- `pricebot.db`
- `venv`
- `__pycache__`
- `.pyc`
- backups
- uploads
- secrets

Database safety:

- New tables are created with `CREATE TABLE IF NOT EXISTS`.
- No migration deletes products.
- No migration truncates `products`.
- `products.name` and the merchant Excel remain unchanged.
- Master identity is a derived layer only.

Required server-side run after deploy:

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/build_master_identity_catalog.py --output-dir identity_reports
sudo systemctl restart pricebot
curl -fsS http://127.0.0.1:8090/health
```

Expected deploy script success marker remains:

```text
DEPLOY_OK=1
```
