#!/usr/bin/env python3
from __future__ import annotations

"""Build the Master Product Identity Catalog for PriceBot.

The script reads current products, derives a safe identity layer, writes it to
SQLite tables, and emits review spreadsheets.  It never edits product names,
prices, or the merchant Excel file.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.catalog import master_identity  # noqa: E402

REPORT_NAMES = {
    "auto": "identity_auto_approved.xlsx",
    "review": "identity_needs_review.xlsx",
    "duplicates": "duplicate_identity_report.xlsx",
    "missing_brand": "missing_brand_report.xlsx",
    "missing_fss": "missing_form_strength_size_report.xlsx",
    "weak": "weak_names_report.xlsx",
    "alias": "alias_overlay_seed.xlsx",
    "ocr": "ocr_keywords_seed.xlsx",
}

HEADERS = [
    "product_id", "original_excel_name", "canonical_name", "brand", "product_family", "category",
    "form", "strength", "size", "pack", "active_ingredient", "cosmetic_type", "use_case",
    "skin_type", "aliases", "ocr_keywords", "barcode", "price", "available", "identity_status",
    "review_status", "notes",
]


def _write_xlsx(path: Path, rows: Iterable[Dict[str, Any]], headers: List[str] = HEADERS) -> None:
    # openpyxl is an optional report writer for local admin tooling; bot runtime
    # does not depend on these files.
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except Exception as exc:
        path.with_suffix(".csv").write_text(
            ",".join(headers) + "\n" + "\n".join(",".join(str(r.get(h, "")).replace(",", " ") for h in headers) for r in rows),
            encoding="utf-8",
        )
        print(f"WARN: openpyxl unavailable, wrote CSV fallback for {path.name}: {exc}")
        return
    wb = Workbook()
    ws = wb.active
    ws.title = "Report"
    ws.append(headers)
    for row in rows:
        ws.append([row.get(h, "") for h in headers])
    fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = "A2"
    for i, h in enumerate(headers, 1):
        width = min(42, max(12, len(h) + 2))
        if h in {"original_excel_name", "canonical_name", "aliases", "ocr_keywords", "notes"}:
            width = 36
        ws.column_dimensions[get_column_letter(i)].width = width
    wb.save(path)


def _filter(rows: List[Dict[str, Any]], needle: str) -> List[Dict[str, Any]]:
    n = needle.lower()
    return [r for r in rows if n in str(r.get("notes") or "").lower()]


def main() -> int:
    parser = argparse.ArgumentParser(description="Build PriceBot Master Product Identity Catalog")
    parser.add_argument("--output-dir", default="identity_reports", help="Directory for xlsx/md reports")
    parser.add_argument("--merchant-id", type=int, default=1)
    parser.add_argument("--no-db-write", action="store_true", help="Dry run: generate reports without writing DB")
    args = parser.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    identities, stats = master_identity.build_master_identity_catalog(merchant_id=args.merchant_id, write_db=not args.no_db_write)
    auto = [r for r in identities if r.get("review_status") == "APPROVED"]
    review = [r for r in identities if r.get("review_status") != "APPROVED"]
    duplicates = _filter(identities, "DUPLICATE_IDENTITY")
    missing_brand = _filter(identities, "MISSING_BRAND")
    missing_fss = _filter(identities, "MISSING_FORM_STRENGTH_SIZE")
    weak = _filter(identities, "WEAK_NAME")
    alias_seed = [{"product_id": r.get("product_id"), "original_excel_name": r.get("original_excel_name"), "canonical_name": r.get("canonical_name"), "aliases": r.get("aliases"), "notes": r.get("notes")} for r in identities]
    ocr_seed = [{"product_id": r.get("product_id"), "original_excel_name": r.get("original_excel_name"), "canonical_name": r.get("canonical_name"), "ocr_keywords": r.get("ocr_keywords"), "notes": r.get("notes")} for r in identities]

    _write_xlsx(out / REPORT_NAMES["auto"], auto)
    _write_xlsx(out / REPORT_NAMES["review"], review)
    _write_xlsx(out / REPORT_NAMES["duplicates"], duplicates)
    _write_xlsx(out / REPORT_NAMES["missing_brand"], missing_brand)
    _write_xlsx(out / REPORT_NAMES["missing_fss"], missing_fss)
    _write_xlsx(out / REPORT_NAMES["weak"], weak)
    _write_xlsx(out / REPORT_NAMES["alias"], alias_seed, ["product_id", "original_excel_name", "canonical_name", "aliases", "notes"])
    _write_xlsx(out / REPORT_NAMES["ocr"], ocr_seed, ["product_id", "original_excel_name", "canonical_name", "ocr_keywords", "notes"])

    md = out / "MASTER_IDENTITY_BUILD_REPORT.md"
    md.write_text(
        "# Master Identity Build Report\n\n"
        f"- products_total: {stats.total_products}\n"
        f"- auto_approved: {stats.auto_approved}\n"
        f"- needs_identity_review: {stats.needs_review}\n"
        f"- missing_brand: {stats.missing_brand}\n"
        f"- missing_form_strength_size: {stats.missing_form_strength_size}\n"
        f"- weak_names: {stats.weak_names}\n"
        f"- duplicate_identity: {stats.duplicates}\n"
        f"- overlay_seeded: {stats.overlay_seeded}\n"
        f"- ocr_keywords_generated: {stats.ocr_keywords}\n\n"
        "Safety notes:\n"
        "- This script does not edit products.name, Excel files, prices, or availability.\n"
        "- Approved identities can help search/image confirmation, but images still never display price until user confirmation.\n"
        "- NEEDS_IDENTITY_REVIEW rows must be reviewed by admin/merchant before exact image matching can trust them.\n",
        encoding="utf-8",
    )
    print(json.dumps(stats.__dict__, ensure_ascii=False, indent=2))
    print(f"REPORT_DIR={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
