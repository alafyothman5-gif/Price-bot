from __future__ import annotations

import database
from normalizer import normalize_text
from services.catalog import master_identity
from services.matching.excel_native_matcher import ENGINE, match_vision_slots
from services.vision import visual_memory


def _insert_product(conn, name: str, price: str = "10", **extra) -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": normalize_text(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    payload.update({k: str(v) for k, v in extra.items() if k in payload})
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def _reset(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_master_identity_test.db"))
    database.init_db(run_production_guard=False)
    visual_memory.ensure_schema()
    master_identity.ensure_schema()
    ENGINE.invalidate()


def _mizon_slots():
    return {
        "status": "OK",
        "brand": "Mizon",
        "primary_title": "Cicaluronic Low PH Cleanser",
        "product_family": "Cicaluronic Low PH Cleanser",
        "foreground_product_text": "MIZON CICALURONIC LOW PH CLEANSER",
        "form": "cleanser",
        "confidence": "0.96",
        "query": "Mizon Cicaluronic Low PH Cleanser",
    }


def test_master_identity_marks_incomplete_excel_name_for_review(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "low ph cleanser", "55", form="cleanser")
    identities, stats = master_identity.build_master_identity_catalog(write_db=True)
    row = next(x for x in identities if int(x["product_id"]) == pid)
    assert row["review_status"] == "PENDING"
    assert row["identity_status"] == "NEEDS_IDENTITY_REVIEW"
    assert "MISSING_BRAND" in row["notes"]
    assert stats.needs_review >= 1


def test_mizon_image_does_not_match_raw_incomplete_excel_without_identity(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        _insert_product(conn, "low ph cleanser", "55", form="cleanser")
    master_identity.build_master_identity_catalog(write_db=True)
    ENGINE.invalidate()
    result = match_vision_slots(_mizon_slots())
    assert result.status != "EXACT_MATCH"


def test_mizon_overlay_then_master_identity_enables_safe_confirmation_candidate(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "low ph cleanser", "55", form="cleanser")
    product = database.get_product(pid)
    slots = _mizon_slots()
    approved = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="admin", admin_approved=True)
    assert approved["approved"] is True
    master_identity.build_master_identity_catalog(write_db=True)
    ENGINE.invalidate()
    result = match_vision_slots(slots)
    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == pid
    assert result.product.get("canonical_display_name") == "Mizon Cicaluronic Low PH Cleanser"
    assert result.diagnostics.get("stage") in {"visual_product_memory_hit", "product_identity_overlay_exact", "products_master_identity_exact"}


def test_flagyl_master_identity_validator_rejects_wrong_forms_and_sizes(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        flagyl_id = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "20", brand="Flagyl", form="suspension", strength="125mg/5ml", size="60ml")
        metro_id = _insert_product(conn, "Metronidazole suspension 100ml", "18", brand="Metronidazole", form="suspension", size="100ml")
        _insert_product(conn, "Flagyl 500mg tablet", "22", brand="Flagyl", form="tablet", strength="500mg")
        _insert_product(conn, "Flagyl suppository", "18", brand="Flagyl", form="suppository")
    master_identity.build_master_identity_catalog(write_db=True)
    ENGINE.invalidate()
    result = match_vision_slots({
        "brand": "Flagyl",
        "primary_title": "Flagyl",
        "foreground_product_text": "FLAGYL 125mg/5ml oral suspension 60ml",
        "form": "suspension",
        "strength": "125mg/5ml",
        "size": "60ml",
        "confidence": "0.95",
        "query": "Flagyl 125mg/5ml oral suspension 60ml",
    })
    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == flagyl_id
    assert int(result.product["id"]) != metro_id


def test_hemazym_primary_title_beats_ingredient_in_master_identity(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        hemazym_id = _insert_product(conn, "Hemazym", "40", brand="Hemazym")
        folic_id = _insert_product(conn, "Folic Acid", "12", brand="Folic Acid")
    master_identity.build_master_identity_catalog(write_db=True)
    ENGINE.invalidate()
    result = match_vision_slots({
        "brand": "Hemazym",
        "primary_title": "Hemazym",
        "foreground_product_text": "Hemazym Liposomal Iron",
        "background_text": "Folic Acid Vitamin B12 Zinc",
        "ingredients": ["Folic Acid", "Vitamin B12", "Zinc"],
        "confidence": "0.95",
        "query": "Hemazym",
    })
    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == hemazym_id
    assert int(result.product["id"]) != folic_id


def test_transition_4g_does_not_match_10g_master_identity(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        _insert_product(conn, "Transition 10g", "30", brand="Transition", size="10g")
    master_identity.build_master_identity_catalog(write_db=True)
    ENGINE.invalidate()
    result = match_vision_slots({
        "brand": "Transition",
        "primary_title": "Transition",
        "foreground_product_text": "Transition 4g",
        "size": "4g",
        "confidence": "0.95",
        "query": "Transition 4g",
    })
    assert not (result.status == "EXACT_MATCH" and result.product and normalize_text(result.product.get("size")) == "10g")
