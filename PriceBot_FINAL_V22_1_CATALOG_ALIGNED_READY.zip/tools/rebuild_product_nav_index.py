#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database  # noqa: E402
from services.product_navigator import build_nav_index  # noqa: E402


def rebuild_product_nav_index() -> dict:
    database.init_db()
    products = database.load_products()
    rows = build_nav_index(products)
    with database.get_db_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_nav_index (
                product_id TEXT,
                section TEXT,
                product_type TEXT,
                use_case TEXT,
                skin_type TEXT,
                body_area TEXT,
                medicine_form TEXT,
                strength TEXT,
                confidence REAL,
                tags_json TEXT,
                created_at TEXT
            )
        """)
        conn.execute("DELETE FROM product_nav_index")
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        counts = {}
        for row in rows:
            counts[row["section"]] = counts.get(row["section"], 0) + 1
            conn.execute(
                """
                INSERT INTO product_nav_index(product_id,section,product_type,use_case,skin_type,body_area,medicine_form,strength,confidence,tags_json,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,
                (row["product_id"], row["section"], row["product_type"], row["use_case"], row["skin_type"], row["body_area"], row["medicine_form"], row["strength"], row["confidence"], row["tags_json"], now),
            )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_nav_section ON product_nav_index(section)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_nav_type ON product_nav_index(product_type)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_nav_pid ON product_nav_index(product_id)")
        conn.commit()
    return {"products": len(products), "indexed": len(rows), "sections": counts}


def main() -> None:
    report = rebuild_product_nav_index()
    print("PRICEBOT_PRODUCT_NAV_INDEX_REBUILD_OK")
    print(f"products: {report['products']}")
    print(f"indexed: {report['indexed']}")
    for k, v in sorted(report["sections"].items()):
        print(f"section_{k}: {v}")


if __name__ == "__main__":
    main()
