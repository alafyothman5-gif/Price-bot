#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database  # noqa: E402
from services.search_engine import product_index_row  # noqa: E402


def rebuild_search_index() -> dict:
    database.init_db()
    products = database.load_products()
    with database.get_db_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_search_index (
                product_id TEXT,
                normalized_name TEXT,
                normalized_brand TEXT,
                normalized_aliases TEXT,
                normalized_ocr_keywords TEXT,
                tokens_json TEXT,
                strong_tokens_json TEXT,
                weak_tokens_json TEXT,
                category TEXT,
                product_type TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                search_mode TEXT,
                quality_status TEXT,
                created_at TEXT
            )
        """)
        conn.execute("DELETE FROM product_search_index")
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        inserted = 0
        exact_only = 0
        for p in products:
            row = product_index_row(p)
            if row.get("search_mode") == "exact_only" or row.get("quality_status") == "exact_only":
                exact_only += 1
            conn.execute(
                """
                INSERT INTO product_search_index(product_id,normalized_name,normalized_brand,normalized_aliases,normalized_ocr_keywords,tokens_json,strong_tokens_json,weak_tokens_json,category,product_type,form,strength,size,search_mode,quality_status,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (row["product_id"], row["normalized_name"], row["normalized_brand"], row["normalized_aliases"], row["normalized_ocr_keywords"], row["tokens_json"], row["strong_tokens_json"], row["weak_tokens_json"], row["category"], row["product_type"], row["form"], row["strength"], row["size"], row["search_mode"], row["quality_status"], now),
            )
            inserted += 1
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_name ON product_search_index(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_brand ON product_search_index(normalized_brand)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_pid ON product_search_index(product_id)")
        conn.commit()
    return {"products": len(products), "indexed": inserted, "exact_only": exact_only}


def main() -> None:
    report = rebuild_search_index()
    print("PRICEBOT_SEARCH_INDEX_REBUILD_OK")
    for k, v in report.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()
