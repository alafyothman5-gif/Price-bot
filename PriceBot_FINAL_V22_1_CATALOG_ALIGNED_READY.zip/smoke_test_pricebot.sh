#!/usr/bin/env bash
set -Eeuo pipefail
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
cd "$(dirname "$0")"
python -m compileall -q .
python -m pytest -q
python acceptance_tests_v3.py
python acceptance_tests_v4.py
python acceptance_tests_final_v17.py
python acceptance_tests_final_v17_1.py
python acceptance_tests_final_v17_2.py
python acceptance_tests_final_v17_4.py
python acceptance_tests_final_v17_5.py
python acceptance_tests_final_v18.py
python acceptance_tests_final_v19.py
python acceptance_tests_final_v19_1.py
python acceptance_tests_final_v19_3_guided_finder.py
python acceptance_tests_final_v20.py
python acceptance_tests_final_v20_1_guided_routing.py
python acceptance_tests_final_v22_company_grade.py
python acceptance_tests_final_v22_1_catalog_aligned.py
python tools/rebuild_search_index.py >/tmp/pricebot_search_index_smoke.log
python tools/rebuild_product_nav_index.py >/tmp/pricebot_nav_index_smoke.log
if curl -fsS http://127.0.0.1:${PRICEBOT_PORT}/health >/tmp/pricebot_health_smoke.log 2>/dev/null; then
  cat /tmp/pricebot_health_smoke.log
  echo
else
  echo "INFO: local service not running on 127.0.0.1:${PRICEBOT_PORT}; compile/tests/index rebuild passed. Run health after service restart."
fi

echo "PRICEBOT_SMOKE_TEST_OK"
