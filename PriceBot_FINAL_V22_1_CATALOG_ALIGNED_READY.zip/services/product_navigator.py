# -*- coding: utf-8 -*-
"""Product Navigator Engine for PriceBot V22.

Builds safe browsing/navigation metadata from the current product catalog. It is
not a therapeutic recommendation engine; medicines remain name/form/strength
selection only, and cosmetics are filtered by type/body-area/skin/use-case.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Sequence

from services.text_normalizer import contains_phrase, normalize_text, strong_tokens, token_set
try:
    from services.catalog_alignment import align_product
except Exception:  # pragma: no cover
    align_product = None

SECTION_LABELS = {
    "medicine": "أدوية",
    "skin_care": "عناية بالبشرة",
    "hair_care": "عناية بالشعر",
    "baby": "أطفال",
    "devices": "أجهزة ومستلزمات",
    "popular": "منتجات شائعة",
    "other": "أخرى",
}

MEDICINE_CATEGORIES = [
    ("pain_fever", "مسكنات وخافض حرارة"),
    ("antibiotic", "مضادات حيوية"),
    ("stomach", "أدوية المعدة"),
    ("allergy_cold", "حساسية وزكام"),
    ("vitamins", "فيتامينات ومكملات"),
    ("dermatology", "جلدية"),
    ("gynecology", "نسائية"),
    ("chronic", "سكري وضغط وقلب"),
    ("search_medicine", "بحث باسم دواء"),
]


def _aligned(product: dict) -> dict:
    if not isinstance(product, dict) or product.get("__aligned_v22"):
        return product
    if align_product is None:
        return product
    try:
        merged = dict(product)
        a = align_product(product)
        weak_existing = {"", None, "other", "unknown", "product"}
        for key, val in a.items():
            if key in {"available", "price"}:
                continue
            if val not in (None, "") and (merged.get(key) in weak_existing or key in {"product_type", "use_case", "skin_type", "body_area", "normalized_name"}):
                merged[key] = val
        if a.get("aliases"):
            merged["aliases"] = "; ".join([str(product.get("aliases") or ""), str(a.get("aliases") or "")]).strip("; ")
        if a.get("ocr_keywords"):
            merged["ocr_keywords"] = " ".join([str(product.get("ocr_keywords") or product.get("image_ocr_keywords") or ""), str(a.get("ocr_keywords") or "")]).strip()
        merged["__aligned_v22"] = True
        return merged
    except Exception:
        return product


def _field(product: dict, *keys: str) -> str:
    product = _aligned(product)
    for k in keys:
        v = product.get(k)
        if v not in (None, ""):
            return str(v)
    return ""


def _identity(product: dict) -> str:
    product = _aligned(product)
    return normalize_text(" ".join(_field(product, k) for k in [
        "name", "brand", "company", "product_family", "category", "subcategory", "form", "use_case", "skin_type", "body_area", "aliases", "ocr_keywords", "image_ocr_keywords"
    ]))


def infer_section(product: dict) -> tuple[str, float]:
    category = normalize_text(product.get("category") or "")
    identity = _identity(product)
    if category == "medicine" or any(w in identity for w in ["tablet", "capsule", "syrup", "suppository", "mg", "فلاجيل", "اموكلان", "panadol", "antibiotic"]):
        return "medicine", 0.85
    if any(w in identity for w in ["baby", "اطفال", "حفاض", "diaper", "kids"]):
        return "baby", 0.80
    if any(w in identity for w in ["shampoo", "conditioner", "hair", "شامبو", "قشره", "قشرة", "تساقط"]):
        return "hair_care", 0.82
    if any(w in identity for w in ["device", "thermometer", "glucometer", "pressure", "جهاز", "قياس", "ترمومتر"]):
        return "devices", 0.80
    if category == "cosmetic" or any(w in identity for w in ["cleanser", "cream", "lotion", "serum", "sunscreen", "غسول", "كريم", "لوشن", "سيروم", "واقي"]):
        return "skin_care", 0.78
    return "other", 0.45


def infer_product_type(product: dict) -> str:
    raw = normalize_text(_field(product, "product_type", "form", "type", "subcategory"))
    identity = _identity(product)
    checks = [
        ("face_cleanser", ["face wash", "cleanser", "foaming", "gel moussant", "غسول وجه", "غسول"]),
        ("moisturizer", ["moisturizer", "moisturising", "moisturizing", "مرطب"]),
        ("sunscreen", ["sunscreen", "sunblock", "spf", "واقي"]),
        ("serum", ["serum", "سيروم"]),
        ("cream", ["cream", "كريم", "balm", "baume"]),
        ("lotion", ["lotion", "لوشن"]),
        ("shampoo", ["shampoo", "شامبو"]),
        ("conditioner", ["conditioner", "بلسم"]),
        ("tablet", ["tablet", "tab", "اقراص", "حبوب"]),
        ("capsule", ["capsule", "cap", "كبسول"]),
        ("syrup", ["syrup", "suspension", "شراب"]),
        ("suppository", ["suppository", "تحاميل", "لبوس"]),
        ("injection", ["injection", "ampoule", "حقن"]),
    ]
    for typ, words in checks:
        if raw == typ or any(contains_phrase(identity, w) for w in words):
            return typ
    return raw


def infer_skin_type(product: dict) -> str:
    raw = normalize_text(product.get("skin_type") or "")
    identity = _identity(product)
    if raw:
        return raw
    if any(w in identity for w in ["oily", "normal oily", "acne", "blemish", "sebum", "effaclar", "cleanance"]):
        return "oily_skin"
    if any(w in identity for w in ["dry", "very dry", "hydrating", "moisturizing", "atoderm", "xerolact", "lipikar"]):
        return "dry_skin"
    if "sensitive" in identity or "حساس" in identity:
        return "sensitive_skin"
    return ""


def infer_use_case(product: dict) -> str:
    raw = normalize_text(product.get("use_case") or "")
    identity = _identity(product)
    if raw:
        return raw
    if any(w in identity for w in ["acne", "blemish", "oil control", "sebum", "effaclar", "cleanance"]):
        return "acne"
    if any(w in identity for w in ["hydrating", "moisturizing", "barrier", "atoderm", "xerolact", "lipikar"]):
        return "hydration"
    if any(w in identity for w in ["spf", "sunscreen", "sunblock"]):
        return "sun_protection"
    if any(w in identity for w in ["dandruff", "قشره", "قشرة"]):
        return "anti_dandruff"
    return ""


def infer_body_area(product: dict) -> str:
    raw = normalize_text(product.get("body_area") or "")
    identity = _identity(product)
    if raw:
        return raw
    if any(w in identity for w in ["body wash", "body lotion", "جسم"]):
        return "body"
    if any(w in identity for w in ["baby", "اطفال", "kids"]):
        return "baby"
    if any(w in identity for w in ["shampoo", "hair", "شامبو", "شعر"]):
        return "hair"
    if any(w in identity for w in ["face", "facial", "cleanser", "serum", "sunscreen", "وجه"]):
        return "face"
    return ""


def nav_index_row(product: dict) -> Dict[str, Any]:
    product = _aligned(product)
    section, conf = infer_section(product)
    ptype = infer_product_type(product)
    use_case = infer_use_case(product)
    skin = infer_skin_type(product)
    area = infer_body_area(product)
    tags = sorted(set([section, ptype, use_case, skin, area]) | strong_tokens(_identity(product)))
    return {
        "product_id": str(product.get("product_id") or product.get("id") or ""),
        "section": section,
        "product_type": ptype,
        "use_case": use_case,
        "skin_type": skin,
        "body_area": area,
        "medicine_form": ptype if section == "medicine" else "",
        "strength": str(product.get("strength") or ""),
        "confidence": float(conf),
        "tags_json": json.dumps(tags, ensure_ascii=False),
    }


def build_nav_index(products: Sequence[dict]) -> List[Dict[str, Any]]:
    return [nav_index_row(p) for p in products or []]


def available_sections(products: Sequence[dict]) -> List[dict]:
    counts: Dict[str, int] = {}
    for row in build_nav_index(products):
        sec = row["section"]
        if sec != "other" and row["confidence"] >= 0.70:
            counts[sec] = counts.get(sec, 0) + 1
    ordered = ["medicine", "skin_care", "hair_care", "baby", "devices", "popular"]
    return [{"id": sec, "label": SECTION_LABELS[sec], "description": f"{counts.get(sec, 0)} منتج"} for sec in ordered if counts.get(sec, 0) or sec == "popular"]


def medicine_menu(products: Sequence[dict]) -> List[dict]:
    # Static safe taxonomy. It does not give advice; it only narrows browsing.
    has_medicine = any(infer_section(p)[0] == "medicine" for p in products or [])
    return [{"id": k, "label": v} for k, v in MEDICINE_CATEGORIES] if has_medicine else [{"id": "search_medicine", "label": "بحث باسم دواء"}]
