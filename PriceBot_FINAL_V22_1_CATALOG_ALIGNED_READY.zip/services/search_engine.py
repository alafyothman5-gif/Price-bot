# -*- coding: utf-8 -*-
"""Deterministic company-grade product search engine for PriceBot V22.

This service complements the existing strict matcher. It never performs global
fuzzy fallback; any fuzzy/token matching is scoped by strong tokens and product
identity fields. The engine can run directly on the current products table or on
`product_search_index` built by tools/rebuild_search_index.py.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from services.text_normalizer import (
    WEAK_TOKENS, compact_text, contains_phrase, is_generic_query, normalize_text,
    split_aliases, strong_tokens, token_set, tokens, weak_tokens,
)
try:
    from services.catalog_alignment import align_product, build_aliases
except Exception:  # pragma: no cover - defensive for partial deployments
    align_product = None
    build_aliases = None

DECISION_EXACT = "EXACT_MATCH"
DECISION_ASK = "ASK_CLARIFICATION"
DECISION_NOT_AVAILABLE = "NOT_AVAILABLE"
DECISION_LOW = "LOW_CONFIDENCE"
DECISION_GUIDED = "GUIDED_FLOW"

GENERAL_BRAND_QUERIES = {"cerave", "rilastil", "bioderma", "la roche", "eucerin"}

@dataclass
class SearchHit:
    product: dict
    score: float
    layer: str
    reason: str = ""

@dataclass
class SearchDecision:
    decision: str
    query: str
    normalized_query: str
    product: Optional[dict] = None
    options: List[dict] = field(default_factory=list)
    score: float = 0.0
    reason: str = ""
    elapsed_ms: float = 0.0


def _product_id(product: dict) -> str:
    return str(product.get("product_id") or product.get("id") or "")


def _field(product: dict, *keys: str) -> str:
    for key in keys:
        val = product.get(key)
        if val not in (None, ""):
            return str(val)
    return ""


def _available(product: dict) -> bool:
    value = normalize_text(product.get("available") or "")
    return value not in {"0", "false", "no", "غير متوفر", "نفد", "unavailable"}


def _is_exact_only(product: dict) -> bool:
    mode = normalize_text(product.get("search_mode") or product.get("quality_status") or "")
    return "exact_only" in mode


def _aligned(product: dict) -> dict:
    if not isinstance(product, dict) or product.get("__aligned_v22"):
        return product
    if align_product is None:
        return product
    try:
        merged = dict(product)
        a = align_product(product)
        weak_existing = {"", None, "other", "unknown", "product"}
        for key, val in a.items():
            if key in {"available", "price"}:
                continue
            if val not in (None, "") and (merged.get(key) in weak_existing or key in {"product_type", "use_case", "skin_type", "body_area", "normalized_name"}):
                merged[key] = val
        # Use generated aliases/OCR in-memory even if DB row has weak fields.
        if a.get("aliases"):
            merged["aliases"] = "; ".join([str(product.get("aliases") or ""), str(a.get("aliases") or "")]).strip("; ")
        if a.get("ocr_keywords"):
            merged["ocr_keywords"] = " ".join([str(product.get("ocr_keywords") or product.get("image_ocr_keywords") or ""), str(a.get("ocr_keywords") or "")]).strip()
        merged["__aligned_v22"] = True
        return merged
    except Exception:
        return product


def _identity(product: dict) -> str:
    p = _aligned(product)
    return normalize_text(" ".join(_field(p, k) for k in [
        "name", "brand", "company", "product_family", "category", "subcategory", "form", "product_type", "strength", "size", "pack",
        "aliases", "ocr_keywords", "image_ocr_keywords", "barcode", "code", "sku", "item_code", "product_code",
    ]))


def product_index_row(product: dict) -> Dict[str, Any]:
    p = _aligned(product)
    name = normalize_text(p.get("normalized_name") or p.get("name"))
    aliases = split_aliases(p.get("aliases") or p.get("alias") or "")
    ocr = normalize_text(p.get("ocr_keywords") or p.get("image_ocr_keywords") or p.get("keywords") or "")
    identity = " ".join([name, normalize_text(p.get("brand")), normalize_text(p.get("company")), normalize_text(p.get("product_family")), ocr, " ".join(aliases)])
    ts = token_set(identity)
    strong = {t for t in ts if t not in WEAK_TOKENS and len(t) >= 3}
    weak = ts - strong
    return {
        "product_id": _product_id(p),
        "normalized_name": name,
        "normalized_brand": normalize_text(p.get("brand") or p.get("company")),
        "normalized_aliases": ";".join(aliases),
        "normalized_ocr_keywords": ocr,
        "tokens_json": json.dumps(sorted(ts), ensure_ascii=False),
        "strong_tokens_json": json.dumps(sorted(strong), ensure_ascii=False),
        "weak_tokens_json": json.dumps(sorted(weak), ensure_ascii=False),
        "category": str(p.get("category") or ""),
        "product_type": str(p.get("product_type") or p.get("form") or p.get("type") or ""),
        "form": str(p.get("form") or ""),
        "strength": str(p.get("strength") or ""),
        "size": str(p.get("size") or p.get("pack") or ""),
        "search_mode": str(p.get("search_mode") or ""),
        "quality_status": str(p.get("quality_status") or ""),
    }


def build_memory_index(products: Sequence[dict]) -> Dict[str, Any]:
    name_map: Dict[str, List[dict]] = {}
    alias_map: Dict[str, List[dict]] = {}
    barcode_map: Dict[str, List[dict]] = {}
    for raw in products or []:
        p = _aligned(raw)
        n = normalize_text(p.get("normalized_name") or p.get("name"))
        if n:
            name_map.setdefault(n, []).append(p)
            name_map.setdefault(compact_text(n), []).append(p)
        alias_values = split_aliases(p.get("aliases") or "")
        # Add safe generated aliases such as Photoblok 50+ <-> +Photoblok 50.
        if build_aliases is not None:
            try:
                alias_values.extend([normalize_text(a) for a in build_aliases(p)])
            except Exception:
                pass
        for alias in alias_values:
            if alias and alias not in WEAK_TOKENS:
                alias_map.setdefault(alias, []).append(p)
                alias_map.setdefault(compact_text(alias), []).append(p)
        for key in ["barcode", "code", "sku", "item_code", "product_code", "source_serial"]:
            val = normalize_text(p.get(key) or "")
            if val:
                barcode_map.setdefault(val, []).append(p)
    return {"name": name_map, "alias": alias_map, "barcode": barcode_map, "products": list(products or [])}


def _unique(items: Sequence[dict]) -> List[dict]:
    seen = set()
    out = []
    for item in items:
        key = _product_id(item) or normalize_text(item.get("name"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _single_or_ask(query: str, qn: str, hits: List[dict], layer: str, elapsed: float) -> SearchDecision:
    hits = _unique(hits)
    if len(hits) == 1:
        return SearchDecision(DECISION_EXACT, query, qn, product=hits[0], score=1.0 if layer != "alias" else 0.98, reason=layer, elapsed_ms=elapsed)
    if len(hits) > 1:
        return SearchDecision(DECISION_ASK, query, qn, options=hits[:10], score=0.9, reason=f"multiple_{layer}", elapsed_ms=elapsed)
    return SearchDecision(DECISION_LOW, query, qn, reason="no_hits", elapsed_ms=elapsed)


def _is_specific_unavailable(qn: str) -> bool:
    st = strong_tokens(qn)
    # A single distinctive long token such as "Formag" is treated as a specific
    # product request, not a generic category. Brand-only queries are intercepted
    # as GUIDED_FLOW before this policy.
    return len(st) >= 2 or any(len(t) >= 5 for t in st) or bool(re.search(r"\d+(?:mg|ml|g|%)", qn))


def _scoped_candidates(qn: str, products: Sequence[dict]) -> List[dict]:
    qstrong = strong_tokens(qn)
    if not qstrong:
        return []
    candidates = []
    for p in products:
        if _is_exact_only(p):
            continue
        identity = _identity(p)
        pstrong = strong_tokens(identity)
        if qstrong & pstrong:
            candidates.append(p)
    return candidates


def _score(qn: str, product: dict) -> float:
    identity = _identity(product)
    if not identity:
        return 0.0
    qstrong = strong_tokens(qn)
    pstrong = strong_tokens(identity)
    overlap = len(qstrong & pstrong)
    base = 0.0
    if qstrong:
        base = overlap / max(len(qstrong), 1)
    phrase_bonus = 0.15 if contains_phrase(identity, qn) or contains_phrase(qn, product.get("name")) else 0.0
    ratio = SequenceMatcher(None, qn, normalize_text(product.get("name"))).ratio() * 0.20
    return min(0.91, base * 0.75 + phrase_bonus + ratio)


def search_products(query: str, products: Sequence[dict], *, allow_guided: bool = True, index: Optional[dict] = None) -> SearchDecision:
    started = time.perf_counter()
    qn = normalize_text(query)
    if not qn:
        return SearchDecision(DECISION_LOW, query, qn, reason="empty", elapsed_ms=0.0)
    if allow_guided and (is_generic_query(qn) or qn in GENERAL_BRAND_QUERIES):
        return SearchDecision(DECISION_GUIDED, query, qn, reason="generic_query", elapsed_ms=(time.perf_counter()-started)*1000)
    idx = index or build_memory_index(products)
    # Layer 1 exact normalized name.
    for key in [qn, compact_text(qn)]:
        if key in idx["name"]:
            return _single_or_ask(query, qn, idx["name"][key], "exact_name", (time.perf_counter()-started)*1000)
    # Layer 2 exact alias.
    for key in [qn, compact_text(qn)]:
        if key in idx["alias"]:
            return _single_or_ask(query, qn, idx["alias"][key], "alias", (time.perf_counter()-started)*1000)
    # Layer 3 barcode/code.
    if re.fullmatch(r"[a-z0-9+.-]{2,}", qn):
        for key in [qn, compact_text(qn)]:
            if key in idx["barcode"]:
                return _single_or_ask(query, qn, idx["barcode"][key], "barcode", (time.perf_counter()-started)*1000)
    # Layer 4 normalized phrase match.
    phrase_hits = [p for p in products if not _is_exact_only(p) and (contains_phrase(_identity(p), qn) or contains_phrase(qn, p.get("name")))]
    phrase_hits = _unique(phrase_hits)
    if len(phrase_hits) == 1:
        return SearchDecision(DECISION_EXACT, query, qn, product=phrase_hits[0], score=0.93, reason="phrase_match", elapsed_ms=(time.perf_counter()-started)*1000)
    if len(phrase_hits) > 1:
        return SearchDecision(DECISION_ASK, query, qn, options=phrase_hits[:10], score=0.88, reason="multiple_phrase", elapsed_ms=(time.perf_counter()-started)*1000)
    # Layer 5 scoped token match, Layer 6 safe fuzzy scoped.
    candidates = _scoped_candidates(qn, products)
    scored = sorted([( _score(qn, p), p) for p in candidates], key=lambda x: x[0], reverse=True)
    scored = [(s, p) for s, p in scored if s >= 0.70]
    elapsed = (time.perf_counter()-started)*1000
    if scored and scored[0][0] >= 0.92:
        top_score = scored[0][0]
        tied = [p for s, p in scored if abs(s - top_score) < 0.03]
        if len(tied) == 1:
            return SearchDecision(DECISION_EXACT, query, qn, product=tied[0], score=top_score, reason="scoped_token", elapsed_ms=elapsed)
    if scored:
        return SearchDecision(DECISION_ASK, query, qn, options=[p for _, p in scored[:10]], score=scored[0][0], reason="scoped_ambiguous", elapsed_ms=elapsed)
    if _is_specific_unavailable(qn):
        return SearchDecision(DECISION_NOT_AVAILABLE, query, qn, score=0.0, reason="specific_not_found", elapsed_ms=elapsed)
    return SearchDecision(DECISION_LOW, query, qn, reason="low_confidence", elapsed_ms=elapsed)
