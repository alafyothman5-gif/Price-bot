# -*- coding: utf-8 -*-
"""Guided Shopping / Interactive Product Finder for PriceBot.

This module is intentionally conservative. It does not replace the strict
V18/V19 matcher. It only catches generic browsing requests and moves the
customer through a small state machine before any product list or price is
shown.
"""
from __future__ import annotations

import html
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from services import product_navigator

GUIDED_STATE_KEY = "guided_finder"
MAX_GUIDED_OPTIONS = 8
_PAGE_MORE_WORDS = {"المزيد", "مزيد", "more", "التالي", "next"}
GUIDED_TTL_SECONDS = int(os.getenv("GUIDED_FINDER_TTL_SECONDS", "900"))

_SKIN_LABELS = {
    "oily_skin": "دهنية",
    "dry_skin": "جافة",
    "sensitive_skin": "حساسة",
    "normal_combination_skin": "عادية/مختلطة",
    "unknown": "لا أعرف",
}

_SKIN_COMPATIBLE = {
    "oily_skin": {"oily_skin", "normal_oily_skin", "oily_combination_skin", "combination_oily_skin", "acne_prone_skin", "acne"},
    "dry_skin": {"dry_skin", "very_dry_skin", "dry_sensitive_skin"},
    "sensitive_skin": {"sensitive_skin", "dry_sensitive_skin", "sensitive"},
    "normal_combination_skin": {"normal_skin", "combination_skin", "normal_combination_skin", "normal_oily_skin"},
}

_SKIN_AR_TO_KEY = {
    "دهنية": "oily_skin", "دهنيه": "oily_skin", "oily": "oily_skin", "حبوب": "oily_skin", "acne": "oily_skin",
    "جافة": "dry_skin", "جافه": "dry_skin", "dry": "dry_skin",
    "حساسة": "sensitive_skin", "حساسه": "sensitive_skin", "sensitive": "sensitive_skin",
    "عادية": "normal_combination_skin", "عاديه": "normal_combination_skin", "مختلطة": "normal_combination_skin", "مختلطه": "normal_combination_skin", "combination": "normal_combination_skin", "normal": "normal_combination_skin",
}

_TYPE_LABELS = {
    "face_cleanser": "غسول وجه",
    "body_wash": "غسول جسم",
    "baby_wash": "غسول أطفال",
    "feminine_wash": "غسول طبي/نسائي",
    "moisturizer": "مرطب",
    "sunscreen": "واقي شمس",
    "serum": "سيروم",
    "acne_treatment": "علاج حبوب",
    "exfoliator": "مقشر",
    "cream_moisturizing": "ترطيب",
    "cream_acne": "حبوب",
    "cream_itch": "التهاب/حكة",
    "cream_sunscreen": "واقي شمس",
    "cream_brightening": "تفتيح",
    "shampoo": "شامبو",
    "conditioner": "بلسم",
    "hair_oil": "زيت",
    "hair_loss": "علاج تساقط",
    "anti_dandruff": "قشرة",
}

_MAIN_MENU = [
    {"id": "search_by_name", "label": "البحث باسم منتج"},
    {"id": "browse_categories", "label": "تصفح الأقسام"},
    {"id": "send_image", "label": "إرسال صورة المنتج"},
    {"id": "orders", "label": "الطلبات"},
]

_CATEGORY_MENU = [
    {"id": "medicine", "label": "أدوية"},
    {"id": "skin_care", "label": "عناية بالبشرة"},
    {"id": "hair_care", "label": "عناية بالشعر"},
    {"id": "baby", "label": "أطفال"},
    {"id": "devices", "label": "أجهزة ومستلزمات"},
    {"id": "popular", "label": "عروض/منتجات شائعة"},
]

_SKIN_CARE_MENU = [
    {"id": "face_cleanser", "label": "غسول وجه"},
    {"id": "moisturizer", "label": "مرطب"},
    {"id": "sunscreen", "label": "واقي شمس"},
    {"id": "serum", "label": "سيروم"},
    {"id": "acne_treatment", "label": "علاج حبوب"},
    {"id": "exfoliator", "label": "مقشر"},
]

_HAIR_CARE_MENU = [
    {"id": "shampoo", "label": "شامبو"},
    {"id": "conditioner", "label": "بلسم"},
    {"id": "hair_oil", "label": "زيت"},
    {"id": "hair_loss", "label": "علاج تساقط"},
    {"id": "anti_dandruff", "label": "قشرة"},
]

_SKIN_MENU = [
    {"id": "oily_skin", "label": "دهنية"},
    {"id": "dry_skin", "label": "جافة"},
    {"id": "sensitive_skin", "label": "حساسة"},
    {"id": "normal_combination_skin", "label": "عادية/مختلطة"},
    {"id": "unknown", "label": "لا أعرف"},
]

_CERAVE_TYPE_MENU = [
    {"id": "face_cleanser", "label": "غسول"},
    {"id": "moisturizer", "label": "مرطب"},
    {"id": "cream_moisturizing", "label": "كريم"},
    {"id": "lotion", "label": "لوشن"},
    {"id": "serum", "label": "سيروم/علاج"},
]

_MENU_TRIGGERS = {"مرحبا", "مرحب", "هلا", "السلام", "السلام عليكم", "القائمة", "قائمه", "منتجات", "ابدأ", "ابدا", "start", "menu", "hello", "hi"}
_BRAND_ONLY = {
    "cerave", "cera ve", "سيرافي", "سيرا في",
    "rilastil", "ريلاستيل",
    "bioderma", "بيوديرما",
    "la roche", "laroche", "la roche posay", "لاروش", "لاروش بوزيه",
    "eucerin", "يوسرين",
}
_BRAND_PRODUCT_MENUS = {
    "cerave": _CERAVE_TYPE_MENU,
    "rilastil": _CERAVE_TYPE_MENU,
    "bioderma": _CERAVE_TYPE_MENU,
    "la_roche": _CERAVE_TYPE_MENU,
    "eucerin": _CERAVE_TYPE_MENU,
}

# V20.1: accept both old internal IDs and human-visible Arabic labels.
_SELECTION_ID_ALIASES = {
    "search": "search_by_name",
    "search_by_name": "search_by_name",
    "browse": "browse_categories",
    "browse_categories": "browse_categories",
    "image": "send_image",
    "send_image": "send_image",
}

_DIRECT_MENU_LABELS = {
    "البحث باسم منتج": "search_by_name",
    "تصفح الأقسام": "browse_categories",
    "ارسال صورة المنتج": "send_image",
    "إرسال صورة المنتج": "send_image",
    "الطلبات": "orders",
    "عناية بالبشرة": "skin_care",
    "العناية بالبشرة": "skin_care",
    "عناية بالشعر": "hair_care",
    "العناية بالشعر": "hair_care",
    "أدوية": "medicine",
    "ادوية": "medicine",
    "أطفال": "baby",
    "اطفال": "baby",
    "أجهزة ومستلزمات": "devices",
    "اجهزة ومستلزمات": "devices",
}
_GENERIC_CLEANSER = {"غسول", "cleanser", "face wash", "wash", "منظف"}
_GENERIC_CREAM = {"كريم", "cream"}
_GENERIC_LOTION = {"لوشن", "lotion"}
_GENERIC_SERUM = {"سيروم", "serum"}
_GENERIC_MOISTURIZER = {"مرطب", "moisturizer", "moisturiser"}
_GENERIC_SUNSCREEN = {"واقي شمس", "sunscreen", "sunblock", "spf"}
_GENERIC_SHAMPOO = {"شامبو", "shampoo"}


@dataclass
class GuidedResult:
    handled: bool
    reply: str = ""
    decision: str = "guided_finder"
    state_update: Dict[str, Any] = field(default_factory=dict)
    clear_state: bool = False
    product: Optional[dict] = None
    options: List[dict] = field(default_factory=list)
    order_item: Optional[dict] = None


def _h(v: Any) -> str:
    return html.escape(str(v or ""), quote=False)


def normalize_text(value: Any) -> str:
    text = str(value or "").strip().lower()
    arabic_map = {"أ": "ا", "إ": "ا", "آ": "ا", "ة": "ه", "ى": "ي", "ؤ": "و", "ئ": "ي", "ٱ": "ا"}
    for src, dst in arabic_map.items():
        text = text.replace(src, dst)
    text = text.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    text = re.sub(r"[\u064b-\u065f]", "", text)
    text = re.sub(r"[^\w\s/]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def _contains(norm: str, phrase: str) -> bool:
    p = normalize_text(phrase)
    return bool(p and f" {p} " in f" {norm} ")


def _skin_key_from_norm(q: str) -> str:
    compact = q.replace(" ", "")
    if any(x in compact for x in ["دهنيه", "دهنية", "الدهنية", "الدهنيه", "oilyskin", "oily"]):
        return "oily_skin"
    if any(x in compact for x in ["جافه", "جافة", "الجافة", "الجافه", "dryskin", "dry"]):
        return "dry_skin"
    if any(x in compact for x in ["حساسه", "حساسة", "الحساسه", "الحساسة", "sensitiveskin", "sensitive"]):
        return "sensitive_skin"
    if any(x in compact for x in ["عاديه", "عادية", "مختلطه", "مختلطة", "normal", "combination"]):
        return "normal_combination_skin"
    return ""


def _field(product: dict, *keys: str) -> str:
    for key in keys:
        value = product.get(key)
        if value not in (None, ""):
            return str(value)
    return ""


def _product_identity(product: dict) -> str:
    return normalize_text(" ".join(_field(product, k) for k in [
        "name", "brand", "company", "product_family", "category", "subcategory", "form", "type", "product_type",
        "use_case", "skin_type", "body_area", "aliases", "ocr_keywords", "image_ocr_keywords", "keywords", "size"
    ]))


def _product_type(product: dict) -> str:
    raw = normalize_text(_field(product, "form", "type", "product_type", "cosmetic_type", "subcategory"))
    identity = _product_identity(product)
    if raw in {"face wash", "wash"} or _contains(identity, "face wash") or _contains(identity, "غسول وجه"):
        return "cleanser"
    if raw in {"cleanser", "lotion", "cream", "serum", "gel", "shampoo", "sunscreen", "moisturizer", "balm", "conditioner", "oil"}:
        return raw
    for typ, words in {
        "cleanser": ["cleanser", "face wash", "foaming", "gel moussant", "غسول", "منظف"],
        "lotion": ["lotion", "لوشن"],
        "cream": ["cream", "كريم", "baume", "balm"],
        "serum": ["serum", "سيروم"],
        "gel": ["gel", "جل"],
        "shampoo": ["shampoo", "شامبو"],
        "sunscreen": ["sunscreen", "spf", "واقي شمس", "sunblock"],
        "moisturizer": ["moisturizer", "moisturizing", "hydrating", "مرطب"],
        "conditioner": ["conditioner", "بلسم"],
        "oil": ["oil", "زيت"],
    }.items():
        if any(_contains(identity, w) for w in words):
            return typ
    return raw


def _product_category(product: dict) -> str:
    cat = normalize_text(_field(product, "category", "category_guess"))
    identity = _product_identity(product)
    if "medicine" in cat or "دواء" in cat or "ادويه" in cat:
        return "medicine"
    if "cosmetic" in cat or "skin" in cat or "beauty" in cat or "كوز" in cat:
        return "cosmetic"
    ptype = _product_type(product)
    if ptype in {"cleanser", "lotion", "cream", "serum", "gel", "shampoo", "sunscreen", "moisturizer", "balm", "conditioner", "oil"}:
        return "cosmetic"
    if any(_contains(identity, w) for w in ["skin", "face", "شعر", "بشرة", "وجه", "spf"]):
        return "cosmetic"
    return cat or "unknown"


def _product_skin(product: dict) -> str:
    raw = normalize_text(_field(product, "skin_type"))
    if raw:
        raw = raw.replace(" ", "_")
        if raw in {"oily", "oily_skin", "دهنيه", "دهنيه"}:
            return "oily_skin"
        if raw in {"dry", "dry_skin"}:
            return "dry_skin"
        if raw in {"sensitive", "sensitive_skin"}:
            return "sensitive_skin"
        if raw in {"normal", "combination", "normal_combination", "normal_combination_skin"}:
            return "normal_combination_skin"
        return raw
    identity = _product_identity(product)
    for key, aliases in _SKIN_AR_TO_KEY.items():
        if _contains(identity, key):
            return aliases
    return ""


def _product_use(product: dict) -> str:
    raw = normalize_text(_field(product, "use_case", "indication"))
    if raw:
        return raw.replace(" ", "_")
    identity = _product_identity(product)
    if any(_contains(identity, w) for w in ["acne", "حبوب", "sebium", "effaclar", "normaderm", "salicylic"]):
        return "acne"
    if any(_contains(identity, w) for w in ["hydrating", "moisturizing", "ترطيب", "dry skin", "xerolact"]):
        return "hydration"
    if any(_contains(identity, w) for w in ["sunscreen", "spf", "واقي"]):
        return "sun_protection"
    if any(_contains(identity, w) for w in ["dandruff", "قشرة", "قشره"]):
        return "anti_dandruff"
    return ""


def _product_area(product: dict) -> str:
    raw = normalize_text(_field(product, "body_area", "target_area"))
    identity = _product_identity(product)
    if raw:
        if raw in {"face", "وجه", "بشره", "بشرة"}:
            return "face"
        if raw in {"body", "جسم"}:
            return "body"
        if raw in {"hair", "شعر"}:
            return "hair"
        if raw in {"baby", "اطفال", "طفل"}:
            return "baby"
        return raw
    if any(_contains(identity, w) for w in ["body", "جسم", "body wash"]):
        return "body"
    if any(_contains(identity, w) for w in ["baby", "اطفال", "طفل", "kids"]):
        return "baby"
    if any(_contains(identity, w) for w in ["hair", "شعر", "shampoo", "conditioner", "scalp"]):
        return "hair"
    if any(_contains(identity, w) for w in ["face", "وجه", "بشرة", "بشره", "skin", "acne", "oily", "dry skin", "sensitive"]):
        return "face"
    return ""


def _is_exact_only_product(product: dict) -> bool:
    mode = normalize_text(_field(product, "search_mode", "quality_status", "matching_mode", "review_status"))
    return mode in {"exact_only", "exactonly"} or "exact only" in mode


def _is_available(product: dict) -> bool:
    value = normalize_text(_field(product, "available", "availability", "status"))
    if not value:
        return False
    bad = {"غير متوفر", "غير موجود", "نافذ", "نفذ", "ناقص", "out of stock", "unavailable", "no", "0", "unknown"}
    return not any(b in value for b in bad)


def _price_text(product: dict) -> str:
    price = str(product.get("price") or "").strip()
    if not price:
        return ""
    return price if "د" in price else f"{price} د.ل"


def _option_lines(options: Sequence[dict], include_price: bool = False) -> str:
    lines = []
    for i, opt in enumerate(options, 1):
        label = opt.get("label") or opt.get("name") or opt.get("id")
        if include_price and opt.get("price"):
            label = f"{label} - {_price_text(opt)}"
        lines.append(f"{i}. {_h(label)}")
    return "\n".join(lines)


def _menu_reply(title: str, options: Sequence[dict], footer: str = "اكتب رقم الاختيار.") -> str:
    return f"{title}\n\n{_option_lines(options)}\n\n{footer}".strip()


def _state(flow: str, step: str, **kwargs: Any) -> Dict[str, Any]:
    data = {
        "current_flow": flow,
        "step": step,
        "expires_at": int(time.time()) + GUIDED_TTL_SECONDS,
    }
    data.update(kwargs)
    if data.get("last_options") and not data.get("last_options_type"):
        data["last_options_type"] = "menu"
    return {GUIDED_STATE_KEY: data}


def detect_guided_intent(query: str) -> str:
    q = normalize_text(query)
    if not q:
        return ""
    if q in {normalize_text(x) for x in _MENU_TRIGGERS}:
        return "main_menu"
    if q in {normalize_text(x) for x in _BRAND_ONLY}:
        return "brand_only"
    if q in {normalize_text(x) for x in _GENERIC_CLEANSER}:
        return "generic_cleanser"
    if _contains(q, "غسول وجه") or _contains(q, "face cleanser") or _contains(q, "face wash"):
        return "face_cleanser"
    if q in {normalize_text(x) for x in _GENERIC_CREAM}:
        return "generic_cream"
    if q in {normalize_text(x) for x in _GENERIC_LOTION}:
        return "generic_lotion"
    if q in {normalize_text(x) for x in _GENERIC_SERUM}:
        return "generic_serum"
    if q in {normalize_text(x) for x in _GENERIC_MOISTURIZER}:
        return "generic_moisturizer"
    if q in {normalize_text(x) for x in _GENERIC_SUNSCREEN}:
        return "generic_sunscreen"
    if q in {normalize_text(x) for x in _GENERIC_SHAMPOO}:
        return "generic_shampoo"
    if _contains(q, "غسول") and not any(_contains(q, w) for w in ["cerave", "bioderma", "rilastil", "la roche", "لاروش"]):
        if _skin_key_from_norm(q):
            return "face_cleanser_with_skin"
        return "generic_cleanser"
    if _contains(q, "كريم") and len(q.split()) <= 3:
        return "generic_cream"
    return ""


def extract_skin_type(query: str) -> str:
    q = normalize_text(query)
    direct = _skin_key_from_norm(q)
    if direct:
        return direct
    for word, key in _SKIN_AR_TO_KEY.items():
        if _contains(q, word):
            return key
    return ""


def _slots_from_intent(intent: str, query: str = "") -> Dict[str, Any]:
    q = normalize_text(query)
    slots: Dict[str, Any] = {}
    if intent in {"face_cleanser", "face_cleanser_with_skin"}:
        slots.update({"selected_category": "skin_care", "selected_product_type": "face_cleanser", "body_area": "face", "form": "cleanser"})
        skin = extract_skin_type(q)
        if skin:
            slots["selected_skin_type"] = skin
    elif intent == "generic_serum":
        slots.update({"selected_category": "skin_care", "selected_product_type": "serum", "body_area": "face", "form": "serum"})
    return slots


def _guided_state(user_state: dict) -> dict:
    state = (user_state or {}).get(GUIDED_STATE_KEY) or {}
    if not isinstance(state, dict):
        return {}
    try:
        expires_at = int(state.get("expires_at") or 0)
    except Exception:
        expires_at = 0
    if expires_at and expires_at < int(time.time()):
        return {}
    return state


def _canonical_option_id(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    direct = _SELECTION_ID_ALIASES.get(raw)
    if direct:
        return direct
    norm = normalize_text(raw)
    for label, cid in _DIRECT_MENU_LABELS.items():
        if norm == normalize_text(label):
            return cid
    return _SELECTION_ID_ALIASES.get(norm, norm)


def _selected_option_from_input(text: str, options: Sequence[dict]) -> Optional[dict]:
    """Select a menu row by number, WhatsApp row/button id, or visible label.

    V20.1 fix: WhatsApp interactive replies usually send row IDs like
    ``browse_categories``/``skin_care`` rather than Arabic text. The previous
    implementation only accepted numeric input, so button/list replies fell
    through to product search.
    """
    q_raw = str(text or "").strip()
    q_norm = normalize_text(q_raw)
    if q_norm.isdigit():
        idx = int(q_norm) - 1
        if 0 <= idx < len(options):
            return dict(options[idx])
    q_id = _canonical_option_id(q_raw)
    for opt in options or []:
        opt_id = _canonical_option_id(opt.get("id"))
        opt_label = normalize_text(opt.get("label") or opt.get("name") or opt.get("title") or "")
        if q_id and opt_id and q_id == opt_id:
            return dict(opt)
        if q_norm and opt_label and q_norm == opt_label:
            return dict(opt)
    return None


# Backward-compatible name used by older tests/helpers.
def _selected_option_from_number(text: str, options: Sequence[dict]) -> Optional[dict]:
    return _selected_option_from_input(text, options)


def _is_same_or_compatible_skin(requested: str, product_skin: str) -> bool:
    if not requested or requested == "unknown":
        return True
    if not product_skin:
        # Unknown catalog skin is not safe enough when customer selected a skin type.
        return False
    if product_skin == requested:
        return True
    allowed = _SKIN_COMPATIBLE.get(requested, {requested})
    return product_skin in allowed


def _is_same_or_compatible_use(requested: str, product_use: str) -> bool:
    if not requested:
        return True
    if not product_use:
        return False
    if product_use == requested:
        return True
    if requested == "acne" and product_use in {"oily_skin", "acne_prone", "oil_control"}:
        return True
    if requested == "hydration" and product_use in {"dry_skin", "barrier_repair", "moisturizing"}:
        return True
    return False


def _target_type_from_slots(slots: Dict[str, Any]) -> str:
    ptype = slots.get("selected_product_type") or slots.get("form") or ""
    return {
        "face_cleanser": "cleanser",
        "body_wash": "cleanser",
        "baby_wash": "cleanser",
        "feminine_wash": "cleanser",
        "cream_moisturizing": "cream",
        "cream_acne": "cream",
        "cream_itch": "cream",
        "cream_sunscreen": "sunscreen",
        "cream_brightening": "cream",
        "hair_oil": "oil",
        "hair_loss": "shampoo",
        "anti_dandruff": "shampoo",
    }.get(str(ptype), str(ptype))


def filter_products_by_guided_slots(slots: Dict[str, Any], products: Sequence[dict], limit: int = MAX_GUIDED_OPTIONS) -> List[dict]:
    target_type = _target_type_from_slots(slots)
    target_area = str(slots.get("body_area") or "")
    skin = str(slots.get("selected_skin_type") or "")
    use_case = str(slots.get("selected_use_case") or "")
    brand = normalize_text(slots.get("brand") or "")
    out: List[Tuple[int, dict]] = []
    for product in products:
        if _is_exact_only_product(product):
            continue
        if not _is_available(product):
            continue
        if _product_category(product) != "cosmetic":
            continue
        ptype = _product_type(product)
        if target_type and ptype != target_type:
            continue
        area = _product_area(product)
        identity = _product_identity(product)
        if target_area == "face":
            if area in {"body", "baby", "hair", "mouth"}:
                continue
            if any(_contains(identity, w) for w in ["body wash", "baby wash", "shampoo", "hair", "غسول جسم", "غسول اطفال", "شامبو"]):
                continue
        elif target_area and area and area != target_area:
            continue
        if brand:
            product_brand = normalize_text(_field(product, "brand", "company"))
            if product_brand and product_brand != brand:
                continue
        pskin = _product_skin(product)
        if not _is_same_or_compatible_skin(skin, pskin):
            continue
        puse = _product_use(product)
        if not _is_same_or_compatible_use(use_case, puse):
            continue
        score = 0
        if area == target_area:
            score += 20
        if pskin == skin:
            score += 20
        if puse == use_case:
            score += 10
        if brand and normalize_text(_field(product, "brand", "company")) == brand:
            score += 10
        out.append((score, product))
    out.sort(key=lambda x: (x[0], normalize_text(x[1].get("name"))), reverse=True)
    return [p for _, p in out[:limit]]


def cosmetic_alternative_fit_gate(target_slots: Dict[str, Any], alternatives: Sequence[dict], limit: int = 3) -> List[dict]:
    """Strict gate used by guided/image flows before showing cosmetic alternatives."""
    return filter_products_by_guided_slots(target_slots, alternatives, limit=limit)


def _pharmacy_name() -> str:
    return os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")


def build_main_menu() -> GuidedResult:
    reply = _menu_reply(
        f"أهلاً بك في {_pharmacy_name()} 🌿\nاختر طريقة البحث:",
        _MAIN_MENU,
    )
    return GuidedResult(True, reply, "guided_main_menu", _state("main_menu", "main_menu", last_options=_MAIN_MENU, last_options_type="main_menu"))


def _ask_categories() -> GuidedResult:
    reply = _menu_reply("اختر القسم:", _CATEGORY_MENU)
    return GuidedResult(True, reply, "guided_categories", _state("browse_categories", "categories", last_options=_CATEGORY_MENU, last_options_type="categories"))


def _ask_skin_care() -> GuidedResult:
    reply = _menu_reply("ماذا تريد من عناية البشرة؟", _SKIN_CARE_MENU)
    return GuidedResult(True, reply, "guided_skin_care", _state("skin_care", "product_type", selected_category="skin_care", last_options=_SKIN_CARE_MENU))


def _ask_hair_care() -> GuidedResult:
    reply = _menu_reply("ماذا تريد من عناية الشعر؟", _HAIR_CARE_MENU)
    return GuidedResult(True, reply, "guided_hair_care", _state("hair_care", "product_type", selected_category="hair_care", last_options=_HAIR_CARE_MENU))


def _ask_medicine_menu(products: Sequence[dict]) -> GuidedResult:
    opts = product_navigator.medicine_menu(products)
    reply = _menu_reply("اختر قسم الأدوية أو ابحث باسم الدواء:", opts)
    return GuidedResult(True, reply, "guided_medicine_menu", _state("medicine", "medicine_category", selected_category="medicine", last_options=opts, last_options_type="medicine_categories"))


def _ask_cleanser_kind() -> GuidedResult:
    opts = [
        {"id": "face_cleanser", "label": "غسول وجه"},
        {"id": "body_wash", "label": "غسول جسم"},
        {"id": "baby_wash", "label": "غسول أطفال"},
        {"id": "feminine_wash", "label": "غسول طبي/نسائي"},
    ]
    reply = _menu_reply("تقصد غسول لأي استخدام؟", opts)
    return GuidedResult(True, reply, "guided_ask_cleanser_kind", _state("skin_care", "cleanser_kind", last_options=opts))


def _ask_cream_use() -> GuidedResult:
    opts = [
        {"id": "cream_moisturizing", "label": "ترطيب"},
        {"id": "cream_acne", "label": "حبوب"},
        {"id": "cream_itch", "label": "التهاب/حكة"},
        {"id": "cream_sunscreen", "label": "واقي شمس"},
        {"id": "cream_brightening", "label": "تفتيح"},
    ]
    reply = _menu_reply("كريم لأي استخدام؟", opts)
    return GuidedResult(True, reply, "guided_ask_cream_use", _state("skin_care", "cream_use", last_options=opts))


def _ask_skin_type(slots: Dict[str, Any]) -> GuidedResult:
    title = "نوع البشرة؟"
    state = dict(slots)
    state.update({"current_flow": "skin_care", "step": "skin_type", "last_options": _SKIN_MENU, "last_options_type": "menu", "expires_at": int(time.time()) + GUIDED_TTL_SECONDS})
    return GuidedResult(True, _menu_reply(title, _SKIN_MENU), "guided_ask_skin_type", {GUIDED_STATE_KEY: state})


def _canonical_brand(norm: str) -> str:
    if norm in {"cerave", "cera ve", "سيرافي", "سيرا في"}:
        return "cerave"
    if norm in {"rilastil", "ريلاستيل"}:
        return "rilastil"
    if norm in {"bioderma", "بيوديرما"}:
        return "bioderma"
    if norm in {"la roche", "laroche", "la roche posay", "لاروش", "لاروش بوزيه"}:
        return "la_roche"
    if norm in {"eucerin", "يوسرين"}:
        return "eucerin"
    return norm.replace(" ", "_")


def _ask_brand_type(brand_query: str = "CeraVe") -> GuidedResult:
    brand = _canonical_brand(normalize_text(brand_query))
    label = {"cerave": "CeraVe", "rilastil": "Rilastil", "bioderma": "Bioderma", "la_roche": "La Roche", "eucerin": "Eucerin"}.get(brand, brand_query)
    opts = _BRAND_PRODUCT_MENUS.get(brand, _CERAVE_TYPE_MENU)
    reply = _menu_reply(f"أي نوع من {label}؟", opts)
    return GuidedResult(True, reply, "guided_brand_type", _state("brand", "brand_product_type", brand=brand, last_options=opts))


def _ask_cerave_type() -> GuidedResult:
    return _ask_brand_type("CeraVe")


def _paged_products_reply(slots: Dict[str, Any], hits: Sequence[dict], page: int = 0) -> GuidedResult:
    page = max(0, int(page or 0))
    start = page * MAX_GUIDED_OPTIONS
    end = start + MAX_GUIDED_OPTIONS
    visible = list(hits[start:end])
    rows = []
    for i, p in enumerate(visible, 1):
        price = _price_text(p)
        price_part = f" — {price}" if price else ""
        rows.append(f"{i}. {_h(p.get('name'))}{price_part}")
    reply = "هذه المنتجات المناسبة حسب الاختيارات:\n\n" + "\n".join(rows)
    if end < len(hits):
        reply += "\n\nاكتب المزيد لعرض نتائج أخرى."
    reply += "\n\nاكتب رقم المنتج للحجز أو الاستفسار."
    state = dict(slots)
    state.update({
        "current_flow": "guided_results",
        "step": "product_selection",
        "last_options": visible,
        "all_options": list(hits),
        "page": page,
        "last_options_type": "products",
        "expires_at": int(time.time()) + GUIDED_TTL_SECONDS,
    })
    return GuidedResult(True, reply, "guided_products", {GUIDED_STATE_KEY: state}, options=visible)


def _show_products_or_ask(slots: Dict[str, Any], products: Sequence[dict]) -> GuidedResult:
    hits = filter_products_by_guided_slots(slots, products, limit=50)
    if not hits:
        skin_txt = _SKIN_LABELS.get(str(slots.get("selected_skin_type") or ""), str(slots.get("selected_skin_type") or ""))
        reply = f"لم أجد بدائل مناسبة بنفس النوع والاستخدام{(' ونوع البشرة ' + skin_txt) if skin_txt else ''}.\n\nاكتب اسم منتج محدد أو اختر نوع بشرة آخر."
        return GuidedResult(True, reply, "guided_no_safe_options", {GUIDED_STATE_KEY: dict(slots, step="no_safe_options", last_options=[])})
    # Products are shown only after guided slots are specific enough; prices are allowed here because every displayed option is an exact product option.
    return _paged_products_reply(slots, hits, page=0)


def _handle_product_selection(phone: str, text: str, state: dict) -> Optional[GuidedResult]:
    opts = state.get("last_options") or []
    opt = _selected_option_from_input(text, opts)
    if opt and opt.get("name"):
        price = _price_text(opt)
        available = "متوفر" if _is_available(opt) else "غير متوفر"
        reply = f"✅ المنتج المحدد:\n{_h(opt.get('name'))}\nالحالة: {available}"
        if price:
            reply += f"\nالسعر: {price}"
        reply += "\n\nللحجز اكتب: نعم"
        return GuidedResult(True, reply, "guided_product_selected", {"last_product": opt, GUIDED_STATE_KEY: None}, product=opt)
    return None


def handle_menu_selection(phone: str, selection: str, user_state: dict, products: Sequence[dict]) -> Optional[GuidedResult]:
    state = _guided_state(user_state)
    if not state:
        return None
    if normalize_text(selection) in _PAGE_MORE_WORDS and state.get("all_options"):
        next_page = int(state.get("page") or 0) + 1
        slots = dict(state)
        hits = list(state.get("all_options") or [])
        if next_page * MAX_GUIDED_OPTIONS < len(hits):
            return _paged_products_reply(slots, hits, page=next_page)
        return GuidedResult(True, "لا توجد نتائج إضافية حالياً. اختر رقم منتج من القائمة أو اكتب اسم منتج آخر.", "guided_no_more_results", {GUIDED_STATE_KEY: state})
    # Product selection from final guided result list.
    selected_product = _handle_product_selection(phone, selection, state)
    if selected_product:
        return selected_product
    opts = state.get("last_options") or []
    chosen = _selected_option_from_input(selection, opts)
    if not chosen:
        return None
    cid = str(chosen.get("id") or "")
    step = str(state.get("step") or "")

    canonical_cid = _canonical_option_id(cid)
    if canonical_cid == "browse_categories":
        return _ask_categories()
    if canonical_cid == "search_by_name":
        return GuidedResult(True, "اكتب اسم المنتج الكامل كما هو على العلبة، أو أرسل صورة واضحة للواجهة الأمامية.", "guided_search_instruction", {GUIDED_STATE_KEY: None})
    if canonical_cid == "send_image":
        return GuidedResult(True, "أرسل صورة واضحة للواجهة الأمامية للمنتج، ويُفضّل أن يظهر الاسم والحجم بوضوح.", "guided_image_instruction", {GUIDED_STATE_KEY: None})
    if canonical_cid == "orders":
        return GuidedResult(True, "للحجز بعد ظهور منتج متوفر اكتب: نعم. ولإلغاء أي خطوة اكتب: لا", "guided_orders_instruction", {GUIDED_STATE_KEY: None})
    cid = canonical_cid

    if step == "medicine_category":
        if cid == "search_medicine":
            return GuidedResult(True, "اكتب اسم الدواء. إذا كان له أكثر من شكل أو جرعة سأطلب التوضيح قبل عرض السعر.", "guided_medicine_instruction", {GUIDED_STATE_KEY: None})
        return GuidedResult(True, "اكتب اسم الدواء داخل هذا القسم. لا أعطي بدائل دوائية تلقائياً، وسأسألك عن الشكل أو الجرعة إذا كان الاسم ناقصاً.", "guided_medicine_category_instruction", {GUIDED_STATE_KEY: None})

    if step in {"category", "categories"}:
        if cid == "skin_care":
            return _ask_skin_care()
        if cid == "hair_care":
            return _ask_hair_care()
        if cid == "medicine":
            return _ask_medicine_menu(products)
        return GuidedResult(True, "هذه الفئة تحتاج اسم منتج محدد حالياً. اكتب الاسم أو أرسل صورة واضحة.", "guided_category_not_ready", {GUIDED_STATE_KEY: None})

    if step in {"product_type", "cleanser_kind", "brand_product_type"}:
        slots = dict(state)
        slots.update({"selected_product_type": cid})
        if cid == "face_cleanser":
            slots.update({"selected_category": "skin_care", "form": "cleanser", "body_area": "face"})
            return _ask_skin_type(slots)
        if cid in {"moisturizer", "serum", "cream_moisturizing", "lotion"}:
            slots.update({"selected_category": "skin_care", "body_area": "face", "form": _target_type_from_slots(slots)})
            return _ask_skin_type(slots)
        if cid == "sunscreen":
            slots.update({"selected_category": "skin_care", "body_area": "face", "form": "sunscreen", "selected_use_case": "sun_protection"})
            return _ask_skin_type(slots)
        if cid in {"body_wash", "baby_wash", "feminine_wash"}:
            slots.update({"form": "cleanser", "body_area": "body" if cid == "body_wash" else "baby" if cid == "baby_wash" else "feminine"})
            return _show_products_or_ask(slots, products)
        if cid in {"shampoo", "anti_dandruff", "conditioner", "hair_oil", "hair_loss"}:
            slots.update({"selected_category": "hair_care", "body_area": "hair", "form": _target_type_from_slots(slots)})
            if cid == "anti_dandruff":
                slots["selected_use_case"] = "anti_dandruff"
            return _show_products_or_ask(slots, products)
        return _show_products_or_ask(slots, products)

    if step == "cream_use":
        slots = dict(state)
        slots.update({"selected_product_type": cid, "body_area": "face", "form": _target_type_from_slots({"selected_product_type": cid})})
        if cid == "cream_moisturizing":
            slots["selected_use_case"] = "hydration"
        elif cid == "cream_acne":
            slots["selected_use_case"] = "acne"
        elif cid == "cream_sunscreen":
            slots["selected_use_case"] = "sun_protection"
        return _ask_skin_type(slots)

    if step == "skin_type":
        slots = dict(state)
        if cid != "unknown":
            slots["selected_skin_type"] = cid
        else:
            slots.pop("selected_skin_type", None)
        return _show_products_or_ask(slots, products)
    return None


def handle_guided_query(phone: str, text: str, user_state: dict, products: Sequence[dict]) -> Optional[GuidedResult]:
    # Existing guided menu state has priority for numeric/id/label selections.
    state_result = handle_menu_selection(phone, text, user_state, products)
    if state_result:
        return state_result

    q = normalize_text(text)
    canonical = _canonical_option_id(text)
    # If state was lost but the user sends a top-level menu label, keep them in
    # the guided route instead of letting product search answer NOT_AVAILABLE.
    if canonical == "browse_categories":
        return _ask_categories()
    if canonical == "search_by_name":
        return GuidedResult(True, "اكتب اسم المنتج الكامل كما هو على العلبة، أو أرسل صورة واضحة للواجهة الأمامية.", "guided_search_instruction", {GUIDED_STATE_KEY: None})
    if canonical == "send_image":
        return GuidedResult(True, "أرسل صورة واضحة للواجهة الأمامية للمنتج، ويُفضّل أن يظهر الاسم والحجم بوضوح.", "guided_image_instruction", {GUIDED_STATE_KEY: None})
    if canonical == "skin_care":
        return _ask_skin_care()
    if canonical == "hair_care":
        return _ask_hair_care()
    if canonical == "medicine":
        return _ask_medicine_menu(products)
    # A bare number without an active guided/variant/order state should not be
    # treated as a product query. Show the main menu again.
    if q.isdigit() and 1 <= int(q) <= 10 and not any((user_state or {}).get(k) for k in ["pending_variant_options", "pending_alternatives", "last_product"]):
        return build_main_menu()

    intent = detect_guided_intent(text)
    if intent == "main_menu":
        return build_main_menu()
    if intent == "generic_cleanser":
        return _ask_cleanser_kind()
    if intent == "generic_cream":
        return _ask_cream_use()
    if intent == "brand_only":
        return _ask_brand_type(text)
    if intent == "face_cleanser":
        return _ask_skin_type(_slots_from_intent(intent, text))
    if intent == "face_cleanser_with_skin":
        slots = _slots_from_intent(intent, text)
        if slots.get("selected_skin_type"):
            return _show_products_or_ask(slots, products)
        return _ask_skin_type(slots)
    if intent == "generic_lotion":
        return _ask_skin_type({"selected_category": "skin_care", "selected_product_type": "lotion", "body_area": "face", "form": "lotion"})
    if intent == "generic_serum":
        return _ask_skin_type(_slots_from_intent(intent, text))
    if intent == "generic_moisturizer":
        return _ask_skin_type({"selected_category": "skin_care", "selected_product_type": "moisturizer", "body_area": "face", "form": "moisturizer", "selected_use_case": "hydration"})
    if intent == "generic_sunscreen":
        return _ask_skin_type({"selected_category": "skin_care", "selected_product_type": "sunscreen", "body_area": "face", "form": "sunscreen", "selected_use_case": "sun_protection"})
    if intent == "generic_shampoo":
        return _ask_hair_care()
    return None


def build_image_cosmetic_clarification(ai_data: dict) -> GuidedResult:
    """Ask for missing skin type/use after a cosmetic image is not exact."""
    form = normalize_text(ai_data.get("form") or ai_data.get("product_type") or ai_data.get("type") or "")
    if form in {"face wash", "wash"}:
        form = "cleanser"
    slots = {
        "current_flow": "image_cosmetic_alternative",
        "step": "skin_type",
        "selected_category": "skin_care",
        "selected_product_type": "face_cleanser" if form == "cleanser" else form or "cosmetic",
        "form": form or "cleanser",
        "body_area": "face" if normalize_text(ai_data.get("body_area") or ai_data.get("target_area") or "") in {"", "unknown", "face", "skin"} else normalize_text(ai_data.get("body_area") or ai_data.get("target_area")),
        "brand": normalize_text(ai_data.get("brand") or ""),
        "last_options": _SKIN_MENU,
    }
    skin = normalize_text(ai_data.get("skin_type") or "")
    if skin:
        slots["selected_skin_type"] = skin.replace(" ", "_")
    use = normalize_text(ai_data.get("use_case") or "")
    if use:
        slots["selected_use_case"] = use.replace(" ", "_")
    slots["expires_at"] = int(time.time()) + GUIDED_TTL_SECONDS
    slots["last_options_type"] = "menu"
    if slots.get("selected_skin_type") or slots.get("selected_use_case"):
        return GuidedResult(True, "", "guided_image_slots_ready", {GUIDED_STATE_KEY: slots})
    reply = _menu_reply("المنتج غير موجود حالياً. هل تريد بديلًا لأي نوع بشرة؟", _SKIN_MENU)
    return GuidedResult(True, reply, "guided_image_ask_skin_type", {GUIDED_STATE_KEY: slots})


def build_whatsapp_list_payload(to_number: str, body: str, button_text: str, rows: Sequence[dict]) -> dict:
    """Optional WhatsApp List Message payload for callers that support interactive sends."""
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "list",
            "body": {"text": str(body or "")[:1024]},
            "action": {
                "button": str(button_text or "اختر")[:20],
                "sections": [{"title": "الخيارات", "rows": [{"id": str(r.get("id") or i), "title": str(r.get("label") or r.get("name") or r.get("id"))[:24]} for i, r in enumerate(rows, 1)]}],
            },
        },
    }
