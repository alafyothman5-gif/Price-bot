#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/pricebot"
BACKUP_ROOT="/root/pricebot_backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
DEST="$BACKUP_ROOT/pricebot_backup_$STAMP"

[[ "${PWD}" == "$APP_DIR" ]] || { echo "ERROR: شغّل السكربت من $APP_DIR فقط." >&2; exit 1; }
[[ -d "/opt/medmcq" || -d "/opt/MedMCQ" ]] && echo "INFO: MedMCQ موجود ومحمي. لن يتم لمسه."
mkdir -p "$DEST"

tar --exclude='./venv' --exclude='./.venv' --exclude='./backups' --exclude='./.git' --exclude='./__pycache__' \
    --exclude='./pricebot.db' --exclude='./pricebot.db-*' --exclude='./.env' \
    -czf "$DEST/code.tar.gz" -C "$APP_DIR" .
[[ -f "$APP_DIR/pricebot.db" ]] && cp -a "$APP_DIR/pricebot.db" "$DEST/pricebot.db"
[[ -f "$APP_DIR/.env" ]] && cp -a "$APP_DIR/.env" "$DEST/.env"
[[ -d "$APP_DIR/media" ]] && tar -czf "$DEST/media.tar.gz" -C "$APP_DIR" media
[[ -d "$APP_DIR/uploads" ]] && tar -czf "$DEST/uploads.tar.gz" -C "$APP_DIR" uploads
[[ -f "/etc/systemd/system/pricebot.service" ]] && cp -a "/etc/systemd/system/pricebot.service" "$DEST/pricebot.service"

cat > "$DEST/manifest.txt" <<EOF
created_at=$STAMP
app_dir=$APP_DIR
contains_code=1
contains_db=$([[ -f "$APP_DIR/pricebot.db" ]] && echo 1 || echo 0)
contains_env=$([[ -f "$APP_DIR/.env" ]] && echo 1 || echo 0)
EOF

echo "PRICEBOT_BACKUP_OK: $DEST"
