#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Safe PriceBot search-index rebuild.

Builds a temporary table first, then atomically swaps it into place. It never
modifies the products table and verifies product count before/after.
"""
from __future__ import annotations
import os
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database  # noqa: E402
from services.search_engine import product_index_row, invalidate_runtime_cache  # noqa: E402

MIN_PRODUCTS = int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "0") or "0")


def _assert_products_healthy(count: int, stage: str) -> None:
    if MIN_PRODUCTS and count < MIN_PRODUCTS:
        raise RuntimeError(f"DB_PROTECTION_FAILED | stage={stage} | products_count={count} | min={MIN_PRODUCTS}")


def rebuild_search_index() -> dict:
    database.init_db()
    before = database.count_products()
    _assert_products_healthy(before, "before_search_index")
    products = database.load_products()
    if len(products) != before:
        # Do not fail for harmless concurrent reads, but expose it in the report.
        print(f"DB_PROTECTION_WARNING | loaded_products={len(products)} | count_products={before}")

    stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
    tmp = f"product_search_index_tmp_{stamp}"
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    inserted = 0
    exact_only = 0

    with database.get_db_connection() as conn:
        conn.execute(f"""
            CREATE TABLE {tmp} (
                product_id TEXT,
                normalized_name TEXT,
                normalized_brand TEXT,
                normalized_aliases TEXT,
                normalized_ocr_keywords TEXT,
                tokens_json TEXT,
                strong_tokens_json TEXT,
                weak_tokens_json TEXT,
                category TEXT,
                product_type TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                search_mode TEXT,
                quality_status TEXT,
                created_at TEXT
            )
        """)
        try:
            for p in products:
                row = product_index_row(p)
                if row.get("search_mode") == "exact_only" or row.get("quality_status") == "exact_only":
                    exact_only += 1
                conn.execute(
                    f"""
                    INSERT INTO {tmp}(product_id,normalized_name,normalized_brand,normalized_aliases,normalized_ocr_keywords,tokens_json,strong_tokens_json,weak_tokens_json,category,product_type,form,strength,size,search_mode,quality_status,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (row["product_id"], row["normalized_name"], row["normalized_brand"], row["normalized_aliases"], row["normalized_ocr_keywords"], row["tokens_json"], row["strong_tokens_json"], row["weak_tokens_json"], row["category"], row["product_type"], row["form"], row["strength"], row["size"], row["search_mode"], row["quality_status"], now),
                )
                inserted += 1
            conn.execute(f"CREATE INDEX idx_{tmp}_name ON {tmp}(normalized_name)")
            conn.execute(f"CREATE INDEX idx_{tmp}_brand ON {tmp}(normalized_brand)")
            conn.execute(f"CREATE INDEX idx_{tmp}_pid ON {tmp}(product_id)")
            conn.commit()
            after_build = database.count_products()
            if after_build != before:
                raise RuntimeError(f"DB_PROTECTION_FAILED | stage=after_build_search_index | before={before} | after={after_build}")
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DROP TABLE IF EXISTS product_search_index")
            conn.execute(f"ALTER TABLE {tmp} RENAME TO product_search_index")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_name ON product_search_index(normalized_name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_brand ON product_search_index(normalized_brand)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_pid ON product_search_index(product_id)")
            conn.commit()
        except Exception:
            conn.rollback()
            try:
                conn.execute(f"DROP TABLE IF EXISTS {tmp}")
                conn.commit()
            except Exception:
                pass
            raise

    after = database.count_products()
    if after != before:
        raise RuntimeError(f"DB_PROTECTION_FAILED | stage=after_search_index | before={before} | after={after}")
    invalidate_runtime_cache()
    return {"products_before": before, "products_after": after, "indexed": inserted, "exact_only": exact_only}


def main() -> None:
    report = rebuild_search_index()
    print("PRICEBOT_SEARCH_INDEX_REBUILD_OK")
    print(f"INDEX_REBUILD_OK | products_before={report['products_before']} | products_after={report['products_after']} | indexed={report['indexed']} | exact_only={report['exact_only']}")


if __name__ == "__main__":
    main()
