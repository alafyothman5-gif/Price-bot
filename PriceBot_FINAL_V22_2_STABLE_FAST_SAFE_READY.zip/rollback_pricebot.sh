#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/pricebot"
BACKUP_ROOT="/root/pricebot_backups"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"

[[ "${PWD}" == "$APP_DIR" ]] || { echo "ERROR: شغّل السكربت من $APP_DIR فقط." >&2; exit 1; }
[[ -d "/opt/medmcq" || -d "/opt/MedMCQ" ]] && echo "INFO: MedMCQ موجود ومحمي. لن يتم لمسه."

mapfile -t BACKUPS < <(find "$BACKUP_ROOT" -maxdepth 1 -type d \( -name 'pricebot_backup_*' -o -name 'pricebot_v22_2_predeploy_*' \) 2>/dev/null | sort -r)
[[ ${#BACKUPS[@]} -gt 0 ]] || { echo "ERROR: لا توجد backups داخل $BACKUP_ROOT" >&2; exit 1; }

echo "آخر النسخ الاحتياطية:"
for i in "${!BACKUPS[@]}"; do
  printf '%s) %s\n' "$((i+1))" "${BACKUPS[$i]}"
  [[ $i -ge 9 ]] && break
done

CHOICE="${1:-1}"
[[ "$CHOICE" =~ ^[0-9]+$ && "$CHOICE" -ge 1 && "$CHOICE" -le "${#BACKUPS[@]}" ]] || { echo "ERROR: اختيار غير صحيح. مثال: ./rollback_pricebot.sh 1" >&2; exit 1; }
SRC="${BACKUPS[$((CHOICE-1))]}"
[[ -f "$SRC/code.tar.gz" ]] || { echo "ERROR: code.tar.gz غير موجود في $SRC" >&2; exit 1; }

echo "سيتم إرجاع ملفات الكود من: $SRC"
tar -xzf "$SRC/code.tar.gz" -C "$APP_DIR"

if [[ "${RESTORE_ENV:-false}" == "true" && -f "$SRC/.env" ]]; then
  cp -a "$SRC/.env" "$APP_DIR/.env"
  echo "RESTORED_ENV=1"
else
  echo "RESTORED_ENV=0 حافظنا على .env الحالي"
fi

if [[ "${RESTORE_DB:-false}" == "true" && -f "$SRC/pricebot.db" ]]; then
  cp -a "$SRC/pricebot.db" "$APP_DIR/pricebot.db"
  echo "RESTORED_DB=1"
else
  echo "RESTORED_DB=0 حافظنا على pricebot.db الحالي"
fi

if [[ "${RESTORE_MEDIA:-false}" == "true" && -f "$SRC/media.tar.gz" ]]; then
  tar -xzf "$SRC/media.tar.gz" -C "$APP_DIR"
  echo "RESTORED_MEDIA=1"
fi
if [[ "${RESTORE_UPLOADS:-false}" == "true" && -f "$SRC/uploads.tar.gz" ]]; then
  tar -xzf "$SRC/uploads.tar.gz" -C "$APP_DIR"
  echo "RESTORED_UPLOADS=1"
fi

timeout 15s sudo systemctl restart "$SERVICE_NAME" || {
  echo "SERVICE_RESTART_TIMEOUT | trying start" >&2
  sudo systemctl kill -s TERM "$SERVICE_NAME" || true
  sleep 2
  sudo systemctl start "$SERVICE_NAME" || true
}
sudo systemctl status "$SERVICE_NAME" --no-pager -l || true
echo "PRICEBOT_ROLLBACK_OK"
