#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final V22.2 stability/speed/data-protection acceptance tests.

The test DB is isolated. It verifies that migrations/index rebuilds do not alter
products, that greetings/menu choices bypass product search, and that exact
lookup is fast through the V22.2 DB/index path.
"""
from __future__ import annotations
import os
import tempfile
import time
from pathlib import Path

TMP_DIR = tempfile.mkdtemp(prefix="pricebot_v22_2_acceptance_")
os.environ["PRICEBOT_DB_FILE"] = str(Path(TMP_DIR) / "acceptance_v22_2.db")
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["PRICEBOT_TEXT_TIMEOUT_SECONDS"] = "1.5"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-v22-2-code"
os.environ["PRICEBOT_DEBUG_ENDPOINTS"] = "false"
os.environ["PRICEBOT_ENV"] = "production"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"

import database  # noqa: E402
import matcher  # noqa: E402
from services import search_engine  # noqa: E402
from tools.rebuild_search_index import rebuild_search_index  # noqa: E402
from tools.rebuild_product_nav_index import rebuild_product_nav_index  # noqa: E402


def seed_catalog(n: int = 1205) -> None:
    database.init_db()
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        conn.execute("DELETE FROM conversation_state")
        rows = [
            {"product_id":"PB1","name":"Photoblok 50+","normalized_name":"photoblok 50","brand":"Photoblok","product_family":"Photoblok 50+","category":"cosmetic","form":"sunscreen","body_area":"face","use_case":"sun_protection","skin_type":"normal_combination_skin","size":"50ml","aliases":"Photoblok 50+; +Photoblok 50","ocr_keywords":"photoblok 50 spf sunscreen face","price":"70","available":"متوفر"},
            {"product_id":"X123","name":"1,2,3 Extra","normalized_name":"1 2 3 extra","brand":"","product_family":"123 Extra","category":"other","form":"product","body_area":"","use_case":"","skin_type":"","size":"","aliases":"123; Extra 1,2,3","ocr_keywords":"123 extra","price":"20","available":"متوفر"},
            {"product_id":"GYNO1","name":"gyno-daktarin vag cream","normalized_name":"gyno daktarin vag cream","brand":"gyno-daktarin","product_family":"gyno-daktarin","category":"medicine","form":"cream","body_area":"","use_case":"","skin_type":"","size":"","aliases":"gyno daktarin vag cream","ocr_keywords":"gyno daktarin vag cream","price":"55","available":"متوفر"},
            {"product_id":"C1","name":"CeraVe Hydrating Cleanser 236ml","normalized_name":"cerave hydrating cleanser 236ml","brand":"CeraVe","product_family":"Hydrating Cleanser","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"236ml","aliases":"cerave hydrating cleanser","ocr_keywords":"cerave hydrating cleanser dry skin face wash","price":"125","available":"متوفر"},
            {"product_id":"B1","name":"Bioderma Sebium Gel Moussant 200ml","normalized_name":"bioderma sebium gel moussant 200ml","brand":"Bioderma","product_family":"Sebium Gel Moussant","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"200ml","aliases":"bioderma sebium gel moussant","ocr_keywords":"bioderma sebium cleanser oily skin face wash","price":"65","available":"متوفر"},
        ]
        for i in range(n - len(rows)):
            rows.append({"product_id":f"DUMMY{i}","name":f"Dummy Product {i}","normalized_name":f"dummy product {i}","brand":"Dummy","product_family":"Dummy","category":"other","form":"product","body_area":"","use_case":"","skin_type":"","size":"","aliases":"","ocr_keywords":"","price":"1","available":"متوفر"})
        for p in rows:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,product_family,category,form,body_area,use_case,skin_type,size,aliases,ocr_keywords,image_ocr_keywords,price,available)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p["product_id"], p["name"], p["normalized_name"], p["brand"], p["product_family"], p["category"], p["form"], p["body_area"], p["use_case"], p["skin_type"], p["size"], p["aliases"], p["ocr_keywords"], p["ocr_keywords"], p["price"], p["available"]),
            )
        conn.commit()
    matcher.invalidate_product_cache()
    search_engine.invalidate_runtime_cache()


def ask(phone: str, text: str):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))


def assert_fast(label: str, elapsed_ms: float, limit_ms: float = 700.0) -> None:
    assert elapsed_ms <= limit_ms, f"{label} too slow: {elapsed_ms:.1f}ms > {limit_ms}ms"


def timed(fn, *args):
    start = time.perf_counter()
    result = fn(*args)
    return result, (time.perf_counter() - start) * 1000


def main() -> None:
    seed_catalog()
    before = database.count_products()
    assert before >= 1000, before

    database.init_db(); database.ensure_v19_tables(); database.ensure_v22_tables()
    assert database.count_products() == before, "migration changed products count"

    r1 = rebuild_search_index()
    assert r1["products_before"] == before and r1["products_after"] == before, r1
    assert database.count_products() == before, "search index rebuild changed products count"
    r2 = rebuild_product_nav_index()
    assert r2["products_before"] == before and r2["products_after"] == before, r2
    assert database.count_products() == before, "nav index rebuild changed products count"

    calls = {"search_db": 0}
    original_search_db = search_engine.search_products_db
    def blocked_search_db(*a, **kw):
        calls["search_db"] += 1
        raise AssertionError("product search must not run for menu/greeting route")
    search_engine.search_products_db = blocked_search_db
    greeting, greeting_ms = timed(ask, "route_greeting", "السلام عليكم")
    assert greeting.decision == "guided_main_menu", greeting.reply
    assert calls["search_db"] == 0, calls
    assert_fast("greeting menu", greeting_ms)
    second, second_ms = timed(ask, "route_greeting", "2")
    assert second.decision == "guided_categories", second.reply
    assert calls["search_db"] == 0, calls
    assert_fast("menu choice", second_ms)
    generic, generic_ms = timed(ask, "route_generic", "غسول")
    assert generic.decision.startswith("guided"), generic.reply
    assert calls["search_db"] == 0, calls
    assert_fast("generic cleanser guided", generic_ms)
    search_engine.search_products_db = original_search_db

    exact, exact_ms = timed(ask, "route_exact", "Photoblok 50+")
    assert exact.decision in {"matched", "matched_unknown_availability"}, exact.reply
    assert "Photoblok 50+" in exact.reply and "السعر" in exact.reply, exact.reply
    assert_fast("Photoblok exact", exact_ms)

    # Warm once because SQLite may configure WAL on the first numeric exact lookup.
    ask("route_123_warm", "123")
    exact_123, exact_123_ms = timed(ask, "route_123", "123")
    assert exact_123.decision in {"matched", "matched_unknown_availability"}, exact_123.reply
    assert "1,2,3 Extra" in exact_123.reply, exact_123.reply
    assert_fast("123 exact", exact_123_ms)

    # A bare number without active menu state should go to main menu, not product search.
    bare, bare_ms = timed(ask, "route_bare", "2")
    assert bare.decision == "guided_main_menu", bare.reply
    assert_fast("bare number menu fallback", bare_ms)

    timeout_fallback = matcher.safe_timeout_fallback_result("route_timeout", "unknown specific product xyz 777", {})
    assert timeout_fallback.decision in {"safe_timeout_fallback", "unavailable", "matched"}, timeout_fallback.reply
    assert "اكتب اسم المنتج" in timeout_fallback.reply or "غير موجود" in timeout_fallback.reply or "السعر" in timeout_fallback.reply

    app_source = Path("app.py").read_text(encoding="utf-8")
    assert "SHUTDOWN_BACKGROUND_TIMEOUT" in app_source and "wait_for(asyncio.gather" in app_source, "shutdown must be bounded"
    assert "warmup_matcher_indexes_background" in app_source and "asyncio.create_task" in app_source, "warmup must be background task"

    after = database.count_products()
    assert after == before, f"products changed during tests: before={before}, after={after}"
    print("ACCEPTANCE_TESTS_FINAL_V22_2_STABILITY_SPEED_OK")
    print(f"DB_PROTECTION_OK | products_count={after}")


if __name__ == "__main__":
    main()
