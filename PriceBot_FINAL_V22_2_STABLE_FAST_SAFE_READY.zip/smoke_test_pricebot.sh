#!/usr/bin/env bash
set -Eeuo pipefail
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
cd "$(dirname "$0")"

python -m compileall -q .
PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_2_stability_speed.py

if [[ -f pricebot.db ]]; then
  BEFORE=$(python - <<'PY'
import database
print(database.count_products())
PY
)
  PRICEBOT_MIN_PRODUCTS_GUARD=0 timeout 60s python tools/rebuild_search_index.py >/tmp/pricebot_search_index_smoke.log || cat /tmp/pricebot_search_index_smoke.log
  PRICEBOT_MIN_PRODUCTS_GUARD=0 timeout 60s python tools/rebuild_product_nav_index.py >/tmp/pricebot_nav_index_smoke.log || cat /tmp/pricebot_nav_index_smoke.log
  AFTER=$(python - <<'PY'
import database
print(database.count_products())
PY
)
  if [[ "$BEFORE" != "$AFTER" ]]; then
    echo "DB_PROTECTION_FAILED | before=$BEFORE | after=$AFTER" >&2
    exit 1
  fi
  echo "DB_PROTECTION_OK | products_count=$AFTER"
else
  echo "INFO: pricebot.db not found in current directory; skipped live index smoke."
fi

if curl -fsS "http://127.0.0.1:${PRICEBOT_PORT}/health" >/tmp/pricebot_health_smoke.log 2>/dev/null; then
  cat /tmp/pricebot_health_smoke.log
  echo
else
  echo "INFO: local service not running on 127.0.0.1:${PRICEBOT_PORT}; code-level smoke passed."
fi

python tools/diagnose_pricebot.py || true

echo "PRICEBOT_V22_2_SMOKE_TEST_OK"
