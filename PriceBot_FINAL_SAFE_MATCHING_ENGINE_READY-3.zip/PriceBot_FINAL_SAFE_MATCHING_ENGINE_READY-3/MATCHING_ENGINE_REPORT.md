# PriceBot Safe Matching Engine Report

## Goal
This version replaces unsafe token scoring behavior with a conservative Product Identity Matching Engine. The bot must not show a price unless a product identity is confirmed from catalog fields.

## Matching decisions
Only these decisions are returned by the matching layer:

- `EXACT_MATCH`
- `ASK_CLARIFICATION`
- `NOT_AVAILABLE`
- `COSMETIC_ALTERNATIVES`
- `LOW_CONFIDENCE`
- `IMAGE_UNCLEAR`

`PRODUCT_LIST` is not used as a random fallback. Lists are shown only as clarification choices or safe cosmetic alternatives.

## Product identity fields
The engine checks:

- brand
- product_family / normalized_name / name
- active_ingredient
- category
- form
- strength
- size
- pack
- barcode
- aliases
- ocr_keywords

A shared generic word such as `syrup`, `cream`, `capsules`, `vitamin`, or `female` is never enough to return a product.

## Query Slot Extraction
`query_slots.py` extracts:

- brand
- product_family
- category
- form
- cosmetic_type
- strength
- size
- pack
- barcode
- strong identity tokens

Arabic and English form synonyms are supported, including:

- شراب / syr / syrup → syrup
- حبوب / أقراص / tab → tablet
- كبسول / cap → capsule
- تحاميل / supp → suppository
- حقن / inj → injection
- غسول / wash → cleanser
- لوشن → lotion
- سيروم → serum

## Guards

### Brand / Family Guard
If the user mentions a clear brand and product family, but that product is not present in the catalog, the engine returns `NOT_AVAILABLE`.

Example: `Rilastil xerolact PB متوفر` returns `NOT_AVAILABLE` and does not list other Rilastil items.

### Cosmetic Type Guard
If the user asks for a cleanser, the engine never returns lotion, moisturizer, cream, or serum as the exact product. Safe alternatives are limited to the same cosmetic type.

### Cross-category Guard
Generic form words do not move matching across categories. Example: `Amoclan syrup` cannot return a supplement syrup.

### Medicine Variant Resolver
Medicines with multiple forms/strengths/prices return `ASK_CLARIFICATION` until the identity is safe.

### Duplicate Price Safety
Duplicate product identities with different prices return `ASK_CLARIFICATION` and are listed in `DUPLICATE_PRODUCTS_REPORT.xlsx`. The engine does not choose the first price.

## Vision
Vision output is matched through slots, not raw OCR text.

The system builds a compact identity query from:

- brand
- product_name
- strength
- size
- pack

Generic text such as `vitamin`, `capsules`, `female`, `supports`, `tube`, `health`, `skin`, `cream`, and `gel` is ignored unless accompanied by a real product identity.

Examples now passing:

- `Pro-D3 50,000 IU vitamin k2 15 capsules` → `EXACT_MATCH` Pro-D3
- `Pro Bio Pro-D3 50,000 IU Vitamin K2` → `EXACT_MATCH` Pro-D3
- `Ovanice Female Fertility 90 capsules 850mg` → `EXACT_MATCH` Ovanice
- `cream tube 50ml` → `LOW_CONFIDENCE`

## Dynamic synonyms
Synonyms are loaded from:

- `data/dynamic_synonyms.json`
- optional SQLite table `dynamic_synonyms`

The cache can be invalidated later without changing code.

## Performance
The product identity catalog is preloaded in memory on startup. Warm text searches are designed to avoid full DB scans and normally finish below 300ms on the 5791-product catalog.

## Logging
Matching logs include:

- decision
- matched_stage
- query_slots
- matched_fields
- rejected_candidates
- reject_reasons
- duplicate_conflict
- latency_ms

Secrets and tokens are not logged.


## Runtime safety additions

- `clean_install_pricebot.sh` builds the new SQLite database in an external `/tmp` file first. It runs import and verify on that temporary database, then copies it to `/opt/pricebot_clean/pricebot.db` only after verification succeeds. This avoids leaving a half-built production DB in the clean install directory.
- `start_pricebot.sh` runs Uvicorn with `$APP_DIR/venv/bin/python -m uvicorn app:app`, avoiding PATH/script resolution issues.
- Per-user async locks are implemented in `app.py`; messages from the same WhatsApp phone are processed sequentially even when multiple workers are running. Stale locks are cleaned by TTL.
- `/health` is now a lightweight liveness endpoint only. Heavy DB checks are exposed separately at `/health/deep`.

## READY-2 deploy fixes

- `start_pricebot.sh` uses `exec "$APP_DIR/venv/bin/python" -m uvicorn app:app --host "$HOST" --port "$PORT"`.
- `clean_install_pricebot.sh` builds the DB in an external temporary path, verifies it, then copies it to `/opt/pricebot_clean/pricebot.db`.
- `/health` is lightweight and does not call `integrity_check`; `/deep-health` and `/health/deep` run deep diagnostics.
- Per-user async locks are implemented in `app.py` to serialize messages per phone number.

## READY-3 Vision matching fixes

This release fixes the practical image-matching failures seen with Pro-D3 and Dexeryl. Vision results are now scoped by extracted product identity before any ranking is allowed. When a clear brand/product identity exists, candidates must contain that same identity; broad catalog words such as `supplement`, `vitamin`, `capsules`, `cream`, `tube`, `health`, and `supports` cannot widen the list.

Validated cases:

- `Pro-D3 50,000 IU Vitamin K2 15 capsules` returns `EXACT_MATCH` for Pro-D3 50,000 IU, or Pro-D3-only clarification if duplicate Pro-D3 rows exist. It cannot show Pro Biovit, probiotics, protein products, D Cypro Vita, or Proviron.
- `DEXERYL crème cream 250g tube glycerol vaseline paraffin` returns `EXACT_MATCH` for DEXERYL CREAM, or Dexeryl-only clarification if duplicate Dexeryl rows exist. It cannot return `NOT_AVAILABLE` while listing DEXERYL CREAM as an alternative.
- `cream tube 250g` without brand/product returns `LOW_CONFIDENCE`; it cannot show a random cream.

The change is limited to Vision/image matching and the NOT_AVAILABLE/alternatives recovery path. UI flow and deployment behavior are unchanged from READY-2.
