"""Query slot extraction for PriceBot Product Identity Matching.

The extractor is intentionally conservative. It extracts product identity slots
that can be verified against the catalog; it does not invent medical usage or
substitution information.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set

from dynamic_synonyms import apply_synonyms, token_synonym
from normalizer import clean_query, normalize_text, tokens

FORM_ALIASES = {
    "syrup": {"syrup", "syr", "شراب"},
    "suspension": {"suspension", "susp", "معلق"},
    "tablet": {"tablet", "tab", "tabs", "tablets", "اقراص", "حبوب"},
    "capsule": {"capsule", "cap", "caps", "capsules", "كبسول", "كبسولات"},
    "suppository": {"suppository", "supp", "suppos", "تحاميل"},
    "injection": {"injection", "inj", "حقن", "حقنه"},
    "drops": {"drops", "drop", "قطره", "قطرة"},
    "cream": {"cream", "كريم"},
    "ointment": {"ointment", "oint", "مرهم"},
    "gel": {"gel", "جل"},
    "spray": {"spray", "بخاخ"},
    "solution": {"solution", "sol"},
    "sachet": {"sachet", "sachets"},
    "cleanser": {"cleanser", "wash", "غسول"},
    "lotion": {"lotion", "لوشن"},
    "serum": {"serum", "سيروم"},
    "moisturizer": {"moisturizer", "moisturizing", "moisturiser", "مرطب"},
    "sunscreen": {"sunscreen", "spf", "sunblock", "واقي", "واقي شمس"},
    "shampoo": {"shampoo", "شامبو"},
    "conditioner": {"conditioner", "بلسم"},
    "oil": {"oil", "زيت"},
    "mask": {"mask", "ماسك"},
    "toner": {"toner"},
}

FORM_CANONICAL: Dict[str, str] = {}
for canon, aliases in FORM_ALIASES.items():
    FORM_CANONICAL[normalize_text(canon)] = canon
    for a in aliases:
        FORM_CANONICAL[normalize_text(a)] = canon

COSMETIC_TYPES = {"cleanser", "cream", "ointment", "gel", "lotion", "serum", "moisturizer", "sunscreen", "shampoo", "conditioner", "spray", "oil", "mask", "toner"}
MEDICINE_FORMS = {"tablet", "capsule", "syrup", "suspension", "drops", "cream", "ointment", "gel", "injection", "suppository", "spray", "solution", "sachet"}

GENERAL_WORDS = {
    "vitamin", "vitamins", "supplement", "supplements", "capsule", "capsules", "tablet", "tablets", "female", "male", "health", "supports", "support",
    "tube", "skin", "face", "body", "new", "original", "plus", "advanced", "daily", "care", "formula", "for", "with", "and",
    "k2", "glycerol", "vaseline", "paraffin",
    "كريم", "جل", "حبوب", "فيتامين", "كبسولات", "شراب", "بشره", "وجه", "صحه", "لل", "مع",
}
UNIT_WORDS = {"mg", "mcg", "g", "kg", "ml", "l", "iu", "i", "u", "unit", "units", "مجم", "مل"}

ARABIC_FORM_WORDS = {normalize_text(a) for aliases in FORM_ALIASES.values() for a in aliases if re.search(r"[\u0600-\u06FF]", a)}

STRENGTH_RE = re.compile(r"\b\d+(?:[\.,/]\d+)?\s*(?:mg|mcg|g|iu|units?|مجم|ملجم)\b|\b\d+\s*/\s*\d+\s*(?:mg|mcg|g|iu)?\b", re.I)
SIZE_RE = re.compile(r"\b\d+(?:[\.,]\d+)?\s*(?:ml|l|g|kg)\b", re.I)
PACK_RE = re.compile(r"\b\d+\s*(?:tab|tabs|tablet|tablets|cap|caps|capsule|capsules|sachet|sachets|strip|strips)\b", re.I)
BARCODE_RE = re.compile(r"\b\d{8,14}\b")


def _extract_regex(pattern: re.Pattern, text: str) -> List[str]:
    out: List[str] = []
    for m in pattern.finditer(str(text or "")):
        val = normalize_text(m.group(0))
        if val and val not in out:
            out.append(val)
    return out


def canonical_form(text: object) -> str:
    n = apply_synonyms(text)
    if not n:
        return ""
    # Check phrase aliases first, then tokens.
    if n in FORM_CANONICAL:
        return FORM_CANONICAL[n]
    for t in n.split():
        if t in FORM_CANONICAL:
            return FORM_CANONICAL[t]
    for alias, canon in FORM_CANONICAL.items():
        if alias and alias in n:
            return canon
    return ""


def compatible_form(requested: str, product_form: str, product_text: str = "") -> bool:
    req = canonical_form(requested) or normalize_text(requested)
    pf = canonical_form(product_form) or normalize_text(product_form)
    if not req:
        return True
    if req == pf:
        return True
    # Syrup/suspension are often interchangeable in pharmacy price lists.
    if req in {"syrup", "suspension"} and pf in {"syrup", "suspension"}:
        return True
    # face_cleanser / body_cleanser variants in old catalogs.
    if req == "cleanser" and "cleanser" in pf:
        return True
    # If the form column is missing but the product name has a clear form token,
    # accept only that clear token.
    if not pf and product_text:
        return compatible_form(req, canonical_form(product_text), "")
    return False


def extract_strengths(text: object) -> List[str]:
    n = normalize_text(text)
    vals = _extract_regex(STRENGTH_RE, n)
    # Special normalized D3 form: 50000 iu may be split by prior normalization.
    if "50000 iu" in n and "50000 iu" not in vals:
        vals.append("50000 iu")
    return vals


def extract_sizes(text: object) -> List[str]:
    vals = _extract_regex(SIZE_RE, normalize_text(text))
    # Do not duplicate mg/iu strengths as size.
    return [v for v in vals if not any(u in v for u in ["mg", "iu", "mcg"])]


def extract_packs(text: object) -> List[str]:
    return _extract_regex(PACK_RE, normalize_text(text))


def normalize_measure(value: object) -> str:
    return apply_synonyms(value).replace(" ", "")


def measure_matches(requested: str, product_value: str) -> bool:
    if not requested:
        return True
    if not product_value:
        return False
    return normalize_measure(requested) == normalize_measure(product_value) or normalize_measure(requested) in normalize_measure(product_value) or normalize_measure(product_value) in normalize_measure(requested)


@dataclass
class QuerySlots:
    raw: str = ""
    clean: str = ""
    normalized: str = ""
    compact: str = ""
    tokens: List[str] = field(default_factory=list)
    strong_tokens: List[str] = field(default_factory=list)
    form: str = ""
    cosmetic_type: str = ""
    category: str = ""
    strength: str = ""
    strengths: List[str] = field(default_factory=list)
    size: str = ""
    sizes: List[str] = field(default_factory=list)
    pack: str = ""
    packs: List[str] = field(default_factory=list)
    barcode: str = ""
    brand: str = ""
    product_family: str = ""
    use_case: str = ""
    skin_type: str = ""
    source: str = "text"

    @property
    def has_specific_identity(self) -> bool:
        return bool(self.brand and (self.product_family or len(self.strong_tokens) >= 2))

    @property
    def has_type_only(self) -> bool:
        return bool(self.form and len(self.strong_tokens) == 0)


def extract_query_slots(text: object, source: str = "text", catalog_brands: Optional[Iterable[str]] = None) -> QuerySlots:
    raw = str(text or "").strip()
    cleaned = clean_query(raw)
    normalized = apply_synonyms(cleaned)
    compact = normalized.replace(" ", "")
    toks = [token_synonym(t) for t in tokens(normalized)]
    form = canonical_form(normalized)
    cosmetic_type = form if form in COSMETIC_TYPES else ""
    category = "cosmetic" if cosmetic_type in COSMETIC_TYPES else ""
    if form in {"tablet", "capsule", "syrup", "suspension", "drops", "injection", "suppository", "sachet", "solution"}:
        category = "medicine"
    strengths = extract_strengths(normalized)
    sizes = extract_sizes(normalized)
    packs = extract_packs(normalized)
    barcode_match = BARCODE_RE.search(normalized)
    barcode = barcode_match.group(0) if barcode_match else ""

    ignore = set(GENERAL_WORDS) | UNIT_WORDS | set(FORM_CANONICAL.keys())
    strong: List[str] = []
    for t in toks:
        if not t or t in ignore:
            continue
        if len(t) <= 2 and not t.isdigit():
            continue
        # Standalone numeric tokens are not identity unless part of strength/pack.
        if t.isdigit() and not any(t in normalize_measure(x) for x in strengths + sizes + packs):
            continue
        if t not in strong:
            strong.append(t)

    # Brand extraction using known catalog brands, then first strong token fallback.
    known_brands = sorted({normalize_text(b) for b in (catalog_brands or []) if normalize_text(b)}, key=len, reverse=True)
    brand = ""
    for b in known_brands:
        # Only accept catalog brand when it appears at the start of the query.
        # Matching any middle word as a brand causes mistakes such as
        # "Cerave Hydrating Cleanser" -> brand=hydrating.
        if b and (normalized == b or normalized.startswith(b + " ")):
            brand = b
            break
    if not brand and strong:
        brand = strong[0]

    family_tokens = [t for t in strong if t != brand]
    # Keep up to four identity tokens for family.  Do not include pure pack words.
    product_family = " ".join(family_tokens[:4])

    return QuerySlots(
        raw=raw,
        clean=cleaned,
        normalized=normalized,
        compact=compact,
        tokens=toks,
        strong_tokens=strong,
        form=form,
        cosmetic_type=cosmetic_type,
        category=category,
        strength=strengths[0] if strengths else "",
        strengths=strengths,
        size=sizes[0] if sizes else "",
        sizes=sizes,
        pack=packs[0] if packs else "",
        packs=packs,
        barcode=barcode,
        brand=brand,
        product_family=product_family,
        source=source,
    )


def build_vision_query(slots: Dict[str, object]) -> str:
    """Build a conservative matching query from Vision slots.

    We intentionally exclude marketing/general visible text.  Matching uses
    brand + product_name + strength + size/pack only.
    """
    parts: List[str] = []
    for key in ["brand", "product_name", "form", "product_type", "strength", "size", "pack"]:
        value = str(slots.get(key) or "").strip()
        if not value:
            continue
        nv = apply_synonyms(value)
        pieces = [t for t in nv.split() if t not in GENERAL_WORDS]
        if pieces:
            parts.append(" ".join(pieces))
    return apply_synonyms(" ".join(parts))
