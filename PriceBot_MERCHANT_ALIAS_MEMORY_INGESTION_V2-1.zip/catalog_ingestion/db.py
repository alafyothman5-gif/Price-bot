from __future__ import annotations

"""SQLite schema helpers for the safe Catalog Ingestion system."""

import json
from typing import Any, Iterable

import database


def _columns(conn, table: str) -> set[str]:
    try:
        return {str(r[1]) for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}
    except Exception:
        return set()


def _add_column(conn, table: str, column: str, ddl: str) -> None:
    if column not in _columns(conn, table):
        conn.execute(f'ALTER TABLE "{table}" ADD COLUMN {column} {ddl}')


def ensure_schema() -> None:
    """Create/upgrade ingestion tables only; never delete or truncate products."""
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")

        # Safe product metadata additions. Existing search/WhatsApp code can ignore them.
        if database.table_exists(conn, "products"):
            _add_column(conn, "products", "last_seen_at", "TEXT")
            _add_column(conn, "products", "normalized_name_catalog", "TEXT DEFAULT ''")

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS merchant_product_aliases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                raw_name TEXT NOT NULL,
                normalized_raw_name TEXT NOT NULL,
                product_id INTEGER NOT NULL,
                source TEXT DEFAULT 'manual',
                last_seen_at TEXT,
                last_seen_in_upload_id INTEGER,
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS ux_merchant_alias_active "
            "ON merchant_product_aliases(merchant_id, normalized_raw_name) WHERE is_active=1"
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_merchant_alias_product ON merchant_product_aliases(product_id, merchant_id)")

        # Product aliases table may already exist in old releases with different column names.
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS product_aliases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER,
                product_db_id INTEGER,
                alias TEXT DEFAULT '',
                alias_normalized TEXT,
                normalized_alias TEXT DEFAULT '',
                source TEXT DEFAULT 'manual',
                is_active INTEGER DEFAULT 1,
                approved INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        for col, ddl in {
            "product_id": "INTEGER",
            "product_db_id": "INTEGER",
            "alias": "TEXT DEFAULT ''",
            "alias_normalized": "TEXT",
            "normalized_alias": "TEXT DEFAULT ''",
            "source": "TEXT DEFAULT 'manual'",
            "is_active": "INTEGER DEFAULT 1",
            "approved": "INTEGER DEFAULT 1",
            "created_at": "TEXT",
            "updated_at": "TEXT",
        }.items():
            _add_column(conn, "product_aliases", col, ddl)
        conn.execute("UPDATE product_aliases SET product_id=COALESCE(product_id, product_db_id) WHERE product_id IS NULL AND product_db_id IS NOT NULL")
        conn.execute("UPDATE product_aliases SET product_db_id=COALESCE(product_db_id, product_id) WHERE product_db_id IS NULL AND product_id IS NOT NULL")
        conn.execute("UPDATE product_aliases SET alias_normalized=COALESCE(alias_normalized, normalized_alias) WHERE (alias_normalized IS NULL OR alias_normalized='') AND normalized_alias<>''")
        conn.execute("UPDATE product_aliases SET normalized_alias=COALESCE(normalized_alias, alias_normalized) WHERE (normalized_alias IS NULL OR normalized_alias='') AND alias_normalized<>''")
        try:
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_product_alias_active ON product_aliases(product_id, alias_normalized) WHERE is_active=1")
        except Exception:
            # Old deployments may already contain duplicate aliases. Keep ingestion
            # working; INSERT OR IGNORE still respects older unique constraints when present.
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_alias_active_nonunique ON product_aliases(product_id, alias_normalized, is_active)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_alias_exact ON product_aliases(alias_normalized, is_active)")

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS catalog_upload_jobs (
                id INTEGER PRIMARY KEY,
                merchant_id INTEGER NOT NULL,
                filename TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                status TEXT DEFAULT 'UPLOADED',
                rows_total INTEGER DEFAULT 0,
                safe_updates_count INTEGER DEFAULT 0,
                unchanged_count INTEGER DEFAULT 0,
                review_count INTEGER DEFAULT 0,
                new_count INTEGER DEFAULT 0,
                invalid_count INTEGER DEFAULT 0,
                duplicate_count INTEGER DEFAULT 0,
                report_json TEXT DEFAULT '{}',
                error_text TEXT DEFAULT '',
                backup_path TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                started_at TEXT,
                finished_at TEXT,
                approved_at TEXT,
                approved_by TEXT DEFAULT ''
            )
            """
        )
        for col, ddl in {
            "file_path": "TEXT DEFAULT ''",
            "rows_total": "INTEGER DEFAULT 0",
            "safe_updates_count": "INTEGER DEFAULT 0",
            "unchanged_count": "INTEGER DEFAULT 0",
            "review_count": "INTEGER DEFAULT 0",
            "new_count": "INTEGER DEFAULT 0",
            "invalid_count": "INTEGER DEFAULT 0",
            "duplicate_count": "INTEGER DEFAULT 0",
            "report_json": "TEXT DEFAULT '{}'",
            "error_text": "TEXT DEFAULT ''",
            "backup_path": "TEXT DEFAULT ''",
            "started_at": "TEXT",
            "finished_at": "TEXT",
            "approved_at": "TEXT",
            "approved_by": "TEXT DEFAULT ''",
        }.items():
            _add_column(conn, "catalog_upload_jobs", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_upload_jobs_status ON catalog_upload_jobs(status, created_at)")

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS catalog_staging_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER NOT NULL,
                merchant_id INTEGER NOT NULL,
                row_number INTEGER DEFAULT 0,
                raw_name TEXT DEFAULT '',
                normalized_name TEXT DEFAULT '',
                raw_price TEXT DEFAULT '',
                parsed_price TEXT DEFAULT '',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                old_price TEXT DEFAULT '',
                new_price TEXT DEFAULT '',
                is_safe_to_apply INTEGER DEFAULT 0,
                duplicate_winner_row INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        for col, ddl in {
            "parsed_price": "TEXT DEFAULT ''",
            "matched_product_id": "INTEGER",
            "reason": "TEXT DEFAULT ''",
            "old_price": "TEXT DEFAULT ''",
            "new_price": "TEXT DEFAULT ''",
            "is_safe_to_apply": "INTEGER DEFAULT 0",
            "duplicate_winner_row": "INTEGER",
        }.items():
            _add_column(conn, "catalog_staging_items", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_staging_job_decision ON catalog_staging_items(job_id, decision)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_staging_safe ON catalog_staging_items(job_id, is_safe_to_apply)")

        # Extend old review table without breaking old code.
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS catalog_review_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                job_id INTEGER,
                staging_item_id INTEGER,
                raw_name TEXT DEFAULT '',
                normalized_name TEXT DEFAULT '',
                price TEXT DEFAULT '',
                issue_type TEXT DEFAULT '',
                status TEXT DEFAULT 'PENDING',
                resolved_product_id INTEGER,
                reviewed_by TEXT DEFAULT '',
                reviewed_at TEXT,
                notes TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        for col, ddl in {
            "staging_item_id": "INTEGER",
            "raw_name": "TEXT DEFAULT ''",
            "normalized_name": "TEXT DEFAULT ''",
            "price": "TEXT DEFAULT ''",
            "issue_type": "TEXT DEFAULT ''",
            "status": "TEXT DEFAULT 'PENDING'",
            "resolved_product_id": "INTEGER",
            "reviewed_by": "TEXT DEFAULT ''",
            "reviewed_at": "TEXT",
            "notes": "TEXT DEFAULT ''",
            # compatibility with existing templates/routes
            "severity": "TEXT DEFAULT 'review'",
            "row_json": "TEXT DEFAULT '{}'",
            "duplicate_key": "TEXT DEFAULT ''",
            "price_old": "TEXT DEFAULT ''",
            "price_new": "TEXT DEFAULT ''",
            "matched_product_db_id": "INTEGER",
            "suggested_brand": "TEXT DEFAULT ''",
            "suggested_family": "TEXT DEFAULT ''",
            "suggested_category": "TEXT DEFAULT ''",
            "suggested_form": "TEXT DEFAULT ''",
            "suggested_strength": "TEXT DEFAULT ''",
            "suggested_size": "TEXT DEFAULT ''",
            "suggested_pack": "TEXT DEFAULT ''",
            "suggested_aliases": "TEXT DEFAULT ''",
            "review_notes": "TEXT DEFAULT ''",
            "reviewed_at": "TEXT",
        }.items():
            _add_column(conn, "catalog_review_items", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_review_pending_safe ON catalog_review_items(status, merchant_id, created_at)")

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS catalog_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER,
                product_id INTEGER,
                old_price TEXT DEFAULT '',
                new_price TEXT DEFAULT '',
                upload_job_id INTEGER,
                staging_item_id INTEGER,
                changed_by TEXT DEFAULT '',
                change_type TEXT DEFAULT '',
                details_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                -- compatibility columns used by older PriceBot code
                job_id INTEGER,
                event TEXT DEFAULT '',
                actor TEXT DEFAULT ''
            )
            """
        )
        for col, ddl in {
            "merchant_id": "INTEGER",
            "product_id": "INTEGER",
            "old_price": "TEXT DEFAULT ''",
            "new_price": "TEXT DEFAULT ''",
            "upload_job_id": "INTEGER",
            "staging_item_id": "INTEGER",
            "changed_by": "TEXT DEFAULT ''",
            "change_type": "TEXT DEFAULT ''",
            "details_json": "TEXT DEFAULT '{}'",
            "job_id": "INTEGER",
            "event": "TEXT DEFAULT ''",
            "actor": "TEXT DEFAULT ''",
        }.items():
            _add_column(conn, "catalog_audit_log", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_audit_upload ON catalog_audit_log(upload_job_id, product_id)")


def audit_conn(conn: Any, *, merchant_id: int, product_id: int | None, old_price: str, new_price: str,
               upload_job_id: int, staging_item_id: int | None, changed_by: str, change_type: str,
               details: Any = None) -> None:
    payload = json.dumps(details or {}, ensure_ascii=False, default=str)
    conn.execute(
        """
        INSERT INTO catalog_audit_log(
            merchant_id, product_id, old_price, new_price, upload_job_id, staging_item_id,
            changed_by, change_type, details_json, job_id, event, actor
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (merchant_id, product_id, old_price, new_price, upload_job_id, staging_item_id,
         changed_by, change_type, payload, upload_job_id, change_type, changed_by),
    )
