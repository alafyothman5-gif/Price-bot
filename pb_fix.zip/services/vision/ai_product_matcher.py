"""AI-only image product matcher for PriceBot.

This module matches text extracted from a product image against the current
`products` table by asking the configured OpenRouter/Gemini text model to return
strict JSON. It is intentionally independent from product_aliases and legacy
image guards. The caller still must require user confirmation before showing
price/availability.
"""
from __future__ import annotations

import json
import os
import re
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Tuple

import httpx

import config_env
import database
from normalizer import normalize_text

MATCH_PROMPT = (
    "You are the PRIMARY product matching engine for a pharmacy catalog. "
    "Given a customer/product text and a list of available catalog candidates, decide whether the text clearly and uniquely identifies exactly one sellable product. "
    "Return ONLY strict JSON. If confident, return {\"matched\": true, \"product_id\": <id>, \"name\": \"<name>\", \"reason\": \"short reason\"}. "
    "If the input is generic, ambiguous, or absent from the candidate list, return {\"matched\": false, \"reason\": \"ambiguous|not_found|generic|insufficient_evidence\"}. "
    "Use only product_id values from the provided candidates. Do not invent products. Do not guess between variants, strengths, sizes, packs, or forms."
)

GENERIC_OFFLINE_WORDS = {
    "cream", "gel", "lotion", "cleanser", "wash", "face", "facial", "serum", "toner",
    "sunscreen", "spf", "moisturizer", "shampoo", "conditioner", "soap", "mask", "balm",
    "tablet", "tablets", "capsule", "capsules", "syrup", "solution", "suspension", "oral",
    "mg", "ml", "g", "gm", "pack", "box", "bottle", "low", "ph",
}

EVIDENCE_VALIDATOR_STOPWORDS = GENERIC_OFFLINE_WORDS | {
    "the", "and", "or", "for", "with", "without", "plus", "extra", "new", "original",
    "creme", "ointment", "spray", "drop", "drops", "injection", "injectable", "ampoule",
    "كريم", "جل", "غسول", "شراب", "حبوب", "اقراص", "كبسولات", "قطرة", "بخاخ",
}


def _log(event: str, **kw: Any) -> None:
    safe: List[str] = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": config_env.openrouter_gemini_model([
            "OPENROUTER_IMAGE_MATCH_MODEL",
            "OPENROUTER_TEXT_MODEL",
            "OPENROUTER_MODEL",
        ]),
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def _extract_json_object(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {"matched": False}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {"matched": False}
    except Exception:
        pass
    match = re.search(r"\{.*\}", raw, flags=re.DOTALL)
    if not match:
        return {"matched": False}
    try:
        data = json.loads(match.group(0))
        return data if isinstance(data, dict) else {"matched": False}
    except Exception:
        return {"matched": False}


def _safe_product_payload(products: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    seen = set()
    for p in products:
        try:
            pid = int(p.get("id") or 0)
        except Exception:
            pid = 0
        name = str(p.get("canonical_display_name") or p.get("name") or "").strip()
        if not pid or not name or pid in seen:
            continue
        seen.add(pid)
        item: Dict[str, Any] = {"id": pid, "name": name}
        for key in ["brand", "product_family", "form", "medicine_form", "product_type", "strength", "size", "pack", "barcode", "aliases", "ocr_keywords"]:
            value = str(p.get(key) or "").strip()
            if value:
                item[key] = value[:220]
        payload.append(item)
    return payload


def _payload_identity_text(p: Dict[str, Any]) -> str:
    return normalize_text(" ".join(str(p.get(k) or "") for k in [
        "name", "brand", "product_family", "form", "medicine_form", "product_type",
        "strength", "size", "pack", "barcode", "aliases", "ocr_keywords",
    ]))


def _token_score(query_token: str, product_text: str, product_tokens: List[str]) -> int:
    if not query_token:
        return 0
    if query_token in product_tokens:
        return 10
    compact = re.sub(r"\s+", "", product_text)
    if len(query_token) >= 4 and query_token in compact:
        return 8
    if len(query_token) >= 5 and any(SequenceMatcher(None, query_token, t).ratio() >= 0.82 for t in product_tokens):
        return 6
    return 0


def _shortlist_products_for_ai(text: str, products: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Build a broad catalog candidate list; Gemini still makes the match decision.

    Sending very large catalogs to the model is slow and can exceed context. This
    shortlist is retrieval-only, not a final match: it preserves broad lexical,
    barcode, alias, and typo-near candidates and lets Gemini choose or reject.
    """
    payload = _safe_product_payload(products)
    total = len(payload)
    try:
        max_candidates = int(os.getenv("PRICEBOT_AI_PRODUCT_CANDIDATE_LIMIT", "160") or 160)
    except Exception:
        max_candidates = 160
    max_candidates = max(20, min(max_candidates, 400))
    if total <= max_candidates:
        return payload, {"total_products": total, "sent_products": total, "shortlisted": False}

    query = normalize_text(text or "")
    query_compact = re.sub(r"\s+", "", query)
    query_tokens = [t for t in _tokens(query) if len(t) >= 2]
    query_strong = [t for t in query_tokens if t not in EVIDENCE_VALIDATOR_STOPWORDS and not re.fullmatch(r"\d+", t)]
    query_numbers = set(re.findall(r"\d+(?:\.\d+)?", query))

    scored: List[Tuple[int, int, Dict[str, Any]]] = []
    for idx, p in enumerate(payload):
        identity = _payload_identity_text(p)
        if not identity:
            continue
        identity_compact = re.sub(r"\s+", "", identity)
        product_tokens = _tokens(identity)
        score = 0
        name_norm = normalize_text(p.get("name") or "")
        if query and query == name_norm:
            score += 1000
        if query and (query in identity or query_compact and query_compact in identity_compact):
            score += 260
        if query and name_norm and len(query) >= 4:
            ratio = SequenceMatcher(None, query, name_norm).ratio()
            if ratio >= 0.34:
                score += int(90 * ratio)
        if query_numbers:
            product_numbers = set(re.findall(r"\d+(?:\.\d+)?", identity))
            score += 18 * len(query_numbers & product_numbers)
        for token in query_strong:
            score += _token_score(token, identity, product_tokens)
        # Keep plausible one-token brand/family candidates, but Gemini must
        # still reject ambiguity if many variants remain.
        if len(query_strong) == 1 and query_strong[0] in product_tokens:
            score += 12
        if score > 0:
            scored.append((score, idx, p))

    scored.sort(key=lambda x: (-x[0], x[1]))
    selected = [p for _score, _idx, p in scored[:max_candidates]]
    return selected, {
        "total_products": total,
        "sent_products": len(selected),
        "shortlisted": True,
        "query_tokens": query_tokens[:12],
        "candidate_limit": max_candidates,
    }


def _tokens(text: str) -> List[str]:
    norm = normalize_text(text or "")
    return re.findall(r"[a-zA-Z0-9%/+-]+|[\u0600-\u06FF]+", norm)


def _looks_generic_name(name: str) -> bool:
    toks = [t for t in _tokens(name) if t not in {"the", "a", "an", "and", "or", "for"}]
    if not toks:
        return True
    strong = [t for t in toks if t not in GENERIC_OFFLINE_WORDS and not re.fullmatch(r"\d+", t)]
    return len(strong) == 0


def _offline_safe_exact_match(extracted_text: str, products: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Safe deterministic fallback for tests/offline mode only.

    It is intentionally conservative and only accepts clear product-name evidence;
    generic product names/descriptors are rejected. Production matching uses the
    OpenRouter/Gemini call when an API key is configured.
    """
    text_norm = normalize_text(extracted_text or "")
    text_compact = re.sub(r"\s+", "", text_norm)
    if not text_norm:
        return {"matched": False, "reason": "no_text"}

    candidates: List[Dict[str, Any]] = []
    for p in products:
        name = str(p.get("name") or "")
        if _looks_generic_name(name):
            continue
        name_norm = normalize_text(name)
        if not name_norm:
            continue
        name_compact = re.sub(r"\s+", "", name_norm)
        name_tokens = [t for t in _tokens(name) if t not in GENERIC_OFFLINE_WORDS]
        # Exact/contained full-name evidence.
        if name_norm == text_norm or (len(name_norm) >= 5 and name_norm in text_norm) or (len(name_compact) >= 5 and name_compact in text_compact):
            candidates.append(p)
            continue
        # Conservative token evidence: all strong product-name tokens appear in the OCR text.
        if name_tokens and len(name_tokens) >= 2 and all(t in text_norm.split() or t in text_compact for t in name_tokens):
            candidates.append(p)

    unique: Dict[int, Dict[str, Any]] = {}
    for p in candidates:
        try:
            unique[int(p.get("id") or 0)] = p
        except Exception:
            pass
    if len(unique) == 1:
        p = next(iter(unique.values()))
        return {"matched": True, "product_id": int(p["id"]), "name": p.get("name"), "source": "offline_safe_exact"}
    if len(unique) > 1:
        return {"matched": False, "reason": "ambiguous_offline", "candidate_ids": list(unique.keys())[:10]}
    return {"matched": False, "reason": "no_offline_match"}



def evidence_tokens_for_product_name(name: str) -> List[str]:
    """Important non-generic tokens that must be evidenced in image text.

    Used as a guard above Gemini so semantic similarity cannot match a product
    whose name has no textual overlap with the photographed label.
    """
    out: List[str] = []
    seen = set()
    for token in _tokens(name or ""):
        t = token.strip().lower()
        if len(t) < 3:
            continue
        if t in EVIDENCE_VALIDATOR_STOPWORDS:
            continue
        if re.fullmatch(r"\d+", t):
            continue
        if t not in seen:
            out.append(t)
            seen.add(t)
    return out


def _token_close(a: str, b: str) -> bool:
    a = normalize_text(a or "")
    b = normalize_text(b or "")
    if not a or not b:
        return False
    if a == b or a in b or b in a:
        return True
    if len(a) < 5 or len(b) < 5:
        return False
    return SequenceMatcher(None, a, b).ratio() >= 0.84


def _token_supported(token: str, evidence_tokens: List[str], evidence_compact: str) -> bool:
    token = normalize_text(token or "")
    if not token:
        return False
    if token in evidence_tokens or token in evidence_compact:
        return True
    return any(_token_close(token, e) for e in evidence_tokens)


def validate_text_evidence_for_match(image_text: str, product_name: str) -> Dict[str, Any]:
    """Return pass/fail for whether text evidence supports the selected product.

    Gemini may understand spelling mistakes, but it must not select a different
    variant from the same brand based only on one shared brand token.  Therefore
    the guard uses reciprocal approximate token coverage: product tokens must be
    evidenced in the user/OCR text, and multi-token user text must also be
    represented in the selected product name.
    """
    product_tokens = evidence_tokens_for_product_name(product_name or "")
    if not product_tokens:
        return {"passed": False, "missing_tokens": [], "matched_tokens": [], "reason": "no_product_evidence_tokens"}
    image_norm = normalize_text(image_text or "")
    image_tokens = [t for t in _tokens(image_norm) if len(t) >= 3 and t not in EVIDENCE_VALIDATOR_STOPWORDS and not re.fullmatch(r"\d+", t)]
    image_compact = re.sub(r"\s+", "", image_norm)

    matched: List[str] = []
    for token in product_tokens:
        if _token_supported(token, image_tokens, image_compact):
            matched.append(token)
    missing = [t for t in product_tokens if t not in matched]

    # Require more than a brand-only overlap when both sides contain variants.
    required_product_hits = 1 if len(product_tokens) == 1 else min(2, len(product_tokens))
    product_ok = len(matched) >= required_product_hits

    query_matched = [t for t in image_tokens if any(_token_close(t, pt) for pt in product_tokens)]
    required_query_hits = 1 if len(image_tokens) <= 1 else min(2, len(image_tokens))
    query_ok = len(query_matched) >= required_query_hits

    passed = bool(product_ok and query_ok)
    reason = "ok" if passed else "insufficient_variant_evidence"
    return {
        "passed": passed,
        "missing_tokens": missing,
        "matched_tokens": matched,
        "product_tokens": product_tokens,
        "query_tokens": image_tokens,
        "query_matched_tokens": query_matched,
        "reason": reason,
    }


async def match_extracted_text_to_product(extracted_text: str, products: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Return {matched: bool, product_id?, name?} for image text.

    This function does not authorize price display; app.py must still ask the
    user for confirmation and store pending_product_id.
    """
    text = str(extracted_text or "").strip()
    if not text:
        return {"matched": False, "reason": "empty_text"}

    product_rows = products if products is not None else database.load_product_rows(visible_only=True)
    product_payload, shortlist_meta = _shortlist_products_for_ai(text, product_rows)
    if not product_payload:
        return {"matched": False, "reason": "no_candidate_products", "shortlist": shortlist_meta}

    cfg = _openrouter_config()
    if not cfg.get("api_key"):
        _log("AI_PRODUCT_MATCH_OFFLINE_FALLBACK", products=len(product_payload))
        return _offline_safe_exact_match(text, product_payload)

    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": MATCH_PROMPT},
            {"role": "user", "content": json.dumps({"input_text": text, "candidate_products": product_payload, "candidate_meta": shortlist_meta}, ensure_ascii=False)},
        ],
        "temperature": 0,
        "max_tokens": 180,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    timeout = float(os.getenv("PRICEBOT_AI_IMAGE_MATCH_TIMEOUT_SECONDS", "12") or 12)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                _log("AI_PRODUCT_MATCH_ERROR", status=resp.status_code)
                return {"matched": False, "reason": "ai_http_error", "shortlist": shortlist_meta}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as exc:
        _log("AI_PRODUCT_MATCH_ERROR", status=type(exc).__name__)
        return {"matched": False, "reason": "ai_exception", "shortlist": shortlist_meta}

    data = _extract_json_object(content)
    if not bool(data.get("matched")):
        return {"matched": False, "reason": str(data.get("reason") or "ai_not_matched"), "raw": data, "shortlist": shortlist_meta}
    try:
        pid = int(data.get("product_id") or 0)
    except Exception:
        pid = 0
    if not pid:
        return {"matched": False, "reason": "ai_missing_product_id", "raw": data, "shortlist": shortlist_meta}
    by_id = {int(p["id"]): p for p in product_payload}
    product = by_id.get(pid)
    if not product:
        _log("AI_IMAGE_MATCH_REJECTED_UNKNOWN_PRODUCT", product_id=pid)
        return {"matched": False, "reason": "ai_unknown_product_id", "raw": data, "shortlist": shortlist_meta}
    return {"matched": True, "product_id": pid, "name": product["name"], "source": "openrouter_gemini", "raw": data, "shortlist": shortlist_meta}


# === PRICEBOT_GEMINI_ONLY_MATCHER_PATCH_START ===

MATCH_PROMPT = (
    "You are the ONLY product matching engine for a pharmacy catalog. "
    "The application will not perform local product matching, fuzzy matching, "
    "local evidence validation, or product selection after your answer. "
    "You must choose the best matching sellable product from candidate_products using the image/OCR text. "
    "Use brand, visible label words, product name, strength, concentration, size, pack, form, barcode, and aliases when available. "
    "Return ONLY strict JSON. "
    "If one catalog product is the best match, return "
    "{\"matched\": true, \"product_id\": <id>, \"name\": \"<name>\", \"confidence\": <0-1>, \"reason\": \"short reason\"}. "
    "If the image/OCR text is unclear, ambiguous, or no reasonable product exists in the catalog, return "
    "{\"matched\": false, \"reason\": \"not_found|unclear|ambiguous\"}. "
    "Use only product_id values from candidate_products. Do not invent products. Do not invent prices."
)


def _pricebot_gemini_only_candidate_payload(products):
    payload = _safe_product_payload(products)

    try:
        limit = int(os.getenv("PRICEBOT_AI_FULL_CATALOG_LIMIT", "5000") or 5000)
    except Exception:
        limit = 5000

    limit = max(50, min(limit, 10000))
    sent = payload[:limit]

    meta = {
        "total_products": len(payload),
        "sent_products": len(sent),
        "matching_owner": "gemini_only",
        "local_matching": False,
        "local_validation": False,
        "truncated": len(payload) > len(sent),
    }

    return sent, meta


async def match_extracted_text_to_product(extracted_text, products=None):
    """
    Gemini-only product matcher.

    This override disables local/offline/fuzzy product matching.
    It sends the visible catalog payload to Gemini and accepts only Gemini's product_id.
    """
    text = str(extracted_text or "").strip()
    if not text:
        return {"matched": False, "reason": "empty_text"}

    product_rows = products if products is not None else database.load_product_rows(visible_only=True)
    product_payload, shortlist_meta = _pricebot_gemini_only_candidate_payload(product_rows)

    if not product_payload:
        return {"matched": False, "reason": "no_candidate_products", "shortlist": shortlist_meta}

    cfg = _openrouter_config()

    if not cfg.get("api_key"):
        _log("AI_PRODUCT_MATCH_NO_API_KEY", products=len(product_payload))
        return {"matched": False, "reason": "missing_openrouter_api_key", "shortlist": shortlist_meta}

    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": MATCH_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "input_text": text,
                        "candidate_products": product_payload,
                        "candidate_meta": shortlist_meta,
                    },
                    ensure_ascii=False,
                ),
            },
        ],
        "temperature": 0,
        "max_tokens": 260,
    }

    headers = {
        "Authorization": f"Bearer {cfg['api_key']}",
        "Content-Type": "application/json",
    }

    timeout = float(os.getenv("PRICEBOT_AI_IMAGE_MATCH_TIMEOUT_SECONDS", "25") or 25)

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                f"{cfg['base_url']}/chat/completions",
                headers=headers,
                json=payload,
            )

        if resp.status_code >= 400:
            _log("AI_PRODUCT_MATCH_ERROR", status=resp.status_code)
            return {"matched": False, "reason": "ai_http_error", "shortlist": shortlist_meta}

        content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")

    except Exception as exc:
        _log("AI_PRODUCT_MATCH_ERROR", status=type(exc).__name__)
        return {"matched": False, "reason": "ai_exception", "shortlist": shortlist_meta}

    data = _extract_json_object(content)

    if not bool(data.get("matched")):
        return {
            "matched": False,
            "reason": str(data.get("reason") or "ai_not_matched"),
            "raw": data,
            "shortlist": shortlist_meta,
        }

    try:
        pid = int(data.get("product_id") or 0)
    except Exception:
        pid = 0

    if not pid:
        return {
            "matched": False,
            "reason": "ai_missing_product_id",
            "raw": data,
            "shortlist": shortlist_meta,
        }

    by_id = {}
    for p in product_payload:
        try:
            by_id[int(p["id"])] = p
        except Exception:
            pass

    product = by_id.get(pid)

    if not product:
        _log("AI_IMAGE_MATCH_REJECTED_UNKNOWN_PRODUCT", product_id=pid)
        return {
            "matched": False,
            "reason": "ai_unknown_product_id",
            "raw": data,
            "shortlist": shortlist_meta,
        }

    _log(
        "AI_PRODUCT_MATCH_GEMINI_ONLY_SELECTED",
        product_id=pid,
        confidence=data.get("confidence"),
        sent_products=shortlist_meta.get("sent_products"),
    )

    return {
        "matched": True,
        "product_id": pid,
        "name": product["name"],
        "source": "openrouter_gemini_only",
        "raw": data,
        "shortlist": shortlist_meta,
    }

# === PRICEBOT_GEMINI_ONLY_MATCHER_PATCH_END ===

