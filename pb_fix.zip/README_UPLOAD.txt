PriceBot Gemini Image Confirmation Fix

Upload target paths if extracting manually:
- app.py -> repository root app.py
- services/vision/ai_product_matcher.py -> services/vision/ai_product_matcher.py

This ZIP contains only the two modified Python files. It does not contain .env, database files, venv, cache, uploads, or secrets.
