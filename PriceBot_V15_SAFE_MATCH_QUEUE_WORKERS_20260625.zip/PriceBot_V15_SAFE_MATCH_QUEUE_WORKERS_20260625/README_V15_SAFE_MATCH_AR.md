# PriceBot V15 Safe Match Queue Workers

هذه نسخة مبنية فوق V14 Infra، لكنها تضيف طبقة أمان للمطابقة بدون تغيير قاعدة البيانات أو embeddings.

## الهدف

- الحفاظ على بنية V14: Redis Queue + Workers + Uvicorn workers.
- حل مشاكل المطابقة التي ظهرت في V13/V14:
  - عدم اختيار منتج عشوائي عند الاسم العام.
  - فهم أفضل للكتابة العربية الصوتية مثل: `متوفر عندكم فيروكسيل` و `عندكم اموكلان`.
  - رفض صورة منتج إذا المنتج غير موجود بدل اقتراح منتج مشابه فقط.
  - عدم مطابقة منتج بتركيز مختلف، مثل `COVERAM 5mg/5mg` مع `COVERAM 5mg/10mg`.

## أهم التعديلات

1. رفع عتبات الثقة الافتراضية:
   - direct: 0.99
   - confirm: 0.85

2. إضافة فلتر V15 Textual Evidence:
   - لا يكفي التشابه semantic وحده.
   - لازم يوجد دليل نصي من الاسم/العلامة/القوة داخل المنتج المرشح.
   - يمنع اقتراح منتجات مثل `Allbrain syrup Omega-3` لصورة `Efamol Brain Formula Liquid` إذا `Efamol` غير موجودة في المنتج.

3. فلتر التركيز/الحجم:
   - إذا query فيها `5mg/5mg` لا يقبل منتج فيه `5mg/10mg`.

4. Arabic phonetic query variants:
   - يحول كلمات عربية صوتية إلى احتمالات لاتينية للبحث فقط.
   - مثال: `فيروكسيل` يولد احتمالات مثل `feroxyl`.
   - مثال: `اموكلان` يولد احتمالات مثل `amoclan`.

5. عند الشك:
   - بدل سؤال نعم/لا على منتج واحد، يعرض قائمة منتجات إذا يوجد أكثر من مرشح.

6. Gemini verification cache:
   - حفظ قرارات Gemini مؤقتًا في Redis لمدة 15 دقيقة لتقليل التكلفة والضغط.

## ما لم يتغير

- لم يتم تغيير PostgreSQL schema.
- لم يتم تغيير pgvector dimension.
- لم يتم تغيير embeddings الحالية.
- لم يتم تغيير Gemini/Vision provider.
- لم يتم حذف منتجات.

## متغيرات مهمة

يفضل ضبط هذه القيم في `.env`:

```env
PRICEBOT_GEMINI_DIRECT_CONFIDENCE=0.99
PRICEBOT_GEMINI_CONFIRM_CONFIDENCE=0.85
PRICEBOT_REQUIRE_TEXTUAL_EVIDENCE=1
PRICEBOT_QUERY_VARIANTS_MAX=24
PRICEBOT_GEMINI_VERIFY_CACHE_TTL_SECONDS=900
PRICEBOT_QUEUE_BACKEND=redis
```

## فحص بعد التشغيل

```bash
curl -sS http://127.0.0.1:8090/health | python3 -m json.tool | head -180
sudo -u postgres psql -d pricebot -Atc "SELECT COUNT(*), SUM(CASE WHEN LOWER(COALESCE(is_available::text,'')) IN ('1','true','yes','y','available','متوفر') THEN 1 ELSE 0 END), COUNT(embedding) FROM products;"
redis-cli ping
```

المتوقع:

```text
5163|5163|5163
PONG
```

## اختبارات مهمة

- `متوفر عندكم فيروكسيل`
- `عندكم amoclan`
- `متوفر عندكم اموكلان`
- صورة `COVERAM 5mg/5mg` إذا لا يوجد نفس التركيز يجب أن تكون غير متوفرة أو لا تعرض سعر مختلف.
- صورة `Efamol Brain Formula Liquid` إذا المنتج غير موجود يجب أن تكون غير متوفرة، لا تطابق Omega-3 مختلف.
