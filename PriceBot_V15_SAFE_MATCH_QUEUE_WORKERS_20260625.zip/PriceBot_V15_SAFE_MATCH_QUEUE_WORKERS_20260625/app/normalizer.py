import re
import unicodedata
from typing import Iterable, List

ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
ARABIC_MAP = {
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ة": "ه", "ى": "ي", "ؤ": "و", "ئ": "ي",
    "ی": "ي", "ک": "ك", "گ": "ك", "چ": "ج", "پ": "ب", "ڤ": "ف",
}
LATIN_VARIANTS = {
    "crème": "cream",
    "creme": "cream",
    "moisturising": "moisturizing",
    "moisturiser": "moisturizer",
    "moisturising": "moisturizing",
    "sunblock": "sunscreen",
    "sun block": "sunscreen",
    "facewash": "face wash",
    "cera ve": "cerave",
    "cera-ve": "cerave",
    "petroleeum": "petroleum",
    "petrolleum": "petroleum",
    "petrolium": "petroleum",
    "la roche posay": "la roche-posay",
    "la roche-posay": "la roche-posay",
    "la roche": "laroche",
}
STOPWORDS = {
    "متوفر", "موجود", "عندكم", "في", "فيه", "السعر", "سعر", "كم", "بكم", "نبي", "ابي", "اريد", "ممكن",
    "لو", "سمحت", "please", "price", "available", "do", "you", "have", "هل", "يوجد", "عليكم", "السلام", "مرحبا", "اهلا",
}
GENERIC_SEARCH_TERMS = {
    "غسول", "كريم", "دواء", "ادويه", "ادوية", "حديد", "فيتامين", "فيتامينات", "شامبو", "بلسم",
    "مرطب", "واقي", "واقي شمس", "سيروم", "مكمل", "مكملات", "سيرافي", "cerave",
    "lotion", "cream", "cleanser", "wash", "shampoo", "serum", "sunscreen", "vitamin", "iron", "medicine",
    "capsule", "capsules", "tablet", "tablets", "syrup", "drops", "female", "health", "supports", "tube",
    "white", "petroleum", "jelly",
}

def normalize_text(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = text.translate(ARABIC_DIGITS)
    for src, dst in ARABIC_MAP.items():
        text = text.replace(src, dst)
    text = text.lower()
    text = text.replace("+", " plus ")
    text = re.sub(r"\bpro\s*[- ]?\s*d\s*3\b", "prod3", text)
    text = re.sub(r"\b50\s*[,< ]\s*000\s*(iu|i u)?\b", "50000 iu", text)
    text = re.sub(r"\b50\s*000iu\b", "50000 iu", text)
    text = re.sub(r"(?<=\d)\s*mg\b", " mg", text)
    text = re.sub(r"(?<=\d)\s*ml\b", " ml", text)
    text = re.sub(r"(?<=\d)\s*iu\b", " iu", text)
    for src, dst in LATIN_VARIANTS.items():
        text = text.replace(src, dst)
    text = re.sub(r"[^0-9a-z\u0600-\u06FF]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def compact_normalize(value: object) -> str:
    return normalize_text(value).replace(" ", "")

def split_multi(value: object) -> List[str]:
    text = str(value or "").strip()
    if not text:
        return []
    parts = re.split(r"\s*\|\s*|\s*,\s*|\s*;\s*|\n+", text)
    out = []
    seen = set()
    for p in parts:
        p = p.strip()
        if p and p not in seen:
            out.append(p)
            seen.add(p)
    return out

def clean_query(value: object) -> str:
    n = normalize_text(value)
    if not n:
        return ""
    tokens = [t for t in n.split() if t not in STOPWORDS]
    return " ".join(tokens).strip()


def is_generic_query(value: object) -> bool:
    q = clean_query(value)
    if not q:
        return True
    if q in GENERIC_SEARCH_TERMS:
        return True
    parts = q.split()
    if len(parts) == 1 and (parts[0] in GENERIC_SEARCH_TERMS or len(parts[0]) <= 2 and not parts[0].isdigit()):
        return True
    return False


# V15: Arabic/English product-name query expansion.
# This is not a hardcoded product dictionary. It only transliterates Arabic brand-like
# tokens so queries such as "متوفر عندكم فيروكسيل" can retrieve "Feroxyl" from DB.
_AR_TO_LATIN_OPTIONS = {
    "ا": ["a", ""], "ب": ["b"], "ت": ["t"], "ث": ["th"], "ج": ["j", "g"], "ح": ["h"], "خ": ["kh"],
    "د": ["d"], "ذ": ["z", "dh"], "ر": ["r"], "ز": ["z"], "س": ["s"], "ش": ["sh"], "ص": ["s"],
    "ض": ["d"], "ط": ["t"], "ظ": ["z"], "ع": ["a", ""], "غ": ["gh"], "ف": ["f"], "ق": ["q", "k"],
    "ك": ["k", "c"], "ل": ["l"], "م": ["m"], "ن": ["n"], "ه": ["h", "a"], "و": ["o", "u", "w"],
    "ي": ["i", "y", "e"], "ء": [""],
}
_QUERY_FILLER_WORDS = STOPWORDS | {"شن", "شني", "شنو", "فيها", "فيكم", "عندي", "عندكو", "نبو", "نبي", "نبى", "توا", "بالله", "لو سمحت", "عطيني"}


def _arabic_token_to_latin_variants(token: str, *, max_variants: int = 24) -> List[str]:
    token = normalize_text(token)
    if not token or not re.fullmatch(r"[\u0600-\u06FF]+", token):
        return []
    variants = [""]
    for ch in token:
        opts = _AR_TO_LATIN_OPTIONS.get(ch, [""])
        nxt = []
        for base in variants:
            for opt in opts:
                val = base + opt
                if len(val) <= 40:
                    nxt.append(val)
        # Keep deterministic and bounded.
        seen = []
        for v in nxt:
            if v not in seen:
                seen.append(v)
            if len(seen) >= max_variants:
                break
        variants = seen or variants
    expanded = set()
    for v in variants:
        v = re.sub(r"(.)\1{2,}", r"\1\1", v).strip()
        if len(v) < 3:
            continue
        expanded.add(v)
        expanded.add(v.replace("ks", "x"))
        expanded.add(v.replace("cs", "x"))
        expanded.add(v.replace("oo", "o"))
        expanded.add(v.replace("ou", "o"))
        expanded.add(v.replace("w", "o"))
        expanded.add(v.replace("k", "c"))
        expanded.add(v.replace("c", "k"))
        if v.startswith("fi"):
            expanded.add("fe" + v[2:])
        if v.endswith("il"):
            expanded.add(v[:-2] + "yl")
        # Common Arabic rendering of xyl / xil / ksil in product names.
        expanded.add(v.replace("oksil", "oxyl"))
        expanded.add(v.replace("oksil", "oxil"))
        expanded.add(v.replace("oksyl", "oxyl"))
        expanded.add(v.replace("oksel", "oxyl"))
        expanded.add(v.replace("oksy", "oxy"))
        expanded.add(v.replace("roks", "rox"))
        expanded.add(v.replace("rocs", "rox"))
    out = []
    for v in sorted(expanded, key=lambda x: (len(x), x)):
        if v and v not in out:
            out.append(v)
        if len(out) >= max_variants:
            break
    return out


def query_variants(value: object, *, max_variants: int = 24) -> List[str]:
    """Return safe retrieval variants for a user query.

    Keeps the original cleaned query and adds Arabic-to-Latin phonetic variants
    for distinctive Arabic tokens. Used for retrieval only, never for direct price.
    """
    cleaned = clean_query(value)
    variants: List[str] = []
    seen = set()

    def add(v: object) -> None:
        q = clean_query(v)
        if not q or len(q) < 3:
            return
        if q not in seen:
            variants.append(q)
            seen.add(q)

    add(cleaned)
    tokens = [t for t in normalize_text(value).split() if t and t not in _QUERY_FILLER_WORDS]
    for token in tokens:
        if len(token) >= 3:
            add(token)
        for v in _arabic_token_to_latin_variants(token, max_variants=24):
            add(v)
            # Common vowel alternatives for Arabic brand names.
            for vv in {v.replace("firo", "fero"), v.replace("firox", "ferox"), v.replace("fi", "fe", 1)}:
                add(vv)
            # Also try the variant inside the cleaned query, preserving context when useful.
            if token in cleaned:
                add(cleaned.replace(token, v))
        if len(variants) >= max_variants:
            break
    return variants[:max_variants]


def truthy(value: object) -> bool:
    n = normalize_text(value)
    return n in {"1", "true", "yes", "y", "متوفر", "available", "ok", "نعم"}

def safe_price(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        num = float(text)
        if num.is_integer():
            return str(int(num))
        return f"{num:.2f}".rstrip("0").rstrip(".")
    except Exception:
        return text
