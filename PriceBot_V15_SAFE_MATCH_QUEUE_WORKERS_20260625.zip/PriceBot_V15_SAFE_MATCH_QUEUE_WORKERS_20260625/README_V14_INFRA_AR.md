# PriceBot V15 Safe Match Queue Workers

هذه نسخة مبنية فوق V13 المستقرة. الهدف منها تقوية البنية التحتية فقط، بدون تغيير منطق المطابقة أو المنتجات أو Gemini.

## ماذا أضفنا؟

- Redis Queue حقيقي بدل الاعتماد فقط على `asyncio.Queue` داخل الذاكرة.
- Webhook سريع: يستقبل رسالة WhatsApp ويضعها في queue ثم يرجع 200 بسرعة.
- queue مشتركة بين أكثر من uvicorn worker.
- تشغيل uvicorn بعدد workers قابل للضبط.
- حد concurrency قابل للضبط.
- Health يعرض:
  - `queue_backend`
  - `redis_queue_enabled`
  - `text_queue_size`
  - `image_queue_size`
  - `text_queue_key`
  - `image_queue_key`
- Redis queue atomic length guard لمنع امتلاء الذاكرة تحت الضغط.
- لا تغيير في database schema.
- لا تغيير في embeddings.
- لا تغيير في semantic matching.

## الإعدادات المقترحة للسيرفر الحالي 4 vCPU / 8GB

```env
PRICEBOT_QUEUE_BACKEND=redis
PRICEBOT_UVICORN_WORKERS=2
PRICEBOT_UVICORN_LIMIT_CONCURRENCY=200
PRICEBOT_TEXT_WORKERS=6
PRICEBOT_IMAGE_WORKERS=2
PRICEBOT_IMAGE_CONCURRENCY=3
PRICEBOT_TEXT_QUEUE_MAXSIZE=8000
PRICEBOT_IMAGE_QUEUE_MAXSIZE=1500
PRICEBOT_RATE_LIMIT_MESSAGES=90
PRICEBOT_RATE_LIMIT_IMAGES=15
PRICEBOT_GLOBAL_RATE_LIMIT_REQUESTS=600
```

مع 2 uvicorn workers، العدد الفعلي التقريبي:

- Text workers = 12
- Image workers = 4
- Image concurrency داخل كل process = 3

## ملاحظات مهمة

- يجب وجود Redis/Valkey شغال و `REDIS_URL` مضبوط.
- هذه النسخة لا تجعل الصور أسرع من Gemini، لكنها تمنع الضغط من إسقاط البوت.
- عند الضغط العالي، الرد قد يتأخر لكن الرسائل تدخل queue.
- لو Redis غير شغال والـ queue backend مضبوط على redis، البوت سيرفض الضغط بدل أن يشتغل بذاكرة محلية غير آمنة.

## فحص بعد التركيب

```bash
curl -sS http://127.0.0.1:8090/health | python3 -m json.tool | head -200
```

المطلوب أن ترى:

```text
final_ui_version: v15_safe_match_queue_workers
queue_backend: redis
redis_queue_enabled: true
redis_state_enabled: true
products_count: 5163
```
