from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import database
from normalizer import clean_query, compact_normalize, is_generic_query, normalize_text, split_multi, tokens

@dataclass
class SearchResult:
    status: str
    message: str = ""
    products: List[Dict] = field(default_factory=list)
    product: Optional[Dict] = None
    clarification: Optional[str] = None


def product_identity_key(p: Dict) -> Tuple[str, str, str, str, str]:
    return (
        normalize_text(p.get("brand")), normalize_text(p.get("product_family")), normalize_text(p.get("form") or p.get("medicine_form")),
        normalize_text(p.get("strength")), normalize_text(p.get("size")),
    )


def dedupe_products(products: List[Dict], limit: int = 20) -> List[Dict]:
    out = []
    seen = set()
    for p in products:
        key = p.get("id") or product_identity_key(p)
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def _visible(products: List[Dict]) -> List[Dict]:
    return [p for p in products if database.product_visible(p, guided=False)]


def _same_identity_duplicates(products: List[Dict]) -> bool:
    if len(products) <= 1:
        return True
    keys = {product_identity_key(p) for p in products}
    return len(keys) == 1


def _medicine_variant_needs_clarification(products: List[Dict], query: str) -> Optional[str]:
    meds = [p for p in products if normalize_text(p.get("category")) == "medicine"]
    if len(meds) <= 1:
        return None
    q = normalize_text(query)
    forms = sorted({normalize_text(p.get("form") or p.get("medicine_form")) for p in meds if normalize_text(p.get("form") or p.get("medicine_form"))})
    strengths = sorted({normalize_text(p.get("strength")) for p in meds if normalize_text(p.get("strength"))})
    if forms and not any(f and f in q for f in forms):
        return "هذا الدواء له أكثر من شكل. اكتب الشكل المطلوب مثل: أقراص / شراب / حقن / تحاميل."
    if strengths and len(strengths) > 1 and not any(s and s in q for s in strengths):
        return "هذا الدواء له أكثر من تركيز. اكتب التركيز المطلوب قبل عرض السعر."
    return None


def build_search_index_entries() -> List[Tuple[str, str, int, int]]:
    entries: List[Tuple[str, str, int, int]] = []
    for p in database.load_product_rows(visible_only=True, guided=False):
        pid = int(p["id"])
        name = normalize_text(p.get("name")) or normalize_text(p.get("original_name"))
        if name:
            entries.append((name, "name", pid, 100))
            entries.append((compact_normalize(name), "compact_name", pid, 95))
        normalized_name = normalize_text(p.get("normalized_name"))
        if normalized_name and normalized_name != name:
            entries.append((normalized_name, "name", pid, 100))
            entries.append((compact_normalize(normalized_name), "compact_name", pid, 95))
        barcode = normalize_text(p.get("barcode"))
        if barcode:
            entries.append((barcode, "barcode", pid, 120))
        for alias in split_multi(p.get("aliases")):
            a = normalize_text(alias)
            if a:
                entries.append((a, "alias", pid, 90))
                entries.append((compact_normalize(a), "compact_alias", pid, 85))
        for keyword in split_multi(p.get("ocr_keywords")):
            k = normalize_text(keyword)
            if k:
                entries.append((k, "ocr_keyword", pid, 82))
                entries.append((compact_normalize(k), "compact_ocr_keyword", pid, 78))
    return entries


def rebuild_search_index() -> int:
    return database.replace_search_index(build_search_index_entries())


SYNONYM_TOKENS = {"zofran": "ondansetron", "داكتارين": "daktarin", "دكتارين": "daktarin", "فلاجيل": "flagyl"}
UNIT_TOKENS = {"mg", "ml", "g", "mcg", "مجم", "مل"}
SAFE_SINGLE_MEDICINE_TOKENS = {"flagyl", "metronidazole", "zofran", "ondansetron", "amoclan", "augmentin", "panadol", "paracetamol"}

VISION_GENERIC_TOKENS = {
    "cream", "gel", "tube", "capsule", "capsules", "cap", "caps", "tablet", "tablets", "tab", "tabs",
    "vitamin", "vitamins", "female", "male", "fertility", "health", "supports", "support", "care", "dietary",
    "supplement", "food", "natural", "advanced", "formula", "softgel", "softgels", "immune",
    "mg", "ml", "g", "iu", "mcg", "i", "u", "plus", "with", "for", "and", "the",
    "كريم", "جل", "حبوب", "فيتامين", "كبسولات", "شراب", "قطره", "بخاخ", "شامبو",
}


def _vision_tokens(value: object) -> List[str]:
    raw = [SYNONYM_TOKENS.get(t, t) for t in tokens(value)]
    out: List[str] = []
    prev = ""
    for t in raw:
        if t in {"iu", "mg", "ml", "g", "mcg"} and prev.isdigit():
            out.append(t)
            prev = t
            continue
        if not t or t in VISION_GENERIC_TOKENS:
            prev = t
            continue
        # Keep strengths such as 50000/850, but ignore tiny package counts
        # when they only follow generic pack words.
        if t.isdigit() and len(t) <= 2 and prev in {"cap", "caps", "capsule", "capsules", "tab", "tabs", "tablet", "tablets"}:
            prev = t
            continue
        if len(t) <= 1 and not t.isdigit():
            prev = t
            continue
        out.append(t)
        prev = t
    return out


def _product_identity_hay(product: Dict) -> str:
    return normalize_text(" ".join(str(product.get(c) or "") for c in [
        "name", "normalized_name", "brand", "product_family", "aliases", "ocr_keywords", "strength", "size", "pack", "form"
    ]))


def _vision_score_product(product: Dict, query_tokens: List[str], compact_query: str) -> int:
    if not query_tokens:
        return 0
    hay = _product_identity_hay(product)
    hay_tokens = set(hay.split())
    compact_hay = compact_normalize(hay)
    name = normalize_text(product.get("name"))
    brand = normalize_text(product.get("brand"))
    family = normalize_text(product.get("product_family"))
    strength = normalize_text(product.get("strength"))
    pack = normalize_text(product.get("pack"))

    # Require at least one real product identity token, not just a dosage/unit.
    identity_text = normalize_text(" ".join([name, brand, family]))
    identity_tokens = {t for t in identity_text.split() if t not in VISION_GENERIC_TOKENS and (not t.isdigit() or len(t) >= 3)}
    non_numeric_identity_tokens = {t for t in identity_tokens if not t.isdigit()}
    if not non_numeric_identity_tokens.intersection(set(query_tokens)):
        return 0

    score = 0
    if compact_query and compact_normalize(name) and compact_normalize(name) in compact_query:
        score += 90
    if compact_query and compact_hay and compact_query in compact_hay:
        score += 45
    if brand and all(t in set(query_tokens) for t in _vision_tokens(brand)):
        score += 45
    if family and all(t in set(query_tokens) for t in _vision_tokens(family)):
        score += 40
    if strength and any(t in set(query_tokens) for t in _vision_tokens(strength)):
        score += 30
    if pack and any(t in set(query_tokens) for t in _vision_tokens(pack)):
        score += 8
    for t in query_tokens:
        if t in hay_tokens:
            score += 12 if not t.isdigit() else 8
        elif t and t in hay:
            score += 5
    return score


def _best_vision_candidates(query: str, limit: int = 10) -> List[Dict]:
    qt = _vision_tokens(query)
    if not qt:
        return []
    compact_q = compact_normalize(" ".join(qt))
    scored: List[Dict] = []
    for p in database.load_product_rows(visible_only=True, guided=False):
        score = _vision_score_product(p, qt, compact_q)
        if score >= 35:
            item = dict(p)
            item["_score"] = score
            scored.append(item)
    scored.sort(key=lambda p: (-int(p.get("_score") or 0), str(p.get("name") or "")))
    return dedupe_products(scored, limit=limit)


def search_vision_product(extracted: Dict) -> SearchResult:
    """Match Vision extraction safely.

    The image model may return long packaging text.  This function searches in
    stages and only uses strong identity tokens.  It never falls back to global
    fuzzy matching or generic words.
    """
    candidates = extracted.get("query_candidates") or []
    if not isinstance(candidates, list):
        candidates = []
    primary = str(extracted.get("query") or "").strip()
    if primary and primary not in candidates:
        candidates.insert(0, primary)

    # 1) Exact product name / alias / OCR keyword on cleaned candidates.
    for q in candidates:
        cleaned = " ".join(_vision_tokens(q))
        if not cleaned:
            continue
        exact = _visible(database.find_by_exact_index(normalize_text(cleaned), ["name", "alias", "ocr_keyword", "barcode"]))
        if not exact:
            exact = _visible(database.find_by_exact_index(compact_normalize(cleaned), ["compact_name", "compact_alias", "compact_ocr_keyword"]))
        exact = dedupe_products(exact, limit=10)
        if len(exact) == 1 or (exact and _same_identity_duplicates(exact)):
            return SearchResult("EXACT_MATCH", product=exact[0], products=[exact[0]])
        if len(exact) > 1:
            return SearchResult("ASK_CLARIFICATION", "وجدت أكثر من منتج قريب من الصورة. اختر المنتج المطلوب:", products=exact[:10])

    # 2) Strong-token scoring over product identity fields only.
    scored: List[Dict] = []
    for q in candidates:
        scored.extend(_best_vision_candidates(q, limit=10))
    scored = dedupe_products(scored, limit=10)
    if not scored:
        return SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.")
    if len(scored) == 1:
        return SearchResult("EXACT_MATCH", product=scored[0], products=[scored[0]])
    top = int(scored[0].get("_score") or 0)
    second = int(scored[1].get("_score") or 0)
    if top >= 70 and top >= second + 25:
        return SearchResult("EXACT_MATCH", product=scored[0], products=[scored[0]])
    return SearchResult("ASK_CLARIFICATION", "وجدت أكثر من منتج قريب من الصورة. اختر المنتج المطلوب:", products=scored[:10])

def expand_query_tokens(q: str) -> List[str]:
    raw = tokens(q)
    expanded: List[str] = []
    has_number = any(t.isdigit() for t in raw)
    for t in raw:
        if has_number and t in UNIT_TOKENS:
            continue
        expanded.append(SYNONYM_TOKENS.get(t, t))
    return expanded

def search_product(query: str, allow_guided_redirect: bool = True) -> SearchResult:
    raw = str(query or "").strip()
    q = clean_query(raw)
    if not q:
        return SearchResult("ASK_CLARIFICATION", "اكتب اسم المنتج كاملًا أو اختر من القائمة.")

    if allow_guided_redirect and is_generic_query(q):
        return SearchResult("ASK_CLARIFICATION", generic_redirect_message(q), clarification="guided")

    norm = normalize_text(q)
    compact = compact_normalize(q)

    exact = _visible(database.find_by_exact_index(norm, ["name", "alias", "ocr_keyword", "barcode"]))
    if not exact and compact:
        exact = _visible(database.find_by_exact_index(compact, ["compact_name", "compact_alias", "compact_ocr_keyword"]))
    exact = dedupe_products(exact, limit=20)
    if len(exact) == 1 or (exact and _same_identity_duplicates(exact)):
        return SearchResult("EXACT_MATCH", product=exact[0], products=[exact[0]])
    if len(exact) > 1:
        clarification = _medicine_variant_needs_clarification(exact, q)
        if clarification:
            return SearchResult("ASK_CLARIFICATION", clarification, products=exact[:10])
        return SearchResult("PRODUCT_LIST", products=exact[:10], message="وجدت أكثر من منتج مطابق. اختر الرقم:")

    qt = expand_query_tokens(q)
    if len(qt) < 2 and not any(t.isdigit() and len(t) >= 3 for t in qt):
        # Single non-generic brand/family names are allowed only through the
        # catalog candidate path. One unique product can show a price; multiple
        # variants must ask the user to choose. Generic words were already
        # blocked above by is_generic_query().
        single_candidates = dedupe_products(database.search_candidates_by_tokens(qt, limit=20), limit=20)
        if not single_candidates:
            return SearchResult("ASK_CLARIFICATION", "اكتب الاسم الكامل للمنتج أو الشركة مع النوع/التركيز.")
        clarification = _medicine_variant_needs_clarification(single_candidates, q)
        if clarification:
            return SearchResult("ASK_CLARIFICATION", clarification, products=single_candidates[:10])
        if len(single_candidates) == 1:
            return SearchResult("EXACT_MATCH", product=single_candidates[0], products=[single_candidates[0]])
        return SearchResult("ASK_CLARIFICATION", "وجدت أكثر من منتج قريب من بحثك. اختر المنتج المطلوب:", products=single_candidates[:10])

    candidates = dedupe_products(database.search_candidates_by_tokens(qt, limit=20), limit=20)
    if not candidates:
        # Long OCR-like text can contain marketing/package words that are not
        # catalog identity.  Use the same conservative strong-token matcher as
        # Vision before declaring NOT_AVAILABLE.  This still rejects generic-only
        # queries and never uses global fuzzy fallback.
        strong = _best_vision_candidates(q, limit=10)
        if len(strong) == 1:
            return SearchResult("EXACT_MATCH", product=strong[0], products=[strong[0]])
        if len(strong) > 1:
            top = int(strong[0].get("_score") or 0)
            second = int(strong[1].get("_score") or 0)
            if top >= 70 and top >= second + 25:
                return SearchResult("EXACT_MATCH", product=strong[0], products=[strong[0]])
            return SearchResult("ASK_CLARIFICATION", "وجدت أكثر من منتج قريب من بحثك. اختر المنتج المطلوب:", products=strong[:10])
        return SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.")

    clarification = _medicine_variant_needs_clarification(candidates, q)
    if clarification:
        return SearchResult("ASK_CLARIFICATION", clarification, products=candidates[:10])

    # If the query is very specific and the best candidate contains all tokens, show list instead of guessing one.
    if len(candidates) == 1:
        return SearchResult("EXACT_MATCH", product=candidates[0], products=[candidates[0]])
    return SearchResult("PRODUCT_LIST", products=candidates[:10], message="وجدت منتجات قريبة من الاسم المكتوب. اختر الرقم:")


def generic_redirect_message(q: str) -> str:
    n = normalize_text(q)
    if n in {"غسول", "cleanser", "wash"}:
        return "هل تقصد غسول وجه، غسول جسم، أم غسول أطفال؟ اختر من تصفح الأقسام لتجنب النتائج الخاطئة."
    if n in {"كريم", "cream", "مرطب", "lotion"}:
        return "اكتب اسم الكريم كاملًا أو اختر القسم المناسب من تصفح الأقسام."
    if n in {"حديد", "iron"}:
        return "لمنتجات الحديد اختر: تصفح الأقسام ← مكملات وفيتامينات ← حديد."
    if n in {"فيتامين", "فيتامينات", "vitamin"}:
        return "اختر نوع الفيتامين من قسم مكملات وفيتامينات."
    if n in {"شامبو", "shampoo"}:
        return "اختر عناية بالشعر ← شامبو لعرض الشامبوهات المتوفرة فقط."
    return "الطلب عام. اختر من تصفح الأقسام أو اكتب اسم المنتج كاملًا."
