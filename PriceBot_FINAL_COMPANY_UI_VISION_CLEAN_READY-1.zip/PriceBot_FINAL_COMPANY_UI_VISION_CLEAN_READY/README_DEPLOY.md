# PriceBot FINAL COMPANY UI + VISION + CLEAN

Release: `PriceBot_FINAL_COMPANY_UI_VISION_CLEAN_READY.zip`

This package is a clean production delivery for the WhatsApp Pharmacy Bot. It contains no `.env`, no `pricebot.db`, no secrets, no backups, no old ZIPs, and no Python caches.

## What this release includes

- Clean `/opt/pricebot_clean` runtime layout.
- `start_pricebot.sh` that safely loads `.env` without `source`.
- OpenRouter compatibility aliases:
  - `AI_OPENROUTER_KEYS` / `AI_OPENROUTER_KEY` / `OPENROUTER_KEYS` / `OPENROUTER_KEY` → `OPENROUTER_API_KEY`
  - `AI_OPENROUTER_MODEL` → `OPENROUTER_MODEL`
  - `AI_OPENROUTER_BASE_URL` → `OPENROUTER_BASE_URL`
- Vision enabled when a valid OpenRouter key exists unless explicitly disabled by:
  - `AI_ENABLED=false`
  - `VISION_ENABLED=false`
  - `IMAGE_ENABLED=false`
  - `OCR_ENABLED=false`
  - `ENABLE_IMAGE_SEARCH=false`
- Booking disabled by default:
  - `BOOKING_ENABLED=false`
  - `RESERVATION_ENABLED=false`
- Company-style WhatsApp UI flow:
  - Start button fallback
  - Main menu
  - Search by name
  - Search by image
  - Category browsing
  - Back/menu reset
- Excel importer with dynamic header detection in the first 15 rows.
- Catalog sellable policy: exact search can show price for sellable `needs_review` products if they are available, priced, named clearly, and not `unknown`.
- Guided browsing remains stricter and uses classified category/subcategory data.

## One-command clean install

Extract the ZIP, then run:

```bash
cd /tmp
unzip PriceBot_FINAL_COMPANY_UI_VISION_CLEAN_READY.zip
cd PriceBot_FINAL_COMPANY_UI_VISION_CLEAN_READY
sudo ./clean_install_pricebot.sh
```

The script does the following safely:

1. Stops `pricebot.service`.
2. Backs up only `.env`, `pricebot.db` if present, and `pricebot.service`.
3. Moves the old `/opt/pricebot_clean` to a rollback folder instead of copying old clutter.
4. Creates a clean `/opt/pricebot_clean`.
5. Copies only clean release files.
6. Copies the existing `.env` safely.
7. Builds a new venv.
8. Imports `products_master_ready.xlsx` into a new DB.
9. Runs verify.
10. Updates `pricebot.service` to `/opt/pricebot_clean/start_pricebot.sh`.
11. Starts the service.
12. Tests health and webhook verification.

The old rollback directory is kept and must not be deleted for at least 48 hours.

## Manual checks after install

```bash
cd /opt/pricebot_clean
./venv/bin/python -m compileall .
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot_clean/pricebot.db --excel-path /opt/pricebot_clean/products_master_ready.xlsx
sudo systemctl status pricebot --no-pager -l
curl -sS http://127.0.0.1:8090/health
TOKEN="$(grep -E '^META_VERIFY_TOKEN=' /opt/pricebot_clean/.env | cut -d= -f2-)" && curl -i "https://46.101.148.246.sslip.io/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=${TOKEN}&hub.challenge=PING"
```

Expected webhook result:

```text
HTTP 200
PING
```

## Important safety notes

- This package does not touch MedMCQ.
- This package does not include `.env` or `pricebot.db`.
- The installer does not copy old backups or old ZIPs.
- The installer does not delete the old rollback folder.
- The bot never shows a price unless a product is matched from the SQLite catalog.
- Vision does not use generic words alone to return random products.
