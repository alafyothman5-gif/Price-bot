import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import ui_flow
import conversation_state as cs
import search_engine
import matcher
import vision_service
import config_env


def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)


def main():
    db_path = os.environ.get("PRICEBOT_DB_PATH") or "/tmp/pricebot_acceptance.sqlite"
    database.configure_db_path(db_path)
    phone = "acceptance_user"
    database.init_db(run_production_guard=False)
    database.clear_state(phone)

    r = ui_flow.handle_text(phone, "مرحبا")
    assert_true("ابدأ الاستخدام" in r or "ابدأ" in r, "greeting_start_button_fallback")
    r = ui_flow.handle_text(phone, "ابدأ")
    assert_true("البحث عن منتج" in r and "تصفح الأقسام" in r, "main_menu")
    r = ui_flow.handle_text(phone, "1")
    assert_true("البحث بالاسم" in r and "البحث بالصورة" in r, "search_submenu")
    r = ui_flow.handle_text(phone, "1")
    assert_true("اكتب اسم المنتج" in r, "name_search_prompt")
    r = ui_flow.handle_text(phone, "gaviscon")
    assert_true("حدد" in r or "اختر" in r or "أكثر" in r, "gaviscon_clarification")
    assert_true(cs.get(phone).get("state") == cs.WAITING_FOR_CLARIFICATION, "state_clarification")
    r = ui_flow.handle_text(phone, "2")
    assert_true("المنتج متوفر" in r and "للحجز" not in r, "product_detail_no_booking")
    r = ui_flow.handle_text(phone, "نعم")
    assert_true("الحجز غير متوفر" in r or "القائمة" in r, "booking_disabled")
    r = ui_flow.handle_text(phone, "القائمة")
    assert_true("اختر خدمة" in r, "menu_reset")
    r = ui_flow.handle_text(phone, "2")
    assert_true("اختر القسم" in r, "browse_categories")
    r = ui_flow.handle_text(phone, "1")
    assert_true("رجوع" in r, "subcategories")
    r = ui_flow.handle_text(phone, "رجوع")
    assert_true("اختر القسم" in r or "اختر خدمة" in r, "back_works")

    for q in ["Pro-D3 50,000 IU", "Ovanice"]:
        result = search_engine.search_product(q)
        assert_true(result.status in {"EXACT_MATCH", "ASK_CLARIFICATION", "PRODUCT_LIST"}, f"search_{q}")
        if result.status == "EXACT_MATCH":
            assert_true(result.product and result.product.get("price"), f"search_price_{q}")

    result = search_engine.search_product("غسول")
    assert_true(result.status == "ASK_CLARIFICATION", "generic_no_random")


    vision_cases = [
        ({"product_name": "Pro-D3 50,000 IU vitamin k2 15 capsules", "confidence": "0.92"}, "Pro-D3 50<000IU"),
        ({"brand": "Pro Bio", "product_name": "Pro-D3 50,000 IU Vitamin K2", "confidence": "0.92"}, "Pro-D3 50<000IU"),
        ({"product_name": "Ovanice Female Fertility 90 capsules 850mg", "confidence": "0.92"}, "Ovanice 90caps"),
    ]
    for slots, expected_name in vision_cases:
        candidates = vision_service.build_query_candidates_from_slots(slots)
        assert_true(candidates, f"vision_candidates_{expected_name}")
        # Raw visible/package text must be stripped from the matcher query.
        assert_true("capsules" not in " ".join(candidates).lower(), f"vision_generic_removed_{expected_name}")
        result = matcher.match_vision_extraction({"query": candidates[0], "query_candidates": candidates, **slots})
        assert_true(result.status == "EXACT_MATCH", f"vision_exact_{expected_name}")
        assert_true(result.product and result.product.get("name") == expected_name and result.product.get("price"), f"vision_price_{expected_name}")

    generic_slots = {"product_name": "cream capsules vitamin female tube", "confidence": "0.92"}
    generic_candidates = vision_service.build_query_candidates_from_slots(generic_slots)
    result = matcher.match_vision_extraction({"query": generic_candidates[0] if generic_candidates else "", "query_candidates": generic_candidates, **generic_slots})
    assert_true(result.status in {"NOT_AVAILABLE", "LOW_CONFIDENCE"}, "vision_generic_no_guess")

    print("ACCEPTANCE_TESTS_PASS=31")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
