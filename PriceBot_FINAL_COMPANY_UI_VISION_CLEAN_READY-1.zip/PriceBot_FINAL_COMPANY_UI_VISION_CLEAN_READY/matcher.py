from typing import Dict

from search_engine import SearchResult, search_product, search_vision_product

ALLOWED_DECISIONS = {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "PRODUCT_LIST", "LOW_CONFIDENCE", "IMAGE_UNCLEAR"}


def _guard_result(result: SearchResult) -> SearchResult:
    if result.status not in ALLOWED_DECISIONS:
        return SearchResult("LOW_CONFIDENCE", "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل أو أرسل صورة أوضح.")
    return result


def match_text(query: str) -> SearchResult:
    return _guard_result(search_product(query))


def match_vision_extraction(extracted: Dict) -> SearchResult:
    return _guard_result(search_vision_product(extracted or {}))
