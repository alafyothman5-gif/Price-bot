"""Company-style WhatsApp UI state machine for PriceBot."""
from __future__ import annotations

from typing import Dict, List, Optional

import category_browser
import config_env
import conversation_state as cs
import database
import matcher
import orders
from normalizer import normalize_text

PHARMACY_NAME = "صيدلية بدر البشرية"

GREETING_WORDS = {"السلام عليكم", "سلام عليكم", "مرحبا", "مرحبه", "اهلا", "أهلا", "هلا", "hi", "hello"}
START_WORDS = {"ابدأ", "ابدا", "start", "ابدأ الاستخدام", "ابدا الاستخدام", "START_USE", "MAIN_MENU"}
MENU_WORDS = {"القائمة", "قائمه", "قائمة", "الرئيسية", "الرئيسيه", "menu", "main menu", "MAIN_MENU"}
BACK_WORDS = {"رجوع", "عودة", "عوده", "back", "0"}
CANCEL_WORDS = {"الغاء", "إلغاء", "cancel"}
HELP_WORDS = {"مساعدة", "ساعدني", "help"}
YES_WORDS = {"نعم", "اي", "ايوه", "أيوه", "yes", "y"}
NEXT_WORDS = {"التالي", "المزيد", "next", "more"}
PREV_WORDS = {"السابق", "قبل", "prev", "previous"}

START_MESSAGE = (
    f"🌿 مرحبًا بك في {PHARMACY_NAME}\n\n"
    "يمكنك البحث عن المنتجات ومعرفة السعر والتوفر مباشرة من خلال البوت.\n\n"
    "اختر طريقة الاستخدام:\n\n"
    "اضغط: ابدأ الاستخدام\n"
    "إذا لم يظهر الزر اكتب: ابدأ"
)

MAIN_MENU_MESSAGE = (
    f"🌿 {PHARMACY_NAME}\n\n"
    "اختر خدمة:\n\n"
    "1. 🔎 البحث عن منتج\n"
    "2. 🗂️ تصفح الأقسام\n"
    "3. ℹ️ معلومات الصيدلية\n\n"
    "اكتب رقم الاختيار."
)

SEARCH_METHOD_MESSAGE = (
    "🔎 البحث عن منتج\n\n"
    "1. البحث بالاسم\n"
    "2. البحث بالصورة\n\n"
    "↩️ رجوع\n"
    "اكتب رقم الاختيار."
)

SEARCH_PROMPT = (
    "اكتب اسم المنتج أو جزءًا منه.\n\n"
    "مثال:\n"
    "Gaviscon\n"
    "Panadol\n"
    "Pro-D3\n\n"
    "اكتب \"القائمة\" للرجوع للقائمة الرئيسية."
)

IMAGE_PROMPT = (
    "📷 أرسل صورة واضحة للواجهة الأمامية للمنتج.\n"
    "يفضل أن يظهر الاسم والتركيز والحجم بوضوح.\n\n"
    "اكتب \"القائمة\" للرجوع للقائمة الرئيسية."
)

HELP_MESSAGE = (
    "طريقة الاستخدام:\n\n"
    "للبحث عن منتج: اختر البحث عن منتج ثم البحث بالاسم.\n"
    "للبحث بالصورة: اختر البحث عن منتج ثم البحث بالصورة وأرسل صورة واضحة.\n"
    "لتصفح المنتجات: اختر تصفح الأقسام.\n\n"
    "أوامر عامة: القائمة / رجوع / إلغاء.\n\n"
    "اكتب \"القائمة\" للرجوع للقائمة الرئيسية."
)

INFO_MESSAGE = (
    f"🌿 {PHARMACY_NAME}\n\n"
    "📍 المدينة: أجدابيا\n"
    "⏰ ساعات العمل: 24 ساعة\n"
    "🚚 التوصيل: غير متوفر حاليًا\n\n"
    "اكتب \"القائمة\" للعودة للقائمة الرئيسية."
)


def _norm(text: str) -> str:
    return normalize_text(text)


def _normset(values) -> set[str]:
    return {_norm(x) for x in values}


def number_choice(text: str) -> Optional[int]:
    t = _norm(text)
    if t.isdigit():
        try:
            return int(t)
        except Exception:
            return None
    return None


def is_start(text: str) -> bool:
    n = _norm(text)
    return n in _normset(START_WORDS) or n == "start use"


def is_greeting(text: str) -> bool:
    return _norm(text) in _normset(GREETING_WORDS)


def is_menu(text: str) -> bool:
    return _norm(text) in _normset(MENU_WORDS)


def is_back(text: str) -> bool:
    return _norm(text) in _normset(BACK_WORDS)


def is_cancel(text: str) -> bool:
    return _norm(text) in _normset(CANCEL_WORDS)


def is_help(text: str) -> bool:
    return _norm(text) in _normset(HELP_WORDS)


def show_start(phone: str) -> str:
    cs.set(phone, cs.START)
    return START_MESSAGE


def show_main_menu(phone: str) -> str:
    cs.set(phone, cs.MAIN_MENU)
    return MAIN_MENU_MESSAGE


def show_search_method(phone: str) -> str:
    cs.set(phone, cs.WAITING_FOR_SEARCH_METHOD)
    return SEARCH_METHOD_MESSAGE


def show_search_prompt(phone: str) -> str:
    cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
    return SEARCH_PROMPT


def show_image_prompt(phone: str) -> str:
    cs.set(phone, cs.WAITING_FOR_PRODUCT_IMAGE)
    return IMAGE_PROMPT


def show_info(phone: str) -> str:
    cs.set(phone, cs.MAIN_MENU)
    return INFO_MESSAGE


def show_categories(phone: str) -> str:
    cats = category_browser.available_main_categories()
    cs.set(phone, cs.BROWSING_CATEGORIES, categories=cats)
    return category_browser.format_main_categories()


def show_subcategories(phone: str, main: str) -> str:
    subs = category_browser.available_subcategories(main)
    cs.set(phone, cs.BROWSING_SUBCATEGORY, main_category=main, subcategories=subs)
    return category_browser.format_subcategories(main)


def show_product_page(phone: str, main: str, sub: str, skin_type: str = "", page: int = 0) -> str:
    products = category_browser.products_for(main, sub, skin_type=skin_type, limit=120)
    ids = [int(p["id"]) for p in products if p.get("id")]
    cs.set(
        phone,
        cs.BROWSING_PRODUCT_PAGE,
        main_category=main,
        subcategory=sub,
        skin_type=skin_type,
        product_ids=ids,
        page=page,
    )
    return category_browser.format_product_page(sub, products, page=page)


def _product_rows_from_ids(ids: List[int]) -> List[Dict]:
    out: List[Dict] = []
    for pid in ids:
        try:
            p = database.get_product(int(pid))
        except Exception:
            p = None
        if p and database.product_visible(p, guided=False):
            out.append(p)
    return out


def _dedupe_display_products(products: List[Dict], limit: int = 10) -> List[Dict]:
    out: List[Dict] = []
    seen = set()
    for p in products:
        key = (
            normalize_text(p.get("name")),
            normalize_text(p.get("form") or p.get("medicine_form") or p.get("product_type")),
            normalize_text(p.get("strength")),
            normalize_text(p.get("size")),
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def _format_clarification_options(products: List[Dict]) -> str:
    if not products:
        return ""
    lines = ["", "حدد المطلوب:"]
    for i, product in enumerate(products[:10], 1):
        name = product.get("name") or "منتج"
        form = product.get("form") or product.get("medicine_form") or product.get("product_type") or ""
        strength = product.get("strength") or ""
        size = product.get("size") or ""
        extra = " ".join(x for x in [form, strength, size] if x).strip()
        lines.append(f"{i}. {name}" + (f" - {extra}" if extra and extra not in str(name) else ""))
    lines.append("")
    lines.append('اكتب رقم المنتج المطلوب أو اكتب "القائمة".')
    return "\n".join(lines)


def _format_products_without_prices(title: str, products: List[Dict], page: int = 0, page_size: int = 10) -> str:
    if not products:
        return "لا توجد منتجات متوفرة حاليًا.\nاكتب رجوع للعودة."
    start = page * page_size
    chunk = products[start:start + page_size]
    lines = [f"{title} - صفحة {page + 1}", ""]
    for i, product in enumerate(chunk, 1):
        lines.append(f"{i}. {product.get('name') or 'منتج'}")
    lines.append("")
    lines.append("اكتب رقم المنتج للتفاصيل.")
    if start + page_size < len(products):
        lines.append('اكتب "التالي" لعرض المزيد.')
    if page > 0:
        lines.append('اكتب "السابق" للصفحة السابقة.')
    lines.append('اكتب "رجوع" للعودة أو "القائمة" للقائمة الرئيسية.')
    return "\n".join(lines)


def handle_search_result(phone: str, result, original_query: str = "") -> str:
    if result.status == "EXACT_MATCH" and result.product:
        cs.set(phone, cs.PRODUCT_DETAIL, product_id=int(result.product["id"]), source="search")
        return orders.format_product_details(result.product)

    if result.status == "PRODUCT_LIST" and result.products:
        products = result.products[:80]
        ids = [int(p["id"]) for p in products if p.get("id")]
        cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=0, main_category="بحث", subcategory="نتائج البحث", hide_prices=True)
        msg = (result.message + "\n\n") if result.message else ""
        return msg + _format_products_without_prices("نتائج البحث", products, page=0)

    if result.status == "ASK_CLARIFICATION":
        products = _dedupe_display_products(result.products, limit=10) if result.products else []
        cs.set(phone, cs.WAITING_FOR_CLARIFICATION, pending_query=original_query, candidate_ids=[int(p["id"]) for p in products if p.get("id")])
        message = result.message or "أحتاج تفاصيل أكثر قبل عرض السعر."
        return message + _format_clarification_options(products)

    if result.status == "NOT_AVAILABLE":
        cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
        return (
            "لم أجد المنتج في قائمة الصيدلية حاليًا.\n\n"
            "تأكد من كتابة الاسم بشكل صحيح، أو أرسل صورة أوضح للمنتج.\n"
            "اكتب \"القائمة\" للرجوع."
        )

    if result.status in {"LOW_CONFIDENCE", "IMAGE_UNCLEAR"}:
        cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
        return (result.message or "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل.") + "\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."

    cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
    return (result.message or "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل.") + "\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."


def handle_back(phone: str, state: Dict) -> str:
    current = cs.current_name(state)
    if current in {cs.START, cs.MAIN_MENU, ""}:
        return show_main_menu(phone)
    if current in {cs.WAITING_FOR_SEARCH_METHOD, cs.WAITING_FOR_PRODUCT_SEARCH, cs.WAITING_FOR_PRODUCT_IMAGE, cs.WAITING_FOR_CLARIFICATION}:
        return show_main_menu(phone)
    if current == cs.BROWSING_CATEGORIES:
        return show_main_menu(phone)
    if current == cs.BROWSING_SUBCATEGORY:
        return show_categories(phone)
    if current == cs.BROWSING_PRODUCT_PAGE:
        main = state.get("main_category") or ""
        if main and main != "بحث":
            return show_subcategories(phone, main)
        return show_main_menu(phone)
    if current == cs.PRODUCT_DETAIL:
        ids = state.get("previous_product_ids") or []
        if ids:
            page = int(state.get("previous_page") or 0)
            cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=page, main_category=state.get("main_category") or "", subcategory=state.get("subcategory") or "")
            return category_browser.format_product_page(state.get("subcategory") or "المنتجات", _product_rows_from_ids(ids), page=page)
        return show_main_menu(phone)
    return show_main_menu(phone)


def handle_main_menu_choice(phone: str, text: str) -> str:
    n = _norm(text)
    choice = number_choice(text)
    if choice == 1 or n in {_norm("البحث عن منتج"), _norm("🔎 البحث عن منتج"), "main search"}:
        return show_search_method(phone)
    if choice == 2 or n in {_norm("تصفح الأقسام"), _norm("تصفح الاقسام"), _norm("🗂️ تصفح الأقسام"), "main browse"}:
        return show_categories(phone)
    if choice == 3 or n in {_norm("معلومات الصيدلية"), _norm("ℹ️ معلومات الصيدلية"), "main info"}:
        return show_info(phone)
    if n in {_norm("البحث بصورة"), _norm("إرسال صورة منتج"), _norm("ارسال صورة منتج"), _norm("📷 البحث بصورة"), "main image"}:
        return show_image_prompt(phone)
    return MAIN_MENU_MESSAGE


def handle_text(phone: str, text: str) -> str:
    raw = str(text or "").strip()
    state = cs.get(phone)
    current = cs.current_name(state)
    n = _norm(raw)

    if not raw:
        return show_start(phone)
    if is_menu(raw):
        return show_main_menu(phone)
    if is_help(raw):
        return HELP_MESSAGE
    if is_cancel(raw):
        return show_main_menu(phone)
    if is_start(raw):
        return show_main_menu(phone)
    if is_greeting(raw):
        if current in {"", cs.START, cs.MAIN_MENU}:
            return show_start(phone)
        return show_main_menu(phone)
    if is_back(raw):
        return handle_back(phone, state)

    if not current or current == cs.START:
        if n in {_norm("بحث"), _norm("بحث باسم منتج"), _norm("البحث عن منتج")}:
            return show_search_method(phone)
        if n in {_norm("تصفح"), _norm("تصفح الأقسام"), _norm("تصفح الاقسام"), _norm("الأقسام"), _norm("اقسام")}:
            return show_categories(phone)
        if n in {_norm("صورة"), _norm("البحث بصورة"), _norm("ارسال صورة")}:
            return show_image_prompt(phone)
        if n in {_norm("معلومات"), _norm("معلومات الصيدلية")}:
            return show_info(phone)
        result = matcher.match_text(raw)
        return handle_search_result(phone, result, original_query=raw)

    if current == cs.MAIN_MENU:
        return handle_main_menu_choice(phone, raw)

    if current == cs.WAITING_FOR_SEARCH_METHOD:
        choice = number_choice(raw)
        if choice == 1 or n in {_norm("البحث بالاسم"), _norm("اسم"), _norm("name")}:
            return show_search_prompt(phone)
        if choice == 2 or n in {_norm("البحث بالصورة"), _norm("صورة"), _norm("image"), _norm("photo")}:
            return show_image_prompt(phone)
        return SEARCH_METHOD_MESSAGE

    if current == cs.WAITING_FOR_PRODUCT_SEARCH:
        result = matcher.match_text(raw)
        return handle_search_result(phone, result, original_query=raw)

    if current == cs.WAITING_FOR_PRODUCT_IMAGE:
        result = matcher.match_text(raw)
        return handle_search_result(phone, result, original_query=raw)

    if current == cs.BROWSING_CATEGORIES:
        choice = number_choice(raw)
        cats = state.get("categories") or category_browser.available_main_categories()
        if choice and 1 <= choice <= len(cats):
            return show_subcategories(phone, cats[choice - 1])
        for cat in cats:
            if n == _norm(cat):
                return show_subcategories(phone, cat)
        return category_browser.format_main_categories()

    if current == cs.BROWSING_SUBCATEGORY:
        main = state.get("main_category") or ""
        subs = state.get("subcategories") or category_browser.available_subcategories(main)
        choice = number_choice(raw)
        selected = ""
        if choice and 1 <= choice <= len(subs):
            selected = subs[choice - 1]
        else:
            for sub in subs:
                if n == _norm(sub):
                    selected = sub
                    break
        if not selected:
            return category_browser.format_subcategories(main)
        if selected == "بحث باسم دواء":
            return show_search_prompt(phone)
        if category_browser.needs_skin_type(main, selected):
            cs.set(phone, "WAITING_FOR_SKIN_TYPE", main_category=main, subcategory=selected)
            return category_browser.skin_type_menu()
        return show_product_page(phone, main, selected)

    if current == "WAITING_FOR_SKIN_TYPE":
        skin_type = category_browser.skin_type_from_choice(raw)
        if not skin_type:
            return category_browser.skin_type_menu()
        return show_product_page(phone, state.get("main_category") or "", state.get("subcategory") or "", skin_type=skin_type)

    if current == cs.BROWSING_PRODUCT_PAGE:
        ids = state.get("product_ids") or []
        page = int(state.get("page") or 0)
        products = _product_rows_from_ids(ids)
        if n in _normset(NEXT_WORDS):
            next_page = page + 1
            if next_page * 10 >= len(products):
                return "لا توجد منتجات إضافية.\nاكتب رجوع للعودة."
            cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=next_page, main_category=state.get("main_category") or "", subcategory=state.get("subcategory") or "", skin_type=state.get("skin_type") or "", hide_prices=bool(state.get("hide_prices")))
            if state.get("hide_prices"):
                return _format_products_without_prices(state.get("subcategory") or "المنتجات", products, page=next_page)
            return category_browser.format_product_page(state.get("subcategory") or "المنتجات", products, page=next_page)
        if n in _normset(PREV_WORDS):
            prev_page = max(0, page - 1)
            cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=prev_page, main_category=state.get("main_category") or "", subcategory=state.get("subcategory") or "", skin_type=state.get("skin_type") or "", hide_prices=bool(state.get("hide_prices")))
            if state.get("hide_prices"):
                return _format_products_without_prices(state.get("subcategory") or "المنتجات", products, page=prev_page)
            return category_browser.format_product_page(state.get("subcategory") or "المنتجات", products, page=prev_page)
        choice = number_choice(raw)
        if choice:
            idx = page * 10 + choice - 1
            if 0 <= idx < len(products):
                product = products[idx]
                cs.set(
                    phone,
                    cs.PRODUCT_DETAIL,
                    product_id=int(product["id"]),
                    previous_product_ids=ids,
                    previous_page=page,
                    main_category=state.get("main_category") or "",
                    subcategory=state.get("subcategory") or "",
                )
                return orders.format_product_details(product)
            return "الرقم خارج القائمة. اختر رقمًا من المنتجات المعروضة أو اكتب رجوع."
        return 'اكتب رقم المنتج للتفاصيل، أو "التالي"، أو "رجوع".'

    if current == cs.WAITING_FOR_CLARIFICATION:
        candidate_ids = state.get("candidate_ids") or []
        choice = number_choice(raw)
        if choice and 1 <= choice <= len(candidate_ids):
            product = database.get_product(int(candidate_ids[choice - 1]))
            if product and database.product_visible(product, guided=False):
                cs.set(phone, cs.PRODUCT_DETAIL, product_id=int(product["id"]), source="clarification")
                return orders.format_product_details(product)
        pending = state.get("pending_query") or ""
        merged = (pending + " " + raw).strip() if pending else raw
        result = matcher.match_text(merged)
        return handle_search_result(phone, result, original_query=merged)

    if current == cs.PRODUCT_DETAIL:
        pid = state.get("product_id")
        product = database.get_product(int(pid)) if pid else None
        if n in _normset(YES_WORDS):
            if not config_env.booking_enabled():
                return "الحجز غير متوفر حاليًا من خلال البوت.\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."
            if product:
                cs.set(phone, cs.WAITING_FOR_QUANTITY, product_id=int(product["id"]))
                return "كم الكمية؟"
        if product:
            return orders.format_product_details(product)
        return show_main_menu(phone)

    if current == cs.WAITING_FOR_QUANTITY:
        if not config_env.booking_enabled():
            return show_main_menu(phone)
        qty = number_choice(raw) or 1
        pid = state.get("product_id")
        product = database.get_product(int(pid)) if pid else None
        if not product:
            return show_main_menu(phone)
        order_id = orders.create_order(phone, product, qty)
        cs.clear(phone)
        return f"تم تسجيل طلبك. سيراجعك فريق الصيدلية.\nرقم الطلب: #{order_id}"

    result = matcher.match_text(raw)
    return handle_search_result(phone, result, original_query=raw)
