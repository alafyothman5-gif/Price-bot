# PriceBot Testing

## Import test on temporary DB

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/import_master_excel.py /opt/pricebot_clean/products_master_ready.xlsx --db-path /tmp/pricebot_import_test.sqlite --dry-run
./venv/bin/python tools/import_master_excel.py /opt/pricebot_clean/products_master_ready.xlsx --db-path /tmp/pricebot_import_test.sqlite
./venv/bin/python tools/verify_production.py --db-path /tmp/pricebot_import_test.sqlite --excel-path /opt/pricebot_clean/products_master_ready.xlsx
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_import_test.sqlite
```

## Acceptance coverage

Menu:

- `مرحبا` shows start/fallback text.
- `ابدأ` shows main menu.
- `القائمة` resets from any state.
- `رجوع` steps back or returns to menu.

Text search:

- `gaviscon` asks for a numbered choice when multiple products exist.
- Selecting a number shows product details and price without booking text.
- `Pro-D3 50,000 IU` matches despite punctuation/spacing.
- `Ovanice` can match a sellable product even if review status needs further classification.
- Generic queries like `غسول` do not return a random product.

Image search:

- A clear image is sent to OpenRouter Vision if a compatible key exists.
- If the image is unclear, the bot asks for a clearer front-facing image.
- If only generic words are visible, the bot does not guess.
- Logs include `VISION_START`, `VISION_PROVIDER`, `VISION_MODEL`, `VISION_EXTRACTED_NAME`, `VISION_CONFIDENCE`, and `VISION_MATCH_DECISION` without printing secrets.

Booking:

- Booking is disabled by default.
- Product details do not contain `booking prompt` unless `BOOKING_ENABLED=true` is explicitly set.
- Replying `نعم` does not create an order when booking is disabled.

## Local test result from this package

```text
NO_DB_IN_ZIP=OK
NO_ENV_IN_ZIP=OK
NO_PYCACHE=OK
COMPILEALL_OK=OK
IMPORT_DRY_RUN_OK=OK
IMPORT_OK products_after=5791 search_index=23747 guided_index=3518 integrity=ok
VERIFY_PRODUCTION_OK=OK
HEADER_DETECTION_ROWS_1_TO_15=OK
ACCEPTANCE_TESTS_PASS=23
BOOKING_DISABLED=OK
VISION_ENV_ALIASES=OK
```
