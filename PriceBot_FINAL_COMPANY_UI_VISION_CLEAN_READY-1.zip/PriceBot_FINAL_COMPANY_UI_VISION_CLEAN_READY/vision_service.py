import base64
import json
import os
from typing import Dict

import httpx

import config_env
from normalizer import normalize_text

GENERIC_IMAGE_WORDS = {
    # Generic dosage/package/category/marketing words.  These words are useful
    # as metadata, but they must not drive Vision matching by themselves.
    "cream", "gel", "tube", "capsule", "capsules", "cap", "caps", "tablet", "tablets", "tab", "tabs",
    "vitamin", "vitamins", "female", "male", "face", "skin", "health", "supports", "support", "care",
    "dietary", "supplement", "food", "fertility", "immune", "natural", "advanced", "formula", "softgel", "softgels",
    "lotion", "syrup", "drops", "spray", "shampoo", "conditioner", "mg", "ml", "g", "iu", "mcg",
    "كريم", "جل", "حبوب", "فيتامين", "كبسولات", "شراب", "قطره", "بخاخ", "شامبو", "صحه",
}


def _clean_visual_text(value: object) -> str:
    """Return a conservative product-identity string from Vision slots.

    Vision often returns long packaging text such as
    "Pro-D3 50,000 IU vitamin k2 15 capsules".  Passing that whole text to
    the normal matcher forces every marketing/package token to match and makes
    real products look unavailable.  Keep brand/product identity + strength and
    drop generic visual words.
    """
    n = normalize_text(value)
    if not n:
        return ""
    out = []
    prev = ""
    for tok in n.split():
        if tok in {"iu", "mg", "ml", "g", "mcg"} and prev.isdigit():
            out.append(tok)
            prev = tok
            continue
        if tok in GENERIC_IMAGE_WORDS:
            prev = tok
            continue
        # Small package counts like 15 capsules often appear on labels but are
        # not reliable identity unless paired with a strong name.  Keep larger
        # strengths such as 50000 and named tokens.
        if tok.isdigit() and len(tok) <= 2 and prev in {"capsule", "capsules", "cap", "caps", "tablet", "tablets", "tab", "tabs"}:
            prev = tok
            continue
        if len(tok) <= 1 and not tok.isdigit():
            prev = tok
            continue
        out.append(tok)
        prev = tok
    return " ".join(out).strip()


def build_query_candidates_from_slots(slots: Dict[str, str]) -> list[str]:
    """Build staged Vision queries; never include raw visible_text wholesale."""
    brand = _clean_visual_text(slots.get("brand"))
    product = _clean_visual_text(slots.get("product_name"))
    strength = _clean_visual_text(slots.get("strength"))
    size = _clean_visual_text(slots.get("size"))

    candidates = []
    def add(*parts: str):
        q = " ".join(p for p in parts if p).strip()
        if q and q not in candidates:
            candidates.append(q)

    # Stage 1: product identity with brand and strength only.
    add(brand, product, strength)
    add(product, strength)
    add(brand, product)
    add(product)
    add(brand, strength)
    add(brand)

    # Stage 2: include size only after stronger identity attempts.
    add(brand, product, strength, size)
    add(product, strength, size)

    # Stage 3: cleaned visible text is a last-resort candidate, still stripped
    # of generic words, never raw OCR/package text.
    visible = _clean_visual_text(slots.get("visible_text"))
    add(visible)
    return candidates[:10]


def _log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-flash-lite").strip() or "google/gemini-2.5-flash-lite",
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def build_query_from_slots(slots: Dict[str, str]) -> str:
    candidates = build_query_candidates_from_slots(slots)
    return candidates[0] if candidates else ""


def _is_weak_visual_query(query: str, slots: Dict[str, str]) -> bool:
    n = normalize_text(query)
    if not n:
        return True
    tokens = n.split()
    strong = [t for t in tokens if t not in GENERIC_IMAGE_WORDS and not t.isdigit() and len(t) >= 3]
    brand = normalize_text(slots.get("brand"))
    product_name = normalize_text(slots.get("product_name"))
    # A reliable image search needs either brand/product name, or at least two strong visible words.
    if brand and product_name and product_name not in GENERIC_IMAGE_WORDS:
        return False
    if len(strong) >= 2:
        return False
    return True


async def extract_product_from_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, str]:
    if not image_bytes:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    cfg = _openrouter_config()
    if not config_env.vision_enabled():
        reason = config_env.vision_disabled_reason()
        _log("VISION_DISABLED_REASON", reason=reason)
        return {"status": "IMAGE_UNCLEAR", "message": "فحص الصور غير مفعّل حاليًا. اكتب اسم المنتج كاملًا."}

    _log("VISION_START")
    _log("VISION_PROVIDER", provider="OpenRouter")
    _log("VISION_MODEL", model=cfg["model"])

    data_url = f"data:{mime_type};base64," + base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "You are reading a pharmacy product package image. Return strict JSON only with keys: "
        "brand, product_name, form, strength, size, pack, visible_text, confidence. "
        "Do not guess. If the product name is not visible, set confidence below 0.75. "
        "Ignore generic words when no brand/product name is visible."
    )
    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]}
        ],
        "temperature": 0,
        "max_tokens": 450,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                _log("VISION_ERROR", provider="openrouter", status=resp.status_code)
                return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as exc:
        _log("VISION_ERROR", provider="openrouter", status=type(exc).__name__)
        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}

    try:
        start = content.find("{")
        end = content.rfind("}")
        data = json.loads(content[start:end + 1] if start >= 0 and end > start else content)
    except Exception:
        _log("VISION_ERROR", provider="openrouter", status="bad_json")
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    try:
        confidence = float(data.get("confidence") or 0)
    except Exception:
        confidence = 0.0
    query_candidates = build_query_candidates_from_slots(data)
    query = query_candidates[0] if query_candidates else ""
    _log("VISION_EXTRACTED_NAME", value=query[:120])
    _log("VISION_CONFIDENCE", value=confidence)

    if confidence < 0.75 or _is_weak_visual_query(query, data):
        return {"status": "LOW_CONFIDENCE", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}
    data["status"] = "OK"
    data["query"] = query
    data["query_candidates"] = query_candidates
    data["confidence"] = str(confidence)
    return data
