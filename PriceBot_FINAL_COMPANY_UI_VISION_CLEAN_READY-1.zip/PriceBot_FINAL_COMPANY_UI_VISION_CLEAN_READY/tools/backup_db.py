#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import database


def main() -> int:
    p = argparse.ArgumentParser(description="Backup a selected PriceBot SQLite DB.")
    p.add_argument("--db-path", default="", help="SQLite DB path to backup.")
    p.add_argument("--label", default="manual", help="Backup label.")
    args = p.parse_args()
    if args.db_path:
        database.configure_db_path(args.db_path)
    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={database.get_db_path()}")
    backup = database.backup_db(args.label)
    print(f"BACKUP_OK {backup}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
