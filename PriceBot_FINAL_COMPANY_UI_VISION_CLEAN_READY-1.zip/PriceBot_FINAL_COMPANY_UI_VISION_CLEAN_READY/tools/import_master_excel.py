#!/usr/bin/env python3
"""Safe explicit Excel importer for PriceBot product catalog.

Rules enforced here:
- Never runs without --db-path.
- Supports the organized catalog columns requested for production.
- Does not DROP, DELETE, empty, replace, or rename the products table.
- Uses idempotent upsert by product_id, then barcode, then normalized_name.
- Hides stale old products not present in the Excel so they do not appear to customers.
- Provides --dry-run reporting before any production write.
"""
import argparse
import sqlite3
import sys
import traceback
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from normalizer import normalize_text, safe_price, truthy
from search_engine import rebuild_search_index
from guided_commerce import rebuild_guided_index

HEADER_ROW = 0
DATA_START_ROW = 0
MAX_HEADER_SCAN_ROWS = 15

# Minimum organized catalog contract requested by the owner.
REQUIRED_COLUMNS = [
    "product_id",
    "name",
    "brand",
    "product_family",
    "category",
    "main_section",
    "sub_section",
    "subcategory",
    "active_ingredient",
    "form",
    "strength",
    "size",
    "pack",
    "barcode",
    "aliases",
    "ocr_keywords",
    "use_case",
    "skin_type",
    "available",
    "price",
    "substitution_group_id",
    "review_status",
    "review_notes",
]

# Older V22 files use section/product_type instead of subcategory.  Keep this
# backward-compatible for transition, but prefer explicit subcategory whenever it exists.
OPTIONAL_COMPAT_COLUMNS = [
    "normalized_name", "company", "section", "product_type", "body_area", "age_group", "gender",
    "medicine_form", "medicine_route", "currency", "search_mode", "quality_status", "is_substitutable",
    "source_serial", "original_name",
]

IDENTITY_COLUMNS = ["product_id", "barcode", "normalized_name"]


def _cell_value(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        try:
            f = float(text)
            if f.is_integer():
                return str(int(f))
        except Exception:
            pass
    return text


def _headers_from_row(values) -> List[str]:
    return [_cell_value(v) for v in values]


def _missing_required(headers: List[str]) -> List[str]:
    present = set(headers)
    missing = [c for c in REQUIRED_COLUMNS if c not in present]
    # Compatibility for older V22 catalogs.  main_section can be derived from
    # category/section; sub_section/subcategory can be derived from section or
    # product_type when the explicit columns do not exist.
    if "main_section" in missing and ("section" in present or "category" in present):
        missing.remove("main_section")
    for col in ["sub_section", "subcategory"]:
        if col in missing and ("section" in present or "product_type" in present):
            missing.remove(col)
    return missing


def _find_header_row(ws) -> Tuple[int, List[str], List[List[str]]]:
    preview: List[List[str]] = []
    best = (0, [], REQUIRED_COLUMNS[:])
    max_col = ws.max_column
    max_scan = min(MAX_HEADER_SCAN_ROWS, ws.max_row)
    for row_num in range(1, max_scan + 1):
        values = next(ws.iter_rows(min_row=row_num, max_row=row_num, max_col=max_col, values_only=True))
        headers = _headers_from_row(values)
        preview.append(headers[:40])
        missing = _missing_required(headers)
        if not missing:
            return row_num, headers, preview
        if len(missing) < len(best[2]):
            best = (row_num, headers, missing)
    found_columns = [h for h in best[1] if h]
    msg = [
        "MISSING_REQUIRED_COLUMNS",
        f"BEST_HEADER_ROW={best[0]}",
        f"MISSING={best[2]}",
        f"FOUND_COLUMNS={found_columns}",
        f"FIRST_10_ROWS_PREVIEW={preview[:10]}",
    ]
    raise RuntimeError("\n".join(msg))

def _canonical_available(value: str) -> str:
    return "true" if truthy(value) else "false"



def _first_match(hay: str, rules):
    for value, words in rules:
        if any(normalize_text(w) and normalize_text(w) in hay for w in words):
            return value
    return ""


def _infer_clear_catalog_fields(row: Dict[str, str]) -> Dict[str, str]:
    """Infer safe catalog fields for obvious sellable products.

    This does not invent medical advice.  It only fixes clear commercial
    grouping/form metadata so exact search and guided browsing do not hide
    obvious products such as Pro-D3 and Ovanice just because manual review_status
    was not fully approved yet.
    """
    hay = normalize_text(" ".join(str(row.get(c) or "") for c in [
        "name", "brand", "product_family", "category", "main_section", "sub_section", "subcategory",
        "form", "active_ingredient", "use_case", "ocr_keywords", "aliases", "review_notes"
    ]))

    unknown_main = normalize_text(row.get("main_section")) in {"", "unknown", "غير معروف", "غير مصنف", "unclassified"}
    unknown_cat = normalize_text(row.get("category")) in {"", "unknown", "غير معروف", "غير مصنف", "unclassified"}
    unknown_sub = normalize_text(row.get("sub_section") or row.get("subcategory")) in {"", "unknown", "غير معروف", "غير مصنف", "unclassified"}

    # Form inference from explicit dosage/package words only.
    if not str(row.get("form") or "").strip():
        form = _first_match(hay, [
            ("capsule", ["capsule", "capsules", "caps", "cap"]),
            ("tablet", ["tablet", "tablets", "tab", "tabs"]),
            ("syrup", ["syrup", "syr"]),
            ("drops", ["drops", "drop"]),
            ("sachet", ["sachet", "sachets"]),
            ("powder", ["powder"]),
            ("cream", ["cream"]),
            ("ointment", ["ointment"]),
            ("gel", ["gel"]),
            ("injection", ["injection", "inj"]),
            ("suppository", ["suppository", "supp", "suppositories"]),
            ("spray", ["spray"]),
            ("solution", ["solution"]),
            ("shampoo", ["shampoo"]),
        ])
        if form:
            row["form"] = form
            if not row.get("product_type"):
                row["product_type"] = form

    if not str(row.get("pack") or "").strip():
        import re
        raw_name = str(row.get("name") or row.get("original_name") or "")
        m = re.search(r"\b(\d+)\s*(caps|cap|capsules|tablets|tabs|tab|sachets|sachet)\b", raw_name, flags=re.I)
        if m:
            unit = m.group(2).lower()
            if unit.startswith("cap"):
                unit = "caps"
            elif unit.startswith("tab"):
                unit = "tabs"
            row["pack"] = f"{m.group(1)} {unit}"

    # Supplements and vitamins: clear commercial categories, not treatment advice.
    supplement_sub = ""
    if any(x in hay for x in ["prod3", " d3 ", "vitamin d", "50000 iu", "800 iu", " k2 "]):
        supplement_sub = "فيتامين D"
    elif any(x in hay for x in ["ovanice", "fertility", "pregnancy", "prenatal", "pregna"]):
        supplement_sub = "مكملات الحمل"
    elif any(x in hay for x in ["omega", "اوميغا"]):
        supplement_sub = "omega"
    elif any(x in hay for x in ["iron", "ferro", "ferr", "حديد"]):
        supplement_sub = "حديد"
    elif any(x in hay for x in ["calcium", "كالسيوم"]):
        supplement_sub = "كالسيوم"
    elif any(x in hay for x in ["magnesium", "مغنيسيوم"]):
        supplement_sub = "مغنيسيوم"
    elif any(x in hay for x in ["zinc", "زنك"]):
        supplement_sub = "زنك"
    elif any(x in hay for x in ["vitamin c", "ascorbic", "فيتامين سي"]):
        supplement_sub = "فيتامين C"
    elif any(x in hay for x in ["multivitamin", "multi vitamin"]):
        supplement_sub = "Multivitamin"
    elif any(x in hay for x in ["vitamin", "supplement", "probiotic", "capsule", "capsules", "caps"]):
        # Capsule alone is not enough for a medicine/cosmetic decision, but it is
        # safe only when the row is already not a clear medicine and has no better section.
        if unknown_main or normalize_text(row.get("category")) in {"supplement", "unknown", ""}:
            supplement_sub = "supplement_unspecified"

    if supplement_sub:
        if unknown_cat or normalize_text(row.get("category")) in {"medicine", "unknown"} and any(x in hay for x in ["prod3", "ovanice", "vitamin", "supplement", "fertility"]):
            row["category"] = "supplement"
        if unknown_main or normalize_text(row.get("main_section")) in {"ادويه", "أدوية", "غير مصنف", "unknown"} and any(x in hay for x in ["prod3", "ovanice", "vitamin", "supplement", "fertility"]):
            row["main_section"] = "مكملات وفيتامينات"
        if unknown_sub or normalize_text(row.get("sub_section") or row.get("subcategory")) in {"ادويه", "أدوية", "غير مصنف", "unknown"}:
            row["sub_section"] = supplement_sub
            row["subcategory"] = supplement_sub
        if not row.get("use_case") and supplement_sub == "مكملات الحمل":
            row["use_case"] = "fertility / pregnancy supplement"

    # Make exact search sellable even when manual review is incomplete, as long
    # as the row has price/availability/name and is not unknown/hidden.
    if normalize_text(row.get("review_status")) in {"needs_review", "review", "ok", "ready", "approved", ""}:
        if row.get("price") and row.get("available") == "true" and row.get("name"):
            # Keep review_status unchanged if it is meaningful; search visibility
            # is controlled by search_mode and database.product_visible().
            if normalize_text(row.get("review_status")) in {"", "ok", "ready"}:
                row["review_status"] = row.get("review_status") or "ok"
            if normalize_text(row.get("search_mode")) in {"", "needs_review", "review_only", "unknown"}:
                row["search_mode"] = "searchable"
    return row

def _normalize_row(item: Dict[str, str], row_number: int) -> Dict[str, str]:
    name = item.get("name") or item.get("original_name") or ""
    normalized_name = item.get("normalized_name") or normalize_text(name)
    main_section = item.get("main_section") or item.get("section") or item.get("category") or ""
    sub_section = item.get("sub_section") or item.get("subcategory") or item.get("section") or item.get("product_type") or ""
    subcategory = item.get("subcategory") or sub_section
    product_id = item.get("product_id") or f"AUTO-{row_number}"
    row: Dict[str, str] = {c: item.get(c, "") for c in database.PRODUCT_COLUMNS}
    row.update({
        "product_id": product_id,
        "name": name,
        "normalized_name": normalized_name,
        "main_section": main_section,
        "sub_section": sub_section,
        "subcategory": subcategory,
        "currency": item.get("currency") or "LYD",
        "price": safe_price(item.get("price")),
        "available": _canonical_available(item.get("available")),
        "original_name": item.get("original_name") or name,
    })
    # Keep old section aligned for any legacy UI, but main_section/sub_section/category/subcategory are source-of-truth.
    if not row.get("section"):
        row["section"] = main_section or subcategory
    if not row.get("product_type"):
        row["product_type"] = item.get("form") or subcategory
    if not row.get("quality_status"):
        row["quality_status"] = "ready"
    if not row.get("search_mode"):
        row["search_mode"] = "searchable"
    row = _infer_clear_catalog_fields(row)
    return row


def read_excel_rows(path: Path) -> Tuple[List[str], List[Dict[str, str]], Dict[str, object]]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    max_row = ws.max_row
    max_col = ws.max_column
    header_row, headers, preview = _find_header_row(ws)
    data_start_row = header_row + 1

    rows: List[Dict[str, str]] = []
    rejected: List[Dict[str, str]] = []
    missing_data: List[Dict[str, str]] = []
    seen_product_ids = set()
    seen_barcodes = set()
    duplicate_product_ids = []
    duplicate_barcodes = []

    for excel_row_num, row_values in enumerate(ws.iter_rows(min_row=data_start_row, max_row=max_row, max_col=max_col, values_only=True), start=data_start_row):
        raw: Dict[str, str] = {}
        empty = True
        for header, value in zip(headers, row_values):
            if not header:
                continue
            val = _cell_value(value)
            if val:
                empty = False
            raw[header] = val
        if empty:
            continue

        name = raw.get("name") or raw.get("original_name") or ""
        if not name:
            rejected.append({"row": str(excel_row_num), "reason": "missing_name"})
            continue

        row = _normalize_row(raw, excel_row_num)
        pid = row.get("product_id", "").strip()
        barcode = row.get("barcode", "").strip()
        if pid and pid in seen_product_ids:
            duplicate_product_ids.append(pid)
            rejected.append({"row": str(excel_row_num), "reason": f"duplicate_product_id:{pid}"})
            continue
        if barcode and barcode in seen_barcodes:
            duplicate_barcodes.append(barcode)
            rejected.append({"row": str(excel_row_num), "reason": f"duplicate_barcode:{barcode}"})
            continue
        if pid:
            seen_product_ids.add(pid)
        if barcode:
            seen_barcodes.add(barcode)

        missing_fields = [c for c in ["category", "subcategory", "available", "price"] if not str(row.get(c) or "").strip()]
        if missing_fields:
            missing_data.append({"row": str(excel_row_num), "product_id": pid, "name": name, "missing": ",".join(missing_fields)})
        rows.append(row)
    wb.close()
    report = {
        "excel_max_row": max_row,
        "excel_max_col": max_col,
        "header_row": header_row,
        "data_start_row": data_start_row,
        "first_10_rows_preview": preview[:10],
        "rejected": rejected,
        "missing_data": missing_data,
        "duplicate_product_ids": duplicate_product_ids,
        "duplicate_barcodes": duplicate_barcodes,
    }
    return headers, rows, report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Safe upsert import for organized PriceBot product Excel.")
    parser.add_argument("excel_path", help="Path to products_master_ready.xlsx or products_master_v22_ready.xlsx")
    parser.add_argument("--db-path", required=True, help="Required explicit SQLite DB path. Example: /opt/pricebot/pricebot.db")
    parser.add_argument("--dry-run", action="store_true", help="Print the import plan and do not write to the DB.")
    return parser.parse_args()


def _abort_if_project_db(db_path: Path) -> None:
    project_root = Path(__file__).resolve().parents[1]
    if db_path.resolve() == (project_root / "pricebot.db").resolve():
        raise RuntimeError("REFUSING_PROJECT_LOCAL_DB: pass an external --db-path, never project/pricebot.db")


def _existing_product_maps(conn: sqlite3.Connection):
    maps = {"product_id": {}, "barcode": {}, "normalized_name": {}}
    if not database.table_exists(conn, "products"):
        return maps, []
    rows = conn.execute("SELECT id, product_id, barcode, normalized_name, name FROM products").fetchall()
    for r in rows:
        db_id = int(r[0])
        pid = str(r[1] or "").strip()
        barcode = str(r[2] or "").strip()
        norm = normalize_text(r[3] or r[4] or "")
        if pid and pid not in maps["product_id"]:
            maps["product_id"][pid] = db_id
        if barcode and barcode not in maps["barcode"]:
            maps["barcode"][barcode] = db_id
        if norm and norm not in maps["normalized_name"]:
            maps["normalized_name"][norm] = db_id
    return maps, rows


def _match_existing(row: Dict[str, str], maps) -> Tuple[int, str]:
    pid = str(row.get("product_id") or "").strip()
    barcode = str(row.get("barcode") or "").strip()
    norm = normalize_text(row.get("normalized_name") or row.get("name"))
    # Product_id is authoritative. If the Excel row has a product_id and it is
    # not in the DB, create a new product instead of merging unrelated rows that
    # happen to share a normalized display name. Barcode may still match an old
    # product whose product_id was previously missing or changed.
    if pid:
        if pid in maps["product_id"]:
            return maps["product_id"][pid], "product_id"
        if barcode and barcode in maps["barcode"]:
            return maps["barcode"][barcode], "barcode"
        return 0, "new"
    if barcode:
        if barcode in maps["barcode"]:
            return maps["barcode"][barcode], "barcode"
        return 0, "new"
    if norm and norm in maps["normalized_name"]:
        return maps["normalized_name"][norm], "normalized_name"
    return 0, "new"


def build_plan(rows: List[Dict[str, str]], rejected_count: int) -> Dict[str, int]:
    with database.connect() as conn:
        maps, old_rows = _existing_product_maps(conn)
        old_count = len(old_rows)
        matched_by = Counter()
        matched_ids = set()
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            if db_id:
                matched_by[kind] += 1
                matched_ids.add(db_id)
            else:
                matched_by["new"] += 1
        stale_old = max(0, old_count - len(matched_ids))
    return {
        "old_products_count": old_count,
        "excel_products_count": len(rows),
        "matched_by_product_id": matched_by["product_id"],
        "matched_by_barcode": matched_by["barcode"],
        "matched_by_normalized_name": matched_by["normalized_name"],
        "new_products": matched_by["new"],
        "stale_old_products": stale_old,
        "rejected_products": rejected_count,
        "products_after_expected_minimum": old_count + matched_by["new"],
        "visible_excel_products_expected": len(rows),
    }


def print_plan(plan: Dict[str, int], meta: Dict[str, object]) -> None:
    print("IMPORT_DRY_RUN_OR_PLAN")
    for key in [
        "old_products_count", "excel_products_count", "matched_by_product_id", "matched_by_barcode",
        "matched_by_normalized_name", "new_products", "stale_old_products", "rejected_products",
        "products_after_expected_minimum", "visible_excel_products_expected",
    ]:
        print(f"{key}={plan.get(key, 0)}")
    print(f"missing_data_products={len(meta.get('missing_data') or [])}")
    print(f"duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])}")
    print(f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])}")


def _update_product(conn: sqlite3.Connection, db_id: int, row: Dict[str, str]) -> None:
    cols = list(database.PRODUCT_COLUMNS)
    assignments = ", ".join(f'"{c}"=?' for c in cols) + ', "updated_at"=datetime(\'now\')'
    params = [row.get(c, "") for c in cols] + [int(db_id)]
    conn.execute(f'UPDATE products SET {assignments} WHERE id=?', params)


def _insert_product(conn: sqlite3.Connection, row: Dict[str, str]) -> int:
    cols = list(database.PRODUCT_COLUMNS)
    insert_cols = cols + ["created_at", "updated_at"]
    placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
    sql = f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})'
    cur = conn.execute(sql, [row.get(c, "") for c in cols])
    return int(cur.lastrowid)


def safe_upsert_import(rows: List[Dict[str, str]], plan: Dict[str, int]) -> Dict[str, int]:
    database.init_db(run_production_guard=False)
    stats = Counter()
    excel_db_ids = set()
    with database.connect() as conn:
        maps, _old_rows = _existing_product_maps(conn)
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            if db_id:
                _update_product(conn, db_id, row)
                stats["updated"] += 1
            else:
                db_id = _insert_product(conn, row)
                stats["added"] += 1
                # Make following duplicate-free rows in same import able to match if needed.
                pid = str(row.get("product_id") or "").strip()
                barcode = str(row.get("barcode") or "").strip()
                norm = normalize_text(row.get("normalized_name") or row.get("name"))
                if pid:
                    maps["product_id"][pid] = db_id
                if barcode:
                    maps["barcode"][barcode] = db_id
                if norm:
                    maps["normalized_name"][norm] = db_id
            excel_db_ids.add(int(db_id))

        # Hide old products not present in the Excel source; do not delete them.
        if excel_db_ids:
            placeholders = ",".join("?" for _ in excel_db_ids)
            cur = conn.execute(
                f"""
                UPDATE products
                SET available='false', search_mode='hidden', review_status='stale_hidden', updated_at=datetime('now')
                WHERE id NOT IN ({placeholders})
                """,
                tuple(excel_db_ids),
            )
            stats["stale_hidden"] = int(cur.rowcount or 0)
        else:
            raise RuntimeError("REFUSING_TO_HIDE_ALL_PRODUCTS: Excel produced zero accepted rows")
    return dict(stats)


def write_report_file(db_path: Path, excel: Path, plan: Dict[str, int], meta: Dict[str, object], stats: Dict[str, int], search_count: int, guided_count: int, integrity: str, products_after: int) -> Path:
    report_path = db_path.parent / f"import_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    lines = [
        "PRICEBOT_IMPORT_REPORT",
        f"db_path={db_path}",
        f"excel_path={excel}",
        f"products_before={plan.get('old_products_count', 0)}",
        f"products_after={products_after}",
        f"products_added={stats.get('added', 0)}",
        f"products_updated={stats.get('updated', 0)}",
        f"products_rejected={plan.get('rejected_products', 0)}",
        f"stale_old_products_hidden={stats.get('stale_hidden', 0)}",
        f"missing_data_products={len(meta.get('missing_data') or [])}",
        f"duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])}",
        f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])}",
        f"search_index={search_count}",
        f"guided_index={guided_count}",
        f"integrity={integrity}",
    ]
    if meta.get("missing_data"):
        lines.append("MISSING_DATA_SAMPLE=" + repr((meta.get("missing_data") or [])[:20]))
    if meta.get("rejected"):
        lines.append("REJECTED_SAMPLE=" + repr((meta.get("rejected") or [])[:20]))
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report_path


def main() -> int:
    args = parse_args()
    excel = Path(args.excel_path).expanduser().resolve()
    if not excel.exists():
        print(f"EXCEL_NOT_FOUND {excel}")
        return 2
    database.configure_db_path(args.db_path)
    db_path = database.get_db_path()
    try:
        _abort_if_project_db(db_path)
    except Exception as exc:
        print(f"IMPORT_REFUSED {type(exc).__name__}: {exc}")
        return 2

    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={db_path}")
    print(f"EXCEL_PATH={excel}")
    print(f"DRY_RUN={1 if args.dry_run else 0}")

    backup = None
    try:
        headers, rows, meta = read_excel_rows(excel)
        print(f"EXCEL_HEADER_ROW={meta.get('header_row')} DATA_START_ROW={meta.get('data_start_row')} excel_max_row={meta['excel_max_row']} rows_accepted={len(rows)} columns={len([h for h in headers if h])}")
        database.init_db(run_production_guard=False)
        before_integrity = database.integrity_check()
        before_count = database.count_products()
        print(f"BEFORE integrity={before_integrity} products={before_count}")
        if str(before_integrity).lower() not in {"ok", "missing"}:
            print("IMPORT_ABORTED: DB integrity is not ok before import")
            return 1
        plan = build_plan(rows, len(meta.get("rejected") or []))
        print_plan(plan, meta)
        if args.dry_run:
            print("DRY_RUN_OK no_write_performed=1")
            return 0
        if not rows:
            raise RuntimeError("NO_ACCEPTED_PRODUCTS_IN_EXCEL")
        if db_path.exists() and str(before_integrity).lower() == "ok":
            backup = database.backup_db("before_catalog_upsert_import")
            print(f"BACKUP_OK {backup}")
        stats = safe_upsert_import(rows, plan)
        search_count = rebuild_search_index()
        guided_count = rebuild_guided_index()
        after_integrity = database.integrity_check()
        after_count = database.count_products()
        if str(after_integrity).lower() != "ok":
            raise RuntimeError(f"POST_IMPORT_INTEGRITY_FAILED: {after_integrity}")
        report = write_report_file(db_path, excel, plan, meta, stats, search_count, guided_count, after_integrity, after_count)
        print(
            "IMPORT_MASTER_EXCEL_OK "
            f"mode=SAFE_UPSERT_NO_DELETE products_before={before_count} products_after={after_count} "
            f"added={stats.get('added',0)} updated={stats.get('updated',0)} rejected={plan['rejected_products']} "
            f"missing_data={len(meta.get('missing_data') or [])} duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])} "
            f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])} stale_hidden={stats.get('stale_hidden',0)} "
            f"search_index={search_count} guided_index={guided_count} integrity={after_integrity} report={report}"
        )
        return 0
    except Exception as exc:
        print("IMPORT_MASTER_EXCEL_FAILED")
        print(f"ERROR={type(exc).__name__}: {exc}")
        traceback.print_exc()
        if backup:
            try:
                database.restore_db_from_backup(backup)
                print(f"DB_RESTORE_OK from={backup}")
            except Exception as restore_exc:
                print(f"DB_RESTORE_FAILED {type(restore_exc).__name__}: {restore_exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
