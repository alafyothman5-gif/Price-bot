#!/usr/bin/env python3
import argparse
import os
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db-path", required=True)
    args = parser.parse_args()
    database.configure_db_path(args.db_path)
    os.environ["PRICEBOT_DB_PATH"] = args.db_path
    runpy.run_path(str(ROOT / "tests" / "acceptance_ui_flow.py"), run_name="__main__")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
