CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL DEFAULT '', "merchant_id" TEXT DEFAULT '', "product_id" TEXT DEFAULT '', "identity_key" TEXT DEFAULT '', "normalized_name" TEXT DEFAULT '', "brand" TEXT DEFAULT '', "company" TEXT DEFAULT '', "category" TEXT DEFAULT '', "main_section" TEXT DEFAULT '', "sub_section" TEXT DEFAULT '', "subcategory" TEXT DEFAULT '', "section" TEXT DEFAULT '', "product_family" TEXT DEFAULT '', "form" TEXT DEFAULT '', "product_type" TEXT DEFAULT '', "active_ingredient" TEXT DEFAULT '', "strength" TEXT DEFAULT '', "size" TEXT DEFAULT '', "pack" TEXT DEFAULT '', "barcode" TEXT DEFAULT '', "aliases" TEXT DEFAULT '', "ocr_keywords" TEXT DEFAULT '', "use_case" TEXT DEFAULT '', "skin_type" TEXT DEFAULT '', "body_area" TEXT DEFAULT '', "age_group" TEXT DEFAULT '', "gender" TEXT DEFAULT '', "medicine_form" TEXT DEFAULT '', "medicine_route" TEXT DEFAULT '', "available" TEXT DEFAULT '', "price" TEXT DEFAULT '', "currency" TEXT DEFAULT '', "search_mode" TEXT DEFAULT '', "quality_status" TEXT DEFAULT '', "is_substitutable" TEXT DEFAULT '', "substitution_group_id" TEXT DEFAULT '', "review_status" TEXT DEFAULT '', "review_notes" TEXT DEFAULT '', "source_serial" TEXT DEFAULT '', "original_name" TEXT DEFAULT '', "created_at" TEXT, "updated_at" TEXT, "canonical_display_name" TEXT DEFAULT '', last_seen_at TEXT, normalized_name_catalog TEXT DEFAULT '', "is_available" INTEGER DEFAULT 1, "last_seen_in_upload" TEXT, "needs_review" INTEGER DEFAULT 0, "stable_product_code" TEXT DEFAULT '', "barcode_verified" INTEGER DEFAULT 0, catalog_image_url TEXT);
CREATE TABLE sqlite_sequence(name,seq);
CREATE INDEX idx_products_name ON products(name);
CREATE INDEX idx_products_norm ON products(normalized_name);
CREATE INDEX idx_products_product_id ON products(product_id);
CREATE INDEX idx_products_barcode ON products(barcode);
CREATE INDEX idx_products_merchant ON products(merchant_id, available);
CREATE TABLE product_search_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL,
                kind TEXT NOT NULL,
                product_db_id INTEGER NOT NULL,
                weight INTEGER DEFAULT 0,
                UNIQUE(key, kind, product_db_id)
            );
CREATE INDEX idx_search_index_key ON product_search_index(key);
CREATE TABLE guided_catalog_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                main_section TEXT NOT NULL,
                sub_section TEXT DEFAULT '',
                product_type TEXT DEFAULT '',
                use_case TEXT DEFAULT '',
                skin_type TEXT DEFAULT '',
                body_area TEXT DEFAULT '',
                age_group TEXT DEFAULT '',
                visible INTEGER DEFAULT 1,
                sort_name TEXT DEFAULT '',
                UNIQUE(product_db_id, main_section, sub_section, skin_type)
            );
CREATE INDEX idx_guided_main ON guided_catalog_index(main_section, sub_section, visible);
CREATE TABLE conversation_state (
                phone TEXT PRIMARY KEY,
                state_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            );
CREATE TABLE orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT NOT NULL,
                product_db_id INTEGER,
                product_name TEXT DEFAULT '',
                quantity INTEGER DEFAULT 1,
                price TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "merchant_id" INTEGER DEFAULT 1, "customer_name" TEXT DEFAULT '', "notes" TEXT DEFAULT '');
CREATE INDEX idx_orders_merchant_status ON orders(merchant_id, status, created_at);
CREATE TABLE processed_messages (
                message_id TEXT PRIMARY KEY,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE dynamic_synonyms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                target TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(source, target)
            );
CREATE INDEX idx_dynamic_synonyms_source ON dynamic_synonyms(source, enabled);
CREATE TABLE image_product_cache (
                image_hash TEXT PRIMARY KEY,
                media_id TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                confidence TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "image_phash" TEXT DEFAULT '');
CREATE INDEX idx_image_cache_media ON image_product_cache(media_id);
CREATE TABLE product_identity_registry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                product_id TEXT DEFAULT '',
                identity_key TEXT NOT NULL,
                canonical_name TEXT DEFAULT '',
                normalized_name TEXT DEFAULT '',
                compact_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                aliases TEXT DEFAULT '',
                ocr_keywords TEXT DEFAULT '',
                category TEXT DEFAULT '',
                search_policy TEXT DEFAULT 'sellable_exact',
                duplicate_group TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id)
            );
CREATE INDEX idx_identity_norm ON product_identity_registry(normalized_name);
CREATE INDEX idx_identity_compact ON product_identity_registry(compact_name);
CREATE INDEX idx_identity_barcode ON product_identity_registry(barcode);
CREATE INDEX idx_identity_brand_family ON product_identity_registry(brand, product_family);
CREATE INDEX idx_identity_key ON product_identity_registry(identity_key);
CREATE TABLE learning_inbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_query TEXT DEFAULT '',
                vision_text TEXT DEFAULT '',
                candidate_products TEXT DEFAULT '[]',
                decision TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                admin_action TEXT DEFAULT '',
                selected_product_id INTEGER,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "image_id" TEXT DEFAULT '', "media_id" TEXT DEFAULT '', "raw_vision_text" TEXT DEFAULT '', "main_visible_product" TEXT DEFAULT '', "background_text" TEXT DEFAULT '', "query_slots" TEXT DEFAULT '{}', "rejected_candidates" TEXT DEFAULT '[]', "created_by" TEXT DEFAULT '', "merchant_id" INTEGER DEFAULT 1);
CREATE INDEX idx_learning_inbox_status ON learning_inbox(status, created_at);
CREATE TABLE admin_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                actor TEXT DEFAULT '',
                ip TEXT DEFAULT '',
                details TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE INDEX idx_admin_audit_event ON admin_audit_log(event, created_at);
CREATE TABLE admin_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                role TEXT DEFAULT 'owner',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "merchant_id" INTEGER DEFAULT 1, "password_salt" TEXT DEFAULT '', "password_hash" TEXT DEFAULT '', "display_name" TEXT DEFAULT '');
CREATE TABLE admin_roles (
                role TEXT PRIMARY KEY,
                permissions TEXT DEFAULT '[]',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE admin_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_hash TEXT UNIQUE NOT NULL,
                username TEXT DEFAULT 'owner',
                role TEXT DEFAULT 'owner',
                ip TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            );
CREATE TABLE merchants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL DEFAULT '',
                slug TEXT UNIQUE DEFAULT '',
                whatsapp_number TEXT DEFAULT '',
                phone_number_id TEXT DEFAULT '',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE merchant_settings (
                merchant_id INTEGER PRIMARY KEY,
                pharmacy_name TEXT DEFAULT '',
                whatsapp_number TEXT DEFAULT '',
                qr_message TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "working_hours" TEXT DEFAULT '24 ساعة', "delivery_enabled" INTEGER DEFAULT 0, "currency" TEXT DEFAULT 'LYD', "welcome_text" TEXT DEFAULT '');
CREATE TABLE catalog_review_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                merchant_id INTEGER DEFAULT 1,
                issue_type TEXT DEFAULT '',
                severity TEXT DEFAULT 'review',
                row_json TEXT DEFAULT '{}',
                duplicate_key TEXT DEFAULT '',
                price_old TEXT DEFAULT '',
                price_new TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "staging_item_id" INTEGER, "matched_product_db_id" INTEGER, "raw_name" TEXT DEFAULT '', "normalized_name" TEXT DEFAULT '', "suggested_brand" TEXT DEFAULT '', "suggested_family" TEXT DEFAULT '', "suggested_category" TEXT DEFAULT '', "suggested_form" TEXT DEFAULT '', "suggested_strength" TEXT DEFAULT '', "suggested_size" TEXT DEFAULT '', "suggested_pack" TEXT DEFAULT '', "suggested_aliases" TEXT DEFAULT '', "review_notes" TEXT DEFAULT '', "reviewed_by" TEXT DEFAULT '', "reviewed_at" TEXT, price TEXT DEFAULT '', resolved_product_id INTEGER, notes TEXT DEFAULT '');
CREATE INDEX idx_catalog_review_job ON catalog_review_items(job_id, status, issue_type);
CREATE TABLE catalog_import_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT DEFAULT '',
                staging_db_path TEXT DEFAULT '',
                status TEXT DEFAULT 'uploaded',
                added INTEGER DEFAULT 0,
                updated INTEGER DEFAULT 0,
                duplicate_conflicts INTEGER DEFAULT 0,
                needs_review INTEGER DEFAULT 0,
                unclassified INTEGER DEFAULT 0,
                missing_form_strength_size INTEGER DEFAULT 0,
                report_text TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "job_type" TEXT DEFAULT '', "started_at" TEXT, "finished_at" TEXT, "error_text" TEXT DEFAULT '', "merchant_id" INTEGER DEFAULT 1, "requires_approval" INTEGER DEFAULT 1, "verified" INTEGER DEFAULT 0, "acceptance_passed" INTEGER DEFAULT 0, "approval_user" TEXT DEFAULT '', "approved_at" TEXT);
CREATE INDEX idx_catalog_import_status ON catalog_import_jobs(status, created_at);
CREATE TABLE catalog_import_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                report_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE image_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                image_hash TEXT UNIQUE,
                media_id TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                confidence TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , "image_phash" TEXT DEFAULT '');
CREATE INDEX idx_admin_sessions_hash ON admin_sessions(session_hash);
CREATE TABLE product_query_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                merchant_id INTEGER DEFAULT 1,
                customer_hash TEXT DEFAULT '',
                original_text TEXT DEFAULT '',
                cleaned_text TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matcher_decision TEXT DEFAULT '',
                matched_product_id INTEGER,
                matched_product_name TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                diagnostics_json TEXT DEFAULT '{}',
                response_ms INTEGER DEFAULT 0,
                status TEXT DEFAULT 'open'
            );
CREATE INDEX idx_product_query_log_decision ON product_query_log(matcher_decision, created_at);
CREATE INDEX idx_product_query_log_status ON product_query_log(status, created_at);
CREATE TABLE image_debug_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                merchant_id INTEGER DEFAULT 1,
                customer_hash TEXT DEFAULT '',
                media_id TEXT DEFAULT '',
                image_hash TEXT DEFAULT '',
                image_phash TEXT DEFAULT '',
                vision_provider TEXT DEFAULT '',
                raw_vision_response TEXT DEFAULT '',
                visible_text TEXT DEFAULT '',
                cleaned_ocr TEXT DEFAULT '',
                candidate_queries TEXT DEFAULT '[]',
                selected_candidate TEXT DEFAULT '',
                matcher_decision TEXT DEFAULT '',
                matched_product_id INTEGER,
                matched_product_name TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                status TEXT DEFAULT 'open'
            );
CREATE INDEX idx_image_debug_log_decision ON image_debug_log(matcher_decision, created_at);
CREATE INDEX idx_image_debug_log_status ON image_debug_log(status, created_at);
CREATE TABLE response_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                merchant_id INTEGER DEFAULT 1,
                channel TEXT DEFAULT 'whatsapp',
                message_type TEXT DEFAULT 'text',
                decision TEXT DEFAULT '',
                response_ms INTEGER DEFAULT 0,
                vision_call INTEGER DEFAULT 0,
                product_db_id INTEGER
            );
CREATE INDEX idx_response_metrics_created ON response_metrics(created_at);
CREATE TABLE product_aliases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                alias TEXT NOT NULL,
                normalized_alias TEXT NOT NULL,
                source TEXT DEFAULT 'manual',
                approved INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP, product_id INTEGER, alias_normalized TEXT, is_active INTEGER DEFAULT 1, updated_at TEXT, "alias_text" TEXT, "cleaned_alias" TEXT, "confidence" REAL DEFAULT 0.95, "active" INTEGER DEFAULT 1, strength TEXT, volume_size TEXT, form TEXT,
                UNIQUE(product_db_id, normalized_alias)
            );
CREATE INDEX idx_product_aliases_norm ON product_aliases(normalized_alias, approved);
CREATE TABLE product_ocr_keywords (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                keyword TEXT NOT NULL,
                normalized_keyword TEXT NOT NULL,
                source TEXT DEFAULT 'manual',
                approved INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id, normalized_keyword)
            );
CREATE INDEX idx_product_ocr_norm ON product_ocr_keywords(normalized_keyword, approved);
CREATE TABLE merchant_inventory (
                merchant_id INTEGER NOT NULL DEFAULT 1,
                product_db_id INTEGER NOT NULL,
                price TEXT DEFAULT '',
                available INTEGER DEFAULT 1,
                missing_from_upload INTEGER DEFAULT 0,
                last_upload_job_id INTEGER,
                last_seen_at TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(merchant_id, product_db_id)
            );
CREATE INDEX idx_merchant_inventory_avail ON merchant_inventory(merchant_id, available, missing_from_upload);
CREATE TABLE catalog_upload_jobs (
                id INTEGER PRIMARY KEY,
                legacy_job_id INTEGER,
                merchant_id INTEGER DEFAULT 1,
                filename TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                status TEXT DEFAULT 'uploaded',
                detected_name_column TEXT DEFAULT '',
                detected_price_column TEXT DEFAULT '',
                rows_raw INTEGER DEFAULT 0,
                rows_staged INTEGER DEFAULT 0,
                updated_prices INTEGER DEFAULT 0,
                prices_unchanged INTEGER DEFAULT 0,
                new_products INTEGER DEFAULT 0,
                duplicates_merged INTEGER DEFAULT 0,
                duplicate_price_last_value_used INTEGER DEFAULT 0,
                need_review INTEGER DEFAULT 0,
                missing_report_only INTEGER DEFAULT 0,
                missing_marked_unavailable INTEGER DEFAULT 0,
                price_conflicts INTEGER DEFAULT 0,
                dangerous_rejected INTEGER DEFAULT 0,
                report_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                approved_at TEXT,
                approved_by TEXT DEFAULT ''
            , rows_total INTEGER DEFAULT 0, safe_updates_count INTEGER DEFAULT 0, unchanged_count INTEGER DEFAULT 0, review_count INTEGER DEFAULT 0, new_count INTEGER DEFAULT 0, invalid_count INTEGER DEFAULT 0, duplicate_count INTEGER DEFAULT 0, error_text TEXT DEFAULT '', backup_path TEXT DEFAULT '', started_at TEXT, finished_at TEXT);
CREATE INDEX idx_catalog_upload_jobs_status ON catalog_upload_jobs(status, created_at);
CREATE TABLE catalog_staging_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER NOT NULL,
                merchant_id INTEGER DEFAULT 1,
                row_number INTEGER DEFAULT 0,
                raw_name TEXT DEFAULT '',
                raw_price TEXT DEFAULT '',
                raw_barcode TEXT DEFAULT '',
                raw_json TEXT DEFAULT '{}',
                normalized_name TEXT DEFAULT '',
                compact_name TEXT DEFAULT '',
                spelling_corrected_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                category TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                identity_key TEXT DEFAULT '',
                matched_product_db_id INTEGER,
                matched_by TEXT DEFAULT '',
                decision TEXT DEFAULT '',
                decision_reason TEXT DEFAULT '',
                duplicate_of_staging_id INTEGER,
                status TEXT DEFAULT 'staged',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            , parsed_price TEXT DEFAULT '', matched_product_id INTEGER, reason TEXT DEFAULT '', old_price TEXT DEFAULT '', new_price TEXT DEFAULT '', is_safe_to_apply INTEGER DEFAULT 0, duplicate_winner_row INTEGER);
CREATE INDEX idx_catalog_staging_job ON catalog_staging_items(job_id, decision, status);
CREATE INDEX idx_catalog_staging_identity ON catalog_staging_items(identity_key, normalized_name);
CREATE INDEX idx_catalog_review_pending ON catalog_review_items(job_id, status, severity);
CREATE TABLE product_merge_map (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_product_db_id INTEGER,
                target_product_db_id INTEGER,
                staging_item_id INTEGER,
                job_id INTEGER,
                reason TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(source_product_db_id, target_product_db_id, job_id)
            );
CREATE TABLE catalog_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                event TEXT NOT NULL,
                actor TEXT DEFAULT '',
                details_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            , merchant_id INTEGER, product_id INTEGER, old_price TEXT DEFAULT '', new_price TEXT DEFAULT '', upload_job_id INTEGER, staging_item_id INTEGER, changed_by TEXT DEFAULT '', change_type TEXT DEFAULT '');
CREATE INDEX idx_catalog_audit_job ON catalog_audit_log(job_id, event, created_at);
CREATE INDEX idx_image_cache_phash ON image_cache(image_phash, decision);
CREATE INDEX idx_image_product_cache_phash ON image_product_cache(image_phash, decision);
CREATE TABLE merchant_product_aliases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                raw_name TEXT NOT NULL,
                normalized_raw_name TEXT NOT NULL,
                product_id INTEGER NOT NULL,
                source TEXT DEFAULT 'manual',
                last_seen_at TEXT,
                last_seen_in_upload_id INTEGER,
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE UNIQUE INDEX ux_merchant_alias_active ON merchant_product_aliases(merchant_id, normalized_raw_name) WHERE is_active=1;
CREATE INDEX idx_merchant_alias_product ON merchant_product_aliases(product_id, merchant_id);
CREATE UNIQUE INDEX ux_product_alias_active ON product_aliases(product_id, alias_normalized) WHERE is_active=1;
CREATE INDEX idx_product_alias_exact ON product_aliases(alias_normalized, is_active);
CREATE INDEX idx_catalog_staging_job_decision ON catalog_staging_items(job_id, decision);
CREATE INDEX idx_catalog_staging_safe ON catalog_staging_items(job_id, is_safe_to_apply);
CREATE INDEX idx_catalog_review_pending_safe ON catalog_review_items(status, merchant_id, created_at);
CREATE INDEX idx_catalog_audit_upload ON catalog_audit_log(upload_job_id, product_id);
CREATE TABLE products_master_identity (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER NOT NULL,
                original_excel_name TEXT DEFAULT '',
                normalized_original_name TEXT DEFAULT '',
                canonical_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                category TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                active_ingredient TEXT DEFAULT '',
                cosmetic_type TEXT DEFAULT '',
                use_case TEXT DEFAULT '',
                skin_type TEXT DEFAULT '',
                aliases TEXT DEFAULT '',
                ocr_keywords TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                price TEXT DEFAULT '',
                available INTEGER DEFAULT 1,
                identity_status TEXT DEFAULT 'NEEDS_IDENTITY_REVIEW',
                review_status TEXT DEFAULT 'PENDING',
                notes TEXT DEFAULT '',
                source TEXT DEFAULT 'auto_enrichment',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP, review_priority TEXT DEFAULT 'LOW', review_action TEXT DEFAULT 'AUTO_APPROVED', duplicate_group_key TEXT DEFAULT '',
                UNIQUE(merchant_id, product_id)
            );
CREATE INDEX idx_master_identity_brand ON products_master_identity(merchant_id, brand, form, strength, size);
CREATE INDEX idx_master_identity_status ON products_master_identity(identity_status, review_status);
CREATE INDEX idx_master_identity_original ON products_master_identity(merchant_id, normalized_original_name);
CREATE TABLE identity_review_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER,
                original_excel_name TEXT DEFAULT '',
                normalized_original_name TEXT DEFAULT '',
                issue_type TEXT DEFAULT '',
                status TEXT DEFAULT 'PENDING',
                suggested_json TEXT DEFAULT '{}',
                notes TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                resolved_at TEXT,
                resolved_by TEXT DEFAULT ''
            , review_priority TEXT DEFAULT 'LOW', review_action TEXT DEFAULT 'MANUAL_REQUIRED', group_key TEXT DEFAULT '', product_ids TEXT DEFAULT '');
CREATE INDEX idx_identity_review_status ON identity_review_queue(status, issue_type, created_at);
CREATE TABLE ocr_keywords (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER NOT NULL,
                keyword TEXT NOT NULL,
                keyword_normalized TEXT NOT NULL,
                source TEXT DEFAULT 'master_identity',
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(merchant_id, product_id, keyword_normalized)
            );
CREATE INDEX idx_ocr_keywords_lookup ON ocr_keywords(merchant_id, keyword_normalized, is_active);
CREATE TABLE visual_product_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                image_signature TEXT NOT NULL,
                canonical_name TEXT NOT NULL,
                excel_name TEXT NOT NULL,
                product_id INTEGER,
                brand TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                confidence INTEGER DEFAULT 1,
                last_seen_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, confirmed_count INTEGER DEFAULT 0, is_approved BOOLEAN DEFAULT 0,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            );
CREATE UNIQUE INDEX idx_visual_signature ON visual_product_memory(merchant_id, image_signature);
CREATE INDEX idx_visual_product_memory_product ON visual_product_memory(product_id, confidence);
CREATE TABLE product_identity_overlay (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                original_excel_name TEXT NOT NULL,
                normalized_excel_name TEXT NOT NULL,
                brand TEXT,
                canonical_name TEXT NOT NULL,
                form TEXT,
                strength TEXT,
                size TEXT,
                pack TEXT,
                source TEXT DEFAULT 'auto_learned',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            );
CREATE UNIQUE INDEX idx_overlay_unique ON product_identity_overlay(merchant_id, normalized_excel_name);
CREATE INDEX idx_overlay_active ON product_identity_overlay(merchant_id, is_active, brand, form, strength, size);
CREATE TABLE visual_product_pending_confirmations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                image_signature TEXT NOT NULL,
                product_id INTEGER NOT NULL,
                user_key TEXT NOT NULL,
                canonical_name TEXT NOT NULL,
                excel_name TEXT NOT NULL,
                brand TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                validation_reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen_at TIMESTAMP,
                UNIQUE(merchant_id, image_signature, product_id, user_key)
            );
CREATE INDEX idx_visual_pending_signature ON visual_product_pending_confirmations(merchant_id, image_signature, product_id);
CREATE TABLE identity_duplicate_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                group_key TEXT NOT NULL,
                product_ids TEXT DEFAULT '',
                raw_names TEXT DEFAULT '',
                issue_type TEXT DEFAULT 'DUPLICATE_IDENTITY_GROUP',
                review_priority TEXT DEFAULT 'CRITICAL',
                status TEXT DEFAULT 'PENDING',
                notes TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(merchant_id, group_key)
            );
CREATE INDEX idx_identity_duplicate_groups_status ON identity_duplicate_groups(status, review_priority, updated_at);
CREATE INDEX idx_product_aliases_cleaned ON product_aliases(cleaned_alias, active);
CREATE INDEX idx_product_aliases_product ON product_aliases(product_id, active);
CREATE UNIQUE INDEX ux_product_aliases_ai_active ON product_aliases(product_id, cleaned_alias, source) WHERE active=1;
CREATE UNIQUE INDEX idx_product_alias_unique
        ON product_aliases(product_id, cleaned_alias)
    ;
CREATE INDEX idx_products_weekly_stock ON products(merchant_id, is_available, needs_review);
CREATE TABLE search_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER,
                product_name TEXT DEFAULT '',
                user_id TEXT DEFAULT '',
                source TEXT DEFAULT 'whatsapp_confirmation',
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE INDEX idx_search_logs_product_time ON search_logs(merchant_id, product_id, timestamp);
CREATE INDEX idx_search_logs_time ON search_logs(timestamp);
CREATE TABLE product_upload_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                filename TEXT DEFAULT '',
                products_count INTEGER DEFAULT 0,
                backup_path TEXT DEFAULT '',
                status TEXT DEFAULT 'success',
                message TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE INDEX idx_product_upload_history_time ON product_upload_history(merchant_id, created_at);
CREATE TABLE upload_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                upload_time TEXT DEFAULT CURRENT_TIMESTAMP,
                filename TEXT DEFAULT '',
                total_rows INTEGER DEFAULT 0,
                new_products INTEGER DEFAULT 0,
                updated_products INTEGER DEFAULT 0,
                deactivated_products INTEGER DEFAULT 0,
                review_products INTEGER DEFAULT 0,
                status TEXT DEFAULT 'success',
                message TEXT DEFAULT ''
            );
CREATE INDEX idx_upload_history_time ON upload_history(merchant_id, upload_time);
CREATE TABLE review_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_name TEXT DEFAULT '',
                similar_existing_id INTEGER,
                temp_product_id INTEGER,
                uploaded_price TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                resolved INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                resolved_at TEXT
            , "candidates" TEXT DEFAULT '');
CREATE INDEX idx_review_queue_status ON review_queue(merchant_id, resolved, created_at);
CREATE INDEX idx_product_alias_cleaned_exact ON product_aliases(cleaned_alias, active);
CREATE TABLE import_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                job_type TEXT DEFAULT 'weekly_upload',
                filename TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                status TEXT DEFAULT 'UPLOADED',
                progress INTEGER DEFAULT 0,
                inserted INTEGER DEFAULT 0,
                updated INTEGER DEFAULT 0,
                skipped INTEGER DEFAULT 0,
                unmatched INTEGER DEFAULT 0,
                ambiguous INTEGER DEFAULT 0,
                summary TEXT DEFAULT '',
                error TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                finished_at TEXT
            , "progress_percent" INTEGER DEFAULT 0, "total_rows" INTEGER DEFAULT 0, "processed_rows" INTEGER DEFAULT 0, "updated_existing_count" INTEGER DEFAULT 0, "inserted_new_count" INTEGER DEFAULT 0, "duplicate_merged_count" INTEGER DEFAULT 0, "review_required_count" INTEGER DEFAULT 0, "invalid_rows_count" INTEGER DEFAULT 0, "skipped_rows_count" INTEGER DEFAULT 0, "error_message" TEXT DEFAULT '', "result_summary_json" TEXT DEFAULT '', "report_path" TEXT DEFAULT '', "started_at" TEXT);
CREATE INDEX idx_import_jobs_status ON import_jobs(merchant_id, status, created_at);
CREATE TABLE safe_text_memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            normalized_query TEXT UNIQUE,
            raw_query TEXT DEFAULT '',
            product_id INTEGER NOT NULL,
            source TEXT DEFAULT 'gemini_safe_economy',
            confirmed_count INTEGER DEFAULT 1,
            rejected_count INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            last_user_key TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
CREATE INDEX idx_safe_text_memory_query_active ON safe_text_memory(normalized_query, active);
CREATE INDEX idx_safe_text_memory_product_active ON safe_text_memory(product_id, active);
CREATE INDEX "idx_perf_products_visible_search" ON "products" ("available", "is_available", "search_mode", "review_status");
CREATE INDEX "idx_perf_products_name_available" ON "products" ("normalized_name", "available", "is_available");
CREATE INDEX "idx_perf_products_identity" ON "products" ("identity_key");
CREATE INDEX "idx_perf_products_brand" ON "products" ("brand");
CREATE INDEX "idx_perf_products_family" ON "products" ("product_family");
CREATE INDEX "idx_perf_products_active_ingredient" ON "products" ("active_ingredient");
CREATE INDEX "idx_perf_products_upload_seen" ON "products" ("merchant_id", "last_seen_in_upload");
CREATE INDEX "idx_perf_products_review" ON "products" ("merchant_id", "needs_review", "review_status");
CREATE INDEX "idx_perf_products_sections" ON "products" ("merchant_id", "main_section", "sub_section");
CREATE INDEX "idx_perf_products_category_sub" ON "products" ("merchant_id", "category", "subcategory");
CREATE INDEX "idx_perf_alias_cleaned_active" ON "product_aliases" ("cleaned_alias", "active");
CREATE INDEX "idx_perf_alias_normalized_active" ON "product_aliases" ("normalized_alias", "active");
CREATE INDEX "idx_perf_alias_text_active" ON "product_aliases" ("alias_text", "active");
CREATE INDEX "idx_perf_alias_product_active" ON "product_aliases" ("product_id", "active");
CREATE INDEX "idx_perf_search_key_kind" ON "product_search_index" ("key", "kind");
CREATE INDEX "idx_perf_search_product" ON "product_search_index" ("product_db_id");
CREATE INDEX "idx_perf_guided_visible" ON "guided_catalog_index" ("visible", "main_section", "sub_section");
CREATE INDEX "idx_perf_guided_product" ON "guided_catalog_index" ("product_db_id");
CREATE INDEX "idx_perf_conversation_expiry" ON "conversation_state" ("expires_at");
CREATE INDEX "idx_perf_conversation_updated" ON "conversation_state" ("updated_at");
CREATE INDEX "idx_perf_processed_created" ON "processed_messages" ("created_at");
CREATE INDEX "idx_perf_import_status_created" ON "import_jobs" ("merchant_id", "status", "created_at");
CREATE INDEX "idx_perf_review_status_created" ON "review_queue" ("merchant_id", "resolved", "created_at");
CREATE INDEX "idx_perf_image_cache_hash" ON "image_cache" ("image_hash");
CREATE INDEX "idx_perf_image_cache_media_updated" ON "image_cache" ("media_id", "updated_at");
CREATE INDEX "idx_perf_image_cache_decision" ON "image_cache" ("decision", "updated_at");
CREATE INDEX "idx_perf_image_product_cache_hash" ON "image_product_cache" ("image_hash");
CREATE INDEX "idx_perf_safe_text_memory_query_active" ON "safe_text_memory" ("normalized_query", "active");
CREATE INDEX "idx_perf_safe_text_memory_product_active" ON "safe_text_memory" ("product_id", "active");
CREATE INDEX "idx_perf_image_product_cache_media_updated" ON "image_product_cache" ("media_id", "updated_at");
CREATE INDEX "idx_perf_learning_status_created" ON "learning_inbox" ("status", "created_at");
CREATE TABLE sqlite_stat1(tbl,idx,stat);
CREATE UNIQUE INDEX idx_products_stable_product_code ON products(stable_product_code);
CREATE INDEX idx_products_barcode_verified ON products(barcode, barcode_verified);
CREATE TABLE memory_review_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_type TEXT NOT NULL,
                memory_id INTEGER,
                action TEXT NOT NULL,
                actor TEXT DEFAULT '',
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE INDEX idx_memory_review_audit_type_time ON memory_review_audit(memory_type, created_at);
CREATE TABLE bot_metrics_daily (
                day TEXT PRIMARY KEY,
                text_messages INTEGER DEFAULT 0,
                image_messages INTEGER DEFAULT 0,
                gemini_calls INTEGER DEFAULT 0,
                safe_text_hits INTEGER DEFAULT 0,
                exact_image_hits INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE catalog_image_candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        product_name TEXT,
        source_query TEXT,
        source_url TEXT,
        local_url TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        source_provider TEXT NOT NULL DEFAULT 'duckduckgo',
        created_at TEXT NOT NULL,
        approved_at TEXT,
        note TEXT
    );
CREATE INDEX idx_catalog_image_candidates_product_status ON catalog_image_candidates(product_id, status);
CREATE INDEX idx_products_id_catalog ON products(id);
CREATE INDEX idx_products_catalog_brand ON products("brand");
CREATE INDEX idx_products_catalog_company ON products("company");
CREATE INDEX idx_products_catalog_category ON products("category");
CREATE INDEX idx_products_catalog_main_section ON products("main_section");
CREATE INDEX idx_products_catalog_is_available ON products("is_available");
CREATE INDEX idx_products_catalog_available ON products("available");
CREATE INDEX idx_products_catalog_price ON products("price");
CREATE INDEX idx_products_catalog_updated_at ON products("updated_at");
CREATE INDEX idx_products_catalog_created_at ON products("created_at");
CREATE VIRTUAL TABLE products_catalog_fts USING fts5(search_text, tokenize='unicode61 remove_diacritics 2')
/* products_catalog_fts(search_text) */;
CREATE TABLE IF NOT EXISTS 'products_catalog_fts_data'(id INTEGER PRIMARY KEY, block BLOB);
CREATE TABLE IF NOT EXISTS 'products_catalog_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS 'products_catalog_fts_content'(id INTEGER PRIMARY KEY, c0);
CREATE TABLE IF NOT EXISTS 'products_catalog_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
CREATE TABLE IF NOT EXISTS 'products_catalog_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;
