# FIX_CLIENT_IP_RECURSION_REPORT_20260623

## File changed

- `catalog_web.py`

## Problem fixed

The `_client_ip(request)` helper was recursively calling itself:

```python
def _client_ip(request: Request) -> str:
    client = _client_ip(request)
```

This could break `/catalog-event` with `RecursionError: maximum recursion depth exceeded`.

## Fix applied

The helper now reads `request.client.host` directly and only uses `X-Forwarded-For` when the app is reached through the local reverse proxy.

```python
def _client_ip(request: Request) -> str:
    client = (request.client.host if request.client else "") or "unknown"
    if client in {"127.0.0.1", "::1", "localhost"}:
        xff = (request.headers.get("x-forwarded-for") or "").split(",", 1)[0].strip()
        if re.fullmatch(r"[A-Fa-f0-9:.]{3,45}", xff):
            return xff
    return client
```

## Expected result

- `/catalog-event` no longer crashes due to recursion.
- Catalog analytics/page-view events should work again.
- Existing catalog/product search behavior is unchanged.
