import asyncio
import hashlib
import hmac
import json
import os
import re
import time
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple

import httpx
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, PlainTextResponse

import config_env

# Load .env and legacy variable aliases before importing modules that resolve
# DB paths or AI/Vision configuration at import time.
config_env.load_environment()

import admin
import database
import guided_commerce
import matcher
import merchant
import orders
import portal
import catalog_web
import vision_service
import ui_flow
import whatsapp_interactive
from search_engine import SearchResult
from services.vision import visual_memory
from services.vision import ai_product_matcher
from normalizer import normalize_text
try:
    from tasks.text_tasks import process_text_message as celery_text_task
    from tasks.vision_tasks import process_vision_message as celery_vision_task
except Exception:
    celery_text_task = None
    celery_vision_task = None

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")
ADMIN_NOTIFY_PHONE = re.sub(r"\D+", "", os.getenv("ADMIN_NOTIFY_PHONE", ""))
QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_QUEUE_MAXSIZE", "2000"))
WORKERS = int(os.getenv("PRICEBOT_WORKERS", "10"))
# Performance Hardening V1: split text and image queues so slow Gemini/image
# processing cannot block fast name-search replies.
TEXT_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_TEXT_QUEUE_MAXSIZE", str(QUEUE_MAXSIZE)))
IMAGE_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_IMAGE_QUEUE_MAXSIZE", str(max(100, QUEUE_MAXSIZE // 2))))
TEXT_WORKERS = int(os.getenv("PRICEBOT_TEXT_WORKERS", str(WORKERS)))
IMAGE_WORKERS = int(os.getenv("PRICEBOT_IMAGE_WORKERS", "4"))
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "25"))
RATE_LIMIT_IMAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_IMAGES", "6"))
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60"))

MAIN_MENU = ui_flow.MAIN_MENU_MESSAGE
START_WORDS = ui_flow.START_WORDS | ui_flow.GREETING_WORDS | ui_flow.MENU_WORDS

app = FastAPI(title="PriceBot Premium Enterprise UI")

# PRICEBOT TRUSTED HOSTS PATCH START
try:
    import os as _pricebot_os
    from starlette.middleware.trustedhost import TrustedHostMiddleware as _PriceBotTrustedHostMiddleware
    _pricebot_allowed_hosts = [h.strip() for h in _pricebot_os.getenv("PRICEBOT_TRUSTED_HOSTS", "46.101.148.246.sslip.io,127.0.0.1,localhost").split(",") if h.strip()]
    app.add_middleware(_PriceBotTrustedHostMiddleware, allowed_hosts=_pricebot_allowed_hosts)
except Exception:
    pass
# PRICEBOT TRUSTED HOSTS PATCH END

# PriceBot Catalog Website
from catalog_web import router as catalog_router
app.mount("/static", StaticFiles(directory="static"), name="static")
app.include_router(portal.router)
app.include_router(admin.router)
app.include_router(merchant.router)
app.include_router(catalog_web.router)  # catalog website router: keep LAST to avoid shadowing merchant/webhook/API routes
text_queue: asyncio.Queue = asyncio.Queue(maxsize=TEXT_QUEUE_MAXSIZE)
image_queue: asyncio.Queue = asyncio.Queue(maxsize=IMAGE_QUEUE_MAXSIZE)
# Backward-compatible alias for code/tests that still inspect `queue`.
queue: asyncio.Queue = text_queue
http_client: Optional[httpx.AsyncClient] = None
rate_buckets: Dict[str, deque] = defaultdict(deque)
image_rate_buckets: Dict[str, deque] = defaultdict(deque)
# Per-user locks prevent concurrent workers from processing multiple messages
# from the same WhatsApp number at the same time.  This protects conversation
# state, clarification options, and numbered choices from race conditions.
user_locks: Dict[str, asyncio.Lock] = {}
user_lock_last_seen: Dict[str, float] = {}
USER_LOCK_TTL_SECONDS = int(os.getenv("PRICEBOT_USER_LOCK_TTL_SECONDS", "900") or 900)
IMAGE_CONCURRENCY = int(os.getenv("PRICEBOT_IMAGE_CONCURRENCY", "8") or 8)
IMAGE_TOTAL_TIMEOUT = float(os.getenv("PRICEBOT_IMAGE_TOTAL_TIMEOUT_SECONDS", "15") or 15)
image_semaphore = asyncio.Semaphore(max(1, IMAGE_CONCURRENCY))


def log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["token", "secret", "authorization"]):
            v = "HIDDEN"
        if k in {"phone", "to", "from_"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)





def _has_meaningful_product_text(texts: List[object]) -> bool:
    """Return True when Vision produced usable product evidence.

    A readable product name/dose should bypass image quality rejection.  Quality
    checks are only a fallback when OCR/Vision produced no useful product text.
    Generic package/form words alone (box, tablet, capsule, image, photo, etc.)
    are not enough.
    """
    combined = " ".join(str(t or "") for t in (texts or [])).strip().lower()
    if not combined:
        return False
    stopwords = {
        "image", "photo", "picture", "box", "pack", "package", "blister",
        "tablet", "tablets", "capsule", "capsules", "cream", "gel", "lotion",
        "syrup", "solution", "suspension", "oral", "use", "bottle", "label",
        "صوره", "صورة", "علبه", "علبة", "حبوب", "كبسول", "كبسولات", "شراب",
    }
    # Dose/size evidence is meaningful only when paired with text elsewhere, but
    # it is a strong signal that the image contains a product label.
    if re.search(r"\d+\s*(?:mg|mcg|g|gm|ml|iu|%)\b", combined, flags=re.IGNORECASE):
        return True
    tokens = re.findall(r"[a-zA-Z\u0600-\u06FF0-9%/+-]+", combined)
    for token in tokens:
        t = token.strip(" -_+/")
        if not t or t in stopwords:
            continue
        # Product/brand words such as CRESTOR, Hemazym, Flagyl, Panadol.
        if re.search(r"[a-zA-Z\u0600-\u06FF]{3,}", t):
            return True
    return False


def _vision_candidate_texts_for_quality_bypass(extracted: Dict) -> List[str]:
    """Collect all Vision text fields only to decide whether quality can be bypassed."""
    parts: List[str] = []
    for key in [
        "extracted_name", "query", "primary_title", "product_name",
        "foreground_product_text", "foreground_text", "visible_text", "raw_vision_text",
    ]:
        value = (extracted or {}).get(key)
        if value:
            parts.append(str(value))
    for key in ["all_texts", "texts", "ocr_texts"]:
        value = (extracted or {}).get(key)
        if isinstance(value, (list, tuple)):
            parts.extend(str(v) for v in value if v)
        elif value:
            parts.append(str(value))
    return parts

def _vision_alias_candidate_texts(extracted: Dict) -> List[str]:
    """Foreground-only texts eligible for exact product_aliases lookup.

    Background and ingredients are intentionally excluded so an ingredient such
    as Folic Acid cannot override the real foreground product title.
    """
    parts: List[str] = []
    for key in [
        "query",
        "foreground_product_text",
        "foreground_text",
        "primary_title",
        "product_name",
    ]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    combo = " ".join(str((extracted or {}).get(k) or "").strip() for k in ["brand", "primary_title", "form", "strength", "size", "pack"] if str((extracted or {}).get(k) or "").strip())
    if combo and combo not in parts:
        parts.insert(0, combo)
    # raw_vision_text may contain ingredients/background. Use it only when no
    # background/ingredients were separately reported by the validator.
    if not str((extracted or {}).get("background_text") or "").strip() and not (extracted or {}).get("ingredients"):
        raw = str((extracted or {}).get("raw_vision_text") or "").strip()
        if raw and raw not in parts:
            parts.append(raw)
    return parts


def _image_confirmation_text(product: Dict, prefix: str = "هل هذا المنتج؟") -> str:
    raw_name = product.get("canonical_display_name") or product.get("name") or "المنتج"
    name = "\u2066" + str(raw_name).strip() + "\u2069"
    details = []
    for key in ["form", "strength", "size", "pack"]:
        if product.get(key):
            details.append(str(product.get(key)))
    suffix = ("\n" + "\u2066" + " / ".join(details) + "\u2069") if details else ""
    return (
        f"🛒 {prefix}\n"
        f"{name}{suffix}\n\n"
        "اختر نعم للتأكيد، أو لا لإعادة المحاولة."
    )



def _vision_has_product_identity_evidence(extracted: Dict) -> bool:
    """Return True when Vision supplied more than a brand label.

    Image confirmation is allowed only for a real product candidate.  Brand-only
    OCR such as "LA ROCHE-POSAY" must become clarification/options, never a
    yes/no confirmation for a synthetic brand row.
    """
    if not extracted:
        return False
    product_keys = [
        "primary_title", "product_name", "product_family",
        "foreground_product_text", "foreground_text", "main_visible_product",
        "form", "strength", "size", "pack",
    ]
    brand = normalize_text(extracted.get("brand") or "")
    values = [str(extracted.get(k) or "").strip() for k in product_keys]
    for value in values:
        if not value:
            continue
        value_norm = normalize_text(value)
        # A repeated brand in title/foreground is still brand-only.
        if value_norm and value_norm != brand:
            return True
    return False


def _set_pending_image_product(phone: str, product: Dict, *, query: str, image_hash: str, media_id: str, extracted: Dict, source: str, **extra) -> None:
    pid = int(product.get("id") or 0)
    if not pid:
        return
    payload = {
        "state": "WAITING_FOR_IMAGE_CONFIRMATION",
        "pending_product_id": pid,
        # Keep product_id for backward-compatible UI payloads, but all "yes"
        # handling now reads pending_product_id first.
        "product_id": pid,
        "confirmation_query": product.get("canonical_display_name") or product.get("name") or query or "",
        "image_hash": image_hash,
        "media_id": media_id,
        "extracted_slots": extracted,
        "source": source,
    }
    payload.update({k: v for k, v in extra.items() if v is not None})
    database.set_state(phone, payload)


def _image_ai_evidence_text(extracted: Dict, usable_vision_texts: List[str]) -> str:
    """Combine Vision text fields for the AI product matcher.

    This replaces product_aliases/generic/brand guards in the image path.  The
    AI matcher receives the extracted text plus current products and must return
    a single product_id or matched=false.
    """
    parts: List[str] = []
    for key in [
        "extracted_name", "query", "primary_title", "product_name",
        "foreground_product_text", "foreground_text", "visible_text", "raw_vision_text",
    ]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    for value in usable_vision_texts or []:
        value = str(value or "").strip()
        if value and value not in parts:
            parts.append(value)
    return " ".join(parts).strip()


async def _handle_ai_image_product_match(
    phone: str,
    evidence_text: str,
    *,
    query: str,
    image_hash: str,
    media_id: str,
    extracted: Dict,
) -> Optional[str]:
    """Run the single AI product matcher and turn a match into confirmation.

    This never displays price.  On "yes", the existing text handler uses
    pending_product_id directly.
    """
    if not evidence_text:
        return None
    ai_hit = await ai_product_matcher.match_extracted_text_to_product(evidence_text)
    if not bool(ai_hit.get("matched")):
        log("AI_IMAGE_PRODUCT_MATCH_FALSE", reason=ai_hit.get("reason"))
        return None
    try:
        product_id = int(ai_hit.get("product_id") or 0)
    except Exception:
        product_id = 0
    if not product_id:
        log("AI_IMAGE_PRODUCT_MATCH_REJECTED", reason="missing_product_id")
        return None
    product = database.get_product(product_id)
    if not product or not database.product_visible(product, guided=False):
        log("AI_IMAGE_PRODUCT_MATCH_REJECTED", product_id=product_id, reason="product_not_visible")
        return None

    evidence_check = ai_product_matcher.validate_text_evidence_for_match(
        evidence_text, product.get("canonical_display_name") or product.get("name") or ""
    )
    if not evidence_check.get("passed"):
        log(
            "EVIDENCE_VALIDATOR_FAILED",
            gemini_product=product.get("canonical_display_name") or product.get("name") or "",
            image_text=str(evidence_text or "")[:220],
            missing_tokens=",".join(evidence_check.get("missing_tokens") or evidence_check.get("product_tokens") or []),
        )
        visible = str(query or evidence_text or "").strip()
        visible = re.sub(r"\s+", " ", visible)[:120]
        if visible:
            return f"🔍 لم أجد المنتج في قائمة الصيدلية.\nالظاهر في الصورة: {visible}\nيرجى كتابة الاسم يدوياً أو إرسال صورة أوضح."
        return "🔍 لم أجد المنتج في قائمة الصيدلية.\nيرجى التأكد من الاسم، أو إرسال صورة أوضح للمنتج.\nاكتب الاسم يدوياً عند الحاجة."

    _set_pending_image_product(
        phone,
        product,
        query=query or evidence_text,
        image_hash=image_hash,
        media_id=media_id,
        extracted=extracted,
        source="ai_product_match_pending_confirmation",
        ai_match_source=ai_hit.get("source"),
    )
    log("AI_IMAGE_PRODUCT_MATCH_CONFIRMATION_ONLY", product_id=product_id, source=ai_hit.get("source"))
    return _image_confirmation_text(product)

def rate_limit_ok(phone: str) -> bool:
    now = time.time()
    b = rate_buckets[phone]
    while b and now - b[0] > RATE_LIMIT_WINDOW:
        b.popleft()
    if len(b) >= RATE_LIMIT_MESSAGES:
        return False
    b.append(now)
    return True


def image_rate_limit_ok(phone: str) -> bool:
    now = time.time()
    b = image_rate_buckets[phone]
    while b and now - b[0] > RATE_LIMIT_WINDOW:
        b.popleft()
    if len(b) >= RATE_LIMIT_IMAGES:
        return False
    b.append(now)
    return True


def cleanup_user_locks() -> None:
    now = time.time()
    stale = [phone for phone, ts in user_lock_last_seen.items() if now - ts > USER_LOCK_TTL_SECONDS]
    for phone in stale:
        lock = user_locks.get(phone)
        if lock is not None and lock.locked():
            continue
        user_locks.pop(phone, None)
        user_lock_last_seen.pop(phone, None)
    if stale:
        log("USER_LOCK_CLEANUP", removed=len(stale), active=len(user_locks))


def get_user_lock(phone: str) -> asyncio.Lock:
    cleanup_user_locks()
    lock = user_locks.get(phone)
    if lock is None:
        lock = asyncio.Lock()
        user_locks[phone] = lock
    user_lock_last_seen[phone] = time.time()
    return lock


def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET:
        return False
    if not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


async def send_whatsapp_message(to_number: str, text: str) -> bool:
    if not text:
        return False
    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number, text=text[:120])
        return True
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": text[:3900]}}
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_ERROR", status=resp.status_code, response=resp.text[:200])
            return False
        return True
    except Exception as exc:
        log("SEND_EXCEPTION", error=repr(exc))
        return False


async def send_whatsapp_payload(to_number: str, payload: Dict) -> bool:
    if not META_TOKEN or not PHONE_ID:
        log("SEND_INTERACTIVE_SKIPPED_NO_META", to=to_number)
        return False
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_INTERACTIVE_ERROR", status=resp.status_code, response=resp.text[:200])
            return False
        return True
    except Exception as exc:
        log("SEND_INTERACTIVE_EXCEPTION", error=repr(exc))
        return False


async def send_reply_with_optional_interactive(to_number: str, text: str) -> bool:
    # Premium WhatsApp UI: all navigation and selection states are sent as
    # WhatsApp buttons/lists. Plain text remains only as a transport fallback
    # and for direct user search text / product photos.
    payload = None
    try:
        payload = ui_flow.build_interactive_payload(to_number, text)
    except Exception as exc:
        log("INTERACTIVE_BUILD_WARNING", error=repr(exc))
    if payload and await send_whatsapp_payload(to_number, payload):
        return True
    return await send_whatsapp_message(to_number, text)


async def notify_admin(text: str) -> None:
    if ADMIN_NOTIFY_PHONE:
        await send_whatsapp_message(ADMIN_NOTIFY_PHONE, text)


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not META_TOKEN:
        return b"", "image/jpeg"
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    assert http_client is not None
    meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
    meta.raise_for_status()
    info = meta.json()
    url = info.get("url", "")
    mime = info.get("mime_type", "image/jpeg")
    if not url:
        return b"", mime
    data = await http_client.get(url, headers=headers, timeout=20)
    data.raise_for_status()
    return data.content, mime


def extract_messages(payload: Dict) -> List[Dict]:
    out: List[Dict] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        text = (inter.get("button_reply") or {}).get("id") or (inter.get("button_reply") or {}).get("title") or ""
                    elif inter.get("type") == "list_reply":
                        text = (inter.get("list_reply") or {}).get("id") or (inter.get("list_reply") or {}).get("title") or ""
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out


def _number_choice(text: str) -> Optional[int]:
    t = normalize_text(text)
    if t.isdigit():
        n = int(t)
        if 1 <= n <= 999:
            return n
    return None


def _main_sections_for_state() -> List[str]:
    return guided_commerce.available_main_sections() or guided_commerce.MAIN_SECTIONS


def _sub_sections_for_state(main: str) -> List[str]:
    return guided_commerce.available_sub_sections(main)


def _products_by_ids(ids: List[int]) -> List[Dict]:
    out = []
    for pid in ids:
        p = database.get_product(int(pid))
        if p and database.product_visible(p, guided=False):
            out.append(p)
    return out


def _show_product_list(phone: str, products_list: List[Dict], page: int = 0) -> str:
    ids = [int(p["id"]) for p in products_list if p.get("id")]
    database.set_state(phone, {"mode": "product_list", "ids": ids, "page": page})
    return orders.format_product_list(products_list, page=page)


def _show_guided_products(phone: str, main: str, sub: str, skin_type: str = "", page: int = 0) -> str:
    # Load more than one page into state, but keep DB query bounded.
    plist = database.guided_products(main, sub, skin_type=skin_type, page=0, page_size=80)
    # Apply stricter skincare filter after DB index for safety.
    plist = [p for p in plist if guided_commerce.product_allowed_in_subsection(p, main, sub, skin_type)]
    if not plist:
        database.clear_state(phone)
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار."
    return _show_product_list(phone, plist, page=page)


def _handle_search_result(phone: str, result) -> str:
    if result.status == "EXACT_MATCH" and result.product:
        database.set_state(phone, {"mode": "product_details", "product_id": int(result.product["id"])})
        return orders.format_product_details(result.product)
    if result.status == "COSMETIC_ALTERNATIVES" and result.products:
        return (result.message + "\n\n" if result.message else "") + _show_product_list(phone, result.products, page=0)
    if result.status == "ASK_CLARIFICATION":
        state = {"mode": "awaiting_clarification", "pending_query": ""}
        if result.products:
            state["candidate_ids"] = [int(p["id"]) for p in result.products if p.get("id")]
        database.set_state(phone, state)
        return result.message or "أحتاج تفاصيل أكثر قبل عرض السعر."
    if result.status == "NOT_AVAILABLE":
        database.clear_state(phone)
        return result.message or "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا."
    return result.message or "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل."


def _is_ui_command_text(text: str) -> bool:
    n = normalize_text(text or "")
    ui_words = {
        # Visible Arabic labels
        "بحث بالاسم", "البحث بالاسم", "بحث باسم", "اسم", "بحث جديد",
        "بحث بالصورة", "البحث بالصورة", "بحث بصورة", "صورة",
        "الأقسام", "الاقسام", "تصفح الأقسام", "تصفح الاقسام",
        "القائمة", "قائمة", "القائمة الرئيسية", "الرئيسية", "رجوع", "عودة",
        "ابدأ", "ابدا", "start", "main menu",
        # WhatsApp interactive ids.  These must bypass safe-memory/Gemini/search
        # and go directly to ui_flow, otherwise an id like SEARCH_NAME can be
        # treated as a product query depending on the previous conversation state.
        "MAIN_MENU", "START_USE", "MAIN_SEARCH", "MAIN_BROWSE", "MAIN_INFO",
        "SEARCH_NAME", "SEARCH_IMAGE", "BACK", "NAV_NEXT", "NAV_PREV",
    }
    return n in {normalize_text(x) for x in ui_words}


def _text_safe_economy_eligible(phone: str, text: str) -> bool:
    raw = str(text or "").strip()
    if not raw:
        return False
    if _is_ui_command_text(raw):
        return False
    n = normalize_text(raw)
    if n in {normalize_text(x) for x in START_WORDS}:
        return False
    # Do not intercept numeric/menu navigation or yes/no answers.
    if raw.isdigit() or n in {"نعم", "اي", "ايوه", "yes", "y", "لا", "no", "n", "رجوع", "back"}:
        return False
    state = database.get_state(phone)
    current = str((state or {}).get("state") or (state or {}).get("mode") or "")
    return current in {"", "START", "MAIN_MENU", "WAITING_FOR_PRODUCT_SEARCH", "WAITING_FOR_PRODUCT_IMAGE"}


async def _maybe_safe_text_memory_confirmation(phone: str, text: str) -> Optional[str]:
    if not _text_safe_economy_eligible(phone, text):
        return None
    try:
        hit = database.lookup_safe_text_memory(text)
    except Exception as exc:
        log("SAFE_TEXT_MEMORY_LOOKUP_WARNING", error=repr(exc))
        hit = None
    if not hit:
        return None
    product = hit.get("product") or {}
    if not product or not product.get("id"):
        return None
    _set_pending_image_product(
        phone,
        product,
        query=str(text or ""),
        image_hash="",
        media_id="",
        extracted={"query": text, "source": "safe_text_memory"},
        source="safe_text_memory_pending_confirmation",
        text_query=str(text or ""),
    )
    log("SAFE_TEXT_MEMORY_HIT_CONFIRMATION_ONLY", product_id=product.get("id"))
    return _image_confirmation_text(product, prefix="هل تقصد هذا المنتج؟")


async def _maybe_gemini_text_fallback(phone: str, text: str, local_result) -> Optional[str]:
    if not _text_safe_economy_eligible(phone, text):
        return None
    if str(os.getenv("PRICEBOT_TEXT_GEMINI_FALLBACK", "1")).strip().lower() not in {"1", "true", "yes", "on"}:
        return None
    if getattr(local_result, "status", "") not in {"LOW_CONFIDENCE", "NOT_AVAILABLE"}:
        return None
    raw = str(text or "").strip()
    # Avoid spending Gemini on very short or generic one-word inputs.
    strongish = [t for t in re.findall(r"[\w%/+-]+", normalize_text(raw), flags=re.UNICODE) if len(t) >= 3]
    if len(strongish) < 2 and not re.search(r"\d", raw):
        return None
    ai_hit = await ai_product_matcher.match_extracted_text_to_product(raw)
    if not bool(ai_hit.get("matched")):
        log("GEMINI_TEXT_FALLBACK_FALSE", reason=ai_hit.get("reason"))
        return None
    try:
        product_id = int(ai_hit.get("product_id") or 0)
    except Exception:
        product_id = 0
    product = database.get_product(product_id) if product_id else None
    if not product or not database.product_visible(product, guided=False):
        log("GEMINI_TEXT_FALLBACK_REJECTED", reason="product_not_visible", product_id=product_id)
        return None
    evidence_check = ai_product_matcher.validate_text_evidence_for_match(raw, product.get("canonical_display_name") or product.get("name") or "")
    if not evidence_check.get("passed"):
        log("GEMINI_TEXT_FALLBACK_EVIDENCE_REJECTED", product_id=product_id)
        return None
    _set_pending_image_product(
        phone,
        product,
        query=raw,
        image_hash="",
        media_id="",
        extracted={"query": raw, "confidence": "gemini_text_fallback"},
        source="ai_text_match_pending_confirmation",
        text_query=raw,
        ai_match_source=ai_hit.get("source"),
    )
    log("GEMINI_TEXT_FALLBACK_CONFIRMATION_ONLY", product_id=product_id, source=ai_hit.get("source"))
    return _image_confirmation_text(product, prefix="هل تقصد هذا المنتج؟")


async def process_text(phone: str, text: str) -> str:
    # Navigation/button labels must always go through ui_flow first.  Otherwise
    # words like "بحث بالاسم" or "بحث بالصورة" can be treated as product names.
    if _is_ui_command_text(text):
        return ui_flow.handle_text(phone, text)
    memory_reply = await _maybe_safe_text_memory_confirmation(phone, text)
    if memory_reply:
        return memory_reply
    if _text_safe_economy_eligible(phone, text):
        local_result = matcher.match_text(text)
        if local_result.status in {"LOW_CONFIDENCE", "NOT_AVAILABLE"}:
            gemini_reply = await _maybe_gemini_text_fallback(phone, text, local_result)
            if gemini_reply:
                return gemini_reply
        return ui_flow.handle_search_result(phone, local_result, original_query=text)
    return ui_flow.handle_text(phone, text)


async def process_image(phone: str, media_id: str) -> str:
    log("IMAGE_RECEIVED", phone=phone)
    await send_whatsapp_message(phone, "🔍 جاري فحص الصورة...")
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return "📷 الصورة غير كافية للتعرف على المنتج.\nالرجاء إعادة التصوير بشكل أوضح، أو كتابة اسم المنتج مباشرة."

    image_hash = hashlib.sha256(image_bytes or b"").hexdigest() if image_bytes else ""

    # Production-safe cache policy: trust only cache entries saved after explicit
    # user confirmation.  Older pre-confirmation image caches are ignored.
    cached = database.get_image_cache(image_hash=image_hash, media_id=media_id)
    if cached and cached.get("decision") in {"VISUAL_MEMORY_APPROVED", "EXACT_IMAGE_CONFIRMED"} and cached.get("matched_product_id"):
        # Gemini Safe Economy Mode: exact image hash hits skip Gemini, but still
        # only pre-fill the candidate and require user confirmation before price.
        log("VISION_EXACT_CACHE_HIT_CONFIRMATION_ONLY", decision=cached.get("decision"))
        p = database.get_product(int(cached.get("matched_product_id")))
        if p and database.product_visible(p, guided=False):
            slots = {}
            try:
                slots = json.loads(cached.get("extracted_slots") or "{}") if isinstance(cached.get("extracted_slots"), str) else (cached.get("extracted_slots") or {})
            except Exception:
                slots = {}
            # VISUAL_MEMORY_APPROVED is a strong learned signature. EXACT_IMAGE_CONFIRMED
            # is trusted only for the identical SHA-256 image_hash, never for similar images.
            if cached.get("decision") == "VISUAL_MEMORY_APPROVED":
                try:
                    memory = visual_memory.lookup_visual_memory(slots or {}, merchant_id=int(p.get("merchant_id") or 1))
                    if not (memory and int(memory.get("product_id") or 0) == int(p["id"])):
                        log("VISION_CACHE_APPROVED_MEMORY_NOT_FOUND_BUT_EXACT_HASH_USED", product_id=p.get("id"))
                except Exception:
                    pass
            _set_pending_image_product(
                phone, p, query=p.get("canonical_display_name") or p.get("name") or "",
                image_hash=image_hash, media_id=media_id, extracted=slots,
                source="exact_image_cache_pending_confirmation",
            )
            return _image_confirmation_text(p)

    try:
        async with image_semaphore:
            extracted = await asyncio.wait_for(
                vision_service.extract_product_from_image(image_bytes, mime),
                timeout=IMAGE_TOTAL_TIMEOUT,
            )
    except asyncio.TimeoutError:
        log("VISION_TIMEOUT", phone=phone)
        try:
            database.record_learning_event(
                customer_query="", vision_text="", decision="IMAGE_UNCLEAR",
                reason="vision_timeout", media_id=media_id,
                query_slots={"image_hash": image_hash},
            )
        except Exception:
            pass
        return "📷 الصورة غير كافية للتعرف على المنتج.\nالرجاء إعادة التصوير بشكل أوضح، أو كتابة اسم المنتج مباشرة."

    usable_vision_texts = _vision_candidate_texts_for_quality_bypass(extracted)
    has_usable_text = _has_meaningful_product_text(usable_vision_texts)

    if extracted.get("status") != "OK":
        # Quality/validation rejection is a fallback only.  If Vision/OCR produced
        # readable product text (e.g. a tilted CRESTOR 20mg image), still try the
        # safe alias path before returning IMAGE_UNCLEAR/LOW_CONFIDENCE.
        if has_usable_text:
            query = extracted.get("query") or extracted.get("extracted_name") or extracted.get("primary_title") or " ".join(usable_vision_texts)
            evidence_text = _image_ai_evidence_text(extracted, usable_vision_texts)
            log("IMAGE_HAS_USABLE_TEXT", text=str(query or evidence_text)[:100], original_status=extracted.get("status"))
            reply = await _handle_ai_image_product_match(
                phone, evidence_text, query=str(query or ""), image_hash=image_hash,
                media_id=media_id, extracted=extracted,
            )
            if reply:
                return reply
            log("AI_IMAGE_TEXT_NO_MATCH", original_status=extracted.get("status"))
            return "🔍 لم أجد المنتج في قائمة الصيدلية.\nيرجى التأكد من الاسم، أو إرسال صورة أوضح للمنتج.\nاكتب الاسم يدوياً عند الحاجة."

        log("VISION_MATCH_DECISION", decision=extracted.get("status") or "IMAGE_UNCLEAR")
        try:
            database.record_learning_event(
                customer_query=str(extracted.get("query") or ""),
                vision_text=str(extracted.get("raw_vision_text") or extracted.get("visible_text") or ""),
                decision=extracted.get("status") or "IMAGE_UNCLEAR",
                reason=str(extracted.get("vision_validation") or extracted.get("message") or "vision_rejected"),
                media_id=media_id,
                main_visible_product=str(extracted.get("primary_title") or extracted.get("foreground_product_text") or ""),
                background_text=str(extracted.get("background_text") or ""),
                query_slots={**extracted, "image_hash": image_hash},
            )
        except Exception:
            pass
        return "📷 الصورة غير كافية للتعرف على المنتج.\nالرجاء إعادة التصوير بشكل أوضح، أو كتابة اسم المنتج مباشرة."

    query = extracted.get("query") or extracted.get("extracted_name") or extracted.get("primary_title") or ""
    log("VISION_RESULT", extracted_name=str(query)[:120], confidence=extracted.get("confidence", ""), usable_text=has_usable_text)

    # New AI image matching path: if Vision produced usable text, ask the text
    # Gemini/OpenRouter matcher to choose exactly one product from products(id,name).
    # product_aliases and legacy image guards are intentionally ignored here.
    if has_usable_text:
        evidence_text = _image_ai_evidence_text(extracted, usable_vision_texts)
        log("IMAGE_HAS_USABLE_TEXT", text=str(evidence_text or query)[:100])
        reply = await _handle_ai_image_product_match(
            phone, evidence_text, query=str(query or ""), image_hash=image_hash,
            media_id=media_id, extracted=extracted,
        )
        if reply:
            return reply
        log("AI_IMAGE_TEXT_NO_MATCH", status="matched_false")
        return "🔍 لم أجد المنتج في قائمة الصيدلية.\nيرجى التأكد من الاسم، أو إرسال صورة أوضح للمنتج.\nاكتب الاسم يدوياً عند الحاجة."

    return "📷 الصورة غير كافية للتعرف على المنتج.\nالرجاء إعادة التصوير بشكل أوضح، أو كتابة اسم المنتج مباشرة."

    if result.products:
        result.products = result.products[:4]
    if result.status == "EXACT_MATCH" and result.product and result.product.get("id"):
        # Image exact identity still requires explicit confirmation before price.
        product = result.product
        _set_pending_image_product(
            phone, product, query=query, image_hash=image_hash, media_id=media_id,
            extracted=extracted, source="vision_exact_pending_confirmation",
        )
        return _image_confirmation_text(product)

    return ui_flow.handle_search_result(phone, result, original_query=query)


async def worker(worker_id: int, worker_queue: asyncio.Queue, queue_name: str) -> None:
    while True:
        item = await worker_queue.get()
        try:
            phone = item["phone"]
            is_image_item = bool(item.get("type") == "image" or item.get("media_id"))
            if is_image_item:
                if not image_rate_limit_ok(phone):
                    await send_whatsapp_message(phone, "وصلت صور كثيرة بسرعة. الرجاء الانتظار قليلاً ثم أرسل صورة واحدة واضحة.")
                    continue
            elif not rate_limit_ok(phone):
                await send_whatsapp_message(phone, "وصلت رسائل كثيرة بسرعة. الرجاء المحاولة بعد قليل.")
                continue
            if item.get("id") and not database.mark_processed(item.get("id")):
                continue
            lock = get_user_lock(phone)
            async with lock:
                user_lock_last_seen[phone] = time.time()
                log("USER_LOCK_ACQUIRED", phone=phone, worker=f"{queue_name}-{worker_id}")
                if item.get("type") == "image" or item.get("media_id"):
                    reply = await process_image(phone, item.get("media_id"))
                else:
                    log("MESSAGE_RECEIVED", phone=phone, text=str(item.get("text", ""))[:80])
                    reply = await process_text(phone, item.get("text", ""))
                await send_reply_with_optional_interactive(phone, reply)
                user_lock_last_seen[phone] = time.time()
        except Exception as exc:
            log("WORKER_ERROR", worker=f"{queue_name}-{worker_id}", error=repr(exc))
            try:
                await send_whatsapp_message(item.get("phone", ""), "❌ حدث خطأ غير متوقع.\nأعد المحاولة، أو اكتب \"دعم\" للتواصل مع الصيدلي.")
            except Exception:
                pass
        finally:
            worker_queue.task_done()


@app.on_event("startup")
async def startup() -> None:
    global http_client
    admin.validate_admin_config(strict=True)
    database.init_db(run_production_guard=True)
    try:
        hardening_stats = database.apply_performance_hardening()
        log("DB_PERFORMANCE_HARDENING", **hardening_stats)
    except Exception as exc:
        log("DB_PERFORMANCE_HARDENING_WARNING", error=repr(exc))
    try:
        visual_memory.ensure_schema()
    except Exception as exc:
        log("VISUAL_MEMORY_SCHEMA_WARNING", error=repr(exc))
    try:
        final_stats = database.ensure_final_hardening_schema()
        log("FINAL_PRODUCTION_HARDENING", **final_stats)
    except Exception as exc:
        log("FINAL_PRODUCTION_HARDENING_WARNING", error=repr(exc))
    try:
        cleanup_stats = database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30))
        log("RUNTIME_CLEANUP", **cleanup_stats)
    except Exception as exc:
        log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
    try:
        matcher.preload_search_index()
    except Exception as exc:
        log("SEARCH_INDEX_PRELOAD_WARNING", error=repr(exc))
    http_client = httpx.AsyncClient()
    for i in range(TEXT_WORKERS):
        asyncio.create_task(worker(i + 1, text_queue, "text"))
    for i in range(IMAGE_WORKERS):
        asyncio.create_task(worker(i + 1, image_queue, "image"))
    log(
        "PRICEBOT_STARTED",
        workers=TEXT_WORKERS + IMAGE_WORKERS,
        text_workers=TEXT_WORKERS,
        image_workers=IMAGE_WORKERS,
        products=database.count_products(),
        vision="enabled" if config_env.vision_enabled() else config_env.vision_disabled_reason(),
        booking="enabled" if config_env.booking_enabled() else "disabled",
    )


@app.on_event("shutdown")
async def shutdown() -> None:
    if http_client:
        await http_client.aclose()


def _matcher_cache_stats() -> Dict[str, object]:
    try:
        from services.matching import excel_native_matcher
        return excel_native_matcher.cache_stats()
    except Exception as exc:
        return {"error": repr(exc)}


@app.get("/health")
def health():
    # Lightweight liveness probe only. It intentionally avoids integrity_check
    # and index scans so monitoring cannot slow normal WhatsApp replies.
    # products_count is a simple COUNT(*) used for quick sanity only.
    return {
        "ok": True,
        "service": "pricebot",
        "status": "alive",
        "products_count": database.count_products(),
        "queue_size": text_queue.qsize() + image_queue.qsize(),
        "text_queue_size": text_queue.qsize(),
        "image_queue_size": image_queue.qsize(),
        "workers": TEXT_WORKERS + IMAGE_WORKERS,
        "text_workers": TEXT_WORKERS,
        "image_workers": IMAGE_WORKERS,
        "rate_limit_messages": RATE_LIMIT_MESSAGES,
        "rate_limit_images": RATE_LIMIT_IMAGES,
        "user_locks_active": len(user_locks),
        "runtime_cache": database.runtime_cache_stats(),
        "matcher_cache": _matcher_cache_stats(),
        "safe_economy": database.safe_economy_stats(),
        "final_metrics": database.final_dashboard_metrics(),
    }


@app.get("/deep-health")
@app.get("/health/deep")
def deep_health():
    # Heavy diagnostics are kept separate from /health.
    return {
        "ok": True,
        "products_count": database.count_products(),
        "integrity": database.integrity_check(),
        "search_index_count": database.count_table("product_search_index"),
        "guided_index_count": database.count_table("guided_catalog_index"),
        "processed_messages_count": database.count_table("processed_messages"),
        "conversation_state_count": database.count_table("conversation_state"),
        "queue_size": text_queue.qsize() + image_queue.qsize(),
        "text_queue_size": text_queue.qsize(),
        "image_queue_size": image_queue.qsize(),
        "workers": TEXT_WORKERS + IMAGE_WORKERS,
        "text_workers": TEXT_WORKERS,
        "image_workers": IMAGE_WORKERS,
        "rate_limit_messages": RATE_LIMIT_MESSAGES,
        "rate_limit_images": RATE_LIMIT_IMAGES,
        "sqlite_performance": database.sqlite_performance_status(),
        "runtime_cache": database.runtime_cache_stats(),
        "matcher_cache": _matcher_cache_stats(),
        "safe_economy": database.safe_economy_stats(),
        "final_metrics": database.final_dashboard_metrics(),
        "user_locks_active": len(user_locks),
    }


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


def _use_celery_workers() -> bool:
    return str(os.getenv("PRICEBOT_USE_CELERY", "")).strip().lower() in {"1", "true", "yes", "on"}


def enqueue_message_fast(msg: Dict) -> bool:
    """Queue message without blocking webhook processing.

    Production can enable PRICEBOT_USE_CELERY=1 to route work to Redis/Celery
    workers. Local/single-server deployments fall back to the in-process queue.
    """
    if _use_celery_workers():
        try:
            if (msg.get("type") == "image" or msg.get("media_id")) and celery_vision_task is not None:
                celery_vision_task.delay(msg)
                return True
            if celery_text_task is not None:
                celery_text_task.delay(msg)
                return True
        except Exception as exc:
            log("CELERY_ENQUEUE_WARNING", error=repr(exc))
    try:
        target_queue = image_queue if (msg.get("type") == "image" or msg.get("media_id")) else text_queue
        target_name = "image" if target_queue is image_queue else "text"
        target_queue.put_nowait(msg)
        return True
    except asyncio.QueueFull:
        log("QUEUE_FULL", phone=msg.get("phone"), queue=target_name)
        try:
            asyncio.create_task(send_whatsapp_message(msg.get("phone", ""), "النظام مشغول حاليًا. تم استلام رسالتك وسنحاول معالجتها بعد قليل."))
        except Exception:
            pass
        return False


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    body = await request.body()
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        return PlainTextResponse("bad signature", status_code=403)
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json"}, status_code=400)
    messages = extract_messages(payload)
    queued = 0
    dropped = 0
    for msg in messages:
        if enqueue_message_fast(msg):
            queued += 1
        else:
            dropped += 1
    return {"ok": True, "queued": queued, "busy": dropped, "worker_mode": "celery" if _use_celery_workers() else "in_process"}
