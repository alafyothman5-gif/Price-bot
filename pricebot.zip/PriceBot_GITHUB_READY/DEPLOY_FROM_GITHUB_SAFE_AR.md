# تشغيل PriceBot من GitHub بطريقة آمنة

هذه النسخة مخصصة للرفع إلى GitHub. لا تحتوي على `.env` ولا قاعدة البيانات ولا البيئة الافتراضية ولا ملفات Excel المرفوعة.

## قاعدة مهمة

لا ترفع إلى GitHub:

- `.env`
- `pricebot.db`
- `.venv/`
- `import_jobs/`
- `import_reports/`
- `backups/`
- أي ملف Excel يحتوي أسعار أو مخزون حقيقي

## أول مرة على السيرفر

```bash
cd /opt
sudo git clone YOUR_GITHUB_REPO_URL pricebot_clean
cd /opt/pricebot_clean

sudo python3 -m venv .venv
sudo .venv/bin/pip install --upgrade pip
sudo .venv/bin/pip install -r requirements.txt

sudo cp .env.example .env
sudo nano .env
```

املأ القيم الحقيقية داخل `.env` على السيرفر فقط.

## لو عندك قاعدة بيانات شغالة حالياً

لا تستبدل قاعدة البيانات. انسخها من النسخة القديمة أو اتركها في نفس المسار:

```bash
/opt/pricebot_clean/pricebot.db
```

## تثبيت خدمة systemd

```bash
sudo cp pricebot.service.example /etc/systemd/system/pricebot.service
sudo systemctl daemon-reload
sudo systemctl enable pricebot.service
sudo systemctl restart pricebot.service
```

## الفحص بعد التشغيل

```bash
sudo systemctl status pricebot.service --no-pager
curl -s http://127.0.0.1:8090/catalog-health
sudo journalctl -u pricebot.service -n 120 --no-pager
```

## تحديث السيرفر لاحقاً من GitHub

```bash
cd /opt/pricebot_clean
sudo git pull
sudo .venv/bin/pip install -r requirements.txt
sudo systemctl restart pricebot.service
sudo journalctl -u pricebot.service -n 120 --no-pager
```

## روابط التشغيل الحالية

- التطبيق الداخلي: `http://127.0.0.1:8090`
- الدومين العام: `https://46.101.148.246.sslip.io`
- لوحة الرفع: `/merchant/upload`
- إعادة بناء البحث: `/merchant/rebuild-search`
