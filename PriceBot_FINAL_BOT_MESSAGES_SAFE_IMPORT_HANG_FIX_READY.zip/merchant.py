from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import tempfile
import time
import subprocess
import threading
import urllib.parse
from io import BytesIO
from pathlib import Path
from typing import Dict, List, Tuple

import qrcode
from fastapi import APIRouter, BackgroundTasks, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates

import database
from services.security import csrf
from tasks.catalog_tasks import catalog_stage_import
from catalog_ingestion.processor import (
    approve_review_item,
    job_report,
    pending_reviews,
    reject_review_item,
)
from services.catalog.staging_workflow import approve_staging_job, reject_staging_job

router = APIRouter()
templates = Jinja2Templates(directory="templates")
MERCHANT_USERNAME = os.getenv("PRICEBOT_MERCHANT_USERNAME") or os.getenv("MERCHANT_USERNAME") or "merchant"
MERCHANT_PASSWORD = os.getenv("PRICEBOT_MERCHANT_PASSWORD") or os.getenv("MERCHANT_PASSWORD") or os.getenv("MERCHANT_CODE", "")
MERCHANT_COOKIE = "pricebot_merchant_session"
MERCHANT_TTL_SECONDS = int(os.getenv("PRICEBOT_MERCHANT_SESSION_TTL_SECONDS", "21600") or 21600)
_RATE: Dict[str, list] = {}
DASHBOARD_COOKIE = "pricebot_dashboard_session"
DASHBOARD_TOKEN = (
    os.getenv("PRICEBOT_DASHBOARD_TOKEN")
    or os.getenv("MERCHANT_DASHBOARD_TOKEN")
    or os.getenv("PRICEBOT_MERCHANT_TOKEN")
    or MERCHANT_PASSWORD
    or ""
)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return forwarded or (request.client.host if request.client else "unknown")


def _rate_ok(request: Request, limit: int = 30, window: int = 60) -> bool:
    ip = _client_ip(request)
    now = time.time()
    bucket = _RATE.setdefault(ip, [])
    bucket[:] = [x for x in bucket if now - x < window]
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def _secret() -> bytes:
    key = os.getenv("PRICEBOT_MERCHANT_SESSION_SECRET") or os.getenv("PRICEBOT_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD") or MERCHANT_PASSWORD
    return (key or "missing-merchant-secret").encode("utf-8")


def _sign(payload: str) -> str:
    return hmac.new(_secret(), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _make_session(username: str) -> str:
    ts = str(int(time.time()))
    nonce = secrets.token_urlsafe(18)
    payload = f"{username}:{ts}:{nonce}"
    return f"{payload}:{_sign(payload)}"


def _session_ok(token: str) -> bool:
    try:
        username, ts, nonce, sig = (token or "").split(":", 3)
        payload = f"{username}:{ts}:{nonce}"
        return username == MERCHANT_USERNAME and hmac.compare_digest(sig, _sign(payload)) and time.time() - int(ts) <= MERCHANT_TTL_SECONDS
    except Exception:
        return False


def _require_auth(request: Request):
    if not _rate_ok(request):
        return PlainTextResponse("rate limited", status_code=429)
    if not _session_ok(request.cookies.get(MERCHANT_COOKIE, "")):
        return RedirectResponse("/merchant/login", status_code=303)
    return None


def _csrf_token(request: Request) -> str:
    return csrf.issue_token(request.cookies.get(MERCHANT_COOKIE, ""))


def _require_csrf(request: Request, token: str = ""):
    if not csrf.verify_token(token, request.cookies.get(MERCHANT_COOKIE, "")):
        database.audit_admin("merchant_csrf_rejected", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"path": str(request.url.path)})
        return PlainTextResponse("CSRF validation failed", status_code=403)
    return None


def _render(request: Request, template: str, context: Dict):
    context = dict(context)
    context.setdefault("csrf_token", _csrf_token(request))
    return templates.TemplateResponse(template, context)


def _merchant_id() -> int:
    return database.default_merchant_id()


def _merchant_nav(active: str = "dashboard") -> list[Dict]:
    items = [
        ("dashboard", "/merchant/dashboard", "📊", "الرئيسية"),
        ("upload", "/merchant/upload", "⬆️", "رفع Excel"),
        ("products", "/merchant/products", "📦", "المنتجات"),
        ("review", "/merchant/review", "🧾", "المراجعة"),
        ("analytics", "/merchant/analytics", "📈", "الإحصائيات"),
        ("settings", "/merchant/settings", "⚙️", "الإعدادات"),
        ("orders", "/merchant/orders", "🧾", "الطلبات"),
        ("share", "/merchant/share", "🔗", "رابط واتساب"),
    ]
    return [{"active": key == active, "href": href, "icon": icon, "label": label} for key, href, icon, label in items]


def _settings() -> Dict:
    return database.get_merchant_settings(_merchant_id())


def _whatsapp_link() -> str:
    import urllib.parse
    s = _settings()
    number = ''.join(ch for ch in str(s.get("whatsapp_number") or os.getenv("BOT_WHATSAPP_NUMBER") or os.getenv("WHATSAPP_PUBLIC_NUMBER") or os.getenv("ADMIN_NOTIFY_PHONE") or "") if ch.isdigit()) or "218000000000"
    pharmacy = s.get("pharmacy_name") or s.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")
    msg = s.get("qr_message") or f"السلام عليكم، أريد الاستفسار عن منتج من {pharmacy}"
    return f"https://wa.me/{number}?text={urllib.parse.quote(msg)}"


def _orders_count(status: str) -> int:
    try:
        return len(database.list_orders(status, 5000, merchant_id=_merchant_id()))
    except Exception:
        return 0




def _safe_value(fn, default=None, label: str = ""):
    try:
        return fn()
    except Exception as exc:
        print(f"MERCHANT_UI_SAFE_VALUE_ERROR | {label or getattr(fn, '__name__', 'call')} | {exc!r}", flush=True)
        return default


def _table_exists_safe(conn, table: str) -> bool:
    try:
        return bool(database.table_exists(conn, table))
    except Exception:
        return False


def _product_inventory_counts(mid: int) -> Dict[str, int]:
    def run():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "products"):
                return {"total": 0, "available": 0, "unavailable": 0, "needs_review": 0}
            cols = set(database.table_columns(conn, "products"))
            where = "WHERE merchant_id=?" if "merchant_id" in cols else ""
            params = (mid,) if where else ()
            total = int(conn.execute(f"SELECT COUNT(*) FROM products {where}", params).fetchone()[0])
            if "is_available" in cols:
                available = int(conn.execute(f"SELECT COUNT(*) FROM products {where} AND COALESCE(is_available,1)=1" if where else "SELECT COUNT(*) FROM products WHERE COALESCE(is_available,1)=1", params).fetchone()[0])
                unavailable = int(conn.execute(f"SELECT COUNT(*) FROM products {where} AND COALESCE(is_available,1)=0" if where else "SELECT COUNT(*) FROM products WHERE COALESCE(is_available,1)=0", params).fetchone()[0])
            else:
                available = total
                unavailable = 0
            if "needs_review" in cols:
                needs_review = int(conn.execute(f"SELECT COUNT(*) FROM products {where} AND COALESCE(needs_review,0)=1" if where else "SELECT COUNT(*) FROM products WHERE COALESCE(needs_review,0)=1", params).fetchone()[0])
            else:
                needs_review = 0
            return {"total": total, "available": available, "unavailable": unavailable, "needs_review": needs_review}
    return _safe_value(run, {"total": 0, "available": 0, "unavailable": 0, "needs_review": 0}, "product_inventory_counts")


def _last_upload_summary(mid: int) -> Dict[str, object]:
    def run():
        rows = database.list_product_upload_history(limit=1, merchant_id=mid)
        return rows[0] if rows else {}
    return _safe_value(run, {}, "last_upload_summary")


def _count_search_logs(days: int, mid: int) -> int:
    def run():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "search_logs"):
                return 0
            row = conn.execute(
                "SELECT COUNT(*) FROM search_logs WHERE merchant_id=? AND timestamp >= datetime('now', ?)",
                (mid, f"-{int(days)} days"),
            ).fetchone()
            return int(row[0] if row else 0)
    return _safe_value(run, 0, f"search_logs_{days}")


def _audit_count(pattern: str, days: int = 30) -> int:
    def run():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "audit_logs"):
                return 0
            row = conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE created_at >= datetime('now', ?) AND (event LIKE ? OR details LIKE ?)",
                (f"-{int(days)} days", f"%{pattern}%", f"%{pattern}%"),
            ).fetchone()
            return int(row[0] if row else 0)
    return _safe_value(run, 0, f"audit_{pattern}")


def _analytics_context(mid: int) -> Dict[str, object]:
    top_week = _safe_value(lambda: database.top_searched_products(days=7, limit=10, merchant_id=mid), [], "top_week")
    top_month = _safe_value(lambda: database.top_searched_products(days=30, limit=10, merchant_id=mid), [], "top_month")
    top_today = _safe_value(lambda: database.top_searched_products(days=1, limit=10, merchant_id=mid), [], "top_today")
    failed = _safe_value(lambda: _top_failed_queries(mid), [], "top_failed")
    metrics = {
        "search_today": _count_search_logs(1, mid),
        "search_week": _count_search_logs(7, mid),
        "image_checked": _audit_count("IMAGE", 30) + _audit_count("VISION", 30),
        "image_success": _audit_count("AI_IMAGE_PRODUCT_MATCH_CONFIRMATION_ONLY", 30),
        "exact_matches": _audit_count("EXACT_MATCH", 30),
        "confirmations": _audit_count("confirmation", 30) + _count_search_logs(30, mid),
        "low_confidence": _audit_count("LOW_CONFIDENCE", 30),
        "image_unclear": _audit_count("IMAGE_UNCLEAR", 30),
        "evidence_rejected": _audit_count("EVIDENCE_VALIDATOR_FAILED", 30),
    }
    checked = max(int(metrics["image_checked"] or 0), 0)
    success = max(int(metrics["image_success"] or 0), 0)
    metrics["image_success_rate"] = round((success / checked * 100), 1) if checked else None
    return {"top_today": top_today, "top_week": top_week, "top_month": top_month, "failed_queries": failed, "metrics": metrics}


def _top_failed_queries(mid: int) -> List[Dict[str, object]]:
    with database.connect() as conn:
        # Prefer learning inbox if present.
        if _table_exists_safe(conn, "learning_inbox"):
            cols = set(database.table_columns(conn, "learning_inbox"))
            query_col = "query" if "query" in cols else ("raw_query" if "raw_query" in cols else "")
            if query_col:
                rows = conn.execute(
                    f"SELECT {query_col} AS query, COUNT(*) AS hits FROM learning_inbox GROUP BY {query_col} ORDER BY hits DESC LIMIT 10"
                ).fetchall()
                return [database.dict_row(r) for r in rows]
        if _table_exists_safe(conn, "audit_logs"):
            rows = conn.execute(
                """
                SELECT substr(details,1,120) AS query, COUNT(*) AS hits
                FROM audit_logs
                WHERE event LIKE '%LOW_CONFIDENCE%' OR event LIKE '%NOT_AVAILABLE%' OR event LIKE '%EVIDENCE_VALIDATOR_FAILED%' OR details LIKE '%LOW_CONFIDENCE%'
                GROUP BY substr(details,1,120)
                ORDER BY hits DESC
                LIMIT 10
                """
            ).fetchall()
            return [database.dict_row(r) for r in rows]
        return []


def _merchant_dashboard_context(request: Request, *, msg: str = "", error: str = "") -> Dict[str, object]:
    mid = _merchant_id()
    inventory = _product_inventory_counts(mid)
    last_upload = _last_upload_summary(mid)
    analytics = _analytics_context(mid)
    uploads = _safe_value(lambda: database.list_product_upload_history(limit=5, merchant_id=mid), [], "uploads")
    review_items = _safe_value(lambda: database.list_review_queue(limit=8, merchant_id=mid), [], "review_items")
    return {
        "request": request,
        "title": "لوحة التاجر",
        "nav": _merchant_nav("dashboard"),
        "pharmacy_name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),
        "inventory": inventory,
        "last_upload": last_upload,
        "uploads": uploads,
        "review_items": review_items,
        "review_count": _safe_value(lambda: database.count_review_queue(merchant_id=mid), 0, "review_count"),
        "analytics": analytics,
        "top_week": analytics.get("top_week", []),
        "top_month": analytics.get("top_month", []),
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }


def _render_safe(request: Request, template: str, context: Dict, *, fallback_title: str = "PriceBot"):
    try:
        return _render(request, template, context)
    except Exception as exc:
        print(f"MERCHANT_UI_RENDER_ERROR | template={template} | error={exc!r}", flush=True)
        safe_message = str(exc)[:300]
        return HTMLResponse(
            f"""
            <!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
            <title>{fallback_title}</title><link rel='stylesheet' href='/static/css/enterprise.css'></head>
            <body><main class='main main-full' style='padding:24px'><section class='panel'>
            <h1>تعذر عرض الصفحة مؤقتاً</h1><p>تم تسجيل الخطأ في السجلات. الخدمة والبوت لم يتوقفا.</p>
            <p class='muted'>تفاصيل مختصرة: {safe_message}</p><a class='btn primary' href='/merchant/dashboard'>الرجوع للوحة</a>
            </section></main></body></html>
            """,
            status_code=200,
        )

def _dashboard_auth_ok(request: Request) -> bool:
    token = request.query_params.get("token") or ""
    cookie = request.cookies.get(DASHBOARD_COOKIE, "")
    if DASHBOARD_TOKEN and token and hmac.compare_digest(token, DASHBOARD_TOKEN):
        return True
    if DASHBOARD_TOKEN and cookie and hmac.compare_digest(cookie, _sign("dashboard:" + DASHBOARD_TOKEN)):
        return True
    return False


def _dashboard_response_with_cookie() -> RedirectResponse:
    resp = RedirectResponse("/dashboard", status_code=303)
    resp.set_cookie(
        DASHBOARD_COOKIE,
        _sign("dashboard:" + DASHBOARD_TOKEN),
        max_age=MERCHANT_TTL_SECONDS,
        httponly=True,
        secure=True,
        samesite="lax",
    )
    return resp


def _read_price_rows_from_upload(filename: str, data: bytes) -> List[Tuple[str, str]]:
    """Read name/price rows from .xlsx or .xls bytes."""
    suffix = Path(filename or "").suffix.lower()
    rows: List[List[object]] = []
    if suffix == ".xlsx":
        from openpyxl import load_workbook
        wb = load_workbook(BytesIO(data), read_only=True, data_only=True)
        ws = wb.active
        rows = [[cell for cell in row] for row in ws.iter_rows(values_only=True)]
    elif suffix == ".xls":
        import xlrd
        book = xlrd.open_workbook(file_contents=data)
        sh = book.sheet_by_index(0)
        rows = [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)]
    else:
        raise ValueError("only .xlsx and .xls files are allowed")

    if not rows:
        return []
    header = [str(x or "").strip().lower() for x in rows[0]]
    has_header = "name" in header and "price" in header
    name_idx = header.index("name") if "name" in header else 0
    price_idx = header.index("price") if "price" in header else 1
    start = 1 if has_header else 0
    out: List[Tuple[str, str]] = []
    for row in rows[start:]:
        if len(row) <= max(name_idx, price_idx):
            continue
        name = str(row[name_idx] or "").strip()
        price = str(row[price_idx] or "").strip()
        if not name:
            continue
        out.append((name, price))
    return out


def _rebuild_runtime_indexes_safely() -> Dict[str, int]:
    stats: Dict[str, int] = {}
    try:
        from search_engine import rebuild_search_index
        stats["search_index"] = int(rebuild_search_index() or 0)
    except Exception as exc:
        stats["search_index_error"] = 1
        print(f"DASHBOARD_REBUILD_SEARCH_INDEX_WARNING {exc!r}", flush=True)
    try:
        import product_identity
        stats["identity_registry"] = int(product_identity.rebuild_product_identity_registry() or 0)
    except Exception as exc:
        stats["identity_registry_error"] = 1
        print(f"DASHBOARD_REBUILD_IDENTITY_WARNING {exc!r}", flush=True)
    try:
        import guided_commerce
        stats["guided_index"] = int(guided_commerce.rebuild_guided_index() or 0)
    except Exception as exc:
        stats["guided_index_error"] = 1
        print(f"DASHBOARD_REBUILD_GUIDED_WARNING {exc!r}", flush=True)
    return stats


def _weekly_clean_name(value: object) -> str:
    return database.normalize_text(value or "")


def _weekly_unit_compact(value: str) -> str:
    text = _weekly_clean_name(value)
    # Only collapse spacing between a number and a unit. This handles safe cases
    # such as "125 mg" vs "125mg" without enabling broad fuzzy matching.
    text = re.sub(r"(\d+)\s+(mg|mcg|g|gm|ml|iu|%)\b", r"\1\2", text)
    return re.sub(r"\s+", " ", text).strip()


def _levenshtein_distance_limited(a: str, b: str, limit: int = 2) -> int:
    if abs(len(a) - len(b)) > limit:
        return limit + 1
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        row_min = i
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            val = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            cur.append(val)
            row_min = min(row_min, val)
        if row_min > limit:
            return limit + 1
        prev = cur
    return prev[-1]


def _find_very_close_weekly_candidate(cleaned: str, existing_rows: List[Dict[str, object]]) -> Tuple[object, str]:
    if not cleaned:
        return None, ""
    compact = _weekly_unit_compact(cleaned)
    hits: List[Tuple[Dict[str, object], str]] = []
    for row in existing_rows:
        existing_clean = str(row.get("cleaned_name") or "")
        existing_compact = _weekly_unit_compact(existing_clean)
        if existing_compact and existing_compact == compact:
            hits.append((row, "unit_spacing_exact"))
            continue
        # A very small typo allowance is only safe for reasonably long names.
        if len(compact) >= 8 and _levenshtein_distance_limited(compact, existing_compact, 2) <= 2:
            hits.append((row, "levenshtein<=2"))
    product_ids = {int(h[0].get("id") or 0) for h in hits if int(h[0].get("id") or 0)}
    if len(product_ids) == 1:
        return hits[0][0], hits[0][1]
    return None, "ambiguous_close_match" if len(product_ids) > 1 else ""


def _smart_weekly_products_upload(rows: List[Tuple[str, str]], filename: str) -> Dict[str, object]:
    """Weekly stock upload: update price/availability without deleting products.

    The uploaded Excel remains a simple name|price list. Exact matches and
    very-close safe matches update existing products. New/ambiguous names create
    temporary review rows. Products missing from this weekly file are marked
    is_available=0 only; they are never deleted and the legacy available flag is
    preserved so the bot can still recognize them and reply "غير متوفر".
    """
    if not rows:
        raise ValueError("file contains no product rows")
    database.init_db(run_production_guard=False)
    backup = database.backup_db("before_weekly_smart_upload")
    mid = _merchant_id()
    now_seen_ids = set()
    updated_products = 0
    matched_existing = 0
    price_updated = 0
    new_products = 0
    review_products = 0
    auto_close_matches = 0
    errors_count = 0

    # Last duplicate row wins, matching the existing catalog ingestion behavior.
    dedup: Dict[str, Tuple[str, str]] = {}
    for name, price in rows:
        clean = _weekly_clean_name(name)
        if not clean:
            continue
        dedup[clean] = (str(name or "").strip(), str(price or "").strip())

    with database.connect() as conn:
        product_cols = set(database.table_columns(conn, "products"))
        existing = []
        for r in conn.execute("SELECT id, name, price, merchant_id FROM products WHERE merchant_id=?", (mid,)).fetchall():
            d = database.dict_row(r)
            d["cleaned_name"] = _weekly_clean_name(d.get("name") or "")
            existing.append(d)
        by_clean: Dict[str, List[Dict[str, object]]] = {}
        for row in existing:
            by_clean.setdefault(str(row.get("cleaned_name") or ""), []).append(row)

        def update_existing(pid: int, name: str, price: str, *, matched_reason: str = "exact", old_price: object = "") -> None:
            nonlocal updated_products, matched_existing, price_updated, auto_close_matches
            new_price = database.safe_price(price)
            old_clean = database.safe_price(old_price)
            matched_existing += 1
            if str(old_clean) != str(new_price):
                price_updated += 1
            vals = {
                "price": new_price,
                "is_available": 1,
                "last_seen_in_upload": "__NOW__",
                "needs_review": 0,
                "review_status": "approved",
                "search_mode": "sellable",
                "quality_status": "ok",
                "updated_at": "__NOW__",
            }
            sets = []
            params = []
            for col, val in vals.items():
                if col not in product_cols:
                    continue
                if val == "__NOW__":
                    sets.append(f'{col}=datetime(\'now\')')
                else:
                    sets.append(f'{col}=?')
                    params.append(val)
            if sets:
                params.extend([int(pid), mid])
                conn.execute(f"UPDATE products SET {', '.join(sets)} WHERE id=? AND merchant_id=?", params)
            now_seen_ids.add(int(pid))
            updated_products += 1
            if matched_reason != "exact":
                auto_close_matches += 1

        def insert_review_product(name: str, price: str, reason: str, similar_existing_id: object = None) -> int:
            nonlocal new_products, review_products
            insert_vals = {
                "merchant_id": mid,
                "name": name,
                "normalized_name": database.normalize_text(name),
                "original_name": name,
                "price": database.safe_price(price),
                "available": "1",
                "is_available": 1,
                "last_seen_in_upload": "__NOW__",
                "needs_review": 1,
                "currency": "LYD",
                "quality_status": "ok",
                "review_status": "needs_review",
                "search_mode": "sellable",
                "created_at": "__NOW__",
                "updated_at": "__NOW__",
            }
            cols = [c for c in insert_vals if c in product_cols]
            col_sql = ",".join(f'"{c}"' for c in cols)
            exprs = []
            params = []
            for c in cols:
                if insert_vals[c] == "__NOW__":
                    exprs.append("datetime('now')")
                else:
                    exprs.append("?")
                    params.append(insert_vals[c])
            cur = conn.execute(f"INSERT INTO products({col_sql}) VALUES({','.join(exprs)})", params)
            temp_id = int(cur.lastrowid)
            now_seen_ids.add(temp_id)
            new_products += 1
            review_products += 1
            if database.table_exists(conn, "review_queue"):
                conn.execute(
                    """
                    INSERT INTO review_queue(merchant_id, product_name, similar_existing_id, temp_product_id, uploaded_price, reason, resolved, created_at)
                    VALUES(?,?,?,?,?,?,0,CURRENT_TIMESTAMP)
                    """,
                    (mid, name, int(similar_existing_id or 0) or None, temp_id, database.safe_price(price), reason),
                )
            return temp_id

        for clean, (name, price) in dedup.items():
            exact_hits = [h for h in by_clean.get(clean, []) if int(h.get("id") or 0)]
            if len(exact_hits) == 1:
                update_existing(int(exact_hits[0]["id"]), name, price, matched_reason="exact", old_price=exact_hits[0].get("price"))
                continue
            if len(exact_hits) > 1:
                insert_review_product(name, price, "multiple exact products share this cleaned name", exact_hits[0].get("id"))
                continue
            close, reason = _find_very_close_weekly_candidate(clean, existing)
            if close:
                update_existing(int(close["id"]), name, price, matched_reason=reason or "very_close", old_price=close.get("price"))
                continue
            insert_review_product(name, price, reason or "new product needs review", None)

        # Missing from the weekly upload means unavailable only. Never delete.
        deactivated_products = 0
        if product_cols.intersection({"is_available", "last_seen_in_upload"}):
            ids = sorted(now_seen_ids)
            if ids:
                placeholders = ",".join("?" for _ in ids)
                params = [mid] + ids
                if "is_available" in product_cols:
                    cur = conn.execute(f"UPDATE products SET is_available=0 WHERE merchant_id=? AND id NOT IN ({placeholders}) AND COALESCE(is_available,1)<>0", params)
                    deactivated_products = int(cur.rowcount or 0)
            else:
                if "is_available" in product_cols:
                    cur = conn.execute("UPDATE products SET is_available=0 WHERE merchant_id=? AND COALESCE(is_available,1)<>0", (mid,))
                    deactivated_products = int(cur.rowcount or 0)
        for table in ["product_search_index", "guided_catalog_index", "product_identity_registry"]:
            if database.table_exists(conn, table):
                conn.execute(f'DELETE FROM "{table}"')

    index_stats = _rebuild_runtime_indexes_safely()
    message = f"matched_existing={matched_existing}; price_updated={price_updated}; updated={updated_products}; new_review={new_products}; deactivated={deactivated_products}; review={review_products}; close_matches={auto_close_matches}; errors={errors_count}; backup={backup}; indexes={index_stats}"
    database.record_weekly_upload_history(
        filename=filename,
        total_rows=len(dedup),
        new_products=new_products,
        updated_products=updated_products,
        deactivated_products=deactivated_products,
        review_products=review_products,
        status="success",
        message=message,
        merchant_id=mid,
    )
    return {
        "count": len(dedup),
        "backup": str(backup),
        "matched_existing": matched_existing,
        "price_updated": price_updated,
        "updated_products": updated_products,
        "new_products": new_products,
        "deactivated_products": deactivated_products,
        "review_products": review_products,
        "auto_close_matches": auto_close_matches,
        "errors": errors_count,
        "index_stats": index_stats,
    }




def _restart_pricebot_service() -> str:
    if str(os.getenv("PRICEBOT_DASHBOARD_SKIP_RESTART", "")).strip().lower() in {"1", "true", "yes", "on"}:
        return "restart skipped by PRICEBOT_DASHBOARD_SKIP_RESTART"
    try:
        result = subprocess.run(["sudo", "systemctl", "restart", "pricebot.service"], text=True, capture_output=True, timeout=30)
        if result.returncode == 0:
            return "pricebot.service restarted"
        return f"restart warning: {result.stderr or result.stdout}"[:500]
    except Exception as exc:
        return f"restart warning: {exc!r}"



@router.get("/dashboard", response_class=HTMLResponse)
def legacy_dashboard_redirect(request: Request, token: str = ""):
    """Backward-compatible legacy dashboard URL.

    The new merchant UI uses /merchant/login and /merchant/dashboard.  A valid
    token may bootstrap a merchant session, but /dashboard never renders the old
    fragile template directly, which prevents 502 from stale dashboard code.
    """
    if token and DASHBOARD_TOKEN and hmac.compare_digest(token, DASHBOARD_TOKEN):
        resp = RedirectResponse("/merchant/dashboard", status_code=303)
        resp.set_cookie(MERCHANT_COOKIE, _make_session(MERCHANT_USERNAME), max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
        return resp
    if _session_ok(request.cookies.get(MERCHANT_COOKIE, "")):
        return RedirectResponse("/merchant/dashboard", status_code=303)
    return RedirectResponse("/merchant/login", status_code=303)


@router.post("/dashboard/upload")
async def legacy_dashboard_upload_redirect(request: Request, file: UploadFile = File(...), csrf_token: str = Form("")):
    # Keep old forms working. New UI posts to /merchant/upload.
    return await merchant_upload_post(request, file=file, csrf_token=csrf_token)


@router.get("/admin/dashboard", response_class=HTMLResponse)
def pharmacy_admin_dashboard_alias(request: Request, token: str = "", msg: str = "", error: str = ""):
    if token and DASHBOARD_TOKEN and hmac.compare_digest(token, DASHBOARD_TOKEN):
        resp = RedirectResponse("/admin/dashboard", status_code=303)
        resp.set_cookie(DASHBOARD_COOKIE, _sign("dashboard:" + DASHBOARD_TOKEN), max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
        return resp
    # The admin router owns /admin.  This alias exists only for old links when
    # the admin module does not provide /admin/dashboard in older deployments.
    return RedirectResponse("/admin", status_code=303)


@router.post("/admin/upload")
async def pharmacy_admin_upload_alias(request: Request, file: UploadFile = File(...), csrf_token: str = Form("")):
    return await merchant_upload_post(request, file=file, csrf_token=csrf_token)


@router.post("/admin/review/resolve")
def dashboard_review_resolve(
    request: Request,
    item_id: int = Form(...),
    action: str = Form(...),
    existing_product_id: str = Form(""),
    csrf_token: str = Form(""),
):
    # Accept either merchant session or legacy dashboard token cookie.
    if not (_session_ok(request.cookies.get(MERCHANT_COOKIE, "")) or _dashboard_auth_ok(request)):
        return RedirectResponse("/merchant/login", status_code=303)
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        eid = int(existing_product_id) if str(existing_product_id or "").strip().isdigit() else None
        database.resolve_review_queue_item(int(item_id), action, existing_product_id=eid, merchant_id=_merchant_id())
        _rebuild_runtime_indexes_safely()
        return RedirectResponse("/merchant/review?msg=" + urllib.parse.quote("✅ تم تحديث عنصر المراجعة."), status_code=303)
    except Exception as exc:
        return RedirectResponse("/merchant/review?error=" + urllib.parse.quote(str(exc)[:250]), status_code=303)


@router.get("/merchant/login", response_class=HTMLResponse)
def login(request: Request, error: str = ""):
    warning = "" if MERCHANT_PASSWORD else "اضبط PRICEBOT_MERCHANT_USERNAME و PRICEBOT_MERCHANT_PASSWORD في .env."
    return templates.TemplateResponse("login.html", {"request": request, "title": "Merchant Login", "heading": "دخول التاجر", "subtitle": "إدارة الطلبات والكتالوج ورابط واتساب.", "error": error, "warning": warning})


@router.post("/merchant/login")
def do_login(request: Request, username: str = Form(...), password: str = Form(...)):
    if not _rate_ok(request, limit=10, window=60):
        return PlainTextResponse("rate limited", status_code=429)
    if not MERCHANT_PASSWORD or username != MERCHANT_USERNAME or not hmac.compare_digest(password, MERCHANT_PASSWORD):
        database.audit_admin("merchant_login_failed", actor=username, ip=_client_ip(request))
        return RedirectResponse("/merchant/login?error=بيانات الدخول غير صحيحة", status_code=303)
    token = _make_session(username)
    database.audit_admin("merchant_login_ok", actor=username, ip=_client_ip(request), details={"merchant_id": _merchant_id()})
    resp = RedirectResponse("/merchant/dashboard", status_code=303)
    resp.set_cookie(MERCHANT_COOKIE, token, max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
    return resp


@router.post("/merchant/logout")
def logout(request: Request, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    resp = RedirectResponse("/merchant/login", status_code=303)
    resp.delete_cookie(MERCHANT_COOKIE)
    return resp



@router.get("/merchant", response_class=HTMLResponse)
def merchant_home_redirect(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return RedirectResponse("/merchant/dashboard", status_code=303)


@router.get("/merchant/dashboard", response_class=HTMLResponse)
def merchant_dashboard(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    context = _merchant_dashboard_context(request, msg=msg, error=error)
    return _render_safe(request, "merchant_dashboard_professional.html", context, fallback_title="لوحة التاجر")



@router.get("/merchant/upload", response_class=HTMLResponse)
def merchant_upload_page(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    context = {
        "request": request,
        "title": "رفع قائمة الأسعار",
        "nav": _merchant_nav("upload"),
        "uploads": _safe_value(lambda: database.list_product_upload_history(limit=5, merchant_id=_merchant_id()), [], "upload_page_history"),
        "import_jobs": _safe_value(lambda: database.list_import_jobs(limit=5, merchant_id=_merchant_id()), [], "import_jobs"),
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_upload.html", context, fallback_title="رفع Excel")



def _job_storage_dir() -> Path:
    try:
        base = database.get_db_path().parent / "import_jobs"
    except Exception:
        base = Path(tempfile.gettempdir()) / "pricebot_import_jobs"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _process_weekly_upload_job(job_id: int, saved_path: str, filename: str) -> None:
    """Background weekly upload job.

    It keeps heavy Excel parsing/upsert out of the HTTP request.  No DELETE FROM
    products is used; the existing smart weekly upload marks missing products
    unavailable only and records review rows for ambiguous/new names.
    """
    try:
        database.update_import_job(job_id, status="PROCESSING", progress=5, summary="بدء قراءة الملف")
        path = Path(saved_path)
        data = path.read_bytes()
        rows = _read_price_rows_from_upload(filename, data)
        database.update_import_job(job_id, progress=25, summary=f"تمت قراءة {len(rows)} صف")
        result = _smart_weekly_products_upload(rows, filename)
        database.update_import_job(
            job_id,
            progress=90,
            updated=int(result.get("updated_products") or result.get("matched_existing") or 0),
            inserted=int(result.get("new_products") or 0),
            unmatched=int(result.get("review_products") or 0),
            skipped=int(result.get("deactivated_products") or 0),
            summary=(
                f"matched_existing={result.get('matched_existing', 0)} | "
                f"price_updated={result.get('price_updated', 0)} | "
                f"inserted_new={result.get('new_products', 0)} | "
                f"marked_unavailable={result.get('deactivated_products', 0)} | "
                f"needs_review={result.get('review_products', 0)} | errors={result.get('errors', 0)}"
            ),
        )
        restart_msg = _restart_pricebot_service()
        database.update_import_job(job_id, status="DONE", progress=100, summary=f"اكتمل الرفع. {restart_msg}")
        print(f"WEEKLY_UPLOAD_JOB_DONE | job_id={job_id} | {result}", flush=True)
    except Exception as exc:
        print(f"WEEKLY_UPLOAD_JOB_FAILED | job_id={job_id} | {exc!r}", flush=True)
        try:
            database.update_import_job(job_id, status="FAILED", progress=100, error=repr(exc), summary="فشل الرفع")
            database.record_weekly_upload_history(
                filename=filename,
                total_rows=0,
                new_products=0,
                updated_products=0,
                deactivated_products=0,
                review_products=0,
                status="failed",
                message=repr(exc),
                merchant_id=_merchant_id(),
            )
        except Exception:
            pass


@router.get("/merchant/job/{job_id}", response_class=HTMLResponse)
def merchant_job_page(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "import_job")
    context = {"request": request, "title": "حالة الاستيراد", "nav": _merchant_nav("upload"), "job": job, "csrf_token": _csrf_token(request)}
    return _render_safe(request, "merchant_import_job.html", context, fallback_title="حالة الاستيراد")


@router.get("/merchant/job_status/{job_id}")
def merchant_job_status(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "import_job_status")
    return job or {"status": "NOT_FOUND"}


@router.get("/admin/job_status/{job_id}")
def admin_job_status(request: Request, job_id: int):
    # Compatibility endpoint requested for polling.  It uses the same merchant
    # session guard here because this router owns merchant/admin dashboard UI.
    auth = _require_auth(request)
    if auth:
        return auth
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "admin_import_job_status")
    return job or {"status": "NOT_FOUND"}

@router.post("/merchant/upload", response_class=HTMLResponse)
async def merchant_upload_post(request: Request, file: UploadFile = File(...), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    filename = file.filename or "products.xlsx"
    suffix = Path(filename).suffix.lower()
    if suffix not in {".xlsx", ".xls"}:
        return RedirectResponse("/merchant/upload?error=" + urllib.parse.quote("يسمح فقط بملفات xlsx أو xls"), status_code=303)
    try:
        data = await file.read()
        if not data:
            return RedirectResponse("/merchant/upload?error=" + urllib.parse.quote("الملف فارغ"), status_code=303)
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", filename)[:180] or "upload.xlsx"
        saved_path = _job_storage_dir() / f"{int(time.time())}_{secrets.token_hex(4)}_{safe_name}"
        saved_path.write_bytes(data)
        job_id = database.create_import_job(filename, str(saved_path), job_type="weekly_upload", merchant_id=_merchant_id())
        threading.Thread(target=_process_weekly_upload_job, args=(int(job_id), str(saved_path), filename), daemon=True).start()
        return RedirectResponse(f"/merchant/job/{int(job_id)}", status_code=303)
    except Exception as exc:
        print(f"MERCHANT_WEEKLY_UPLOAD_QUEUE_ERROR | {exc!r}", flush=True)
        return RedirectResponse("/merchant/upload?error=" + urllib.parse.quote(str(exc)[:250]), status_code=303)


def _preview_products(needs_review: object = None, limit: int = 20, only_new_seen: bool = False) -> List[Dict[str, object]]:
    with database.connect() as conn:
        if not _table_exists_safe(conn, "products"):
            return []
        cols = set(database.table_columns(conn, "products"))
        where = ["merchant_id=?"] if "merchant_id" in cols else []
        params: List[object] = [_merchant_id()] if "merchant_id" in cols else []
        if needs_review is not None and "needs_review" in cols:
            where.append("COALESCE(needs_review,0)=?")
            params.append(1 if needs_review else 0)
        if only_new_seen and "last_seen_in_upload" in cols:
            where.append("last_seen_in_upload >= datetime('now','-2 hours')")
        sql_where = ("WHERE " + " AND ".join(where)) if where else ""
        order = "ORDER BY id DESC"
        rows = conn.execute(f"SELECT * FROM products {sql_where} {order} LIMIT ?", params + [int(limit or 20)]).fetchall()
        return [database.dict_row(r) for r in rows]


@router.get("/merchant/review", response_class=HTMLResponse)
def merchant_review_page(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    items = _safe_value(lambda: database.list_review_queue(limit=100, merchant_id=_merchant_id()), [], "review_page")
    review_products = _safe_value(lambda: _preview_products(needs_review=True, limit=100), [], "review_products")
    context = {
        "request": request,
        "title": "قائمة المراجعة",
        "nav": _merchant_nav("review"),
        "items": items,
        "review_products": review_products,
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_review.html", context, fallback_title="قائمة المراجعة")


@router.post("/merchant/review/resolve")
def merchant_review_resolve(
    request: Request,
    item_id: int = Form(...),
    action: str = Form(...),
    existing_product_id: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        eid = int(existing_product_id) if str(existing_product_id or "").strip().isdigit() else None
        database.resolve_review_queue_item(int(item_id), action, existing_product_id=eid, merchant_id=_merchant_id())
        _rebuild_runtime_indexes_safely()
        return RedirectResponse("/merchant/review?msg=" + urllib.parse.quote("✅ تم تحديث عنصر المراجعة."), status_code=303)
    except Exception as exc:
        return RedirectResponse("/merchant/review?error=" + urllib.parse.quote(str(exc)[:250]), status_code=303)


@router.get("/merchant/analytics", response_class=HTMLResponse)
def merchant_analytics_page(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    context = {
        "request": request,
        "title": "الإحصائيات",
        "nav": _merchant_nav("analytics"),
        "analytics": _analytics_context(_merchant_id()),
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_analytics.html", context, fallback_title="الإحصائيات")


@router.get("/merchant/settings", response_class=HTMLResponse)
def merchant_settings_page(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    context = {
        "request": request,
        "title": "إعدادات الصيدلية",
        "nav": _merchant_nav("settings"),
        "settings": _settings(),
        "whatsapp_link": _whatsapp_link(),
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_settings.html", context, fallback_title="الإعدادات")


@router.get("/merchant/logout")
def logout_get(request: Request):
    resp = RedirectResponse("/merchant/login", status_code=303)
    resp.delete_cookie(MERCHANT_COOKIE)
    return resp


@router.get("/merchant/catalog", response_class=HTMLResponse)
def merchant_catalog_redirect(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return RedirectResponse("/merchant/upload", status_code=303)


@router.get("/merchant/orders", response_class=HTMLResponse)
def merchant_orders(request: Request, status: str = "pending"):
    auth = _require_auth(request)
    if auth:
        return auth
    if status not in {"pending", "confirmed", "done", "rejected"}:
        status = "pending"
    return _render(request, "merchant_orders.html", {"request": request, "title": "Merchant Orders", "nav": _merchant_nav("orders"), "orders": database.list_orders(status, 300, merchant_id=_merchant_id()), "status": status})


@router.post("/merchant/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str, csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status, merchant_id=_merchant_id())
    database.audit_admin("merchant_order_status_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"order_id": order_id, "status": status, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/orders", status_code=303)


@router.get("/merchant/share", response_class=HTMLResponse)
def merchant_share(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return _render(request, "merchant_share.html", {"request": request, "title": "QR & Link", "nav": _merchant_nav("share"), "whatsapp_link": _whatsapp_link(), "settings": _settings()})


@router.post("/merchant/settings")
def merchant_settings_update(
    request: Request,
    pharmacy_name: str = Form(""),
    whatsapp_number: str = Form(""),
    qr_message: str = Form(""),
    working_hours: str = Form("24 ساعة"),
    delivery_enabled: str = Form("0"),
    currency: str = Form("LYD"),
    welcome_text: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    database.update_merchant_settings(_merchant_id(), pharmacy_name, whatsapp_number, qr_message, working_hours, delivery_enabled, currency, welcome_text)
    database.audit_admin("merchant_settings_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/settings?msg=" + urllib.parse.quote("✅ تم حفظ الإعدادات"), status_code=303)


@router.get("/merchant/qr.png")
def merchant_qr(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    img = qrcode.make(_whatsapp_link())
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


@router.get("/merchant/catalog", response_class=HTMLResponse)
def merchant_catalog(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    jobs = database.list_catalog_import_jobs(20)
    reviews = pending_reviews(limit=80)
    return _render(request, "merchant_catalog.html", {"request": request, "title": "Merchant Catalog", "nav": _merchant_nav("catalog"), "jobs": jobs, "reviews": reviews})


@router.post("/merchant/catalog/upload")
async def merchant_catalog_upload(request: Request, background_tasks: BackgroundTasks, file: UploadFile = File(...), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    suffix = Path(file.filename or "upload.xlsx").suffix or ".xlsx"
    tmpdir = Path(tempfile.mkdtemp(prefix="pricebot_merchant_catalog_"))
    excel_path = tmpdir / ("upload" + suffix)
    excel_path.write_bytes(await file.read())
    job_id = database.create_catalog_import_job(file.filename or "upload.xlsx", str(excel_path), status="queued")
    database.update_catalog_import_job(job_id, job_type="merchant_staging_import", merchant_id=_merchant_id(), requires_approval=1, report_text="Merchant upload queued for staging. Production unchanged until admin approval.")
    if os.getenv("PRICEBOT_USE_CELERY", "").lower() in {"1", "true", "yes", "on"}:
        try:
            catalog_stage_import.delay(int(job_id), str(excel_path), int(_merchant_id()))
        except Exception:
            background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(_merchant_id()))
    else:
        background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(_merchant_id()))
    database.audit_admin("merchant_catalog_staging_queued", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"job_id": job_id, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/catalog", status_code=303)


@router.get("/merchant/catalog/jobs/{job_id}", response_class=HTMLResponse)
def merchant_catalog_job(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    report = job_report(int(job_id))
    return _render(request, "merchant_catalog_job.html", {"request": request, "title": f"Catalog Job #{job_id}", "nav": _merchant_nav("catalog"), "job_id": job_id, "report": report})


@router.post("/merchant/catalog/jobs/{job_id}/approve")
def merchant_catalog_job_approve(
    request: Request,
    job_id: int,
    csrf_token: str = Form(""),
    full_inventory_upload: str = Form(""),
    mark_missing_unavailable: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        approve_staging_job(
            int(job_id),
            actor=MERCHANT_USERNAME,
            full_inventory_upload=str(full_inventory_upload).lower() in {"1", "true", "yes", "on"},
            mark_missing_unavailable=str(mark_missing_unavailable).lower() in {"1", "true", "yes", "on"},
        )
    except Exception as exc:
        database.audit_admin("merchant_catalog_approve_failed", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"job_id": job_id, "error": repr(exc)})
        return PlainTextResponse(f"approval failed: {type(exc).__name__}: {exc}", status_code=500)
    return RedirectResponse(f"/merchant/catalog/jobs/{job_id}", status_code=303)


@router.post("/merchant/catalog/jobs/{job_id}/reject")
def merchant_catalog_job_reject(request: Request, job_id: int, reason: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    reject_staging_job(int(job_id), actor=MERCHANT_USERNAME, reason=reason)
    return RedirectResponse("/merchant/catalog", status_code=303)


@router.post("/merchant/catalog/review/{review_id}/approve")
def merchant_catalog_review_approve(
    request: Request,
    review_id: int,
    suggested_brand: str = Form(""),
    suggested_family: str = Form(""),
    suggested_category: str = Form(""),
    suggested_form: str = Form(""),
    suggested_strength: str = Form(""),
    suggested_size: str = Form(""),
    suggested_pack: str = Form(""),
    suggested_aliases: str = Form(""),
    review_notes: str = Form(""),
    resolved_product_id: str = Form(""),
    apply_price: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        approve_review_item(
            int(review_id),
            actor=MERCHANT_USERNAME,
            suggested_brand=suggested_brand,
            suggested_family=suggested_family,
            suggested_category=suggested_category,
            suggested_form=suggested_form,
            suggested_strength=suggested_strength,
            suggested_size=suggested_size,
            suggested_pack=suggested_pack,
            suggested_aliases=suggested_aliases,
            review_notes=review_notes,
            resolved_product_id=resolved_product_id,
            apply_price=apply_price,
        )
    except Exception as exc:
        database.audit_admin("merchant_review_approve_failed", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"review_id": review_id, "error": repr(exc)})
        return PlainTextResponse(f"review approval failed: {type(exc).__name__}: {exc}", status_code=500)
    referer = request.headers.get("referer") or "/merchant/catalog"
    return RedirectResponse(referer, status_code=303)


@router.post("/merchant/catalog/review/{review_id}/reject")
def merchant_catalog_review_reject(request: Request, review_id: int, reason: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    reject_review_item(int(review_id), actor=MERCHANT_USERNAME, reason=reason)
    referer = request.headers.get("referer") or "/merchant/catalog"
    return RedirectResponse(referer, status_code=303)


@router.get("/merchant/learning", response_class=HTMLResponse)
def merchant_learning(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    items = database.list_learning_inbox("pending", 100)
    return _render(request, "merchant_learning.html", {"request": request, "title": "Merchant Learning", "nav": _merchant_nav("learning"), "items": items})



@router.get("/merchant/products", response_class=HTMLResponse)
def merchant_products(request: Request, q: str = "", availability: str = "all", review: str = "all"):
    auth = _require_auth(request)
    if auth:
        return auth
    def load_products():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "products"):
                return []
            cols = set(database.table_columns(conn, "products"))
            where = []
            params: List[object] = []
            if "merchant_id" in cols:
                where.append("merchant_id=?")
                params.append(_merchant_id())
            nq = q.strip()
            if nq:
                key = f"%{database.normalize_text(nq)}%"
                if "normalized_name" in cols:
                    where.append("(normalized_name LIKE ? OR name LIKE ?)")
                    params.extend([key, f"%{nq}%"])
                else:
                    where.append("name LIKE ?")
                    params.append(f"%{nq}%")
            if availability == "available" and "is_available" in cols:
                where.append("COALESCE(is_available,1)=1")
            elif availability == "unavailable" and "is_available" in cols:
                where.append("COALESCE(is_available,1)=0")
            if review == "needs_review" and "needs_review" in cols:
                where.append("COALESCE(needs_review,0)=1")
            elif review == "approved" and "needs_review" in cols:
                where.append("COALESCE(needs_review,0)=0")
            sql_where = "WHERE " + " AND ".join(where) if where else ""
            rows = conn.execute(f"SELECT * FROM products {sql_where} ORDER BY id DESC LIMIT 300", params).fetchall()
            return [database.dict_row(r) for r in rows]
    products = _safe_value(load_products, [], "merchant_products")
    return _render_safe(request, "merchant_products.html", {
        "request": request,
        "title": "المنتجات",
        "nav": _merchant_nav("products"),
        "products": products,
        "q": q,
        "availability": availability,
        "review": review,
        "csrf_token": _csrf_token(request),
    }, fallback_title="المنتجات")


@router.post("/merchant/products/{product_id}/price")
def merchant_product_price(request: Request, product_id: int, price: str = Form(...), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    with database.connect() as conn:
        conn.execute("UPDATE products SET price=?, updated_at=datetime('now') WHERE id=? AND merchant_id=?", (price.strip(), int(product_id), _merchant_id()))
    database.audit_admin("merchant_product_price_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"product_id": product_id, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/products", status_code=303)
