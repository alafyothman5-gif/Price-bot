# README_TESTING - PriceBot V2

## 1. Install dependencies
```bash
python -m venv venv
./venv/bin/pip install -r requirements.txt
```

## 2. Import current catalog into a fresh test DB
```bash
./venv/bin/python tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/pricebot_v2_test.sqlite
```

Expected important lines:
```text
PRODUCT_IDENTITY_REGISTRY_OK count=5791
IMPORT_MASTER_EXCEL_OK ... products_after=5791 ... search_index=40358 guided_index=3577 identity_registry=5791 integrity=ok
```

## 3. Run all acceptance tests
```bash
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_v2_test.sqlite
```

Expected output:
```text
ACCEPTANCE_TESTS_PASS=23
SAFE_MATCHING_ACCEPTANCE_PASS=82
ACCEPTANCE_TESTS_ALL_PASS=105
```

## 4. Mandatory manual checks
Text:
- `Panadol` must return clarification.
- `فلاجيل` must return clarification.
- `MEBO scar` must return exact match.
- `Rilastil xerolact PB` must return not available without unrelated products.
- `Cerave Hydrating Cleanser` must show cleanser-only alternatives.

Vision:
- `MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym` must resolve to `mebo scar`.
- `Pro-D3 50,000 IU Vitamin K2 15 capsules` must resolve to Pro-D3 50,000 IU.
- `100 ml oral suspension Remedica` must be low confidence/front-view request.

## Original PriceList conversion test

```bash
./venv/bin/python tools/prepare_pricelist_excel.py PriceList.xls --out products_master_ready.xlsx --report CATALOG_IMPORT_REPORT.md
./venv/bin/python tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/pricebot_catalog_test.db
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_catalog_test.db
```

Expected:

```text
products_after=5791
product_identity_registry=5791
ACCEPTANCE_TESTS_ALL_PASS=106
```
