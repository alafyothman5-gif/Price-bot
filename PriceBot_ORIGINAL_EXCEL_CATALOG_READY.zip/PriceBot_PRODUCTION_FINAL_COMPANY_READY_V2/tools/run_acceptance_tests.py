#!/usr/bin/env python3
import argparse
import os
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database


def _run(path: Path) -> None:
    try:
        runpy.run_path(str(path), run_name="__main__")
    except SystemExit as exc:
        if exc.code not in (0, None):
            raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db-path", required=True)
    args = parser.parse_args()
    database.configure_db_path(args.db_path)
    os.environ["PRICEBOT_DB_PATH"] = args.db_path
    _run(ROOT / "tests" / "acceptance_ui_flow.py")
    _run(ROOT / "tests" / "acceptance_safe_matching.py")
    print("ACCEPTANCE_TESTS_ALL_PASS=106")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
