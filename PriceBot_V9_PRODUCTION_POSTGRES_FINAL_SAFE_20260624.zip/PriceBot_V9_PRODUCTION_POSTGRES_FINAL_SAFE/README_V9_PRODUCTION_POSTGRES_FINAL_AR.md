# PriceBot V9 Production PostgreSQL Final Safe

هذه آخر نسخة تطوير قبل التشغيل الفعلي. لا تحتوي على `.env` الحقيقي ولا `pricebot.db`.

## أهم ما أُضيف في V9

- نقل الإنتاج إلى PostgreSQL محلي مجاني على نفس السيرفر.
- سكربت إنشاء PostgreSQL + مستخدم + قاعدة بيانات + ترحيل SQLite إلى PostgreSQL.
- PostgreSQL connection pool عبر `psycopg_pool`.
- جدول `schema_migrations` لتسجيل الترحيلات المستقبلية.
- فهارس PostgreSQL للأداء.
- `/health` يعرض محرك قاعدة البيانات وحالة pool.
- endpoint داخلي آمن لإعادة تحميل الفهرس بعد تحديث المنتجات:
  `/internal/reload-index`
- حماية إضافية لصيغة `media_id` قبل تحميل وسائط واتساب.
- سكربت rollback كامل للرجوع للنسخة السابقة إذا فشل التشغيل.

## ما سيحدث عند التشغيل لاحقًا

شغّل فقط:

```bash
bash INSTALL_V9_ON_SERVER.sh
```

السكربت سيقوم بـ:

1. عمل backup كامل للنسخة الحالية.
2. حفظ `.env` و `pricebot.db` و systemd و Caddyfile.
3. تثبيت PostgreSQL محليًا مجانًا على نفس السيرفر.
4. إنشاء قاعدة `pricebot` ومستخدم `pricebot`.
5. ترحيل المنتجات وكل الجداول من SQLite إلى PostgreSQL.
6. تحديث `.env` تلقائيًا بـ `DATABASE_URL`.
7. تشغيل الخدمة على V9.
8. فحص `/health` والتأكد أن `database_engine.engine = postgres`.

## ملاحظات مهمة

- لا تشغل هذه النسخة الآن إلا عندما تقرر التشغيل النهائي.
- لا ترفع النسخ التي تحتوي قاعدة البيانات إلى GitHub.
- هذه النسخة آمنة للرفع لأنها لا تحتوي قاعدة البيانات ولا المفاتيح.
- PostgreSQL هنا مجاني لأنه مثبت على نفس الـ VPS الحالي، ولا يحتاج خدمة خارجية مدفوعة.

## rollback

إذا فشل التشغيل، السكربت يحاول الرجوع تلقائيًا. ويمكن الرجوع يدويًا بالأمر الذي سيطبعه السكربت:

```bash
bash /root/PRICEBOT_SAFE_BACKUPS/pricebot_pre_v9_postgres_*/RESTORE_PRE_V9.sh
```
