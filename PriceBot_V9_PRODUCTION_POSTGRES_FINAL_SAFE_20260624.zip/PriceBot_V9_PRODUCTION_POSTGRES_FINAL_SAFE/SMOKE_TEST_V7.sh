#!/usr/bin/env bash
set -euo pipefail
PORT="${PORT:-8090}"
cd /opt/pricebot_whatsapp_gemini
. .venv/bin/activate
python -m py_compile app.py matcher_index.py state_store.py vision_service.py config_env.py database.py
echo "COMPILE_OK"
echo "===== HEALTH IMPORTANT FIELDS ====="
curl -sS "http://127.0.0.1:${PORT}/health" | python3 -c '
import sys,json
d=json.load(sys.stdin)
keys=[
"ok","final_ui_version","matcher_index_enabled","redis_state_enabled",
"products_count","workers","text_workers","image_workers",
"text_queue_size","image_queue_size","text_queue_maxsize","image_queue_maxsize",
"webhook_signature_required","meta_app_secret_configured","security_warnings",
"send_retry","media_download_retry","vision_retry"
]
for k in keys:
    print(f"{k}: {d.get(k)}")
print("redis:", d.get("redis"))
print("rate_limiters:", d.get("rate_limiters"))
'
