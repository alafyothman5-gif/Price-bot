# PriceBot WhatsApp — V7 Resilience Build

هذه نسخة تطوير مبنية على النسخة الشغالة V6B/V6C بدون تغيير تجربة المستخدم وبدون تغيير منطق Gemini الأساسي.

## المسار المتوقع على السيرفر
`/opt/pricebot_whatsapp_gemini`

## الخدمة
`pricebot-whatsapp-gemini.service`

## المنفذ
`127.0.0.1:8090`

## النسخة المتوقعة في health
`final_ui_version: v7_resilience_redis_rate_queue_retry`

## أهم ما أضيف في V7
1. Redis/Valkey rate limiter مشترك بين uvicorn workers.
2. Global webhook rate limit لحماية `/webhook`.
3. Queue safety: عند امتلاء queue يرجع webhook `503` بدل إسقاط الرسائل بصمت، حتى Meta يعيد المحاولة.
4. Queue item timeout: الرسائل القديمة داخل queue لا تعلق للأبد، ويرسل للزبون رسالة انشغال.
5. WhatsApp send retry للأخطاء المؤقتة فقط مع exponential backoff.
6. WhatsApp media download retry للأخطاء المؤقتة فقط.
7. Gemini/OpenRouter vision retry للأخطاء المؤقتة فقط: timeout / network / 429 / 5xx.
8. Redis reconnect و health واضح: لا يوجد fallback صامت للذاكرة إذا `REDIS_URL` موجود إلا عند تفعيل `PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK=1`.
9. Health أوضح: Redis، rate limiters، queues، token config، signature warnings.
10. Graceful shutdown: ينتظر تفريغ queues لفترة محددة قبل إلغاء العمال.
11. Structured JSON logging في `app.py`.

## لم يتغير
- لا يوجد dashboard أو صفحة ويب.
- منطق Gemini لا يزال مسؤولًا عن قراءة الصورة فقط.
- المطابقة المحلية الصارمة V6B باقية.
- Patch إخفاء OCR/Gemini عند غير متوفر باقٍ.
- رسالة غير المتوفر للزبون تبقى: `غير متوفر حاليًا في الصيدلية.`

## أوامر بعد التنصيب
```bash
curl -sS http://127.0.0.1:8090/health | python3 -m json.tool
systemctl status pricebot-whatsapp-gemini --no-pager
journalctl -u pricebot-whatsapp-gemini -f --no-pager
redis-cli ping
```

## اختبار واتساب المطلوب
1. السلام عليكم → تظهر القائمة.
2. Panadol → قائمة.
3. Rilastil → قائمة.
4. Rilastil xerolact PB → يطابق xerolact PB baume أو يسأل تأكيد لو غير متأكد.
5. صورة Coveram 5/5 → لا يقترح Coveram 10/5؛ إذا غير موجود يقول غير متوفر حاليًا.
6. صورة منتج غير موجود → غير متوفر حاليًا.
7. روشتة → يرفض ويطلب صورة علبة منتج فقط.
