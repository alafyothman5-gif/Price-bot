# PriceBot V7 Resilience — Clean Safe Package

هذه نسخة V7 نظيفة وآمنة للإرسال أو الرفع الخاص.

## مهم
- لا تحتوي على `pricebot.db`.
- لا تحتوي على `.env` الحقيقي.
- تحتوي على `.env.example` مع إخفاء المفاتيح والأرقام.
- مبنية على V6B/V6C مع إضافات V7 للاستقرار والتحمل.

## أهم ما تحتويه
- Redis/Valkey state + Redis rate limiter.
- Global webhook rate limit.
- Queue maxsize + queue item timeout.
- HTTP 503 عند ازدحام queue.
- Retry لإرسال WhatsApp وتحميل الوسائط وVision/Gemini للأخطاء المؤقتة.
- Graceful shutdown.
- Health أقوى.
- Strict matching من V6B/V6C.

## طريقة التشغيل
استخدم `INSTALL_OR_UPDATE_ON_SERVER.sh` على السيرفر بعد أخذ Backup.

## قاعدة البيانات
هذه النسخة لا تحتوي قاعدة البيانات. سكربت التنصيب يحافظ على قاعدة السيرفر الموجودة في:
`/opt/pricebot_whatsapp_gemini/pricebot.db`
