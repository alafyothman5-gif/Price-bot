# PriceBot V8.2 Release Candidate Safe

هذه نسخة Release Candidate قبل التشغيل النهائي.

## الحالة
- لا تُشغَّل الآن إلا عند قرار النشر.
- لا تحتوي `.env` الحقيقي.
- لا تحتوي `pricebot.db`.
- مخصصة للرفع لاحقًا وتشغيلها مرة واحدة فوق النسخة الشغالة على السيرفر.

## مبنية على
- النسخة الشغالة V6B/V6C التي عُدلت من التيرمنل.
- إضافات V7 resilience.
- إضافات V8 stability.
- فحوصات V8.1 pre-deploy.

## أهم ما فيها
- Redis/Valkey state.
- Redis rate limit.
- Queue safety.
- Retry لإرسال WhatsApp وتحميل الصور وVision transient errors.
- Strict matching.
- Strength conflict protection.
- Generic one-token list behavior.
- Customer OCR/Gemini leak protection.
- Health موسع.
- Startup warnings.
- Graceful shutdown.
- سكربت rollback تلقائي إذا فشل التشغيل.

## نسخة health المتوقعة بعد التشغيل
`final_ui_version: v8_2_release_candidate_safe`

## سكربت التشغيل لاحقًا
```bash
bash INSTALL_V8_2_ON_SERVER.sh
```

## سكربت الفحص قبل التشغيل
```bash
bash scripts/predeploy_check.sh
```

## سكربت فحص الإصدار داخل الحزمة
```bash
bash scripts/release_audit.sh
```

## ملاحظة مهمة
سكربت التشغيل مصمم للسيرفر الحالي فقط، لأنه يحتاج أن يجد:
- `/opt/pricebot_whatsapp_gemini/.env`
- `/opt/pricebot_whatsapp_gemini/pricebot.db`

إذا لم يجدهما، يتوقف ولا يكمل.
