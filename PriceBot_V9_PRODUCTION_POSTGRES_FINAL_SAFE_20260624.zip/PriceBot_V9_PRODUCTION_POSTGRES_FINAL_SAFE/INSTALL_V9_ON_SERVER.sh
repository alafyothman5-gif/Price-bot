#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/pricebot_whatsapp_gemini"
SERVICE="pricebot-whatsapp-gemini"
PORT="8090"
BACKUP_ROOT="/root/PRICEBOT_SAFE_BACKUPS"
BACKUP_DIR="$BACKUP_ROOT/pricebot_pre_v9_postgres_$(date +%Y%m%d_%H%M%S)"
AUTO_ROLLBACK_AVAILABLE=0

info(){ echo; echo "===== $* ====="; }
warn(){ echo "WARNING: $*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }

ensure_env(){
  local key="$1" val="$2"
  if grep -q "^${key}=" "$APP_DIR/.env" 2>/dev/null; then return 0; fi
  printf '\n%s=%s\n' "$key" "$val" >> "$APP_DIR/.env"
}

set_env(){
  local key="$1" val="$2"
  if grep -q "^${key}=" "$APP_DIR/.env" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${val}|" "$APP_DIR/.env"
  else
    printf '\n%s=%s\n' "$key" "$val" >> "$APP_DIR/.env"
  fi
}

on_error(){
  local line="$1"
  echo
  echo "INSTALL_FAILED at line $line"
  if [ "$AUTO_ROLLBACK_AVAILABLE" = "1" ] && [ "${PRICEBOT_NO_AUTO_ROLLBACK:-0}" != "1" ]; then
    echo "Running automatic rollback..."
    bash "$BACKUP_DIR/RESTORE_PRE_V9.sh" || true
  else
    echo "Auto rollback not available yet."
  fi
  echo "Manual restore command when available: bash $BACKUP_DIR/RESTORE_PRE_V9.sh"
}
trap 'on_error $LINENO' ERR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

info "PACKAGE PREFLIGHT"
[ -d "$SCRIPT_DIR/app" ] || fail "app directory missing in package"
for f in app.py matcher_index.py database.py state_store.py vision_service.py config_env.py requirements.txt .env.example; do
  [ -f "$SCRIPT_DIR/app/$f" ] || fail "missing package file: app/$f"
done
[ -f "$SCRIPT_DIR/app/tools/migrate_sqlite_to_postgres.py" ] || fail "missing PostgreSQL migration tool"
[ -f "$SCRIPT_DIR/scripts/setup_postgres_and_migrate.sh" ] || fail "missing PostgreSQL setup script"
if find "$SCRIPT_DIR" -type f \( -name '.env' -o -name 'pricebot.db' -o -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.db-wal' -o -name '*.db-shm' \) | grep -q .; then
  fail "unsafe package: real .env or database file is inside the ZIP folder"
fi

info "SERVER PREFLIGHT"
[ -d "$APP_DIR" ] || fail "current app dir not found: $APP_DIR"
[ -f "$APP_DIR/.env" ] || fail "server .env missing: $APP_DIR/.env"
[ -f "$APP_DIR/pricebot.db" ] || fail "server SQLite database missing for migration: $APP_DIR/pricebot.db"

info "INSTALL TOOLS"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3-venv sqlite3 rsync curl openssl postgresql postgresql-contrib redis-tools

info "CREATE FULL BACKUP BEFORE V9"
mkdir -p "$BACKUP_DIR"
rsync -a "$APP_DIR"/ "$BACKUP_DIR/app/"
cp "$APP_DIR/.env" "$BACKUP_DIR/.env"
sqlite3 "$APP_DIR/pricebot.db" ".backup '$BACKUP_DIR/pricebot.db'"
cp "/etc/systemd/system/${SERVICE}.service" "$BACKUP_DIR/${SERVICE}.service" 2>/dev/null || true
cp "/etc/caddy/Caddyfile" "$BACKUP_DIR/Caddyfile" 2>/dev/null || true

cat > "$BACKUP_DIR/RESTORE_PRE_V9.sh" <<RESTORE
#!/usr/bin/env bash
set -euo pipefail
SERVICE="$SERVICE"
APP_DIR="$APP_DIR"
BACKUP_DIR="$BACKUP_DIR"
echo "===== RESTORE PRE V9 BACKUP ====="
systemctl stop "\$SERVICE" || true
rm -rf "\$APP_DIR"
mkdir -p "\$APP_DIR"
rsync -a "\$BACKUP_DIR/app/" "\$APP_DIR/"
[ -f "\$BACKUP_DIR/.env" ] && cp "\$BACKUP_DIR/.env" "\$APP_DIR/.env"
[ -f "\$BACKUP_DIR/pricebot.db" ] && cp "\$BACKUP_DIR/pricebot.db" "\$APP_DIR/pricebot.db"
[ -f "\$BACKUP_DIR/${SERVICE}.service" ] && cp "\$BACKUP_DIR/${SERVICE}.service" "/etc/systemd/system/${SERVICE}.service"
[ -f "\$BACKUP_DIR/Caddyfile" ] && cp "\$BACKUP_DIR/Caddyfile" "/etc/caddy/Caddyfile" && systemctl reload caddy || true
systemctl daemon-reload
systemctl reset-failed "\$SERVICE" || true
systemctl start "\$SERVICE"
sleep 5
curl -sS http://127.0.0.1:8090/health || true
echo
systemctl is-active "\$SERVICE"
echo "RESTORE_DONE"
RESTORE
chmod +x "$BACKUP_DIR/RESTORE_PRE_V9.sh"
AUTO_ROLLBACK_AVAILABLE=1

echo "Backup saved: $BACKUP_DIR"
echo "Rollback command: bash $BACKUP_DIR/RESTORE_PRE_V9.sh"

info "STOP CURRENT SERVICE"
systemctl stop "$SERVICE" || true
sleep 2

info "FREE PORT $PORT FROM OLD PRICEBOT PROCESSES ONLY"
PIDS="$(ss -lntp 2>/dev/null | grep ":$PORT " | grep -oE 'pid=[0-9]+' | cut -d= -f2 | sort -u || true)"
if [ -n "$PIDS" ]; then
  for PID in $PIDS; do
    CMD="$(ps -p "$PID" -o cmd= 2>/dev/null || true)"
    echo "PID $PID => $CMD"
    if echo "$CMD" | grep -q "uvicorn" && echo "$CMD" | grep -Eq "pricebot_whatsapp_gemini|pricebot_clean"; then
      kill "$PID" || true
      sleep 1
      kill -9 "$PID" 2>/dev/null || true
    else
      fail "port $PORT is used by a non-PriceBot process; refusing to kill it"
    fi
  done
fi

info "DEPLOY V9 CODE WHILE PRESERVING .env AND SQLite source"
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"
rsync -a "$SCRIPT_DIR/app/" "$APP_DIR/" \
  --exclude ".env" \
  --exclude ".env.example" \
  --exclude "pricebot.db" \
  --exclude "*.db-wal" \
  --exclude "*.db-shm" \
  --exclude "__pycache__"
cp "$BACKUP_DIR/.env" "$APP_DIR/.env"
cp "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
chmod 600 "$APP_DIR/.env" || true
chmod 600 "$APP_DIR/pricebot.db" || true

info "ENSURE V9 ENV DEFAULTS"
set_env REDIS_URL "redis://127.0.0.1:6379/0"
ensure_env PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK 0
ensure_env PRICEBOT_RATE_LIMIT_FAIL_OPEN 0
ensure_env PRICEBOT_GLOBAL_RATE_LIMIT_REQUESTS 600
ensure_env PRICEBOT_GLOBAL_RATE_LIMIT_WINDOW_SECONDS 60
ensure_env PRICEBOT_RATE_LIMIT_MESSAGES 90
ensure_env PRICEBOT_RATE_LIMIT_IMAGES 15
ensure_env PRICEBOT_RATE_LIMIT_WINDOW_SECONDS 60
ensure_env PRICEBOT_TEXT_QUEUE_MAXSIZE 8000
ensure_env PRICEBOT_IMAGE_QUEUE_MAXSIZE 1500
ensure_env PRICEBOT_QUEUE_ITEM_TIMEOUT_SECONDS 45
ensure_env PRICEBOT_WEBHOOK_BUSY_STATUS_CODE 503
ensure_env PRICEBOT_WHATSAPP_SEND_RETRY_ATTEMPTS 3
ensure_env PRICEBOT_MEDIA_DOWNLOAD_RETRY_ATTEMPTS 3
ensure_env PRICEBOT_VISION_RETRY_ATTEMPTS 3
ensure_env PRICEBOT_VISION_RETRY_BASE_DELAY_SECONDS 0.5
ensure_env PRICEBOT_SHUTDOWN_DRAIN_TIMEOUT_SECONDS 15
ensure_env PRICEBOT_HTTP_KEEPALIVE 60
ensure_env PRICEBOT_HTTP_MAX_CONNECTIONS 160
ensure_env PRICEBOT_TEXT_WORKERS 20
ensure_env PRICEBOT_IMAGE_WORKERS 6
ensure_env PRICEBOT_IMAGE_CONCURRENCY 5
ensure_env PRICEBOT_PRODUCT_INDEX_TTL_SECONDS 300
ensure_env PRICEBOT_POSTGRES_POOL_ENABLED 1
ensure_env PRICEBOT_POSTGRES_POOL_MIN 1
ensure_env PRICEBOT_POSTGRES_POOL_MAX 10
ensure_env PRICEBOT_POSTGRES_POOL_REQUIRED 0
ensure_env PRICEBOT_INTERNAL_RELOAD_TOKEN "$(openssl rand -hex 24)"

if grep -q '^META_APP_SECRET=.' "$APP_DIR/.env" && ! grep -Eq '^META_APP_SECRET=(\*\*\*SET_ME\*\*\*|CHANGE_ME|set_me|)$' "$APP_DIR/.env"; then
  set_env PRICEBOT_REQUIRE_META_SIGNATURE true
else
  set_env PRICEBOT_REQUIRE_META_SIGNATURE false
  warn "META_APP_SECRET is missing/placeholder. Signature verification is disabled to avoid breaking webhook; set META_APP_SECRET later then enable it."
fi

info "CREATE VENV AND INSTALL REQUIREMENTS"
cd "$APP_DIR"
python3 -m venv .venv
. "$APP_DIR/.venv/bin/activate"
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

info "COMPILE CHECK"
python -m py_compile app.py matcher_index.py state_store.py vision_service.py config_env.py database.py tools/migrate_sqlite_to_postgres.py
echo "COMPILE_OK"

info "MIGRATE SQLITE TO LOCAL POSTGRESQL"
APP_DIR="$APP_DIR" PRICEBOT_SQLITE_SOURCE="$APP_DIR/pricebot.db" bash "$SCRIPT_DIR/scripts/setup_postgres_and_migrate.sh"

info "WRITE SYSTEMD SERVICE"
cat > "/etc/systemd/system/${SERVICE}.service" <<SERVICEFILE
[Unit]
Description=PriceBot WhatsApp V9 Production PostgreSQL Final
After=network.target postgresql.service valkey-server.service
Wants=postgresql.service valkey-server.service

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
Environment=PYTHONUNBUFFERED=1
Environment=PORT=${PORT}
ExecStart=${APP_DIR}/.venv/bin/uvicorn app:app --host 127.0.0.1 --port ${PORT} --workers 2
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
SERVICEFILE

systemctl daemon-reload
systemctl reset-failed "$SERVICE" || true
systemctl enable "$SERVICE"
systemctl start "$SERVICE"

info "WAIT HEALTH"
HEALTH_OK=0
for i in $(seq 1 60); do
  if curl -sS "http://127.0.0.1:$PORT/health" >/tmp/pricebot_v9_health.json 2>/dev/null; then
    HEALTH_OK=1
    cat /tmp/pricebot_v9_health.json
    echo
    break
  fi
  echo "waiting... $i"
  sleep 2
done
[ "$HEALTH_OK" = "1" ] || fail "health endpoint did not respond after start"

info "IMPORTANT HEALTH FIELDS"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/tmp/pricebot_v9_health.json')
d=json.loads(p.read_text())
required = {
    'final_ui_version': 'v9_production_postgres_final_safe',
    'matcher_index_enabled': True,
    'queue_safety_enabled': True,
    'redis_rate_limit_enabled': True,
    'customer_ocr_leak_protection': True,
    'v9_production_postgres_final': True,
}
failed=[]
for k, expected in required.items():
    print(f'{k}: {d.get(k)}')
    if d.get(k) != expected:
        failed.append((k, d.get(k), expected))
for k in ['products_count','redis_state_enabled','workers','text_workers','image_workers','startup_warnings','security_warnings','database_engine']:
    print(f'{k}: {d.get(k)}')
engine=(d.get('database_engine') or {}).get('engine')
if engine != 'postgres':
    failed.append(('database_engine.engine', engine, 'postgres'))
if failed:
    raise SystemExit('health required fields mismatch: ' + repr(failed))
PY

info "SERVICE"
systemctl is-active "$SERVICE"
echo "V9_INSTALL_RESULT=OK"
echo "Backup path: $BACKUP_DIR"
echo "Rollback command: bash $BACKUP_DIR/RESTORE_PRE_V9.sh"
