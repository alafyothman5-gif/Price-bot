from __future__ import annotations

import asyncio
import os
import re
import time
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Set

import database
from normalizer import clean_query, normalize_text

GENERIC_TOKENS = {
    "mg", "mcg", "g", "gm", "ml", "iu", "tab", "tabs", "tablet", "tablets", "cap", "caps",
    "capsule", "capsules", "syrup", "cream", "creme", "gel", "spray", "drop", "drops", "solution",
    "oral", "coated", "film", "enteric", "x", "pack", "box", "pcs", "piece", "tube", "bottle",
    "balm", "lotion", "wash", "cleanser", "serum", "face", "skin", "spf", "new", "original",
    "دواء", "الدواء", "علبة", "علبه", "حبوب", "كبسول", "كبسولات", "شراب", "مرهم", "كريم", "جل",
    "قطرة", "بخاخ", "اقراص", "أقراص", "شريط", "حبة", "حبه", "صورة", "صوره", "منتج", "المنتج",
}

PRESCRIPTION_HINTS = {
    "rx", "prescription", "doctor", "patient", "diagnosis", "dose", "dosage", "clinic", "hospital",
    "روشتة", "روشته", "وصفة", "وصفه", "دكتور", "طبيب", "عيادة", "عياده", "مريض", "تشخيص", "جرعة", "الجرعة",
}


_STRENGTH_UNITS = r"(?:mg|mcg|g|gm|ml|iu|%)"


def _num_norm(value: str) -> str:
    v = str(value or "").strip().lower().replace(",", ".")
    if not v:
        return ""
    try:
        f = float(v)
        if f.is_integer():
            return str(int(f))
        return f"{f:.4f}".rstrip("0").rstrip(".")
    except Exception:
        return v


def strength_signature(value: Any) -> Dict[str, Any]:
    """Extract medicinal strength signals without treating pack counts as strength.

    This prevents matching one strength ratio to a different strength ratio and similar high-risk
    substitutions. It intentionally ignores plain pack numbers like 30 tablets.
    """
    text = normalize_text(str(value or "")).lower()
    text = text.replace("／", "/").replace("⁄", "/")
    pairs: Set[str] = set()
    nums: List[str] = []

    # 10/5, 5mg/5mg, 200mg/5ml
    for m in re.finditer(rf"(\d+(?:\.\d+)?)\s*(?:{_STRENGTH_UNITS})?\s*/\s*(\d+(?:\.\d+)?)\s*(?:{_STRENGTH_UNITS})?", text):
        a = _num_norm(m.group(1))
        b = _num_norm(m.group(2))
        if a and b:
            pairs.add(f"{a}/{b}")
            nums.extend([a, b])

    # 5mg, 200 mg, 5 ml
    for m in re.finditer(rf"(\d+(?:\.\d+)?)\s*{_STRENGTH_UNITS}\b", text):
        n = _num_norm(m.group(1))
        if n:
            nums.append(n)

    # if two unit strengths appear next to each other, form a pair too
    if len(nums) >= 2:
        pairs.add(f"{nums[0]}/{nums[1]}")

    return {"pairs": pairs, "nums": nums, "num_set": set(nums)}


def strength_conflicts(query: Any, product_text: Any) -> bool:
    q = strength_signature(query)
    p = strength_signature(product_text)

    q_pairs = q["pairs"]
    p_pairs = p["pairs"]
    q_nums = q["nums"]
    p_nums = p["nums"]
    p_num_set = p["num_set"]

    if not q_pairs and not q_nums:
        return False

    # If both sides express a ratio/combination, it must match exactly.
    if q_pairs and p_pairs and not (q_pairs & p_pairs):
        return True

    if q_pairs and p_pairs:
        return False

    # If no product strength exists, do not reject solely on strength.
    if not p_nums:
        return False

    # If query contains multiple strength numbers, all must be present.
    if len(set(q_nums)) >= 2 and not set(q_nums).issubset(p_num_set):
        return True

    return False


def tokens(value: Any, *, include_generic: bool = False) -> List[str]:
    n = normalize_text(str(value or ""))
    raw = re.findall(r"[a-zA-Z0-9]+|[\u0600-\u06FF]+", n)
    out: List[str] = []
    seen = set()
    for token in raw:
        t = token.strip().lower()
        if not t:
            continue
        if len(t) < 2 and not t.isdigit():
            continue
        if not include_generic:
            if t in GENERIC_TOKENS:
                continue
            if re.fullmatch(r"\d+(?:mg|ml|g|gm|mcg|iu)?", t):
                continue
        if t not in seen:
            out.append(t)
            seen.add(t)
    return out


def product_name(product: Dict[str, Any]) -> str:
    return str(product.get("canonical_display_name") or product.get("name") or product.get("original_name") or "").strip()


def product_price(product: Dict[str, Any], default_currency: str = "LYD") -> str:
    price = str(product.get("price") or "").strip()
    currency = str(product.get("currency") or default_currency or "LYD").strip()
    return f"{price} {currency}".strip() if price else ""


def looks_like_prescription(text: Any) -> bool:
    n = normalize_text(text or "")
    return any(h in n for h in PRESCRIPTION_HINTS)


class ProductIndex:
    """Fast in-memory inverted index over visible products.

    Search no longer scans every product on each customer request. Products are
    loaded periodically and token-to-product mappings reduce each query to a
    small candidate set. Gemini/Vision logic remains untouched; this class only
    matches extracted or typed text against the current inventory.
    """

    def __init__(self, ttl_seconds: int = 300, max_candidates: int = 250) -> None:
        self.ttl_seconds = int(ttl_seconds or 300)
        self.max_candidates = int(max_candidates or 250)
        self.products: Dict[int, Dict[str, Any]] = {}
        self.product_tokens: Dict[int, Set[str]] = {}
        self.product_name_tokens: Dict[int, List[str]] = {}
        self.token_to_ids: Dict[str, Set[int]] = defaultdict(set)
        self.vocab: Set[str] = set()
        self.loaded_at = 0.0
        self.build_lock = asyncio.Lock()

    @property
    def age_seconds(self) -> float:
        return max(0.0, time.time() - self.loaded_at) if self.loaded_at else 999999.0

    def _product_text(self, p: Dict[str, Any], alias_map: Optional[Dict[int, List[str]]] = None) -> str:
        pid = int(p.get("id") or 0)
        fields = [
            "name", "original_name", "canonical_display_name", "brand", "company", "product_family",
            "active_ingredient", "form", "strength", "size", "pack", "barcode", "aliases", "ocr_keywords",
            "category", "subcategory", "main_section", "sub_section", "product_type", "medicine_form",
        ]
        parts = [str(p.get(f) or "") for f in fields]
        if alias_map and pid in alias_map:
            parts.extend(alias_map.get(pid) or [])
        return " ".join(parts)

    def _load_alias_map(self) -> Dict[int, List[str]]:
        out: Dict[int, List[str]] = {}
        try:
            for row in database.load_product_alias_rows(active_only=True):
                pid = int(row.get("product_id") or row.get("product_db_id") or 0)
                alias = str(row.get("alias_text") or row.get("alias") or row.get("cleaned_alias") or "").strip()
                if pid and alias:
                    out.setdefault(pid, []).append(alias)
        except Exception:
            pass
        return out

    async def refresh(self, force: bool = False) -> None:
        if not force and self.loaded_at and self.age_seconds < self.ttl_seconds:
            return
        async with self.build_lock:
            if not force and self.loaded_at and self.age_seconds < self.ttl_seconds:
                return
            alias_map = self._load_alias_map()
            rows = database.load_product_rows(visible_only=True)
            products: Dict[int, Dict[str, Any]] = {}
            product_terms: Dict[int, Set[str]] = {}
            product_name_terms: Dict[int, List[str]] = {}
            token_to_ids: Dict[str, Set[int]] = defaultdict(set)
            vocab: Set[str] = set()
            for raw in rows:
                try:
                    pid = int(raw.get("id") or 0)
                except Exception:
                    pid = 0
                name = product_name(raw)
                if not pid or not name:
                    continue
                p = dict(raw)
                text = self._product_text(p, alias_map)
                p_tokens = set(tokens(text))
                n_tokens = tokens(name)
                if not p_tokens:
                    continue
                products[pid] = p
                product_terms[pid] = p_tokens
                product_name_terms[pid] = n_tokens
                for token in p_tokens:
                    token_to_ids[token].add(pid)
                    vocab.add(token)
            self.products = products
            self.product_tokens = product_terms
            self.product_name_tokens = product_name_terms
            self.token_to_ids = token_to_ids
            self.vocab = vocab
            self.loaded_at = time.time()

    async def ensure_fresh(self) -> None:
        await self.refresh(force=False)

    def get(self, product_id: int) -> Optional[Dict[str, Any]]:
        return self.products.get(int(product_id or 0))

    def _candidate_ids(self, q_tokens: List[str]) -> Set[int]:
        ids: Set[int] = set()
        for token in q_tokens:
            if token in self.token_to_ids:
                ids.update(self.token_to_ids[token])
            elif len(token) >= 4:
                # Vocabulary scan only, not product scan; handles small OCR/typing variants.
                for vocab_token in self.vocab:
                    if token in vocab_token or vocab_token in token:
                        ids.update(self.token_to_ids.get(vocab_token, set()))
        if len(ids) > self.max_candidates:
            # Prefer products containing the first meaningful token when a brand query is broad.
            first = q_tokens[0] if q_tokens else ""
            first_ids = set(self.token_to_ids.get(first, set()))
            if first_ids:
                ids = first_ids
        return ids

    def _score(self, query: str, q_tokens: List[str], p: Dict[str, Any]) -> int:
        pid = int(p.get("id") or 0)
        q_norm = normalize_text(query)
        q_compact = q_norm.replace(" ", "")
        name = product_name(p)
        name_norm = normalize_text(name)
        raw_hay = self._product_text(p)
        hay = normalize_text(raw_hay)
        hay_compact = hay.replace(" ", "")
        if strength_conflicts(query, raw_hay):
            return -999999
        p_tokens = self.product_tokens.get(pid, set())
        n_tokens = self.product_name_tokens.get(pid, [])
        matched = [t for t in q_tokens if t in p_tokens or (len(t) >= 4 and t in hay_compact)]
        if not matched and not (q_norm and (q_norm in name_norm or q_norm in hay)):
            return -999999
        score = 0
        if name_norm == q_norm:
            score += 25000
        if q_norm and q_norm in name_norm:
            score += 1800
        if name_norm and name_norm in q_norm:
            score += 1500
        if q_compact and len(q_compact) >= 5 and q_compact in hay_compact:
            score += 1100
        if q_tokens:
            unique_hits = len(set(matched))
            score += unique_hits * 320
            if unique_hits == len(set(q_tokens)):
                score += 1100
        if q_tokens and n_tokens and q_tokens[0] == n_tokens[0]:
            score += 1000
        if len(q_tokens) == 1 and n_tokens:
            if n_tokens[0] == q_tokens[0]:
                score += 1400
            elif q_tokens[0] in n_tokens:
                score += 700
        extra = [t for t in n_tokens if t not in set(matched)]
        score -= min(len(extra) * 6, 90)
        return score

    async def search(self, query: Any, limit: int = 80) -> List[Dict[str, Any]]:
        await self.ensure_fresh()
        cleaned = clean_query(str(query or "").strip()) or str(query or "").strip()
        q_tokens = tokens(cleaned)
        q_norm = normalize_text(cleaned)
        if not q_tokens and not q_norm:
            return []
        ids = self._candidate_ids(q_tokens)
        # For one-word brand/family queries, include all indexed products where the token appears
        # in the searchable product text. This makes generic brand-only searches show a list.
        if len(q_tokens) == 1 and len(q_tokens[0]) >= 3:
            qt = q_tokens[0]
            for pid, p in self.products.items():
                hay_all = normalize_text(self._product_text(p))
                if qt in hay_all:
                    ids.add(pid)
        # If exact phrase is long and token candidate is empty, use safe substring over indexed products only as a fallback.
        if not ids and len(q_norm) >= 5:
            for pid, p in self.products.items():
                if q_norm in normalize_text(product_name(p)):
                    ids.add(pid)
        scored: List[Dict[str, Any]] = []
        for pid in ids:
            p = self.products.get(pid)
            if not p:
                continue
            score = self._score(cleaned, q_tokens, p)
            if score <= -999999:
                continue
            item = dict(p)
            item["_score"] = score
            item["_name_token_count"] = len(self.product_name_tokens.get(pid, []))
            scored.append(item)
        scored.sort(key=lambda x: (-int(x.get("_score") or 0), int(x.get("_name_token_count") or 99), len(product_name(x)), product_name(x).lower()))
        return self._dedupe(scored)[:limit]

    def _dedupe(self, items: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        seen = set()
        for p in items:
            key = f"{normalize_text(product_name(p))}|{str(p.get('price') or '').strip()}"
            if key in seen:
                continue
            seen.add(key)
            out.append(p)
        return out

    def should_show_list(self, query: Any, candidates: List[Dict[str, Any]]) -> bool:
        if len(candidates) <= 1:
            return False
        q_tokens = tokens(query)
        q_norm = normalize_text(query)
        exact = [p for p in candidates if normalize_text(product_name(p)) == q_norm]
        if len(exact) == 1 and len(q_tokens) > 1:
            return False
        if len(q_tokens) <= 1:
            return True
        if len(q_tokens) == 2:
            return True
        top = int(candidates[0].get("_score") or 0)
        second = int(candidates[1].get("_score") or 0)
        return (top - second) < 180

    def direct_match_ok(self, query: Any, candidates: List[Dict[str, Any]]) -> bool:
        if not candidates:
            return False
        if len(tokens(query)) <= 1:
            return False
        if self.should_show_list(query, candidates):
            return False
        top = candidates[0]
        if normalize_text(product_name(top)) == normalize_text(query):
            return True
        second = int(candidates[1].get("_score") or 0) if len(candidates) > 1 else 0
        return int(top.get("_score") or 0) >= 2200 and int(top.get("_score") or 0) - second >= 450

    async def memory_lookup(self, query: Any) -> Optional[Dict[str, Any]]:
        # Do not use learned memory for generic one-token searches.
        if len(tokens(query)) <= 1:
            return None
        try:
            hit = database.lookup_safe_text_memory(query)
            if hit and hit.get("product") and database.product_visible(hit.get("product"), guided=False):
                return hit.get("product")
        except Exception:
            pass
        try:
            alias_hit = database.lookup_product_by_alias_exact([query], ignore_articles=True)
            if alias_hit.get("status") == "EXACT_ALIAS_MATCH" and alias_hit.get("product"):
                p = alias_hit.get("product")
                if p and database.product_visible(p, guided=False):
                    return p
        except Exception:
            pass
        return None

# PRICEBOT_V6B_STRICT_MATCH_RUNTIME_PATCH
# General strict matching patch:
# - prevents strength mismatch such as 5/5 -> 10/5 and 500mg -> 250mg
# - prevents weak multi-token matches where a multi-token query would otherwise match only by brand
# - does not change Gemini/Vision extraction logic

import re as _pb_re

_PB_DIGITS_TRANS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_PB_STRENGTH_UNITS = r"(?:mg|mcg|g|gm|ml|iu|%)"


def _pb_raw(value):
    return str(value or "").translate(_PB_DIGITS_TRANS).lower().replace("／", "/").replace("⁄", "/")


def _pb_num_norm(value):
    v = str(value or "").strip().lower().replace(",", ".")
    try:
        f = float(v)
        if f.is_integer():
            return str(int(f))
        return f"{f:.4f}".rstrip("0").rstrip(".")
    except Exception:
        return v


def strength_signature(value):
    raw = _pb_raw(value)

    pairs = set()
    singles = []

    # 5/5, 10/5, 5mg/5mg, 200mg/5ml
    for m in _pb_re.finditer(
        rf"(\d+(?:\.\d+)?)\s*(?:{_PB_STRENGTH_UNITS})?\s*/\s*(\d+(?:\.\d+)?)\s*(?:{_PB_STRENGTH_UNITS})?",
        raw,
    ):
        a = _pb_num_norm(m.group(1))
        b = _pb_num_norm(m.group(2))
        if a and b:
            pairs.add(f"{a}/{b}")
            singles.extend([a, b])

    # 500mg, 250 mg, 5ml
    for m in _pb_re.finditer(rf"(\d+(?:\.\d+)?)\s*{_PB_STRENGTH_UNITS}\b", raw):
        n = _pb_num_norm(m.group(1))
        if n:
            singles.append(n)

    return {
        "pairs": pairs,
        "singles": singles,
        "single_set": set(singles),
    }


def strength_conflicts(query, product_text):
    q = strength_signature(query)
    p = strength_signature(product_text)

    q_pairs = q["pairs"]
    p_pairs = p["pairs"]

    q_singles = q["singles"]
    p_singles = p["singles"]
    p_single_set = p["single_set"]

    # If both have ratio strengths, they must intersect exactly.
    if q_pairs and p_pairs:
        return not bool(q_pairs & p_pairs)

    # If query has ratio but product has only single strengths, all ratio numbers must exist.
    if q_pairs and p_singles:
        q_nums = set()
        for pair in q_pairs:
            q_nums.update(pair.split("/"))
        return not q_nums.issubset(p_single_set)

    # If query has unit strengths and product has unit strengths, query numbers must exist.
    if q_singles and p_singles:
        return not set(q_singles).issubset(p_single_set)

    return False


def _pb_product_text_for_index(self, product):
    try:
        return self._product_text(product)
    except Exception:
        if isinstance(product, dict):
            return " ".join(str(v or "") for v in product.values())
        return str(product or "")


def _pb_close_token(a, b):
    a = str(a or "").lower().strip()
    b = str(b or "").lower().strip()
    if not a or not b:
        return False
    if a == b:
        return True
    if len(a) >= 4 and len(b) >= 4 and (a in b or b in a):
        return True
    return False


if not hasattr(ProductIndex, "_v6b_original_search"):
    ProductIndex._v6b_original_search = ProductIndex.search

    async def _v6b_strict_search(self, query, limit=20):
        expanded_limit = max(int(limit or 20) * 5, 80)
        candidates = await ProductIndex._v6b_original_search(self, query, limit=expanded_limit)

        q_tokens = tokens(query)
        filtered = []

        for product in candidates:
            p_text = _pb_product_text_for_index(self, product)

            # Reject any clear strength mismatch.
            if strength_conflicts(query, p_text):
                continue

            # For multi-token queries, avoid weak matches that only share brand.
            # Example: a multi-token query must not match a different product by brand-only overlap.
            if len(q_tokens) >= 2:
                p_tokens = set(tokens(p_text))
                matched = 0

                for qt in q_tokens:
                    if any(_pb_close_token(qt, pt) for pt in p_tokens):
                        matched += 1

                if matched < 2:
                    continue

            filtered.append(product)

            if len(filtered) >= int(limit or 20):
                break

        return filtered

    ProductIndex.search = _v6b_strict_search
