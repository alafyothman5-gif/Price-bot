# PriceBot V8.1 Pre-Deploy Checked Safe

هذه نسخة V8.1 النهائية قبل التشغيل.

## الإضافات فوق V8

- سكربت فحص قبل التشغيل: `scripts/predeploy_check.sh`
- سكربت اختبار ضغط آمن بدون إرسال واتساب: `scripts/load_test_text_webhook.sh`
- README تشغيل ورجوع واضح: `README_DEPLOY_AR.md`
- تحديث version في health إلى:
  - `final_ui_version: v8_1_predeploy_checked_safe`
  - `v8_1_predeploy_checked: true`
- مراجعة أمان ZIP:
  - لا يوجد `.env` حقيقي.
  - لا توجد قاعدة بيانات.
  - لا توجد مفاتيح API.

## لا تغييرات على منطق Gemini

لم يتم تغيير منطق Gemini/Vision. التطويرات هنا تشغيل وفحص وحماية فقط.
