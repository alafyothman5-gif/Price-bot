# تشغيل PriceBot V8.2 Release Candidate لاحقًا

## لا تشغل الآن
هذه النسخة جاهزة للتشغيل لاحقًا عندما تقرر الانتقال من النسخة الحالية إلى V8.2.

## قبل التشغيل
تأكد أن السيرفر الحالي ما زال يحتوي:

```bash
/opt/pricebot_whatsapp_gemini/.env
/opt/pricebot_whatsapp_gemini/pricebot.db
```

وتأكد أن Valkey/Redis يعمل:

```bash
redis-cli ping
```

المتوقع:

```text
PONG
```

## التشغيل لاحقًا
بعد رفع وفك ضغط النسخة على السيرفر، ادخل مجلد النسخة وشغل:

```bash
bash scripts/predeploy_check.sh
bash INSTALL_V8_2_ON_SERVER.sh
```

## ماذا يفعل سكربت التشغيل؟
- يرفض التشغيل إذا لم يجد `.env` أو `pricebot.db` على السيرفر.
- يعمل backup كامل قبل أي تعديل.
- يحفظ `.env` الحقيقي.
- يحفظ `pricebot.db`.
- يحفظ systemd service.
- يحفظ Caddyfile إن وجد.
- ينشر الكود الجديد فقط.
- يبني venv.
- يفحص compile.
- يشغل الخدمة.
- يفحص `/health`.
- إذا فشل التشغيل، يحاول rollback تلقائيًا.

## مكان النسخ الاحتياطية
```bash
/root/PRICEBOT_SAFE_BACKUPS/pricebot_pre_v8_2_YYYYMMDD_HHMMSS
```

## الرجوع اليدوي
إذا أردت الرجوع يدويًا:

```bash
bash /root/PRICEBOT_SAFE_BACKUPS/pricebot_pre_v8_2_YYYYMMDD_HHMMSS/RESTORE_PRE_V8_2.sh
```

## فحص health بعد التشغيل
```bash
curl -sS http://127.0.0.1:8090/health | python3 -m json.tool
```

المهم أن ترى:

```text
final_ui_version: v8_2_release_candidate_safe
matcher_index_enabled: true
queue_safety_enabled: true
redis_rate_limit_enabled: true
customer_ocr_leak_protection: true
```

## اختبار واتساب بعد التشغيل
1. أرسل: السلام عليكم
2. يجب أن تظهر أزرار البحث.
3. جرّب بحث نصي باسم عام مثل Panadol.
4. يجب أن تظهر قائمة إذا توجد عدة منتجات.
5. جرّب صورة منتج واضح.
6. جرّب صورة غير منتج/روشتة.
7. تأكد أن رسالة غير المتوفر هي فقط:

```text
غير متوفر حاليًا في الصيدلية.
```

بدون OCR وبدون Gemini text وبدون تفاصيل داخلية.

---

# V9 PostgreSQL Final Deployment

النسخة V9 تختلف عن V8.2 في أنها تنقل قاعدة البيانات من SQLite إلى PostgreSQL المحلي على نفس السيرفر.

## أمر التشغيل النهائي

```bash
bash INSTALL_V9_ON_SERVER.sh
```

## بعد التشغيل تأكد من health

```bash
curl -sS http://127.0.0.1:8090/health | python3 -m json.tool
```

يجب أن ترى:

```json
"final_ui_version": "v9_production_postgres_final_safe"
```

وتحت `database_engine`:

```json
"engine": "postgres"
```

## إعادة تحميل الفهرس بعد تحديث المنتجات

بعد أي import للمنتجات، يمكن استدعاء:

```bash
TOKEN=$(grep '^PRICEBOT_INTERNAL_RELOAD_TOKEN=' /opt/pricebot_whatsapp_gemini/.env | cut -d= -f2-)
curl -sS -X POST -H "x-pricebot-token: $TOKEN" http://127.0.0.1:8090/internal/reload-index
```
