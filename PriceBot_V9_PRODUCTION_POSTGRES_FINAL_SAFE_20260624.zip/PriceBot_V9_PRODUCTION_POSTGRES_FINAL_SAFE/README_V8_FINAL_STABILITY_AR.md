# PriceBot V8 Final Stability Safe

هذه نسخة تطوير نهائية مبنية على V7/V6B/V6C بدون قاعدة بيانات وبدون مفاتيح حقيقية.

## الهدف
- WhatsApp فقط.
- Gemini/OpenRouter يبقى مسؤولًا عن قراءة الصور، ولا يتم تغيير منطق Gemini الأساسي.
- المطابقة المحلية آمنة وسريعة عبر matcher_index.
- الأسماء العامة تعرض قائمة.
- اختلاف التركيز يمنع المطابقة.
- لا يتم عرض نص OCR/Gemini للزبون عند عدم توفر المنتج.

## إضافات V8
- Runtime metrics في /health.
- Startup validation warnings.
- Redis/Valkey state + Redis rate limit.
- Queue safety + timeout + 503 عند الامتلاء.
- Retry لإرسال WhatsApp وتحميل الوسائط وVision.
- Graceful shutdown.
- customer OCR leak protection.
- scripts/test_v8_safety.sh.

## علامات النجاح في /health
- final_ui_version: v8_final_stability_resilience
- matcher_index_enabled: true
- redis_state_enabled: true
- queue_safety_enabled: true
- redis_rate_limit_enabled: true
- v8_final_stability: true
