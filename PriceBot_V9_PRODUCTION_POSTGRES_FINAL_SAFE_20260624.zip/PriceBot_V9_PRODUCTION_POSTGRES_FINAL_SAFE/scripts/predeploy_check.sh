#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FAIL=0
WARN=0
ok(){ echo "PASS: $*"; }
warn(){ echo "WARN: $*"; WARN=$((WARN+1)); }
fail(){ echo "FAIL: $*"; FAIL=$((FAIL+1)); }
section(){ echo; echo "===== $* ====="; }

section "V9 PACKAGE STRUCTURE"
[ -d "$ROOT/app" ] && ok "app exists" || fail "app missing"
[ -f "$ROOT/INSTALL_V9_ON_SERVER.sh" ] && ok "V9 installer exists" || fail "V9 installer missing"
[ -f "$ROOT/app/tools/migrate_sqlite_to_postgres.py" ] && ok "SQLite→Postgres migration tool exists" || fail "migration tool missing"
[ -f "$ROOT/scripts/setup_postgres_and_migrate.sh" ] && ok "PostgreSQL setup script exists" || fail "PostgreSQL setup script missing"
[ -f "$ROOT/README_V9_PRODUCTION_POSTGRES_FINAL_AR.md" ] && ok "V9 README exists" || fail "V9 README missing"

section "NO SECRETS / DB"
if find "$ROOT" -type f \( -name '.env' -o -name 'pricebot.db' -o -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.db' -o -name '*.db-wal' -o -name '*.db-shm' \) | grep -q .; then
  fail "unsafe database/env file found in release"
else
  ok "no .env or database in package"
fi
if grep -RInE '(EA[A-Za-z0-9]{80,}|sk-or-[A-Za-z0-9_-]{20,}|AIza[0-9A-Za-z_-]{20,}|xox[baprs]-[A-Za-z0-9-]{20,})' "$ROOT" >/tmp/pricebot_v9_secret_grep.txt 2>/dev/null; then
  fail "possible real secret found"
  sed -n '1,20p' /tmp/pricebot_v9_secret_grep.txt
else
  ok "no common real secret patterns"
fi

section "VERSION / FEATURES"
grep -q 'v9_production_postgres_final_safe' "$ROOT/app/app.py" && ok "V9 version marker exists" || fail "V9 version marker missing"
grep -q 'database_engine_info' "$ROOT/app/database.py" && ok "database_engine_info exists" || fail "database engine info missing"
grep -q 'schema_migrations' "$ROOT/app/database.py" && ok "schema migration ledger exists" || fail "schema migrations missing"
grep -q 'psycopg_pool' "$ROOT/app/requirements.txt" && ok "PostgreSQL pool dependency exists" || fail "psycopg_pool dependency missing"
grep -q '/internal/reload-index' "$ROOT/app/app.py" && ok "internal index reload endpoint exists" || fail "internal reload endpoint missing"

section "SCRIPT SYNTAX"
for sh in "$ROOT"/*.sh "$ROOT/scripts"/*.sh; do
  [ -f "$sh" ] || continue
  bash -n "$sh" && ok "bash syntax OK: ${sh#$ROOT/}" || fail "bash syntax failed: ${sh#$ROOT/}"
done

section "PYTHON COMPILE"
python3 -m py_compile \
  "$ROOT/app/app.py" \
  "$ROOT/app/database.py" \
  "$ROOT/app/matcher_index.py" \
  "$ROOT/app/state_store.py" \
  "$ROOT/app/vision_service.py" \
  "$ROOT/app/config_env.py" \
  "$ROOT/app/tools/migrate_sqlite_to_postgres.py" && ok "compile OK" || fail "compile failed"

section "RESULT"
echo "PREDEPLOY_WARN=$WARN"
echo "PREDEPLOY_FAIL=$FAIL"
if [ "$FAIL" -ne 0 ]; then
  echo "PREDEPLOY_RESULT=FAIL"
  exit 1
fi
echo "PREDEPLOY_RESULT=OK"
