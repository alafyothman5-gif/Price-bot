#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/pricebot_whatsapp_gemini}"
SQLITE_DB="${PRICEBOT_SQLITE_SOURCE:-${APP_DIR}/pricebot.db}"
DB_NAME="${PRICEBOT_POSTGRES_DB:-pricebot}"
DB_USER="${PRICEBOT_POSTGRES_USER:-pricebot}"
ENV_FILE="${APP_DIR}/.env"
MIN_PRODUCTS="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
REPLACE="${PRICEBOT_POSTGRES_REPLACE:-1}"

if [ ! -f "$SQLITE_DB" ]; then
  echo "SQLITE_SOURCE_NOT_FOUND: $SQLITE_DB" >&2
  exit 1
fi
if [ ! -f "$ENV_FILE" ]; then
  echo "ENV_FILE_NOT_FOUND: $ENV_FILE" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y postgresql postgresql-contrib python3-venv sqlite3 openssl
systemctl enable postgresql
systemctl start postgresql

DB_PASS="${PRICEBOT_POSTGRES_PASSWORD:-$(openssl rand -hex 24)}"

sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${DB_USER}') THEN
    CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASS}';
  ELSE
    ALTER ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASS}';
  END IF;
END
\$\$;
SELECT 'CREATE DATABASE ${DB_NAME} OWNER ${DB_USER}' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${DB_NAME}')\gexec
ALTER DATABASE ${DB_NAME} OWNER TO ${DB_USER};
SQL

DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}"

cd "$APP_DIR"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

MIGRATE_ARGS=(--sqlite "$SQLITE_DB" --postgres "$DATABASE_URL" --min-products "$MIN_PRODUCTS")
if [ "$REPLACE" = "1" ]; then
  MIGRATE_ARGS+=(--replace)
fi
python tools/migrate_sqlite_to_postgres.py "${MIGRATE_ARGS[@]}"

cp "$ENV_FILE" "$ENV_FILE.backup-before-postgres-$(date +%Y%m%d_%H%M%S)"
python3 - <<PY
from pathlib import Path
path = Path("$ENV_FILE")
updates = {
    "DATABASE_URL": "$DATABASE_URL",
    "POSTGRES_DSN": "$DATABASE_URL",
    "PRICEBOT_REQUIRE_POSTGRES_PRODUCTION": "1",
    "PRICEBOT_POSTGRES_POOL_ENABLED": "1",
    "PRICEBOT_POSTGRES_POOL_MIN": "1",
    "PRICEBOT_POSTGRES_POOL_MAX": "10",
    "PRICEBOT_PRODUCTION_MODE": "1",
    "PRICEBOT_STRICT_DB_STARTUP": "1",
}
text = path.read_text(errors="ignore") if path.exists() else ""
lines = text.splitlines()
seen = set()
out = []
for line in lines:
    if "=" in line and not line.strip().startswith("#"):
        key = line.split("=", 1)[0].strip()
        if key in updates:
            out.append(f"{key}={updates[key]}")
            seen.add(key)
        else:
            out.append(line)
    else:
        out.append(line)
for key, value in updates.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out).rstrip()+"\n")
PY
chmod 600 "$ENV_FILE"

echo "POSTGRES_MIGRATION_OK"
echo "DATABASE_URL written to $ENV_FILE"
echo "SQLite source preserved at: $SQLITE_DB"
