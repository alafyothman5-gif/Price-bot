#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FAIL=0
ok(){ echo "PASS: $*"; }
fail(){ echo "FAIL: $*"; FAIL=$((FAIL+1)); }
[ -f "$ROOT/app/tools/migrate_sqlite_to_postgres.py" ] && ok "migration tool exists" || fail "migration tool missing"
[ -f "$ROOT/scripts/setup_postgres_and_migrate.sh" ] && ok "postgres setup script exists" || fail "postgres setup script missing"
grep -q "psycopg_pool" "$ROOT/app/requirements.txt" && ok "psycopg_pool dependency exists" || fail "psycopg_pool missing"
grep -q "database_engine_info" "$ROOT/app/database.py" && ok "database health info exists" || fail "database_engine_info missing"
grep -q "schema_migrations" "$ROOT/app/database.py" && ok "schema migrations ledger exists" || fail "schema migrations missing"
grep -q "/internal/reload-index" "$ROOT/app/app.py" && ok "internal reload endpoint exists" || fail "internal reload endpoint missing"
grep -q "v9_production_postgres_final_safe" "$ROOT/app/app.py" && ok "V9 version exists" || fail "V9 version missing"
python3 -m py_compile "$ROOT/app/database.py" "$ROOT/app/tools/migrate_sqlite_to_postgres.py" && ok "Python compile OK" || fail "Python compile failed"
echo "V9_DB_AUDIT_FAIL=$FAIL"
if [ "$FAIL" -ne 0 ]; then exit 1; fi
echo "V9_DB_AUDIT_RESULT=OK"
