#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ZIP_PATH="${1:-}"
FAIL=0
WARN=0

ok(){ echo "PASS: $*"; }
warn(){ echo "WARN: $*"; WARN=$((WARN+1)); }
fail(){ echo "FAIL: $*"; FAIL=$((FAIL+1)); }
section(){ echo; echo "===== $* ====="; }

section "TREE AUDIT"
[ -d "$ROOT/app" ] && ok "app exists" || fail "app missing"
[ -f "$ROOT/INSTALL_V9_ON_SERVER.sh" ] && ok "installer exists" || fail "installer missing"
[ -f "$ROOT/README_DEPLOY_AR.md" ] && ok "deploy README exists" || fail "deploy README missing"

section "NO SECRETS OR DATABASE"
if find "$ROOT" -type f \( -name '.env' -o -name 'pricebot.db' -o -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.db' -o -name '*.db-wal' -o -name '*.db-shm' \) | grep -q .; then
  fail "unsafe file found in release tree"
  find "$ROOT" -type f \( -name '.env' -o -name 'pricebot.db' -o -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.db' -o -name '*.db-wal' -o -name '*.db-shm' \)
else
  ok "no .env or database files in release tree"
fi

if grep -RInE '(EA[A-Za-z0-9]{80,}|sk-or-[A-Za-z0-9_-]{20,}|AIza[0-9A-Za-z_-]{20,}|xox[baprs]-[A-Za-z0-9-]{20,})' "$ROOT" >/tmp/pricebot_release_secret_grep.txt 2>/dev/null; then
  fail "possible real API token/key pattern found"
  sed -n '1,20p' /tmp/pricebot_release_secret_grep.txt
else
  ok "no common real token/key patterns found"
fi

section "VERSION AND HEALTH FLAGS"
if grep -q 'FINAL_UI_VERSION = "v9_production_postgres_final_safe"' "$ROOT/app/app.py"; then ok "version OK"; else fail "version mismatch"; fi
for marker in 'v9_production_postgres_final' 'queue_safety_enabled' 'redis_rate_limit_enabled' 'customer_ocr_leak_protection'; do
  grep -q "$marker" "$ROOT/app/app.py" && ok "health marker exists: $marker" || fail "health marker missing: $marker"
done

section "SCRIPT SYNTAX"
for sh in "$ROOT"/*.sh "$ROOT/scripts"/*.sh; do
  [ -f "$sh" ] || continue
  bash -n "$sh" && ok "bash syntax OK: ${sh#$ROOT/}" || fail "bash syntax failed: ${sh#$ROOT/}"
done

section "PYTHON COMPILE"
python3 -m py_compile "$ROOT/app/app.py" "$ROOT/app/matcher_index.py" "$ROOT/app/state_store.py" "$ROOT/app/vision_service.py" "$ROOT/app/config_env.py" "$ROOT/app/database.py" "$ROOT/app/tools/migrate_sqlite_to_postgres.py" && ok "compile OK" || fail "compile failed"

if [ -n "$ZIP_PATH" ]; then
  section "ZIP AUDIT"
  if [ -f "$ZIP_PATH" ]; then
    ok "zip exists: $ZIP_PATH"
    if unzip -l "$ZIP_PATH" | grep -E '(^|/)(\.env|pricebot\.db|.*\.sqlite3?|.*\.db-wal|.*\.db-shm)$' >/tmp/pricebot_zip_unsafe.txt; then
      fail "unsafe file found inside zip"
      cat /tmp/pricebot_zip_unsafe.txt
    else
      ok "zip does not contain .env or database files"
    fi
  else
    fail "zip path not found: $ZIP_PATH"
  fi
fi

section "RESULT"
echo "RELEASE_AUDIT_WARN=$WARN"
echo "RELEASE_AUDIT_FAIL=$FAIL"
if [ "$FAIL" -ne 0 ]; then
  echo "RELEASE_AUDIT_RESULT=FAIL"
  exit 1
fi
echo "RELEASE_AUDIT_RESULT=OK"
