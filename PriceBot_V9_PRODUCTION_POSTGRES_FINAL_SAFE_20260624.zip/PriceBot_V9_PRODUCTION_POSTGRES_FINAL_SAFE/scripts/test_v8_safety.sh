#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${1:-/opt/pricebot_whatsapp_gemini}"
PORT="${PRICEBOT_PORT:-8090}"

echo "===== V8.2 HEALTH ====="
curl -sS "http://127.0.0.1:${PORT}/health" | python3 -c '
import sys,json
d=json.load(sys.stdin)
for k in ["final_ui_version","v8_final_stability","v8_1_predeploy_checked","v8_2_release_candidate","matcher_index_enabled","redis_state_enabled","queue_safety_enabled","redis_rate_limit_enabled","customer_ocr_leak_protection","products_count","workers"]:
    print(f"{k}: {d.get(k)}")
'

echo
echo "===== REDIS ====="
redis-cli ping

echo
echo "===== INTERNAL MATCHER TEST ====="
cd "$APP_DIR"
"$APP_DIR/.venv/bin/python" - <<'PY'
import asyncio
from matcher_index import ProductIndex, product_name, strength_conflicts

PASS=0; WARN=0; FAIL=0

def ok(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1; print(f"PASS | {name} | {detail}")
    else:
        FAIL += 1; print(f"FAIL | {name} | {detail}")

def warn(name, detail=""):
    global WARN
    WARN += 1; print(f"WARN | {name} | {detail}")

async def main():
    idx=ProductIndex(ttl_seconds=300)
    await idx.refresh(force=True)
    ok("index_loaded", len(idx.products)>1000, f"products={len(idx.products)}")
    ok("ratio_strength_conflict_5_5_vs_10_5", strength_conflicts("medicine 5/5", "medicine 10/5") is True)
    ok("ratio_strength_same_5_5", strength_conflicts("medicine 5/5", "medicine 5/5") is False)
    ok("mg_strength_conflict_500_vs_250", strength_conflicts("medicine 500mg", "medicine 250mg") is True)
    ok("mg_strength_same_500", strength_conflicts("medicine 500mg", "medicine 500mg") is False)
    for q in ["Vichy","Panadol","Rilastil","CeraVe","Bioderma","Eucerin"]:
        c=await idx.search(q,limit=30)
        if not c:
            warn(f"{q}_no_candidates"); continue
        ok(f"{q}_generic_not_direct", idx.direct_match_ok(q,c) is False, f"candidates={len(c)}")
        if len(c)>1: ok(f"{q}_generic_show_list", idx.should_show_list(q,c) is True, f"candidates={len(c)}")
        else: warn(f"{q}_single_candidate", product_name(c[0]))
    cov=await idx.search("coveram 5/5",limit=30)
    bad=[product_name(p) for p in cov if "coveram" in product_name(p).lower() and "10/5" in product_name(p).lower() and "5/5" not in product_name(p).lower()]
    ok("coveram_5_5_not_matching_10_5", not bad, f"bad={bad[:5]}")
    ril=await idx.search("Rilastil xerolact PB",limit=5)
    top=product_name(ril[0]) if ril else ""
    if top: ok("rilastil_xerolact_not_weak_brand_only", "intense c" not in top.lower(), f"top={top}")
    else: warn("rilastil_xerolact_no_candidate")
    print("===== SUMMARY =====")
    print(f"PASS={PASS}"); print(f"WARN={WARN}"); print(f"FAIL={FAIL}")
    if FAIL==0: print("FINAL_RESULT=OK")
    else: print("FINAL_RESULT=FAIL"); raise SystemExit(1)
asyncio.run(main())
PY

echo
echo "===== NO HARDCODED PRODUCT FIXES CHECK ====="
grep -RniE 'if .*coveram|if .*vichy|if .*panadol|if .*rilastil' "$APP_DIR/app.py" "$APP_DIR/matcher_index.py" || true

echo
echo "===== DONE ====="
