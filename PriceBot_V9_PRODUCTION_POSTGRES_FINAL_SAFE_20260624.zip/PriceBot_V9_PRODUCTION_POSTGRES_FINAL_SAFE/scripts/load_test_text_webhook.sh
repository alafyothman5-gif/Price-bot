#!/usr/bin/env bash
set -euo pipefail

# Safe webhook load test.
# Default mode sends EMPTY WhatsApp webhook payloads, so it does NOT enqueue customer messages
# and does NOT trigger outbound WhatsApp sends.
# To test real queue behavior deliberately, set PRICEBOT_LOADTEST_SEND_FAKE_MESSAGE=1.

URL="${PRICEBOT_LOADTEST_URL:-http://127.0.0.1:8090/webhook}"
N="${PRICEBOT_LOADTEST_N:-50}"
CONCURRENCY="${PRICEBOT_LOADTEST_CONCURRENCY:-10}"
ENV_FILE="${PRICEBOT_ENV_FILE:-/opt/pricebot_whatsapp_gemini/.env}"
SEND_FAKE_MESSAGE="${PRICEBOT_LOADTEST_SEND_FAKE_MESSAGE:-0}"
SECRET="${PRICEBOT_META_APP_SECRET:-}"

if [ -z "$SECRET" ] && [ -f "$ENV_FILE" ]; then
  SECRET="$(grep -E '^META_APP_SECRET=' "$ENV_FILE" | tail -1 | cut -d= -f2- || true)"
  [ "$SECRET" = '***SET_ME***' ] && SECRET=""
fi

sign_body(){
  local body="$1"
  if [ -n "$SECRET" ] && command -v openssl >/dev/null 2>&1; then
    printf '%s' "$body" | openssl dgst -sha256 -hmac "$SECRET" -binary | xxd -p -c 256 | sed 's/^/sha256=/'
  else
    printf ''
  fi
}

mk_body(){
  local i="$1"
  if [ "$SEND_FAKE_MESSAGE" = "1" ]; then
    # WARNING: this can enqueue work and may trigger outbound WhatsApp API attempts.
    cat <<JSON
{"object":"whatsapp_business_account","entry":[{"id":"loadtest","changes":[{"value":{"messaging_product":"whatsapp","metadata":{"display_phone_number":"000","phone_number_id":"loadtest"},"messages":[{"from":"218000000000","id":"loadtest_${i}","timestamp":"1782300000","text":{"body":"loadtest ${i}"},"type":"text"}]},"field":"messages"}]}]}
JSON
  else
    # Safe: no messages array, no queue, no outbound sends.
    cat <<JSON
{"object":"whatsapp_business_account","entry":[]}
JSON
  fi
}

one(){
  local i="$1"
  local body sig code
  body="$(mk_body "$i")"
  sig="$(sign_body "$body")"
  if [ -n "$sig" ]; then
    code="$(curl -sS -o /dev/null -w '%{http_code}' -X POST "$URL" -H 'Content-Type: application/json' -H "X-Hub-Signature-256: $sig" --data-binary "$body" || true)"
  else
    code="$(curl -sS -o /dev/null -w '%{http_code}' -X POST "$URL" -H 'Content-Type: application/json' --data-binary "$body" || true)"
  fi
  echo "$code"
}

export -f one mk_body sign_body
export URL SECRET SEND_FAKE_MESSAGE

echo "URL=$URL"
echo "N=$N CONCURRENCY=$CONCURRENCY SEND_FAKE_MESSAGE=$SEND_FAKE_MESSAGE"
if [ "$SEND_FAKE_MESSAGE" != "1" ]; then
  echo "SAFE_MODE=1: empty payloads only; no outbound WhatsApp should be triggered."
else
  echo "SAFE_MODE=0: fake message mode may enqueue work and trigger outbound WhatsApp API attempts."
fi
if [ -z "$SECRET" ]; then
  echo "WARN: META_APP_SECRET not found; if signature is required, responses may be 403."
fi

TMP="$(mktemp)"
seq 1 "$N" | xargs -P "$CONCURRENCY" -I{} bash -c 'one "$@"' _ {} > "$TMP"

echo
sort "$TMP" | uniq -c | awk '{print "HTTP_"$2"="$1}'
rm -f "$TMP"

echo
echo "Health after test:"
curl -sS "${URL%/webhook}/health" 2>/dev/null || curl -sS "http://127.0.0.1:8090/health" 2>/dev/null || true
echo
