#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build PriceBot V22.3 Guided Commerce catalog index.

Sources:
  1) Excel file such as products_master_v22_ready.xlsx
  2) Current SQLite DB products table (--db)

This tool never deletes or updates products. It only rebuilds guided_catalog_index
when --write-db is used, and writes a safe report guided_catalog_tree_report.xlsx.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.guided_finder import build_guided_catalog_rows  # noqa: E402


def read_excel(path: Path) -> List[dict]:
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(c or "").strip() for c in rows[0]]
    products = []
    for row in rows[1:]:
        item = {headers[i]: (row[i] if i < len(row) else "") for i in range(len(headers)) if headers[i]}
        if str(item.get("name") or item.get("product_name") or "").strip():
            if "name" not in item and "product_name" in item:
                item["name"] = item.get("product_name")
            products.append(item)
    return products


def read_db() -> List[dict]:
    import database
    database.init_db()
    return database.load_products()


def write_report(rows: List[dict], products: List[dict], output: Path) -> None:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "guided_catalog_tree"
    ws.append(["section", "submenu", "product_count", "available_count", "examples", "unclassified_count", "warnings"])
    grouped: Dict[tuple, List[dict]] = defaultdict(list)
    for r in rows:
        grouped[(r.get("section") or "other", r.get("menu_level_1") or "")].append(r)
    unclassified = [r for r in rows if r.get("section") == "other" or not r.get("menu_level_1") or float(r.get("confidence") or 0) < 0.60]
    product_by_id = {str(p.get("product_id") or p.get("id") or ""): p for p in products}
    for (section, submenu), items in sorted(grouped.items()):
        available = [r for r in items if int(r.get("is_available") or 0) == 1]
        examples = []
        for r in available[:5]:
            p = product_by_id.get(str(r.get("product_id") or "")) or {}
            if p.get("name"):
                examples.append(str(p.get("name")))
        warnings = []
        if section == "other" or not submenu:
            warnings.append("needs_manual_classification")
        if not available:
            warnings.append("empty_or_unavailable")
        ws.append([section, submenu, len(items), len(available), "; ".join(examples), len(unclassified), "; ".join(warnings)])

    ws2 = wb.create_sheet("unclassified")
    ws2.append(["product_id", "name", "section", "submenu", "confidence", "tags"])
    for r in unclassified[:1000]:
        p = product_by_id.get(str(r.get("product_id") or "")) or {}
        ws2.append([r.get("product_id"), p.get("name"), r.get("section"), r.get("menu_level_1"), r.get("confidence"), r.get("tags_json")])

    ws3 = wb.create_sheet("raw_index")
    headers = ["product_id", "section", "menu_level_1", "menu_level_2", "menu_level_3", "product_type", "use_case", "skin_type", "body_area", "is_available", "confidence", "tags_json"]
    ws3.append(headers)
    for r in rows:
        ws3.append([r.get(h, "") for h in headers])
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Guided Commerce catalog index safely")
    parser.add_argument("--input", default="products_master_v22_ready.xlsx", help="Excel file path")
    parser.add_argument("--db", action="store_true", help="Read products from current SQLite DB")
    parser.add_argument("--write-db", action="store_true", help="Replace guided_catalog_index only; never touches products")
    parser.add_argument("--report", default="guided_catalog_tree_report.xlsx", help="Output XLSX report")
    args = parser.parse_args()

    if args.db:
        products = read_db()
    else:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"INPUT_NOT_FOUND: {input_path}")
            print("Use --db to build from the deployed SQLite products table.")
            raise SystemExit(2)
        products = read_excel(input_path)

    rows = build_guided_catalog_rows(products)
    report_path = Path(args.report)
    write_report(rows, products, report_path)

    result = {"products_read": len(products), "guided_rows": len(rows), "report": str(report_path)}
    if args.write_db:
        import database
        before = database.count_products()
        db_result = database.replace_guided_catalog_index(rows)
        after = database.count_products()
        if before != after:
            raise SystemExit(f"DB_PROTECTION_FAILED: before={before} after={after}")
        result.update(db_result)
        result["db_protection"] = "ok"
    print("GUIDED_CATALOG_INDEX_OK | " + json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
