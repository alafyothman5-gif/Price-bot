#!/usr/bin/env bash
set -Eeuo pipefail
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
cd "$(dirname "$0")"

python -m compileall -q .
PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_2_stability_speed.py
PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_3_guided_commerce.py

if [[ -f pricebot.db ]]; then
  BEFORE=$(python - <<'PY'
import database
print(database.count_products())
PY
)
  PRICEBOT_MIN_PRODUCTS_GUARD=0 timeout 60s python tools/rebuild_search_index.py >/tmp/pricebot_search_index_smoke.log || cat /tmp/pricebot_search_index_smoke.log
  PRICEBOT_MIN_PRODUCTS_GUARD=0 timeout 60s python tools/rebuild_product_nav_index.py >/tmp/pricebot_nav_index_smoke.log || cat /tmp/pricebot_nav_index_smoke.log
  PRICEBOT_MIN_PRODUCTS_GUARD=0 timeout 60s python tools/build_guided_catalog_index.py --db --write-db --report guided_catalog_tree_report.xlsx >/tmp/pricebot_guided_index_smoke.log || cat /tmp/pricebot_guided_index_smoke.log
  AFTER=$(python - <<'PY'
import database
print(database.count_products())
PY
)
  if [[ "$BEFORE" != "$AFTER" ]]; then
    echo "DB_PROTECTION_FAILED | before=$BEFORE | after=$AFTER" >&2
    exit 1
  fi
  echo "DB_PROTECTION_OK | products_count=$AFTER"
else
  echo "INFO: pricebot.db not found in current directory; skipped live index smoke."
fi

if curl -fsS "http://127.0.0.1:${PRICEBOT_PORT}/health" >/tmp/pricebot_health_smoke.log 2>/dev/null; then
  cat /tmp/pricebot_health_smoke.log
  echo
else
  echo "INFO: local service not running on 127.0.0.1:${PRICEBOT_PORT}; code-level smoke passed."
fi

if [[ -f pricebot.db ]]; then
  python tools/diagnose_pricebot.py || true
else
  echo "INFO: skipped diagnose because pricebot.db is not present in this package directory."
fi

echo "PRICEBOT_V22_3_GUIDED_COMMERCE_SMOKE_TEST_OK"
