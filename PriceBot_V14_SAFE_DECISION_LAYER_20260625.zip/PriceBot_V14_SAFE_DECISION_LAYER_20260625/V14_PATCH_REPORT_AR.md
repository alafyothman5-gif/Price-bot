# PriceBot V14 – Safe Decision Layer Patch Report

تم تطبيق التعديلات على نسخة V13 المرفوعة بدون تغيير أبعاد التضمين وبدون إضافة أي نموذج محلي.

## الملفات المعدّلة

- `app/semantic_matcher.py`
  - رفع عتبة السعر المباشر إلى `0.99`.
  - رفع عتبة التأكيد إلى `0.85`.
  - إضافة Redis cache لنتائج `gemini_verify` لمدة 15 دقيقة.
  - لم يتم تغيير `PRICEBOT_EMBEDDING_DIM` ولا `embedding_dim = 1536`.

- `app/app.py`
  - عند قرار `confirm` مع أكثر من مرشح، يتم عرض قائمة اختيار بدل زر نعم/لا.
  - إضافة Vision cache في Redis لمدة ساعة حسب `image_hash`.
  - إضافة `/metrics` اختياريًا إذا كانت `starlette_exporter` مثبتة.
  - تحديث نسخة الواجهة إلى `v14_safe_decision_layer`.

- `app/vision_service.py`
  - إضافة منع أسماء المكونات العامة مثل `folic acid`, `iron`, `vitamin c`, `زنك`, `حديد` إذا ظهرت وحدها كهوية المنتج.
  - إرجاع رسالة واضحة تطلب صورة للعلبة كاملة أو كتابة الاسم.

- `systemd/pricebot-whatsapp-gemini.service`
  - تشغيل Uvicorn بعدد عاملين: `--workers 2`.

- `app/start-pricebot.sh`
  - دعم `PRICEBOT_UVICORN_WORKERS` مع قيمة افتراضية `2`.

- `app/.env.example`
  - تحديث قيم العتبات والعمال واتصالات PostgreSQL.

- `app/requirements.txt`
  - إضافة `starlette_exporter` كمراقبة اختيارية.

## فحوصات تمت داخل بيئة العمل

- تم تشغيل `python3 -m compileall -q app` بنجاح.
- تم فحص أن `embedding_dim` ما زال `1536`.
- تم فحص أن عتبات Gemini الافتراضية أصبحت `0.99` و `0.85`.

ملاحظة: اختبار الاستيراد المحلي أظهر تحذيرًا بسبب عدم وجود `psycopg` داخل بيئة الاختبار فقط، وهو موجود في `requirements.txt` وسيُثبت على السيرفر.

## تنبيه مهم قبل النشر

إذا كان ملف `.env` الحقيقي على السيرفر يحتوي القيم القديمة:

```env
PRICEBOT_GEMINI_DIRECT_CONFIDENCE=0.90
PRICEBOT_GEMINI_CONFIRM_CONFIDENCE=0.60
```

فإنها ستتغلب على القيم الافتراضية داخل الكود. لذلك يجب تحديث `.env` الحقيقي أثناء النشر بالقيم الجديدة.
