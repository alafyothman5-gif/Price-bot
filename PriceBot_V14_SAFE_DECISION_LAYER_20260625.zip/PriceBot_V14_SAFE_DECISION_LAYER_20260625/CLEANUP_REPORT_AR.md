# تقرير تنظيف PriceBot V13

## النسخة الأصلية

`PriceBot_V13_LITE_HYBRID_SAFE_CONFIRM_20260625.zip`

## النسخة الناتجة

`PriceBot_V13_LITE_HYBRID_SAFE_CONFIRM_CLEAN_20260625.zip`

## سياسة التنظيف

تم تنظيف الملفات الخارجية والزائدة فقط. لم يتم تغيير منطق المطابقة الأساسي داخل `app.py` أو `semantic_matcher.py` أو `vision_service.py` أو `database.py` لتجنب كسر النظام المستقر.

## ملفات حُذفت لأنها غير لازمة للتشغيل الحالي

- `FILE_MANIFEST_V10.txt`
- `FILE_MANIFEST_V11.txt`
- `FILE_MANIFEST_V12.txt`
- `FILE_MANIFEST_V13.txt`
- `README_AR.md`
- `README_PRICEBOT_V10_SEMANTIC_GEMINI_AR.md`
- `README_PRICEBOT_V11_IMAGE_FIX_AR.md`
- `README_PRICEBOT_V12_STRICT_ELASTIC_FALLBACK_AR.md`
- `README_PRICEBOT_V13_LITE_HYBRID_SAFE_CONFIRM_AR.md` واستُبدل بـ README نظيف.
- `app/README_FINAL_UI_AR.md`
- `app/README_WHATSAPP_ONLY_AR.md`
- `app/pricebot.service.example`
- `app/start_pricebot.sh`
- `app/tools/migrate_sqlite_to_postgres.py`
- `app/dynamic_synonyms.py`
- `app/data/dynamic_synonyms.json`

## ملفات بقيت لأنها لازمة أو تشغيلية

- كود webhook والمطابقة والصورة وقاعدة البيانات.
- systemd service.
- `.env.example` نظيف بدون أسرار.
- scripts الخاصة بتحديث المنتجات وإعادة بناء embeddings.

## تعديل صغير غير وظيفي

- تحديث وصف systemd من V10 إلى V13.
- تحديث `.env.example` ليطابق V13.
- إضافة `openpyxl` إلى `requirements.txt` لأن سكربت sync يقرأ Excel ويحتاجها.
