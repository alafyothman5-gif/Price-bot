# PriceBot V13 Lite Hybrid Safe Confirm - Clean Runtime ZIP

هذه نسخة تنظيف من V13 الأصلية. الهدف منها تشغيل آخر نظام مستقر بأقل ملفات ممكنة، بدون بقايا توثيق V10/V11/V12 وبدون أدوات migration قديمة.

## ما الموجود داخل النسخة؟

- `app/app.py` — Webhook وواجهة WhatsApp و/health.
- `app/database.py` — PostgreSQL schema وعمليات المنتجات والحالة.
- `app/semantic_matcher.py` — V13 hybrid matcher: pgvector + pg_trgm + Gemini verification.
- `app/vision_service.py` — استخراج اسم المنتج من الصورة عبر Gemini Vision.
- `app/services/vision/evidence_validator.py` — تنظيف/تحقق نتيجة Vision لمنع مطابقة وصف عام بدل اسم المنتج.
- `app/state_store.py` — Redis state/rate limit/confirmations.
- `app/normalizer.py` و`app/config_env.py` — normalization وقراءة البيئة.
- `app/scripts/sync_products_from_github.sh` — تحديث المنتجات من GitHub `current_products.xlsx`.
- `app/scripts/sync_current_products_from_github.py` — قراءة Excel وتحديث PostgreSQL.
- `app/scripts/rebuild_semantic_index.py` — إعادة بناء embeddings الناقصة.
- `systemd/pricebot-whatsapp-gemini.service` — service file محدث باسم V13.

## ما المحذوف؟

- ملفات README القديمة الخاصة بـ V10/V11/V12.
- ملفات manifest القديمة.
- README قديم كان يذكر SQLite.
- أداة `tools/migrate_sqlite_to_postgres.py` لأنها ليست مطلوبة في التشغيل الحالي PostgreSQL.
- ملف التشغيل المكرر `start_pricebot.sh` وتم الإبقاء على `start-pricebot.sh` فقط.
- ملفات dynamic synonyms غير المستعملة من مسار V13 الحالي.
- أي `__pycache__` أو ملفات مؤقتة.

## ملاحظات مهمة

- لا يحتوي ZIP على `.env` الحقيقي.
- لا يحتوي ZIP على قاعدة البيانات.
- لا يحذف أو يعدل منتجاتك تلقائيًا.
- لا يشغّل migrations تلقائيًا.
- عند التركيب على السيرفر يجب الحفاظ على:
  - `/opt/pricebot_whatsapp_gemini/.env`
  - PostgreSQL database `pricebot`
  - Redis/Valkey

## فحص بعد التركيب

```bash
systemctl status pricebot-whatsapp-gemini --no-pager
curl -sS http://127.0.0.1:8090/health | python3 -m json.tool | head -180
sudo -u postgres psql -d pricebot -Atc "
SELECT COUNT(*),
SUM(CASE WHEN LOWER(COALESCE(is_available::text,'')) IN ('1','true','yes','y','available','متوفر') THEN 1 ELSE 0 END),
COUNT(embedding)
FROM products;"
redis-cli ping
```

المتوقع حاليًا:

```text
5163|5163|5163
PONG
```
