#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/pricebot_whatsapp_gemini"
ZIP_PATH="${1:-/root/PriceBot_V14_SAFE_DECISION_LAYER_20260625.zip}"
BACKUP_DIR="/root/pricebot_backups/$(date +%Y%m%d_%H%M%S)_pre_v14"
TMP_DIR="/tmp/pricebot_v14_deploy"

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo bash DEPLOY_V14_SAFE_COMMANDS.sh /path/to/PriceBot_V14_SAFE_DECISION_LAYER_20260625.zip"
  exit 1
fi

mkdir -p "$BACKUP_DIR"
cp -a "$APP_DIR/.env" "$BACKUP_DIR/.env"
cp -a /etc/systemd/system/pricebot-whatsapp-gemini.service "$BACKUP_DIR/pricebot-whatsapp-gemini.service" 2>/dev/null || true

if command -v pg_dump >/dev/null 2>&1; then
  set +e
  source "$APP_DIR/.env"
  pg_dump "${DATABASE_URL:-${POSTGRES_URL:-}}" > "$BACKUP_DIR/pricebot_pre_v14.sql" 2>"$BACKUP_DIR/pg_dump.err"
  set -e
fi

rm -rf "$TMP_DIR"
mkdir -p "$TMP_DIR"
unzip -q "$ZIP_PATH" -d "$TMP_DIR"
SRC_DIR="$(find "$TMP_DIR" -maxdepth 1 -type d -name 'PriceBot_V14*' | head -1)"
if [ -z "$SRC_DIR" ]; then
  echo "V14 source directory not found inside zip"
  exit 1
fi

systemctl stop pricebot-whatsapp-gemini || true
rsync -a --delete --exclude '.env' --exclude '.venv' --exclude 'venv' "$SRC_DIR/app/" "$APP_DIR/"
install -m 0644 "$SRC_DIR/systemd/pricebot-whatsapp-gemini.service" /etc/systemd/system/pricebot-whatsapp-gemini.service

python3 - <<'PY'
from pathlib import Path
path = Path('/opt/pricebot_whatsapp_gemini/.env')
text = path.read_text(encoding='utf-8') if path.exists() else ''
updates = {
    'PRICEBOT_GEMINI_DIRECT_CONFIDENCE': '0.99',
    'PRICEBOT_GEMINI_CONFIRM_CONFIDENCE': '0.85',
    'PRICEBOT_POSTGRES_POOL_MAX': '30',
    'PRICEBOT_POSTGRES_POOL_MIN': '5',
    'PRICEBOT_POSTGRES_POOL_TIMEOUT_SECONDS': '10',
    'PRICEBOT_TEXT_WORKERS': '30',
    'PRICEBOT_IMAGE_WORKERS': '10',
    'PRICEBOT_UVICORN_WORKERS': '2',
}
lines = text.splitlines()
seen = set()
for i, line in enumerate(lines):
    stripped = line.strip()
    if not stripped or stripped.startswith('#') or '=' not in line:
        continue
    key = line.split('=', 1)[0].strip()
    if key in updates:
        lines[i] = f'{key}={updates[key]}'
        seen.add(key)
for key, value in updates.items():
    if key not in seen:
        lines.append(f'{key}={value}')
path.write_text('\n'.join(lines).rstrip() + '\n', encoding='utf-8')
PY

if [ -x "$APP_DIR/.venv/bin/pip" ]; then
  "$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
else
  python3 -m venv "$APP_DIR/.venv"
  "$APP_DIR/.venv/bin/pip" install --upgrade pip
  "$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
fi

cd "$APP_DIR"
"$APP_DIR/.venv/bin/python" -m compileall -q .

systemctl daemon-reload
systemctl restart pricebot-whatsapp-gemini
sleep 2
systemctl --no-pager --full status pricebot-whatsapp-gemini
curl -s http://127.0.0.1:8090/health | python3 -m json.tool | head -80

echo "Backup saved in: $BACKUP_DIR"
echo "Follow logs with: journalctl -u pricebot-whatsapp-gemini -f"
