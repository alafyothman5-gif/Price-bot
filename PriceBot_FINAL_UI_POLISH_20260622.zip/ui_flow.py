"""Company-style WhatsApp UI state machine for PriceBot."""
from __future__ import annotations

from typing import Dict, List, Optional

import category_browser
import config_env
import conversation_state as cs
import database
import matcher
import orders
import whatsapp_interactive
from normalizer import normalize_text, safe_price
from services.whatsapp.result_formatter import clarification_message, list_row_description, product_display_name
from services.vision import visual_memory

PHARMACY_NAME = "صيدلية بدر البشرية"

GREETING_WORDS = {"السلام عليكم", "سلام عليكم", "مرحبا", "مرحبه", "اهلا", "أهلا", "هلا", "hi", "hello"}
START_WORDS = {"ابدأ", "ابدا", "start", "ابدأ الاستخدام", "ابدا الاستخدام", "START_USE", "MAIN_MENU"}
MENU_WORDS = {"القائمة", "قائمه", "قائمة", "الرئيسية", "الرئيسيه", "menu", "main menu", "MAIN_MENU"}
BACK_WORDS = {"رجوع", "عودة", "عوده", "back", "0"}
CANCEL_WORDS = {"الغاء", "إلغاء", "cancel"}
HELP_WORDS = {"مساعدة", "ساعدني", "help", "دعم", "support"}
YES_WORDS = {"نعم", "اي", "ايوه", "أيوه", "yes", "y"}
NEXT_WORDS = {"التالي", "المزيد", "next", "more"}
PREV_WORDS = {"السابق", "قبل", "prev", "previous"}

START_MESSAGE = (
    f"{PHARMACY_NAME} 🌿\n\n"
    "ابحث عن المنتج بالاسم أو بالصورة.\n"
    "اختر من الأزرار بالأسفل."
)

MAIN_MENU_MESSAGE = (
    f"{PHARMACY_NAME} 🌿\n\n"
    "اختر طريقة البحث:"
)

SEARCH_METHOD_MESSAGE = "اختر طريقة البحث:"

SEARCH_PROMPT = (
    "🔎 اكتب اسم المنتج فقط.\n"
    "مثال: Panadol Extra أو CeraVe Cream"
)

IMAGE_PROMPT = (
    "📷 أرسل صورة واضحة للواجهة الأمامية للمنتج.\n"
    "سأطلب منك التأكيد قبل عرض السعر."
)

HELP_MESSAGE = (
    "للتواصل مع الصيدلية، استخدم رقم واتساب الموجود في معلومات الصيدلية أو اكتب القائمة للرجوع."
)

INFO_MESSAGE = (
    f"{PHARMACY_NAME} 🌿\n\n"
    "المدينة: أجدابيا\n"
    "ساعات العمل: 24 ساعة\n"
    "التوصيل: غير متوفر حاليًا"
)


def _norm(text: str) -> str:
    return normalize_text(text)


def _normset(values) -> set[str]:
    return {_norm(x) for x in values}


def number_choice(text: str) -> Optional[int]:
    t = _norm(text)
    if t.isdigit():
        try:
            return int(t)
        except Exception:
            return None
    return None


def is_start(text: str) -> bool:
    n = _norm(text)
    return n in _normset(START_WORDS) or n == "start use"


def is_greeting(text: str) -> bool:
    return _norm(text) in _normset(GREETING_WORDS)


def is_menu(text: str) -> bool:
    return _norm(text) in _normset(MENU_WORDS)


def is_back(text: str) -> bool:
    return _norm(text) in _normset(BACK_WORDS)


def is_cancel(text: str) -> bool:
    return _norm(text) in _normset(CANCEL_WORDS)


def is_help(text: str) -> bool:
    return _norm(text) in _normset(HELP_WORDS)


def show_start(phone: str) -> str:
    cs.set(phone, cs.START)
    return START_MESSAGE


def show_main_menu(phone: str) -> str:
    cs.set(phone, cs.MAIN_MENU)
    return MAIN_MENU_MESSAGE


def show_search_method(phone: str) -> str:
    cs.set(phone, cs.WAITING_FOR_SEARCH_METHOD)
    return SEARCH_METHOD_MESSAGE


def show_search_prompt(phone: str) -> str:
    cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
    return SEARCH_PROMPT


def show_image_prompt(phone: str) -> str:
    cs.set(phone, cs.WAITING_FOR_PRODUCT_IMAGE)
    return IMAGE_PROMPT


def show_info(phone: str) -> str:
    cs.set(phone, cs.MAIN_MENU)
    return INFO_MESSAGE


def show_categories(phone: str) -> str:
    cats = category_browser.available_main_categories()
    cs.set(phone, cs.BROWSING_CATEGORIES, categories=cats)
    return "🗂️ اختر القسم من القائمة بالأسفل."


def show_subcategories(phone: str, main: str) -> str:
    subs = category_browser.available_subcategories(main)
    cs.set(phone, cs.BROWSING_SUBCATEGORY, main_category=main, subcategories=subs)
    return f"🗂️ {main}\nاختر التصنيف من القائمة بالأسفل."


def show_product_page(phone: str, main: str, sub: str, skin_type: str = "", page: int = 0) -> str:
    products = category_browser.products_for(main, sub, skin_type=skin_type, limit=120)
    ids = [int(p["id"]) for p in products if p.get("id")]
    cs.set(
        phone,
        cs.BROWSING_PRODUCT_PAGE,
        main_category=main,
        subcategory=sub,
        skin_type=skin_type,
        product_ids=ids,
        page=page,
    )
    return category_browser.format_product_page(sub, products, page=page)


def _product_rows_from_ids(ids: List[int]) -> List[Dict]:
    out: List[Dict] = []
    for pid in ids:
        try:
            p = database.get_product(int(pid))
        except Exception:
            p = None
        if p and database.product_visible(p, guided=False):
            out.append(p)
    return out


def _dedupe_display_products(products: List[Dict], limit: int = 10) -> List[Dict]:
    out: List[Dict] = []
    seen = set()
    for p in products:
        key = (
            normalize_text(p.get("name")),
            normalize_text(p.get("form") or p.get("medicine_form") or p.get("product_type")),
            normalize_text(p.get("strength")),
            normalize_text(p.get("size")),
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def _format_clarification_options(products: List[Dict]) -> str:
    if not products:
        return ""
    return "\n\nحدد المنتج المطلوب من القائمة التفاعلية."


def _format_products_without_prices(title: str, products: List[Dict], page: int = 0, page_size: int = 10) -> str:
    if not products:
        return "لا توجد منتجات متوفرة حاليًا."
    total = len(products)
    return (
        f"🔎 {title}\n"
        f"وجدت {total} منتج متاح.\n"
        "اختر المنتج من القائمة بالأسفل لعرض السعر."
    )


def handle_search_result(phone: str, result, original_query: str = "") -> str:
    if result.status == "EXACT_MATCH" and result.product:
        cs.set(phone, cs.PRODUCT_DETAIL, product_id=int(result.product["id"]), source="search")
        return orders.format_product_details(result.product)

    if result.status == "COSMETIC_ALTERNATIVES" and result.products:
        products = result.products[:80]
        ids = [int(p["id"]) for p in products if p.get("id")]
        cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=0, main_category="بحث", subcategory="نتائج البحث", hide_prices=True)
        msg = (result.message + "\n\n") if result.message else ""
        return msg + _format_products_without_prices("نتائج البحث", products, page=0)

    if result.status == "ASK_CLARIFICATION":
        products = _dedupe_display_products(result.products, limit=10) if result.products else []
        cs.set(phone, cs.WAITING_FOR_CLARIFICATION, pending_query=original_query, candidate_ids=[int(p["id"]) for p in products if p.get("id")])
        if products:
            return clarification_message(products)
        return result.message or "أحتاج تفاصيل أكثر قبل عرض السعر. اكتب اسم المنتج كاملًا."

    if result.status == "NOT_AVAILABLE":
        cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
        return (
            "🔍 لم أجد المنتج في قائمة الصيدلية.\n"
            "اكتب الاسم بشكل أوضح، أو أرسل صورة للمنتج."
        )

    if result.status in {"LOW_CONFIDENCE", "IMAGE_UNCLEAR"}:
        cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
        return (
            "📷 الصورة غير كافية للتعرف على المنتج.\n"
            "الرجاء إعادة التصوير بشكل أوضح، أو كتابة اسم المنتج مباشرة."
        )

    cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
    return (result.message or "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل.") + "\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."


def handle_back(phone: str, state: Dict) -> str:
    current = cs.current_name(state)
    if current in {cs.START, cs.MAIN_MENU, ""}:
        return show_main_menu(phone)
    if current in {cs.WAITING_FOR_SEARCH_METHOD, cs.WAITING_FOR_PRODUCT_SEARCH, cs.WAITING_FOR_PRODUCT_IMAGE, cs.WAITING_FOR_CLARIFICATION}:
        return show_main_menu(phone)
    if current == cs.BROWSING_CATEGORIES:
        return show_main_menu(phone)
    if current == cs.BROWSING_SUBCATEGORY:
        return show_categories(phone)
    if current == cs.BROWSING_PRODUCT_PAGE:
        main = state.get("main_category") or ""
        if main and main != "بحث":
            return show_subcategories(phone, main)
        return show_main_menu(phone)
    if current == cs.PRODUCT_DETAIL:
        ids = state.get("previous_product_ids") or []
        if ids:
            page = int(state.get("previous_page") or 0)
            cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=page, main_category=state.get("main_category") or "", subcategory=state.get("subcategory") or "")
            return category_browser.format_product_page(state.get("subcategory") or "المنتجات", _product_rows_from_ids(ids), page=page)
        return show_main_menu(phone)
    return show_main_menu(phone)


def handle_main_menu_choice(phone: str, text: str) -> str:
    n = _norm(text)
    choice = number_choice(text)
    if choice == 1 or n in {_norm("بحث بالاسم"), _norm("البحث بالاسم"), _norm("اسم"), "main name"}:
        return show_search_prompt(phone)
    if choice == 2 or n in {_norm("بحث بالصورة"), _norm("البحث بالصورة"), _norm("البحث بصورة"), _norm("إرسال صورة منتج"), _norm("ارسال صورة منتج"), _norm("صورة"), "main image"}:
        return show_image_prompt(phone)
    if choice == 3 or n in {_norm("تصفح الأقسام"), _norm("تصفح الاقسام"), _norm("🗂️ تصفح الأقسام"), "main browse"}:
        return show_categories(phone)
    if choice == 4 or n in {_norm("معلومات الصيدلية"), _norm("ℹ️ معلومات الصيدلية"), "main info"}:
        return show_info(phone)
    if n in {_norm("بحث"), _norm("البحث"), _norm("البحث عن منتج"), _norm("🔎 البحث عن منتج"), "main search"}:
        return show_search_method(phone)
    return MAIN_MENU_MESSAGE




def _interactive_id(text: str) -> str:
    return str(text or "").strip()


def _format_product_row(product: Dict) -> Dict[str, str]:
    title = product_display_name(product)[:24]
    return {
        "id": f"PRODUCT_{int(product.get('id'))}",
        "title": title or "منتج",
        "description": list_row_description(product, include_price=False)[:72],
    }


def _handle_interactive_id(phone: str, raw_id: str, state: Dict) -> Optional[str]:
    current = cs.current_name(state)
    raw_id = _interactive_id(raw_id)
    raw_norm = _norm(raw_id)

    # WhatsApp Cloud API normally sends the button/list id (SEARCH_NAME, MAIN_MENU, ...).
    # Some clients/providers send the visible Arabic title instead.  Handle both
    # before treating the text as a product query.
    if raw_norm in {_norm("بحث بالاسم"), _norm("البحث بالاسم"), _norm("اسم"), _norm("اكتب اسم المنتج"), _norm("بحث جديد")}:
        return show_search_prompt(phone)
    if raw_norm in {_norm("بحث بالصورة"), _norm("البحث بالصورة"), _norm("البحث بصورة"), _norm("صورة"), _norm("أرسل صورة المنتج"), _norm("ارسل صورة المنتج")}:
        return show_image_prompt(phone)
    if raw_norm in {_norm("الأقسام"), _norm("الاقسام"), _norm("تصفح الأقسام"), _norm("تصفح الاقسام")}:
        return show_categories(phone)
    if raw_norm in {_norm("القائمة"), _norm("القائمة الرئيسية"), _norm("الرئيسية")}:
        return show_main_menu(phone)

    if raw_id in {"START_USE", "MAIN_MENU"}:
        return show_main_menu(phone)
    if raw_id == "MAIN_SEARCH":
        return show_search_method(phone)
    if raw_id == "MAIN_BROWSE":
        return show_categories(phone)
    if raw_id == "MAIN_INFO":
        return show_info(phone)
    if raw_id == "SEARCH_NAME":
        return show_search_prompt(phone)
    if raw_id == "SEARCH_IMAGE":
        return show_image_prompt(phone)
    if raw_id == "BACK":
        return handle_back(phone, state)
    if raw_id == "NAV_NEXT":
        return handle_text(phone, "التالي")
    if raw_id == "NAV_PREV":
        return handle_text(phone, "السابق")
    if raw_id.startswith("CAT_"):
        try:
            idx = int(raw_id.split("_", 1)[1])
            cats = state.get("categories") or category_browser.available_main_categories()
            if 0 <= idx < len(cats):
                return show_subcategories(phone, cats[idx])
        except Exception:
            return None
    if raw_id.startswith("SUB_"):
        try:
            idx = int(raw_id.split("_", 1)[1])
            main = state.get("main_category") or ""
            subs = state.get("subcategories") or category_browser.available_subcategories(main)
            if 0 <= idx < len(subs):
                selected = subs[idx]
                if selected == "بحث باسم دواء":
                    return show_search_prompt(phone)
                if category_browser.needs_skin_type(main, selected):
                    cs.set(phone, "WAITING_FOR_SKIN_TYPE", main_category=main, subcategory=selected)
                    return category_browser.skin_type_menu()
                return show_product_page(phone, main, selected)
        except Exception:
            return None
    if raw_id.startswith("SKIN_"):
        skin_map = {"SKIN_oily": "دهنية", "SKIN_dry": "جافة", "SKIN_sensitive": "حساسة", "SKIN_normal": "عادية", "SKIN_unknown": "لا أعرف"}
        label = skin_map.get(raw_id, "")
        if label:
            skin_type = category_browser.skin_type_from_choice(label)
            return show_product_page(phone, state.get("main_category") or "", state.get("subcategory") or "", skin_type=skin_type)
    if raw_id.startswith("PRODUCT_") or raw_id.startswith("CLARIFY_"):
        try:
            pid = int(raw_id.split("_", 1)[1])
            product = database.get_product(pid)
            if product and database.product_visible(product, guided=False):
                ids = state.get("product_ids") or state.get("candidate_ids") or []
                cs.set(
                    phone,
                    cs.PRODUCT_DETAIL,
                    product_id=int(product["id"]),
                    previous_product_ids=ids,
                    previous_page=int(state.get("page") or 0),
                    main_category=state.get("main_category") or "",
                    subcategory=state.get("subcategory") or "",
                )
                return orders.format_product_details(product)
        except Exception:
            return None
    if raw_id == "ORDER_START":
        pid = state.get("product_id")
        product = database.get_product(int(pid)) if pid else None
        if not config_env.booking_enabled():
            return "الحجز غير متوفر حاليًا من خلال البوت."
        if product:
            cs.set(phone, cs.WAITING_FOR_QUANTITY, product_id=int(product["id"]))
            return "اختر الكمية المطلوبة."
    if raw_id.startswith("QTY_"):
        try:
            qty = int(raw_id.split("_", 1)[1])
            pid = state.get("product_id")
            product = database.get_product(int(pid)) if pid else None
            if product and config_env.booking_enabled():
                order_id = orders.create_order(phone, product, qty)
                cs.clear(phone)
                return f"✅ تم تسجيل طلبك. سيراجعك فريق الصيدلية.\nرقم الطلب: #{order_id}"
        except Exception:
            return None
    return None

def handle_text(phone: str, text: str) -> str:
    raw = str(text or "").strip()
    state = cs.get(phone)
    current = cs.current_name(state)
    interactive_reply = _handle_interactive_id(phone, raw, state)
    if interactive_reply is not None:
        return interactive_reply
    n = _norm(raw)

    if not raw:
        return show_start(phone)
    if is_menu(raw):
        return show_main_menu(phone)
    if is_help(raw):
        return HELP_MESSAGE
    if is_cancel(raw):
        return show_main_menu(phone)
    if is_start(raw):
        return show_main_menu(phone)
    if is_greeting(raw):
        if current in {"", cs.START, cs.MAIN_MENU}:
            return show_start(phone)
        return show_main_menu(phone)
    if is_back(raw):
        return handle_back(phone, state)

    if not current or current == cs.START:
        if n in {_norm("بحث"), _norm("بحث باسم منتج"), _norm("البحث عن منتج")}:
            return show_search_method(phone)
        if n in {_norm("تصفح"), _norm("تصفح الأقسام"), _norm("تصفح الاقسام"), _norm("الأقسام"), _norm("اقسام")}:
            return show_categories(phone)
        if n in {_norm("صورة"), _norm("البحث بصورة"), _norm("ارسال صورة")}:
            return show_image_prompt(phone)
        if n in {_norm("معلومات"), _norm("معلومات الصيدلية")}:
            return show_info(phone)
        result = matcher.match_text(raw)
        return handle_search_result(phone, result, original_query=raw)

    if current == cs.MAIN_MENU:
        return handle_main_menu_choice(phone, raw)

    if current == cs.WAITING_FOR_SEARCH_METHOD:
        choice = number_choice(raw)
        if choice == 1 or n in {_norm("اكتب اسم المنتج"), _norm("البحث بالاسم"), _norm("اسم"), _norm("name")}:
            return show_search_prompt(phone)
        if choice == 2 or n in {_norm("أرسل صورة المنتج"), _norm("ارسل صورة المنتج"), _norm("البحث بالصورة"), _norm("صورة"), _norm("image"), _norm("photo")}:
            return show_image_prompt(phone)
        if choice == 3:
            return show_main_menu(phone)
        return SEARCH_METHOD_MESSAGE


    if current == "WAITING_FOR_IMAGE_CONFIRMATION":
        choice = number_choice(raw)
        if raw in {"IMAGE_CONFIRM_NO"} or n in _normset({"لا", "لا لا", "no", "n", "الغاء", "إلغاء"}) or choice == 2:
            try:
                database.reject_safe_text_memory(state.get("confirmation_query") or state.get("text_query") or "", int(state.get("pending_product_id") or state.get("product_id") or 0))
            except Exception:
                pass
            cs.set(phone, cs.WAITING_FOR_PRODUCT_SEARCH)
            return "🔍 لم أجد المنتج في قائمة الصيدلية.\nيرجى التأكد من الاسم، أو إرسال صورة أوضح للمنتج."
        if raw in {"IMAGE_CONFIRM_YES"} or n in _normset(YES_WORDS) or choice == 1:
            if database.import_in_progress():
                return "⏳ جاري تحديث الأسعار الآن. يمكنك البحث عن المنتجات، لكن تأكيد الطلبات متوقف مؤقتًا لثوانٍ. حاول بعد قليل."
            pid = state.get("pending_product_id")
            if not pid:
                pid = state.get("product_id")  # backward compatibility only
            if pid:
                product = database.get_product(int(pid))
                if product and database.product_visible(product, guided=False):
                    extracted_slots = state.get("extracted_slots") or {}
                    learn_result = {}
                    try:
                        learn_result = visual_memory.learn_from_confirmation(
                            extracted_slots,
                            product,
                            merchant_id=int(product.get("merchant_id") or 1),
                            user_key=phone,
                        ) or {}
                    except Exception:
                        learn_result = {}
                    # Gemini Safe Economy Mode:
                    # Save only exact confirmed image_hashes. This never displays
                    # price directly from a future image; it only pre-fills the
                    # same confirmation question without another Gemini call.
                    if state.get("image_hash"):
                        try:
                            database.set_image_cache(
                                str(state.get("image_hash") or ""),
                                str(state.get("media_id") or ""),
                                extracted_slots,
                                int(product["id"]),
                                "EXACT_IMAGE_CONFIRMED",
                                str((extracted_slots or {}).get("confidence") or ""),
                            )
                        except Exception:
                            pass
                    if learn_result.get("approved"):
                        try:
                            database.set_image_cache(
                                str(state.get("image_hash") or ""),
                                str(state.get("media_id") or ""),
                                extracted_slots,
                                int(product["id"]),
                                "VISUAL_MEMORY_APPROVED",
                                str((extracted_slots or {}).get("confidence") or ""),
                            )
                        except Exception:
                            pass
                    # Store conservative exact text memory after confirmation.
                    # Generic one-word queries are rejected inside database.py.
                    try:
                        for _candidate_text in [
                            state.get("confirmation_query"),
                            state.get("text_query"),
                            (extracted_slots or {}).get("query"),
                            (extracted_slots or {}).get("primary_title"),
                            (extracted_slots or {}).get("product_name"),
                            (extracted_slots or {}).get("foreground_product_text"),
                        ]:
                            if _candidate_text:
                                database.add_safe_text_memory(
                                    _candidate_text,
                                    int(product["id"]),
                                    source=str(state.get("source") or "confirmed_product"),
                                    user_key=phone,
                                )
                    except Exception:
                        pass
                    try:
                        database.record_search_log(int(product["id"]), product.get("name") or "", user_id=phone, source="image_confirmation")
                    except Exception:
                        pass
                    cs.set(phone, cs.PRODUCT_DETAIL, product_id=int(product["id"]), source="confirmed_image")
                    return orders.format_product_details(product)
            # Image confirmations must be tied to a pending product id. Do not
            # re-run text matching from confirmation_query on "yes", because that
            # can convert a brand-only title into a wrong product/price.
            return "لم يتم تحديد منتج واضح من الصورة. اكتب اسم المنتج كاملًا أو أرسل صورة أوضح."
        return "هل تريد المتابعة بهذا المنتج؟ اكتب نعم أو 1، أو اكتب لا لإرسال اسم المنتج يدويًا."

    if current == cs.WAITING_FOR_PRODUCT_SEARCH:
        result = matcher.match_text(raw)
        return handle_search_result(phone, result, original_query=raw)

    if current == cs.WAITING_FOR_PRODUCT_IMAGE:
        result = matcher.match_text(raw)
        return handle_search_result(phone, result, original_query=raw)

    if current == cs.BROWSING_CATEGORIES:
        choice = number_choice(raw)
        cats = state.get("categories") or category_browser.available_main_categories()
        if choice and 1 <= choice <= len(cats):
            return show_subcategories(phone, cats[choice - 1])
        for cat in cats:
            if n == _norm(cat):
                return show_subcategories(phone, cat)
        return "اختر القسم من القائمة بالأسفل."

    if current == cs.BROWSING_SUBCATEGORY:
        main = state.get("main_category") or ""
        subs = state.get("subcategories") or category_browser.available_subcategories(main)
        choice = number_choice(raw)
        selected = ""
        if choice and 1 <= choice <= len(subs):
            selected = subs[choice - 1]
        else:
            for sub in subs:
                if n == _norm(sub):
                    selected = sub
                    break
        if not selected:
            return f"{main}\nاختر التصنيف من القائمة بالأسفل."
        if selected == "بحث باسم دواء":
            return show_search_prompt(phone)
        if category_browser.needs_skin_type(main, selected):
            cs.set(phone, "WAITING_FOR_SKIN_TYPE", main_category=main, subcategory=selected)
            return category_browser.skin_type_menu()
        return show_product_page(phone, main, selected)

    if current == "WAITING_FOR_SKIN_TYPE":
        skin_type = category_browser.skin_type_from_choice(raw)
        if not skin_type:
            return category_browser.skin_type_menu()
        return show_product_page(phone, state.get("main_category") or "", state.get("subcategory") or "", skin_type=skin_type)

    if current == cs.BROWSING_PRODUCT_PAGE:
        ids = state.get("product_ids") or []
        page = int(state.get("page") or 0)
        products = _product_rows_from_ids(ids)
        if n in _normset(NEXT_WORDS):
            next_page = page + 1
            if next_page * 10 >= len(products):
                return "لا توجد منتجات إضافية.\nاكتب رجوع للعودة."
            cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=next_page, main_category=state.get("main_category") or "", subcategory=state.get("subcategory") or "", skin_type=state.get("skin_type") or "", hide_prices=bool(state.get("hide_prices")))
            if state.get("hide_prices"):
                return _format_products_without_prices(state.get("subcategory") or "المنتجات", products, page=next_page)
            return category_browser.format_product_page(state.get("subcategory") or "المنتجات", products, page=next_page)
        if n in _normset(PREV_WORDS):
            prev_page = max(0, page - 1)
            cs.set(phone, cs.BROWSING_PRODUCT_PAGE, product_ids=ids, page=prev_page, main_category=state.get("main_category") or "", subcategory=state.get("subcategory") or "", skin_type=state.get("skin_type") or "", hide_prices=bool(state.get("hide_prices")))
            if state.get("hide_prices"):
                return _format_products_without_prices(state.get("subcategory") or "المنتجات", products, page=prev_page)
            return category_browser.format_product_page(state.get("subcategory") or "المنتجات", products, page=prev_page)
        choice = number_choice(raw)
        if choice:
            idx = page * 10 + choice - 1
            if 0 <= idx < len(products):
                product = products[idx]
                cs.set(
                    phone,
                    cs.PRODUCT_DETAIL,
                    product_id=int(product["id"]),
                    previous_product_ids=ids,
                    previous_page=page,
                    main_category=state.get("main_category") or "",
                    subcategory=state.get("subcategory") or "",
                )
                return orders.format_product_details(product)
            return "الرقم خارج القائمة. اختر رقمًا من المنتجات المعروضة أو اكتب رجوع."
        return "اختر المنتج من القائمة بالأسفل، أو اختر بحث جديد."

    if current == cs.WAITING_FOR_IMAGE_CONFIRMATION:
        return whatsapp_interactive.image_confirmation_payload(phone, text or "هل هذا المنتج؟")
    if current == cs.WAITING_FOR_CLARIFICATION:
        candidate_ids = state.get("candidate_ids") or []
        choice = number_choice(raw)
        if choice and 1 <= choice <= len(candidate_ids):
            product = database.get_product(int(candidate_ids[choice - 1]))
            if product and database.product_visible(product, guided=False):
                cs.set(phone, cs.PRODUCT_DETAIL, product_id=int(product["id"]), source="clarification")
                return orders.format_product_details(product)
        pending = state.get("pending_query") or ""
        merged = (pending + " " + raw).strip() if pending else raw
        result = matcher.match_text(merged)
        return handle_search_result(phone, result, original_query=merged)

    if current == cs.PRODUCT_DETAIL:
        pid = state.get("product_id")
        product = database.get_product(int(pid)) if pid else None
        if n in _normset(YES_WORDS):
            if not config_env.booking_enabled():
                return "الحجز غير متوفر حاليًا من خلال البوت.\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."
            if product:
                cs.set(phone, cs.WAITING_FOR_QUANTITY, product_id=int(product["id"]))
                return "كم الكمية؟"
        if product:
            return orders.format_product_details(product)
        return show_main_menu(phone)

    if current == cs.WAITING_FOR_QUANTITY:
        if not config_env.booking_enabled():
            return show_main_menu(phone)
        qty = number_choice(raw) or 1
        pid = state.get("product_id")
        product = database.get_product(int(pid)) if pid else None
        if not product:
            return show_main_menu(phone)
        order_id = orders.create_order(phone, product, qty)
        cs.clear(phone)
        return f"تم تسجيل طلبك. سيراجعك فريق الصيدلية.\nرقم الطلب: #{order_id}"

    result = matcher.match_text(raw)
    return handle_search_result(phone, result, original_query=raw)


def build_interactive_payload(phone: str, text: str) -> Optional[Dict]:
    """Build the WhatsApp interactive message matching the current UI state.

    This function is intentionally UI-only: it reads conversation state and
    visible catalog rows, but it does not change matching, pricing, AI, or
    import logic.
    """
    state = cs.get(phone)
    current = cs.current_name(state)
    if text == START_MESSAGE:
        return whatsapp_interactive.start_button_payload(phone, text)
    if text == MAIN_MENU_MESSAGE or current == cs.MAIN_MENU:
        return whatsapp_interactive.main_menu_payload(phone, text if text == MAIN_MENU_MESSAGE else MAIN_MENU_MESSAGE)
    if text == SEARCH_METHOD_MESSAGE or current == cs.WAITING_FOR_SEARCH_METHOD:
        return whatsapp_interactive.search_method_payload(phone, text)
    if text == SEARCH_PROMPT or current == cs.WAITING_FOR_PRODUCT_SEARCH:
        # If this state is showing a search result list, the product-page branch below takes priority.
        if state.get("product_ids"):
            pass
        else:
            return whatsapp_interactive.search_prompt_payload(phone, text)
    if text == IMAGE_PROMPT or current == cs.WAITING_FOR_PRODUCT_IMAGE:
        return whatsapp_interactive.image_prompt_payload(phone, text)
    if text == INFO_MESSAGE:
        return whatsapp_interactive.back_menu_payload(phone, text)
    if current == cs.BROWSING_CATEGORIES:
        cats = state.get("categories") or category_browser.available_main_categories()
        return whatsapp_interactive.category_payload(phone, "🗂️ اختر القسم المناسب من القائمة.", cats)
    if current == cs.BROWSING_SUBCATEGORY:
        main = state.get("main_category") or ""
        subs = state.get("subcategories") or category_browser.available_subcategories(main)
        return whatsapp_interactive.subcategory_payload(phone, f"{main}\nاختر التصنيف المناسب.", subs)
    if current == "WAITING_FOR_SKIN_TYPE":
        return whatsapp_interactive.skin_type_payload(phone, "اختر نوع البشرة لتحسين النتائج.")
    if current == cs.WAITING_FOR_CLARIFICATION:
        candidate_ids = state.get("candidate_ids") or []
        products = _product_rows_from_ids([int(x) for x in candidate_ids])
        rows = []
        for product in products[:9]:
            row = _format_product_row(product)
            row["id"] = f"CLARIFY_{int(product['id'])}"
            rows.append(row)
        if rows:
            return whatsapp_interactive.clarification_payload(phone, text or "حدد المنتج المطلوب من القائمة.", rows)
        return whatsapp_interactive.back_menu_payload(phone, text)
    if current == cs.BROWSING_PRODUCT_PAGE:
        ids = state.get("product_ids") or []
        page = int(state.get("page") or 0)
        products = _product_rows_from_ids([int(x) for x in ids])
        start = page * 10
        chunk = products[start:start + 8]
        rows = []
        hide_prices = bool(state.get("hide_prices"))
        for product in chunk:
            row = _format_product_row(product)
            if hide_prices:
                row["description"] = list_row_description(product, include_price=False)[:72]
            rows.append(row)
        has_next = start + 10 < len(products)
        has_prev = page > 0
        if rows:
            title = state.get("subcategory") or "المنتجات"
            return whatsapp_interactive.products_payload(phone, f"{title}\nاختر المنتج لعرض التفاصيل.", rows, has_next=has_next, has_prev=has_prev)
    if current == cs.PRODUCT_DETAIL:
        return whatsapp_interactive.product_detail_payload(phone, text, booking_enabled=config_env.booking_enabled())
    if current == cs.WAITING_FOR_QUANTITY:
        return whatsapp_interactive.quantity_payload(phone, text or "اختر الكمية.")
    if text:
        return whatsapp_interactive.back_menu_payload(phone, text)
    return None
