# PriceBot_FINAL_CLEAN_INSTALL_READY

Clean install package for PriceBot / WhatsApp Pharmacy Bot only.

This package is designed to create a new clean installation at:

`/opt/pricebot_clean`

It does not delete `/opt/pricebot`, does not touch MedMCQ, does not include `.env`, does not include `pricebot.db`, and does not include secrets.

## Included

- Final PriceBot code and WhatsApp UI flow.
- Catalog-based importer using `products_master_ready.xlsx`.
- Safe DB tools with explicit `--db-path` support.
- `clean_install_prepare.sh` to build a clean candidate.
- `switch_service_to_clean.sh` to switch `pricebot.service` after verification.
- `rollback_to_old_pricebot.sh` for fast rollback.
- `cleanup_old_after_48h.sh` to move the old install after 48h, only with explicit confirmation.

## Not included

- `.env`
- `pricebot.db`
- `*.db`, `*.sqlite`, WAL/SHM files
- ZIP files
- cache files
- demo files
- backups

## Safe flow

Run from the extracted ZIP folder:

```bash
sudo ./clean_install_prepare.sh
```

This will:

1. Stop only `pricebot.service` briefly.
2. Back up `/opt/pricebot` to `/root/pricebot_clean_install_backups/current_pricebot_<timestamp>`.
3. Restart the old bot while preparing the clean candidate.
4. Create `/opt/pricebot_clean`.
5. Copy final code only.
6. Copy `/opt/pricebot/.env` safely.
7. Set `PRICEBOT_DB_PATH=/opt/pricebot_clean/pricebot.db` in the clean `.env`.
8. Build a new clean DB from `/opt/pricebot_clean/products_master_ready.xlsx`.
9. Run verify and acceptance tests.

After successful preparation, switch the service:

```bash
sudo /opt/pricebot_clean/switch_service_to_clean.sh
```

Test:

```bash
sudo systemctl status pricebot --no-pager -l
curl -sS http://127.0.0.1:8090/health
TOKEN="$(grep -E '^META_VERIFY_TOKEN=' /opt/pricebot_clean/.env | cut -d= -f2-)" && curl -i "https://46.101.148.246.sslip.io/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=${TOKEN}&hub.challenge=PING"
```

Expected webhook response:

`HTTP 200` and `PING`.

## Rollback

If anything fails after switching:

```bash
sudo /opt/pricebot_clean/rollback_to_old_pricebot.sh
```

## Cleanup after 48h

Do not run this until the clean install has worked for at least 48 hours.

```bash
sudo CONFIRM_CLEANUP_OLD_PRICEBOT=YES /opt/pricebot_clean/cleanup_old_after_48h.sh
```

This moves `/opt/pricebot` to `/root/pricebot_retired/...`; it does not permanently delete backups.

## Manual DB rebuild command

Use only with explicit `--db-path`:

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/import_master_excel.py /opt/pricebot_clean/products_master_ready.xlsx --db-path /opt/pricebot_clean/pricebot.db --dry-run
./venv/bin/python tools/import_master_excel.py /opt/pricebot_clean/products_master_ready.xlsx --db-path /opt/pricebot_clean/pricebot.db
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot_clean/pricebot.db --excel-path /opt/pricebot_clean/products_master_ready.xlsx
```
