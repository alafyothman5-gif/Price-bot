#!/usr/bin/env bash
set -euo pipefail

OLD_DIR="${PRICEBOT_OLD_DIR:-/opt/pricebot}"
CLEAN_DIR="${PRICEBOT_CLEAN_DIR:-/opt/pricebot_clean}"
SERVICE_PATH="/etc/systemd/system/pricebot.service"
SERVICE_NAME="pricebot.service"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_clean_install_backups}"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: run as root or with sudo." >&2
  exit 1
fi
if [ ! -d "$OLD_DIR" ]; then
  echo "ERROR: old PriceBot directory missing: $OLD_DIR" >&2
  exit 1
fi

BACKUP_UNIT=""
if [ -f "$CLEAN_DIR/.rollback_service_unit" ]; then
  BACKUP_UNIT="$(cat "$CLEAN_DIR/.rollback_service_unit")"
fi
if [ -z "$BACKUP_UNIT" ] || [ ! -f "$BACKUP_UNIT" ]; then
  BACKUP_UNIT="$(ls -1t "$BACKUP_ROOT"/pricebot.service.before_clean_switch_* 2>/dev/null | head -n 1 || true)"
fi

if [ -n "$BACKUP_UNIT" ] && [ -f "$BACKUP_UNIT" ]; then
  cp "$BACKUP_UNIT" "$SERVICE_PATH"
else
  cat > "$SERVICE_PATH" <<EOF
[Unit]
Description=PriceBot WhatsApp Pharmacy Bot
After=network.target

[Service]
WorkingDirectory=$OLD_DIR
EnvironmentFile=$OLD_DIR/.env
Environment=PRICEBOT_DB_PATH=$OLD_DIR/pricebot.db
ExecStart=$OLD_DIR/venv/bin/uvicorn app:app --host 127.0.0.1 --port 8090
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF
fi

systemctl daemon-reload
systemctl restart "$SERVICE_NAME"
sleep 3
systemctl status "$SERVICE_NAME" --no-pager -l
curl -fsS --max-time 5 http://127.0.0.1:8090/health || true

echo "ROLLBACK_TO_OLD_PRICEBOT_DONE old_dir=$OLD_DIR"
