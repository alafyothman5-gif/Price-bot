#!/usr/bin/env python3
import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from normalizer import normalize_text

PASS = 0
FAIL = 0


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run PriceBot WhatsApp UI flow acceptance tests against a selected DB.")
    p.add_argument("--db-path", required=True, help="SQLite DB path to test. Example: /tmp/test.sqlite")
    return p.parse_args()


def check(name, condition, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"PASS {name} {detail}")
    else:
        FAIL += 1
        print(f"FAIL {name} {detail}")


def has_any(text: str, words) -> bool:
    n = normalize_text(text)
    return any(normalize_text(w) in n for w in words)


async def run_tests():
    import app
    import matcher
    import conversation_state as cs

    database.init_db(run_production_guard=False)
    phone = "ACCEPTANCE_UI_FLOW_PHONE"
    database.clear_state(phone)

    before_products = database.count_products()
    check("DB integrity", str(database.integrity_check()).lower() == "ok", database.integrity_check())
    check("products not zero", before_products > 0, str(before_products))

    r = await app.process_text(phone, "مرحبا")
    check("01 greeting shows start", "ابدأ الاستخدام" in r and "صيدلية بدر" in r, r[:80])

    r = await app.process_text(phone, "ابدأ")
    check("02 start shows main menu", "البحث عن منتج" in r and "تصفح الأقسام" in r and "البحث بصورة" in r, r[:100])

    r = await app.process_text(phone, "1")
    st = database.get_state(phone)
    check("03 main menu 1 enters search", "اكتب اسم المنتج" in r and cs.current_name(st) == cs.WAITING_FOR_PRODUCT_SEARCH, cs.current_name(st))

    r = await app.process_text(phone, "فلاجيل")
    st = database.get_state(phone)
    check("04 search flagyl clarifies not menu", "فلاجيل" in r.lower() or "flagyl" in r.lower() or "حدد" in r, r[:140])
    check("04b clarification state", cs.current_name(st) == cs.WAITING_FOR_CLARIFICATION, cs.current_name(st))

    r = await app.process_text(phone, "القائمة")
    check("05 menu command resets", "كيف تريد البحث" in r and cs.current_name(database.get_state(phone)) == cs.MAIN_MENU)

    r = await app.process_text(phone, "2")
    check("06 main menu 2 opens categories", "اختر القسم" in r and "أدوية" in r and "عناية بالبشرة" in r, r[:120])

    r = await app.process_text(phone, "3")
    check("07 category opens subcategories", "عناية بالبشرة" in r and "غسول" in r and "سيروم" in r, r[:120])

    r = await app.process_text(phone, "1")
    check("08 skincare asks skin type", "نوع البشرة" in r and "دهنية" in r, r[:120])

    r = await app.process_text(phone, "1")
    check("09 subcategory products only", "غسول وجه" in r and "اكتب رقم المنتج" in r, r[:160])
    forbidden = ["shampoo", "baby wash", "body wash"]
    check("09b no obvious wrong category words on page", not any(x in r.lower() for x in forbidden), r[:200])

    r = await app.process_text(phone, "1")
    check("10 product page numeric opens detail", "✅ المنتج متوفر" in r and "السعر" in r, r[:160])

    r = await app.process_text(phone, "رجوع")
    check("11 back returns to product list", "صفحة" in r and "اكتب رقم المنتج" in r, r[:120])

    r = await app.process_text(phone, "التالي")
    check("12 next page works", "صفحة 2" in r or "لا توجد منتجات إضافية" in r, r[:120])

    r = await app.process_text(phone, "القائمة")
    await app.process_text(phone, "3")
    st = database.get_state(phone)
    check("13 image mode state", cs.current_name(st) == cs.WAITING_FOR_PRODUCT_IMAGE, cs.current_name(st))

    async def fake_download(media_id: str):
        return b"fake", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة. من فضلك أرسل صورة أوضح يظهر فيها اسم المنتج كاملًا."}

    app.download_whatsapp_media = fake_download
    app.vision_service.extract_product_from_image = fake_extract
    r = await app.process_image(phone, "fake-media")
    check("14 unclear image message", "الصورة غير واضحة" in r, r[:120])

    async def fake_payload(to_number, payload):
        return False
    sent = []
    async def fake_text(to_number, text):
        sent.append(text)
        return True
    app.send_whatsapp_payload = fake_payload
    app.send_whatsapp_message = fake_text
    ok = await app.send_reply_with_optional_interactive(phone, app.ui_flow.MAIN_MENU_MESSAGE)
    check("15 interactive fallback text works", ok and sent and "كيف تريد البحث" in sent[-1])

    database.clear_state(phone)
    res = matcher.match_text("Cerave")
    check("16 brand-only no random exact", res.status == "ASK_CLARIFICATION", res.status)

    res = matcher.match_text("غسول")
    check("17 type-only no random exact", res.status == "ASK_CLARIFICATION", res.status)

    res = matcher.match_text("Rilastil Xerolact PB")
    check("18 not available no random alternatives", res.status in {"NOT_AVAILABLE", "ASK_CLARIFICATION"} and res.status != "EXACT_MATCH", res.status)

    after_products = database.count_products()
    check("19 no product destructive path", before_products == after_products, f"before={before_products} after={after_products}")

    print(f"ACCEPTANCE_RESULT pass={PASS} fail={FAIL}")
    return 0 if FAIL == 0 else 1


def main() -> int:
    args = parse_args()
    database.configure_db_path(args.db_path)
    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={database.get_db_path()}")
    return asyncio.run(run_tests())


if __name__ == "__main__":
    raise SystemExit(main())
