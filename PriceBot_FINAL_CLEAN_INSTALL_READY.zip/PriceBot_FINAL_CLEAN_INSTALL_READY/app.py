import asyncio
import hashlib
import hmac
import os
import re
import time
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse

import admin
import database
import guided_commerce
import matcher
import merchant
import orders
import vision_service
import ui_flow
import whatsapp_interactive
from normalizer import clean_query, normalize_text

load_dotenv()

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")
ADMIN_NOTIFY_PHONE = re.sub(r"\D+", "", os.getenv("ADMIN_NOTIFY_PHONE", ""))
QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_QUEUE_MAXSIZE", "500"))
WORKERS = int(os.getenv("PRICEBOT_WORKERS", "4"))
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "25"))
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60"))

MAIN_MENU = ui_flow.MAIN_MENU_MESSAGE
START_WORDS = ui_flow.START_WORDS | ui_flow.GREETING_WORDS | ui_flow.MENU_WORDS

app = FastAPI(title="PriceBot Clean Guided Search V1")
app.include_router(admin.router)
app.include_router(merchant.router)
queue: asyncio.Queue = asyncio.Queue(maxsize=QUEUE_MAXSIZE)
http_client: Optional[httpx.AsyncClient] = None
rate_buckets: Dict[str, deque] = defaultdict(deque)


def log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["token", "secret", "authorization"]):
            v = "HIDDEN"
        if k in {"phone", "to", "from_"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def rate_limit_ok(phone: str) -> bool:
    now = time.time()
    b = rate_buckets[phone]
    while b and now - b[0] > RATE_LIMIT_WINDOW:
        b.popleft()
    if len(b) >= RATE_LIMIT_MESSAGES:
        return False
    b.append(now)
    return True


def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET:
        return False
    if not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


async def send_whatsapp_message(to_number: str, text: str) -> bool:
    if not text:
        return False
    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number, text=text[:120])
        return True
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": text[:3900]}}
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_ERROR", status=resp.status_code, response=resp.text[:200])
            return False
        return True
    except Exception as exc:
        log("SEND_EXCEPTION", error=repr(exc))
        return False


async def send_whatsapp_payload(to_number: str, payload: Dict) -> bool:
    if not META_TOKEN or not PHONE_ID:
        log("SEND_INTERACTIVE_SKIPPED_NO_META", to=to_number)
        return False
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_INTERACTIVE_ERROR", status=resp.status_code, response=resp.text[:200])
            return False
        return True
    except Exception as exc:
        log("SEND_INTERACTIVE_EXCEPTION", error=repr(exc))
        return False


async def send_reply_with_optional_interactive(to_number: str, text: str) -> bool:
    # Try WhatsApp interactive messages for the two most important navigation
    # points.  If Meta rejects the interactive payload, fallback text is sent.
    if text == ui_flow.START_MESSAGE:
        body = f"🌿 {PHARMACY_NAME}\n\nأهلاً بك.\nاضغط ابدأ الاستخدام للبحث عن المنتجات والأسعار والتوفر."
        if await send_whatsapp_payload(to_number, whatsapp_interactive.start_button_payload(to_number, body)):
            return True
    if text == ui_flow.MAIN_MENU_MESSAGE:
        body = f"🌿 {PHARMACY_NAME}\n\nكيف تريد البحث؟"
        if await send_whatsapp_payload(to_number, whatsapp_interactive.main_menu_payload(to_number, body)):
            return True
    return await send_whatsapp_message(to_number, text)


async def notify_admin(text: str) -> None:
    if ADMIN_NOTIFY_PHONE:
        await send_whatsapp_message(ADMIN_NOTIFY_PHONE, text)


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not META_TOKEN:
        return b"", "image/jpeg"
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    assert http_client is not None
    meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
    meta.raise_for_status()
    info = meta.json()
    url = info.get("url", "")
    mime = info.get("mime_type", "image/jpeg")
    if not url:
        return b"", mime
    data = await http_client.get(url, headers=headers, timeout=20)
    data.raise_for_status()
    return data.content, mime


def extract_messages(payload: Dict) -> List[Dict]:
    out: List[Dict] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        text = (inter.get("button_reply") or {}).get("title") or (inter.get("button_reply") or {}).get("id") or ""
                    elif inter.get("type") == "list_reply":
                        text = (inter.get("list_reply") or {}).get("title") or (inter.get("list_reply") or {}).get("id") or ""
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out


def _number_choice(text: str) -> Optional[int]:
    t = normalize_text(text)
    if t.isdigit():
        n = int(t)
        if 1 <= n <= 999:
            return n
    return None


def _main_sections_for_state() -> List[str]:
    return guided_commerce.available_main_sections() or guided_commerce.MAIN_SECTIONS


def _sub_sections_for_state(main: str) -> List[str]:
    return guided_commerce.available_sub_sections(main)


def _products_by_ids(ids: List[int]) -> List[Dict]:
    out = []
    for pid in ids:
        p = database.get_product(int(pid))
        if p and database.product_visible(p, guided=False):
            out.append(p)
    return out


def _show_product_list(phone: str, products_list: List[Dict], page: int = 0) -> str:
    ids = [int(p["id"]) for p in products_list if p.get("id")]
    database.set_state(phone, {"mode": "product_list", "ids": ids, "page": page})
    return orders.format_product_list(products_list, page=page)


def _show_guided_products(phone: str, main: str, sub: str, skin_type: str = "", page: int = 0) -> str:
    # Load more than one page into state, but keep DB query bounded.
    plist = database.guided_products(main, sub, skin_type=skin_type, page=0, page_size=80)
    # Apply stricter skincare filter after DB index for safety.
    plist = [p for p in plist if guided_commerce.product_allowed_in_subsection(p, main, sub, skin_type)]
    if not plist:
        database.clear_state(phone)
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار."
    return _show_product_list(phone, plist, page=page)


def _handle_search_result(phone: str, result) -> str:
    if result.status == "EXACT_MATCH" and result.product:
        database.set_state(phone, {"mode": "product_details", "product_id": int(result.product["id"])})
        return orders.format_product_details(result.product)
    if result.status == "PRODUCT_LIST" and result.products:
        return (result.message + "\n\n" if result.message else "") + _show_product_list(phone, result.products, page=0)
    if result.status == "ASK_CLARIFICATION":
        state = {"mode": "awaiting_clarification", "pending_query": ""}
        if result.products:
            state["candidate_ids"] = [int(p["id"]) for p in result.products if p.get("id")]
        database.set_state(phone, state)
        return result.message or "أحتاج تفاصيل أكثر قبل عرض السعر."
    if result.status == "NOT_AVAILABLE":
        database.clear_state(phone)
        return result.message or "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا."
    return result.message or "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل."


async def process_text(phone: str, text: str) -> str:
    return ui_flow.handle_text(phone, text)


async def process_image(phone: str, media_id: str) -> str:
    await send_whatsapp_message(phone, "جاري فحص الصورة، انتظر لحظات...")
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception:
        return "تعذر تحميل الصورة. الرجاء إرسال صورة أوضح أو كتابة اسم المنتج."
    extracted = await vision_service.extract_product_from_image(image_bytes, mime)
    if extracted.get("status") != "OK":
        return extracted.get("message") or "الصورة غير واضحة. الرجاء إرسال صورة أوضح للواجهة الأمامية للمنتج."
    result = matcher.match_text(extracted.get("query", ""))
    return ui_flow.handle_search_result(phone, result, original_query=extracted.get("query", ""))


async def worker(worker_id: int) -> None:
    while True:
        item = await queue.get()
        try:
            phone = item["phone"]
            if not rate_limit_ok(phone):
                await send_whatsapp_message(phone, "وصلت رسائل كثيرة بسرعة. الرجاء المحاولة بعد قليل.")
                continue
            if item.get("id") and not database.mark_processed(item.get("id")):
                continue
            if item.get("type") == "image" or item.get("media_id"):
                reply = await process_image(phone, item.get("media_id"))
            else:
                reply = await process_text(phone, item.get("text", ""))
            await send_reply_with_optional_interactive(phone, reply)
        except Exception as exc:
            log("WORKER_ERROR", worker=worker_id, error=repr(exc))
            try:
                await send_whatsapp_message(item.get("phone", ""), "حدث خطأ مؤقت. الرجاء المحاولة مرة أخرى.")
            except Exception:
                pass
        finally:
            queue.task_done()


@app.on_event("startup")
async def startup() -> None:
    global http_client
    database.init_db(run_production_guard=True)
    http_client = httpx.AsyncClient()
    for i in range(WORKERS):
        asyncio.create_task(worker(i + 1))
    log("PRICEBOT_STARTED", workers=WORKERS, products=database.count_products())


@app.on_event("shutdown")
async def shutdown() -> None:
    if http_client:
        await http_client.aclose()


@app.get("/health")
def health():
    return {
        "ok": True,
        "products_count": database.count_products(),
        "integrity": database.integrity_check(),
        "search_index_count": database.count_table("product_search_index"),
        "guided_index_count": database.count_table("guided_catalog_index"),
        "queue_size": queue.qsize(),
    }


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    body = await request.body()
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        return PlainTextResponse("bad signature", status_code=403)
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json"}, status_code=400)
    messages = extract_messages(payload)
    for msg in messages:
        try:
            queue.put_nowait(msg)
        except asyncio.QueueFull:
            log("QUEUE_FULL", phone=msg.get("phone"))
    return {"ok": True, "queued": len(messages)}
