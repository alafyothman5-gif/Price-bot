#!/usr/bin/env bash
set -euo pipefail

CLEAN_DIR="${PRICEBOT_CLEAN_DIR:-/opt/pricebot_clean}"
OLD_DIR="${PRICEBOT_OLD_DIR:-/opt/pricebot}"
SERVICE_PATH="/etc/systemd/system/pricebot.service"
SERVICE_NAME="pricebot.service"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_clean_install_backups}"
STAMP="$(date +%Y%m%d_%H%M%S)"
UNIT_BACKUP="$BACKUP_ROOT/pricebot.service.before_clean_switch_$STAMP"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: run as root or with sudo." >&2
  exit 1
fi
if [ "$CLEAN_DIR" != "/opt/pricebot_clean" ] || [ "$OLD_DIR" != "/opt/pricebot" ]; then
  echo "ERROR: refusing non-standard paths. CLEAN_DIR=$CLEAN_DIR OLD_DIR=$OLD_DIR" >&2
  exit 1
fi
if [ ! -f "$CLEAN_DIR/app.py" ] || [ ! -f "$CLEAN_DIR/.env" ] || [ ! -f "$CLEAN_DIR/pricebot.db" ]; then
  echo "ERROR: clean install is incomplete. Run clean_install_prepare.sh first." >&2
  exit 1
fi
mkdir -p "$BACKUP_ROOT"

cd "$CLEAN_DIR"
./venv/bin/python -m compileall .
./venv/bin/python tools/verify_production.py --db-path "$CLEAN_DIR/pricebot.db" --excel-path "$CLEAN_DIR/products_master_ready.xlsx"

if [ -f "$SERVICE_PATH" ]; then
  cp "$SERVICE_PATH" "$UNIT_BACKUP"
  echo "$UNIT_BACKUP" > "$CLEAN_DIR/.rollback_service_unit"
fi

cat > "$SERVICE_PATH" <<EOF
[Unit]
Description=PriceBot WhatsApp Pharmacy Bot - Clean Install
After=network.target

[Service]
WorkingDirectory=$CLEAN_DIR
EnvironmentFile=$CLEAN_DIR/.env
Environment=PRICEBOT_DB_PATH=$CLEAN_DIR/pricebot.db
ExecStart=$CLEAN_DIR/venv/bin/uvicorn app:app --host 127.0.0.1 --port 8090
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl stop "$SERVICE_NAME" || true
systemctl start "$SERVICE_NAME"
sleep 3
if ! systemctl is-active --quiet "$SERVICE_NAME"; then
  echo "ERROR: clean service failed. Rolling back service unit." >&2
  if [ -f "$UNIT_BACKUP" ]; then
    cp "$UNIT_BACKUP" "$SERVICE_PATH"
    systemctl daemon-reload
    systemctl restart "$SERVICE_NAME" || true
  fi
  systemctl status "$SERVICE_NAME" --no-pager -l || true
  exit 1
fi

curl -fsS --max-time 5 http://127.0.0.1:8090/health >/tmp/pricebot_clean_health.txt || {
  echo "ERROR: health check failed. Rolling back service unit." >&2
  if [ -f "$UNIT_BACKUP" ]; then
    cp "$UNIT_BACKUP" "$SERVICE_PATH"
    systemctl daemon-reload
    systemctl restart "$SERVICE_NAME" || true
  fi
  exit 1
}

cat > "$CLEAN_DIR/CLEAN_SWITCH_STATUS.txt" <<EOF
PRICEBOT_SERVICE_SWITCHED_TO_CLEAN=OK
clean_dir=$CLEAN_DIR
old_dir_kept_for_rollback=$OLD_DIR
unit_backup=$UNIT_BACKUP
health=$(cat /tmp/pricebot_clean_health.txt)
EOF

echo "PRICEBOT_SERVICE_SWITCHED_TO_CLEAN=OK"
echo "Old install kept untouched for rollback: $OLD_DIR"
echo "Keep it at least 48 hours before cleanup."
