#!/usr/bin/env bash
set -euo pipefail

OLD_DIR="${PRICEBOT_OLD_DIR:-/opt/pricebot}"
CLEAN_DIR="${PRICEBOT_CLEAN_DIR:-/opt/pricebot_clean}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_clean_install_backups}"
RELEASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
CURRENT_BACKUP="$BACKUP_ROOT/current_pricebot_$STAMP"
PREVIOUS_CLEAN_BACKUP="$BACKUP_ROOT/previous_pricebot_clean_$STAMP"

require_root() {
  if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: run as root or with sudo." >&2
    exit 1
  fi
}

refuse_dangerous_paths() {
  case "$OLD_DIR" in
    /opt/pricebot) ;;
    *) echo "ERROR: OLD_DIR must be /opt/pricebot unless you know exactly what you are doing. Got: $OLD_DIR" >&2; exit 1 ;;
  esac
  case "$CLEAN_DIR" in
    /opt/pricebot_clean) ;;
    *) echo "ERROR: CLEAN_DIR must be /opt/pricebot_clean. Got: $CLEAN_DIR" >&2; exit 1 ;;
  esac
  if echo "$OLD_DIR $CLEAN_DIR" | grep -Eiq 'medmcq|med-mcq|telegram'; then
    echo "ERROR: refusing any path that may touch MedMCQ." >&2
    exit 1
  fi
}

require_root
refuse_dangerous_paths

if [ ! -d "$OLD_DIR" ]; then
  echo "ERROR: current PriceBot directory not found: $OLD_DIR" >&2
  exit 1
fi
if [ ! -f "$OLD_DIR/.env" ]; then
  echo "ERROR: current .env not found: $OLD_DIR/.env" >&2
  exit 1
fi
if [ ! -f "$RELEASE_DIR/products_master_ready.xlsx" ]; then
  echo "ERROR: products_master_ready.xlsx missing from release ZIP." >&2
  exit 1
fi

mkdir -p "$BACKUP_ROOT"

WAS_ACTIVE=0
if systemctl is-active --quiet "$SERVICE_NAME"; then
  WAS_ACTIVE=1
fi

echo "STEP 1/8: stopping PriceBot briefly for a consistent backup..."
systemctl stop "$SERVICE_NAME" || true

echo "STEP 2/8: full current backup => $CURRENT_BACKUP"
mkdir -p "$CURRENT_BACKUP"
rsync -a --numeric-ids \
  --exclude '__pycache__/' --exclude '*.pyc' \
  "$OLD_DIR"/ "$CURRENT_BACKUP"/

# Bring the old working bot back while the clean candidate is prepared.
if [ "$WAS_ACTIVE" = "1" ]; then
  echo "Restarting current PriceBot while clean candidate is prepared..."
  systemctl start "$SERVICE_NAME" || true
fi

echo "STEP 3/8: creating clean directory $CLEAN_DIR"
if [ -e "$CLEAN_DIR" ]; then
  echo "Existing clean dir found. Moving it to $PREVIOUS_CLEAN_BACKUP"
  mv "$CLEAN_DIR" "$PREVIOUS_CLEAN_BACKUP"
fi
mkdir -p "$CLEAN_DIR"

rsync -a --delete \
  --exclude '.env' --exclude 'pricebot.db' --exclude '*.db' --exclude '*.sqlite' --exclude '*.db-wal' --exclude '*.db-shm' \
  --exclude '*.zip' --exclude '__pycache__/' --exclude '*.pyc' --exclude 'backups/' \
  "$RELEASE_DIR"/ "$CLEAN_DIR"/

cp "$OLD_DIR/.env" "$CLEAN_DIR/.env"
chmod 600 "$CLEAN_DIR/.env"

# Prevent accidental fallback to the old /opt/pricebot DB when the clean service starts.
if ! grep -q '^PRICEBOT_DB_PATH=' "$CLEAN_DIR/.env"; then
  printf '\n# Added by clean_install_prepare.sh\nPRICEBOT_DB_PATH=%s/pricebot.db\n' "$CLEAN_DIR" >> "$CLEAN_DIR/.env"
else
  sed -i "s#^PRICEBOT_DB_PATH=.*#PRICEBOT_DB_PATH=$CLEAN_DIR/pricebot.db#" "$CLEAN_DIR/.env"
fi

mkdir -p "$CLEAN_DIR/backups"

echo "STEP 4/8: creating virtualenv and installing requirements"
python3 -m venv "$CLEAN_DIR/venv"
"$CLEAN_DIR/venv/bin/pip" install --upgrade pip >/dev/null
"$CLEAN_DIR/venv/bin/pip" install -r "$CLEAN_DIR/requirements.txt"

echo "STEP 5/8: compile check"
cd "$CLEAN_DIR"
./venv/bin/python -m compileall .

echo "STEP 6/8: dry-run import into clean DB path"
./venv/bin/python tools/import_master_excel.py "$CLEAN_DIR/products_master_ready.xlsx" --db-path "$CLEAN_DIR/pricebot.db" --dry-run

echo "STEP 7/8: building clean DB from products_master_ready.xlsx"
./venv/bin/python tools/import_master_excel.py "$CLEAN_DIR/products_master_ready.xlsx" --db-path "$CLEAN_DIR/pricebot.db"

echo "STEP 8/8: verify clean candidate"
./venv/bin/python tools/verify_production.py --db-path "$CLEAN_DIR/pricebot.db" --excel-path "$CLEAN_DIR/products_master_ready.xlsx"
./venv/bin/python tools/run_acceptance_tests.py --db-path "$CLEAN_DIR/pricebot.db"

cat > "$CLEAN_DIR/CLEAN_INSTALL_STATUS.txt" <<EOF
PRICEBOT_CLEAN_INSTALL_PREPARED=OK
old_dir=$OLD_DIR
clean_dir=$CLEAN_DIR
current_backup=$CURRENT_BACKUP
previous_clean_backup=$PREVIOUS_CLEAN_BACKUP
service_not_switched_yet=1
next_command=$CLEAN_DIR/switch_service_to_clean.sh
EOF

echo "CLEAN_INSTALL_PREPARED_OK"
echo "Current old bot kept for rollback: $OLD_DIR"
echo "Current full backup: $CURRENT_BACKUP"
echo "Clean candidate: $CLEAN_DIR"
echo "Next, switch service only after reviewing verify output: sudo $CLEAN_DIR/switch_service_to_clean.sh"
