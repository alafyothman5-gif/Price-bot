#!/usr/bin/env bash
set -euo pipefail

OLD_DIR="${PRICEBOT_OLD_DIR:-/opt/pricebot}"
CLEAN_DIR="${PRICEBOT_CLEAN_DIR:-/opt/pricebot_clean}"
RETIRE_ROOT="${PRICEBOT_RETIRE_ROOT:-/root/pricebot_retired}"
SERVICE_PATH="/etc/systemd/system/pricebot.service"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: run as root or with sudo." >&2
  exit 1
fi
if [ "${CONFIRM_CLEANUP_OLD_PRICEBOT:-}" != "YES" ]; then
  echo "REFUSED: set CONFIRM_CLEANUP_OLD_PRICEBOT=YES only after 48h of confirmed clean operation." >&2
  exit 2
fi
if ! grep -q "WorkingDirectory=$CLEAN_DIR" "$SERVICE_PATH"; then
  echo "REFUSED: pricebot.service is not pointing to $CLEAN_DIR." >&2
  exit 2
fi
if ! systemctl is-active --quiet pricebot.service; then
  echo "REFUSED: pricebot.service is not active." >&2
  exit 2
fi
if [ ! -d "$OLD_DIR" ]; then
  echo "OLD_DIR already absent: $OLD_DIR"
  exit 0
fi
mkdir -p "$RETIRE_ROOT"
TARGET="$RETIRE_ROOT/pricebot_old_$STAMP"
mv "$OLD_DIR" "$TARGET"
echo "OLD_PRICEBOT_MOVED_NOT_DELETED=$TARGET"
echo "Backups are preserved. Remove retired folder manually only after a longer retention period."
