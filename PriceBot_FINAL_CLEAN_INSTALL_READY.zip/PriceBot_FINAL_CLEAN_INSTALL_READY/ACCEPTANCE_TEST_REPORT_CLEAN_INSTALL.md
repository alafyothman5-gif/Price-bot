# PriceBot FINAL CLEAN INSTALL acceptance report

Package: `PriceBot_FINAL_CLEAN_INSTALL_READY.zip`

## Static package checks

- NO_ENV_IN_ZIP=OK
- NO_DB_IN_ZIP=OK
- NO_SQLITE_IN_ZIP=OK
- NO_ZIP_INSIDE_ZIP=OK
- NO_PYC_OR_PYCACHE=OK
- NO_DEMO_FILES=OK
- MEDMCQ_NOT_REFERENCED=OK

## Clean install safety

- Does not delete `/opt/pricebot`.
- Does not remove `/opt/pricebot/.env`.
- Does not remove `/opt/pricebot/pricebot.db`.
- Does not delete backups.
- Creates `/opt/pricebot_clean`.
- Copies `.env` from `/opt/pricebot/.env` to `/opt/pricebot_clean/.env`.
- Forces `PRICEBOT_DB_PATH=/opt/pricebot_clean/pricebot.db` for the clean service.
- Builds a clean DB from `products_master_ready.xlsx` using explicit `--db-path`.
- Keeps old `/opt/pricebot` available for rollback for at least 48 hours.

## Local DB build test

Command:

```bash
python3 tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/pricebot_clean_test.sqlite --dry-run
python3 tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/pricebot_clean_test.sqlite
python3 tools/verify_production.py --db-path /tmp/pricebot_clean_test.sqlite --excel-path products_master_ready.xlsx
python3 tools/run_acceptance_tests.py --db-path /tmp/pricebot_clean_test.sqlite
```

Result:

- Excel rows accepted: 5791
- products_after: 5791
- integrity_check: ok
- product_search_index: 23746
- guided_catalog_index: 5785
- processed_messages unique: OK
- conversation_state unique: OK
- product_search_index schema: OK
- guided_catalog_index schema: OK
- product_nav_index: NOT_USED_OR_EMPTY
- acceptance tests: pass=23 fail=0

## Required server checks after switch

```bash
sudo systemctl status pricebot --no-pager -l
curl -sS http://127.0.0.1:8090/health
TOKEN="$(grep -E '^META_VERIFY_TOKEN=' /opt/pricebot_clean/.env | cut -d= -f2-)" && curl -i "https://46.101.148.246.sslip.io/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=${TOKEN}&hub.challenge=PING"
```

Expected webhook result: `HTTP 200` and `PING`.
