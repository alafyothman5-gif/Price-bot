import re
import unicodedata
from typing import Iterable, List

ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
ARABIC_MAP = {
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ة": "ه", "ى": "ي", "ؤ": "و", "ئ": "ي",
    "ی": "ي", "ک": "ك", "گ": "ك", "چ": "ج", "پ": "ب", "ڤ": "ف",
}
LATIN_VARIANTS = {
    "moisturising": "moisturizing",
    "moisturiser": "moisturizer",
    "moisturising": "moisturizing",
    "sunblock": "sunscreen",
    "sun block": "sunscreen",
    "facewash": "face wash",
    "cera ve": "cerave",
    "la roche": "laroche",
}
STOPWORDS = {
    "متوفر", "موجود", "عندكم", "في", "فيه", "السعر", "سعر", "كم", "بكم", "نبي", "ابي", "اريد", "ممكن",
    "لو", "سمحت", "please", "price", "available", "do", "you", "have", "عليكم", "السلام", "مرحبا", "اهلا",
}
GENERIC_SEARCH_TERMS = {
    "غسول", "كريم", "دواء", "ادويه", "ادوية", "حديد", "فيتامين", "فيتامينات", "شامبو", "بلسم",
    "مرطب", "واقي", "واقي شمس", "سيروم", "مكمل", "مكملات", "سيرافي", "cerave",
    "lotion", "cream", "cleanser", "wash", "shampoo", "serum", "sunscreen", "vitamin", "iron", "medicine",
}

def normalize_text(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = text.translate(ARABIC_DIGITS)
    for src, dst in ARABIC_MAP.items():
        text = text.replace(src, dst)
    text = text.lower()
    text = text.replace("+", " plus ")
    text = re.sub(r"(?<=\d)\s*mg\b", " mg", text)
    text = re.sub(r"(?<=\d)\s*ml\b", " ml", text)
    for src, dst in LATIN_VARIANTS.items():
        text = text.replace(src, dst)
    text = re.sub(r"[^0-9a-z\u0600-\u06FF]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def compact_normalize(value: object) -> str:
    return normalize_text(value).replace(" ", "")

def split_multi(value: object) -> List[str]:
    text = str(value or "").strip()
    if not text:
        return []
    parts = re.split(r"\s*\|\s*|\s*,\s*|\s*;\s*|\n+", text)
    out = []
    seen = set()
    for p in parts:
        p = p.strip()
        if p and p not in seen:
            out.append(p)
            seen.add(p)
    return out

def clean_query(value: object) -> str:
    n = normalize_text(value)
    if not n:
        return ""
    tokens = [t for t in n.split() if t not in STOPWORDS]
    return " ".join(tokens).strip()

def tokens(value: object) -> List[str]:
    return [t for t in normalize_text(value).split() if t and t not in STOPWORDS]

def is_generic_query(value: object) -> bool:
    q = clean_query(value)
    if not q:
        return True
    if q in GENERIC_SEARCH_TERMS:
        return True
    parts = q.split()
    if len(parts) == 1 and (parts[0] in GENERIC_SEARCH_TERMS or len(parts[0]) <= 2 and not parts[0].isdigit()):
        return True
    return False

def truthy(value: object) -> bool:
    n = normalize_text(value)
    return n in {"1", "true", "yes", "y", "متوفر", "available", "ok", "نعم"}

def safe_price(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        num = float(text)
        if num.is_integer():
            return str(int(num))
        return f"{num:.2f}".rstrip("0").rstrip(".")
    except Exception:
        return text
