# Open Data Alias Build Report

Status: script implemented and compile-tested. It was not executed against the real production database because `/opt/pricebot_clean/pricebot.db` is not available inside this build environment and must not be included in the ZIP.

Script:

```bash
./venv/bin/python tools/build_aliases_from_open_data.py \
  --sources-dir data/open_alias_sources \
  --report OPEN_DATA_ALIAS_BUILD_REPORT.md
```

Production path:

- Active directory: `/opt/pricebot_clean`
- Database: `/opt/pricebot_clean/pricebot.db`

Safety rules implemented:

- The script is manual/offline; it does not run during deploy.
- It supports local CSV/TSV/JSON/JSONL sources and optional URL input.
- It does not use fuzzy matching.
- It writes only to `product_aliases`.
- It never updates prices, availability, product rows, WhatsApp settings, or image cache.
- It rejects ambiguous aliases when the same normalized alias maps to more than one product.
- It skips DrugBank-like sources unless `--allow-restricted-source` is explicitly passed and a valid commercial-use license exists.
- Open-data aliases do not allow direct price display from images. Images still require foreground validation, `strict_image_candidate_validator`, and user confirmation.

Build-environment test coverage:

```text
PYTHONPATH=. pytest -q tests/test_open_data_alias_builder.py
2 passed
```

Notes:

- No production product count is claimed in this report because the real server DB is not available here.
- Do not reuse old reports containing outdated counts such as `4982`.
