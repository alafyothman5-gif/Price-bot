#!/usr/bin/env bash
set -Eeuo pipefail
# Production-safe installer wrapper.  This release must not rebuild, delete, or
# replace the live pricebot.db.  It delegates to deploy_pricebot_clean.sh, which
# preserves .env, pricebot.db, and uploads/.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$DIR/deploy_pricebot_clean.sh"
