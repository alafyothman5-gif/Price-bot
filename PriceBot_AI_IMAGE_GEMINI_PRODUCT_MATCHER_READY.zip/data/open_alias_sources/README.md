# Open Alias Sources

Put open-license CSV/TSV/JSON/JSONL files here before running:

```bash
./venv/bin/python tools/build_aliases_from_open_data.py --sources-dir data/open_alias_sources --report OPEN_DATA_ALIAS_BUILD_REPORT.md
```

The runtime bot does not need internet access. DrugBank data must not be used unless the pharmacy has a commercial-use license.
