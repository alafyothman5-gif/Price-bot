from __future__ import annotations

import database
from normalizer import normalize_text
from services.matching.excel_native_matcher import ENGINE, match_vision_slots
from services.vision import visual_memory


def _insert_product(conn, name: str, price: str = "10", **extra) -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": normalize_text(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    payload.update({k: str(v) for k, v in extra.items() if k in payload})
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def _reset(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_visual_test.db"))
    database.init_db(run_production_guard=False)
    visual_memory.ensure_schema()
    ENGINE.invalidate()


def _mizon_slots():
    return {
        "status": "OK",
        "brand": "Mizon",
        "primary_title": "Cicaluronic Low PH Cleanser",
        "product_family": "Cicaluronic Low PH Cleanser",
        "foreground_product_text": "Mizon Cicaluronic Low PH Cleanser",
        "form": "cleanser",
        "confidence": "0.96",
        "query": "Mizon Cicaluronic Low PH Cleanser",
    }


def test_mizon_incomplete_excel_name_is_not_auto_exact_before_admin_approval(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "low ph cleanser", "55", form="cleanser")
    product = database.get_product(pid)
    slots = _mizon_slots()

    learn = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="u1")
    ENGINE.invalidate()
    result = match_vision_slots(slots)

    assert learn["approved"] is False
    assert learn["reason"] in {"brand_mismatch", "pending_until_threshold"}
    assert result.status != "EXACT_MATCH"
    assert visual_memory.lookup_visual_memory(slots, merchant_id=1) is None


def test_admin_approval_enables_overlay_for_incomplete_excel_name(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "low ph cleanser", "55", form="cleanser")
    product = database.get_product(pid)
    slots = _mizon_slots()

    approved = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="admin", admin_approved=True)
    ENGINE.invalidate()
    result = match_vision_slots(slots)

    assert approved["approved"] is True
    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == pid
    assert result.product.get("canonical_display_name") == "Mizon Cicaluronic Low PH Cleanser"
    assert result.diagnostics.get("stage") in {"visual_product_memory_hit", "product_identity_overlay_exact"}


def test_visual_memory_approves_only_after_three_distinct_users(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "Mizon Cicaluronic Low PH Cleanser", "55", brand="Mizon", form="cleanser")
    product = database.get_product(pid)
    slots = _mizon_slots()

    first = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="u1")
    repeat_same_user = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="u1")
    second = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="u2")
    assert first["approved"] is False
    assert repeat_same_user["confirmed_count"] == 1
    assert second["approved"] is False
    assert visual_memory.lookup_visual_memory(slots, merchant_id=1) is None

    third = visual_memory.learn_from_confirmation(slots, product, merchant_id=1, user_key="u3")
    ENGINE.invalidate()
    result = match_vision_slots(slots)

    assert third["approved"] is True
    assert third["confirmed_count"] == 3
    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == pid
    assert result.diagnostics.get("stage") == "visual_product_memory_hit"


def test_strict_validator_rejects_brand_form_and_size_mismatch():
    slots = {"brand": "Transition", "primary_title": "Transition", "form": "cream", "size": "4g"}
    wrong_brand = {"id": 1, "name": "Other Transition 4g", "brand": "Other", "form": "cream", "size": "4g"}
    wrong_form = {"id": 2, "name": "Transition Lotion 4g", "brand": "Transition", "form": "lotion", "size": "4g"}
    wrong_size = {"id": 3, "name": "Transition 10g", "brand": "Transition", "form": "cream", "size": "10g"}
    ok = {"id": 4, "name": "Transition 4g", "brand": "Transition", "form": "cream", "size": "4g"}

    assert not visual_memory.strict_image_candidate_validator(slots, wrong_brand)
    assert not visual_memory.strict_image_candidate_validator(slots, wrong_form)
    assert not visual_memory.strict_image_candidate_validator(slots, wrong_size)
    assert visual_memory.strict_image_candidate_validator(slots, ok)


def test_flagyl_image_never_matches_metronidazole_wrong_size(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        flagyl_id = _insert_product(conn, "Flagyl 125mg/5ml oral suspension 60ml", "20", brand="Flagyl", form="suspension", strength="125mg/5ml", size="60ml")
        metro_id = _insert_product(conn, "Metronidazole suspension 100ml", "18", brand="Metronidazole", form="suspension", size="100ml")
    ENGINE.invalidate()

    result = match_vision_slots({
        "brand": "Flagyl",
        "primary_title": "Flagyl",
        "product_family": "Flagyl",
        "foreground_product_text": "Flagyl 125mg/5ml oral suspension 60ml",
        "form": "suspension",
        "strength": "125mg/5ml",
        "size": "60ml",
        "confidence": "0.95",
        "query": "Flagyl 125mg/5ml oral suspension 60ml",
    })

    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == flagyl_id
    assert int(result.product["id"]) != metro_id


def test_hemazym_ingredients_do_not_match_folic_acid(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        hemazym_id = _insert_product(conn, "Hemazym", "40", brand="Hemazym")
        folic_id = _insert_product(conn, "Folic Acid", "12", brand="Folic Acid")
    ENGINE.invalidate()

    result = match_vision_slots({
        "brand": "Hemazym",
        "primary_title": "Hemazym",
        "foreground_product_text": "Hemazym Liposomal Iron",
        "background_text": "Folic Acid Vitamin B12 Zinc",
        "ingredients": ["Folic Acid", "Vitamin B12", "Zinc"],
        "confidence": "0.95",
        "query": "Hemazym",
    })

    assert result.status == "EXACT_MATCH"
    assert result.product and int(result.product["id"]) == hemazym_id
    assert int(result.product["id"]) != folic_id


def test_transition_size_mismatch_does_not_sell_wrong_size(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        _insert_product(conn, "Transition 10g", "30", brand="Transition", size="10g")
    ENGINE.invalidate()

    result = match_vision_slots({
        "brand": "Transition",
        "primary_title": "Transition",
        "foreground_product_text": "Transition 4g",
        "size": "4g",
        "confidence": "0.95",
        "query": "Transition 4g",
    })

    assert result.status in {"NOT_AVAILABLE", "ASK_CLARIFICATION", "LOW_CONFIDENCE"}
    assert not (result.status == "EXACT_MATCH" and result.product and normalize_text(result.product.get("size")) == "10g")
