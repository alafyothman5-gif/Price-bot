from __future__ import annotations

import pytest

pytestmark = pytest.mark.skip(
    reason="Legacy product_aliases image path retired. Image matching now uses AI matcher in tests/test_ai_image_gemini_product_matcher.py."
)


def test_legacy_alias_image_path_retired():
    assert True
