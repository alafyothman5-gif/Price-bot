from __future__ import annotations

import pytest

import database


def _insert_product(conn, name: str, price: str = "10") -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": database.clean_alias_text(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


@pytest.mark.asyncio
async def test_ai_image_match_sets_pending_product_id_without_price(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_ai_image_match.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        crestor = _insert_product(conn, "Crestor 20mg", "35")

    async def fake_download(media_id):
        return b"tilted-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "IMAGE_UNCLEAR",
            "query": "CRESTOR 20mg",
            "foreground_product_text": "CRESTOR 20mg",
            "primary_title": "CRESTOR",
            "raw_vision_text": "CRESTOR 20mg",
            "message": "الصورة مائلة أو مقصوصة",
        }

    async def fake_ai(text):
        assert "CRESTOR" in text or "crestor" in text.lower()
        return {"matched": True, "product_id": crestor, "name": "Crestor 20mg", "source": "test_ai"}

    state = {}
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.ai_product_matcher, "match_extracted_text_to_product", fake_ai)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000010", "media-crestor")
    assert "هل هذا المنتج" in reply
    assert "Crestor 20mg" in reply
    assert "35" not in reply
    assert state.get("state") == "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("pending_product_id") == crestor


@pytest.mark.asyncio
async def test_ai_image_match_false_requests_manual_name(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_ai_image_false.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        _insert_product(conn, "MIZON Cicaluronic Low PH Cleanser", "42")
        _insert_product(conn, "Good Bye Blemish Low PH Cleanser", "44")

    async def fake_download(media_id):
        return b"image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "Low PH Cleanser",
            "foreground_product_text": "Low PH Cleanser",
            "primary_title": "Low PH Cleanser",
            "confidence": 0.95,
        }

    async def fake_ai(text):
        return {"matched": False}

    state = {}
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.ai_product_matcher, "match_extracted_text_to_product", fake_ai)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000011", "media-low-ph")
    assert "هل هذا المنتج" not in reply
    assert "اكتب" in reply or "لم أتعرف" in reply
    assert state.get("pending_product_id") is None


@pytest.mark.asyncio
async def test_empty_image_without_text_still_returns_unclear(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_ai_image_empty.db"))
    database.init_db(run_production_guard=False)

    async def fake_download(media_id):
        return b"blank", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {"status": "IMAGE_UNCLEAR", "query": "", "all_texts": [], "raw_vision_text": "", "message": "الصورة غير كافية للتعرف على المنتج."}

    state = {}
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000012", "media-empty")
    assert "الصورة" in reply or "اكتب" in reply
    assert state.get("pending_product_id") is None
