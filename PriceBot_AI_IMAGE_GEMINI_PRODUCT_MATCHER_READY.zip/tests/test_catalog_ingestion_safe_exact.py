from pathlib import Path

import openpyxl

import database
from catalog_ingestion.build_master_aliases import build_master_aliases
from catalog_ingestion.db import ensure_schema
from catalog_ingestion.processor import approve_staging_job, create_and_verify_staging_job


def _insert_product(conn, name: str, price: str) -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": name.lower(),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def test_safe_catalog_ingestion_exact_only(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_test.db"))
    database.init_db(run_production_guard=False)
    ensure_schema()
    with database.connect() as conn:
        _insert_product(conn, "Panadol Advance 500mg Tablets", "10")
        _insert_product(conn, "Panadol Extra 500mg Tablets", "11")
        _insert_product(conn, "Flagyl Syrup 125mg 120ml", "15")
    build_master_aliases()

    xlsx = tmp_path / "upload.xlsx"
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["name", "price"])
    ws.append(["Panadol Advance 500 mg Tablets", "12"])
    ws.append(["Panadol", "9"])
    ws.append(["Unknown Product X", "20"])
    ws.append(["Flagyl Syrup 125mg 120ml", "15"])
    ws.append(["Bad Price", "abc"])
    ws.append(["Panadol Advance 500 mg Tablets", "13"])
    wb.save(xlsx)

    job_id = database.create_catalog_import_job("upload.xlsx", str(xlsx), status="queued")
    report = create_and_verify_staging_job(job_id, str(xlsx), 1)
    assert report["summary"]["safe_updates_count"] == 1
    assert report["summary"]["unchanged_count"] == 1
    assert report["summary"]["review_count"] == 2
    assert report["summary"]["invalid_count"] == 1
    assert report["summary"]["duplicate_count"] == 1

    result = approve_staging_job(job_id, actor="pytest")
    assert result["status"] == "PARTIALLY_APPROVED"
    with database.connect() as conn:
        rows = conn.execute("SELECT name, price FROM products ORDER BY id").fetchall()
        assert rows[0]["price"] == "13"
        assert rows[1]["price"] == "11"
        assert rows[2]["price"] == "15"
        pending = conn.execute("SELECT COUNT(*) FROM catalog_review_items WHERE status='PENDING'").fetchone()[0]
        assert pending == 2
