from __future__ import annotations

import pytest

from services.vision.evidence_validator import parse_vision_response, validate_vision_payload


def test_bad_json_title_only_never_becomes_price_match():
    raw = "HEMAZYM\nLiposomal Iron\nFolic Acid"
    parsed = parse_vision_response(raw)
    evidence = validate_vision_payload(parsed)
    assert evidence.status == "OK"
    assert evidence.needs_confirmation_only is True
    assert evidence.query
    assert "هل تقصد" in evidence.message


def test_ingredients_do_not_override_primary_title():
    payload = {
        "foreground_product_text": "Hemazym Liposomal Iron",
        "primary_title": "Hemazym",
        "brand": "Hemazym",
        "product_family": "Hemazym",
        "background_text": "Folic Acid Vitamin B12 Zinc",
        "raw_vision_text": "Hemazym Folic Acid Vitamin B12 Zinc",
        "confidence": 0.94,
    }
    evidence = validate_vision_payload(payload)
    assert evidence.status == "OK"
    assert "folic" not in evidence.query.lower()
    assert "vitamin" not in evidence.query.lower()
    assert "hemazym" in evidence.query.lower()


@pytest.mark.asyncio
async def test_image_exact_match_requires_confirmation_before_price(monkeypatch):
    import app

    async def fake_send(*args, **kwargs):
        return True

    async def fake_download(media_id):
        return b"fake-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "Vichy Normaderm",
            "foreground_product_text": "VICHY NORMADERM",
            "primary_title": "Normaderm",
            "brand": "Vichy",
            "product_family": "Normaderm",
            "confidence": "0.95",
        }

    product = {"id": 10, "name": "Normaderm Vichy", "price": "138", "available": 1}

    async def fake_ai_match(text):
        return {"matched": True, "product_id": 10, "name": "Normaderm Vichy", "source": "test_ai"}

    state = {}
    monkeypatch.setattr(app, "send_whatsapp_message", fake_send)
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.ai_product_matcher, "match_extracted_text_to_product", fake_ai_match)
    monkeypatch.setattr(app.database, "get_product", lambda product_id: product if int(product_id) == 10 else None)
    monkeypatch.setattr(app.database, "product_visible", lambda p, guided=False: True)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000000", "media-1")
    assert "هل هذا المنتج" in reply
    assert "138" not in reply
    assert state.get("state") == "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("product_id") == 10
