from __future__ import annotations

import csv
from pathlib import Path

import database
from normalizer import normalize_text
from tools.build_aliases_from_open_data import build_aliases_from_open_data


def _insert_product(conn, name: str, price: str = "10", **extra) -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": normalize_text(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    payload.update({k: str(v) for k, v in extra.items() if k in payload})
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def _reset(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_open_alias_test.db"))
    database.init_db(run_production_guard=False)


def test_open_data_alias_builder_inserts_only_safe_unique_aliases(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "Hemazym Liposomal Iron", "40", brand="Hemazym", form="tablet")
        _insert_product(conn, "Folic Acid", "12", brand="Folic Acid", form="tablet")

    src_dir = tmp_path / "sources"
    src_dir.mkdir()
    csv_path = src_dir / "openfda_sample.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["brand_name", "product_name", "generic_name", "dosage_form"])
        writer.writeheader()
        writer.writerow({
            "brand_name": "Hemazym",
            "product_name": "Hemazym Liposomal Iron",
            "generic_name": "Folic Acid Vitamin B12 Zinc",
            "dosage_form": "tablet",
        })

    report = tmp_path / "OPEN_DATA_ALIAS_BUILD_REPORT.md"
    stats = build_aliases_from_open_data(sources_dir=str(src_dir), report=str(report), dry_run=False)

    assert stats["ok"] is True
    assert stats["source_files_read"] == 1
    assert stats["aliases_inserted"] >= 1
    assert report.exists()
    with database.connect() as conn:
        rows = conn.execute("SELECT product_id, alias_normalized, source FROM product_aliases WHERE source='open_data_safe'").fetchall()
        aliases = [(int(r[0]), str(r[1])) for r in rows]
    assert any(row_pid == pid and "hemazym" in alias for row_pid, alias in aliases)
    assert not any(alias.strip() == "folic acid" for _, alias in aliases)


def test_open_data_alias_builder_skips_restricted_drugbank_source_without_license(tmp_path):
    _reset(tmp_path)
    with database.connect() as conn:
        _insert_product(conn, "Safe Product", "10", brand="Safe")
    restricted = tmp_path / "drugbank_sample.csv"
    restricted.write_text("brand_name,product_name\nSafe,Safe Product\n", encoding="utf-8")

    report = tmp_path / "OPEN_DATA_ALIAS_BUILD_REPORT.md"
    stats = build_aliases_from_open_data(sources_dir=str(tmp_path / "missing"), sources=[str(restricted)], report=str(report), dry_run=True)

    assert stats["source_files_read"] == 0
    assert any("restricted" in w.lower() for w in stats["warnings"])
    assert "DrugBank" in report.read_text(encoding="utf-8")
