import database
from catalog_ingestion.db import ensure_schema
from catalog_ingestion.normalizer import normalize_arabic_name, rebuild_merchant_alias_normalized_names
from catalog_ingestion.processor import _load_master_exact_index, _match_row


def _insert_product(conn, name: str, price: str = "10", **extra) -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": normalize_arabic_name(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    payload.update({k: str(v) for k, v in extra.items()})
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def _fresh_db(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_v2_test.db"))
    database.init_db(run_production_guard=False)
    ensure_schema()


def test_14_arabic_normalization_bridge():
    assert normalize_arabic_name("بنادول أدفانس ٥٠٠") == normalize_arabic_name("بنادول ادفانس 500")
    assert normalize_arabic_name("بنادول ادفانس 500") == normalize_arabic_name("Panadol Advance 500mg")
    assert normalize_arabic_name("بنادول") == "panadol"
    assert normalize_arabic_name("فلاجيل") == "flagyl"
    assert normalize_arabic_name("سيرافي") == "cerave"
    assert normalize_arabic_name("بيودرما سنسيبيو") == "bioderma sensibio"


def test_15_safe_identity_match_and_variant_rejection(tmp_path):
    _fresh_db(tmp_path)
    with database.connect() as conn:
        _insert_product(
            conn,
            "Flagyl Oral Suspension 200mg 120ml",
            brand="flagyl",
            form="suspension",
            strength="200mg",
            size="120ml",
        )
        master_exact, token_index, product_rows = _load_master_exact_index(conn)
        decision, product_id, reason = _match_row(
            normalize_arabic_name("flagyl syrup 200mg"), {}, master_exact, token_index, product_rows
        )
        assert decision == "SAFE_IDENTITY_MATCH"
        assert product_id is not None

    _fresh_db(tmp_path)
    with database.connect() as conn:
        _insert_product(conn, "Flagyl Oral Suspension 125mg 120ml", brand="flagyl", form="suspension", strength="125mg", size="120ml")
        _insert_product(conn, "Flagyl Oral Suspension 200mg 120ml", brand="flagyl", form="suspension", strength="200mg", size="120ml")
        master_exact, token_index, product_rows = _load_master_exact_index(conn)
        decision, product_id, reason = _match_row(normalize_arabic_name("flagyl syrup"), {}, master_exact, token_index, product_rows)
        assert decision == "AMBIGUOUS_REVIEW"
        assert product_id is None
        decision, product_id, reason = _match_row(normalize_arabic_name("flagyl"), {}, master_exact, token_index, product_rows)
        assert decision == "AMBIGUOUS_REVIEW"
        assert product_id is None
        decision, product_id, reason = _match_row(normalize_arabic_name("panadol"), {}, master_exact, token_index, product_rows)
        assert decision in {"AMBIGUOUS_REVIEW", "NEW_PRODUCT_REVIEW"}
        assert decision != "SAFE_IDENTITY_MATCH"


def test_16_unsafe_rejected_single_generic_tokens(tmp_path):
    _fresh_db(tmp_path)
    with database.connect() as conn:
        master_exact, token_index, product_rows = _load_master_exact_index(conn)
        decision, product_id, reason = _match_row(normalize_arabic_name("غسول"), {}, master_exact, token_index, product_rows)
        assert decision == "UNSAFE_REJECTED"
        assert product_id is None
        decision, product_id, reason = _match_row(normalize_arabic_name("cream"), {}, master_exact, token_index, product_rows)
        assert decision == "UNSAFE_REJECTED"
        assert product_id is None


def test_17_token_hits_one_is_ambiguous_and_alias_migration(tmp_path):
    _fresh_db(tmp_path)
    with database.connect() as conn:
        pid = _insert_product(conn, "Unique Derm Product 50ml", brand="unique", form="cream", size="50ml")
        master_exact, token_index, product_rows = _load_master_exact_index(conn)
        decision, product_id, reason = _match_row(normalize_arabic_name("unique"), {}, master_exact, token_index, product_rows)
        assert decision == "AMBIGUOUS_REVIEW"
        assert product_id is None
        conn.execute(
            """
            INSERT INTO merchant_product_aliases(merchant_id, raw_name, normalized_raw_name, product_id, source, is_active)
            VALUES(1, 'بنادول ادفانس 500', 'بنادول ادفانس 500', ?, 'old', 1)
            """,
            (pid,),
        )
        result = rebuild_merchant_alias_normalized_names(conn)
        assert result["updated"] == 1
        row = conn.execute("SELECT normalized_raw_name FROM merchant_product_aliases WHERE raw_name='بنادول ادفانس 500'").fetchone()
        assert row[0] == "panadol advance 500"
