#!/usr/bin/env python3
"""Import AI-generated product aliases from CSV into product_aliases.

Expected CSV columns:
    original_name, alias_text

Matching rule is deliberately strict:
    clean(original_name) must equal clean(products.name) for one product only.

Unmatched or ambiguous original names are written to unmatched.csv and do not
modify production data.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database

REQUIRED_COLUMNS = {"original_name", "alias_text"}


def _open_text(path: Path):
    if str(path).lower().endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8-sig", newline="")
    return path.open("r", encoding="utf-8-sig", newline="")


def _read_rows(path: Path) -> Iterable[Dict[str, str]]:
    with _open_text(path) as fh:
        sample = fh.read(4096)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample)
        except Exception:
            dialect = csv.excel
        reader = csv.DictReader(fh, dialect=dialect)
        headers = {str(h or "").strip() for h in (reader.fieldnames or [])}
        missing = REQUIRED_COLUMNS - headers
        if missing:
            raise SystemExit(f"CSV missing required columns: {sorted(missing)}")
        for row in reader:
            yield {k: str(v or "").strip() for k, v in row.items()}


def _load_product_name_map(conn: Any) -> Dict[str, List[int]]:
    out: Dict[str, List[int]] = {}
    rows = conn.execute("SELECT id, name FROM products").fetchall()
    for row in rows:
        clean = database.clean_alias_text(row["name"] if hasattr(row, "keys") else row[1])
        if not clean:
            continue
        pid = int(row["id"] if hasattr(row, "keys") else row[0])
        out.setdefault(clean, []).append(pid)
    return out


def _insert_alias(conn: Any, product_id: int, alias_text: str, cleaned_alias: str, source: str = "ai_generated") -> bool:
    if not cleaned_alias:
        return False
    database.ensure_product_aliases_schema(conn)
    existing = conn.execute(
        """
        SELECT id FROM product_aliases
        WHERE product_id=? AND cleaned_alias=? AND COALESCE(active, is_active, approved, 1)=1
        LIMIT 1
        """,
        (int(product_id), cleaned_alias),
    ).fetchone()
    if existing:
        conn.execute(
            """
            UPDATE product_aliases
            SET alias_text=COALESCE(NULLIF(alias_text,''), ?), alias=COALESCE(NULLIF(alias,''), ?),
                confidence=MAX(COALESCE(confidence,0), 0.95), source=COALESCE(NULLIF(source,''), ?),
                active=1, is_active=1, approved=1, updated_at=datetime('now')
            WHERE id=?
            """,
            (alias_text, alias_text, source, int(existing[0])),
        )
        return False
    conn.execute(
        """
        INSERT INTO product_aliases(
            product_id, product_db_id, alias_text, cleaned_alias, confidence, source, active,
            alias, alias_normalized, normalized_alias, is_active, approved, created_at, updated_at
        ) VALUES(?,?,?,?,0.95,?,1,?,?,?,1,1,datetime('now'),datetime('now'))
        """,
        (int(product_id), int(product_id), alias_text, cleaned_alias, source, alias_text, cleaned_alias, cleaned_alias),
    )
    return True


def import_alias_csv(csv_path: Path, unmatched_path: Path, dry_run: bool = False) -> Dict[str, int]:
    stats = {
        "rows_total": 0,
        "aliases_inserted": 0,
        "aliases_existing": 0,
        "unmatched_products": 0,
        "ambiguous_products": 0,
        "invalid_rows": 0,
    }
    unmatched: List[Dict[str, str]] = []
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        database.ensure_product_aliases_schema(conn)
        product_map = _load_product_name_map(conn)
        for row in _read_rows(csv_path):
            stats["rows_total"] += 1
            original = str(row.get("original_name") or "").strip()
            alias = str(row.get("alias_text") or "").strip()
            if not original or not alias:
                stats["invalid_rows"] += 1
                unmatched.append({"original_name": original, "alias_text": alias, "reason": "missing_original_or_alias"})
                continue
            original_clean = database.clean_alias_text(original)
            alias_clean = database.clean_alias_text(alias)
            ids = product_map.get(original_clean, [])
            if not ids:
                stats["unmatched_products"] += 1
                unmatched.append({"original_name": original, "alias_text": alias, "reason": "no_exact_products_name_match"})
                continue
            if len(ids) > 1:
                stats["ambiguous_products"] += 1
                unmatched.append({"original_name": original, "alias_text": alias, "reason": f"multiple_products_name_match:{ids[:10]}"})
                continue
            if dry_run:
                stats["aliases_inserted"] += 1
                continue
            inserted = _insert_alias(conn, ids[0], alias, alias_clean)
            if inserted:
                stats["aliases_inserted"] += 1
            else:
                stats["aliases_existing"] += 1
    unmatched_path.parent.mkdir(parents=True, exist_ok=True)
    with unmatched_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["original_name", "alias_text", "reason"])
        writer.writeheader()
        writer.writerows(unmatched)
    return stats


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Import PriceBot AI-generated product aliases safely.")
    parser.add_argument("--csv", default="data/aliases/product_aliases_from_pricelist.csv", help="CSV with original_name,alias_text")
    parser.add_argument("--db-path", default="", help="SQLite DB path; production default is /opt/pricebot/pricebot.db via database resolver")
    parser.add_argument("--unmatched", default="unmatched.csv", help="Output CSV for rows that did not match products.name exactly")
    parser.add_argument("--dry-run", action="store_true", help="Validate and count without inserting aliases")
    args = parser.parse_args(argv)
    if args.db_path:
        database.configure_db_path(args.db_path)
    stats = import_alias_csv(Path(args.csv), Path(args.unmatched), dry_run=bool(args.dry_run))
    for k, v in stats.items():
        print(f"{k}={v}")
    print(f"UNMATCHED_CSV={Path(args.unmatched).resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
