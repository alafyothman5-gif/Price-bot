#!/usr/bin/env python3
from __future__ import annotations

"""Generate an admin catalog-quality report without modifying production data."""

from pathlib import Path
from typing import Any, Dict, List

import database
from normalizer import normalize_text

OUTPUT = Path("catalog_quality_report.xlsx")
REQUIRED_CORE = ["brand", "form", "strength", "size"]


def _has(product: Dict[str, Any], key: str) -> bool:
    value = str(product.get(key) or "").strip()
    if not value:
        return False
    return normalize_text(value) not in {"unknown", "غير معروف", "غير مصنف", "unclassified", "none", "null"}


def _row_issue(product: Dict[str, Any]) -> str:
    missing = [field for field in REQUIRED_CORE if not _has(product, field)]
    if missing:
        return "missing_" + ",".join(missing)
    return "ok"


def collect_rows() -> List[Dict[str, Any]]:
    rows = database.load_product_rows(visible_only=False, guided=False)
    out: List[Dict[str, Any]] = []
    for p in rows:
        issue = _row_issue(p)
        if issue == "ok":
            continue
        out.append({
            "id": p.get("id"),
            "name": p.get("name") or p.get("canonical_display_name") or "",
            "brand": p.get("brand") or "",
            "product_family": p.get("product_family") or "",
            "form": p.get("form") or p.get("medicine_form") or p.get("product_type") or "",
            "strength": p.get("strength") or "",
            "size": p.get("size") or "",
            "pack": p.get("pack") or "",
            "category": p.get("category") or p.get("main_section") or p.get("section") or "",
            "issue": issue,
            "exact_matching_policy": "blocked_until_review" if issue != "ok" else "allowed",
        })
    return out


def write_xlsx(path: Path = OUTPUT) -> Path:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "catalog_quality"
    headers = ["id", "name", "brand", "product_family", "form", "strength", "size", "pack", "category", "issue", "exact_matching_policy"]
    ws.append(headers)
    for row in collect_rows():
        ws.append([row.get(h, "") for h in headers])
    ws.freeze_panes = "A2"
    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max(max_len + 2, 12), 45)
    wb.save(path)
    return path


if __name__ == "__main__":
    out = write_xlsx(OUTPUT)
    print(f"CATALOG_QUALITY_REPORT_OK path={out} rows={len(collect_rows())}")
