#!/usr/bin/env python3
from __future__ import annotations

"""Build conservative product aliases from open-data CSV/JSON sources.

This is a one-time/offline utility. It is intentionally NOT run during deploy and
it never updates prices, availability, product rows, WhatsApp settings, or server
configuration.

Usage examples:
  ./venv/bin/python tools/build_aliases_from_open_data.py \
      --sources-dir data/open_alias_sources \
      --report OPEN_DATA_ALIAS_BUILD_REPORT.md

  ./venv/bin/python tools/build_aliases_from_open_data.py \
      --source /tmp/openfda_labels.csv --dry-run

Supported source formats: .csv, .tsv, .jsonl, .ndjson, .json and gzip versions.
If a URL is passed through --source, it is downloaded to a temporary file for that
run only. Runtime PriceBot does not depend on internet access.

Safety model:
* No fuzzy matching.
* Aliases are inserted only when the normalized alias maps to exactly one product.
* Ambiguous or weak aliases are written to the report, not activated.
* DrugBank is blocked unless --allow-restricted-source is explicitly provided,
  because public DrugBank data usually has licensing restrictions for commercial use.
"""

import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import re
import sys
import tempfile
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Set, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database  # noqa: E402
from catalog_ingestion.db import ensure_schema as ensure_catalog_schema  # noqa: E402
from catalog_ingestion.normalizer import normalize_arabic_name  # noqa: E402
from normalizer import normalize_text  # noqa: E402
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths, normalize_measure  # noqa: E402

RESTRICTED_SOURCE_HINTS = {"drugbank", "drug bank"}
SOURCE_EXTENSIONS = {".csv", ".tsv", ".jsonl", ".ndjson", ".json", ".gz"}

FIELD_ALIASES = {
    "brand": ["brand", "brand_name", "brand name", "openfda.brand_name", "trademark", "proprietary_name"],
    "name": ["name", "product_name", "product name", "openfda.brand_name", "medicine_name", "title", "label", "drug_name", "trade_name"],
    "generic": ["generic_name", "generic name", "openfda.generic_name", "active_ingredient", "active ingredient", "ingredient", "substance", "substance_name"],
    "form": ["form", "dosage_form", "dosage form", "route_form", "product_type", "type"],
    "strength": ["strength", "dosage", "active_strength", "concentration", "potency"],
    "size": ["size", "volume", "net_content", "package_size", "pack_size"],
    "pack": ["pack", "package", "package_description", "package desc", "quantity"],
}

AR_FORM_TRANSLATIONS = {
    "tablet": ["اقراص", "حبوب"],
    "tablets": ["اقراص", "حبوب"],
    "capsule": ["كبسولات", "كبسول"],
    "capsules": ["كبسولات", "كبسول"],
    "syrup": ["شراب"],
    "suspension": ["معلق", "شراب"],
    "cream": ["كريم"],
    "ointment": ["مرهم"],
    "gel": ["جل"],
    "cleanser": ["غسول"],
    "wash": ["غسول"],
    "lotion": ["لوشن"],
    "serum": ["سيروم"],
    "drops": ["قطرات", "نقط"],
    "spray": ["بخاخ", "سبراي"],
    "shampoo": ["شامبو"],
}

WEAK_ALIAS_TOKENS = {
    "the", "and", "for", "with", "new", "plus", "extra", "advance", "advanced",
    "cream", "gel", "lotion", "serum", "cleanser", "wash", "foam", "ointment",
    "tablet", "tablets", "capsule", "capsules", "syrup", "suspension", "drops",
    "solution", "oral", "topical", "skin", "face", "body", "care", "support",
    "vitamin", "iron", "zinc", "acid", "folic", "metronidazole", "paracetamol",
    "mg", "mcg", "ml", "g", "iu", "pack", "tube", "bottle", "box", "low", "ph",
    "كريم", "جل", "لوشن", "سيروم", "غسول", "مرهم", "شراب", "اقراص", "حبوب",
}


def _n(value: Any) -> str:
    return normalize_text(value)


def _alias_norm(value: Any) -> str:
    return normalize_arabic_name(str(value or ""))


def _tokens(value: Any) -> List[str]:
    return [t for t in _n(value).split() if t]


def _strong_tokens(value: Any) -> Set[str]:
    out: Set[str] = set()
    for t in _tokens(value):
        if t in WEAK_ALIAS_TOKENS:
            continue
        if len(t) <= 2 and not t.isdigit():
            continue
        if t.isdigit():
            continue
        out.add(t)
    return out


def _split_multi(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        parts: List[str] = []
        for item in value:
            parts.extend(_split_multi(item))
        return parts
    text = str(value).strip()
    if not text:
        return []
    raw = re.split(r"\s*\|\s*|\s*;\s*|\n+|\s*/\s*(?=[A-Za-z\u0600-\u06FF])", text)
    out: List[str] = []
    seen: Set[str] = set()
    for p in raw:
        p = p.strip(" ,;|\t\r\n")
        if p and _n(p) not in seen:
            out.append(p)
            seen.add(_n(p))
    return out


def _is_safe_alias(alias: str) -> bool:
    norm = _alias_norm(alias)
    toks = norm.split()
    if not norm or len(norm) < 4:
        return False
    if len(toks) < 2 and not any(ch.isdigit() for ch in norm):
        return False
    strong = [t for t in toks if t not in WEAK_ALIAS_TOKENS and (len(t) > 2 or any(ch.isdigit() for ch in t))]
    if not strong:
        return False
    # Single generic strong ingredient/type tokens are not safe global aliases.
    if len(strong) == 1 and strong[0] in {"folic", "metronidazole", "paracetamol", "cleanser", "lotion", "cream"}:
        return False
    return True


def _safe_join(parts: Sequence[Any]) -> str:
    return re.sub(r"\s+", " ", " ".join(str(p).strip() for p in parts if str(p or "").strip())).strip()


def _row_get(row: Dict[str, Any], logical: str) -> str:
    lower = {str(k).strip().lower(): v for k, v in row.items()}
    values: List[str] = []
    for key in FIELD_ALIASES.get(logical, []):
        v = lower.get(key.lower())
        if v is None:
            continue
        if isinstance(v, list):
            values.extend(str(x) for x in v if x)
        elif isinstance(v, dict):
            values.extend(str(x) for x in v.values() if x)
        else:
            values.append(str(v))
    return _safe_join(values)


def _flatten_json_record(record: Dict[str, Any], prefix: str = "") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key, value in (record or {}).items():
        k = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, dict):
            out.update(_flatten_json_record(value, k))
        elif isinstance(value, list):
            # Keep scalar lists usable for openFDA fields.
            scalars = [str(x) for x in value if not isinstance(x, (dict, list))]
            if scalars:
                out[k] = " | ".join(scalars)
            for i, item in enumerate(value[:3]):
                if isinstance(item, dict):
                    out.update(_flatten_json_record(item, f"{k}.{i}"))
        else:
            out[k] = value
    return out


def _open_text(path: Path) -> io.TextIOBase:
    if path.suffix.lower() == ".gz":
        return io.TextIOWrapper(gzip.open(path, "rb"), encoding="utf-8", errors="replace")
    return open(path, "r", encoding="utf-8", errors="replace")


def _iter_source_rows(path: Path) -> Iterator[Dict[str, Any]]:
    suffixes = [s.lower() for s in path.suffixes]
    compressed = suffixes[-1:] == [".gz"]
    inner_suffix = suffixes[-2] if compressed and len(suffixes) >= 2 else path.suffix.lower()
    with _open_text(path) as f:
        if inner_suffix == ".tsv":
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                yield dict(row)
        elif inner_suffix == ".csv":
            sample = f.read(4096)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample)
            except Exception:
                dialect = csv.excel
            reader = csv.DictReader(f, dialect=dialect)
            for row in reader:
                yield dict(row)
        elif inner_suffix in {".jsonl", ".ndjson"}:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        yield _flatten_json_record(obj)
                except Exception:
                    continue
        elif inner_suffix == ".json":
            try:
                obj = json.load(f)
            except Exception:
                return
            if isinstance(obj, dict):
                candidates = obj.get("results") or obj.get("data") or obj.get("items") or obj.get("records") or []
                if isinstance(candidates, list):
                    for item in candidates:
                        if isinstance(item, dict):
                            yield _flatten_json_record(item)
                else:
                    yield _flatten_json_record(obj)
            elif isinstance(obj, list):
                for item in obj:
                    if isinstance(item, dict):
                        yield _flatten_json_record(item)


def _download_url(url: str) -> Path:
    suffix = Path(url.split("?", 1)[0]).suffix or ".csv"
    fd, tmp = tempfile.mkstemp(prefix="pricebot_open_alias_", suffix=suffix)
    os.close(fd)
    with urllib.request.urlopen(url, timeout=60) as resp, open(tmp, "wb") as out:
        out.write(resp.read())
    return Path(tmp)


def _collect_source_paths(sources_dir: Path, explicit_sources: Sequence[str], allow_restricted: bool) -> Tuple[List[Path], List[str]]:
    warnings: List[str] = []
    paths: List[Path] = []
    if sources_dir.exists():
        for p in sorted(sources_dir.rglob("*")):
            if p.is_file() and (p.suffix.lower() in SOURCE_EXTENSIONS or any(s.lower() in SOURCE_EXTENSIONS for s in p.suffixes)):
                paths.append(p)
    for src in explicit_sources:
        src = src.strip()
        if not src:
            continue
        if src.startswith(("http://", "https://")):
            if any(h in src.lower() for h in RESTRICTED_SOURCE_HINTS) and not allow_restricted:
                warnings.append(f"SKIPPED restricted/licensed source URL: {src}")
                continue
            try:
                paths.append(_download_url(src))
            except Exception as exc:
                warnings.append(f"FAILED to download {src}: {exc!r}")
            continue
        p = Path(src)
        if any(h in str(p).lower() for h in RESTRICTED_SOURCE_HINTS) and not allow_restricted:
            warnings.append(f"SKIPPED restricted/licensed source path: {src}")
            continue
        if p.exists() and p.is_file():
            paths.append(p)
        elif p.exists() and p.is_dir():
            for child in sorted(p.rglob("*")):
                if child.is_file() and (child.suffix.lower() in SOURCE_EXTENSIONS or any(s.lower() in SOURCE_EXTENSIONS for s in child.suffixes)):
                    paths.append(child)
        else:
            warnings.append(f"SOURCE not found: {src}")
    # Dedupe preserving order.
    seen: Set[str] = set()
    final: List[Path] = []
    for p in paths:
        key = str(p.resolve()) if p.exists() else str(p)
        if key not in seen:
            seen.add(key)
            final.append(p)
    return final, warnings


def _product_text(product: Dict[str, Any]) -> str:
    fields = [
        "name", "original_name", "normalized_name", "canonical_display_name", "brand",
        "product_family", "active_ingredient", "form", "medicine_form", "strength", "size", "pack", "aliases", "ocr_keywords",
    ]
    return _safe_join(product.get(f) for f in fields)


def _product_aliases(product: Dict[str, Any]) -> Set[str]:
    aliases: Set[str] = set()
    for field in ["name", "original_name", "normalized_name", "canonical_display_name"]:
        value = str(product.get(field) or "").strip()
        if value:
            aliases.add(value)
    name = str(product.get("name") or "").strip()
    brand = str(product.get("brand") or "").strip()
    family = str(product.get("product_family") or "").strip()
    form = str(product.get("form") or product.get("medicine_form") or "").strip()
    strength = str(product.get("strength") or "").strip()
    size = str(product.get("size") or "").strip()
    pack = str(product.get("pack") or "").strip()
    if brand and family:
        aliases.add(_safe_join([brand, family, form, strength, size, pack]))
        aliases.add(_safe_join([brand, family, strength, size]))
        aliases.add(_safe_join([brand, family, form]))
    if name and form:
        aliases.add(_safe_join([name, form]))
    # Arabic form variant only if the alias already includes a stronger product identity.
    if form:
        cf = canonical_form(form) or _n(form)
        for ar_form in AR_FORM_TRANSLATIONS.get(cf, []):
            if brand and family:
                aliases.add(_safe_join([brand, family, ar_form, strength, size]))
            elif name and len(_strong_tokens(name)) >= 1:
                aliases.add(_safe_join([name, ar_form, strength, size]))
    return {a for a in aliases if _is_safe_alias(a)}


def _source_aliases(row: Dict[str, Any]) -> Set[str]:
    brand = _row_get(row, "brand")
    name = _row_get(row, "name")
    generic = _row_get(row, "generic")
    form = _row_get(row, "form")
    strength = _row_get(row, "strength")
    size = _row_get(row, "size")
    pack = _row_get(row, "pack")
    aliases: Set[str] = set()
    for base in _split_multi(name):
        aliases.add(_safe_join([brand, base, form, strength, size]))
        aliases.add(_safe_join([brand, base, strength, size]))
        aliases.add(_safe_join([brand, base, form]))
        aliases.add(_safe_join([base, form, strength, size]))
    for gen in _split_multi(generic):
        # Active-ingredient aliases require form/strength to reduce ambiguity.
        aliases.add(_safe_join([gen, form, strength, size]))
        if brand:
            aliases.add(_safe_join([brand, gen, form, strength, size]))
    return {a for a in aliases if _is_safe_alias(a)}


def _row_matches_product(row: Dict[str, Any], product: Dict[str, Any]) -> bool:
    """Exact-token, no-fuzzy source row to product match."""
    p_text = _n(_product_text(product))
    p_strong = _strong_tokens(p_text)
    if not p_text or not p_strong:
        return False

    row_brand = _n(_row_get(row, "brand"))
    row_name = _n(_row_get(row, "name"))
    row_generic = _n(_row_get(row, "generic"))
    row_form = canonical_form(_row_get(row, "form")) or _n(_row_get(row, "form"))
    row_strengths = {normalize_measure(x) for x in extract_strengths(_row_get(row, "strength") or row_name) if normalize_measure(x)}
    row_sizes = {normalize_measure(x) for x in extract_sizes(_row_get(row, "size") or row_name) if normalize_measure(x)}
    p_measures = {normalize_measure(x) for x in (extract_strengths(p_text) + extract_sizes(p_text) + extract_packs(p_text)) if normalize_measure(x)}

    if row_brand:
        brand_tokens = _strong_tokens(row_brand)
        if brand_tokens and not brand_tokens.issubset(p_strong):
            return False
    # Product name/brand overlap must be exact token containment, not fuzzy.
    row_identity_strong = _strong_tokens(_safe_join([row_brand, row_name]))
    if row_identity_strong:
        if len(row_identity_strong & p_strong) >= min(2, len(row_identity_strong)):
            pass
        elif row_brand and _n(row_brand) in p_text:
            pass
        else:
            return False
    elif row_generic:
        gen_tokens = _strong_tokens(row_generic)
        if not gen_tokens or not (gen_tokens & p_strong):
            return False
    else:
        return False

    if row_form:
        product_form = canonical_form(product.get("form") or product.get("medicine_form") or product.get("name") or "") or ""
        if product_form and product_form != row_form:
            return False
    # When both sides specify measures, every source measure must be present in product identity.
    for measure in row_strengths | row_sizes:
        if p_measures and measure not in p_measures and measure not in p_text.replace(" ", ""):
            return False
    return True


def _load_products(limit: int = 0) -> List[Dict[str, Any]]:
    rows = database.load_product_rows(limit=limit or None, visible_only=False, guided=False)
    products: List[Dict[str, Any]] = []
    for p in rows:
        if not p or not p.get("id"):
            continue
        products.append(dict(p))
    return products


def _insert_aliases(alias_to_product: Dict[str, int], dry_run: bool) -> int:
    if dry_run:
        return 0
    inserted = 0
    with database.connect() as conn:
        for norm, product_id in sorted(alias_to_product.items()):
            cur = conn.execute(
                """
                INSERT OR IGNORE INTO product_aliases(
                    product_id, product_db_id, alias, alias_normalized, normalized_alias,
                    source, is_active, approved, created_at, updated_at
                ) VALUES(?,?,?,?,?, 'open_data_safe', 1, 1, datetime('now'), datetime('now'))
                """,
                (int(product_id), int(product_id), norm, norm, norm),
            )
            inserted += int(cur.rowcount or 0)
    return inserted


def _write_report(report_path: Path, stats: Dict[str, Any]) -> None:
    report_path.parent.mkdir(parents=True, exist_ok=True)
    warnings = stats.get("warnings") or []
    source_stats = stats.get("source_stats") or []
    ambiguous = stats.get("ambiguous_examples") or []
    rejected = stats.get("rejected_examples") or []
    lines = [
        "# Open Data Alias Build Report",
        "",
        "This report was generated by `tools/build_aliases_from_open_data.py`.",
        "",
        "Safety policy:",
        "- No fuzzy matching was used.",
        "- Aliases were activated only when the normalized alias mapped to exactly one product.",
        "- Ambiguous aliases were rejected and left for admin/catalog review.",
        "- Open-data aliases never allow direct price display from an image; image results still require strict validation and user confirmation.",
        "- DrugBank sources are skipped unless an explicit commercial-use license is available and `--allow-restricted-source` is passed.",
        "",
        "## Summary",
        f"- Products read: {stats.get('products_read', 0)}",
        f"- Source files read: {stats.get('source_files_read', 0)}",
        f"- Source records read: {stats.get('source_records_read', 0)}",
        f"- Product self aliases considered: {stats.get('self_aliases_considered', 0)}",
        f"- Open-data aliases considered: {stats.get('open_aliases_considered', 0)}",
        f"- Aliases inserted: {stats.get('aliases_inserted', 0)}",
        f"- Ambiguous aliases rejected: {stats.get('ambiguous_aliases_rejected', 0)}",
        f"- Weak aliases rejected: {stats.get('weak_aliases_rejected', 0)}",
        f"- Products not improved by open data: {stats.get('products_not_improved_by_open_data', 0)}",
        f"- Dry run: {stats.get('dry_run', False)}",
        "",
        "## Sources",
    ]
    if source_stats:
        for s in source_stats:
            lines.append(f"- `{s.get('path')}`: records={s.get('records', 0)}, matched_records={s.get('matched_records', 0)}")
    else:
        lines.append("- No source files were found. Only conservative self aliases were considered.")
    if warnings:
        lines.extend(["", "## Warnings"])
        lines.extend(f"- {w}" for w in warnings[:100])
    if ambiguous:
        lines.extend(["", "## Ambiguous alias examples"])
        for item in ambiguous[:50]:
            lines.append(f"- `{item['alias']}` -> products {item['product_ids']}")
    if rejected:
        lines.extend(["", "## Rejected weak/unsafe alias examples"])
        for item in rejected[:50]:
            lines.append(f"- `{item}`")
    lines.append("")
    report_path.write_text("\n".join(lines), encoding="utf-8")


def build_aliases_from_open_data(
    sources_dir: str = "data/open_alias_sources",
    sources: Optional[Sequence[str]] = None,
    report: str = "OPEN_DATA_ALIAS_BUILD_REPORT.md",
    dry_run: bool = False,
    limit_products: int = 0,
    allow_restricted_source: bool = False,
) -> Dict[str, Any]:
    ensure_catalog_schema()
    products = _load_products(limit=limit_products)
    candidate_map: Dict[str, Set[int]] = defaultdict(set)
    weak_rejected: List[str] = []
    product_open_improved: Set[int] = set()

    for product in products:
        pid = int(product.get("id") or 0)
        for alias in _product_aliases(product):
            norm = _alias_norm(alias)
            if _is_safe_alias(norm):
                candidate_map[norm].add(pid)
            else:
                weak_rejected.append(alias)

    paths, warnings = _collect_source_paths(Path(sources_dir), list(sources or []), allow_restricted_source)
    source_records = 0
    open_aliases_considered = 0
    source_stats: List[Dict[str, Any]] = []

    # Product loop is acceptable for ~5k catalog and one-time tool. It never runs in WhatsApp request path.
    product_cache = [(p, _n(_product_text(p))) for p in products]
    for path in paths:
        records = 0
        matched_records = 0
        try:
            rows = _iter_source_rows(path)
            for row in rows:
                records += 1
                source_records += 1
                row_aliases = _source_aliases(row)
                if not row_aliases:
                    continue
                matched_any = False
                for product, _ptext in product_cache:
                    if not _row_matches_product(row, product):
                        continue
                    pid = int(product.get("id") or 0)
                    matched_any = True
                    product_open_improved.add(pid)
                    for alias in row_aliases:
                        norm = _alias_norm(alias)
                        open_aliases_considered += 1
                        if _is_safe_alias(norm):
                            candidate_map[norm].add(pid)
                        else:
                            weak_rejected.append(alias)
                if matched_any:
                    matched_records += 1
        except Exception as exc:
            warnings.append(f"FAILED reading {path}: {exc!r}")
        source_stats.append({"path": str(path), "records": records, "matched_records": matched_records})

    safe_aliases: Dict[str, int] = {}
    ambiguous: List[Dict[str, Any]] = []
    for norm, ids in candidate_map.items():
        if len(ids) == 1:
            safe_aliases[norm] = next(iter(ids))
        else:
            ambiguous.append({"alias": norm, "product_ids": sorted(ids)[:12]})

    inserted = _insert_aliases(safe_aliases, dry_run=dry_run)
    stats = {
        "ok": True,
        "products_read": len(products),
        "source_files_read": len(paths),
        "source_records_read": source_records,
        "source_stats": source_stats,
        "self_aliases_considered": sum(len(_product_aliases(p)) for p in products),
        "open_aliases_considered": open_aliases_considered,
        "aliases_inserted": inserted,
        "safe_aliases_ready": len(safe_aliases),
        "ambiguous_aliases_rejected": len(ambiguous),
        "weak_aliases_rejected": len(weak_rejected),
        "products_not_improved_by_open_data": max(0, len(products) - len(product_open_improved)) if paths else len(products),
        "ambiguous_examples": ambiguous[:50],
        "rejected_examples": weak_rejected[:50],
        "warnings": warnings,
        "dry_run": dry_run,
    }
    _write_report(Path(report), stats)
    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description="Build conservative product_aliases from open-data CSV/JSON sources.")
    parser.add_argument("--sources-dir", default="data/open_alias_sources", help="Directory containing local CSV/TSV/JSON/JSONL source files.")
    parser.add_argument("--source", action="append", default=[], help="Additional local file/dir or optional URL. Can be repeated.")
    parser.add_argument("--report", default="OPEN_DATA_ALIAS_BUILD_REPORT.md", help="Output markdown report path.")
    parser.add_argument("--db-path", default="", help="Optional SQLite DB path override. Defaults to PRICEBOT_DB_PATH or production fallback.")
    parser.add_argument("--dry-run", action="store_true", help="Generate report without inserting aliases.")
    parser.add_argument("--limit-products", type=int, default=0, help="Limit product rows for testing.")
    parser.add_argument("--allow-restricted-source", action="store_true", help="Allow sources with restricted-license hints such as DrugBank. Use only with proper license.")
    args = parser.parse_args()

    if args.db_path:
        database.configure_db_path(args.db_path)
    stats = build_aliases_from_open_data(
        sources_dir=args.sources_dir,
        sources=args.source,
        report=args.report,
        dry_run=args.dry_run,
        limit_products=args.limit_products,
        allow_restricted_source=args.allow_restricted_source,
    )
    print(json.dumps({k: v for k, v in stats.items() if k not in {"ambiguous_examples", "rejected_examples", "source_stats"}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
