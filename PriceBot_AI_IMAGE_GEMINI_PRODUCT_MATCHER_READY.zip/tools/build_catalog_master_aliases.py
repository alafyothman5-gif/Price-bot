#!/usr/bin/env python3
from catalog_ingestion.build_master_aliases import main

if __name__ == "__main__":
    main()
