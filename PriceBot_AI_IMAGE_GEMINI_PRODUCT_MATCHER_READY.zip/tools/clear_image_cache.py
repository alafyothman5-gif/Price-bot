#!/usr/bin/env python3
from __future__ import annotations

import database

if __name__ == "__main__":
    database.init_db(run_production_guard=False)
    deleted = database.clear_image_cache()
    print(f"IMAGE_CACHE_CLEARED deleted={deleted}")
