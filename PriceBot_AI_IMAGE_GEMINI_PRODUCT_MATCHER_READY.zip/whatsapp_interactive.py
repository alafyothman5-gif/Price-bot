"""WhatsApp Cloud API interactive payload builders for PriceBot premium UI."""
from __future__ import annotations

from typing import Dict, Iterable, List, Optional


def _txt(value: object, limit: int) -> str:
    s = str(value or "").replace("\n", " ").strip()
    if len(s) <= limit:
        return s
    return s[: max(0, limit - 1)].rstrip() + "…"


def button_payload(to_number: str, body: str, buttons: Iterable[Dict[str, str]]) -> Dict:
    safe = []
    for b in list(buttons)[:3]:
        safe.append({"type": "reply", "reply": {"id": _txt(b.get("id"), 200), "title": _txt(b.get("title"), 20)}})
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "button",
            "body": {"text": _txt(body, 1024)},
            "action": {"buttons": safe},
        },
    }


def list_payload(to_number: str, body: str, button: str, title: str, rows: List[Dict[str, str]]) -> Dict:
    safe_rows = []
    for row in rows[:10]:
        item = {"id": _txt(row.get("id", row.get("title", "")), 200), "title": _txt(row.get("title", ""), 24)}
        if row.get("description"):
            item["description"] = _txt(row.get("description", ""), 72)
        safe_rows.append(item)
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "list",
            "header": {"type": "text", "text": _txt(title, 60)},
            "body": {"text": _txt(body, 1024)},
            "action": {"button": _txt(button, 20), "sections": [{"title": _txt(title, 24), "rows": safe_rows}]},
        },
    }


def start_button_payload(to_number: str, body: str) -> Dict:
    return button_payload(to_number, body, [{"id": "START_USE", "title": "ابدأ الاستخدام"}])


def main_menu_payload(to_number: str, body: str) -> Dict:
    return list_payload(
        to_number,
        body,
        "القائمة",
        "القائمة الرئيسية",
        [
            {"id": "MAIN_SEARCH", "title": "🔎 بحث عن منتج", "description": "بالاسم أو بالصورة"},
            {"id": "MAIN_BROWSE", "title": "🗂️ تصفح الأقسام", "description": "اختيار حسب القسم"},
            {"id": "MAIN_INFO", "title": "ℹ️ معلومات الصيدلية", "description": "العمل والتوصيل"},
        ],
    )


def search_method_payload(to_number: str, body: str) -> Dict:
    return button_payload(
        to_number,
        body,
        [
            {"id": "SEARCH_NAME", "title": "اكتب الاسم"},
            {"id": "SEARCH_IMAGE", "title": "أرسل صورة"},
            {"id": "MAIN_MENU", "title": "القائمة"},
        ],
    )


def search_prompt_payload(to_number: str, body: str) -> Dict:
    return button_payload(to_number, body, [{"id": "SEARCH_IMAGE", "title": "أرسل صورة"}, {"id": "MAIN_MENU", "title": "القائمة"}])


def image_prompt_payload(to_number: str, body: str) -> Dict:
    return button_payload(to_number, body, [{"id": "SEARCH_NAME", "title": "بحث بالاسم"}, {"id": "MAIN_MENU", "title": "القائمة"}])


def back_menu_payload(to_number: str, body: str) -> Dict:
    return button_payload(to_number, body, [{"id": "BACK", "title": "رجوع"}, {"id": "MAIN_MENU", "title": "القائمة"}])




def image_confirmation_payload(to_number: str, body: str) -> Dict:
    return button_payload(
        to_number,
        body,
        [
            {"id": "IMAGE_CONFIRM_YES", "title": "نعم"},
            {"id": "IMAGE_CONFIRM_NO", "title": "لا"},
        ],
    )

def category_payload(to_number: str, body: str, categories: List[str]) -> Dict:
    rows = [{"id": f"CAT_{i}", "title": c} for i, c in enumerate(categories[:9])]
    rows.append({"id": "MAIN_MENU", "title": "القائمة الرئيسية"})
    return list_payload(to_number, body, "اختر القسم", "الأقسام", rows)


def subcategory_payload(to_number: str, body: str, subcategories: List[str]) -> Dict:
    rows = [{"id": f"SUB_{i}", "title": c} for i, c in enumerate(subcategories[:9])]
    rows.append({"id": "BACK", "title": "رجوع"})
    return list_payload(to_number, body, "اختر النوع", "التصنيفات", rows)


def skin_type_payload(to_number: str, body: str) -> Dict:
    rows = [
        {"id": "SKIN_oily", "title": "دهنية"},
        {"id": "SKIN_dry", "title": "جافة"},
        {"id": "SKIN_sensitive", "title": "حساسة"},
        {"id": "SKIN_normal", "title": "عادية / مختلطة"},
        {"id": "SKIN_unknown", "title": "لا أعرف"},
        {"id": "BACK", "title": "رجوع"},
    ]
    return list_payload(to_number, body, "نوع البشرة", "اختيار البشرة", rows)


def products_payload(to_number: str, body: str, rows: List[Dict[str, str]], has_next: bool = False, has_prev: bool = False) -> Dict:
    safe = rows[:8]
    if has_next:
        safe.append({"id": "NAV_NEXT", "title": "التالي", "description": "عرض منتجات إضافية"})
    if has_prev:
        safe.append({"id": "NAV_PREV", "title": "السابق", "description": "العودة للصفحة السابقة"})
    safe.append({"id": "BACK", "title": "رجوع"})
    return list_payload(to_number, body, "اختر المنتج", "المنتجات", safe[:10])


def clarification_payload(to_number: str, body: str, rows: List[Dict[str, str]]) -> Dict:
    safe = rows[:9]
    safe.append({"id": "MAIN_MENU", "title": "القائمة الرئيسية"})
    return list_payload(to_number, body, "حدد المنتج", "تأكيد المنتج", safe[:10])


def product_detail_payload(to_number: str, body: str, booking_enabled: bool = False) -> Dict:
    buttons = []
    if booking_enabled:
        buttons.append({"id": "ORDER_START", "title": "حجز المنتج"})
    buttons.extend([{"id": "SEARCH_NAME", "title": "بحث جديد"}, {"id": "MAIN_MENU", "title": "القائمة"}])
    return button_payload(to_number, body, buttons[:3])


def quantity_payload(to_number: str, body: str) -> Dict:
    rows = [{"id": f"QTY_{i}", "title": f"{i}"} for i in range(1, 6)]
    rows.append({"id": "BACK", "title": "رجوع"})
    return list_payload(to_number, body, "اختر الكمية", "الكمية", rows)
