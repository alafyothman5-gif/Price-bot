# PriceBot Safe Deploy — `/opt/pricebot_clean`

This package is prepared for the current production layout only.

## Production layout

- Active directory: `/opt/pricebot_clean`
- Symlink: `/opt/pricebot -> /opt/pricebot_clean`
- SQLite database: `/opt/pricebot_clean/pricebot.db`
- systemd service: `pricebot.service`
- Local health check: `http://127.0.0.1:8090/health`

Do not create `/opt/pricebot` as an independent project directory. It must remain a symlink to `/opt/pricebot_clean`.

## Files that must never be committed or included in ZIP releases

- `.env`
- `pricebot.db`
- `venv/`
- `__pycache__/`
- backups
- uploaded customer/media files unless explicitly required

Secrets must stay only on the server inside `/opt/pricebot_clean/.env` or the server environment. Do not put secrets in GitHub.

## Safe deploy command

Upload/extract the ZIP into a temporary directory, then run from the extracted directory:

```bash
chmod +x deploy_pricebot_clean.sh clean_install_pricebot.sh
./deploy_pricebot_clean.sh
```

`clean_install_pricebot.sh` is only a wrapper around `deploy_pricebot_clean.sh`.

## What the deploy script does

1. Targets `/opt/pricebot_clean` only.
2. Creates a backup under `/opt/pricebot_backups/<timestamp>/`.
3. Preserves these live runtime items:
   - `/opt/pricebot_clean/.env`
   - `/opt/pricebot_clean/pricebot.db`
   - `/opt/pricebot_clean/uploads/`
4. Stops `pricebot.service`.
5. Replaces code files only.
6. Restores preserved runtime items.
7. Runs Python compile checks including `services/vision/visual_memory.py`.
8. Clears legacy image cache entries so old pre-overlay decisions cannot be reused.
9. Starts `pricebot.service`.
10. Waits up to 60 seconds for `http://127.0.0.1:8090/health`.
11. Prints `DEPLOY_OK=1` on success.

## Database safety rules

The deploy script does not delete, recreate, or replace `/opt/pricebot_clean/pricebot.db`.

The Self-Learning Visual Overlay creates only these additional tables with `CREATE TABLE IF NOT EXISTS`:

- `visual_product_memory`
- `product_identity_overlay`
- `visual_product_pending_confirmations`

These tables are derived memory layers. They do not edit the original Excel data and do not overwrite product rows.

The Catalog Ingestion flow writes to staging first, then preview, then approval. It does not update production prices until safe rows are explicitly approved. Products missing from a weekly Excel upload are report-only and are not deleted or marked unavailable.

## Image safety rule

Images never display price or availability directly. Image flow is:

`Image -> Vision/OCR -> foreground/title validation -> visual memory/overlay/matcher candidate -> user confirmation/selection -> price/availability`

A single confirmation is recorded only as pending learning. Trusted visual memory is written only after `strict_image_candidate_validator` passes and either an admin approves the signature or 3 distinct users confirm the same signature/product. If the user rejects or does not confirm, no visual memory is written.

When uncertain, the bot asks for clarification or asks the customer to write the product name.

## Optional one-time open-data alias build

A new conservative offline utility is included:

```bash
./venv/bin/python tools/build_aliases_from_open_data.py \
  --sources-dir data/open_alias_sources \
  --report OPEN_DATA_ALIAS_BUILD_REPORT.md
```

Rules:

- It is not run automatically during deploy.
- It never updates prices or availability.
- It reads local CSV/TSV/JSON/JSONL files placed under `data/open_alias_sources/`.
- Optional `--source` can point to a local file/directory or a URL, but runtime PriceBot must not depend on internet access.
- It inserts only safe, non-ambiguous aliases into `product_aliases` with `source='open_data_safe'`.
- Ambiguous aliases are rejected into `OPEN_DATA_ALIAS_BUILD_REPORT.md`.
- DrugBank-like sources are skipped unless `--allow-restricted-source` is passed and a valid commercial-use license exists.
- These aliases still do not allow direct price display from image. Image matching must pass foreground validation, `strict_image_candidate_validator`, and user confirmation.
