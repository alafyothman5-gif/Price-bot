from __future__ import annotations

"""Arabic/English catalog name normalization.

The function in this file is the single source of truth for merchant-uploaded
names, master aliases, and exact-match lookups.  It deliberately does not use
fuzzy matching or probabilistic guessing.
"""

import argparse
import re
import unicodedata
from typing import Any

_ARABIC_DIGITS = str.maketrans({
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
    "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
})

_UNIT_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"\b(?:ملي\s*جرام|ملجم|مجم|mg|m\s*g)\b", "mg"),
    (r"\b(?:ميكرو\s*جرام|ميكروجرام|mcg|µg|ug)\b", "mcg"),
    (r"\b(?:جرام|جم|غم|g)\b", "g"),
    (r"\b(?:ملي\s*لتر|مللى|مللي|مل|ml|m\s*l)\b", "ml"),
    (r"\b(?:وحده\s*دوليه|وحدة\s*دولية|iu|i\s*u)\b", "iu"),
    (r"\b(?:بالمئه|بالمائة|%|percent)\b", "%"),
)

_STOP_WORDS = {
    "السعر", "سعر", "متوفر", "متوفره", "متوفرة", "عندكم", "موجود", "موجوده", "موجودة",
    "كم", "بكم", "بكام", "اريد", "أريد", "نبي", "ابي", "لو", "سمحت", "بالله", "please",
    "price", "available", "availability", "do", "you", "have",
}

# Deterministic Arabic -> English bridge.  This mirrors the matcher/catalog
# bridge vocabulary but is kept local so Catalog Ingestion normalization is not
# coupled to the runtime matcher import graph.  The bridge is exact phrase/token
# replacement, not fuzzy matching.
BRAND_BRIDGE_VARIANTS: dict[str, str] = {
    # common medicines
    "بنادول ادفانس": "panadol advance",
    "بنادول أدفانس": "panadol advance",
    "بنادول اكسترا": "panadol extra",
    "بنادول": "panadol",
    "بانادول": "panadol",
    "فلاجيل": "flagyl",
    "فلاجل": "flagyl",
    "اموكلان": "amoclan",
    "اموكلان": "amoclan",
    "اوجمنتين": "augmentin",
    "اغمنتين": "augmentin",
    "جافيسكون": "gaviscon",
    "داكتارين": "daktarin",
    "ميبو": "mebo",
    "سيتال": "cetal",
    "ادول": "adol",
    "بروفين": "brufen",
    "ايبوبروفين": "ibuprofen",
    "فولتارين": "voltaren",
    "كتافلام": "cataflam",
    "كتافاست": "catafast",
    "كونجستال": "congestal",
    "كلاريتين": "claritine",
    "زيرتك": "zyrtec",
    "اوميز": "omez",
    "نكسيوم": "nexium",
    "موتيليوم": "motilium",
    "سبازمو ديجستين": "spasmo digestin",
    # cosmetics / dermocosmetics
    "سيرافي": "cerave",
    "سيرا في": "cerave",
    "فيشي": "vichy",
    "بيوديرما": "bioderma",
    "بيودرما": "bioderma",
    "سنسيبيو": "sensibio",
    "سيبيوم": "sebium",
    "اتوديرم": "atoderm",
    "لاروش بوزيه": "la roche posay",
    "لاروش": "la roche",
    "لاروشبوزيه": "la roche posay",
    "بوزيه": "posay",
    "يوسرين": "eucerin",
    "يورياج": "uriage",
    "افين": "avene",
    "افène": "avene",
    "ريلاستيل": "rilastil",
    "سيباميد": "sebamed",
    "نيوكس": "nuxe",
    "نوكس": "nuxe",
    "كلينك": "clinique",
    "ذا اورديناري": "the ordinary",
    "اورديناري": "ordinary",
    "ميزون": "mizon",
    "ميزن": "mizon",
    "كيو في": "qv",
    "كيوفي": "qv",
    # descriptors and forms used in merchant Arabic uploads
    "ادفانس": "advance",
    "أدفانس": "advance",
    "اكسترا": "extra",
    "بلس": "plus",
    "فورت": "forte",
    "اطفال": "kids",
    "بيبي": "baby",
    "كبار": "adult",
    "اثار": "scar",
    "ندبات": "scar",
    "سكار": "scar",
    "مرطب": "moisturizing",
    "واقي شمس": "sunscreen",
    "غسول": "cleanser",
    "كريم": "cream",
    "جل": "gel",
    "لوشن": "lotion",
    "سيروم": "serum",
    "شامبو": "shampoo",
    "بلسم": "conditioner",
    "بخاخ": "spray",
    "سبراي": "spray",
    "زيت": "oil",
    "مرهم": "ointment",
    "شراب": "syrup",
    "معلق": "suspension",
    "اقراص": "tablets",
    "أقراص": "tablets",
    "حبوب": "tablets",
    "كبسولات": "capsules",
    "كبسول": "capsules",
    "قطرات": "drops",
    "قطره": "drops",
    "نقط": "drops",
    "حقن": "injection",
    "امبول": "ampoule",
    "تحاميل": "suppository",
    "لبوس": "suppository",
    "اكياس": "sachets",
    "كيس": "sachet",
    "محلول": "solution",
}

_BRIDGE_REPLACEMENTS: tuple[tuple[re.Pattern[str], str], ...] = tuple(
    (
        re.compile(r"(?<![0-9a-zA-Z\u0600-\u06FF])" + re.escape(k.lower()) + r"(?![0-9a-zA-Z\u0600-\u06FF])"),
        v.lower(),
    )
    for k, v in sorted(BRAND_BRIDGE_VARIANTS.items(), key=lambda kv: len(kv[0]), reverse=True)
)

_PUNCT_RE = re.compile(r"[^0-9a-zA-Z\u0600-\u06FF%]+")


def _strip_diacritics(text: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKD", text) if unicodedata.category(ch) != "Mn")


def _apply_brand_bridge(text: str) -> str:
    for pattern, replacement in _BRIDGE_REPLACEMENTS:
        text = pattern.sub(f" {replacement} ", text)
    return text


def normalize_arabic_name(raw: str) -> str:
    """Return a conservative normalized key for exact catalog matching.

    Steps are fixed by the PriceBot Catalog Ingestion specification:
    lowercase/strip, remove Arabic diacritics/tatweel, normalize Arabic letters,
    normalize Arabic digits, normalize whole-word units, apply Arabic-English
    brand/form bridge, remove request words, collapse spaces.
    """
    text = str(raw or "").lower().strip()
    text = _strip_diacritics(text)
    text = text.replace("ـ", "")
    text = text.translate(_ARABIC_DIGITS)
    text = re.sub("[أإآٱ]", "ا", text)
    text = text.replace("ة", "ه").replace("ى", "ي")
    text = text.replace("ؤ", "و").replace("ئ", "ي")

    # Normalize common Arabic comma/decimal forms before punctuation cleanup.
    text = text.replace("٫", ".").replace("،", " ").replace(",", " ")

    for pattern, replacement in _UNIT_PATTERNS:
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    # Keep decimals and unit adjacency readable: 500 mg -> 500mg, 200 ml -> 200ml.
    text = re.sub(r"(?<=\d)\s+(?=(?:mg|mcg|g|ml|iu|%)\b)", "", text, flags=re.I)

    # Canonicalize common mg strengths so Arabic uploads that omit "mg" still
    # match exact master aliases such as "Panadol Advance 500mg".  Other units
    # such as ml/g stay explicit because size mismatches must remain visible.
    text = re.sub(r"\b(\d+(?:\.\d+)?)mg\b", r"\1", text, flags=re.I)

    # Arabic-English bridge must run after Arabic letter/digit/unit normalization
    # and before stop-word removal.
    text = _apply_brand_bridge(text)
    text = _PUNCT_RE.sub(" ", text)

    tokens = [t for t in text.split() if t and t not in _STOP_WORDS]
    return " ".join(tokens).strip()


def rebuild_merchant_alias_normalized_names(conn: Any | None = None) -> dict[str, int]:
    """Rebuild merchant_product_aliases.normalized_raw_name with current normalizer.

    This is the safe Python migration requested for deployments upgrading from
    the pre-bridge normalizer.  It never guesses product identity and never
    touches products/prices.
    """
    import database
    from .db import ensure_schema

    own_conn = conn is None
    if own_conn:
        ensure_schema()
        conn = database.connect()
    assert conn is not None
    try:
        if not database.table_exists(conn, "merchant_product_aliases"):
            return {"checked": 0, "updated": 0, "skipped_conflicts": 0}
        rows = conn.execute(
            "SELECT id, merchant_id, raw_name, normalized_raw_name FROM merchant_product_aliases WHERE is_active=1"
        ).fetchall()
        checked = updated = skipped = 0
        for row in rows:
            r = database.dict_row(row) or {}
            checked += 1
            alias_id = int(r.get("id") or 0)
            merchant_id = int(r.get("merchant_id") or 0)
            raw_name = str(r.get("raw_name") or "")
            old_norm = str(r.get("normalized_raw_name") or "")
            new_norm = normalize_arabic_name(raw_name)
            if not alias_id or not new_norm or new_norm == old_norm:
                continue
            conflict = conn.execute(
                """
                SELECT id FROM merchant_product_aliases
                WHERE merchant_id=? AND normalized_raw_name=? AND is_active=1 AND id<>?
                LIMIT 1
                """,
                (merchant_id, new_norm, alias_id),
            ).fetchone()
            if conflict:
                skipped += 1
                continue
            conn.execute(
                "UPDATE merchant_product_aliases SET normalized_raw_name=?, updated_at=datetime('now') WHERE id=?",
                (new_norm, alias_id),
            )
            updated += 1
        return {"checked": checked, "updated": updated, "skipped_conflicts": skipped}
    finally:
        if own_conn:
            conn.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Rebuild merchant alias normalized names after normalizer upgrades.")
    parser.add_argument("--db-path", default="", help="Optional SQLite DB path. Defaults to PriceBot DB resolver.")
    args = parser.parse_args()
    if args.db_path:
        import database
        database.configure_db_path(args.db_path)
    print(rebuild_merchant_alias_normalized_names())


if __name__ == "__main__":
    main()
