from __future__ import annotations

"""Migration: rebuild merchant_product_aliases.normalized_raw_name.

Run after deploying a normalizer upgrade that adds Arabic-English brand/form
bridging:

    ./venv/bin/python -m catalog_ingestion.migrate_merchant_alias_normalization

Optional:

    ./venv/bin/python -m catalog_ingestion.migrate_merchant_alias_normalization --db-path /opt/pricebot_clean/pricebot.db

This migration is intentionally narrow: it only rewrites normalized_raw_name
from raw_name using normalize_arabic_name(). It does not touch products, prices,
review rows, or upload jobs.
"""

from .normalizer import main, rebuild_merchant_alias_normalized_names

__all__ = ["rebuild_merchant_alias_normalized_names", "main"]

if __name__ == "__main__":
    main()
