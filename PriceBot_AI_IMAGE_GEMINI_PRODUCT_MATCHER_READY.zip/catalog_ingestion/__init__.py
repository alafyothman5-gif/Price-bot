"""Safe Catalog Ingestion system for PriceBot.

This package is intentionally isolated from WhatsApp/search/vision runtime code.
It only touches production products after a preview job is explicitly approved.
"""

from .normalizer import normalize_arabic_name
from .processor import (
    create_and_verify_staging_job,
    approve_staging_job,
    reject_staging_job,
    job_report,
    pending_reviews,
    resolve_review_item,
    reject_review_item,
    create_product_from_review,
    approve_review_item,
)

__all__ = [
    "normalize_arabic_name",
    "create_and_verify_staging_job",
    "approve_staging_job",
    "reject_staging_job",
    "job_report",
    "pending_reviews",
    "resolve_review_item",
    "reject_review_item",
    "create_product_from_review",
    "approve_review_item",
]
