from __future__ import annotations

"""One-time master alias builder for Catalog Ingestion.

Run from project root:
  ./venv/bin/python -m catalog_ingestion.build_master_aliases

It reads products, creates conservative exact aliases, and stores them in
product_aliases.  It never updates prices and never deletes products.
"""

import argparse
from typing import Iterable, List

import database
from .db import ensure_schema
from .normalizer import normalize_arabic_name

BRAND_AR = {
    "panadol": ["بنادول", "بانادول"],
    "flagyl": ["فلاجيل", "فلاجل"],
    "amoclan": ["اموكلان", "اموكلان"],
    "augmentin": ["اوجمنتين", "اغمنتين"],
    "gaviscon": ["جافيسكون"],
    "daktarin": ["داكتارين"],
    "mebo": ["ميبو"],
    "cerave": ["سيرافي", "سيرا في"],
    "vichy": ["فيشي"],
    "bioderma": ["بيوديرما"],
    "eucerin": ["يوسرين"],
    "uriage": ["يورياج"],
    "rilastil": ["ريلاستيل"],
    "laroche": ["لاروش", "لاروش بوزيه"],
    "la roche": ["لاروش", "لاروش بوزيه"],
}

FORM_AR = {
    "tablet": ["اقراص", "حبوب"],
    "tablets": ["اقراص", "حبوب"],
    "tab": ["اقراص", "حبوب"],
    "capsule": ["كبسولات", "كبسول"],
    "capsules": ["كبسولات", "كبسول"],
    "cap": ["كبسولات", "كبسول"],
    "syrup": ["شراب"],
    "suspension": ["معلق", "شراب"],
    "drops": ["قطرات", "نقط"],
    "drop": ["قطرات", "نقط"],
    "injection": ["حقن", "امبول"],
    "cream": ["كريم"],
    "ointment": ["مرهم"],
    "gel": ["جل"],
    "lotion": ["لوشن"],
    "cleanser": ["غسول"],
    "wash": ["غسول"],
    "shampoo": ["شامبو"],
    "serum": ["سيروم"],
    "spray": ["بخاخ", "سبراي"],
    "sachet": ["اكياس", "كيس"],
    "suppository": ["تحاميل", "لبوس"],
}

DESCRIPTOR_AR = {
    "advance": ["ادفانس"],
    "extra": ["اكسترا"],
    "plus": ["بلس"],
    "forte": ["فورت"],
    "baby": ["اطفال", "بيبي"],
    "kids": ["اطفال"],
    "children": ["اطفال"],
    "adult": ["كبار"],
    "scar": ["اثار", "ندبات", "سكار"],
    "moisturizing": ["مرطب"],
    "hydrating": ["مرطب"],
    "cleanser": ["غسول"],
    "sunscreen": ["واقي شمس"],
}


def _variants_for_token(token: str) -> list[str]:
    t = token.lower().strip()
    return BRAND_AR.get(t) or FORM_AR.get(t) or DESCRIPTOR_AR.get(t) or [token]


def _limited_arabic_alias(name: str) -> str:
    tokens = [t for t in name.replace("-", " ").replace("/", " ").split() if t.strip()]
    out: list[str] = []
    for t in tokens:
        variants = _variants_for_token(t)
        out.append(variants[0] if variants else t)
    return " ".join(out)


def _alias_candidates(product: dict) -> Iterable[str]:
    base_values = [product.get("name"), product.get("original_name"), product.get("normalized_name")]
    for value in base_values:
        if value:
            yield str(value)
            ar = _limited_arabic_alias(str(value))
            if ar and ar != str(value):
                yield ar
    # Form-less alias for common exact master matching, but do not create brand-only aliases.
    name = str(product.get("name") or "")
    tokens = name.split()
    if len(tokens) >= 3:
        no_form = [t for t in tokens if t.lower() not in FORM_AR]
        if 2 <= len(no_form) < len(tokens):
            yield " ".join(no_form)
            yield _limited_arabic_alias(" ".join(no_form))


def build_master_aliases(limit: int = 0) -> dict:
    ensure_schema()
    inserted = 0
    skipped = 0
    with database.connect() as conn:
        rows = conn.execute("SELECT id, name, original_name, normalized_name FROM products ORDER BY id" + (" LIMIT ?" if limit else ""), ((int(limit),) if limit else ())).fetchall()
        for row in rows:
            product = database.dict_row(row) or {}
            product_id = int(product.get("id") or 0)
            for alias in _alias_candidates(product):
                norm = normalize_arabic_name(alias)
                # Avoid unsafe aliases that are too short or brand-only-like.
                if not norm or len(norm) < 3 or len(norm.split()) < 2:
                    skipped += 1
                    continue
                cur = conn.execute(
                    """
                    INSERT OR IGNORE INTO product_aliases(
                        product_id, product_db_id, alias, alias_normalized, normalized_alias,
                        source, is_active, approved, created_at, updated_at
                    ) VALUES(?,?,?,?,?, 'auto_generated', 1, 1, datetime('now'), datetime('now'))
                    """,
                    (product_id, product_id, alias, norm, norm),
                )
                inserted += int(cur.rowcount or 0)
    return {"ok": True, "inserted": inserted, "skipped": skipped}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()
    print(build_master_aliases(limit=args.limit))


if __name__ == "__main__":
    main()
