# PriceBot Catalog Ingestion

نظام آمن لرفع ملف أسعار أسبوعي من التاجر بدون تحديث مباشر للإنتاج.

## الفكرة

- التاجر يرفع Excel بعمودين فقط: `name` و `price`.
- الملف يدخل `catalog_staging_items` أولاً.
- التحديث الآمن فقط هو:
  - `KNOWN_MERCHANT_ALIAS`: الاسم محفوظ سابقاً لنفس التاجر.
  - `MASTER_EXACT_MATCH`: الاسم مطابق تماماً لاسم/alias موثوق.
- أي اسم غامض أو جديد يدخل `catalog_review_items` ولا يغير السعر.
- عند موافقة التاجر، يتم تطبيق الصفوف الآمنة فقط داخل معاملة واحدة وبعد backup.
- المنتجات غير المذكورة في الملف لا تُحذف ولا تصبح unavailable.

## الجداول

يضيف النظام الجداول التالية فقط، باستخدام `CREATE TABLE IF NOT EXISTS`:

- `merchant_product_aliases`
- `product_aliases`
- `catalog_upload_jobs`
- `catalog_staging_items`
- `catalog_review_items`
- `catalog_audit_log`

كما يضيف أعمدة آمنة اختيارية إلى `products` مثل `last_seen_at` و `normalized_name_catalog`.

## التطبيع

الدالة المركزية:

```python
from catalog_ingestion.normalizer import normalize_arabic_name
```

تقوم بـ lower/strip، إزالة التشكيل والتطويل، توحيد أ/إ/آ إلى ا، ة إلى ه، ى إلى ي، تحويل الأرقام العربية، توحيد الوحدات مثل mg/ml، إزالة كلمات الطلب مثل السعر/متوفر/عندكم، وتقليص المسافات.

## بناء Master Aliases مرة واحدة

بعد النشر وتشغيل البوت على قاعدة البيانات الحقيقية:

```bash
cd /opt/pricebot_clean  # أو مسار المشروع الفعلي
./venv/bin/python -m catalog_ingestion.build_master_aliases
```

أو:

```bash
./venv/bin/python tools/build_catalog_master_aliases.py
```

هذا السكربت لا يحدث الأسعار ولا يحذف منتجات. فقط يضيف aliases موثوقة مبنية من جدول `products`.

## سير الرفع

المسارات الحالية `/merchant/catalog/upload` و `/admin/catalog/upload` أصبحت تستخدم هذا النظام عبر `services/catalog/staging_workflow.py`.

الحالات الأساسية:

- `UPLOADED`
- `PROCESSING`
- `PENDING_PREVIEW`
- `APPROVED`
- `PARTIALLY_APPROVED`
- `FAILED`
- `ROLLED_BACK`

## مراجعة الأدمن

المسار الجديد:

```text
/admin/catalog/reviews
```

الأدمن يستطيع:

- ربط اسم غامض بمنتج موجود، فينشأ Merchant Alias ويتعلم النظام الاسم.
- تطبيق السعر اختيارياً بعد الربط.
- رفض العنصر.
- إنشاء منتج جديد من عنصر مراجعة، ثم يصبح قابلاً للظهور لأنه اعتمد يدوياً.

## ضمانات مهمة

- لا يوجد fuzzy matching لتحديث الأسعار.
- لا يوجد تحديث مباشر قبل Preview و Approval.
- اختلاف السعر لمنتج مؤكد الهوية يعتبر `UPDATE_PRICE` طبيعي وليس conflict.
- خطأ صف واحد لا يفشل الملف كله.
- التكرارات داخل الملف: آخر صف بنفس الاسم normalized يفوز.
- WAL و busy_timeout مفعّلان عند فتح الاتصال.
- لا يلمس MedMCQ ولا إعدادات Meta/OpenRouter/WhatsApp.
