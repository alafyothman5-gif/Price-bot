from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any


def parse_price(value: Any) -> str:
    """Parse a merchant Excel price into a stable text decimal.

    Raises ValueError for invalid prices.  The database keeps price as TEXT in
    existing PriceBot versions, so returning a normalized string is safer than
    changing schema types.
    """
    raw = str(value if value is not None else "").strip()
    if not raw:
        raise ValueError("EMPTY_PRICE")
    raw = raw.replace("د.ل", "").replace("دينار", "").replace("lyd", "").replace("LYD", "")
    raw = raw.replace("،", ".").replace(",", ".")
    raw = "".join(ch for ch in raw if ch.isdigit() or ch == "." or ch == "-")
    if raw in {"", ".", "-", "-."}:
        raise ValueError("INVALID_PRICE")
    try:
        dec = Decimal(raw)
    except InvalidOperation as exc:
        raise ValueError("INVALID_PRICE") from exc
    if dec < 0:
        raise ValueError("NEGATIVE_PRICE")
    dec = dec.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP).normalize()
    text = format(dec, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def same_price(a: Any, b: Any) -> bool:
    try:
        return parse_price(a) == parse_price(b)
    except Exception:
        return str(a or "").strip() == str(b or "").strip()
