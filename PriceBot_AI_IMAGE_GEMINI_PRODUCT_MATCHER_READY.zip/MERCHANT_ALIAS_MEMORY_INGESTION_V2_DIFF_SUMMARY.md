# Merchant Alias Memory Ingestion V2 Diff Summary

Modified existing code files only:

1. `catalog_ingestion/normalizer.py`
   - Added deterministic Arabic-English bridge in `normalize_arabic_name()`.
   - Added common Arabic brand/form/descriptor variants.
   - Added safe Python migration function `rebuild_merchant_alias_normalized_names()`.
   - Added CLI entry point for rebuilding existing `merchant_product_aliases.normalized_raw_name`.

2. `catalog_ingestion/processor.py`
   - Added `UNSAFE_REJECTED` for generic single-token names.
   - Added `SAFE_IDENTITY_MATCH` before `NEW_PRODUCT_REVIEW`.
   - Fixed `token_hits == 1` to return `AMBIGUOUS_REVIEW`.
   - Added `auto_identity` source when approved staging rows come from `SAFE_IDENTITY_MATCH`.

New support files:

- `catalog_ingestion/migrate_merchant_alias_normalization.py`
- `tests/test_catalog_ingestion_v2_acceptance.py`
- `DIFFS/catalog_ingestion_normalizer.diff`
- `DIFFS/catalog_ingestion_processor.diff`
- `CATALOG_INGESTION_V2_TEST_RESULTS.txt`

No protected files were included:

- `.env`
- `pricebot.db`
- `venv`
- `__pycache__`
- backups
- secrets
