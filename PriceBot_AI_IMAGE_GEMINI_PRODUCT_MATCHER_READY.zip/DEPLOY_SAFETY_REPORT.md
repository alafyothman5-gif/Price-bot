# Deploy Safety Report

Build: `PriceBot_FINAL_SELF_LEARNING_ALIAS_VISUAL_STRICT_READY`

Production layout preserved:

- Active directory: `/opt/pricebot_clean`
- Symlink: `/opt/pricebot -> /opt/pricebot_clean`
- Database: `/opt/pricebot_clean/pricebot.db`
- Service: `pricebot.service`
- Health: `http://127.0.0.1:8090/health`

Deploy script:

- `deploy_pricebot_clean.sh` targets `/opt/pricebot_clean` only.
- Health check waits up to 60 seconds.
- Success marker: `DEPLOY_OK=1`.
- Preserves `.env`, `pricebot.db`, and `uploads/`.
- Does not replace, delete, or truncate the database.
- Does not change the `/opt/pricebot` symlink.
- Does not touch MedMCQ.

New schema additions are idempotent:

- `visual_product_memory`
- `visual_product_pending_confirmations`
- `product_identity_overlay`
- existing `product_aliases` is reused for safe aliases

New script:

- `tools/build_aliases_from_open_data.py`
- Manual/offline only; not run during deploy.
- Writes only to `product_aliases`.
- Does not update prices or availability.

Build checks executed:

```text
python -m compileall . -q
PYTHONPATH=. pytest -q tests/test_production_safe_image_policy.py tests/test_self_learning_visual_overlay.py tests/test_open_data_alias_builder.py tests/test_catalog_ingestion_safe_exact.py
13 passed
```

No `.env`, `pricebot.db`, `venv`, `__pycache__`, `.pyc`, backups, or uploads should be included in the ZIP.
