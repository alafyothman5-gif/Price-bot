"""Compatibility wrapper for the single production matcher."""
from search_engine import SearchResult
from services.matching.excel_native_matcher import (
    match_text as search_product,
    match_vision_slots as search_from_vision_slots,
    preload_search_index as rebuild_search_index,
    invalidate_memory_index,
)
