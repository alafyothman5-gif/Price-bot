from __future__ import annotations

"""Compatibility wrapper for the new safe Catalog Ingestion package.

The public function names are kept so existing routes/tasks keep working.
"""

from typing import Any, Dict

from catalog_ingestion.processor import (
    approve_staging_job as _approve_staging_job,
    create_and_verify_staging_job as _create_and_verify_staging_job,
    reject_staging_job as _reject_staging_job,
)


def create_and_verify_staging_job(job_id: int, excel_path: str, merchant_id: int = 1) -> Dict[str, Any]:
    return _create_and_verify_staging_job(int(job_id), str(excel_path), int(merchant_id or 1))


def approve_staging_job(job_id: int, actor: str = "admin", *, full_inventory_upload: bool = False, mark_missing_unavailable: bool = False) -> Dict[str, Any]:
    # full_inventory_upload/mark_missing_unavailable are intentionally ignored by
    # the safe system: products missing from the weekly Excel are never deleted
    # or marked unavailable by this workflow.
    return _approve_staging_job(int(job_id), actor=actor)


def reject_staging_job(job_id: int, actor: str = "admin", reason: str = "") -> Dict[str, Any]:
    return _reject_staging_job(int(job_id), actor=actor, reason=reason)
