from __future__ import annotations

"""Self-learning visual overlay for PriceBot image recognition.

This module never edits the merchant Excel/product rows. It adds derived SQLite
memory beside the existing catalog:

* visual_product_memory: approved image-signature -> product_id memory.
* visual_product_pending_confirmations: non-trusted confirmations until the same
  validated signature/product is confirmed by distinct users enough times.
* product_identity_overlay: approved full identity fields for incomplete Excel names.

The overlay is only used after foreground/title validation. It never displays a
price by itself; the WhatsApp flow still asks the user to confirm the candidate
before product details are shown.
"""

import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

import database
from normalizer import normalize_text
from query_slots import canonical_form, normalize_measure

DEFAULT_MERCHANT_ID = 1
CONFIRMATION_THRESHOLD = 3

# Generic weak words. Product-specific names must not be added here.
WEAK_IMAGE_IDENTITY_TOKENS = {
    "low", "ph", "plus", "forte", "extra", "advance", "advanced", "new",
    "cream", "creme", "gel", "lotion", "serum", "cleanser", "wash", "foam",
    "ointment", "moisturizer", "moisturising", "moisturizing", "sunscreen",
    "spf", "shampoo", "conditioner", "spray", "oil", "mask", "toner",
    "tablet", "tablets", "capsule", "capsules", "syrup", "suspension",
    "solution", "drops", "drop", "oral", "pack", "tube", "bottle", "box",
    "skin", "face", "body", "hair", "care", "for", "with", "and",
    "vitamin", "vitamins", "folic", "acid", "iron", "zinc", "collagen",
    "hyaluronic", "metronidazole", "paracetamol", "mg", "mcg", "ml", "g", "iu",
    "كريم", "جل", "لوشن", "سيروم", "غسول", "شامبو", "مرهم", "شراب",
    "اقراص", "حبوب", "كبسولات", "فيتامين", "حديد", "بشره", "وجه",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple, set)):
        return " ".join(_text(v) for v in value if v is not None).strip()
    return str(value).strip()


def _n(value: Any) -> str:
    return normalize_text(_text(value))


def _compact(value: Any) -> str:
    return re.sub(r"\s+", " ", _n(value)).strip()


def _tokens(value: Any) -> List[str]:
    return [t for t in _n(value).split() if t]


def _strong_tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in _tokens(value):
        if t in WEAK_IMAGE_IDENTITY_TOKENS:
            continue
        if len(t) <= 2 and not t.isdigit():
            continue
        if t.isdigit():
            continue
        if t not in out:
            out.append(t)
    return out


def _field_measure(value: Any) -> str:
    return normalize_measure(value) or _n(value)


def _slot_form(slots: Dict[str, Any]) -> str:
    return canonical_form(slots.get("form") or slots.get("product_type") or "") or _n(slots.get("form") or slots.get("product_type") or "")


def _slot_measure(slots: Dict[str, Any], key: str) -> str:
    return _field_measure(slots.get(key) or "")


def _candidate_text(candidate: Dict[str, Any]) -> str:
    return _n(" ".join(_text(candidate.get(k)) for k in [
        "brand", "canonical_display_name", "canonical_name", "name", "original_name",
        "normalized_name", "aliases", "ocr_keywords", "product_family", "form",
        "medicine_form", "strength", "size", "pack",
    ]))


def _candidate_brand(candidate: Dict[str, Any]) -> str:
    return _n(candidate.get("brand"))


def _candidate_form(candidate: Dict[str, Any]) -> str:
    return canonical_form(candidate.get("form") or candidate.get("medicine_form") or candidate.get("product_type") or candidate.get("name") or "") or _n(candidate.get("form") or candidate.get("medicine_form") or "")


def _candidate_measure(candidate: Dict[str, Any], key: str) -> str:
    explicit = _field_measure(candidate.get(key) or "")
    if explicit:
        return explicit
    # Fall back to the identity text when older Excel rows lack explicit columns.
    text = _n(" ".join(_text(candidate.get(k)) for k in ["canonical_display_name", "name", "aliases", "ocr_keywords", key]))
    wanted = normalize_measure(text)
    return wanted or ""


def _canonical_from_slots(slots: Dict[str, Any]) -> str:
    slots = slots or {}
    brand = _text(slots.get("brand"))
    title = _text(
        slots.get("primary_title")
        or slots.get("main_visible_product")
        or slots.get("product_name")
        or slots.get("product_family")
        or slots.get("foreground_product_text")
        or slots.get("query")
    )
    form = _text(slots.get("form") or slots.get("product_type"))
    strength = _text(slots.get("strength"))
    size = _text(slots.get("size"))
    pack = _text(slots.get("pack"))
    parts: List[str] = []
    if brand and brand.lower() not in title.lower():
        parts.append(brand)
    if title:
        parts.append(title)
    for extra in [form, strength, size, pack]:
        if extra and _n(extra) not in _n(" ".join(parts)):
            parts.append(extra)
    return re.sub(r"\s+", " ", " ".join(parts)).strip()


def image_signature_from_slots(slots: Dict[str, Any]) -> str:
    """Build a strict foreground/title image signature.

    Background, raw all-OCR text, and ingredients are deliberately excluded.
    """
    slots = slots or {}
    parts = [
        slots.get("brand"),
        slots.get("primary_title") or slots.get("main_visible_product") or slots.get("product_name") or slots.get("product_family") or slots.get("foreground_product_text") or slots.get("query"),
        _slot_form(slots),
        _slot_measure(slots, "strength"),
        _slot_measure(slots, "size"),
        _slot_measure(slots, "pack"),
    ]
    return _compact(" ".join(_text(p) for p in parts if _text(p)))


def _add_column_if_missing(conn: Any, table: str, column: str, ddl: str) -> None:
    try:
        cols = set(database.table_columns(conn, table))
    except Exception:
        cols = set()
    if column not in cols:
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {ddl}')


def ensure_schema() -> None:
    """Create visual overlay tables idempotently and migrate old installs safely."""
    with database.connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS visual_product_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                image_signature TEXT NOT NULL,
                canonical_name TEXT NOT NULL,
                excel_name TEXT NOT NULL,
                product_id INTEGER,
                brand TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                confidence INTEGER DEFAULT 1,
                confirmed_count INTEGER DEFAULT 0,
                is_approved BOOLEAN DEFAULT 0,
                last_seen_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            )
        """)
        _add_column_if_missing(conn, "visual_product_memory", "confirmed_count", "INTEGER DEFAULT 0")
        _add_column_if_missing(conn, "visual_product_memory", "is_approved", "BOOLEAN DEFAULT 0")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_visual_signature ON visual_product_memory(merchant_id, image_signature)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_visual_product_memory_product ON visual_product_memory(product_id, is_approved, confirmed_count)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS visual_product_pending_confirmations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                image_signature TEXT NOT NULL,
                product_id INTEGER NOT NULL,
                user_key TEXT NOT NULL,
                canonical_name TEXT NOT NULL,
                excel_name TEXT NOT NULL,
                brand TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                validation_reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen_at TIMESTAMP,
                UNIQUE(merchant_id, image_signature, product_id, user_key)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_visual_pending_signature ON visual_product_pending_confirmations(merchant_id, image_signature, product_id)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_identity_overlay (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                original_excel_name TEXT NOT NULL,
                normalized_excel_name TEXT NOT NULL,
                brand TEXT,
                canonical_name TEXT NOT NULL,
                form TEXT,
                strength TEXT,
                size TEXT,
                pack TEXT,
                source TEXT DEFAULT 'auto_learned',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            )
        """)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_overlay_unique ON product_identity_overlay(merchant_id, normalized_excel_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_overlay_active ON product_identity_overlay(merchant_id, is_active, brand, form, strength, size)")


def validate_image_candidate(vision_slots: Dict[str, Any], candidate: Dict[str, Any]) -> Dict[str, Any]:
    """Strictly verify that a product candidate is compatible with visible image evidence."""
    slots = vision_slots or {}
    product = candidate or {}
    candidate_text = _candidate_text(product)
    if not candidate_text:
        return {"ok": False, "reason": "candidate_missing_identity"}

    brand = _n(slots.get("brand"))
    if brand:
        candidate_brand = _candidate_brand(product)
        if candidate_brand and candidate_brand != brand:
            return {"ok": False, "reason": "brand_mismatch", "expected": brand, "candidate_brand": candidate_brand}
        if not candidate_brand and brand not in candidate_text.split() and brand not in candidate_text:
            return {"ok": False, "reason": "brand_mismatch", "expected": brand, "candidate_brand": candidate_brand}

    primary_title = _text(slots.get("primary_title") or slots.get("main_visible_product") or slots.get("product_name") or slots.get("product_family"))
    foreground_text = _text(slots.get("foreground_product_text") or slots.get("visible_text") or "")
    identity_text = " ".join(x for x in [brand, primary_title, foreground_text] if x).strip()
    title_strong = _strong_tokens(primary_title or foreground_text)
    # A title made only of low-value descriptors, type words, measures, or ingredients
    # is not enough to validate an image exact match.
    if not brand and not title_strong:
        return {"ok": False, "reason": "weak_image_identity"}
    if primary_title and title_strong and not any(t in candidate_text.split() or t in candidate_text for t in title_strong):
        return {"ok": False, "reason": "primary_title_not_in_candidate", "title_tokens": title_strong[:6]}

    form = _slot_form(slots)
    if form:
        candidate_form = _candidate_form(product)
        if candidate_form != form:
            return {"ok": False, "reason": "form_mismatch", "expected": form, "candidate_form": candidate_form}

    for key in ["strength", "size", "pack"]:
        expected = _slot_measure(slots, key)
        if not expected:
            continue
        actual = _candidate_measure(product, key)
        if actual != expected and expected not in candidate_text:
            return {"ok": False, "reason": f"{key}_mismatch", "expected": expected, "candidate_value": actual}

    # If ingredients/background contain a candidate name but foreground/title does not,
    # the candidate is unsafe. This is generic and not product-specific.
    foreground_norm = _n(" ".join([primary_title, foreground_text, _text(slots.get("brand"))]))
    background_norm = _n(" ".join([_text(slots.get("background_text")), _text(slots.get("ingredients"))]))
    candidate_name_tokens = [t for t in _strong_tokens(product.get("canonical_display_name") or product.get("name")) if t not in _strong_tokens(identity_text)]
    if background_norm and candidate_name_tokens and any(t in background_norm for t in candidate_name_tokens) and not any(t in foreground_norm for t in candidate_name_tokens):
        return {"ok": False, "reason": "candidate_evidence_only_in_background_or_ingredients"}

    return {"ok": True, "reason": "strict_image_candidate_validator_passed"}


def strict_image_candidate_validator(vision_slots: Dict[str, Any], candidate: Dict[str, Any]) -> bool:
    """Boolean wrapper required by the production image safety policy."""
    return bool(validate_image_candidate(vision_slots, candidate).get("ok"))


def lookup_visual_memory(slots: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID) -> Optional[Dict[str, Any]]:
    ensure_schema()
    signature = image_signature_from_slots(slots)
    if not signature:
        return None
    with database.connect() as conn:
        row = conn.execute(
            """
            SELECT * FROM visual_product_memory
            WHERE merchant_id=? AND image_signature=? AND (is_approved=1 OR confirmed_count>=?)
            LIMIT 1
            """,
            (int(merchant_id or DEFAULT_MERCHANT_ID), signature, CONFIRMATION_THRESHOLD),
        ).fetchone()
        return database.dict_row(row) if row else None


def _approve_visual_memory(slots: Dict[str, Any], product: Dict[str, Any], merchant_id: int, confirmed_count: int, source: str = "auto_learned") -> Optional[int]:
    signature = image_signature_from_slots(slots)
    if not signature or not product or not product.get("id"):
        return None
    canonical = _canonical_from_slots(slots) or _text(product.get("canonical_display_name") or product.get("name"))
    excel_name = _text(product.get("name") or product.get("original_name") or canonical)
    with database.connect() as conn:
        conn.execute(
            """
            INSERT INTO visual_product_memory(
                merchant_id, image_signature, canonical_name, excel_name, product_id,
                brand, form, strength, size, confidence, confirmed_count, is_approved,
                last_seen_at, created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,1,datetime('now'),datetime('now'))
            ON CONFLICT(merchant_id, image_signature) DO UPDATE SET
                canonical_name=excluded.canonical_name,
                excel_name=excluded.excel_name,
                product_id=excluded.product_id,
                brand=excluded.brand,
                form=excluded.form,
                strength=excluded.strength,
                size=excluded.size,
                confidence=MAX(COALESCE(visual_product_memory.confidence,0)+1, excluded.confidence),
                confirmed_count=MAX(COALESCE(visual_product_memory.confirmed_count,0), excluded.confirmed_count),
                is_approved=1,
                last_seen_at=datetime('now')
            """,
            (
                int(merchant_id or DEFAULT_MERCHANT_ID), signature, canonical, excel_name, int(product["id"]),
                _text(slots.get("brand") or product.get("brand")), _slot_form(slots) or _text(product.get("form") or product.get("medicine_form")),
                _slot_measure(slots, "strength") or _field_measure(product.get("strength")),
                _slot_measure(slots, "size") or _field_measure(product.get("size")),
                max(1, int(confirmed_count or 1)), max(1, int(confirmed_count or 1)),
            ),
        )
        row = conn.execute(
            "SELECT id FROM visual_product_memory WHERE merchant_id=? AND image_signature=?",
            (int(merchant_id or DEFAULT_MERCHANT_ID), signature),
        ).fetchone()
        return int(row[0]) if row else None


def upsert_identity_overlay(slots: Dict[str, Any], product: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID, source: str = "auto_learned") -> Optional[int]:
    ensure_schema()
    if not product:
        return None
    excel_name = _text(product.get("name") or product.get("original_name") or "")
    normalized_excel = _n(product.get("normalized_name") or excel_name)
    canonical = _canonical_from_slots(slots) or _text(product.get("canonical_display_name") or excel_name)
    if not excel_name or not normalized_excel or not canonical:
        return None
    with database.connect() as conn:
        conn.execute(
            """
            INSERT INTO product_identity_overlay(
                merchant_id, original_excel_name, normalized_excel_name, brand,
                canonical_name, form, strength, size, pack, source, is_active, created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,1,datetime('now'))
            ON CONFLICT(merchant_id, normalized_excel_name) DO UPDATE SET
                original_excel_name=excluded.original_excel_name,
                brand=COALESCE(NULLIF(excluded.brand,''), product_identity_overlay.brand),
                canonical_name=excluded.canonical_name,
                form=COALESCE(NULLIF(excluded.form,''), product_identity_overlay.form),
                strength=COALESCE(NULLIF(excluded.strength,''), product_identity_overlay.strength),
                size=COALESCE(NULLIF(excluded.size,''), product_identity_overlay.size),
                pack=COALESCE(NULLIF(excluded.pack,''), product_identity_overlay.pack),
                source=CASE WHEN product_identity_overlay.source='manual' THEN product_identity_overlay.source ELSE excluded.source END,
                is_active=1
            """,
            (
                int(merchant_id or DEFAULT_MERCHANT_ID), excel_name, normalized_excel,
                _text(slots.get("brand") or product.get("brand")), canonical,
                _slot_form(slots) or _text(product.get("form") or product.get("medicine_form")),
                _slot_measure(slots, "strength") or _field_measure(product.get("strength")),
                _slot_measure(slots, "size") or _field_measure(product.get("size")),
                _slot_measure(slots, "pack") or _field_measure(product.get("pack")),
                source,
            ),
        )
        row = conn.execute(
            "SELECT id FROM product_identity_overlay WHERE merchant_id=? AND normalized_excel_name=?",
            (int(merchant_id or DEFAULT_MERCHANT_ID), normalized_excel),
        ).fetchone()
        return int(row[0]) if row else None


def record_pending_confirmation(slots: Dict[str, Any], product: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID, user_key: str = "") -> Dict[str, Any]:
    ensure_schema()
    signature = image_signature_from_slots(slots)
    if not signature or not product or not product.get("id"):
        return {"ok": False, "reason": "missing_signature_or_product", "confirmed_count": 0}
    validation = validate_image_candidate(slots, product)
    if not validation.get("ok"):
        return {"ok": False, "reason": validation.get("reason"), "confirmed_count": 0, "validation": validation}
    canonical = _canonical_from_slots(slots) or _text(product.get("canonical_display_name") or product.get("name"))
    excel_name = _text(product.get("name") or product.get("original_name") or canonical)
    user_key = _compact(user_key or "anonymous") or "anonymous"
    merchant_id = int(merchant_id or DEFAULT_MERCHANT_ID)
    with database.connect() as conn:
        conn.execute(
            """
            INSERT INTO visual_product_pending_confirmations(
                merchant_id, image_signature, product_id, user_key, canonical_name, excel_name,
                brand, form, strength, size, validation_reason, created_at, last_seen_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'))
            ON CONFLICT(merchant_id, image_signature, product_id, user_key) DO UPDATE SET
                canonical_name=excluded.canonical_name,
                excel_name=excluded.excel_name,
                brand=excluded.brand,
                form=excluded.form,
                strength=excluded.strength,
                size=excluded.size,
                validation_reason=excluded.validation_reason,
                last_seen_at=datetime('now')
            """,
            (
                merchant_id, signature, int(product["id"]), user_key, canonical, excel_name,
                _text(slots.get("brand") or product.get("brand")), _slot_form(slots) or _text(product.get("form") or product.get("medicine_form")),
                _slot_measure(slots, "strength") or _field_measure(product.get("strength")),
                _slot_measure(slots, "size") or _field_measure(product.get("size")),
                str(validation.get("reason") or "strict_pass"),
            ),
        )
        row = conn.execute(
            """
            SELECT COUNT(DISTINCT user_key) AS c
            FROM visual_product_pending_confirmations
            WHERE merchant_id=? AND image_signature=? AND product_id=?
            """,
            (merchant_id, signature, int(product["id"])),
        ).fetchone()
        count = int(row[0] if row else 0)
    return {"ok": True, "reason": "pending_confirmation_recorded", "confirmed_count": count, "image_signature": signature}


def admin_approve_visual_memory(slots: Dict[str, Any], product: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID) -> Dict[str, Optional[int]]:
    ensure_schema()
    # Admin approval is the controlled path for incomplete Excel names.  Validate
    # the candidate after applying the identity fields the admin is approving;
    # this still prevents size/form/strength contradictions.
    enriched = dict(product or {})
    enriched.setdefault("canonical_display_name", _canonical_from_slots(slots or {}) or enriched.get("name"))
    for field in ["brand", "form", "strength", "size", "pack"]:
        if (slots or {}).get(field):
            enriched[field] = (slots or {}).get(field)
    validation = validate_image_candidate(slots or {}, enriched)
    if not validation.get("ok"):
        return {"visual_memory_id": None, "overlay_id": None, "approved": False, "reason": validation.get("reason")}
    vm_id = _approve_visual_memory(slots or {}, enriched, int(merchant_id or DEFAULT_MERCHANT_ID), CONFIRMATION_THRESHOLD, source="manual")
    overlay_id = upsert_identity_overlay(slots or {}, enriched, merchant_id=merchant_id, source="manual") if vm_id else None
    return {"visual_memory_id": vm_id, "overlay_id": overlay_id, "approved": bool(vm_id), "reason": "admin_approved"}


def learn_from_confirmation(slots: Dict[str, Any], product: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID, user_key: str = "", admin_approved: bool = False) -> Dict[str, Any]:
    """Learn after confirmation without trusting one user confirmation prematurely.

    A single user confirmation records a pending confirmation only. The signature
    becomes approved visual memory only after admin approval or after at least
    CONFIRMATION_THRESHOLD distinct users confirm the same validated signature/product.
    """
    ensure_schema()
    slots = slots or {}
    product = product or {}
    if admin_approved:
        return admin_approve_visual_memory(slots, product, merchant_id=merchant_id)
    validation = validate_image_candidate(slots, product)
    if not validation.get("ok"):
        return {"visual_memory_id": None, "overlay_id": None, "approved": False, "confirmed_count": 0, "reason": validation.get("reason"), "validation": validation}
    existing = lookup_visual_memory(slots, merchant_id=merchant_id)
    if existing and int(existing.get("product_id") or 0) == int(product.get("id") or 0):
        vm_id = _approve_visual_memory(slots, product, int(merchant_id or DEFAULT_MERCHANT_ID), int(existing.get("confirmed_count") or CONFIRMATION_THRESHOLD), source="auto_learned")
        return {"visual_memory_id": vm_id, "overlay_id": None, "approved": bool(vm_id), "confirmed_count": int(existing.get("confirmed_count") or CONFIRMATION_THRESHOLD), "reason": "already_approved"}
    pending = record_pending_confirmation(slots, product, merchant_id=merchant_id, user_key=user_key)
    count = int(pending.get("confirmed_count") or 0)
    if count >= CONFIRMATION_THRESHOLD:
        vm_id = _approve_visual_memory(slots, product, int(merchant_id or DEFAULT_MERCHANT_ID), count, source="auto_learned")
        overlay_id = upsert_identity_overlay(slots, product, merchant_id=merchant_id, source="auto_learned") if vm_id else None
        return {"visual_memory_id": vm_id, "overlay_id": overlay_id, "approved": bool(vm_id), "confirmed_count": count, "reason": "threshold_approved"}
    return {"visual_memory_id": None, "overlay_id": None, "approved": False, "confirmed_count": count, "reason": "pending_until_threshold"}


def load_identity_overlays(merchant_id: int = DEFAULT_MERCHANT_ID) -> List[Dict[str, Any]]:
    ensure_schema()
    with database.connect() as conn:
        rows = conn.execute(
            """
            SELECT * FROM product_identity_overlay
            WHERE merchant_id=? AND is_active=1
            ORDER BY id DESC
            """,
            (int(merchant_id or DEFAULT_MERCHANT_ID),),
        ).fetchall()
        return [database.dict_row(r) for r in rows if r]


def enrich_product_rows(rows: Iterable[Dict[str, Any]], merchant_id: int = DEFAULT_MERCHANT_ID) -> List[Dict[str, Any]]:
    """Attach active approved overlay identity to product dictionaries in memory only."""
    product_rows = [dict(r) for r in rows]
    overlays = load_identity_overlays(merchant_id=merchant_id)
    by_norm = {str(o.get("normalized_excel_name") or ""): o for o in overlays if o.get("normalized_excel_name")}
    if not by_norm:
        return product_rows
    for p in product_rows:
        key = _n(p.get("normalized_name") or p.get("name") or p.get("original_name"))
        overlay = by_norm.get(key)
        if not overlay:
            continue
        canonical = _text(overlay.get("canonical_name"))
        if canonical and not _text(p.get("canonical_display_name")):
            p["canonical_display_name"] = canonical
        alias_parts = [_text(p.get("aliases")), canonical]
        p["aliases"] = " | ".join(x for x in alias_parts if x)
        ocr_parts = [_text(p.get("ocr_keywords")), canonical]
        p["ocr_keywords"] = " | ".join(x for x in ocr_parts if x)
        for field in ["brand", "form", "strength", "size", "pack"]:
            value = _text(overlay.get(field))
            if value and not _text(p.get(field)):
                p[field] = value
        p["identity_overlay_id"] = overlay.get("id")
        p["identity_overlay_canonical_name"] = canonical
    return product_rows


def _overlay_product_match(row: Dict[str, Any], product: Dict[str, Any], slots: Dict[str, Any]) -> bool:
    enriched = dict(product or {})
    for field in ["brand", "form", "strength", "size", "pack"]:
        if row.get(field) and not enriched.get(field):
            enriched[field] = row.get(field)
    if row.get("canonical_name"):
        enriched.setdefault("canonical_display_name", row.get("canonical_name"))
    return strict_image_candidate_validator(slots, enriched)


def find_overlay_products(slots: Dict[str, Any], merchant_id: int = DEFAULT_MERCHANT_ID, limit: int = 5) -> List[Dict[str, Any]]:
    """Find products through product_identity_overlay with hard slot constraints."""
    ensure_schema()
    slots = slots or {}
    canonical = _canonical_from_slots(slots)
    title_norm = _n(canonical or slots.get("query") or slots.get("foreground_product_text"))
    if not title_norm:
        return []
    overlays = load_identity_overlays(merchant_id=merchant_id)
    if not overlays:
        return []
    rows = database.load_product_rows(visible_only=True, guided=False)
    by_norm: Dict[str, Dict[str, Any]] = {
        _n(r.get("normalized_name") or r.get("name") or r.get("original_name")): r for r in rows
    }
    matched: List[Dict[str, Any]] = []
    for overlay in overlays:
        product = by_norm.get(_n(overlay.get("normalized_excel_name")))
        if not product:
            continue
        overlay_text = _n(" ".join(_text(overlay.get(c)) for c in ["brand", "canonical_name", "form", "strength", "size", "pack", "original_excel_name"]))
        title_tokens = [t for t in title_norm.split() if len(t) > 2 and t not in WEAK_IMAGE_IDENTITY_TOKENS]
        if title_tokens and not any(t in overlay_text for t in title_tokens):
            continue
        product = dict(product)
        product.setdefault("canonical_display_name", overlay.get("canonical_name") or product.get("name"))
        for field in ["brand", "form", "strength", "size", "pack"]:
            if overlay.get(field) and not product.get(field):
                product[field] = overlay.get(field)
        product["identity_overlay_id"] = overlay.get("id")
        if not _overlay_product_match(overlay, product, slots):
            continue
        matched.append(product)
        if len(matched) >= limit:
            break
    return matched


__all__ = [
    "CONFIRMATION_THRESHOLD",
    "ensure_schema",
    "image_signature_from_slots",
    "lookup_visual_memory",
    "validate_image_candidate",
    "strict_image_candidate_validator",
    "record_pending_confirmation",
    "admin_approve_visual_memory",
    "learn_from_confirmation",
    "enrich_product_rows",
    "find_overlay_products",
]
