#!/usr/bin/env python3
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
import guided_commerce
from search_engine import search_product


def run(cmd, timeout=4):
    try:
        out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        return out.returncode, out.stdout.strip()
    except Exception as exc:
        return 999, f"{type(exc).__name__}: {exc}"


def timed(label, fn):
    start = time.perf_counter()
    try:
        result = fn()
        ok = True
    except Exception as exc:
        result = f"ERROR {type(exc).__name__}: {exc}"
        ok = False
    ms = int((time.perf_counter() - start) * 1000)
    print(f"{label}: {'OK' if ok else 'FAIL'} {ms}ms {result}")
    return ok


def excel_info(path: Path):
    if not path.exists():
        return "missing"
    try:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        headers = [str(ws.cell(3, c).value or '').strip() for c in range(1, ws.max_column + 1)]
        rows = max(0, ws.max_row - 3)
        wb.close()
        return f"exists rows≈{rows} columns={len([h for h in headers if h])} header_row_3={'product_id' in headers and 'name' in headers}"
    except Exception as exc:
        return f"error {type(exc).__name__}: {exc}"


def main() -> int:
    db_path = database.get_db_path()
    excel_path = Path(sys.argv[1]) if len(sys.argv) >= 2 else Path('/opt/pricebot/products_master_v22_ready.xlsx')
    print(f"DB path: {db_path}")
    print(f"DB exists: {db_path.exists()}")
    try:
        database.init_db(run_production_guard=False)
    except Exception as exc:
        print(f"init_db: FAIL {type(exc).__name__}: {exc}")
    print(f"integrity_check: {database.integrity_check()}")
    print(f"products count: {database.count_products()}")
    print(f"Excel: {excel_path} => {excel_info(excel_path)}")
    print(f"search index count: {database.count_table('product_search_index')}")
    print(f"guided index count: {database.count_table('guided_catalog_index')}")

    code, out = run(['systemctl', 'is-active', 'pricebot'], timeout=3)
    print(f"service status: {out if out else code}")
    code, out = run(['bash', '-lc', 'curl -fsS --max-time 3 http://127.0.0.1:8090/health || true'], timeout=5)
    print(f"health: {out[:300] if out else 'not reachable'}")

    timed('sample exact search Photoblok 50+', lambda: search_product('Photoblok 50+').status)
    timed('guided main menu', lambda: ', '.join(guided_commerce.available_main_sections()[:5]) or 'empty')
    timed('guided menu timing', lambda: guided_commerce.format_main_menu().split('\n')[0])

    final_ok = str(database.integrity_check()).lower() == 'ok' and database.count_products() > 0
    print(f"VERIFY_PRODUCTION_{'OK' if final_ok else 'WARNING'}")
    return 0 if final_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
