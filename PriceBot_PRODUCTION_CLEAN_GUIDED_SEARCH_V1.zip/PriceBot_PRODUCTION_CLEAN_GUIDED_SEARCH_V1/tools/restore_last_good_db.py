#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import database

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        backup = Path(sys.argv[1])
    else:
        backups = sorted(database.BACKUPS_DIR.glob("pricebot_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not backups:
            raise SystemExit("NO_BACKUP_FOUND")
        backup = backups[0]
    database.restore_db_from_backup(backup)
    print(f"RESTORE_OK from={backup} to={database.get_db_path()}")
