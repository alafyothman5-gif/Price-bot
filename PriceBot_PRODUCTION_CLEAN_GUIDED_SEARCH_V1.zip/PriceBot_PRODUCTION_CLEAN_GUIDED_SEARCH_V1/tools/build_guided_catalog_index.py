#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from guided_commerce import rebuild_guided_index

if __name__ == "__main__":
    database.init_db(run_production_guard=False)
    before = database.count_products()
    count = rebuild_guided_index()
    after = database.count_products()
    print(f"GUIDED_INDEX_REBUILD_OK rows={count} products_before={before} products_after={after}")
