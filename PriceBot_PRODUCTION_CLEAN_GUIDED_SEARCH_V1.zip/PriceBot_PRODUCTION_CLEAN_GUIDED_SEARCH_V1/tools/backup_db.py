#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import database

if __name__ == "__main__":
    backup = database.backup_db("manual")
    print(f"BACKUP_OK {backup}")
