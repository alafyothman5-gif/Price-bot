from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import database
from normalizer import clean_query, compact_normalize, is_generic_query, normalize_text, split_multi, tokens

@dataclass
class SearchResult:
    status: str
    message: str = ""
    products: List[Dict] = field(default_factory=list)
    product: Optional[Dict] = None
    clarification: Optional[str] = None


def product_identity_key(p: Dict) -> Tuple[str, str, str, str, str]:
    return (
        normalize_text(p.get("brand")), normalize_text(p.get("product_family")), normalize_text(p.get("form") or p.get("medicine_form")),
        normalize_text(p.get("strength")), normalize_text(p.get("size")),
    )


def dedupe_products(products: List[Dict], limit: int = 20) -> List[Dict]:
    out = []
    seen = set()
    for p in products:
        key = p.get("id") or product_identity_key(p)
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def _visible(products: List[Dict]) -> List[Dict]:
    return [p for p in products if database.product_visible(p, guided=False)]


def _same_identity_duplicates(products: List[Dict]) -> bool:
    if len(products) <= 1:
        return True
    keys = {product_identity_key(p) for p in products}
    return len(keys) == 1


def _medicine_variant_needs_clarification(products: List[Dict], query: str) -> Optional[str]:
    meds = [p for p in products if normalize_text(p.get("category")) == "medicine"]
    if len(meds) <= 1:
        return None
    q = normalize_text(query)
    forms = sorted({normalize_text(p.get("form") or p.get("medicine_form")) for p in meds if normalize_text(p.get("form") or p.get("medicine_form"))})
    strengths = sorted({normalize_text(p.get("strength")) for p in meds if normalize_text(p.get("strength"))})
    if forms and not any(f and f in q for f in forms):
        return "هذا الدواء له أكثر من شكل. اكتب الشكل المطلوب مثل: أقراص / شراب / حقن / تحاميل."
    if strengths and len(strengths) > 1 and not any(s and s in q for s in strengths):
        return "هذا الدواء له أكثر من تركيز. اكتب التركيز المطلوب قبل عرض السعر."
    return None


def build_search_index_entries() -> List[Tuple[str, str, int, int]]:
    entries: List[Tuple[str, str, int, int]] = []
    for p in database.load_product_rows(visible_only=False):
        pid = int(p["id"])
        name = normalize_text(p.get("name")) or normalize_text(p.get("original_name"))
        if name:
            entries.append((name, "name", pid, 100))
            entries.append((compact_normalize(name), "compact_name", pid, 95))
        normalized_name = normalize_text(p.get("normalized_name"))
        if normalized_name and normalized_name != name:
            entries.append((normalized_name, "name", pid, 100))
            entries.append((compact_normalize(normalized_name), "compact_name", pid, 95))
        barcode = normalize_text(p.get("barcode"))
        if barcode:
            entries.append((barcode, "barcode", pid, 120))
        for alias in split_multi(p.get("aliases")):
            a = normalize_text(alias)
            if a:
                entries.append((a, "alias", pid, 90))
                entries.append((compact_normalize(a), "compact_alias", pid, 85))
    return entries


def rebuild_search_index() -> int:
    return database.replace_search_index(build_search_index_entries())


SYNONYM_TOKENS = {"zofran": "ondansetron", "داكتارين": "daktarin", "دكتارين": "daktarin", "فلاجيل": "flagyl"}
UNIT_TOKENS = {"mg", "ml", "g", "mcg", "مجم", "مل"}

def expand_query_tokens(q: str) -> List[str]:
    raw = tokens(q)
    expanded: List[str] = []
    has_number = any(t.isdigit() for t in raw)
    for t in raw:
        if has_number and t in UNIT_TOKENS:
            continue
        expanded.append(SYNONYM_TOKENS.get(t, t))
    return expanded

def search_product(query: str, allow_guided_redirect: bool = True) -> SearchResult:
    raw = str(query or "").strip()
    q = clean_query(raw)
    if not q:
        return SearchResult("ASK_CLARIFICATION", "اكتب اسم المنتج كاملًا أو اختر من القائمة.")

    if allow_guided_redirect and is_generic_query(q):
        return SearchResult("ASK_CLARIFICATION", generic_redirect_message(q), clarification="guided")

    norm = normalize_text(q)
    compact = compact_normalize(q)

    exact = _visible(database.find_by_exact_index(norm, ["name", "alias", "barcode"]))
    if not exact and compact:
        exact = _visible(database.find_by_exact_index(compact, ["compact_name", "compact_alias"]))
    exact = dedupe_products(exact, limit=20)
    if len(exact) == 1 or (exact and _same_identity_duplicates(exact)):
        return SearchResult("EXACT_MATCH", product=exact[0], products=[exact[0]])
    if len(exact) > 1:
        clarification = _medicine_variant_needs_clarification(exact, q)
        if clarification:
            return SearchResult("ASK_CLARIFICATION", clarification, products=exact[:10])
        return SearchResult("PRODUCT_LIST", products=exact[:10], message="وجدت أكثر من منتج مطابق. اختر الرقم:")

    qt = expand_query_tokens(q)
    # Conservative rule: one weak/general token is not enough.
    if len(qt) < 2 and not any(t.isdigit() and len(t) >= 3 for t in qt):
        return SearchResult("ASK_CLARIFICATION", "اكتب الاسم الكامل للمنتج أو الشركة مع النوع/التركيز.")

    candidates = dedupe_products(database.search_candidates_by_tokens(qt, limit=20), limit=20)
    if not candidates:
        return SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.")

    clarification = _medicine_variant_needs_clarification(candidates, q)
    if clarification:
        return SearchResult("ASK_CLARIFICATION", clarification, products=candidates[:10])

    # If the query is very specific and the best candidate contains all tokens, show list instead of guessing one.
    if len(candidates) == 1:
        return SearchResult("EXACT_MATCH", product=candidates[0], products=[candidates[0]])
    return SearchResult("PRODUCT_LIST", products=candidates[:10], message="وجدت منتجات قريبة من الاسم المكتوب. اختر الرقم:")


def generic_redirect_message(q: str) -> str:
    n = normalize_text(q)
    if n in {"غسول", "cleanser", "wash"}:
        return "هل تقصد غسول وجه، غسول جسم، أم غسول أطفال؟ اختر من تصفح الأقسام لتجنب النتائج الخاطئة."
    if n in {"كريم", "cream", "مرطب", "lotion"}:
        return "اكتب اسم الكريم كاملًا أو اختر القسم المناسب من تصفح الأقسام."
    if n in {"حديد", "iron"}:
        return "لمنتجات الحديد اختر: تصفح الأقسام ← مكملات وفيتامينات ← حديد."
    if n in {"فيتامين", "فيتامينات", "vitamin"}:
        return "اختر نوع الفيتامين من قسم مكملات وفيتامينات."
    if n in {"شامبو", "shampoo"}:
        return "اختر عناية بالشعر ← شامبو لعرض الشامبوهات المتوفرة فقط."
    return "الطلب عام. اختر من تصفح الأقسام أو اكتب اسم المنتج كاملًا."
