import base64
import json
import os
from typing import Dict, Optional

import httpx

from normalizer import normalize_text

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "").strip()
OPENROUTER_MODEL = os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-flash-lite").strip()


def build_query_from_slots(slots: Dict[str, str]) -> str:
    parts = []
    for key in ["brand", "product_name", "strength", "size", "form"]:
        v = str(slots.get(key) or "").strip()
        if v:
            parts.append(v)
    return " ".join(parts).strip()


async def extract_product_from_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, str]:
    if not image_bytes:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة. الرجاء إرسال صورة أوضح للواجهة الأمامية للمنتج."}
    if not OPENROUTER_API_KEY:
        return {"status": "IMAGE_UNCLEAR", "message": "فحص الصور غير مفعّل حاليًا. اكتب اسم المنتج كاملًا."}

    data_url = f"data:{mime_type};base64," + base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "Extract pharmacy product identity from the image. Return strict JSON only with keys: "
        "brand, product_name, strength, size, form, confidence. "
        "If unreadable, confidence must be below 0.75. Do not guess."
    )
    payload = {
        "model": OPENROUTER_MODEL,
        "messages": [
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]}
        ],
        "temperature": 0,
        "max_tokens": 350,
    }
    headers = {"Authorization": f"Bearer {OPENROUTER_API_KEY}", "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=25) as client:
            resp = await client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception:
        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}

    try:
        start = content.find("{")
        end = content.rfind("}")
        data = json.loads(content[start:end+1] if start >= 0 and end > start else content)
    except Exception:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة. الرجاء إرسال صورة أوضح للواجهة الأمامية للمنتج."}

    confidence = float(data.get("confidence") or 0)
    if confidence < 0.75:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة. الرجاء إرسال صورة أوضح للواجهة الأمامية للمنتج."}
    query = build_query_from_slots(data)
    if not normalize_text(query) or len(normalize_text(query).split()) < 2:
        return {"status": "LOW_CONFIDENCE", "message": "لم أستطع تحديد اسم المنتج من الصورة بدقة. الرجاء إرسال صورة أوضح للواجهة الأمامية."}
    data["status"] = "OK"
    data["query"] = query
    return data
