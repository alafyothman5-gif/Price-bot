# PriceBot_PRODUCTION_CLEAN_GUIDED_SEARCH_V1

نسخة Clean Restart لبوت واتساب صيدلية بدر البشرية.

## ما تم تنظيفه

- حذف مسارات V20/V22 القديمة والـ deploy scripts المتراكمة.
- حذف ملفات demo/fixtures والاختبارات القديمة المتضاربة.
- عدم تضمين `pricebot.db` أو `.env` أو tokens أو backups أو `__pycache__`.
- فصل الكود عن استيراد Excel: deploy لا يستورد منتجات ولا يلمس جدول products.
- إضافة أدوات منفصلة لـ backup/import/index/verify/restore.

## الملفات الأساسية

- `app.py`: Webhook + WhatsApp flow + queue workers.
- `database.py`: SQLite schema/migrations آمنة وإدارة state/orders/indexes.
- `guided_commerce.py`: القوائم الموجهة وتصنيف الأقسام.
- `search_engine.py`: بحث محافظ بدون global fuzzy عشوائي.
- `matcher.py`: واجهة قرارات المطابقة الآمنة.
- `vision_service.py`: استخراج بيانات الصورة عبر OpenRouter عند توفر المفتاح.
- `orders.py`: عرض المنتج والحجز.
- `admin.py`: لوحة أدمن بسيطة للطلبات.
- `merchant.py`: لوحة تاجر بسيطة.

## الأدوات

- `tools/backup_db.py`
- `tools/restore_last_good_db.py`
- `tools/import_master_excel.py`
- `tools/build_search_index.py`
- `tools/build_guided_catalog_index.py`
- `tools/verify_production.py`
- `tools/run_acceptance_tests.py`

## طريقة التشغيل المطلوبة على السيرفر

نفّذ من داخل المجلد المستخرج للنسخة:

```bash
./deploy_code_only.sh
cd /opt/pricebot
./venv/bin/python tools/verify_production.py
./venv/bin/python tools/import_master_excel.py /opt/pricebot/products_master_v22_ready.xlsx
./venv/bin/python tools/verify_production.py
sudo systemctl restart pricebot
sudo systemctl status pricebot --no-pager -l
```

## ملاحظات حماية قاعدة البيانات

- `deploy_code_only.sh` يستبعد: `.env`, `pricebot.db`, `*.db-wal`, `*.db-shm`, `backups/`, `media/uploads/`.
- `import_master_excel.py` يعمل backup قبل الاستيراد.
- الاستيراد يستخدم upsert حسب `product_id` ولا ينفذ `DROP products` ولا `DELETE FROM products`.
- عند فشل الاستيراد يحاول rollback ثم restore من آخر backup تم إنشاؤه.
- `verify_production.py` يفحص integrity/count/indexes/health/timing.

## نتائج الاختبار المحلي داخل بيئة التطوير

تم اختبار الاستيراد على الملف المرفوع `products_master_v22_ready.xlsx`:

- Header row: 3
- Data start row: 4
- Excel max row: 5794
- Imported rows: 5791
- DB integrity: ok
- Products after import: 5791
- Search index: 11990 entries تقريبًا بعد إزالة التكرار
- Guided index: 5791 rows
- Sample exact search `Photoblok 50+`: EXACT_MATCH
- Generic `غسول`: لا يعرض منتج عشوائي، يطلب تحديد النوع
- Brand-only `Cerave`: ASK_CLARIFICATION
- `Zofran 4 mg`: PRODUCT_LIST آمن بدل NOT_AVAILABLE بسبب وجود أكثر من صيغة Ondansetron في الملف
- حجز منتج بعد اختيار التفاصيل: تم إنشاء order في جدول orders

## حدود مقصودة

- لا توجد بدائل دوائية تلقائية.
- إذا الصورة غير واضحة أو Vision غير مفعّل، يطلب صورة أوضح أو اسم المنتج.
- `search_mode=exact_only` لا يظهر في القوائم العامة، لكنه يظهر في البحث الدقيق بالاسم/alias.
- المنتجات `review_only / needs_review / unknown` لا تظهر للعميل.
