from search_engine import SearchResult, search_product

ALLOWED_DECISIONS = {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "PRODUCT_LIST", "LOW_CONFIDENCE", "IMAGE_UNCLEAR"}

def match_text(query: str) -> SearchResult:
    result = search_product(query)
    if result.status not in ALLOWED_DECISIONS:
        return SearchResult("LOW_CONFIDENCE", "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل أو أرسل صورة أوضح.")
    return result
