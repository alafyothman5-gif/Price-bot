import json
import os
import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from normalizer import normalize_text, split_multi, truthy, safe_price

BASE_DIR = Path(__file__).resolve().parent
DB_FILE = Path(os.getenv("PRICEBOT_DB_FILE", str(BASE_DIR / "pricebot.db")))
if not DB_FILE.is_absolute():
    DB_FILE = BASE_DIR / DB_FILE
BACKUPS_DIR = BASE_DIR / "backups"

PRODUCT_COLUMNS = [
    "product_id", "name", "normalized_name", "brand", "company", "category", "section", "product_family",
    "form", "product_type", "active_ingredient", "strength", "size", "pack", "barcode", "aliases",
    "ocr_keywords", "use_case", "skin_type", "body_area", "age_group", "gender", "medicine_form",
    "medicine_route", "available", "price", "currency", "search_mode", "quality_status", "is_substitutable",
    "substitution_group_id", "review_status", "review_notes", "source_serial", "original_name",
]
TEXT_COLUMNS = {c: "TEXT DEFAULT ''" for c in PRODUCT_COLUMNS}
TEXT_COLUMNS.update({
    "created_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
    "updated_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
})

VISIBLE_REVIEW = {"", "ok", "ready", "approved", "valid"}
VISIBLE_QUALITY = {"", "ok", "ready", "approved", "verified", "partial", "good"}
HIDDEN_SEARCH_MODES = {"review_only", "needs_review", "unknown", "hidden"}
GUIDED_HIDDEN_SEARCH_MODES = HIDDEN_SEARCH_MODES | {"exact_only"}


def _env_true(name: str) -> bool:
    return str(os.getenv(name, "")).strip().lower() in {"1", "true", "yes", "on", "production"}


def _min_products_guard() -> int:
    try:
        return int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000)
    except Exception:
        return 1000


def get_db_path() -> Path:
    return DB_FILE


@contextmanager
def connect() -> Iterable[sqlite3.Connection]:
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_FILE), timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def dict_row(row: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    return {k: row[k] for k in row.keys()}


def table_exists(conn: sqlite3.Connection, table: str) -> bool:
    return bool(conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    if not table_exists(conn, table):
        return []
    return [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()]


def add_column(conn: sqlite3.Connection, table: str, col: str, ddl_type: str) -> None:
    if col not in table_columns(conn, table):
        conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}" {ddl_type}')


def integrity_check() -> str:
    if not DB_FILE.exists():
        return "missing"
    with connect() as conn:
        row = conn.execute("PRAGMA integrity_check").fetchone()
        return str(row[0] if row else "failed")


def validate_production_db_or_fail(min_products: Optional[int] = None) -> None:
    if not (_env_true("PRICEBOT_PRODUCTION_MODE") or _env_true("PRICEBOT_STRICT_DB_STARTUP")):
        return
    min_products = _min_products_guard() if min_products is None else int(min_products)
    if not DB_FILE.exists():
        raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | db_missing | {DB_FILE}")
    with DB_FILE.open("rb") as fh:
        if fh.read(16) != b"SQLite format 3\x00":
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | not_sqlite | {DB_FILE}")
    with connect() as conn:
        result = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if str(result).lower() != "ok":
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | integrity={result}")
        if not table_exists(conn, "products"):
            raise RuntimeError("PRODUCTION_DB_STARTUP_FAILED | products_table_missing")
        count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count < min_products:
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | products={count} | min={min_products}")


def init_db(run_production_guard: bool = True) -> None:
    if run_production_guard:
        validate_production_db_or_fail()
    with connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL DEFAULT '')")
        for col, ddl in TEXT_COLUMNS.items():
            add_column(conn, "products", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_norm ON products(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_product_id ON products(product_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_search_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL,
                kind TEXT NOT NULL,
                product_db_id INTEGER NOT NULL,
                weight INTEGER DEFAULT 0,
                UNIQUE(key, kind, product_db_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_index_key ON product_search_index(key)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS guided_catalog_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                main_section TEXT NOT NULL,
                sub_section TEXT DEFAULT '',
                product_type TEXT DEFAULT '',
                use_case TEXT DEFAULT '',
                skin_type TEXT DEFAULT '',
                body_area TEXT DEFAULT '',
                age_group TEXT DEFAULT '',
                visible INTEGER DEFAULT 1,
                sort_name TEXT DEFAULT '',
                UNIQUE(product_db_id, main_section, sub_section, skin_type)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_guided_main ON guided_catalog_index(main_section, sub_section, visible)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversation_state (
                phone TEXT PRIMARY KEY,
                state_json TEXT NOT NULL DEFAULT '{}',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT NOT NULL,
                product_db_id INTEGER,
                product_name TEXT DEFAULT '',
                quantity INTEGER DEFAULT 1,
                price TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS processed_messages (
                message_id TEXT PRIMARY KEY,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)


def backup_db(label: str = "manual") -> Path:
    if not DB_FILE.exists():
        raise FileNotFoundError(f"DB not found: {DB_FILE}")
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = BACKUPS_DIR / f"pricebot_{label}_{stamp}.db"
    src = sqlite3.connect(str(DB_FILE), timeout=30)
    dst = sqlite3.connect(str(backup), timeout=30)
    try:
        src.backup(dst)
    finally:
        src.close(); dst.close()
    return backup


def restore_db_from_backup(backup_path: Path) -> None:
    backup_path = Path(backup_path)
    if not backup_path.exists():
        raise FileNotFoundError(str(backup_path))
    test = sqlite3.connect(str(backup_path), timeout=10)
    try:
        res = test.execute("PRAGMA integrity_check").fetchone()[0]
        if str(res).lower() != "ok":
            raise RuntimeError(f"backup integrity failed: {res}")
    finally:
        test.close()
    if DB_FILE.exists():
        emergency = backup_db("before_restore")
        print(f"PRE_RESTORE_BACKUP={emergency}")
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(backup_path, DB_FILE)


def audit(event: str, details: Any = None) -> None:
    try:
        with connect() as conn:
            conn.execute("INSERT INTO audit_logs(event, details) VALUES(?, ?)", (event, json.dumps(details or {}, ensure_ascii=False)))
    except Exception:
        pass


def product_visible(product: Dict[str, Any], guided: bool = False) -> bool:
    if not truthy(product.get("available")):
        return False
    if not str(product.get("price") or "").strip():
        return False
    quality = normalize_text(product.get("quality_status"))
    review = normalize_text(product.get("review_status"))
    search_mode = normalize_text(product.get("search_mode"))
    if review not in VISIBLE_REVIEW:
        return False
    if quality not in VISIBLE_QUALITY:
        return False
    if search_mode in (GUIDED_HIDDEN_SEARCH_MODES if guided else HIDDEN_SEARCH_MODES):
        return False
    return True


def count_products() -> int:
    with connect() as conn:
        if not table_exists(conn, "products"):
            return 0
        return int(conn.execute("SELECT COUNT(*) FROM products").fetchone()[0])


def count_table(table: str) -> int:
    with connect() as conn:
        if not table_exists(conn, table):
            return 0
        return int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])


def get_product(product_db_id: int) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        row = conn.execute("SELECT * FROM products WHERE id=?", (int(product_db_id),)).fetchone()
        return dict_row(row)


def load_product_rows(limit: Optional[int] = None, visible_only: bool = False, guided: bool = False) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM products ORDER BY name COLLATE NOCASE"
    if limit:
        sql += f" LIMIT {int(limit)}"
    with connect() as conn:
        rows = [dict_row(r) for r in conn.execute(sql).fetchall()]
    rows = [r for r in rows if r]
    if visible_only:
        rows = [r for r in rows if product_visible(r, guided=guided)]
    return rows


def find_by_exact_index(key: str, kinds: Sequence[str]) -> List[Dict[str, Any]]:
    if not key:
        return []
    placeholders = ",".join("?" for _ in kinds)
    with connect() as conn:
        rows = conn.execute(f"""
            SELECT p.*, i.kind, i.weight
            FROM product_search_index i
            JOIN products p ON p.id = i.product_db_id
            WHERE i.key=? AND i.kind IN ({placeholders})
            ORDER BY i.weight DESC, p.name COLLATE NOCASE
            LIMIT 30
        """, (key, *kinds)).fetchall()
        return [dict_row(r) for r in rows]


def search_candidates_by_tokens(query_tokens: Sequence[str], limit: int = 20) -> List[Dict[str, Any]]:
    clean = [normalize_text(t) for t in query_tokens if normalize_text(t)]
    if not clean:
        return []
    with connect() as conn:
        rows = conn.execute("SELECT * FROM products WHERE available IS NOT NULL ORDER BY name COLLATE NOCASE LIMIT 10000").fetchall()
        out = []
        for row in rows:
            p = dict_row(row)
            if not product_visible(p, guided=False):
                continue
            hay = normalize_text(" ".join(str(p.get(c) or "") for c in ["name", "aliases", "brand", "product_family", "active_ingredient", "form", "strength", "size", "barcode"]))
            if all(t in hay.split() or t in hay for t in clean):
                score = sum(10 for t in clean if t in normalize_text(p.get("name")).split()) + sum(4 for t in clean if t in hay)
                p["_score"] = score
                out.append(p)
        out.sort(key=lambda x: (-int(x.get("_score") or 0), str(x.get("name") or "")))
        return out[:limit]


def replace_search_index(entries: List[Tuple[str, str, int, int]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM product_search_index")
        conn.executemany("INSERT OR IGNORE INTO product_search_index(key, kind, product_db_id, weight) VALUES(?,?,?,?)", entries)
        return len(entries)


def replace_guided_index(entries: List[Tuple[int, str, str, str, str, str, str, str, int, str]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM guided_catalog_index")
        conn.executemany("""
            INSERT OR IGNORE INTO guided_catalog_index(
                product_db_id, main_section, sub_section, product_type, use_case, skin_type, body_area, age_group, visible, sort_name
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
        """, entries)
        return len(entries)


def guided_products(main_section: str, sub_section: str = "", skin_type: str = "", page: int = 0, page_size: int = 10) -> List[Dict[str, Any]]:
    params: List[Any] = [main_section]
    filters = "g.visible=1 AND g.main_section=?"
    if sub_section:
        filters += " AND g.sub_section=?"
        params.append(sub_section)
    if skin_type:
        filters += " AND (g.skin_type=? OR g.skin_type='' OR g.skin_type='unknown')"
        params.append(skin_type)
    params.extend([int(page_size), int(page) * int(page_size)])
    with connect() as conn:
        rows = conn.execute(f"""
            SELECT p.*, g.main_section, g.sub_section, g.skin_type AS guided_skin_type
            FROM guided_catalog_index g
            JOIN products p ON p.id = g.product_db_id
            WHERE {filters}
            ORDER BY g.sort_name COLLATE NOCASE
            LIMIT ? OFFSET ?
        """, params).fetchall()
        out = []
        for row in rows:
            p = dict_row(row)
            if p and product_visible(p, guided=True):
                out.append(p)
        return out


def guided_count(main_section: str, sub_section: str = "") -> int:
    params: List[Any] = [main_section]
    filters = "visible=1 AND main_section=?"
    if sub_section:
        filters += " AND sub_section=?"
        params.append(sub_section)
    with connect() as conn:
        return int(conn.execute(f"SELECT COUNT(*) FROM guided_catalog_index WHERE {filters}", params).fetchone()[0])


def get_state(phone: str) -> Dict[str, Any]:
    with connect() as conn:
        row = conn.execute("SELECT state_json FROM conversation_state WHERE phone=?", (phone,)).fetchone()
        if not row:
            return {}
        try:
            return json.loads(row[0] or "{}")
        except Exception:
            return {}


def set_state(phone: str, state: Dict[str, Any]) -> None:
    with connect() as conn:
        conn.execute("""
            INSERT INTO conversation_state(phone, state_json, updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(phone) DO UPDATE SET state_json=excluded.state_json, updated_at=CURRENT_TIMESTAMP
        """, (phone, json.dumps(state or {}, ensure_ascii=False)))


def clear_state(phone: str) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM conversation_state WHERE phone=?", (phone,))


def mark_processed(message_id: str) -> bool:
    if not message_id:
        return True
    try:
        with connect() as conn:
            conn.execute("INSERT INTO processed_messages(message_id) VALUES(?)", (message_id,))
        return True
    except sqlite3.IntegrityError:
        return False


def create_order(phone: str, product: Dict[str, Any], quantity: int = 1) -> int:
    quantity = max(1, int(quantity or 1))
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO orders(phone, product_db_id, product_name, quantity, price, status)
            VALUES(?,?,?,?,?,'pending')
        """, (phone, product.get("id"), product.get("name") or "", quantity, safe_price(product.get("price"))))
        return int(cur.lastrowid)


def list_orders(status: str = "pending", limit: int = 100) -> List[Dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders WHERE status=? ORDER BY id DESC LIMIT ?", (status, int(limit))).fetchall()
        return [dict_row(r) for r in rows]


def recent_orders_for_phone(phone: str, limit: int = 5) -> List[Dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders WHERE phone=? ORDER BY id DESC LIMIT ?", (phone, int(limit))).fetchall()
        return [dict_row(r) for r in rows]


def update_order_status(order_id: int, status: str) -> None:
    with connect() as conn:
        conn.execute("UPDATE orders SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (status, int(order_id)))
