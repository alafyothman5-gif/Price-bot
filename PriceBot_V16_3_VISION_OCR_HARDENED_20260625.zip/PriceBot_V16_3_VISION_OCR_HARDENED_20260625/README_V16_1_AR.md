# PriceBot V16.1

## الجديد

1. حماية ضغط الصور:
   - لا ينهار البوت عند دخول صور كثيرة.
   - عند الزحمة يرسل تنبيه للعميل أو يرفض الصورة بأمان بدل تراكم غير محدود.
   - النصوص تبقى سريعة.

2. بدائل الكوزمتك فقط:
   - لو منتج تجميلي غير متوفر، يسأل العميل هل يريد بدائل.
   - Gemini يعمل فقط بعد موافقة العميل.
   - البدائل من قاعدة البيانات فقط، ولا يخترع منتجات.
   - فلتر صارم: نفس النوع/المادة/التركيز إن ذُكر، ويفضل شركة أخرى.

3. المطابقة الأساسية كما هي:
   - لا Gemini للنصوص.
   - لا embeddings للنصوص.
   - V16 Product Identity Router مستمر.

## الفحص

```bash
curl -s http://127.0.0.1:8090/health | python3 -m json.tool | head -120
```

ابحث عن:

```text
final_ui_version: v16_1_overload_cosmetic_alternatives
v16_1_overload_cosmetic_alternatives: true
cosmetic_alternatives
overload_protection
```
