# PriceBot V16.2 – Vision + Redis Stability

## الهدف
إصلاح مشاكل الصور المتكررة التي كانت تظهر كـ "الصورة غير واضحة" رغم أن اسم المنتج مقروء، مع إصلاحات أمان صغيرة للإنتاج.

## التغييرات

1. **تحسين Vision OCR**
   - رفع جودة الصورة المرسلة إلى Vision.
   - رفع العرض الأقصى إلى 1400px بدل 1024px.
   - تعديل Prompt حتى لا يترك `product_identity` فارغًا إذا كان اسم المنتج واضحًا جزئيًا.

2. **تخفيف فلتر Vision المحافظ**
   - سابقًا كان يرفض أي نتيجة `confidence < 0.75` حتى لو الاسم ظاهر.
   - الآن إذا كان اسم المنتج/التركيز واضحًا، يسمح بتمريره إلى Product Identity Router.
   - لا يعني هذا عرض سعر عشوائي؛ المطابقة النهائية لا تزال تمر عبر V16 Router.

3. **إصلاح CeraVe**
   - إزالة `cerave / سيرافي` من قائمة الكلمات العامة.
   - CeraVe ماركة حقيقية وليست كلمة generic.

4. **Redis fallback**
   - تفعيل `PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK=1` كحماية إضافية لو Redis انقطع لحظيًا.

5. **الحفاظ على V16/V16.1**
   - لا Gemini للنصوص.
   - لا embeddings للنصوص.
   - Gemini Vision للصور فقط.
   - حماية ضغط الصور وبدائل الكوزمتك باقية.

## الفحص المتوقع
`/health` يجب أن يعرض:

- `final_ui_version: v16_2_vision_redis_stability`
- `v16_2_vision_redis_stability: true`
- `semantic_memory_enabled: false`
- `vision_enabled: true`
