from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

import database
from normalizer import normalize_text, split_multi, is_generic_query

ROUTER_NAME = "v16_product_identity_router"

DROP_WORDS = {
    "السلام", "عليكم", "عليك", "مرحبا", "اهلا", "اهلاً", "اهلن", "لو", "سمحت", "سمحتي",
    "متوفر", "موجود", "عندكم", "عندك", "لديكم", "في", "الصيدليه", "الصيدلية", "صيدليه", "صيدلية",
    "نبي", "ابي", "ابى", "أبي", "نبى", "اريد", "أريد", "سعر", "كم", "شن", "بكم", "هل", "ممكن", "بالله",
    "available", "availability", "price", "have", "do", "you", "please", "pharmacy", "how", "much", "is", "the", "a", "an",
}

FORM_WORDS = {
    "tab", "tabs", "tablet", "tablets", "cap", "caps", "capsule", "capsules", "syrup", "susp", "suspension",
    "cream", "gel", "ointment", "lotion", "solution", "drop", "drops", "spray", "sachet", "powder", "oral",
    "mg", "ml", "iu", "gm", "g", "mcg", "٪", "percent",
    "كريم", "جل", "مرهم", "شراب", "حبوب", "حب", "كبسول", "كبسولات", "قطره", "قطرات", "بخاخ", "محلول", "بودره",
}

BLOCKED_GENERIC = {
    "دواء", "ادويه", "ادوية", "علاج", "مسكن", "مضاد", "مضاد حيوي", "دواء ضغط", "ضغط", "سكر", "صداع",
    "كريم", "مرطب", "غسول", "سيروم", "واقي", "واقي شمس", "فيتامين", "حديد", "زنك", "مغنيسيوم", "كالسيوم",
    "medicine", "drug", "painkiller", "antibiotic", "cream", "moisturizer", "cleanser", "serum", "sunscreen", "vitamin", "iron", "zinc",
}

MANUAL_ALIASES = {
    "اموكلان": "amoclan",
    "أموكلان": "amoclan",
    "اموكلين": "amoclan",
    "اموكلان": "amoclan",
    "باندول": "panadol",
    "بانادول": "panadol",
    "بنادول": "panadol",
    "بانادول": "panadol",
    "لاروش": "la roche",
    "لا روش": "la roche",
    "لاروش بوزيه": "la roche posay",
    "لاروش بوزي": "la roche posay",
    "لاروش بوزاي": "la roche posay",
    "فيروكسيل": "ferroxyl",
    "فيروكسل": "ferroxyl",
    "هيمازيم": "hemazym",
    "هيموزيم": "hemazym",
    "زيرولاكت": "xerolact",
    "زيرو لاكت": "xerolact",
    "ريلاستيل": "rilastil",
    "سيرافي": "cerave",
    "سيتافيل": "cetaphil",
    "ايفاكلار": "effaclar",
    "ايفاكلير": "effaclar",
}


def _load_env_aliases() -> Dict[str, str]:
    raw = os.getenv("PRICEBOT_PRODUCT_ALIASES", "")
    out: Dict[str, str] = {}
    for part in re.split(r"\s*\|\s*|\s*;\s*|\n+", raw):
        if not part.strip() or "=" not in part:
            continue
        a, b = part.split("=", 1)
        a = normalize_text(a)
        b = normalize_text(b)
        if a and b:
            out[a] = b
    return out


def compact(value: Any) -> str:
    return normalize_text(value).replace(" ", "")


def _tokens(value: Any) -> List[str]:
    return [t for t in normalize_text(value).split() if t and t not in DROP_WORDS]


def _significant_tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in _tokens(value):
        if t in FORM_WORDS:
            continue
        if len(t) <= 1 and not t.isdigit():
            continue
        out.append(t)
    return out


def _dedupe_products(rows: List[Dict[str, Any]], limit: int = 30) -> List[Dict[str, Any]]:
    seen = set()
    out = []
    for p in rows:
        try:
            pid = int(p.get("id") or 0)
        except Exception:
            pid = 0
        if not pid or pid in seen:
            continue
        if not database.product_visible(p, guided=False):
            continue
        out.append(p)
        seen.add(pid)
        if len(out) >= limit:
            break
    return out


def clean_product_query(raw: Any) -> str:
    q = normalize_text(raw)
    if not q:
        return ""
    aliases = dict(MANUAL_ALIASES)
    aliases.update(_load_env_aliases())
    # replace longer phrases first
    for src, dst in sorted(aliases.items(), key=lambda x: len(x[0]), reverse=True):
        src_n = normalize_text(src)
        dst_n = normalize_text(dst)
        if src_n and dst_n:
            q = re.sub(rf"(?<!\w){re.escape(src_n)}(?!\w)", dst_n, q)
    toks = [t for t in q.split() if t not in DROP_WORDS]
    return normalize_text(" ".join(toks))


def _term_parts(product: Dict[str, Any]) -> Tuple[List[str], List[str]]:
    product_terms: List[str] = []
    family_terms: List[str] = []

    for key in ["name", "original_name", "canonical_display_name", "normalized_name"]:
        value = normalize_text(product.get(key))
        if value:
            product_terms.append(value)

    for key in ["brand", "product_family", "company"]:
        value = normalize_text(product.get(key))
        if value and value not in BLOCKED_GENERIC:
            family_terms.append(value)

    for key in ["aliases", "ocr_keywords"]:
        for item in split_multi(product.get(key)):
            value = clean_product_query(item)
            if value and value not in BLOCKED_GENERIC:
                # An alias with 2+ significant tokens is usually product-level.
                if len(_significant_tokens(value)) >= 2:
                    product_terms.append(value)
                else:
                    family_terms.append(value)

    # Also derive first token brand-like family from name when no brand exists.
    name_toks = _significant_tokens(product.get("name") or product.get("original_name"))
    if name_toks:
        family_terms.append(name_toks[0])

    def clean_list(values: List[str]) -> List[str]:
        out: List[str] = []
        seen = set()
        for v in values:
            v = normalize_text(v)
            if not v or v in seen or v in BLOCKED_GENERIC:
                continue
            out.append(v)
            seen.add(v)
        return out

    return clean_list(product_terms), clean_list(family_terms)


def _ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def _query_is_family(q: str, products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not q:
        return []
    q_compact = compact(q)
    hits: List[Dict[str, Any]] = []
    for p in products:
        _, family_terms = _term_parts(p)
        for term in family_terms:
            if q == term or q_compact == compact(term):
                hits.append(p)
                break
    return _dedupe_products(hits, limit=80)


def _score_product(q: str, product: Dict[str, Any]) -> Tuple[float, str, bool]:
    """Return (score, source, exact_product_term)."""
    if not q:
        return 0.0, "empty", False
    qc = compact(q)
    q_tokens = set(_significant_tokens(q))
    product_terms, family_terms = _term_parts(product)

    for term in product_terms:
        tc = compact(term)
        if q == term or qc == tc:
            return 1.0, "exact_product_term", True

    # Query is an exact family term for this product, not enough for direct.
    for term in family_terms:
        if q == term or qc == compact(term):
            return 0.91, "family_term", False

    best = 0.0
    source = "none"
    for term in product_terms + family_terms:
        if not term:
            continue
        tc = compact(term)
        term_tokens = set(_significant_tokens(term))
        if q_tokens and q_tokens.issubset(term_tokens):
            score = 0.80 + min(0.12, 0.03 * len(q_tokens))
            if score > best:
                best, source = score, "token_subset"
        if len(qc) >= 4 and (qc in tc or tc in qc):
            # substring is useful but never direct by itself
            ratio = min(len(qc), len(tc)) / max(len(qc), len(tc))
            score = 0.78 + min(0.14, 0.14 * ratio)
            if score > best:
                best, source = score, "substring"
        if len(qc) >= 5 and len(tc) >= 5:
            r = _ratio(qc, tc)
            if r >= 0.74 and r > best:
                best, source = r, "fuzzy"
    return best, source, False


@dataclass
class RouterDecision:
    action: str
    product: Optional[Dict[str, Any]] = None
    product_id: int = 0
    confidence: float = 0.0
    similarity: float = 0.0
    source: str = ""
    reason: str = ""
    candidates: List[Dict[str, Any]] = field(default_factory=list)
    query_text: str = ""


def route_product_query(raw: Any, *, limit: int = 30, source_context: str = "text") -> RouterDecision:
    q = clean_product_query(raw)
    if not q or q in BLOCKED_GENERIC or is_generic_query(q):
        return RouterDecision(action="unavailable", reason="empty_or_generic_query", query_text=q, source="v16_router")

    products = database.load_product_rows(visible_only=True)
    if not products:
        return RouterDecision(action="unavailable", reason="no_visible_products", query_text=q, source="v16_router")

    # 1) Family/brand exact: always list when multiple sellable products exist.
    family_hits = _query_is_family(q, products)
    if family_hits:
        if len(family_hits) == 1:
            p = family_hits[0]
            return RouterDecision(action="direct", product=p, product_id=int(p.get("id") or 0), confidence=0.995, similarity=1.0, source="v16_family_unique", candidates=[p], query_text=q)
        return RouterDecision(action="confirm", product=family_hits[0], product_id=int(family_hits[0].get("id") or 0), confidence=0.96, similarity=1.0, source="v16_family_list", candidates=family_hits[:limit], query_text=q)

    scored: List[Tuple[float, str, bool, Dict[str, Any]]] = []
    for p in products:
        score, src, exact = _score_product(q, p)
        if score >= 0.74:
            scored.append((score, src, exact, p))

    scored.sort(key=lambda x: (x[0], 1 if x[2] else 0, str(x[3].get("name") or "")), reverse=True)
    candidates = _dedupe_products([p for _, _, _, p in scored], limit=limit)
    if not candidates:
        return RouterDecision(action="unavailable", reason="no_safe_candidates", query_text=q, source="v16_router")

    exact_candidates = _dedupe_products([p for score, src, exact, p in scored if exact and score >= 0.999], limit=limit)
    if exact_candidates:
        if len(exact_candidates) == 1:
            p = exact_candidates[0]
            return RouterDecision(action="direct", product=p, product_id=int(p.get("id") or 0), confidence=0.999, similarity=1.0, source="v16_exact_product", candidates=[p], query_text=q)
        return RouterDecision(action="confirm", product=exact_candidates[0], product_id=int(exact_candidates[0].get("id") or 0), confidence=0.98, similarity=1.0, source="v16_exact_multi", candidates=exact_candidates[:limit], query_text=q)

    top_score, top_src, _, top_product = scored[0]

    # 2) Strong non-exact hits: list/confirm only; no direct price from fuzzy/rank.
    strong = _dedupe_products([p for score, _, _, p in scored if score >= max(0.82, top_score - 0.06)], limit=limit)
    if top_score >= 0.90 and len(strong) == 1:
        # Unique but not exact: confirmation button, not direct.
        p = strong[0]
        return RouterDecision(action="confirm", product=p, product_id=int(p.get("id") or 0), confidence=0.91, similarity=top_score, source=f"v16_unique_{top_src}", candidates=[p], query_text=q)

    if top_score >= 0.80 and strong:
        return RouterDecision(action="confirm", product=strong[0], product_id=int(strong[0].get("id") or 0), confidence=0.88, similarity=top_score, source="v16_candidate_list", candidates=strong[:limit], query_text=q)

    return RouterDecision(action="unavailable", reason="below_safe_threshold", confidence=top_score, similarity=top_score, query_text=q, source="v16_router")


def health() -> Dict[str, Any]:
    try:
        visible = len(database.load_product_rows(visible_only=True))
    except Exception:
        visible = 0
    return {
        "router": ROUTER_NAME,
        "text_gemini_enabled": False,
        "text_embeddings_enabled": False,
        "direct_policy": "exact_product_or_unique_family_only",
        "fuzzy_policy": "confirm_or_list_only",
        "visible_products_cached": visible,
        "manual_aliases": len(MANUAL_ALIASES) + len(_load_env_aliases()),
        "updated_at": int(time.time()),
    }
