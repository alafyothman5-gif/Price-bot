# PriceBot V16.3 Vision OCR Hardened

إصلاح مسار الصور بعد V16.2.

- Gemini Vision كان يعمل، لكن أحيانًا يرجع LOW_CONFIDENCE بصيغة غير JSON.
- الـ parser كان يقبل `status LOW CONFIDENCE` كأنه اسم منتج.
- تم منع ذلك نهائيًا.
- تم إجبار Vision على JSON قدر الإمكان.
- تم رفع جودة الصورة إلى 1800px و JPEG 95.
- تم تفعيل detail=high.
- لا يزال النص يعمل بدون Gemini وبدون embeddings.
