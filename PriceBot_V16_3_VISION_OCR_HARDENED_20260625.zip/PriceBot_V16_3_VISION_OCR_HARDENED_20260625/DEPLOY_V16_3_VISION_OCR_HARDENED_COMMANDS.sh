#!/usr/bin/env bash
set -Eeuo pipefail

ZIP_PATH="${1:-}"
APP_DIR="/opt/pricebot_whatsapp_gemini"
SERVICE="pricebot-whatsapp-gemini"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="/root/backups/pricebot_before_v16_3_$TS"

if [[ -z "$ZIP_PATH" || ! -f "$ZIP_PATH" ]]; then
  echo "ERROR: pass V16.3 zip path"
  exit 1
fi

mkdir -p /root/backups "$BACKUP_DIR"
echo "### Backup current PriceBot"
if [[ -d "$APP_DIR" ]]; then
  rsync -aHAX --numeric-ids "$APP_DIR/" "$BACKUP_DIR/pricebot_whatsapp_gemini/"
fi
cp -a "/etc/systemd/system/$SERVICE.service" "$BACKUP_DIR/$SERVICE.service" 2>/dev/null || true
journalctl -u "$SERVICE" -n 300 --no-pager > "$BACKUP_DIR/journal_before.txt" 2>&1 || true
echo "$BACKUP_DIR" > /root/backups/LAST_PRICEBOT_PRE_V16_BACKUP.txt

WORK="/tmp/pricebot_v16_1_unpack_$TS"
rm -rf "$WORK"
mkdir -p "$WORK"
unzip -q "$ZIP_PATH" -d "$WORK"
SRC="$(find "$WORK" -maxdepth 2 -type d -name app | head -1 | xargs -r dirname)"
if [[ -z "$SRC" || ! -d "$SRC/app" ]]; then
  echo "ERROR: app folder not found in zip"
  exit 1
fi

echo "### Stop PriceBot"
systemctl stop "$SERVICE" || true

mkdir -p "$APP_DIR"
if [[ -f "$APP_DIR/.env" ]]; then
  cp -a "$APP_DIR/.env" "$BACKUP_DIR/.env.preserved"
fi

echo "### Install V16.3 files"
rsync -a --delete \
  --exclude='.env' \
  --exclude='.venv' \
  --exclude='data' \
  --exclude='*.db' \
  --exclude='*.sqlite' \
  --exclude='*.sqlite3' \
  "$SRC/app/" "$APP_DIR/"

if [[ -f "$BACKUP_DIR/.env.preserved" ]]; then
  cp -a "$BACKUP_DIR/.env.preserved" "$APP_DIR/.env"
fi

cat >> "$APP_DIR/.env" <<'EOF'

# V16.3 Product Identity Router + vision/redis stability
PRICEBOT_MATCHING_POLICY=v16_3_vision_ocr_hardened
PRICEBOT_SEMANTIC_INDEX_ON_STARTUP=0
PRICEBOT_SEMANTIC_PERIODIC_INDEX=0
PRICEBOT_ENABLE_SEMANTIC_MEMORY_DECISIONS=0
PRICEBOT_TEXT_WORKERS=30
PRICEBOT_IMAGE_WORKERS=10
PRICEBOT_POSTGRES_POOL_MIN=5
PRICEBOT_POSTGRES_POOL_MAX=30
PRICEBOT_POSTGRES_POOL_TIMEOUT_SECONDS=10
PRICEBOT_IMAGE_QUEUE_WARN_AT=60
PRICEBOT_IMAGE_QUEUE_REJECT_AT=240
PRICEBOT_IMAGE_QUEUE_NOTICE_TTL_SECONDS=120
PRICEBOT_COSMETIC_ALT_CONCURRENCY=2
PRICEBOT_COSMETIC_ALT_MAX_RESULTS=5
PRICEBOT_COSMETIC_ALT_CANDIDATES=60
PRICEBOT_COSMETIC_ALT_TIMEOUT_SECONDS=12
PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK=1
PRICEBOT_VISION_MAX_WIDTH=1800
PRICEBOT_VISION_JPEG_QUALITY=95
PRICEBOT_VISION_TIMEOUT_SECONDS=14
PRICEBOT_VISION_RETRY_ATTEMPTS=3
PRICEBOT_VISION_RETRY_BASE_DELAY_SECONDS=0.5
EOF

if [[ -d "$APP_DIR/.venv" && -x "$APP_DIR/.venv/bin/python" ]]; then
  echo "### Compile check"
  cd "$APP_DIR"
  "$APP_DIR/.venv/bin/python" -m py_compile app.py product_identity_router.py cosmetic_alternatives.py database.py vision_service.py semantic_matcher.py
else
  echo "WARNING: venv not found; skipping compile check"
fi

if [[ -f "$SRC/systemd/$SERVICE.service" ]]; then
  cp -a "$SRC/systemd/$SERVICE.service" "/etc/systemd/system/$SERVICE.service"
fi
sed -i 's/--workers [0-9][0-9]*/--workers 2/g' "/etc/systemd/system/$SERVICE.service"

if command -v redis-cli >/dev/null 2>&1; then
  redis-cli --scan --pattern '*gemini_verify*' | xargs -r redis-cli del >/dev/null 2>&1 || true
  redis-cli --scan --pattern '*vision:*' | xargs -r redis-cli del >/dev/null 2>&1 || true
fi

echo "### Restart PriceBot"
systemctl daemon-reload
systemctl restart "$SERVICE"
sleep 8

echo "### Status"
systemctl status "$SERVICE" --no-pager | head -50 || true

echo
echo "### Health"
curl -s http://127.0.0.1:8090/health | python3 -m json.tool | head -120 || true

echo
echo "DONE_V16_3_VISION_OCR_HARDENED"
echo "Backup: $BACKUP_DIR"
