# PriceBot V15 – Gemini Router Clean

تم تغيير نظام المطابقة من عرض نتائج semantic الخام إلى Router نهائي يعتمد على Gemini.

## السياسة الجديدة

- Gemini هو صاحب القرار النهائي: `direct` أو `list` أو `unavailable`.
- لا تُعرض قائمة من نتائج semantic الخام للمستخدم.
- الاسم العام مثل `Panadol` / `باندول` / `La Roche` / `لاروش` يعرض قائمة variants فقط إذا وجد أكثر من شكل.
- الاسم المحدد مثل `Panadol Advance` يعرض السعر مباشرة فقط عند ثقة عالية جدًا.
- غير الموجود يرجع غير متوفر بدل اقتراح بديل عشوائي.
- الصور لا تطابق إلا إذا اتفق نص Vision مع المنتج المقترح؛ وإلا يطلب صورة أوضح أو الاسم كتابة.
- تم تعطيل semantic memory كقرار افتراضي حتى لا تعيد تأكيدات قديمة نتائج خاطئة.
- تم إضافة PostgreSQL advisory lock في startup حتى يعمل `--workers 2` بدون deadlock.

## ثوابت لم تتغير

- `embedding_dim = 1536`
- لا توجد نماذج محلية أو sentence-transformers أو reranker.
