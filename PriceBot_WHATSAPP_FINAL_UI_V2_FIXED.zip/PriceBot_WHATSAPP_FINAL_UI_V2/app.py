from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import re
import time
from collections import defaultdict, deque
from typing import Any, Deque, Dict, List, Optional, Tuple

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse

import config_env

# Load .env before resolving database path, WhatsApp tokens, or Gemini config.
config_env.load_environment()

import database
import vision_service
from normalizer import clean_query, normalize_text
from services.vision import ai_product_matcher

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN") or os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "الصيدلية")

TEXT_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_TEXT_QUEUE_MAXSIZE", os.getenv("PRICEBOT_QUEUE_MAXSIZE", "2000")) or 2000)
IMAGE_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_IMAGE_QUEUE_MAXSIZE", "500") or 500)
TEXT_WORKERS = int(os.getenv("PRICEBOT_TEXT_WORKERS", "8") or 8)
IMAGE_WORKERS = int(os.getenv("PRICEBOT_IMAGE_WORKERS", "3") or 3)
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "25") or 25)
RATE_LIMIT_IMAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_IMAGES", "6") or 6)
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60") or 60)
IMAGE_CONCURRENCY = int(os.getenv("PRICEBOT_IMAGE_CONCURRENCY", "4") or 4)
IMAGE_TOTAL_TIMEOUT = float(os.getenv("PRICEBOT_IMAGE_TOTAL_TIMEOUT_SECONDS", "18") or 18)

PRICEBOT_CURRENCY = os.getenv("PRICEBOT_CURRENCY", "د.ل")
NOT_FOUND_REPLY = os.getenv("PRICEBOT_NOT_FOUND_REPLY", "غير متوفر")
UNCLEAR_IMAGE_REPLY = os.getenv("PRICEBOT_UNCLEAR_IMAGE_REPLY", "لم أتعرف على المنتج. اكتب الاسم أو أرسل صورة أوضح.")
GREETING_REPLY = os.getenv("PRICEBOT_GREETING_REPLY", "اكتب اسم المنتج أو أرسل صورته.")
REQUIRE_GEMINI = str(os.getenv("PRICEBOT_REQUIRE_GEMINI_MATCHING", "1")).lower() in {"1", "true", "yes", "on"}
STRICT_EVIDENCE_GUARD = str(os.getenv("PRICEBOT_STRICT_TEXT_EVIDENCE_GUARD", "0")).lower() in {"1", "true", "yes", "on"}

app = FastAPI(title="PriceBot WhatsApp Only", docs_url=None, redoc_url=None, openapi_url=None)
text_queue: asyncio.Queue = asyncio.Queue(maxsize=TEXT_QUEUE_MAXSIZE)
image_queue: asyncio.Queue = asyncio.Queue(maxsize=IMAGE_QUEUE_MAXSIZE)
http_client: Optional[httpx.AsyncClient] = None
rate_buckets: Dict[str, Deque[float]] = defaultdict(deque)
image_rate_buckets: Dict[str, Deque[float]] = defaultdict(deque)
user_locks: Dict[str, asyncio.Lock] = {}
user_lock_last_seen: Dict[str, float] = {}
USER_LOCK_TTL_SECONDS = int(os.getenv("PRICEBOT_USER_LOCK_TTL_SECONDS", "900") or 900)
image_semaphore = asyncio.Semaphore(max(1, IMAGE_CONCURRENCY))


def log(event: str, **kw: Any) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["token", "secret", "authorization", "key"]):
            v = "HIDDEN"
        if k in {"phone", "to", "from_", "from"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _extract_candidate_texts(extracted: Dict[str, Any]) -> List[str]:
    parts: List[str] = []
    for key in [
        "query", "primary_title", "product_name", "product_family",
        "foreground_product_text", "foreground_text", "visible_text", "raw_vision_text",
        "brand", "form", "strength", "size", "pack",
    ]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    return parts


def _has_product_text(parts: List[str]) -> bool:
    combined = " ".join(str(p or "") for p in parts).strip()
    if not combined:
        return False
    if re.search(r"\d+\s*(?:mg|mcg|g|gm|ml|iu|%)\b", combined, flags=re.I):
        return True
    generic = {
        "image", "photo", "picture", "box", "pack", "package", "tablet", "tablets",
        "capsule", "capsules", "cream", "gel", "lotion", "syrup", "solution", "oral",
        "bottle", "label", "صوره", "صورة", "علبه", "علبة", "حبوب", "كبسولات", "شراب",
    }
    for token in re.findall(r"[a-zA-Z\u0600-\u06FF0-9%/+-]+", combined.lower()):
        t = token.strip(" -_+/")
        if len(t) >= 3 and t not in generic and re.search(r"[a-zA-Z\u0600-\u06FF]", t):
            return True
    return False


def _price_only(product: Dict[str, Any]) -> str:
    raw_price = str(product.get("price") or "").strip()
    currency = str(product.get("currency") or PRICEBOT_CURRENCY or "").strip()
    if not raw_price:
        return NOT_FOUND_REPLY
    # The owner requested price-only replies. Keep the response compact and avoid
    # product details, alternatives, booking text, catalog links, or buttons.
    return f"{raw_price} {currency}".strip()


def _is_greeting_or_empty(text: str) -> bool:
    n = normalize_text(text or "")
    return n in {
        "", "start", "ابدأ", "ابدا", "السلام عليكم", "سلام", "مرحبا", "اهلا", "هاي",
        "hello", "hi", "menu", "القائمه", "القائمة", "الرئيسيه", "الرئيسية",
    }


def _clean_product_query(text: str) -> str:
    raw = str(text or "").strip()
    cleaned = clean_query(raw).strip()
    return cleaned or raw


# ---------------------------------------------------------------------------
# Final WhatsApp customer UI
# ---------------------------------------------------------------------------
# WhatsApp buttons/lists are used instead of asking customers to type numbers.
# The bot starts with a welcome menu for any first Arabic/English text, then
# searches only after the customer chooses text or image search.
USER_MODES: Dict[str, str] = {}
MAX_LIST_ROWS = int(os.getenv("PRICEBOT_MAX_LIST_ROWS", "10") or 10)
MAX_LIST_MESSAGES = int(os.getenv("PRICEBOT_MAX_LIST_MESSAGES", "3") or 3)

BTN_SEARCH_TEXT = "BTN_SEARCH_TEXT"
BTN_SEARCH_IMAGE = "BTN_SEARCH_IMAGE"
UNSUPPORTED_MEDIA_TOKEN = "__UNSUPPORTED_MEDIA__"

PRODUCT_STOPWORDS = {
    "mg", "mcg", "g", "gm", "ml", "iu", "tab", "tabs", "tablet", "tablets",
    "cap", "caps", "capsule", "capsules", "syrup", "cream", "gel", "spray",
    "drop", "drops", "solution", "oral", "coated", "film", "enteric", "x",
    "pack", "box", "pcs", "piece", "دواء", "الدواء", "علبة", "علبه", "حبوب",
    "كبسول", "كبسولات", "شراب", "مرهم", "كريم", "جل", "قطرة", "بخاخ",
    "اقراص", "أقراص", "شريط", "حبة", "حبه",
}

PRESCRIPTION_HINTS = {
    "rx", "prescription", "doctor", "patient", "diagnosis", "dose", "dosage",
    "clinic", "hospital", "روشتة", "روشته", "وصفة", "وصفه", "دكتور", "طبيب",
    "عيادة", "عياده", "مريض", "المريض", "تشخيص", "جرعة", "الجرعة",
}

_DIGITS_TRANS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def _wa_text(body: str) -> Dict[str, Any]:
    return {"__wa_payload": {"type": "text", "text": {"body": str(body or "")[:3900]}}}


def _welcome_menu_payload() -> Dict[str, Any]:
    body = (
        f"مرحبًا بك في {PHARMACY_NAME} 🌿\n\n"
        "اختر طريقة البحث عن توفر وسعر الدواء أو المنتج:"
    )
    return {
        "__wa_payload": {
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": body},
                "action": {
                    "buttons": [
                        {"type": "reply", "reply": {"id": BTN_SEARCH_TEXT, "title": "بحث نص"}},
                        {"type": "reply", "reply": {"id": BTN_SEARCH_IMAGE, "title": "بحث بصورة"}},
                    ]
                },
            },
        }
    }


def _ask_text_payload() -> Dict[str, Any]:
    return _wa_text("اكتب اسم الدواء أو المنتج الآن.\nمثال: Panadol Extra")


def _ask_image_payload() -> Dict[str, Any]:
    return _wa_text("أرسل صورة واضحة لعلبة الدواء أو المنتج فقط.")


def _unavailable_payload() -> Dict[str, Any]:
    return _wa_text(
        "نعتذر، المنتج غير متوفر حاليًا في الصيدلية.\n"
        "يمكنك البحث باسم آخر أو إرسال صورة واضحة للمنتج."
    )


def _prescription_payload() -> Dict[str, Any]:
    return _wa_text(
        "عذرًا، لا يمكنني قراءة الروشتات الطبية.\n"
        "فضلاً أرسل صورة واضحة لعلبة الدواء أو المنتج فقط."
    )


def _unclear_image_payload() -> Dict[str, Any]:
    return _wa_text(
        "لم أتمكن من قراءة اسم المنتج من الصورة بوضوح.\n"
        "فضلاً أرسل صورة أوضح لواجهة العلبة أو اكتب اسم المنتج."
    )


def _product_name(product: Dict[str, Any]) -> str:
    return str(
        product.get("canonical_display_name")
        or product.get("name")
        or product.get("original_name")
        or ""
    ).strip()


def _product_price(product: Dict[str, Any]) -> str:
    raw_price = str(product.get("price") or "").strip()
    currency = str(product.get("currency") or PRICEBOT_CURRENCY or "").strip()
    if not raw_price:
        return ""
    return f"{raw_price} {currency}".strip()


def _product_available_payload(product: Dict[str, Any]) -> Dict[str, Any]:
    price = _product_price(product)
    if not price:
        return _unavailable_payload()
    return _wa_text(f"متوفر ✅\nالسعر: {price}")


def _short(value: str, limit: int) -> str:
    value = re.sub(r"\s+", " ", str(value or "")).strip()
    if not value:
        return "منتج"
    return value if len(value) <= limit else value[: max(1, limit - 1)].rstrip() + "…"


def _product_tokens(value: Any) -> List[str]:
    n = normalize_text(str(value or ""))
    raw = re.findall(r"[a-zA-Z0-9\u0600-\u06FF]+", n)
    out: List[str] = []
    seen = set()
    for token in raw:
        t = token.strip().lower().translate(_DIGITS_TRANS)
        if not t or t in PRODUCT_STOPWORDS:
            continue
        # Pure numbers such as 200 or 10 are too weak for product matching.
        # They caused unrelated products with the same strength/volume to appear
        # in image search results. Keep brand/product words as the matching core.
        if t.isdigit():
            continue
        if len(t) < 2:
            continue
        if t not in seen:
            out.append(t)
            seen.add(t)
    return out


def _product_haystack(product: Dict[str, Any]) -> str:
    fields = [
        "name", "original_name", "canonical_display_name", "brand", "company",
        "product_family", "active_ingredient", "form", "strength", "size", "pack",
        "barcode", "aliases", "ocr_keywords", "category", "subcategory", "main_section",
        "sub_section", "product_type", "medicine_form",
    ]
    return " ".join(str(product.get(f) or "") for f in fields)


def _dedupe_products(products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for product in products:
        key = normalize_text(_product_name(product)) + "|" + str(product.get("price") or "").strip()
        if not key.strip("|") or key in seen:
            continue
        seen.add(key)
        out.append(product)
    return out


def _search_available_products(query: str, *, limit: int = 40) -> List[Dict[str, Any]]:
    q = _clean_product_query(query)
    q_norm = normalize_text(q)
    q_tokens = _product_tokens(q)
    q_compact = q_norm.replace(" ", "")
    if not q_norm and not q_tokens:
        return []

    results: List[Dict[str, Any]] = []
    for product in database.load_product_rows(visible_only=True):
        name = _product_name(product)
        if not name:
            continue
        name_norm = normalize_text(name)
        hay = normalize_text(_product_haystack(product))
        hay_tokens = set(_product_tokens(hay))
        hay_compact = hay.replace(" ", "")

        matched_tokens: List[str] = []
        for token in q_tokens:
            if token in hay_tokens or (len(token) >= 4 and token in hay_compact):
                matched_tokens.append(token)

        substring_hit = False
        if q_norm and name_norm:
            substring_hit = q_norm in name_norm or name_norm in q_norm
        if q_compact and len(q_compact) >= 4 and q_compact in hay_compact:
            substring_hit = True

        if not matched_tokens and not substring_hit:
            continue

        name_tokens = _product_tokens(name)
        score = 0
        if name_norm == q_norm:
            score += 10000
        if q_norm and q_norm in name_norm:
            score += 900
        if name_norm and name_norm in q_norm:
            score += 700
        if q_tokens:
            score += len(set(matched_tokens)) * 180
            if len(set(matched_tokens)) == len(set(q_tokens)):
                score += 420
        if q_tokens and name_tokens and q_tokens[0] == name_tokens[0]:
            score += 260
        extra_tokens = [t for t in name_tokens if t not in set(matched_tokens)]
        score -= min(len(extra_tokens) * 10, 120)

        item = dict(product)
        item["_score"] = score
        item["_name_token_count"] = len(name_tokens)
        results.append(item)

    results.sort(key=lambda x: (-int(x.get("_score") or 0), int(x.get("_name_token_count") or 99), len(_product_name(x)), _product_name(x).lower()))
    return _dedupe_products(results)[:limit]


def _should_show_list(query: str, candidates: List[Dict[str, Any]]) -> bool:
    if len(candidates) <= 1:
        return False
    q_norm = normalize_text(query)
    q_tokens = _product_tokens(query)
    exact = [p for p in candidates if normalize_text(_product_name(p)) == q_norm]
    if len(exact) == 1 and len(q_tokens) > 1:
        return False
    if len(q_tokens) <= 2:
        return True
    top = int(candidates[0].get("_score") or 0)
    second = int(candidates[1].get("_score") or 0)
    return (top - second) < 180


def _product_list_payloads(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payloads: List[Dict[str, Any]] = []
    shown_limit = max(1, MAX_LIST_ROWS) * max(1, MAX_LIST_MESSAGES)
    candidates = candidates[:shown_limit]
    if not candidates:
        return [_unavailable_payload()]

    chunks = [candidates[i:i + MAX_LIST_ROWS] for i in range(0, len(candidates), MAX_LIST_ROWS)]
    for idx, chunk in enumerate(chunks, start=1):
        rows = []
        for product in chunk:
            pid = int(product.get("id") or 0)
            name = _product_name(product)
            price = _product_price(product)
            rows.append({
                "id": f"PROD:{pid}",
                "title": _short(name, 24),
                "description": _short(f"{price} - {name}" if price else name, 72),
            })
        body = "وجدت أكثر من منتج متوفر بهذا الاسم. اختر المنتج المطلوب من القائمة:"
        if len(chunks) > 1:
            body += f"\nالقائمة {idx} من {len(chunks)}"
        payloads.append({
            "__wa_payload": {
                "type": "interactive",
                "interactive": {
                    "type": "list",
                    "body": {"text": body},
                    "action": {"button": "اختر المنتج", "sections": [{"title": "المنتجات المتوفرة", "rows": rows}]},
                },
            }
        })
    return payloads


def _looks_like_prescription(text: str) -> bool:
    n = normalize_text(text)
    return any(hint in n for hint in PRESCRIPTION_HINTS)


def _is_search_text_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_TEXT), "بحث نص", "بحث بنص", "نص", "1"}


def _is_search_image_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_IMAGE), "بحث صورة", "بحث بصورة", "صورة", "صوره", "2"}


def _is_product_selection(raw: str) -> bool:
    return str(raw or "").strip().startswith("PROD:")


async def _match_with_gemini(query: str, *, phone: str = "", source: str = "whatsapp_text") -> Optional[Dict[str, Any]]:
    query = str(query or "").strip()
    if not query:
        return None
    if REQUIRE_GEMINI and not config_env.resolve_openrouter_api_key():
        log("GEMINI_MATCHING_DISABLED", reason="missing_openrouter_api_key")
        return None

    ai_hit = await ai_product_matcher.match_extracted_text_to_product(query)
    if not bool(ai_hit.get("matched")):
        log("GEMINI_MATCH_FALSE", reason=ai_hit.get("reason"), source=source)
        return None

    try:
        product_id = int(ai_hit.get("product_id") or 0)
    except Exception:
        product_id = 0
    if not product_id:
        log("GEMINI_MATCH_REJECTED", reason="missing_product_id", source=source)
        return None

    product = database.get_product(product_id)
    if not product or not database.product_visible(product, guided=False):
        log("GEMINI_MATCH_REJECTED", reason="product_not_visible", product_id=product_id, source=source)
        return None

    # Gemini is the primary/only matcher. The optional local evidence guard is
    # disabled by default because bilingual pharmacy queries can be valid even
    # when their tokens do not overlap exactly with the Excel product name.
    if STRICT_EVIDENCE_GUARD:
        evidence = ai_product_matcher.validate_text_evidence_for_match(
            query,
            product.get("canonical_display_name") or product.get("name") or "",
        )
        if not evidence.get("passed"):
            log("GEMINI_MATCH_EVIDENCE_REJECTED", product_id=product_id, reason=evidence.get("reason"), source=source)
            return None

    try:
        database.record_search_log(
            product_id=product_id,
            product_name=product.get("canonical_display_name") or product.get("name") or "",
            user_id=phone,
            source=source,
        )
    except Exception as exc:
        log("SEARCH_LOG_WARNING", error=repr(exc))
    return product


async def process_text(phone: str, text: str) -> Any:
    raw = str(text or "").strip()

    if raw == UNSUPPORTED_MEDIA_TOKEN:
        return _prescription_payload()

    if _is_product_selection(raw):
        try:
            pid = int(raw.split(":", 1)[1])
        except Exception:
            pid = 0
        product = database.get_product(pid) if pid else None
        USER_MODES[phone] = "awaiting_text"
        if product and database.product_visible(product, guided=False):
            log("UI_PRODUCT_SELECTED", phone=phone, product_id=pid)
            return _product_available_payload(product)
        return _unavailable_payload()

    if _is_search_text_button(raw):
        USER_MODES[phone] = "awaiting_text"
        return _ask_text_payload()

    if _is_search_image_button(raw):
        USER_MODES[phone] = "awaiting_image"
        return _ask_image_payload()

    # First contact / any normal Arabic or English text before choosing a mode:
    # show the welcome menu with buttons, as requested.
    if USER_MODES.get(phone) != "awaiting_text":
        USER_MODES[phone] = "idle"
        return _welcome_menu_payload()

    query = _clean_product_query(raw)
    if not query:
        return _ask_text_payload()
    if _looks_like_prescription(query):
        return _prescription_payload()

    candidates = _search_available_products(query, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES)
    if not candidates:
        log("UI_TEXT_NOT_AVAILABLE", phone=phone, query=query[:120])
        USER_MODES[phone] = "awaiting_text"
        return _unavailable_payload()

    if _should_show_list(query, candidates):
        log("UI_TEXT_LIST", phone=phone, query=query[:120], count=len(candidates))
        return _product_list_payloads(candidates)

    product = candidates[0]
    USER_MODES[phone] = "awaiting_text"
    log("UI_TEXT_MATCH", phone=phone, product_id=product.get("id"), name=_product_name(product))
    return _product_available_payload(product)



def _vision_search_text(extracted: Dict[str, Any]) -> str:
    """Build a clean product-focused query from Gemini/Vision output.

    Do not search using the full raw OCR dump first. Raw label text contains
    weak tokens like 200, cream, balm, dermatologico, etc.; using it caused
    unrelated product lists. Prefer structured product fields and only fall back
    to raw text when nothing else exists.
    """
    priority_keys = [
        "query", "product_name", "primary_title", "product_family",
        "brand", "foreground_product_text", "foreground_text",
        "form", "strength", "size",
    ]
    parts: List[str] = []
    for key in priority_keys:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    focused = " ".join(parts).strip()
    if _product_tokens(focused):
        return focused
    fallback = str((extracted or {}).get("visible_text") or (extracted or {}).get("raw_vision_text") or "").strip()
    return fallback


def _strong_image_candidates(evidence_text: str, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Keep only products strongly supported by the image text.

    For image matching, a product must share distinctive tokens with the
    detected package name. A shared strength/volume number or generic dosage
    form is not enough.
    """
    q_tokens = _product_tokens(evidence_text)
    distinctive = [t for t in q_tokens if len(t) >= 3]
    if not distinctive:
        return []

    filtered: List[Dict[str, Any]] = []
    required = 1 if len(distinctive) == 1 else 2

    for product in candidates:
        hay_tokens = set(_product_tokens(_product_haystack(product)))
        name_tokens = set(_product_tokens(_product_name(product)))
        hit = [t for t in distinctive if t in hay_tokens]
        name_hit = [t for t in distinctive if t in name_tokens]

        if len(hit) >= required or (distinctive and distinctive[0] in name_tokens and len(hit) >= 1):
            item = dict(product)
            item["_image_hits"] = len(hit)
            item["_image_name_hits"] = len(name_hit)
            # Promote products matching more visible package tokens.
            item["_score"] = int(item.get("_score") or 0) + len(hit) * 350 + len(name_hit) * 250
            filtered.append(item)

    filtered.sort(key=lambda x: (-int(x.get("_image_hits") or 0), -int(x.get("_image_name_hits") or 0), -int(x.get("_score") or 0), len(_product_name(x))))
    return _dedupe_products(filtered)

async def process_image(phone: str, media_id: str) -> Any:
    log("IMAGE_RECEIVED", phone=phone)
    USER_MODES[phone] = "awaiting_image"
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return _unclear_image_payload()

    image_hash = hashlib.sha256(image_bytes or b"").hexdigest() if image_bytes else ""
    if not image_bytes:
        return _unclear_image_payload()

    try:
        cached = database.get_image_cache(image_hash=image_hash, media_id=media_id)
        if cached and cached.get("matched_product_id"):
            product = database.get_product(int(cached.get("matched_product_id") or 0))
            if product and database.product_visible(product, guided=False):
                log("IMAGE_EXACT_CACHE_HIT", product_id=product.get("id"))
                return _product_available_payload(product)
    except Exception as exc:
        log("IMAGE_CACHE_WARNING", error=repr(exc))

    try:
        async with image_semaphore:
            extracted = await asyncio.wait_for(
                vision_service.extract_product_from_image(image_bytes, mime),
                timeout=IMAGE_TOTAL_TIMEOUT,
            )
    except asyncio.TimeoutError:
        log("VISION_TIMEOUT", phone=phone)
        return _unclear_image_payload()
    except Exception as exc:
        log("VISION_ERROR", error=repr(exc))
        return _unclear_image_payload()

    parts = _extract_candidate_texts(extracted)
    evidence_text = _vision_search_text(extracted)
    raw_evidence_text = " ".join(parts).strip()
    if not evidence_text and not raw_evidence_text:
        return _prescription_payload()
    if _looks_like_prescription(evidence_text) or _looks_like_prescription(raw_evidence_text):
        log("VISION_PRESCRIPTION_REJECTED", text=(evidence_text or raw_evidence_text)[:160])
        return _prescription_payload()
    if extracted.get("status") != "OK" and not _has_product_text(parts):
        log("VISION_REJECTED", status=extracted.get("status"))
        return _prescription_payload()

    log("UI_IMAGE_EVIDENCE", text=evidence_text[:180])
    raw_candidates = _search_available_products(evidence_text, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES)
    candidates = _strong_image_candidates(evidence_text, raw_candidates)
    if not candidates:
        try:
            database.record_learning_event(
                customer_query=str(extracted.get("query") or ""),
                vision_text=evidence_text[:1000],
                decision="LOCAL_NO_MATCH",
                reason=str(extracted.get("status") or "no_match"),
                media_id=media_id,
                query_slots={**(extracted or {}), "image_hash": image_hash},
            )
        except Exception:
            pass
        return _unavailable_payload()

    # Image search should be strict. If there are several strong matches, send
    # one focused list only; do not flood the customer with unrelated pages.
    if len(candidates) > 1 and _should_show_list(evidence_text, candidates):
        focused = candidates[:MAX_LIST_ROWS]
        log("UI_IMAGE_LIST", phone=phone, text=evidence_text[:140], count=len(focused))
        return _product_list_payloads(focused[:MAX_LIST_ROWS])[:1]

    product = candidates[0]
    log("UI_IMAGE_MATCH", product_id=product.get("id"), name=_product_name(product))
    try:
        database.set_image_cache(
            image_hash=image_hash,
            media_id=media_id,
            extracted_slots=extracted or {},
            matched_product_id=int(product.get("id") or 0),
            decision="UI_IMAGE_MATCHED",
            confidence=str(extracted.get("confidence") or ""),
        )
    except Exception as exc:
        log("IMAGE_CACHE_SET_WARNING", error=repr(exc))
    return _product_available_payload(product)


def rate_limit_ok(phone: str, *, image: bool = False) -> bool:
    now = time.time()
    bucket = image_rate_buckets[phone] if image else rate_buckets[phone]
    while bucket and now - bucket[0] > RATE_LIMIT_WINDOW:
        bucket.popleft()
    limit = RATE_LIMIT_IMAGES if image else RATE_LIMIT_MESSAGES
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def cleanup_user_locks() -> None:
    now = time.time()
    stale = [phone for phone, ts in user_lock_last_seen.items() if now - ts > USER_LOCK_TTL_SECONDS]
    for phone in stale:
        lock = user_locks.get(phone)
        if lock is not None and lock.locked():
            continue
        user_locks.pop(phone, None)
        user_lock_last_seen.pop(phone, None)


def get_user_lock(phone: str) -> asyncio.Lock:
    cleanup_user_locks()
    lock = user_locks.get(phone)
    if lock is None:
        lock = asyncio.Lock()
        user_locks[phone] = lock
    user_lock_last_seen[phone] = time.time()
    return lock


def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET or not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


async def send_whatsapp_message(to_number: str, content: Any) -> bool:
    if not content:
        return False

    # Allow process_text/process_image to return multiple interactive list
    # messages when a generic name has more than 10 matching products.
    if isinstance(content, list):
        ok = True
        for item in content:
            ok = bool(await send_whatsapp_message(to_number, item)) and ok
            await asyncio.sleep(0.15)
        return ok

    if isinstance(content, dict) and "__wa_payload" in content:
        payload = dict(content["__wa_payload"])
        payload["messaging_product"] = "whatsapp"
        payload["to"] = to_number
    else:
        text = str(content or "")
        payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": text[:3900]}}

    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number)
        return True
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_ERROR", status=resp.status_code, response=resp.text[:500])
            return False
        return True
    except Exception as exc:
        log("SEND_EXCEPTION", error=repr(exc))
        return False


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not META_TOKEN:
        return b"", "image/jpeg"
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    assert http_client is not None
    meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
    meta.raise_for_status()
    info = meta.json()
    url = info.get("url", "")
    mime = info.get("mime_type", "image/jpeg")
    if not url:
        return b"", mime
    data = await http_client.get(url, headers=headers, timeout=20)
    data.raise_for_status()
    return data.content, mime


def extract_messages(payload: Dict[str, Any]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        br = inter.get("button_reply") or {}
                        text = br.get("id") or br.get("title") or ""
                    elif inter.get("type") == "list_reply":
                        lr = inter.get("list_reply") or {}
                        text = lr.get("id") or lr.get("title") or ""
                elif mtype in {"document", "audio", "video", "sticker"}:
                    text = UNSUPPORTED_MEDIA_TOKEN
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out


async def worker(worker_id: int, worker_queue: asyncio.Queue, queue_name: str) -> None:
    while True:
        item = await worker_queue.get()
        try:
            phone = item["phone"]
            is_image = bool(item.get("type") == "image" or item.get("media_id"))
            if not rate_limit_ok(phone, image=is_image):
                await send_whatsapp_message(phone, "طلبات كثيرة بسرعة. حاول بعد قليل.")
                continue
            if item.get("id") and not database.mark_processed(item.get("id")):
                continue
            async with get_user_lock(phone):
                user_lock_last_seen[phone] = time.time()
                if is_image:
                    reply = await process_image(phone, item.get("media_id", ""))
                else:
                    log("MESSAGE_RECEIVED", phone=phone, text=str(item.get("text", ""))[:100])
                    reply = await process_text(phone, item.get("text", ""))
                await send_whatsapp_message(phone, reply)
                user_lock_last_seen[phone] = time.time()
        except Exception as exc:
            log("WORKER_ERROR", worker=f"{queue_name}-{worker_id}", error=repr(exc))
            try:
                await send_whatsapp_message(item.get("phone", ""), "حدث خطأ. حاول مرة أخرى.")
            except Exception:
                pass
        finally:
            worker_queue.task_done()


@app.on_event("startup")
async def startup() -> None:
    global http_client
    database.init_db(run_production_guard=True)
    try:
        log("DB_PERFORMANCE_HARDENING", **database.apply_performance_hardening())
    except Exception as exc:
        log("DB_PERFORMANCE_HARDENING_WARNING", error=repr(exc))
    try:
        log("FINAL_SCHEMA", **database.ensure_final_hardening_schema())
    except Exception as exc:
        log("FINAL_SCHEMA_WARNING", error=repr(exc))
    try:
        log("RUNTIME_CLEANUP", **database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30)))
    except Exception as exc:
        log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
    http_client = httpx.AsyncClient()
    for i in range(TEXT_WORKERS):
        asyncio.create_task(worker(i + 1, text_queue, "text"))
    for i in range(IMAGE_WORKERS):
        asyncio.create_task(worker(i + 1, image_queue, "image"))
    log(
        "PRICEBOT_WHATSAPP_ONLY_STARTED",
        products=database.count_products(),
        text_workers=TEXT_WORKERS,
        image_workers=IMAGE_WORKERS,
        gemini="configured" if config_env.resolve_openrouter_api_key() else "missing_key",
        vision="enabled" if config_env.vision_enabled() else config_env.vision_disabled_reason(),
    )


@app.on_event("shutdown")
async def shutdown() -> None:
    if http_client:
        await http_client.aclose()


@app.get("/health")
def health() -> Dict[str, Any]:
    return {
        "ok": True,
        "service": "pricebot-whatsapp-only",
        "products_count": database.count_products(),
        "text_queue_size": text_queue.qsize(),
        "image_queue_size": image_queue.qsize(),
        "workers": TEXT_WORKERS + IMAGE_WORKERS,
        "gemini_configured": bool(config_env.resolve_openrouter_api_key()),
        "vision_enabled": config_env.vision_enabled(),
        "web_pages_enabled": False,
        "final_ui_enabled": True,
        "final_ui_version": "v2_stateful_strict_image",
    }


@app.get("/")
def root() -> Dict[str, Any]:
    return {"ok": True, "service": "pricebot-whatsapp-only", "webhook": "/webhook", "web_pages_enabled": False, "final_ui_enabled": True}


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


def enqueue_message_fast(msg: Dict[str, str]) -> bool:
    try:
        queue = image_queue if (msg.get("type") == "image" or msg.get("media_id")) else text_queue
        queue.put_nowait(msg)
        return True
    except asyncio.QueueFull:
        log("QUEUE_FULL", phone=msg.get("phone"))
        return False


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    body = await request.body()
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        return PlainTextResponse("bad signature", status_code=403)
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json"}, status_code=400)
    queued = 0
    dropped = 0
    for msg in extract_messages(payload):
        if enqueue_message_fast(msg):
            queued += 1
        else:
            dropped += 1
    return {"ok": True, "queued": queued, "busy": dropped, "mode": "whatsapp_only"}
