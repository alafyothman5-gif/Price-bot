#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${PRICEBOT_APP_DIR:-/opt/pricebot_clean}"
HOST="${HOST:-${PRICEBOT_HOST:-127.0.0.1}}"
PORT="${PORT:-${PRICEBOT_PORT:-8090}}"
cd "$APP_DIR"
ENV_FILE="${PRICEBOT_ENV_FILE:-$APP_DIR/.env}"
if [ -f "$ENV_FILE" ]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi
if [ -x "$APP_DIR/.venv/bin/python" ]; then
  PY="$APP_DIR/.venv/bin/python"
elif [ -x "$APP_DIR/venv/bin/python" ]; then
  PY="$APP_DIR/venv/bin/python"
else
  PY="python3"
fi
exec "$PY" -m uvicorn app:app --host "$HOST" --port "$PORT" --proxy-headers
