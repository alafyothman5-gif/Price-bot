# PriceBot V16.5 Safe Catalog Terms Layer

هذه النسخة مبنية على V16.3 فقط، وتتجاهل V16.4 نهائياً.

## الهدف

تحسين المطابقة بدون لمس جدول المنتجات الأصلي:

- لا تغيير أسعار.
- لا تغيير is_available.
- لا حذف منتجات.
- لا استيراد Excel جديد فوق جدول products.
- لا Gemini للنصوص.
- لا embeddings للنصوص.
- Gemini Vision يبقى للصور فقط.

## الطبقة الجديدة

تمت إضافة جدول مشتق:

```text
product_search_terms
```

هذا الجدول يحتوي مصطلحات بحث آمنة مشتقة من المنتجات الحالية:

- exact_product
- brand
- family
- alias

## القواعد

- اسم الشركة فقط لا يعطي سعر مباشر.
- الأسماء العامة تعرض قائمة/تأكيد فقط.
- السعر المباشر يخرج فقط من term من نوع exact_product.
- البحث الضبابي على terms لا يعطي سعر مباشر؛ يعطي قائمة/تأكيد فقط.

## أمثلة

```text
Bioderma
```

لا يعطي سعر مباشر، بل قائمة/تأكيد.

```text
Bioderma Sebium Gel
```

يطابق المنتج المحدد إذا موجود.

```text
Biretix Tri Active
```

يبحث في product_search_terms بدل الاعتماد على الاسم الخام فقط.

## النشر

```bash
bash DEPLOY_V16_5_SAFE_CATALOG_TERMS_LAYER_COMMANDS.sh /path/to/PriceBot_V16_5_SAFE_CATALOG_TERMS_LAYER_20260626.zip
```

## الرجوع

السكريبت يحفظ Backup قبل التركيب في:

```text
/root/backups/LAST_PRICEBOT_PRE_V16_5_BACKUP.txt
```
