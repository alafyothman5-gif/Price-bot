#!/usr/bin/env bash
set -Eeuo pipefail

ZIP_PATH="${1:-}"
APP_DIR="/opt/pricebot_whatsapp_gemini"
SERVICE="pricebot-whatsapp-gemini"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="/root/backups/pricebot_before_v16_5_catalog_terms_$TS"

if [[ -z "$ZIP_PATH" || ! -f "$ZIP_PATH" ]]; then
  echo "ERROR: pass V16.5 zip path"
  exit 1
fi

mkdir -p /root/backups "$BACKUP_DIR/systemd" "$BACKUP_DIR/postgres" "$BACKUP_DIR/logs"
echo "### Backup current PriceBot"
if [[ -d "$APP_DIR" ]]; then
  rsync -aHAX --numeric-ids "$APP_DIR/" "$BACKUP_DIR/pricebot_whatsapp_gemini/"
fi
cp -a "/etc/systemd/system/$SERVICE.service" "$BACKUP_DIR/systemd/" 2>/dev/null || true
journalctl -u "$SERVICE" -n 300 --no-pager > "$BACKUP_DIR/logs/journal_before.txt" 2>&1 || true
if command -v pg_dump >/dev/null 2>&1; then
  sudo -u postgres pg_dump -Fc pricebot > "$BACKUP_DIR/postgres/pricebot_before_v16_5.dump" 2>"$BACKUP_DIR/postgres/pg_dump.err" || true
fi
echo "$BACKUP_DIR" > /root/backups/LAST_PRICEBOT_PRE_V16_5_BACKUP.txt

WORK="/tmp/pricebot_v16_5_unpack_$TS"
rm -rf "$WORK"
mkdir -p "$WORK"
unzip -q "$ZIP_PATH" -d "$WORK"

# Robustly locate the app folder even if ZIP has a top-level directory or nested folder.
APP_SRC="$(find "$WORK" -type f -name app.py -printf '%h\n' | head -1)"
if [[ -z "$APP_SRC" || ! -f "$APP_SRC/app.py" ]]; then
  echo "ERROR: app.py/app folder not found in zip"
  echo "ZIP content sample:"
  find "$WORK" -maxdepth 8 -type f | head -120
  exit 1
fi
ROOT_SRC="$(dirname "$APP_SRC")"

echo "### Source app folder: $APP_SRC"

echo "### Stop PriceBot"
systemctl stop "$SERVICE" || true

mkdir -p "$APP_DIR"
if [[ -f "$APP_DIR/.env" ]]; then
  cp -a "$APP_DIR/.env" "$BACKUP_DIR/.env.preserved"
fi

echo "### Install V16.5 files"
rsync -a --delete \
  --exclude='.env' \
  --exclude='.venv' \
  --exclude='data' \
  --exclude='*.db' \
  --exclude='*.sqlite' \
  --exclude='*.sqlite3' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  "$APP_SRC/" "$APP_DIR/"

if [[ -f "$BACKUP_DIR/.env.preserved" ]]; then
  cp -a "$BACKUP_DIR/.env.preserved" "$APP_DIR/.env"
fi

# Add/update V16.5 runtime flags. Duplicate keys are acceptable because app reads last effective env from shell,
# but we remove previous V16.5 block markers first to keep .env readable.
cat >> "$APP_DIR/.env" <<'EOF'

# V16.5 Safe Catalog Terms Layer - derived search metadata only
PRICEBOT_MATCHING_POLICY=v16_5_safe_catalog_terms_layer
PRICEBOT_SEMANTIC_INDEX_ON_STARTUP=0
PRICEBOT_SEMANTIC_PERIODIC_INDEX=0
PRICEBOT_ENABLE_SEMANTIC_MEMORY_DECISIONS=0
PRICEBOT_TEXT_WORKERS=30
PRICEBOT_IMAGE_WORKERS=10
PRICEBOT_POSTGRES_POOL_MIN=5
PRICEBOT_POSTGRES_POOL_MAX=30
PRICEBOT_POSTGRES_POOL_TIMEOUT_SECONDS=10
PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK=1
PRICEBOT_RUNTIME_CACHE=1
PRICEBOT_RUNTIME_CACHE_TTL_SECONDS=3600
PRICEBOT_VISION_MAX_WIDTH=1800
PRICEBOT_VISION_JPEG_QUALITY=95
PRICEBOT_VISION_TIMEOUT_SECONDS=14
PRICEBOT_VISION_RETRY_ATTEMPTS=3
PRICEBOT_VISION_RETRY_BASE_DELAY_SECONDS=0.5
EOF

if [[ -d "$APP_DIR/.venv" && -x "$APP_DIR/.venv/bin/python" ]]; then
  echo "### Compile check"
  cd "$APP_DIR"
  "$APP_DIR/.venv/bin/python" -m py_compile app.py product_identity_router.py catalog_terms.py cosmetic_alternatives.py database.py vision_service.py semantic_matcher.py

  echo "### Build safe catalog terms layer"
  "$APP_DIR/.venv/bin/python" - <<'PY'
import os
from pathlib import Path
env = Path('/opt/pricebot_whatsapp_gemini/.env')
if env.exists():
    for line in env.read_text(errors='ignore').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k,v=line.split('=',1)
        os.environ[k.strip()] = v.strip().strip('"').strip("'")
import catalog_terms
print(catalog_terms.rebuild_terms())
PY
else
  echo "ERROR: venv not found at $APP_DIR/.venv"
  exit 1
fi

if [[ -f "$ROOT_SRC/systemd/$SERVICE.service" ]]; then
  cp -a "$ROOT_SRC/systemd/$SERVICE.service" "/etc/systemd/system/$SERVICE.service"
fi
if [[ -f "/etc/systemd/system/$SERVICE.service" ]]; then
  sed -i 's/--workers [0-9][0-9]*/--workers 2/g' "/etc/systemd/system/$SERVICE.service"
fi

if command -v redis-cli >/dev/null 2>&1; then
  redis-cli --scan --pattern '*products*' | xargs -r redis-cli del >/dev/null 2>&1 || true
  redis-cli --scan --pattern '*identity*' | xargs -r redis-cli del >/dev/null 2>&1 || true
  redis-cli --scan --pattern '*catalog*' | xargs -r redis-cli del >/dev/null 2>&1 || true
  redis-cli --scan --pattern '*vision:*' | xargs -r redis-cli del >/dev/null 2>&1 || true
fi

echo "### Restart PriceBot"
systemctl daemon-reload
systemctl restart "$SERVICE"
sleep 8

echo "### Status"
systemctl status "$SERVICE" --no-pager | head -50 || true

echo
echo "### Health"
curl -s http://127.0.0.1:8090/health | python3 -m json.tool | head -180 || true

echo
echo "DONE_V16_5_SAFE_CATALOG_TERMS_LAYER"
echo "Backup: $BACKUP_DIR"
