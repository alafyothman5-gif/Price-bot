from __future__ import annotations

"""Production-safe validation layer for AI Vision evidence.

The matcher must not search with all OCR text.  This module accepts either a
strict JSON payload from Vision or a raw model response, then returns only the
front/primary product evidence that is allowed to affect matching.
"""

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from normalizer import normalize_text

INGREDIENT_NOISE = {
    "folic", "folic acid", "vitamin", "vitamin b12", "b12", "iron", "zinc",
    "collagen", "hyaluronic", "hyaluronic acid", "spf", "niacinamide",
    "ceramide", "ceramides", "retinol", "caffeine", "paracetamol",
    "magnesium", "calcium", "omega", "dha", "epa", "biotin", "keratin",
    "acid", "sodium", "potassium", "chloride", "extract", "aqua", "water",
    "fragrance", "perfume", "glycerin", "panthenol", "allantoin",
}

BACKGROUND_HINTS = {
    "background", "shelf", "ingredient", "ingredients", "composition", "contains",
    "with", "plus", "supports", "health", "skin", "face", "body", "new", "daily",
    "laboratoires", "laboratoire", "dermatologique", "dermatological", "made in",
}

WEAK_TITLE_WORDS = {
    "cream", "gel", "lotion", "serum", "cleanser", "wash", "foam", "skin", "face",
    "body", "tablet", "capsules", "capsule", "syrup", "suspension", "drops", "spray",
    "tube", "box", "bottle", "mg", "ml", "g", "plus", "forte", "kids", "baby",
}

STRUCTURED_KEYS = {
    "product_identity", "primary_name", "variant",
    "foreground_product_text", "primary_title", "brand", "product_family", "form",
    "strength", "size", "pack", "background_text", "raw_vision_text", "confidence",
    # Backward-compatible keys emitted by older prompts.
    "main_visible_product", "product_name", "visible_text",
}

YES_NO_STATUSES = {"OK", "BAD_JSON_TITLE_ONLY", "IMAGE_UNCLEAR", "LOW_CONFIDENCE"}

PSEUDO_LOW_CONFIDENCE_TITLES = {
    "status low confidence", "low confidence", "image unclear", "status image unclear",
    "status ok", "ok", "unclear", "not readable", "no readable product",
}


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return " ".join(_as_text(v) for v in value if v is not None).strip()
    return str(value).strip()


def _find_json_object(raw: str) -> Tuple[Dict[str, Any], bool]:
    if not raw:
        return {}, False
    try:
        value = json.loads(raw)
        return (value if isinstance(value, dict) else {}), True
    except Exception:
        pass
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        try:
            value = json.loads(raw[start:end + 1])
            return (value if isinstance(value, dict) else {}), True
        except Exception:
            return {}, False
    return {}, False


def parse_vision_response(raw_response: str) -> Dict[str, Any]:
    data, ok = _find_json_object(raw_response or "")
    if ok:
        data["_json_ok"] = True
        return data
    title = detect_primary_title_from_raw(raw_response or "")
    if title:
        return {
            "_json_ok": False,
            "status": "BAD_JSON_TITLE_ONLY",
            "product_identity": title,
            "primary_name": title,
            "primary_title": title,
            "foreground_product_text": title,
            "raw_vision_text": raw_response or "",
            "confidence": 0.70,
        }
    return {
        "_json_ok": False,
        "status": "IMAGE_UNCLEAR",
        "raw_vision_text": raw_response or "",
        "confidence": 0.0,
    }


def detect_primary_title_from_raw(raw: str) -> str:
    """Best-effort title detector for bad JSON.

    It is intentionally conservative.  The returned title can be used only for a
    confirmation question, never for price display.
    """
    lines = [re.sub(r"[^A-Za-z0-9\-\s]+", " ", x).strip() for x in (raw or "").splitlines()]
    lines = [re.sub(r"\s+", " ", x) for x in lines if x.strip()]
    candidates: List[str] = []
    for line in lines[:8]:
        norm_line = normalize_text(line)
        if norm_line in PSEUDO_LOW_CONFIDENCE_TITLES or "low confidence" in norm_line or "image unclear" in norm_line:
            continue
        if len(line) < 3 or len(line) > 60:
            continue
        words = line.split()
        if not words:
            continue
        if normalize_text(words[0]) in {"status", "confidence", "product", "product identity", "primary", "primary name", "message"}:
            continue
        upper_ratio = sum(1 for ch in line if ch.isalpha() and ch.isupper()) / max(1, sum(1 for ch in line if ch.isalpha()))
        strong_words = [w for w in words if normalize_text(w) not in WEAK_TITLE_WORDS and len(w) > 2]
        if upper_ratio >= 0.55 and strong_words:
            candidates.append(line)
    if candidates:
        # Prefer the earliest short title.
        candidates.sort(key=lambda x: (len(x.split()) > 5, len(x)))
        return candidates[0]
    # Inline fallback: quoted/labelled product-like token.
    m = re.search(r"(?:product|title|name)\s*[:=]\s*([A-Z][A-Z0-9\- ]{2,50})", raw or "", flags=re.I)
    if m:
        value = re.sub(r"\s+", " ", m.group(1)).strip()
        n = normalize_text(value)
        if n not in PSEUDO_LOW_CONFIDENCE_TITLES and "low confidence" not in n and "image unclear" not in n:
            return value
    return ""


def _contains_noise_only(text: str) -> bool:
    n = normalize_text(text)
    if not n:
        return True
    words = n.split()
    if not words:
        return True
    strong = [w for w in words if w not in WEAK_TITLE_WORDS and not w.isdigit() and len(w) > 2]
    if not strong:
        return True
    joined = " ".join(words)
    if joined in INGREDIENT_NOISE:
        return True
    return False


def _remove_ingredient_noise(text: str) -> str:
    n = normalize_text(text)
    if not n:
        return ""
    # Remove multi-word ingredient phrases first.
    cleaned = f" {n} "
    for phrase in sorted(INGREDIENT_NOISE, key=len, reverse=True):
        p = normalize_text(phrase)
        if not p:
            continue
        cleaned = re.sub(r"(?<!\w)" + re.escape(p) + r"(?!\w)", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def _confidence(data: Dict[str, Any]) -> float:
    try:
        return float(data.get("confidence") or 0)
    except Exception:
        return 0.0


@dataclass
class VisionEvidence:
    status: str
    query: str = ""
    message: str = ""
    slots: Dict[str, Any] = field(default_factory=dict)
    needs_confirmation_only: bool = False


def _clean_identity_text(text: str) -> str:
    """Remove OCR/marketing noise while preserving product identifiers."""
    value = _as_text(text)
    if not value:
        return ""
    value = value.replace("\\n", " ").replace("\r", " ")
    value = re.sub(r"[•●|؛]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" -_|:;,.،")

    marketing_phrases = [
        "high absorption", "potent formula base", "potent formula", "formula base",
        "food supplement", "dietary supplement", "iron supplement",
        "dermatologically tested", "clinically proven", "for dry skin", "for very dry skin",
        "dry to very dry", "normal to dry", "sensitive skin", "oily skin", "made in",
        "keep out", "store below", "read leaflet", "supports health",
    ]
    # Remove only obvious marketing phrases. Do not remove product-line words
    # such as Liposomal, Effaclar, Cicaplast, Moisturising, etc.
    for phrase in marketing_phrases:
        value = re.sub(r"(?i)(?<!\w)" + re.escape(phrase) + r"(?!\w)", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" -_|:;,.،")
    return value[:180].strip()


def _dedupe_repeated_words(text: str) -> str:
    words = str(text or "").split()
    if not words:
        return ""
    # Collapse A B A B -> A B and A A -> A.
    for size in range(1, max(1, len(words) // 2) + 1):
        if len(words) >= size * 2 and words[:size] == words[size:size * 2]:
            words = words[:size] + words[size * 2:]
            break
    out = []
    for w in words:
        if not out or out[-1].lower() != w.lower():
            out.append(w)
    return " ".join(out).strip()


def _identity_from_slots(data: Dict[str, Any]) -> str:
    """Preferred clean query for matcher. Never uses raw/background OCR.

    If Vision returns structured identity slots, rebuild the query from those
    slots instead of trusting a potentially polluted product_identity string.
    This protects cases like:
    "Hemazym Liposomal Folic Acid Vitamin B12 High Absorption" ->
    "Hemazym Liposomal".
    """
    parts: List[str] = []
    seen = set()

    def add(value: Any) -> None:
        value = _clean_identity_text(value)
        if not value or _contains_noise_only(value):
            return
        key = normalize_text(value)
        if key and key not in seen:
            parts.append(value)
            seen.add(key)

    structured_keys = ["primary_name", "primary_title", "product_name", "brand", "variant", "product_family", "form", "strength", "size", "pack"]
    has_structured = any(_clean_identity_text(data.get(k)) for k in structured_keys)
    if has_structured:
        for key in structured_keys:
            add(data.get(key))
        identity = " ".join(parts).strip()
        identity = re.sub(r"\s+", " ", identity).strip(" -_|:;,.،")
        if identity:
            return identity[:180]

    explicit = _clean_identity_text(data.get("product_identity"))
    if explicit and not _contains_noise_only(explicit):
        # Last-resort explicit identity. Remove common ingredient/noise phrases
        # only in this fallback path to avoid passing long OCR text to matching.
        explicit = _remove_ingredient_noise(explicit) or explicit
        explicit = _dedupe_repeated_words(explicit)
        return explicit[:180]
    return ""


def validate_vision_payload(data: Dict[str, Any]) -> VisionEvidence:
    data = dict(data or {})
    raw_status = str(data.get("status") or "").strip()
    for k in ["product_identity", "primary_name", "primary_title", "product_name", "foreground_product_text", "main_visible_product", "visible_text"]:
        v = normalize_text(_as_text(data.get(k)))
        if v in PSEUDO_LOW_CONFIDENCE_TITLES or "low confidence" in v or "image unclear" in v:
            data[k] = ""

    if raw_status == "BAD_JSON_TITLE_ONLY":
        title = _as_text(data.get("product_identity") or data.get("primary_name") or data.get("primary_title") or data.get("foreground_product_text"))
        if title:
            return VisionEvidence(
                status="OK",
                query=title,
                needs_confirmation_only=True,
                message=f"هل تقصد {title}?",
                slots={
                    **data,
                    "product_identity": title,
                    "primary_name": title,
                    "foreground_product_text": title,
                    "primary_title": title,
                    "main_visible_product": title,
                    "product_name": title,
                    "visible_text": title,
                    "query": title,
                    "confidence": str(data.get("confidence") or 0.70),
                    "vision_validation": "bad_json_title_only",
                },
            )
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة لم تُقرأ بشكل كافٍ. اكتب اسم المنتج من فضلك.", slots=data)

    conf = _confidence(data)
    product_identity = _identity_from_slots(data)

    # V16.2: Vision models often read the product name correctly but assign a
    # conservative confidence, especially with pharmacy counter glare or angled
    # boxes. Do not reject such images before matching. If a strong foreground
    # identity exists, allow the router to produce a list/confirmation. Direct
    # price is still controlled later by Product Identity Router rules.
    if conf < 0.55:
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة غير كافية، أرسل صورة أوضح للمنتج أو اكتب اسمه.", slots=data)
    if conf < 0.75 and not product_identity:
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة غير كافية، أرسل صورة أوضح للمنتج أو اكتب اسمه.", slots=data)
    primary = _clean_identity_text(data.get("primary_name") or data.get("primary_title") or data.get("product_name") or data.get("main_visible_product"))
    brand = _clean_identity_text(data.get("brand"))
    variant = _clean_identity_text(data.get("variant") or data.get("product_family"))
    foreground = _as_text(data.get("foreground_product_text") or data.get("main_visible_product") or data.get("visible_text"))
    background = _as_text(data.get("background_text"))
    raw_vision = _as_text(data.get("raw_vision_text") or data.get("visible_text"))

    if not product_identity:
        # Controlled fallback: foreground is allowed only after ingredient/noise removal.
        foreground_clean = _clean_identity_text(_remove_ingredient_noise(foreground))
        if foreground_clean and not _contains_noise_only(foreground_clean):
            product_identity = foreground_clean

    if not product_identity or _contains_noise_only(product_identity):
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة غير كافية، أرسل صورة أوضح للمنتج أو اكتب اسمه.", slots=data)

    bg_norm = normalize_text(background)
    id_norm = normalize_text(product_identity)
    if bg_norm and id_norm and id_norm in bg_norm and not foreground and not primary:
        return VisionEvidence(status="IMAGE_UNCLEAR", message="النص المقروء يظهر كخلفية وليس اسم المنتج. أرسل صورة أوضح للواجهة الأمامية.", slots=data)

    slots = {
        **data,
        "product_identity": product_identity,
        "primary_name": primary or product_identity.split()[0],
        "brand": brand,
        "variant": variant,
        "foreground_product_text": foreground or product_identity,
        "primary_title": primary or product_identity,
        "main_visible_product": primary or product_identity,
        "product_name": primary or product_identity,
        "visible_text": product_identity,
        "background_text": background,
        "raw_vision_text": raw_vision,
        "query": product_identity,
        "confidence": str(conf),
        "vision_validation": "product_identity_only",
    }
    for key in ["form", "strength", "size", "pack", "product_family"]:
        if key in data:
            slots[key] = data.get(key)
    return VisionEvidence(status="OK", query=product_identity, slots=slots)


__all__ = [
    "INGREDIENT_NOISE",
    "VisionEvidence",
    "detect_primary_title_from_raw",
    "parse_vision_response",
    "validate_vision_payload",
]
