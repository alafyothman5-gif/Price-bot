#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP_DIR))

import config_env  # noqa: E402

config_env.load_environment()

import database  # noqa: E402
from semantic_matcher import SemanticMatcher  # noqa: E402


def log(event: str, **kw):
    print(json.dumps({"event": event, **kw}, ensure_ascii=False, default=str), flush=True)


async def main() -> int:
    parser = argparse.ArgumentParser(description="Rebuild missing PriceBot V10 pgvector embeddings.")
    parser.add_argument("--limit", type=int, default=int(os.getenv("PRICEBOT_SEMANTIC_REBUILD_LIMIT", "10000") or 10000))
    parser.add_argument("--batch-size", type=int, default=int(os.getenv("PRICEBOT_EMBEDDING_BATCH_SIZE", "64") or 64))
    args = parser.parse_args()

    database.init_db(run_production_guard=False)
    matcher = SemanticMatcher()
    matcher.set_logger(log)
    await matcher.initialize(auto_index=False)
    result = await matcher.rebuild_missing_embeddings(limit=args.limit, batch_size=args.batch_size)
    print(json.dumps({"ok": bool(result.get("ok")), "result": result, "health": matcher.health()}, ensure_ascii=False, indent=2, default=str))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
