from __future__ import annotations

import json
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import httpx

import config_env
import database
from normalizer import normalize_text

ALT_ENGINE_NAME = "v16_1_cosmetic_alternatives_strict"

# Cosmetic brands/ranges commonly found in pharmacy cosmetic catalogs.
COSMETIC_BRANDS = {
    "la roche", "la roche posay", "laroche", "larocheposay", "effaclar", "cicaplast", "anthelios",
    "cerave", "bioderma", "eucerin", "vichy", "avene", "uriage", "svr", "isis", "isispharma",
    "rilastil", "cetaphil", "mustela", "nuxe", "the ordinary", "ordinary", "acm", "ducray",
    "isis pharma", "bepanthen", "bioderma", "filorga", "sesderma", "isdin", "topicrem",
}

AR_SYNONYMS = {
    "لاروش": "la roche",
    "لا روش": "la roche",
    "لاروش بوزيه": "la roche posay",
    "سيرافي": "cerave",
    "بيوديرما": "bioderma",
    "ايucerin": "eucerin",
    "يوسرين": "eucerin",
    "فيشي": "vichy",
    "افين": "avene",
    "افان": "avene",
    "يورياج": "uriage",
    "اس في ار": "svr",
    "ريلاستيل": "rilastil",
    "سيتافيل": "cetaphil",
    "موستيلا": "mustela",
    "ذا اورديناري": "the ordinary",
    "اورديناري": "the ordinary",
    "سيكا": "cica",
    "سيكابلاست": "cicaplast",
    "سيروم": "serum",
    "نايسن امايد": "niacinamide",
    "نايسناميد": "niacinamide",
    "نياسيناميد": "niacinamide",
    "نياسناميد": "niacinamide",
    "هيالورونيك": "hyaluronic",
    "هيالورونك": "hyaluronic",
    "ريتينول": "retinol",
    "فيتامين سي": "vitamin c",
    "فتامين سي": "vitamin c",
    "ساليسيليك": "salicylic",
    "ازيليك": "azelaic",
    "ازليك": "azelaic",
    "سيراميد": "ceramide",
    "يوريا": "urea",
    "واقي شمس": "sunscreen spf",
    "واقي": "sunscreen",
    "غسول": "cleanser",
    "مرطب": "moisturizer",
    "لوشن": "lotion",
    "تونر": "toner",
    "بلسم": "balm",
}

ACTIVE_GROUPS: Dict[str, set[str]] = {
    "niacinamide": {"niacinamide", "niacinamid", "nicinamide", "نايسن", "نايسناميد", "نياسيناميد"},
    "cica": {"cica", "cicaplast", "cicabio", "cicalfate", "سيكا", "سيكابلاست", "b5"},
    "hyaluronic": {"hyaluronic", "hyalu", "ha", "هيالورونيك"},
    "retinol": {"retinol", "retinal", "ريتينول"},
    "vitamin_c": {"vitamin c", "vit c", "ascorbic", "فيتامين سي"},
    "salicylic": {"salicylic", "bha", "ساليسيليك"},
    "azelaic": {"azelaic", "azelaic acid", "ازيليك", "ازليك"},
    "ceramide": {"ceramide", "ceramides", "سيراميد"},
    "urea": {"urea", "يوريا"},
    "spf": {"spf", "sunscreen", "anthelios", "واقي", "واقي شمس"},
    "cleanser": {"cleanser", "wash", "gel moussant", "غسول"},
    "effaclar": {"effaclar", "ايفاكلار", "ايفاكلير"},
}

FORM_GROUPS: Dict[str, set[str]] = {
    "serum": {"serum", "سيروم"},
    "cream": {"cream", "creme", "كريم"},
    "gel": {"gel", "جل"},
    "cleanser": {"cleanser", "wash", "غسول"},
    "sunscreen": {"sunscreen", "spf", "واقي", "واقي شمس"},
    "lotion": {"lotion", "لوشن"},
    "toner": {"toner", "تونر"},
    "balm": {"balm", "baume", "بلسم"},
}

GENERIC_ONLY = {"cream", "كريم", "serum", "سيروم", "gel", "جل", "moisturizer", "مرطب", "cleanser", "غسول", "sunscreen", "واقي"}
DROP_WORDS = {"السلام", "عليكم", "متوفر", "موجود", "عندكم", "نبي", "ابي", "أبي", "سعر", "كم", "هل", "لو", "سمحت", "please", "price", "available", "do", "you", "have"}


def clean_query(value: Any) -> str:
    q = normalize_text(value)
    for src, dst in sorted(AR_SYNONYMS.items(), key=lambda x: len(x[0]), reverse=True):
        src_n = normalize_text(src)
        dst_n = normalize_text(dst)
        if src_n and dst_n:
            q = re.sub(rf"(?<!\w){re.escape(src_n)}(?!\w)", dst_n, q)
    toks = [t for t in q.split() if t not in DROP_WORDS]
    return normalize_text(" ".join(toks))


def product_text(product: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key in ["name", "canonical_display_name", "original_name", "brand", "product_family", "aliases", "active_ingredient", "form", "strength", "size", "pack"]:
        v = str((product or {}).get(key) or "").strip()
        if v:
            parts.append(v)
    return clean_query(" ".join(parts))


def _contains_any(text: str, values: set[str]) -> bool:
    if not text:
        return False
    padded = f" {text} "
    compact = text.replace(" ", "")
    for v in values:
        vn = clean_query(v)
        if not vn:
            continue
        if f" {vn} " in padded or vn.replace(" ", "") in compact:
            return True
    return False


def _extract_groups(text: str, groups: Dict[str, set[str]]) -> set[str]:
    found: set[str] = set()
    for name, variants in groups.items():
        if _contains_any(text, variants):
            found.add(name)
    return found


def _extract_brand(text: str) -> str:
    compact = text.replace(" ", "")
    for brand in sorted(COSMETIC_BRANDS, key=len, reverse=True):
        b = clean_query(brand)
        if not b:
            continue
        if b in text or b.replace(" ", "") in compact:
            return b
    return ""


def _extract_concentrations(text: str) -> set[str]:
    out: set[str] = set()
    for m in re.finditer(r"\b(\d+(?:\.\d+)?)\s*(%|percent|٪)\b", text):
        out.add(m.group(1).rstrip(".0") + "%")
    return out


def _extract_features(value: Any) -> Dict[str, Any]:
    q = clean_query(value)
    return {
        "clean_query": q,
        "brand": _extract_brand(q),
        "actives": _extract_groups(q, ACTIVE_GROUPS),
        "forms": _extract_groups(q, FORM_GROUPS),
        "concentrations": _extract_concentrations(q),
    }


def is_cosmetic_request(value: Any) -> bool:
    f = _extract_features(value)
    q = f["clean_query"]
    if not q:
        return False
    # Do not trigger alternatives for generic-only requests like "كريم".
    tokens = set(q.split())
    if tokens and tokens.issubset(GENERIC_ONLY):
        return False
    return bool(f["brand"] or f["actives"] or _contains_any(q, set().union(*FORM_GROUPS.values()))) and bool(f["actives"] or f["brand"])


def _product_cosmetic(product: Dict[str, Any]) -> bool:
    t = product_text(product)
    return bool(_extract_brand(t) or _extract_groups(t, ACTIVE_GROUPS) or _extract_groups(t, FORM_GROUPS))


def _candidate_passes(request_features: Dict[str, Any], product: Dict[str, Any]) -> Tuple[bool, int, str]:
    t = product_text(product)
    pf = _extract_features(t)
    req_brand = str(request_features.get("brand") or "")
    if req_brand and pf.get("brand") == req_brand:
        # requested "same product from another company"; exclude same requested brand.
        return False, 0, "same_brand"

    req_actives: set[str] = set(request_features.get("actives") or set())
    req_forms: set[str] = set(request_features.get("forms") or set())
    req_conc: set[str] = set(request_features.get("concentrations") or set())
    prod_actives: set[str] = set(pf.get("actives") or set())
    prod_forms: set[str] = set(pf.get("forms") or set())
    prod_conc: set[str] = set(pf.get("concentrations") or set())

    if req_conc and not req_conc.issubset(prod_conc):
        return False, 0, "concentration_mismatch"
    if req_actives and not req_actives.issubset(prod_actives):
        return False, 0, "active_mismatch"
    if req_forms and prod_forms and not (req_forms & prod_forms):
        return False, 0, "form_mismatch"
    if not req_actives and not (req_forms & prod_forms):
        return False, 0, "no_strict_shared_feature"

    score = 0
    score += 6 * len(req_actives & prod_actives)
    score += 3 * len(req_forms & prod_forms)
    score += 3 * len(req_conc & prod_conc)
    if pf.get("brand"):
        score += 1
    return True, score, "ok"


def candidate_pool(query: Any, *, limit: int = 60) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    features = _extract_features(query)
    if not is_cosmetic_request(query):
        return [], features
    rows: List[Tuple[int, str, Dict[str, Any]]] = []
    for p in database.load_product_rows(visible_only=True):
        if not database.product_visible(p, guided=False):
            continue
        if not _product_cosmetic(p):
            continue
        ok, score, reason = _candidate_passes(features, p)
        if ok:
            rows.append((score, str(p.get("name") or ""), p))
    rows.sort(key=lambda x: (x[0], x[1]), reverse=True)
    seen = set()
    out: List[Dict[str, Any]] = []
    for _score, _name, p in rows:
        pid = int(p.get("id") or 0)
        if not pid or pid in seen:
            continue
        seen.add(pid)
        out.append(p)
        if len(out) >= limit:
            break
    return out, features


def _safe_product_name(p: Dict[str, Any]) -> str:
    return str(p.get("name") or p.get("canonical_display_name") or p.get("original_name") or "").strip()


def _safe_price(p: Dict[str, Any]) -> str:
    for key in ["price", "sale_price", "unit_price", "public_price"]:
        v = p.get(key)
        if v not in (None, ""):
            return str(v)
    return ""


def _parse_json_object(content: str) -> Dict[str, Any]:
    content = str(content or "").strip()
    if not content:
        return {}
    content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content, flags=re.I | re.S).strip()
    try:
        data = json.loads(content)
        return data if isinstance(data, dict) else {}
    except Exception:
        m = re.search(r"\{.*\}", content, flags=re.S)
        if m:
            try:
                data = json.loads(m.group(0))
                return data if isinstance(data, dict) else {}
            except Exception:
                return {}
    return {}


async def gemini_select_alternatives(query: Any, candidates: List[Dict[str, Any]], *, client: Optional[httpx.AsyncClient] = None, max_results: int = 5, timeout: float = 12.0) -> List[int]:
    if not candidates or not config_env.resolve_openrouter_api_key():
        return []
    config_env.apply_openrouter_aliases()
    model = config_env.openrouter_gemini_model(["OPENROUTER_COSMETIC_ALT_MODEL", "OPENROUTER_TEXT_MODEL", "OPENROUTER_MODEL"])
    base_url = (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/")
    api_key = config_env.resolve_openrouter_api_key()
    items = []
    for p in candidates[: int(os.getenv("PRICEBOT_COSMETIC_ALT_GEMINI_CANDIDATES", "40") or 40)]:
        items.append({"id": int(p.get("id") or 0), "name": _safe_product_name(p), "brand": str(p.get("brand") or ""), "price": _safe_price(p)})
    prompt = (
        "You are a strict pharmacy cosmetic alternative selector. "
        "Select alternatives ONLY from the provided available candidates. "
        "This is for COSMETICS/SKINCARE only, not medicines. "
        "Rules: same cosmetic purpose/type and same key active/range when stated. "
        "If requested concentration is stated, selected alternatives must have the same concentration. "
        "Prefer a different company/brand from the requested brand. "
        "Never invent products and never select weak/general alternatives. "
        "If no strict alternatives exist, return an empty list. "
        "Return STRICT JSON only: {\"product_ids\":[ids],\"reason\":\"short\"}."
    )
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps({"requested_product": str(query), "available_candidates": items, "max_results": max_results}, ensure_ascii=False)},
        ],
        "temperature": 0,
        "max_tokens": 500,
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    own_client = None
    try:
        if client is None:
            own_client = httpx.AsyncClient(timeout=timeout)
            client = own_client
        resp = await client.post(f"{base_url}/chat/completions", headers=headers, json=payload, timeout=timeout)
        if resp.status_code >= 400:
            return []
        content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
        data = _parse_json_object(content)
        raw_ids = data.get("product_ids") or []
        allowed = {int(p.get("id") or 0) for p in candidates}
        out: List[int] = []
        for x in raw_ids:
            try:
                pid = int(x)
            except Exception:
                continue
            if pid in allowed and pid not in out:
                out.append(pid)
            if len(out) >= max_results:
                break
        return out
    except Exception:
        return []
    finally:
        if own_client is not None:
            await own_client.aclose()


def postfilter_selected(query: Any, candidates: List[Dict[str, Any]], ids: List[int], *, max_results: int = 5) -> List[Dict[str, Any]]:
    by_id = {int(p.get("id") or 0): p for p in candidates}
    features = _extract_features(query)
    out: List[Dict[str, Any]] = []
    for pid in ids:
        p = by_id.get(int(pid))
        if not p:
            continue
        ok, _score, _reason = _candidate_passes(features, p)
        if ok and database.product_visible(p, guided=False):
            out.append(p)
        if len(out) >= max_results:
            break
    return out


def health() -> Dict[str, Any]:
    return {
        "engine": ALT_ENGINE_NAME,
        "cosmetic_only": True,
        "gemini_used_only_after_customer_accepts": True,
        "strict_postfilter_enabled": True,
        "known_brands": len(COSMETIC_BRANDS),
        "active_groups": len(ACTIVE_GROUPS),
        "updated_at": int(time.time()),
    }
