from __future__ import annotations

import re
import time
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import database
from normalizer import normalize_text, split_multi

LAYER_NAME = "v16_5_safe_catalog_terms_layer"

# Known commercial brands/families. Brand-only terms must never produce a direct price.
KNOWN_BRANDS = {
    "bioderma", "cerave", "cera ve", "la roche", "la roche posay", "laroche", "cantabria", "cantabria labs",
    "biretix", "rilastil", "uriage", "avene", "vichy", "eucerin", "cetaphil", "isispharma", "isis pharma",
    "svr", "nuxe", "ducray", "babe", "bioderma", "the ordinary", "ordinary", "isis", "sesderma",
    "panadol", "advancis", "hemazym", "ferrogentle", "eutirox", "zyprexa", "amoclan", "coveram",
}

# Arabic/common aliases. These are catalog terms, not products by themselves unless combined with a variant.
AR_TO_EN = {
    "بيوديرما": "bioderma",
    "سيرافي": "cerave",
    "سيرا في": "cerave",
    "لاروش": "la roche",
    "لا روش": "la roche",
    "لاروش بوزيه": "la roche posay",
    "بيريتكس": "biretix",
    "كانتربيا": "cantabria",
    "كانتربيا لابس": "cantabria labs",
    "ريلاستيل": "rilastil",
    "زيرولاكت": "xerolact",
    "يورياج": "uriage",
    "افين": "avene",
    "اڤين": "avene",
    "فيشي": "vichy",
    "يوسرين": "eucerin",
    "سيتافيل": "cetaphil",
    "باندول": "panadol",
    "بانادول": "panadol",
    "بنادول": "panadol",
    "هيمازيم": "hemazym",
    "هيموزيم": "hemazym",
    "اوتيروكس": "eutirox",
    "يوثيروكس": "eutirox",
    "اموكلان": "amoclan",
    "اموكلين": "amoclan",
}

DROP_WORDS = {
    "السلام", "عليكم", "عليك", "مرحبا", "اهلا", "اهلاً", "اهلن", "لو", "سمحت", "سمحتي",
    "متوفر", "موجود", "عندكم", "عندك", "لديكم", "في", "الصيدليه", "الصيدلية", "صيدليه", "صيدلية",
    "نبي", "ابي", "ابى", "أبي", "نبى", "اريد", "أريد", "سعر", "كم", "شن", "بكم", "هل", "ممكن", "بالله",
    "available", "availability", "price", "have", "do", "you", "please", "pharmacy", "how", "much", "is", "the", "a", "an",
}

FORM_WORDS = {
    "tab", "tabs", "tablet", "tablets", "cap", "caps", "capsule", "capsules", "syrup", "susp", "suspension",
    "cream", "gel", "ointment", "lotion", "solution", "drop", "drops", "spray", "sachet", "powder", "oral", "serum",
    "cleanser", "wash", "foam", "fluid", "balm", "milk", "mask", "ampoule", "ampules", "oil",
    "mg", "ml", "iu", "gm", "g", "mcg", "microgram", "micrograms", "٪", "percent",
    "كريم", "جل", "مرهم", "شراب", "حبوب", "حب", "كبسول", "كبسولات", "قطره", "قطرات", "بخاخ", "محلول", "بودره", "سيروم", "غسول",
}

BLOCKED_GENERIC = {
    "دواء", "ادويه", "ادوية", "علاج", "مسكن", "مضاد", "مضاد حيوي", "دواء ضغط", "ضغط", "سكر", "صداع",
    "كريم", "مرطب", "غسول", "سيروم", "واقي", "واقي شمس", "فيتامين", "حديد", "زنك", "مغنيسيوم", "كالسيوم",
    "medicine", "drug", "painkiller", "antibiotic", "cream", "moisturizer", "cleanser", "serum", "sunscreen", "vitamin", "iron", "zinc",
}

STRENGTH_SIZE_RE = re.compile(r"\b\d+(?:[\.,]\d+)?\s*(?:mg|mcg|microgram|micrograms|g|gm|ml|iu|%)\b", re.I)
PACK_RE = re.compile(r"\b(?:x\s*\d+|\d+\s*(?:tab|tabs|tablet|tablets|cap|caps|capsule|capsules|sachets?|ampoules?))\b", re.I)


def canon(value: Any) -> str:
    q = normalize_text(value)
    for src, dst in sorted(AR_TO_EN.items(), key=lambda x: len(x[0]), reverse=True):
        q = re.sub(rf"(?<!\w){re.escape(normalize_text(src))}(?!\w)", normalize_text(dst), q)
    q = q.replace("-", " ").replace("/", " ")
    return normalize_text(q)


def compact(value: Any) -> str:
    return canon(value).replace(" ", "")


def tokens(value: Any) -> List[str]:
    return [t for t in canon(value).split() if t and t not in DROP_WORDS]


def significant_tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in tokens(value):
        if t in FORM_WORDS:
            continue
        if len(t) <= 1 and not t.isdigit():
            continue
        out.append(t)
    return out


def _term_ok(term: str) -> bool:
    term = canon(term)
    if not term or term in BLOCKED_GENERIC:
        return False
    if len(term) < 3 and not term.isdigit():
        return False
    return True


def detect_brand(name: str, existing: str = "") -> str:
    existing = canon(existing)
    if existing and existing not in BLOCKED_GENERIC:
        return existing
    n = canon(name)
    nc = n.replace(" ", "")
    best = ""
    for b in sorted(KNOWN_BRANDS, key=len, reverse=True):
        bc = b.replace(" ", "")
        if n.startswith(b + " ") or nc.startswith(bc):
            best = b
            break
    return best


def derive_family(name: str, brand: str = "", existing: str = "") -> str:
    existing = canon(existing)
    if existing and existing not in BLOCKED_GENERIC and existing != brand:
        return existing
    n = canon(name)
    brand = canon(brand)
    t = significant_tokens(n)
    if brand:
        brand_t = set(brand.split())
        t = [x for x in t if x not in brand_t]
    # First significant token after brand is usually the product line/family.
    for x in t:
        if x not in BLOCKED_GENERIC and x not in FORM_WORDS and not STRENGTH_SIZE_RE.fullmatch(x):
            return x
    return ""


def _add(terms: List[Tuple[str, str, int, str]], value: str, typ: str, weight: int, source: str) -> None:
    value = canon(value)
    if not _term_ok(value):
        return
    terms.append((value, typ, weight, source))


def build_terms_for_product(product: Dict[str, Any]) -> List[Tuple[str, str, int, str]]:
    name = str(product.get("name") or product.get("original_name") or "")
    original = str(product.get("original_name") or "")
    brand = detect_brand(name, product.get("brand") or product.get("company") or "")
    family = derive_family(name, brand, product.get("product_family") or "")
    strength = canon(product.get("strength") or "")
    size = canon(product.get("size") or "")
    form = canon(product.get("form") or product.get("product_type") or "")

    terms: List[Tuple[str, str, int, str]] = []
    clean_name = canon(name)
    _add(terms, clean_name, "exact_product", 100, "name")
    if original and canon(original) != clean_name:
        _add(terms, original, "exact_product", 95, "original_name")

    # Strong OCR phrase extraction from product name.
    sig = significant_tokens(clean_name)
    if brand:
        _add(terms, brand, "brand", 60, "brand")
    if family:
        _add(terms, family, "family", 70, "family")
        if brand:
            _add(terms, f"{brand} {family}", "family", 85, "brand_family")

    # Product-line variants: brand + first 2-4 significant tokens, and family + variant.
    if sig:
        if brand:
            brand_set = set(brand.split())
            sig_no_brand = [x for x in sig if x not in brand_set]
        else:
            sig_no_brand = sig
        for n in range(2, min(5, len(sig_no_brand) + 1)):
            phrase = " ".join(sig_no_brand[:n])
            if phrase and phrase != family:
                _add(terms, phrase, "alias", 78 + n, "derived_phrase")
                if brand:
                    _add(terms, f"{brand} {phrase}", "exact_product", 88 + n, "derived_brand_phrase")
        # If size/strength present in the visible name, make it exact-level.
        matches = STRENGTH_SIZE_RE.findall(clean_name) + PACK_RE.findall(clean_name)
        if matches and brand and sig_no_brand:
            _add(terms, f"{brand} {' '.join(sig_no_brand[:3])}", "exact_product", 92, "derived_strength_context")

    if strength and brand and family:
        _add(terms, f"{brand} {family} {strength}", "exact_product", 96, "strength")
    if size and brand and family:
        _add(terms, f"{brand} {family} {size}", "exact_product", 96, "size")
    if form and brand and family:
        _add(terms, f"{brand} {family} {form}", "alias", 82, "form")

    for key in ["aliases", "ocr_keywords", "barcode"]:
        for item in split_multi(product.get(key)):
            item_n = canon(item)
            if not _term_ok(item_n):
                continue
            typ = "exact_product" if len(significant_tokens(item_n)) >= 2 else "family"
            _add(terms, item_n, typ, 88 if typ == "exact_product" else 70, key)

    # Arabic equivalents for known brands/families.
    for ar, en in AR_TO_EN.items():
        if brand and canon(en) == brand:
            _add(terms, ar, "brand", 58, "manual_ar_brand")
            if family:
                _add(terms, f"{ar} {family}", "family", 75, "manual_ar_brand_family")
        if family and canon(en) == family:
            _add(terms, ar, "family", 68, "manual_ar_family")

    # De-duplicate for this product.
    out: List[Tuple[str, str, int, str]] = []
    seen = set()
    for term, typ, weight, source in terms:
        key = (term, typ)
        if key in seen:
            continue
        seen.add(key)
        out.append((term, typ, int(weight), source))
    return out


def ensure_schema() -> None:
    with database.connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_search_terms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                term TEXT NOT NULL DEFAULT '',
                normalized_term TEXT NOT NULL DEFAULT '',
                compact_term TEXT NOT NULL DEFAULT '',
                term_type TEXT NOT NULL DEFAULT 'alias',
                weight INTEGER DEFAULT 0,
                source TEXT DEFAULT 'auto',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id, normalized_term, term_type)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_terms_norm ON product_search_terms(normalized_term)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_terms_compact ON product_search_terms(compact_term)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_terms_product ON product_search_terms(product_db_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_search_terms_type ON product_search_terms(term_type)")


def rebuild_terms() -> Dict[str, Any]:
    ensure_schema()
    products = database.load_product_rows(visible_only=False)
    entries: List[Tuple[int, str, str, str, str, int, str]] = []
    review_needed = 0
    for p in products:
        try:
            pid = int(p.get("id") or 0)
        except Exception:
            pid = 0
        if not pid:
            continue
        terms = build_terms_for_product(p)
        if len(terms) < 2:
            review_needed += 1
        for term, typ, weight, source in terms:
            entries.append((pid, term, canon(term), compact(term), typ, int(weight), source))
    with database.connect() as conn:
        conn.execute("DELETE FROM product_search_terms")
        if entries:
            conn.executemany("""
                INSERT OR IGNORE INTO product_search_terms(product_db_id, term, normalized_term, compact_term, term_type, weight, source)
                VALUES(?,?,?,?,?,?,?)
            """, entries)
        count = int(conn.execute("SELECT COUNT(*) FROM product_search_terms").fetchone()[0])
    try:
        database.invalidate_runtime_caches()
    except Exception:
        pass
    return {"ok": True, "products_seen": len(products), "terms_count": count, "review_needed": review_needed, "layer": LAYER_NAME}


def _rows_to_products(rows: Sequence[Dict[str, Any]], products_by_id: Dict[int, Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for r in rows:
        try:
            pid = int(r.get("product_db_id") or r.get("id") or 0)
        except Exception:
            pid = 0
        if not pid or pid in seen:
            continue
        p = products_by_id.get(pid) or database.get_product(pid)
        if p and database.product_visible(p, guided=False):
            out.append(dict(p))
            seen.add(pid)
    return out


def search_exact(query: str, products_by_id: Dict[int, Dict[str, Any]], limit: int = 30) -> Dict[str, Any]:
    q = canon(query)
    if not q:
        return {"term_type": "", "products": []}
    try:
        with database.connect() as conn:
            if not database.table_exists(conn, "product_search_terms"):
                return {"term_type": "", "products": []}
            rows = [dict(r) for r in conn.execute("""
                SELECT product_db_id, term_type, weight, source, normalized_term
                FROM product_search_terms
                WHERE normalized_term=? OR compact_term=?
                ORDER BY weight DESC
                LIMIT ?
            """, (q, compact(q), int(limit) * 3)).fetchall()]
    except Exception:
        return {"term_type": "", "products": []}
    if not rows:
        return {"term_type": "", "products": []}
    # If any exact product term exists, prefer exact products. Otherwise brand/family list.
    exact_rows = [r for r in rows if str(r.get("term_type") or "") == "exact_product"]
    if exact_rows:
        return {"term_type": "exact_product", "products": _rows_to_products(exact_rows, products_by_id)[:limit], "rows": exact_rows[:limit]}
    list_rows = [r for r in rows if str(r.get("term_type") or "") in {"brand", "family", "alias"}]
    return {"term_type": str((list_rows[0] if list_rows else rows[0]).get("term_type") or "alias"), "products": _rows_to_products(list_rows or rows, products_by_id)[:limit], "rows": (list_rows or rows)[:limit]}


def load_terms_for_product(product_id: int) -> List[Dict[str, Any]]:
    try:
        with database.connect() as conn:
            if not database.table_exists(conn, "product_search_terms"):
                return []
            return [dict(r) for r in conn.execute("SELECT * FROM product_search_terms WHERE product_db_id=? ORDER BY weight DESC", (int(product_id),)).fetchall()]
    except Exception:
        return []


def health() -> Dict[str, Any]:
    try:
        with database.connect() as conn:
            exists = database.table_exists(conn, "product_search_terms")
            count = int(conn.execute("SELECT COUNT(*) FROM product_search_terms").fetchone()[0]) if exists else 0
            brand_count = int(conn.execute("SELECT COUNT(*) FROM product_search_terms WHERE term_type IN ('brand','family')").fetchone()[0]) if exists else 0
    except Exception as exc:
        return {"layer": LAYER_NAME, "enabled": False, "error": str(exc)[:180]}
    return {"layer": LAYER_NAME, "enabled": True, "terms_count": count, "brand_family_terms": brand_count, "known_brands": len(KNOWN_BRANDS), "updated_at": int(time.time())}


def _ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def search_fuzzy(query: str, products_by_id: Dict[int, Dict[str, Any]], limit: int = 30) -> Dict[str, Any]:
    """Safe fuzzy search over generated catalog terms. Never direct by itself."""
    q = canon(query)
    qc = compact(q)
    q_tokens = set(significant_tokens(q))
    if not q or q in BLOCKED_GENERIC or len(qc) < 3:
        return {"products": [], "score": 0.0, "term_type": ""}
    try:
        with database.connect() as conn:
            if not database.table_exists(conn, "product_search_terms"):
                return {"products": [], "score": 0.0, "term_type": ""}
            rows = [dict(r) for r in conn.execute("""
                SELECT product_db_id, normalized_term, compact_term, term_type, weight, source
                FROM product_search_terms
                ORDER BY weight DESC
            """).fetchall()]
    except Exception:
        return {"products": [], "score": 0.0, "term_type": ""}
    scored: List[Tuple[float, Dict[str, Any]]] = []
    for r in rows:
        term = str(r.get("normalized_term") or "")
        tc = str(r.get("compact_term") or "") or term.replace(" ", "")
        term_tokens = set(significant_tokens(term))
        score = 0.0
        if q_tokens and q_tokens.issubset(term_tokens):
            score = 0.86 + min(0.08, 0.02 * len(q_tokens))
        elif len(qc) >= 4 and len(tc) >= 4 and (qc in tc or tc in qc):
            score = 0.82 + min(0.08, 0.08 * (min(len(qc), len(tc)) / max(len(qc), len(tc))))
        elif len(qc) >= 5 and len(tc) >= 5:
            rscore = _ratio(qc, tc)
            if rscore >= 0.78:
                score = rscore
        if score >= 0.78:
            scored.append((score + min(int(r.get("weight") or 0), 100) / 10000.0, r))
    scored.sort(key=lambda x: x[0], reverse=True)
    if not scored:
        return {"products": [], "score": 0.0, "term_type": ""}
    products = _rows_to_products([r for _, r in scored], products_by_id)[:limit]
    return {"products": products, "score": float(scored[0][0]), "term_type": str(scored[0][1].get("term_type") or "alias"), "rows": [r for _, r in scored[:limit]]}
