# تقرير V16.5

## ما الذي تغير؟

تمت إضافة طبقة بحث مشتقة من المنتجات الحالية باسم:

```text
Safe Catalog Terms Layer
```

## ما الذي لم يتغير؟

- products.name لا يتم تعديله.
- products.price لا يتم تعديله.
- products.is_available لا يتم تعديله.
- لا يتم حذف المنتجات.
- لا يتم استبدال قاعدة البيانات.

## لماذا؟

لأن المشكلة الأساسية كانت ضعف أسماء Excel الخام. الحل الآمن هو توليد طبقة بحث فوق القاعدة الحالية، وليس تعديل القاعدة نفسها.

## ملفات مضافة

```text
app/catalog_terms.py
```

## ملفات معدلة

```text
app/product_identity_router.py
app/app.py
DEPLOY_V16_5_SAFE_CATALOG_TERMS_LAYER_COMMANDS.sh
```

## سياسة السعر المباشر

السعر المباشر مسموح فقط عندما يوجد تطابق exact_product واضح.

اسم brand/family مثل:

```text
Bioderma
CeraVe
La Roche
Cantabria
```

لا يعطي سعر مباشر.
