#!/usr/bin/env bash
set -euo pipefail
TARGET="${TARGET:-/opt/pricebot_clean}"
SERVICE="${SERVICE:-pricebot.service}"
LAST="$(ls -td "$TARGET"/backups/catalog_site_* 2>/dev/null | head -1 || true)"
if [ -z "$LAST" ]; then
  echo "ERROR: no catalog_site backup folder found" >&2
  exit 1
fi

echo "Using backup: $LAST"
[ -f "$LAST/app.py.bak" ] && cp -a "$LAST/app.py.bak" "$TARGET/app.py"
[ -f "$LAST/portal.py.bak" ] && cp -a "$LAST/portal.py.bak" "$TARGET/portal.py"
if [ -f "$LAST/catalog_web.py.bak" ]; then
  cp -a "$LAST/catalog_web.py.bak" "$TARGET/catalog_web.py"
else
  rm -f "$TARGET/catalog_web.py"
fi
systemctl restart "$SERVICE"
sleep 3
systemctl status "$SERVICE" --no-pager || true
echo "Rollback done."
