#!/usr/bin/env bash
set -euo pipefail

echo "===== Service status ====="
systemctl status pricebot.service --no-pager || true

echo "===== Local /health ====="
curl -s http://127.0.0.1:8090/health | head -c 1000 || true
echo

echo "===== Local /catalog-health ====="
curl -s http://127.0.0.1:8090/catalog-health || true
echo

echo "===== Local /products test ====="
curl -I http://127.0.0.1:8090/products 2>/dev/null | head || true
