from __future__ import annotations

import html
import os
import re
import sqlite3
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote, urlencode

from fastapi import APIRouter, Query
from fastapi.responses import HTMLResponse, JSONResponse

import database

router = APIRouter()

PAGE_SIZE = int(os.getenv("PRICEBOT_CATALOG_PAGE_SIZE", "24") or 24)
MAX_SEARCH_ROWS = int(os.getenv("PRICEBOT_CATALOG_MAX_SEARCH_ROWS", "500") or 500)

TEXT_COLUMNS = [
    "name",
    "canonical_display_name",
    "normalized_name",
    "normalized_name_catalog",
    "original_name",
    "product_id",
    "brand",
    "company",
    "product_family",
    "aliases",
    "ocr_keywords",
    "active_ingredient",
    "form",
    "strength",
    "size",
    "pack",
    "barcode",
    "stable_product_code",
    "category",
    "main_section",
    "sub_section",
    "sub_category",
]

IMAGE_COLUMNS = [
    "image_url",
    "photo_url",
    "product_image",
    "main_image",
    "image_path",
    "photo_path",
    "picture",
]


def _db_file() -> Path:
    raw = (
        os.getenv("PRICEBOT_DB_FILE")
        or os.getenv("PRICEBOT_DB_PATH")
        or str(getattr(database, "DB_FILE", "") or "")
        or "/opt/pricebot_clean/pricebot.db"
    )
    return Path(raw).expanduser().resolve()


def _connect() -> sqlite3.Connection:
    db_path = _db_file()
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    return conn


def _h(value: object) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def _ident(name: str) -> str:
    # Column names come from PRAGMA table_info, but still quote defensively.
    return '"' + name.replace('"', '""') + '"'


def _columns(conn: sqlite3.Connection) -> set[str]:
    try:
        rows = conn.execute("PRAGMA table_info(products)").fetchall()
        return {str(row["name"]) for row in rows}
    except Exception:
        return set()


def _first_existing(cols: set[str], candidates: Iterable[str]) -> Optional[str]:
    for col in candidates:
        if col in cols:
            return col
    return None


def _coalesce(cols: set[str], candidates: Iterable[str], fallback: str = "") -> str:
    parts = []
    for col in candidates:
        if col in cols:
            parts.append(f"NULLIF(TRIM(CAST({_ident(col)} AS TEXT)), '')")

    # SQLite COALESCE() must receive at least two arguments.
    # If no matching column exists and the fallback is empty, return a literal empty string.
    if fallback:
        parts.append("?")
    elif parts:
        parts.append("''")
    else:
        return "''"

    if len(parts) == 1:
        return parts[0]
    return "COALESCE(" + ", ".join(parts) + ")"


def _available_condition(cols: set[str]) -> str:
    checks: List[str] = []
    if "is_available" in cols:
        checks.append("LOWER(CAST(COALESCE(NULLIF(TRIM(CAST(\"is_available\" AS TEXT)), ''), '0') AS TEXT)) IN ('1','true','yes','available')")
    if "available" in cols:
        checks.append("LOWER(CAST(COALESCE(NULLIF(TRIM(CAST(\"available\" AS TEXT)), ''), '0') AS TEXT)) IN ('1','true','yes','available')")
    if not checks:
        return "1=1"
    # OR is intentional because old deployments may disagree between available and is_available.
    return "(" + " OR ".join(checks) + ")"


def _truthy(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "available", "on"}


def _select_sql(cols: set[str]) -> Tuple[str, List[object]]:
    params: List[object] = []

    def coalesce_with_param(candidates: Iterable[str], fallback: str) -> str:
        expr = _coalesce(cols, candidates, fallback)
        if fallback:
            params.append(fallback)
        return expr

    name_expr = coalesce_with_param(["canonical_display_name", "name", "original_name", "product_id"], "Product")
    category_expr = coalesce_with_param(["category", "main_section", "section", "sub_section"], "")
    brand_expr = coalesce_with_param(["brand", "company", "product_family"], "")
    image_expr = coalesce_with_param(IMAGE_COLUMNS, "")
    price_expr = _ident("price") if "price" in cols else "NULL"
    currency_expr = _ident("currency") if "currency" in cols else "'LYD'"
    available_expr = (
        _ident("is_available") if "is_available" in cols else (_ident("available") if "available" in cols else "1")
    )

    select_part = f"""
        id,
        {name_expr} AS display_name,
        {category_expr} AS category,
        {brand_expr} AS brand,
        {image_expr} AS image_url,
        {price_expr} AS price,
        {currency_expr} AS currency,
        {available_expr} AS available_value
    """
    return select_part, params


def _format_price(price: object, currency: object) -> str:
    if price is None or str(price).strip() == "":
        return "السعر غير متوفر"
    cur = str(currency or os.getenv("PRICEBOT_DEFAULT_CURRENCY", "LYD") or "LYD").strip()
    raw = str(price).replace(",", "").strip()
    try:
        value = float(raw)
        shown = str(int(value)) if value.is_integer() else f"{value:.2f}".rstrip("0").rstrip(".")
        return f"{shown} {cur}"
    except Exception:
        return f"{raw} {cur}".strip()


def _tokens(query: str) -> List[str]:
    query = (query or "").strip().lower()
    # Keep 2-char product markers such as PB and 20, reject single-letter broad scans.
    return [t for t in re.findall(r"[\w\u0600-\u06FF%+.-]+", query) if len(t) >= 2][:10]


def _score(row: Dict[str, object], tokens: List[str]) -> int:
    name = str(row.get("display_name") or "").lower()
    brand = str(row.get("brand") or "").lower()
    category = str(row.get("category") or "").lower()
    hay = " ".join(str(v or "") for v in row.values()).lower()
    score = 0
    for token in tokens:
        if token in name:
            score += 8
        if token in brand:
            score += 5
        if token in category:
            score += 2
        if token in hay:
            score += 1
    # Prefer rows where all tokens are represented when possible.
    represented = sum(1 for token in tokens if token in hay)
    score += represented * 4
    return score


def _merchant_settings() -> Dict[str, object]:
    try:
        return database.get_merchant_settings()
    except Exception:
        return {
            "name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),
            "pharmacy_name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),
            "whatsapp_number": os.getenv("BOT_WHATSAPP_NUMBER", ""),
        }


def _pharmacy_name() -> str:
    settings = _merchant_settings()
    return str(settings.get("pharmacy_name") or settings.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"))


def _whatsapp_number() -> str:
    settings = _merchant_settings()
    raw = str(
        settings.get("whatsapp_number")
        or os.getenv("WHATSAPP_PUBLIC_NUMBER")
        or os.getenv("BOT_WHATSAPP_NUMBER")
        or os.getenv("ADMIN_NOTIFY_PHONE")
        or ""
    )
    return re.sub(r"\D+", "", raw)


def _whatsapp_link(message: str) -> str:
    number = _whatsapp_number()
    if number:
        return f"https://wa.me/{number}?text={quote(message)}"
    return f"https://wa.me/?text={quote(message)}"


def _image_src(value: object) -> str:
    src = str(value or "").strip()
    if not src:
        return ""
    if src.startswith(("http://", "https://", "data:")):
        return src
    if src.startswith("/"):
        return src
    return "/static/" + src.lstrip("/")


def _categories() -> List[Dict[str, object]]:
    try:
        with _connect() as conn:
            cols = _columns(conn)
            cat_col = _first_existing(cols, ["category", "main_section", "section"])
            if not cat_col:
                return []
            rows = conn.execute(
                f"""
                SELECT {_ident(cat_col)} AS name, COUNT(*) AS count
                FROM products
                WHERE {_available_condition(cols)}
                  AND {_ident(cat_col)} IS NOT NULL
                  AND TRIM(CAST({_ident(cat_col)} AS TEXT)) != ''
                GROUP BY {_ident(cat_col)}
                ORDER BY count DESC, name COLLATE NOCASE
                LIMIT 60
                """
            ).fetchall()
            return [dict(row) for row in rows]
    except Exception:
        return []


def _query_products(q: str = "", category: str = "", page: int = 1) -> Tuple[List[Dict[str, object]], int]:
    q = (q or "").strip()
    category = (category or "").strip()
    page = max(int(page or 1), 1)
    tokens = _tokens(q)
    if q and not tokens:
        return [], 0

    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return [], 0
        select_part, select_params = _select_sql(cols)
        where = [_available_condition(cols)]
        where_params: List[object] = []

        cat_col = _first_existing(cols, ["category", "main_section", "section"])
        if category and cat_col:
            where.append(f"CAST({_ident(cat_col)} AS TEXT) = ?")
            where_params.append(category)

        search_cols = [col for col in TEXT_COLUMNS if col in cols]
        if tokens and search_cols:
            parts: List[str] = []
            for token in tokens:
                like = f"%{token}%"
                for col in search_cols:
                    parts.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                    where_params.append(like)
            where.append("(" + " OR ".join(parts) + ")")

        where_sql = " AND ".join(f"({w})" for w in where)
        if tokens:
            rows = conn.execute(
                f"SELECT {select_part} FROM products WHERE {where_sql} LIMIT ?",
                list(select_params) + where_params + [MAX_SEARCH_ROWS],
            ).fetchall()
            products = [dict(row) for row in rows]
            products.sort(key=lambda row: (-_score(row, tokens), str(row.get("display_name") or "")))
            total = len(products)
            start = (page - 1) * PAGE_SIZE
            return products[start:start + PAGE_SIZE], total

        total = int(conn.execute(f"SELECT COUNT(*) AS total FROM products WHERE {where_sql}", where_params).fetchone()["total"] or 0)
        rows = conn.execute(
            f"SELECT {select_part} FROM products WHERE {where_sql} ORDER BY id DESC LIMIT ? OFFSET ?",
            list(select_params) + where_params + [PAGE_SIZE, (page - 1) * PAGE_SIZE],
        ).fetchall()
        return [dict(row) for row in rows], total


def _get_product(product_id: int) -> Optional[Dict[str, object]]:
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return None
        select_part, params = _select_sql(cols)
        row = conn.execute(
            f"SELECT {select_part} FROM products WHERE id=? AND {_available_condition(cols)} LIMIT 1",
            params + [int(product_id)],
        ).fetchone()
        return dict(row) if row else None


def _category_chips(active: str = "") -> str:
    items = _categories()[:18]
    if not items:
        return ""
    all_cls = "chip active" if not active else "chip"
    chips = [f'<a class="{all_cls}" href="/products">الكل</a>']
    for item in items:
        name = str(item.get("name") or "")
        cls = "chip active" if name == active else "chip"
        href = "/products?" + urlencode({"category": name})
        chips.append(f'<a class="{cls}" href="{_h(href)}">{_h(name)}</a>')
    return '<div class="chips">' + ''.join(chips) + '</div>'


def _search_form(q: str = "", category: str = "") -> str:
    options = ['<option value="">كل الأقسام</option>']
    for item in _categories():
        name = str(item.get("name") or "")
        selected = " selected" if name == category else ""
        options.append(f'<option value="{_h(name)}"{selected}>{_h(name)} ({_h(item.get("count"))})</option>')
    return f"""
    <section class="search-panel">
      <form class="search" action="/products" method="get">
        <div class="search-input-wrap">
          <span class="search-icon">⌕</span>
          <input name="q" value="{_h(q)}" placeholder="ابحث عن دواء أو منتج... مثال: Panadol / CeraVe" autocomplete="off">
        </div>
        <select name="category">{''.join(options)}</select>
        <button type="submit">بحث</button>
      </form>
      {_category_chips(category)}
    </section>
    """


def _product_card(product: Dict[str, object]) -> str:
    product_id = product.get("id")
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}" loading="lazy">' if img else '<div class="no-img"><span>＋</span><small>صورة قريباً</small></div>'
    wa_msg = f"السلام عليكم، أريد طلب المنتج: {name}. السعر: {price}. رقم المنتج: {product_id}"
    wa = _whatsapp_link(wa_msg)
    meta_parts = [x for x in [brand, category] if x]
    meta = " / ".join(meta_parts) if meta_parts else "منتج صيدلية"
    return f"""
    <article class="card">
      <a class="image" href="/product/{_h(product_id)}">{img_html}</a>
      <div class="card-body">
        <a class="name" href="/product/{_h(product_id)}" dir="auto">{_h(name)}</a>
        <div class="meta" dir="auto">{_h(meta)}</div>
        <div class="card-row">
          <div class="price">{_h(price)}</div>
          <div class="badge">متوفر</div>
        </div>
        <div class="actions">
          <a class="btn secondary" href="/product/{_h(product_id)}">التفاصيل</a>
          <a class="btn" href="{_h(wa)}" target="_blank" rel="noopener">واتساب</a>
        </div>
      </div>
    </article>
    """


def _page_url(page: int, q: str = "", category: str = "") -> str:
    params = {"page": page}
    if q:
        params["q"] = q
    if category:
        params["category"] = category
    return "/products?" + urlencode(params)


def _products_section(q: str = "", category: str = "", page: int = 1) -> str:
    products, total = _query_products(q=q, category=category, page=page)
    page_count = max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    cards = "".join(_product_card(p) for p in products)
    if not cards:
        cards = '<div class="empty"><strong>لم نجد منتجات مطابقة</strong><br>جرّب كلمة أبسط مثل اسم البراند، أو اختر قسماً مختلفاً.</div>'
    prev_link = f'<a class="btn secondary" href="{_h(_page_url(page - 1, q, category))}">السابق</a>' if page > 1 else ""
    next_link = f'<a class="btn secondary" href="{_h(_page_url(page + 1, q, category))}">التالي</a>' if page < page_count else ""
    title = f'نتائج البحث عن: <span dir="auto">{_h(q)}</span>' if q else "كل المنتجات المتوفرة"
    return f"""
    {_search_form(q=q, category=category)}
    <div class="section-head">
      <div><h2>{title}</h2><p>عدد النتائج: {_h(total)} | الصفحة {_h(page)} من {_h(page_count)}</p></div>
    </div>
    <div class="grid">{cards}</div>
    <nav class="pagination">{prev_link}{next_link}</nav>
    """


def _shell(title: str, body: str) -> HTMLResponse:
    pharmacy = _pharmacy_name()
    return HTMLResponse(f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>{_h(title)} | {_h(pharmacy)}</title>
  <style>
    :root {{
      --bg:#f4f7f8; --card:#ffffff; --text:#101828; --muted:#667085; --line:#e6eaee;
      --main:#0f766e; --main2:#115e59; --accent:#10b981; --soft:#ecfdf5; --soft2:#eef2ff;
      --shadow:0 12px 30px rgba(15,23,42,.08); --radius:22px;
    }}
    * {{ box-sizing:border-box; -webkit-tap-highlight-color:transparent; }}
    body {{ margin:0; background:var(--bg); color:var(--text); font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Tahoma,Arial,sans-serif; line-height:1.55; }}
    a {{ color:inherit; text-decoration:none; }}
    .wrap {{ width:min(1180px,100%); margin:auto; padding:0 14px; }}
    .topbar {{ position:sticky; top:0; z-index:20; background:rgba(255,255,255,.94); backdrop-filter:blur(12px); border-bottom:1px solid var(--line); }}
    .topbar .wrap {{ display:flex; align-items:center; justify-content:space-between; gap:12px; padding:10px 14px; }}
    .brand {{ display:flex; align-items:center; gap:10px; min-width:0; }}
    .logo {{ width:42px; height:42px; border-radius:15px; background:linear-gradient(135deg,var(--main),var(--accent)); display:grid; place-items:center; color:white; font-weight:950; box-shadow:var(--shadow); }}
    .brand-title {{ min-width:0; }}
    .brand-title strong {{ display:block; font-size:15px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:56vw; }}
    .brand-title span {{ display:block; font-size:12px; color:var(--muted); }}
    .navlinks {{ display:flex; gap:8px; align-items:center; }}
    .navlinks a {{ color:var(--main2); background:#f0fdfa; border:1px solid #ccfbf1; padding:8px 11px; border-radius:999px; font-weight:850; font-size:13px; }}
    .hero {{ background:radial-gradient(circle at top left,rgba(16,185,129,.28),transparent 32%),linear-gradient(135deg,#0f766e,#134e4a); color:white; padding:26px 0 30px; }}
    .hero h1 {{ margin:0 0 7px; font-size:clamp(24px,5vw,38px); letter-spacing:-.02em; }}
    .hero p {{ margin:0; opacity:.92; font-size:15px; }}
    .quick {{ display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-top:18px; }}
    .quick a {{ background:rgba(255,255,255,.12); border:1px solid rgba(255,255,255,.22); color:white; border-radius:18px; padding:12px; font-weight:850; text-align:center; }}
    .search-panel {{ margin:-18px 0 18px; position:relative; z-index:3; }}
    .search {{ background:white; border:1px solid var(--line); border-radius:24px; padding:12px; display:grid; grid-template-columns:1fr 210px 105px; gap:9px; box-shadow:var(--shadow); }}
    .search-input-wrap {{ position:relative; }}
    .search-icon {{ position:absolute; inset-inline-start:12px; top:50%; transform:translateY(-50%); color:var(--muted); font-weight:900; }}
    input,select,button {{ width:100%; border:1px solid var(--line); border-radius:16px; padding:12px; font-size:15px; background:#fff; color:var(--text); }}
    input {{ padding-inline-start:36px; direction:auto; }}
    button,.btn {{ border:0; background:var(--main); color:white; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; justify-content:center; border-radius:16px; padding:10px 13px; font-weight:900; text-align:center; }}
    .btn.secondary {{ background:var(--soft2); color:#3730a3; }}
    .chips {{ display:flex; gap:8px; overflow:auto; padding:10px 2px 2px; scrollbar-width:none; }}
    .chips::-webkit-scrollbar {{ display:none; }}
    .chip {{ flex:0 0 auto; background:white; border:1px solid var(--line); color:var(--main2); border-radius:999px; padding:7px 12px; font-size:13px; font-weight:850; }}
    .chip.active {{ background:var(--main); color:white; border-color:var(--main); }}
    .section-head {{ display:flex; justify-content:space-between; align-items:end; gap:10px; flex-wrap:wrap; margin:10px 0 14px; }}
    .section-head h2 {{ margin:0; font-size:22px; letter-spacing:-.02em; }}
    .section-head p,.meta {{ color:var(--muted); margin:2px 0 0; }}
    .grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(245px,1fr)); gap:13px; }}
    .card {{ background:white; border:1px solid var(--line); border-radius:var(--radius); padding:12px; box-shadow:var(--shadow); min-width:0; display:grid; grid-template-columns:104px 1fr; gap:12px; align-items:stretch; }}
    .image {{ height:104px; border-radius:18px; background:linear-gradient(135deg,#eef2f7,#fff); border:1px dashed #d5dce7; display:flex; align-items:center; justify-content:center; overflow:hidden; text-decoration:none; }}
    .image img {{ width:100%; height:100%; object-fit:contain; background:white; }}
    .no-img {{ color:#8aa0b7; font-weight:900; text-align:center; line-height:1.2; display:grid; gap:2px; }}
    .no-img span {{ width:34px; height:34px; margin:auto; display:grid; place-items:center; border-radius:50%; background:#eef2f7; font-size:22px; color:#94a3b8; }}
    .no-img small {{ font-size:11px; }}
    .card-body {{ min-width:0; display:flex; flex-direction:column; }}
    .name {{ font-size:15px; font-weight:950; line-height:1.35; min-height:39px; max-height:42px; overflow:hidden; overflow-wrap:anywhere; }}
    .card .meta {{ font-size:12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:4px; }}
    .card-row {{ display:flex; align-items:center; justify-content:space-between; gap:8px; margin-top:8px; }}
    .price {{ color:var(--main2); font-size:17px; font-weight:950; direction:ltr; text-align:right; white-space:nowrap; }}
    .badge {{ display:inline-flex; align-items:center; background:var(--soft); color:var(--main2); border-radius:999px; padding:4px 8px; font-size:12px; font-weight:900; white-space:nowrap; }}
    .actions {{ display:grid; grid-template-columns:1fr 1fr; gap:7px; margin-top:auto; padding-top:10px; }}
    .actions .btn {{ padding:8px 9px; border-radius:13px; font-size:13px; }}
    .empty {{ background:white; border:1px solid var(--line); border-radius:22px; padding:28px; text-align:center; color:var(--muted); grid-column:1/-1; box-shadow:var(--shadow); }}
    .pagination {{ display:flex; gap:10px; justify-content:center; margin:24px 0 34px; flex-wrap:wrap; }}
    .detail {{ background:white; border:1px solid var(--line); border-radius:28px; box-shadow:var(--shadow); padding:16px; margin:22px 0; display:grid; grid-template-columns:320px 1fr; gap:22px; }}
    .detail .image {{ height:320px; margin:0; }}
    .detail h2 {{ margin:0 0 10px; font-size:26px; overflow-wrap:anywhere; }}
    .detail-actions {{ display:flex; gap:10px; flex-wrap:wrap; margin-top:18px; }}
    .footer {{ color:var(--muted); padding:28px 0 34px; font-size:13px; text-align:center; }}
    @media (max-width:760px) {{
      .wrap {{ padding:0 12px; }}
      .navlinks a:nth-child(n+3) {{ display:none; }}
      .hero {{ padding:22px 0 34px; }}
      .quick {{ grid-template-columns:1fr 1fr; }}
      .quick a:nth-child(3) {{ grid-column:1/-1; }}
      .search {{ grid-template-columns:1fr; }}
      .section-head h2 {{ font-size:19px; }}
      .grid {{ grid-template-columns:1fr; gap:10px; }}
      .card {{ grid-template-columns:96px 1fr; border-radius:20px; padding:10px; }}
      .image {{ height:96px; border-radius:16px; }}
      .name {{ font-size:15px; min-height:38px; }}
      .detail {{ grid-template-columns:1fr; }}
      .detail .image {{ height:260px; }}
      .detail-actions .btn {{ width:100%; }}
    }}
  </style>
</head>
<body>
  <header class="topbar"><div class="wrap"><a class="brand" href="/catalog"><div class="logo">Rx</div><div class="brand-title"><strong>{_h(pharmacy)}</strong><span>كتالوج المنتجات</span></div></a><nav class="navlinks"><a href="/products">المنتجات</a><a href="/catalog">بحث</a><a href="/merchant">التاجر</a><a href="/portal">النظام</a></nav></div></header>
  <section class="hero"><div class="wrap"><h1>كتالوج الصيدلية</h1><p>ابحث عن المنتج، راجع السعر والتوفر، ثم اطلبه مباشرة عبر واتساب.</p><div class="quick"><a href="/products">كل المنتجات</a><a href="/products?q=Panadol">Panadol</a><a href="/products?q=CeraVe">CeraVe</a></div></div></section>
  <main class="wrap">{body}<div class="footer">PriceBot Catalog — متصل بقاعدة المنتجات الحالية.</div></main>
</body>
</html>""")

@router.get("/", response_class=HTMLResponse)
@router.get("/catalog", response_class=HTMLResponse)
def catalog_home() -> HTMLResponse:
    body = f"""
    {_search_form()}
    <div class="section-head"><h2>منتجات مضافة حديثاً</h2><p>الصور الافتراضية ستُستبدل لاحقاً من لوحة التاجر.</p></div>
    <div class="grid">{''.join(_product_card(p) for p in _query_products(page=1)[0][:12])}</div>
    """
    return _shell("كتالوج المنتجات", body)


@router.get("/products", response_class=HTMLResponse)
def products_page(
    q: str = Query("", max_length=140),
    category: str = Query("", max_length=160),
    page: int = Query(1, ge=1),
) -> HTMLResponse:
    return _shell("المنتجات", _products_section(q=q, category=category, page=page))


@router.get("/product/{product_id}", response_class=HTMLResponse)
def product_detail(product_id: int) -> HTMLResponse:
    product = _get_product(product_id)
    if not product:
        return _shell("المنتج غير موجود", '<div class="empty">المنتج غير موجود أو غير متاح حالياً.</div>')
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}">' if img else '<div class="no-img">No image<br>available</div>'
    wa_msg = f"السلام عليكم، أريد طلب المنتج: {name}. السعر: {price}. رقم المنتج: {product_id}"
    body = f"""
    <section class="detail">
      <div class="image">{img_html}</div>
      <div>
        <h2 dir="auto">{_h(name)}</h2>
        <div class="price">{_h(price)}</div>
        <div class="badge">متوفر</div>
        <p class="meta">رقم المنتج: {_h(product_id)}</p>
        <p class="meta">القسم: {_h(category) if category else 'غير محدد'}</p>
        <p class="meta">البراند: {_h(brand) if brand else 'غير محدد'}</p>
        <br>
        <a class="btn" href="{_h(_whatsapp_link(wa_msg))}" target="_blank" rel="noopener">اطلب عبر واتساب</a>
        <a class="btn secondary" href="/products" style="margin-inline-start:8px">رجوع للمنتجات</a>
      </div>
    </section>
    """
    return _shell(name, body)


@router.get("/catalog-health")
def catalog_health() -> JSONResponse:
    try:
        with _connect() as conn:
            cols = _columns(conn)
            total = int(conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"] or 0)
            available = int(conn.execute(f"SELECT COUNT(*) AS c FROM products WHERE {_available_condition(cols)}").fetchone()["c"] or 0)
        return JSONResponse({
            "ok": True,
            "service": "pricebot_catalog",
            "db_path": str(_db_file()),
            "readonly": True,
            "products_count": total,
            "available_count": available,
            "page_size": PAGE_SIZE,
        })
    except Exception as exc:
        return JSONResponse({
            "ok": False,
            "service": "pricebot_catalog",
            "db_path": str(_db_file()),
            "error": repr(exc),
        }, status_code=500)
