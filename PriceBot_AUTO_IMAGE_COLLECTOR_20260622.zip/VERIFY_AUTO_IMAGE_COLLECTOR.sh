#!/usr/bin/env bash
set -euo pipefail
cd /opt/pricebot_clean

echo "===== Service ====="
sudo systemctl status pricebot.service --no-pager -l | head -n 25 || true

echo "===== Catalog health ====="
curl -s http://127.0.0.1:8090/catalog-health || true

echo "\n===== Candidate table ====="
sqlite3 pricebot.db "SELECT status, COUNT(*) FROM catalog_image_candidates GROUP BY status;" 2>/dev/null || echo "No candidate table"

echo "\n===== Candidate files ====="
ls -lah static/catalog_image_candidates 2>/dev/null | head -n 20 || echo "No candidate image folder"

echo "\nOpen: https://46.101.148.246.sslip.io/merchant/auto-images"
