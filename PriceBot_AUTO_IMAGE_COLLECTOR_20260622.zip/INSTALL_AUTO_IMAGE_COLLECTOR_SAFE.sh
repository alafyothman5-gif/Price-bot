#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$APP_DIR/backups/auto-image-collector-$(date +%F_%H-%M-%S)"

echo "===== Backup current catalog files/database ====="
mkdir -p "$BACKUP_DIR"
cd "$APP_DIR"
cp -a catalog_web.py "$BACKUP_DIR/catalog_web.py" 2>/dev/null || true
cp -a pricebot.db "$BACKUP_DIR/pricebot.db"
mkdir -p "$BACKUP_DIR/static"
cp -a static/catalog_images "$BACKUP_DIR/static/catalog_images" 2>/dev/null || true
cp -a static/catalog_image_candidates "$BACKUP_DIR/static/catalog_image_candidates" 2>/dev/null || true

echo "===== Check Python syntax ====="
python3 -m py_compile "$SCRIPT_DIR/catalog_web.py"

echo "===== Install auto image collector ====="
mkdir -p "$APP_DIR/static/catalog_images" "$APP_DIR/static/catalog_image_candidates"
cp -a "$SCRIPT_DIR/catalog_web.py" "$APP_DIR/catalog_web.py"

echo "===== Ensure database columns/tables ====="
python3 - <<'PY'
import sqlite3
from pathlib import Path
app = Path('/opt/pricebot_clean')
db = app / 'pricebot.db'
conn = sqlite3.connect(str(db), timeout=20)
try:
    cols = {row[1] for row in conn.execute('PRAGMA table_info(products)').fetchall()}
    if 'catalog_image_url' not in cols:
        conn.execute('ALTER TABLE products ADD COLUMN catalog_image_url TEXT')
        print('Added column: catalog_image_url')
    else:
        print('Column exists: catalog_image_url')
    conn.execute("""CREATE TABLE IF NOT EXISTS catalog_image_candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        product_name TEXT,
        source_query TEXT,
        source_url TEXT,
        local_url TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        source_provider TEXT NOT NULL DEFAULT 'duckduckgo',
        created_at TEXT NOT NULL,
        approved_at TEXT,
        note TEXT
    )""")
    conn.execute('CREATE INDEX IF NOT EXISTS idx_catalog_image_candidates_product_status ON catalog_image_candidates(product_id, status)')
    conn.commit()
    print('Table ready: catalog_image_candidates')
finally:
    conn.close()
PY

echo "===== Restart PriceBot only ====="
sudo systemctl restart pricebot.service
sleep 8

echo "===== Health ====="
curl -s http://127.0.0.1:8090/catalog-health || true

echo ""
echo "DONE. Open: https://46.101.148.246.sslip.io/merchant/auto-images"
echo "Review: https://46.101.148.246.sslip.io/merchant/auto-images/candidates"
echo "Backup saved to: $BACKUP_DIR"
