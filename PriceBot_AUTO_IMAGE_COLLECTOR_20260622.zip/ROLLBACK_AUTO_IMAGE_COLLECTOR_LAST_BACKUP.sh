#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
cd "$APP_DIR"
LAST_BACKUP="$(ls -td backups/auto-image-collector-* 2>/dev/null | head -n 1 || true)"
if [ -z "$LAST_BACKUP" ]; then
  echo "No auto-image-collector backup found"
  exit 1
fi

echo "Restoring catalog_web.py from: $LAST_BACKUP"
cp -a "$LAST_BACKUP/catalog_web.py" "$APP_DIR/catalog_web.py" 2>/dev/null || true
sudo systemctl restart pricebot.service
sleep 8
curl -s http://127.0.0.1:8090/catalog-health || true
