#!/usr/bin/env bash
set -euo pipefail
curl -i http://127.0.0.1:8090/catalog-health
curl -I http://127.0.0.1:8090/contact || true
curl -I http://127.0.0.1:8090/products || true
