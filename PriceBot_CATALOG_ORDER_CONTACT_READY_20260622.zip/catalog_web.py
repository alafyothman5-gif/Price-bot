from __future__ import annotations

import datetime
import html
import json
import os
import re
import shutil
import sqlite3
import uuid
import urllib.request
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote, urlencode

from fastapi import APIRouter, Query, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, PlainTextResponse

import database

router = APIRouter()

PAGE_SIZE = int(os.getenv("PRICEBOT_CATALOG_PAGE_SIZE", "24") or 24)
MAX_SEARCH_ROWS = int(os.getenv("PRICEBOT_CATALOG_MAX_SEARCH_ROWS", "500") or 500)

TEXT_COLUMNS = [
    "name",
    "canonical_display_name",
    "normalized_name",
    "normalized_name_catalog",
    "original_name",
    "product_id",
    "brand",
    "company",
    "product_family",
    "aliases",
    "ocr_keywords",
    "active_ingredient",
    "form",
    "strength",
    "size",
    "pack",
    "barcode",
    "stable_product_code",
    "category",
    "main_section",
    "sub_section",
    "sub_category",
]

IMAGE_COLUMNS = [
    "catalog_image_url",
    "image_url",
    "photo_url",
    "product_image",
    "main_image",
    "image_path",
    "photo_path",
    "picture",
]


def _db_file() -> Path:
    raw = (
        os.getenv("PRICEBOT_DB_FILE")
        or os.getenv("PRICEBOT_DB_PATH")
        or str(getattr(database, "DB_FILE", "") or "")
        or "/opt/pricebot_clean/pricebot.db"
    )
    return Path(raw).expanduser().resolve()


def _connect() -> sqlite3.Connection:
    db_path = _db_file()
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    return conn


def _connect_rw() -> sqlite3.Connection:
    db_path = _db_file()
    conn = sqlite3.connect(str(db_path), timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=10000")
    return conn


def _ensure_image_schema() -> None:
    with _connect_rw() as conn:
        cols = _columns(conn)
        if "catalog_image_url" not in cols:
            conn.execute("ALTER TABLE products ADD COLUMN catalog_image_url TEXT")
            conn.commit()



def _h(value: object) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def _ident(name: str) -> str:
    # Column names come from PRAGMA table_info, but still quote defensively.
    return '"' + name.replace('"', '""') + '"'


def _columns(conn: sqlite3.Connection) -> set[str]:
    try:
        rows = conn.execute("PRAGMA table_info(products)").fetchall()
        return {str(row["name"]) for row in rows}
    except Exception:
        return set()


def _first_existing(cols: set[str], candidates: Iterable[str]) -> Optional[str]:
    for col in candidates:
        if col in cols:
            return col
    return None


def _coalesce(cols: set[str], candidates: Iterable[str], fallback: str = "") -> str:
    parts = []
    for col in candidates:
        if col in cols:
            parts.append(f"NULLIF(TRIM(CAST({_ident(col)} AS TEXT)), '')")

    # SQLite COALESCE() must receive at least two arguments.
    # If no matching column exists and the fallback is empty, return a literal empty string.
    if fallback:
        parts.append("?")
    elif parts:
        parts.append("''")
    else:
        return "''"

    if len(parts) == 1:
        return parts[0]
    return "COALESCE(" + ", ".join(parts) + ")"


def _available_condition(cols: set[str]) -> str:
    checks: List[str] = []
    if "is_available" in cols:
        checks.append("LOWER(CAST(COALESCE(NULLIF(TRIM(CAST(\"is_available\" AS TEXT)), ''), '0') AS TEXT)) IN ('1','true','yes','available')")
    if "available" in cols:
        checks.append("LOWER(CAST(COALESCE(NULLIF(TRIM(CAST(\"available\" AS TEXT)), ''), '0') AS TEXT)) IN ('1','true','yes','available')")
    if not checks:
        return "1=1"
    # OR is intentional because old deployments may disagree between available and is_available.
    return "(" + " OR ".join(checks) + ")"


def _truthy(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "available", "on"}


def _select_sql(cols: set[str]) -> Tuple[str, List[object]]:
    params: List[object] = []

    def coalesce_with_param(candidates: Iterable[str], fallback: str) -> str:
        expr = _coalesce(cols, candidates, fallback)
        if fallback:
            params.append(fallback)
        return expr

    name_expr = coalesce_with_param(["canonical_display_name", "name", "original_name", "product_id"], "Product")
    category_expr = coalesce_with_param(["category", "main_section", "section", "sub_section"], "")
    brand_expr = coalesce_with_param(["brand", "company", "product_family"], "")
    image_expr = coalesce_with_param(IMAGE_COLUMNS, "")
    price_expr = _ident("price") if "price" in cols else "NULL"
    currency_expr = _ident("currency") if "currency" in cols else "'LYD'"
    available_expr = (
        _ident("is_available") if "is_available" in cols else (_ident("available") if "available" in cols else "1")
    )

    select_part = f"""
        id,
        {name_expr} AS display_name,
        {category_expr} AS category,
        {brand_expr} AS brand,
        {image_expr} AS image_url,
        {price_expr} AS price,
        {currency_expr} AS currency,
        {available_expr} AS available_value
    """
    return select_part, params


def _format_price(price: object, currency: object) -> str:
    if price is None or str(price).strip() == "":
        return "السعر غير متوفر"
    cur = str(currency or os.getenv("PRICEBOT_DEFAULT_CURRENCY", "LYD") or "LYD").strip()
    raw = str(price).replace(",", "").strip()
    try:
        value = float(raw)
        shown = str(int(value)) if value.is_integer() else f"{value:.2f}".rstrip("0").rstrip(".")
        return f"{shown} {cur}"
    except Exception:
        return f"{raw} {cur}".strip()


def _tokens(query: str) -> List[str]:
    query = (query or "").strip().lower()
    # Keep 2-char product markers such as PB and 20, reject single-letter broad scans.
    return [t for t in re.findall(r"[\w\u0600-\u06FF%+.-]+", query) if len(t) >= 2][:10]


def _score(row: Dict[str, object], tokens: List[str]) -> int:
    name = str(row.get("display_name") or "").lower()
    brand = str(row.get("brand") or "").lower()
    category = str(row.get("category") or "").lower()
    hay = " ".join(str(v or "") for v in row.values()).lower()
    score = 0
    for token in tokens:
        if token in name:
            score += 8
        if token in brand:
            score += 5
        if token in category:
            score += 2
        if token in hay:
            score += 1
    # Prefer rows where all tokens are represented when possible.
    represented = sum(1 for token in tokens if token in hay)
    score += represented * 4
    return score


def _merchant_settings() -> Dict[str, object]:
    try:
        return database.get_merchant_settings()
    except Exception:
        return {
            "name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),
            "pharmacy_name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),
            "whatsapp_number": os.getenv("BOT_WHATSAPP_NUMBER", ""),
        }


def _pharmacy_name() -> str:
    settings = _merchant_settings()
    return str(settings.get("pharmacy_name") or settings.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"))


def _whatsapp_number() -> str:
    settings = _merchant_settings()
    raw = str(
        settings.get("whatsapp_number")
        or os.getenv("WHATSAPP_PUBLIC_NUMBER")
        or os.getenv("BOT_WHATSAPP_NUMBER")
        or os.getenv("ADMIN_NOTIFY_PHONE")
        or ""
    )
    return re.sub(r"\D+", "", raw)


def _whatsapp_link(message: str) -> str:
    number = _whatsapp_number()
    if number:
        return f"https://wa.me/{number}?text={quote(message)}"
    return f"https://wa.me/?text={quote(message)}"


def _public_base_url() -> str:
    raw = (
        os.getenv("PUBLIC_BASE_URL")
        or os.getenv("PRICEBOT_PUBLIC_BASE_URL")
        or os.getenv("APP_PUBLIC_URL")
        or "https://46.101.148.246.sslip.io"
    )
    return str(raw).rstrip("/")


def _product_url(product_id: object) -> str:
    return f"{_public_base_url()}/product/{product_id}"


def _order_message(product: Dict[str, object]) -> str:
    product_id = product.get("id")
    name = str(product.get("display_name") or "Product").strip()
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    parts = [
        "السلام عليكم، أريد طلب هذا المنتج:",
        f"المنتج: {name}",
        f"السعر الظاهر: {price}",
        f"رقم المنتج: {product_id}",
    ]
    if brand:
        parts.append(f"البراند: {brand}")
    if category:
        parts.append(f"القسم: {category}")
    parts.extend([
        f"رابط المنتج: {_product_url(product_id)}",
        "يرجى تأكيد التوفر والسعر النهائي."
    ])
    return "\n".join(parts)


def _image_src(value: object) -> str:
    src = str(value or "").strip()
    if not src:
        return ""
    if src.startswith(("http://", "https://", "data:")):
        return src
    if src.startswith("/"):
        return src
    return "/static/" + src.lstrip("/")


def _categories() -> List[Dict[str, object]]:
    try:
        with _connect() as conn:
            cols = _columns(conn)
            cat_col = _first_existing(cols, ["category", "main_section", "section"])
            if not cat_col:
                return []
            rows = conn.execute(
                f"""
                SELECT {_ident(cat_col)} AS name, COUNT(*) AS count
                FROM products
                WHERE {_available_condition(cols)}
                  AND {_ident(cat_col)} IS NOT NULL
                  AND TRIM(CAST({_ident(cat_col)} AS TEXT)) != ''
                GROUP BY {_ident(cat_col)}
                ORDER BY count DESC, name COLLATE NOCASE
                LIMIT 60
                """
            ).fetchall()
            return [dict(row) for row in rows]
    except Exception:
        return []


def _query_products(q: str = "", category: str = "", page: int = 1) -> Tuple[List[Dict[str, object]], int]:
    q = (q or "").strip()
    category = (category or "").strip()
    page = max(int(page or 1), 1)
    tokens = _tokens(q)
    if q and not tokens:
        return [], 0

    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return [], 0
        select_part, select_params = _select_sql(cols)
        where = [_available_condition(cols)]
        where_params: List[object] = []

        cat_col = _first_existing(cols, ["category", "main_section", "section"])
        if category and cat_col:
            where.append(f"CAST({_ident(cat_col)} AS TEXT) = ?")
            where_params.append(category)

        search_cols = [col for col in TEXT_COLUMNS if col in cols]
        if tokens and search_cols:
            parts: List[str] = []
            for token in tokens:
                like = f"%{token}%"
                for col in search_cols:
                    parts.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                    where_params.append(like)
            where.append("(" + " OR ".join(parts) + ")")

        where_sql = " AND ".join(f"({w})" for w in where)
        if tokens:
            rows = conn.execute(
                f"SELECT {select_part} FROM products WHERE {where_sql} LIMIT ?",
                list(select_params) + where_params + [MAX_SEARCH_ROWS],
            ).fetchall()
            products = [dict(row) for row in rows]
            products.sort(key=lambda row: (-_score(row, tokens), str(row.get("display_name") or "")))
            total = len(products)
            start = (page - 1) * PAGE_SIZE
            return products[start:start + PAGE_SIZE], total

        total = int(conn.execute(f"SELECT COUNT(*) AS total FROM products WHERE {where_sql}", where_params).fetchone()["total"] or 0)
        rows = conn.execute(
            f"SELECT {select_part} FROM products WHERE {where_sql} ORDER BY id DESC LIMIT ? OFFSET ?",
            list(select_params) + where_params + [PAGE_SIZE, (page - 1) * PAGE_SIZE],
        ).fetchall()
        return [dict(row) for row in rows], total


def _get_product(product_id: int) -> Optional[Dict[str, object]]:
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return None
        select_part, params = _select_sql(cols)
        row = conn.execute(
            f"SELECT {select_part} FROM products WHERE id=? AND {_available_condition(cols)} LIMIT 1",
            params + [int(product_id)],
        ).fetchone()
        return dict(row) if row else None



def _category_chips(active: str = "") -> str:
    items = _categories()[:16]
    if not items:
        return ""
    all_cls = "chip active" if not active else "chip"
    chips = [f'<a class="{all_cls}" href="/products">الكل</a>']
    for item in items:
        name = str(item.get("name") or "")
        cls = "chip active" if name == active else "chip"
        href = "/products?" + urlencode({"category": name})
        chips.append(f'<a class="{cls}" href="{_h(href)}" dir="auto">{_h(name)}</a>')
    return '<div class="chips" aria-label="الأقسام">' + ''.join(chips) + '</div>'


def _search_form(q: str = "", category: str = "", compact: bool = False) -> str:
    options = ['<option value="">كل الأقسام</option>']
    for item in _categories():
        name = str(item.get("name") or "")
        selected = " selected" if name == category else ""
        options.append(f'<option value="{_h(name)}"{selected}>{_h(name)} ({_h(item.get("count"))})</option>')
    cls = "search-panel compact" if compact else "search-panel"
    return f"""
    <section class="{cls}">
      <form class="search" action="/products" method="get">
        <div class="search-input-wrap">
          <span class="search-icon">⌕</span>
          <input name="q" value="{_h(q)}" placeholder="ابحث عن المنتجات... Panadol / CeraVe" autocomplete="off" dir="auto">
        </div>
        <select name="category">{''.join(options)}</select>
        <button type="submit">بحث</button>
      </form>
    </section>
    """


def _category_icon(name: str) -> str:
    n = (name or "").lower()
    if any(x in n for x in ["cosmetic", "skin", "beauty", "تجميل", "بشرة"]):
        return "✦"
    if any(x in n for x in ["medicine", "drug", "دواء", "ادوية", "أدوية"]):
        return "Rx"
    if any(x in n for x in ["supplement", "vitamin", "فيتامين", "مكمل"]):
        return "◎"
    return "▦"


def _category_tiles(limit: int = 6) -> str:
    cats = _categories()[:limit]
    if not cats:
        return ""
    tiles = []
    for item in cats:
        name = str(item.get("name") or "")
        count = item.get("count") or ""
        href = "/products?" + urlencode({"category": name})
        tiles.append(f"""
        <a class="cat-tile" href="{_h(href)}">
          <span class="cat-icon">{_h(_category_icon(name))}</span>
          <strong dir="auto">{_h(name)}</strong>
          <small>{_h(count)} منتج</small>
        </a>
        """)
    return '<section class="cat-grid">' + ''.join(tiles) + '</section>'


def _product_card(product: Dict[str, object], mode: str = "list") -> str:
    product_id = product.get("id")
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}" loading="lazy">' if img else '<div class="no-img"><span>＋</span><small>صورة قريباً</small></div>'
    meta_parts = [x for x in [brand, category] if x]
    meta = " / ".join(meta_parts) if meta_parts else "منتج صيدلية"
    cls = "card tile-card" if mode == "tile" else "card"
    return f"""
    <article class="{cls}">
      <a class="image" href="/product/{_h(product_id)}">{img_html}</a>
      <div class="card-body">
        <a class="name" href="/product/{_h(product_id)}" dir="auto">{_h(name)}</a>
        <div class="meta" dir="auto">{_h(meta)}</div>
        <div class="card-row">
          <div class="price">{_h(price)}</div>
          <div class="badge">متوفر</div>
        </div>
        <div class="actions">
          <a class="btn secondary" href="/product/{_h(product_id)}">التفاصيل</a>
          <a class="btn" href="/order/{_h(product_id)}" target="_blank" rel="noopener">اطلب</a>
        </div>
      </div>
    </article>
    """


def _page_url(page: int, q: str = "", category: str = "") -> str:
    params = {"page": page}
    if q:
        params["q"] = q
    if category:
        params["category"] = category
    return "/products?" + urlencode(params)


def _products_section(q: str = "", category: str = "", page: int = 1) -> str:
    products, total = _query_products(q=q, category=category, page=page)
    page_count = max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    cards = "".join(_product_card(p) for p in products)
    if not cards:
        cards = '<div class="empty"><strong>لم نجد منتجات مطابقة</strong><br>جرّب كلمة أبسط مثل اسم البراند، أو اختر قسماً مختلفاً.</div>'
    prev_link = f'<a class="btn secondary" href="{_h(_page_url(page - 1, q, category))}">السابق</a>' if page > 1 else ""
    next_link = f'<a class="btn secondary" href="{_h(_page_url(page + 1, q, category))}">التالي</a>' if page < page_count else ""
    title = f'نتائج البحث عن: <span dir="auto">{_h(q)}</span>' if q else "كل المنتجات المتوفرة"
    return f"""
    {_search_form(q=q, category=category)}
    {_category_chips(category)}
    <div class="section-head">
      <div><h2>{title}</h2><p>عدد النتائج: {_h(total)} | الصفحة {_h(page)} من {_h(page_count)}</p></div>
    </div>
    <div class="grid product-list">{cards}</div>
    <nav class="pagination">{prev_link}{next_link}</nav>
    """


def _bottom_nav(active: str = "home") -> str:
    def item(key: str, href: str, icon: str, label: str) -> str:
        cls = "active" if active == key else ""
        return f'<a class="{cls}" href="{href}"><span>{icon}</span><small>{label}</small></a>'
    return '<nav class="bottom-nav">' + ''.join([
        item("home", "/catalog", "⌂", "الرئيسية"),
        item("products", "/products", "▦", "المنتجات"),
        item("whatsapp", _whatsapp_link("السلام عليكم، أريد الاستفسار عن منتجات الصيدلية."), "☏", "واتساب"),
        item("offers", "/products?category=cosmetic", "✦", "العروض"),
        item("contact", "/contact", "○", "تواصل"),
    ]) + '</nav>'


def _shell(title: str, body: str, active: str = "home", show_hero: bool = False) -> HTMLResponse:
    pharmacy = _pharmacy_name()
    hero_html = ""
    if show_hero:
        hero_html = f"""
        <section class="app-hero">
          <div class="hero-banner">
            <div>
              <strong>كتالوج الصيدلية</strong>
              <span>ابحث، راجع السعر والتوفر، ثم اطلب عبر واتساب.</span>
            </div>
            <b>Rx</b>
          </div>
          <div class="quick-row">
            <a href="/products?q=Panadol">Panadol</a>
            <a href="/products">كل المنتجات</a>
            <a href="/products?q=CeraVe">CeraVe</a>
          </div>
        </section>
        """
    return HTMLResponse(f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>{_h(title)} | {_h(pharmacy)}</title>
  <style>
    :root {{
      --bg:#f7f8fa; --card:#ffffff; --text:#111827; --muted:#6b7280; --line:#e5e7eb;
      --main:#0f766e; --main2:#0d5f59; --accent:#14b8a6; --soft:#ecfdf5; --soft2:#eef2ff;
      --purple:#7c3aed; --pink:#b8329c; --shadow:0 12px 28px rgba(15,23,42,.09); --radius:24px;
    }}
    * {{ box-sizing:border-box; -webkit-tap-highlight-color:transparent; }}
    body {{ margin:0; background:var(--bg); color:var(--text); font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Tahoma,Arial,sans-serif; line-height:1.55; padding-bottom:76px; }}
    a {{ color:inherit; text-decoration:none; }}
    .wrap {{ width:min(1120px,100%); margin:auto; padding:0 14px; }}

    .app-header {{ position:sticky; top:0; z-index:50; background:#fff; border-bottom:1px solid var(--line); box-shadow:0 4px 16px rgba(0,0,0,.03); }}
    .app-header-inner {{ height:78px; display:grid; grid-template-columns:1fr auto 1fr; align-items:center; gap:10px; padding:0 14px; }}
    .header-side {{ display:flex; align-items:center; gap:12px; }}
    .header-side.left {{ justify-content:flex-start; }}
    .header-side.right {{ justify-content:flex-end; }}
    .icon-btn {{ width:42px; height:42px; border:1px solid #eee; background:#fff; border-radius:16px; display:grid; place-items:center; color:var(--main2); font-weight:900; box-shadow:0 6px 16px rgba(0,0,0,.04); position:relative; }}
    .cart-count {{ position:absolute; top:-7px; right:-5px; min-width:20px; height:20px; border-radius:999px; display:grid; place-items:center; background:#ef4444; color:white; font-size:11px; font-weight:900; }}
    .language {{ color:#111827; font-weight:850; font-size:14px; }}
    .brand-logo {{ display:flex; flex-direction:column; align-items:center; line-height:1; }}
    .brand-logo .rx {{ width:70px; height:46px; border-radius:18px; background:linear-gradient(135deg,var(--main),var(--accent)); color:white; display:grid; place-items:center; font-size:24px; font-weight:950; box-shadow:var(--shadow); }}
    .brand-logo small {{ color:var(--muted); margin-top:6px; font-size:11px; white-space:nowrap; }}

    .app-hero {{ background:linear-gradient(180deg,#fff 0,#fff 42%,transparent 42%); padding:18px 0 0; }}
    .hero-banner {{ min-height:150px; border-radius:28px; padding:22px; background:radial-gradient(circle at 10% 15%,rgba(255,255,255,.28),transparent 30%),linear-gradient(135deg,var(--main),#11423f); color:white; display:flex; align-items:center; justify-content:space-between; gap:18px; overflow:hidden; box-shadow:var(--shadow); }}
    .hero-banner strong {{ display:block; font-size:27px; margin-bottom:8px; }}
    .hero-banner span {{ display:block; font-size:15px; opacity:.92; }}
    .hero-banner b {{ width:96px; height:96px; border-radius:30px; background:rgba(255,255,255,.16); display:grid; place-items:center; font-size:38px; box-shadow:inset 0 0 0 1px rgba(255,255,255,.24); }}
    .quick-row {{ display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:14px; }}
    .quick-row a {{ background:rgba(255,255,255,.15); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,.24); color:white; background-color:rgba(15,118,110,.82); border-radius:22px; min-height:60px; display:grid; place-items:center; font-size:18px; font-weight:950; box-shadow:0 10px 24px rgba(15,118,110,.18); }}
    .quick-row a:nth-child(3) {{ grid-column:1/-1; }}

    .search-panel {{ margin:18px 0 14px; }}
    .search-panel.compact {{ margin:14px 0; }}
    .search {{ background:white; border:1px solid var(--line); border-radius:28px; padding:12px; display:grid; grid-template-columns:1fr 210px 105px; gap:10px; box-shadow:var(--shadow); }}
    .search-input-wrap {{ position:relative; }}
    .search-icon {{ position:absolute; inset-inline-start:15px; top:50%; transform:translateY(-50%); color:var(--main2); font-size:22px; font-weight:900; }}
    input,select,button {{ width:100%; border:1px solid var(--line); border-radius:19px; padding:13px; font-size:16px; background:#fff; color:var(--text); }}
    input {{ padding-inline-start:48px; direction:auto; }}
    button,.btn {{ border:0; background:var(--main); color:white; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; border-radius:18px; padding:11px 14px; font-weight:950; text-align:center; }}
    .btn.secondary {{ background:var(--soft2); color:#3730a3; }}

    .cat-grid {{ display:grid; grid-template-columns:repeat(2,1fr); gap:12px; margin:24px 0 18px; }}
    .cat-tile {{ min-height:128px; border-radius:26px; padding:16px; color:white; background:linear-gradient(135deg,#8b5cf6,#c084fc); display:flex; flex-direction:column; justify-content:space-between; box-shadow:var(--shadow); overflow:hidden; position:relative; }}
    .cat-tile:nth-child(2n) {{ background:linear-gradient(135deg,#0f766e,#2dd4bf); }}
    .cat-tile:nth-child(3n) {{ background:linear-gradient(135deg,#2563eb,#60a5fa); }}
    .cat-tile:nth-child(4n) {{ background:linear-gradient(135deg,#be185d,#f472b6); }}
    .cat-tile:after {{ content:""; position:absolute; width:120px; height:120px; border-radius:35px; background:rgba(255,255,255,.16); inset-inline-end:-35px; bottom:-35px; transform:rotate(18deg); }}
    .cat-icon {{ width:46px; height:46px; border-radius:17px; background:rgba(255,255,255,.23); display:grid; place-items:center; font-weight:950; font-size:20px; z-index:1; }}
    .cat-tile strong {{ font-size:18px; z-index:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
    .cat-tile small {{ opacity:.9; z-index:1; }}

    .chips {{ display:flex; gap:9px; overflow:auto; padding:8px 2px 12px; scrollbar-width:none; }}
    .chips::-webkit-scrollbar {{ display:none; }}
    .chip {{ flex:0 0 auto; background:white; border:1px solid var(--line); color:var(--main2); border-radius:999px; padding:9px 14px; font-size:14px; font-weight:900; box-shadow:0 5px 14px rgba(0,0,0,.04); }}
    .chip.active {{ background:var(--main); color:white; border-color:var(--main); }}

    .section-head {{ display:flex; justify-content:space-between; align-items:end; gap:10px; flex-wrap:wrap; margin:22px 0 14px; }}
    .section-head h2 {{ margin:0; font-size:23px; letter-spacing:-.02em; }}
    .section-head p,.meta {{ color:var(--muted); margin:4px 0 0; }}
    .grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(245px,1fr)); gap:13px; }}
    .grid.home-grid {{ grid-template-columns:repeat(2,minmax(0,1fr)); }}
    .card {{ background:white; border:1px solid var(--line); border-radius:26px; padding:12px; box-shadow:var(--shadow); min-width:0; display:grid; grid-template-columns:104px 1fr; gap:12px; align-items:stretch; }}
    .tile-card {{ grid-template-columns:1fr; padding:10px; }}
    .image {{ height:104px; border-radius:20px; background:linear-gradient(135deg,#f1f5f9,#fff); border:1px dashed #d5dce7; display:flex; align-items:center; justify-content:center; overflow:hidden; text-decoration:none; }}
    .tile-card .image {{ height:118px; }}
    .image img {{ width:100%; height:100%; object-fit:contain; background:white; }}
    .no-img {{ color:#8aa0b7; font-weight:900; text-align:center; line-height:1.25; display:grid; gap:3px; }}
    .no-img span {{ width:38px; height:38px; margin:auto; display:grid; place-items:center; border-radius:50%; background:#eef2f7; font-size:25px; color:#94a3b8; }}
    .no-img small {{ font-size:11px; }}
    .card-body {{ min-width:0; display:flex; flex-direction:column; }}
    .name {{ font-size:15px; font-weight:950; line-height:1.35; min-height:39px; max-height:42px; overflow:hidden; overflow-wrap:anywhere; }}
    .card .meta {{ font-size:12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:4px; }}
    .card-row {{ display:flex; align-items:center; justify-content:space-between; gap:8px; margin-top:8px; }}
    .price {{ color:var(--main2); font-size:18px; font-weight:950; direction:ltr; text-align:right; white-space:nowrap; }}
    .badge {{ display:inline-flex; align-items:center; background:var(--soft); color:var(--main2); border-radius:999px; padding:4px 8px; font-size:12px; font-weight:900; white-space:nowrap; }}
    .actions {{ display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:auto; padding-top:10px; }}
    .actions .btn {{ padding:9px 8px; border-radius:15px; font-size:13px; }}
    .empty {{ background:white; border:1px solid var(--line); border-radius:24px; padding:28px; text-align:center; color:var(--muted); grid-column:1/-1; box-shadow:var(--shadow); }}
    .pagination {{ display:flex; gap:10px; justify-content:center; margin:24px 0 34px; flex-wrap:wrap; }}

    .detail {{ background:white; border:1px solid var(--line); border-radius:30px; box-shadow:var(--shadow); padding:16px; margin:20px 0; display:grid; grid-template-columns:320px 1fr; gap:22px; }}
    .detail .image {{ height:320px; margin:0; }}
    .detail h2 {{ margin:0 0 10px; font-size:26px; overflow-wrap:anywhere; }}
    .detail-actions {{ display:flex; gap:10px; flex-wrap:wrap; margin-top:18px; }}
    .order-note {{ margin-top:14px; padding:12px 14px; border-radius:18px; background:#fffbeb; color:#92400e; border:1px solid #fde68a; font-weight:800; }}
    .info-list {{ display:grid; gap:8px; margin:14px 0; }}
    .info-list p {{ margin:0; background:#f8fafc; border:1px solid var(--line); border-radius:14px; padding:10px 12px; color:#475569; }}
    .contact-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:12px; margin:18px 0; }}
    .contact-card {{ background:white; border:1px solid var(--line); border-radius:24px; padding:18px; box-shadow:var(--shadow); }}
    .contact-card strong {{ display:block; font-size:18px; margin-bottom:6px; }}
    .contact-card p {{ color:var(--muted); margin:0 0 12px; }}
    .customer-notice {{ background:#eff6ff; border:1px solid #bfdbfe; color:#1e40af; border-radius:18px; padding:12px 14px; margin-top:14px; font-weight:800; }}
    .footer {{ color:var(--muted); padding:26px 0 34px; font-size:13px; text-align:center; }}

    .bottom-nav {{ position:fixed; z-index:60; bottom:0; left:0; right:0; height:70px; background:linear-gradient(135deg,var(--main),var(--main2)); display:grid; grid-template-columns:repeat(5,1fr); box-shadow:0 -10px 28px rgba(0,0,0,.16); padding-bottom:env(safe-area-inset-bottom); }}
    .bottom-nav a {{ color:rgba(255,255,255,.82); display:flex; flex-direction:column; align-items:center; justify-content:center; gap:3px; font-weight:850; }}
    .bottom-nav a span {{ font-size:22px; line-height:1; }}
    .bottom-nav a small {{ font-size:12px; }}
    .bottom-nav a.active {{ color:white; }}

    @media (max-width:760px) {{
      .wrap {{ padding:0 12px; }}
      .app-header-inner {{ height:78px; }}
      .language {{ font-size:13px; }}
      .icon-btn {{ width:39px; height:39px; border-radius:15px; }}
      .brand-logo .rx {{ width:64px; height:42px; font-size:22px; }}
      .hero-banner {{ min-height:138px; border-radius:24px; }}
      .hero-banner strong {{ font-size:24px; }}
      .hero-banner b {{ width:76px; height:76px; font-size:30px; }}
      .search {{ grid-template-columns:1fr; border-radius:25px; }}
      .cat-grid {{ grid-template-columns:repeat(2,1fr); gap:11px; }}
      .cat-tile {{ min-height:118px; }}
      .section-head h2 {{ font-size:21px; }}
      .grid {{ grid-template-columns:1fr; gap:10px; }}
      .grid.home-grid {{ grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; }}
      .card {{ grid-template-columns:96px 1fr; border-radius:22px; padding:10px; }}
      .tile-card {{ grid-template-columns:1fr; }}
      .image {{ height:96px; border-radius:18px; }}
      .tile-card .image {{ height:105px; }}
      .tile-card .actions {{ grid-template-columns:1fr; }}
      .tile-card .btn.secondary {{ display:none; }}
      .name {{ font-size:14px; min-height:38px; }}
      .detail {{ grid-template-columns:1fr; }}
      .detail .image {{ height:260px; }}
      .detail-actions .btn {{ width:100%; }}
    }}
  </style>
</head>
<body>
  <header class="app-header">
    <div class="app-header-inner">
      <div class="header-side right">
        <span class="language">العربية</span>
        <a class="icon-btn" href="{_h(_whatsapp_link('السلام عليكم، أريد الاستفسار عن طلب من الصيدلية.'))}">☏</a>
        <a class="icon-btn" href="/contact">○</a>
      </div>
      <a class="brand-logo" href="/catalog"><span class="rx">Rx</span><small>{_h(pharmacy)}</small></a>
      <div class="header-side left">
        <a class="icon-btn" href="/products">⌕</a>
      </div>
    </div>
  </header>
  <main class="wrap">{hero_html}{body}<div class="footer">الأسعار والتوفر حسب آخر تحديث من الصيدلية، ويتم تأكيد الطلب عبر واتساب.</div></main>
  {_bottom_nav(active)}
</body>
</html>""")

@router.get("/", response_class=HTMLResponse)
@router.get("/catalog", response_class=HTMLResponse)
def catalog_home() -> HTMLResponse:
    products = _query_products(page=1)[0][:10]
    body = f"""
    {_search_form(compact=True)}
    {_category_tiles(4)}
    <div class="section-head"><div><h2>منتجات مضافة حديثاً</h2><p>الصور الافتراضية ستُستبدل لاحقاً من لوحة التاجر.</p></div></div>
    <div class="grid home-grid">{''.join(_product_card(p, mode='tile') for p in products)}</div>
    """
    return _shell("كتالوج المنتجات", body, active="home", show_hero=True)


@router.get("/products", response_class=HTMLResponse)
def products_page(
    q: str = Query("", max_length=140),
    category: str = Query("", max_length=160),
    page: int = Query(1, ge=1),
) -> HTMLResponse:
    return _shell("المنتجات", _products_section(q=q, category=category, page=page), active="products")


@router.get("/product/{product_id}", response_class=HTMLResponse)
def product_detail(product_id: int) -> HTMLResponse:
    product = _get_product(product_id)
    if not product:
        return _shell("المنتج غير موجود", '<div class="empty">المنتج غير موجود أو غير متاح حالياً.</div>', active="products")
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}">' if img else '<div class="no-img"><span>＋</span><small>صورة قريباً</small></div>'
    body = f"""
    <section class="detail">
      <div class="image">{img_html}</div>
      <div>
        <h2 dir="auto">{_h(name)}</h2>
        <div class="price">{_h(price)}</div>
        <br><div class="badge">متوفر</div>
        <div class="info-list">
          <p>رقم المنتج: <b>{_h(product_id)}</b></p>
          <p>القسم: <b>{_h(category) if category else 'غير محدد'}</b></p>
          <p>البراند: <b>{_h(brand) if brand else 'غير محدد'}</b></p>
        </div>
        <div class="order-note">سيتم تأكيد السعر والتوفر النهائي عبر واتساب قبل تجهيز الطلب.</div>
        <div class="detail-actions">
          <a class="btn" href="/order/{_h(product_id)}" target="_blank" rel="noopener">اطلب عبر واتساب</a>
          <a class="btn secondary" href="/products">رجوع للمنتجات</a>
        </div>
      </div>
    </section>
    """
    return _shell(name, body, active="products")


@router.get("/order/{product_id}")
def order_product(product_id: int):
    product = _get_product(product_id)
    if not product:
        return RedirectResponse(_whatsapp_link(f"السلام عليكم، أريد الاستفسار عن منتج رقم {product_id}، لكنه غير ظاهر كمُتاح في الموقع."), status_code=302)
    return RedirectResponse(_whatsapp_link(_order_message(product)), status_code=302)


@router.get("/contact", response_class=HTMLResponse)
def contact_page() -> HTMLResponse:
    pharmacy = _pharmacy_name()
    wa = _whatsapp_link("السلام عليكم، أريد التواصل مع الصيدلية.")
    body = f"""
    <section class="contact-card">
      <h2>تواصل مع {_h(pharmacy)}</h2>
      <p>للطلبات والاستفسارات، استخدم واتساب. الأسعار والتوفر يتم تأكيدهما قبل تجهيز الطلب.</p>
      <div class="detail-actions">
        <a class="btn" href="{_h(wa)}" target="_blank" rel="noopener">فتح واتساب</a>
        <a class="btn secondary" href="/products">تصفح المنتجات</a>
      </div>
      <div class="customer-notice">هذا الموقع كتالوج عرض وطلب عبر واتساب، وليس بوابة دفع إلكتروني حالياً.</div>
    </section>
    <div class="contact-grid">
      <div class="contact-card"><strong>طريقة الطلب</strong><p>ابحث عن المنتج، افتح التفاصيل، ثم اضغط اطلب عبر واتساب.</p></div>
      <div class="contact-card"><strong>التوفر</strong><p>حالة التوفر مبنية على آخر ملف منتجات مرفوع من الصيدلية.</p></div>
      <div class="contact-card"><strong>التأكيد</strong><p>يتم تأكيد السعر والتوفر النهائيين داخل محادثة واتساب.</p></div>
    </div>
    """
    return _shell("تواصل معنا", body, active="contact")




def _merchant_auth_response(request: Request):
    try:
        from merchant import _require_auth  # type: ignore
        return _require_auth(request)
    except Exception as exc:
        return PlainTextResponse(f"Merchant auth unavailable: {exc!r}", status_code=503)


def _merchant_csrf_token(request: Request) -> str:
    try:
        from merchant import _csrf_token  # type: ignore
        return _csrf_token(request)
    except Exception:
        return ""


def _merchant_csrf_response(request: Request, token: str):
    try:
        from merchant import _require_csrf  # type: ignore
        return _require_csrf(request, token)
    except Exception as exc:
        return PlainTextResponse(f"CSRF auth unavailable: {exc!r}", status_code=503)


def _image_admin_query(q: str = "", missing: str = "", page: int = 1) -> Tuple[List[Dict[str, object]], int]:
    _ensure_image_schema()
    page = max(int(page or 1), 1)
    q = (q or "").strip()
    missing = (missing or "").strip()
    tokens = _tokens(q)
    page_size = 18
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return [], 0
        select_part, select_params = _select_sql(cols)
        image_expr = _coalesce(cols, IMAGE_COLUMNS, "")
        where = [_available_condition(cols)]
        params: List[object] = []
        if missing == "1":
            where.append(f"TRIM(CAST(({image_expr}) AS TEXT)) = ''")
        if tokens:
            search_cols = [col for col in TEXT_COLUMNS if col in cols]
            if search_cols:
                parts: List[str] = []
                for token in tokens:
                    like = f"%{token}%"
                    for col in search_cols:
                        parts.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                        params.append(like)
                where.append("(" + " OR ".join(parts) + ")")
        where_sql = " AND ".join(f"({w})" for w in where)
        total = int(conn.execute(f"SELECT COUNT(*) AS total FROM products WHERE {where_sql}", params).fetchone()["total"] or 0)
        rows = conn.execute(
            f"SELECT {select_part} FROM products WHERE {where_sql} ORDER BY id DESC LIMIT ? OFFSET ?",
            list(select_params) + params + [page_size, (page - 1) * page_size],
        ).fetchall()
        return [dict(r) for r in rows], total


def _image_admin_card(product: Dict[str, object], csrf_token: str, q: str = "", missing: str = "") -> str:
    pid = int(product.get("id") or 0)
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}" loading="lazy">' if img else '<div class="no-img"><span>＋</span><small>لا توجد صورة</small></div>'
    back_q = _h(q)
    back_missing = _h(missing)
    delete_form = ""
    if img:
        delete_form = (
            f'<form method="post" action="/merchant/catalog-images/delete" class="mini-form" onsubmit="return confirm(\'حذف صورة هذا المنتج؟\')">'
            f'<input type="hidden" name="csrf_token" value="{_h(csrf_token)}">'
            f'<input type="hidden" name="product_id" value="{pid}">'
            f'<input type="hidden" name="q" value="{back_q}">'
            f'<input type="hidden" name="missing" value="{back_missing}">'
            f'<button class="danger" type="submit">حذف الصورة</button>'
            f'</form>'
        )
    return f'''
    <article class="image-admin-card" id="product-{pid}">
      <div class="image admin-img">{img_html}</div>
      <div class="admin-info">
        <strong dir="auto">{_h(name)}</strong>
        <small>#{pid} — {_h(category or 'بدون قسم')} — {_h(price)}</small>
        <a class="btn secondary admin-view-link" href="/product/{pid}?v=img" target="_blank" rel="noopener">عرض في الكتالوج</a>
        <form method="post" action="/merchant/catalog-images/upload" enctype="multipart/form-data" class="upload-form">
          <input type="hidden" name="csrf_token" value="{_h(csrf_token)}">
          <input type="hidden" name="product_id" value="{pid}">
          <input type="hidden" name="q" value="{back_q}">
          <input type="hidden" name="missing" value="{back_missing}">
          <input type="file" name="image" accept="image/png,image/jpeg,image/webp" required>
          <button type="submit">رفع / تغيير الصورة</button>
        </form>
        {delete_form}
      </div>
    </article>
    '''


def _safe_static_image_path(url: str) -> Optional[Path]:
    url = (url or "").strip()
    prefix = "/static/catalog_images/"
    if not url.startswith(prefix):
        return None
    name = url[len(prefix):]
    if "/" in name or "\\" in name or not name:
        return None
    return (Path.cwd() / "static" / "catalog_images" / name).resolve()


@router.get("/merchant/catalog-images", response_class=HTMLResponse)
def merchant_catalog_images(
    request: Request,
    q: str = Query("", max_length=140),
    missing: str = Query("1"),
    page: int = Query(1, ge=1),
    updated: str = Query(""),
) -> HTMLResponse:
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    products, total = _image_admin_query(q=q, missing=missing, page=page)
    csrf_token = _merchant_csrf_token(request)
    page_size = 18
    page_count = max((total + page_size - 1) // page_size, 1)
    cards = "".join(_image_admin_card(p, csrf_token, q=q, missing=missing) for p in products) or '<div class="empty">لا توجد منتجات مطابقة.</div>'
    notice = '<div class="success-notice">تم حفظ الصورة. إذا كانت صفحة الكتالوج مفتوحة سابقاً، افتح المنتج من زر عرض في الكتالوج أو حدّث الصفحة.</div>' if updated else ''
    missing_selected = " selected" if missing == "1" else ""
    all_selected = " selected" if missing != "1" else ""
    prev_link = f'<a class="btn secondary" href="/merchant/catalog-images?q={_h(q)}&missing={_h(missing)}&page={page-1}">السابق</a>' if page > 1 else ""
    next_link = f'<a class="btn secondary" href="/merchant/catalog-images?q={_h(q)}&missing={_h(missing)}&page={page+1}">التالي</a>' if page < page_count else ""
    body = f'''
    <style>
      .image-admin-head {{ background:white; border:1px solid var(--line); border-radius:28px; box-shadow:var(--shadow); padding:18px; margin:18px 0; }}
      .image-admin-head h2 {{ margin:0 0 6px; font-size:24px; }}
      .image-admin-head p {{ margin:0; color:var(--muted); }}
      .image-admin-grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(290px,1fr)); gap:12px; }}
      .image-admin-card {{ background:white; border:1px solid var(--line); border-radius:24px; padding:12px; box-shadow:var(--shadow); display:grid; grid-template-columns:100px 1fr; gap:12px; }}
      .admin-img {{ width:100px; height:100px; }}
      .admin-info strong {{ display:block; font-size:15px; line-height:1.35; max-height:42px; overflow:hidden; }}
      .admin-info small {{ display:block; color:var(--muted); margin:4px 0 8px; }}
      .upload-form,.mini-form {{ display:grid; gap:7px; }}
      .upload-form input[type=file] {{ padding:8px; font-size:13px; }}
      .upload-form button,.mini-form button {{ padding:9px; border-radius:14px; font-size:13px; }}
      .admin-view-link {{ margin:0 0 8px; width:100%; min-height:34px; font-size:13px; }}
      .success-notice {{ background:#ecfdf5; color:#065f46; border:1px solid #bbf7d0; border-radius:18px; padding:12px 14px; margin:12px 0; font-weight:850; }}
      .danger {{ background:#fee2e2 !important; color:#991b1b !important; }}
      @media (max-width:760px) {{ .image-admin-grid {{ grid-template-columns:1fr; }} }}
    </style>
    <section class="image-admin-head">
      <h2>إدارة صور المنتجات</h2>
      <p>ارفع صورة للمنتج، وستظهر مباشرة في الكتالوج وصفحة التفاصيل. الملفات المقبولة: JPG / PNG / WEBP.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <a class="btn" href="/merchant/auto-images">جلب صور تلقائي</a>
        <a class="btn secondary" href="/merchant/auto-images/candidates">مراجعة الصور المقترحة</a>
      </div>
    </section>
    <section class="search-panel compact">
      <form class="search" action="/merchant/catalog-images" method="get">
        <div class="search-input-wrap"><span class="search-icon">⌕</span><input name="q" value="{_h(q)}" placeholder="ابحث عن منتج لإضافة صورة..." dir="auto"></div>
        <select name="missing"><option value="1"{missing_selected}>بدون صور فقط</option><option value="0"{all_selected}>كل المنتجات</option></select>
        <button type="submit">بحث</button>
      </form>
    </section>
    <div class="section-head"><div><h2>المنتجات</h2><p>عدد النتائج: {_h(total)} | الصفحة {_h(page)} من {_h(page_count)}</p></div></div>
    {notice}
    <div class="image-admin-grid">{cards}</div>
    <nav class="pagination">{prev_link}{next_link}</nav>
    '''
    return _shell("إدارة صور المنتجات", body, active="account")


@router.post("/merchant/catalog-images/upload")
def merchant_catalog_image_upload(
    request: Request,
    product_id: int = Form(...),
    csrf_token: str = Form(""),
    q: str = Form(""),
    missing: str = Form("1"),
    image: UploadFile = File(...),
):
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    csrf_resp = _merchant_csrf_response(request, csrf_token)
    if csrf_resp:
        return csrf_resp
    _ensure_image_schema()
    content_type = (image.content_type or "").lower()
    suffix = Path(image.filename or "").suffix.lower().strip(".")
    if content_type == "image/jpeg":
        ext = "jpg"
    elif content_type == "image/png":
        ext = "png"
    elif content_type == "image/webp":
        ext = "webp"
    elif suffix in {"jpg", "jpeg", "png", "webp"}:
        ext = "jpg" if suffix == "jpeg" else suffix
    else:
        return PlainTextResponse("نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WEBP.", status_code=400)
    max_bytes = int(os.getenv("PRICEBOT_CATALOG_IMAGE_MAX_BYTES", "5242880") or 5242880)
    data = image.file.read(max_bytes + 1)
    if len(data) > max_bytes:
        return PlainTextResponse("حجم الصورة أكبر من الحد المسموح 5MB.", status_code=400)
    if not data:
        return PlainTextResponse("الصورة فارغة.", status_code=400)
    base_dir = Path.cwd() / "static" / "catalog_images"
    base_dir.mkdir(parents=True, exist_ok=True)
    filename = f"p{int(product_id)}_{uuid.uuid4().hex[:10]}.{ext}"
    target = base_dir / filename
    target.write_bytes(data)
    new_url = f"/static/catalog_images/{filename}"
    old_path = None
    with _connect_rw() as conn:
        cols = _columns(conn)
        if "catalog_image_url" not in cols:
            conn.execute("ALTER TABLE products ADD COLUMN catalog_image_url TEXT")
        row = conn.execute("SELECT catalog_image_url FROM products WHERE id=?", (int(product_id),)).fetchone()
        if not row:
            try:
                target.unlink()
            except Exception:
                pass
            return PlainTextResponse("المنتج غير موجود.", status_code=404)
        old_path = _safe_static_image_path(row["catalog_image_url"] or "")
        conn.execute("UPDATE products SET catalog_image_url=? WHERE id=?", (new_url, int(product_id)))
        conn.commit()
    if old_path and old_path.exists():
        try:
            old_path.unlink()
        except Exception:
            pass
    return RedirectResponse(f"/merchant/catalog-images?q={quote(q)}&missing=0&updated=1#product-{int(product_id)}", status_code=303)


@router.post("/merchant/catalog-images/delete")
def merchant_catalog_image_delete(
    request: Request,
    product_id: int = Form(...),
    csrf_token: str = Form(""),
    q: str = Form(""),
    missing: str = Form("1"),
):
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    csrf_resp = _merchant_csrf_response(request, csrf_token)
    if csrf_resp:
        return csrf_resp
    _ensure_image_schema()
    old_path = None
    with _connect_rw() as conn:
        row = conn.execute("SELECT catalog_image_url FROM products WHERE id=?", (int(product_id),)).fetchone()
        if row:
            old_path = _safe_static_image_path(row["catalog_image_url"] or "")
            conn.execute("UPDATE products SET catalog_image_url=NULL WHERE id=?", (int(product_id),))
            conn.commit()
    if old_path and old_path.exists():
        try:
            old_path.unlink()
        except Exception:
            pass
    return RedirectResponse(f"/merchant/catalog-images?q={quote(q)}&missing={quote(missing)}&updated=deleted", status_code=303)

# ---------------------------------------------------------------------------
# Auto Image Collector
# ---------------------------------------------------------------------------

CANDIDATE_COLUMNS_SQL = """
CREATE TABLE IF NOT EXISTS catalog_image_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    product_name TEXT,
    source_query TEXT,
    source_url TEXT,
    local_url TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    source_provider TEXT NOT NULL DEFAULT 'duckduckgo',
    created_at TEXT NOT NULL,
    approved_at TEXT,
    note TEXT
)
"""


def _utc_now() -> str:
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _ensure_auto_image_schema() -> None:
    _ensure_image_schema()
    with _connect_rw() as conn:
        conn.execute(CANDIDATE_COLUMNS_SQL)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_image_candidates_product_status ON catalog_image_candidates(product_id, status)")
        conn.commit()


def _candidate_base_dir() -> Path:
    base = Path.cwd() / "static" / "catalog_image_candidates"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _final_image_base_dir() -> Path:
    base = Path.cwd() / "static" / "catalog_images"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _safe_candidate_image_path(url: str) -> Optional[Path]:
    url = (url or "").strip()
    prefix = "/static/catalog_image_candidates/"
    if not url.startswith(prefix):
        return None
    name = url[len(prefix):]
    if "/" in name or "\\" in name or not name:
        return None
    return (Path.cwd() / "static" / "catalog_image_candidates" / name).resolve()


def _auto_image_query_from_product(product: Dict[str, object]) -> str:
    name = str(product.get("display_name") or "").strip()
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    parts: List[str] = []
    if brand and brand.lower() not in name.lower():
        parts.append(brand)
    parts.append(name)
    parts.append("product packshot")
    if category.lower() in {"cosmetic", "medicine", "supplement"}:
        parts.append(category)
    q = " ".join(x for x in parts if x).strip()
    return re.sub(r"\s+", " ", q)[:180]


def _auto_missing_products(q: str = "", category: str = "", limit: int = 10) -> List[Dict[str, object]]:
    q = (q or "").strip()
    category = (category or "").strip()
    limit = max(1, min(int(limit or 10), 50))
    tokens = _tokens(q)
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return []
        select_part, select_params = _select_sql(cols)
        image_expr = _coalesce(cols, IMAGE_COLUMNS, "")
        where = [_available_condition(cols), f"TRIM(CAST(({image_expr}) AS TEXT)) = ''"]
        params: List[object] = []
        cat_col = _first_existing(cols, ["category", "main_section", "section"])
        if category and cat_col:
            where.append(f"CAST({_ident(cat_col)} AS TEXT) = ?")
            params.append(category)
        if tokens:
            search_cols = [col for col in TEXT_COLUMNS if col in cols]
            parts: List[str] = []
            for token in tokens:
                like = f"%{token}%"
                for col in search_cols:
                    parts.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                    params.append(like)
            if parts:
                where.append("(" + " OR ".join(parts) + ")")
        where_sql = " AND ".join(f"({w})" for w in where)
        rows = conn.execute(
            f"SELECT {select_part} FROM products WHERE {where_sql} ORDER BY id DESC LIMIT ?",
            list(select_params) + params + [limit],
        ).fetchall()
        return [dict(row) for row in rows]


def _candidate_count_for_product(product_id: int) -> int:
    _ensure_auto_image_schema()
    with _connect() as conn:
        return int(conn.execute(
            "SELECT COUNT(*) AS c FROM catalog_image_candidates WHERE product_id=? AND status IN ('pending','approved')",
            (int(product_id),),
        ).fetchone()["c"] or 0)


def _duckduckgo_vqd(query: str) -> str:
    url = "https://duckduckgo.com/?" + urlencode({"q": query, "iax": "images", "ia": "images"})
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 PriceBotCatalog/1.0"})
    with urllib.request.urlopen(req, timeout=12) as resp:
        text = resp.read(250000).decode("utf-8", "ignore")
    patterns = [
        r"vqd=['\"]([^'\"]+)['\"]",
        r"vqd=([0-9-]+)&",
        r"'vqd':'([^']+)'",
    ]
    for pat in patterns:
        m = re.search(pat, text)
        if m:
            return m.group(1)
    raise RuntimeError("DuckDuckGo image token was not found")


def _duckduckgo_image_urls(query: str, limit: int = 8) -> List[str]:
    limit = max(1, min(int(limit or 8), 20))
    vqd = _duckduckgo_vqd(query)
    url = "https://duckduckgo.com/i.js?" + urlencode({
        "l": "us-en",
        "o": "json",
        "q": query,
        "vqd": vqd,
        "f": ",,,,,",
        "p": "1",
    })
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 PriceBotCatalog/1.0",
        "Referer": "https://duckduckgo.com/",
    })
    with urllib.request.urlopen(req, timeout=15) as resp:
        payload = json.loads(resp.read(1200000).decode("utf-8", "ignore"))
    urls: List[str] = []
    for item in payload.get("results", []) or []:
        img = str(item.get("image") or item.get("thumbnail") or "").strip()
        if img.startswith(("http://", "https://")) and img not in urls:
            urls.append(img)
        if len(urls) >= limit:
            break
    return urls


def _guess_image_ext(content_type: str, url: str) -> str:
    ct = (content_type or "").lower()
    if "png" in ct:
        return "png"
    if "webp" in ct:
        return "webp"
    if "jpeg" in ct or "jpg" in ct:
        return "jpg"
    suffix = Path(url.split("?", 1)[0]).suffix.lower().strip(".")
    if suffix in {"jpg", "jpeg", "png", "webp"}:
        return "jpg" if suffix == "jpeg" else suffix
    return "jpg"


def _download_candidate_image(product_id: int, source_url: str, index: int = 0) -> Optional[str]:
    source_url = (source_url or "").strip()
    if not source_url.startswith(("http://", "https://")):
        return None
    max_bytes = int(os.getenv("PRICEBOT_AUTO_IMAGE_MAX_BYTES", "3145728") or 3145728)
    req = urllib.request.Request(source_url, headers={
        "User-Agent": "Mozilla/5.0 PriceBotCatalog/1.0",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    })
    with urllib.request.urlopen(req, timeout=15) as resp:
        content_type = str(resp.headers.get("Content-Type") or "")
        if "image" not in content_type.lower():
            return None
        data = resp.read(max_bytes + 1)
    if not data or len(data) > max_bytes:
        return None
    ext = _guess_image_ext(content_type, source_url)
    filename = f"cand_p{int(product_id)}_{uuid.uuid4().hex[:10]}_{int(index)}.{ext}"
    target = _candidate_base_dir() / filename
    target.write_bytes(data)
    return f"/static/catalog_image_candidates/{filename}"


def _insert_candidate(product: Dict[str, object], source_query: str, source_url: str, local_url: str) -> int:
    _ensure_auto_image_schema()
    with _connect_rw() as conn:
        cur = conn.execute(
            """
            INSERT INTO catalog_image_candidates
            (product_id, product_name, source_query, source_url, local_url, status, source_provider, created_at)
            VALUES (?, ?, ?, ?, ?, 'pending', 'duckduckgo', ?)
            """,
            (int(product.get("id") or 0), str(product.get("display_name") or ""), source_query, source_url, local_url, _utc_now()),
        )
        conn.commit()
        return int(cur.lastrowid)


def _fetch_candidates_for_product(product: Dict[str, object], per_product: int = 3) -> Dict[str, object]:
    pid = int(product.get("id") or 0)
    if not pid:
        return {"product_id": pid, "created": 0, "error": "missing product id"}
    if _candidate_count_for_product(pid) >= per_product:
        return {"product_id": pid, "created": 0, "skipped": "already has candidates"}
    query = _auto_image_query_from_product(product)
    created = 0
    errors: List[str] = []
    try:
        urls = _duckduckgo_image_urls(query, limit=max(per_product * 4, 8))
    except Exception as exc:
        return {"product_id": pid, "created": 0, "error": repr(exc), "query": query}
    seen = set()
    for idx, url in enumerate(urls):
        if url in seen:
            continue
        seen.add(url)
        try:
            local = _download_candidate_image(pid, url, idx)
            if not local:
                continue
            _insert_candidate(product, query, url, local)
            created += 1
            if created >= per_product:
                break
        except Exception as exc:
            errors.append(type(exc).__name__)
            continue
    return {"product_id": pid, "created": created, "query": query, "errors": errors[:3]}


def _candidate_rows(status: str = "pending", q: str = "", limit: int = 80) -> List[sqlite3.Row]:
    _ensure_auto_image_schema()
    status = (status or "pending").strip().lower()
    if status not in {"pending", "approved", "rejected", "all"}:
        status = "pending"
    q = (q or "").strip().lower()
    limit = max(1, min(int(limit or 80), 200))
    where: List[str] = []
    params: List[object] = []
    if status != "all":
        where.append("c.status=?")
        params.append(status)
    if q:
        where.append("LOWER(COALESCE(c.product_name,'')) LIKE ?")
        params.append(f"%{q}%")
    where_sql = "WHERE " + " AND ".join(where) if where else ""
    with _connect() as conn:
        return conn.execute(
            f"""
            SELECT c.*, p.catalog_image_url AS current_image
            FROM catalog_image_candidates c
            LEFT JOIN products p ON p.id=c.product_id
            {where_sql}
            ORDER BY c.id DESC
            LIMIT ?
            """,
            params + [limit],
        ).fetchall()


def _candidate_card(row: sqlite3.Row, csrf_token: str) -> str:
    cid = int(row["id"])
    pid = int(row["product_id"])
    name = str(row["product_name"] or f"Product #{pid}")
    local = _image_src(row["local_url"])
    source_q = str(row["source_query"] or "")
    current = _image_src(row["current_image"] or "")
    current_html = f'<img src="{_h(current)}" alt="current" loading="lazy">' if current else '<div class="no-img"><span>＋</span><small>لا توجد صورة حالية</small></div>'
    return f'''
    <article class="candidate-card">
      <div class="candidate-images">
        <div><small>الصورة المقترحة</small><img src="{_h(local)}" alt="{_h(name)}" loading="lazy"></div>
        <div><small>الصورة الحالية</small>{current_html}</div>
      </div>
      <div class="candidate-info">
        <strong dir="auto">{_h(name)}</strong>
        <small>رقم المنتج: {pid}</small>
        <small dir="auto">بحث: {_h(source_q)}</small>
        <div class="candidate-actions">
          <form method="post" action="/merchant/auto-images/approve">
            <input type="hidden" name="csrf_token" value="{_h(csrf_token)}">
            <input type="hidden" name="candidate_id" value="{cid}">
            <button type="submit">اعتماد الصورة</button>
          </form>
          <form method="post" action="/merchant/auto-images/reject">
            <input type="hidden" name="csrf_token" value="{_h(csrf_token)}">
            <input type="hidden" name="candidate_id" value="{cid}">
            <button class="danger" type="submit">رفض</button>
          </form>
          <a class="btn secondary" href="/product/{pid}?v=auto" target="_blank" rel="noopener">عرض المنتج</a>
        </div>
      </div>
    </article>
    '''


@router.get("/merchant/auto-images", response_class=HTMLResponse)
def merchant_auto_images(request: Request, q: str = Query("", max_length=140), category: str = Query(""), limit: int = Query(10, ge=1, le=50)) -> HTMLResponse:
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    csrf_token = _merchant_csrf_token(request)
    categories = _categories()
    options = ['<option value="">كل الأقسام</option>']
    for item in categories:
        name = str(item.get("name") or "")
        selected = " selected" if name == category else ""
        options.append(f'<option value="{_h(name)}"{selected}>{_h(name)} ({_h(item.get("count"))})</option>')
    sample = _auto_missing_products(q=q, category=category, limit=min(limit, 12))
    sample_html = "".join(f'<li dir="auto">#{_h(p.get("id"))} — {_h(p.get("display_name"))}</li>' for p in sample) or "<li>لا توجد منتجات بدون صور حسب الفلتر الحالي.</li>"
    body = f'''
    <style>
      .auto-box {{ background:white; border:1px solid var(--line); border-radius:28px; box-shadow:var(--shadow); padding:18px; margin:18px 0; }}
      .auto-box h2 {{ margin:0 0 8px; }}
      .auto-box p,.auto-box li {{ color:var(--muted); }}
      .auto-actions {{ display:grid; gap:10px; }}
      .warning-note {{ background:#fff7ed; border:1px solid #fed7aa; color:#9a3412; border-radius:18px; padding:12px; margin:12px 0; font-weight:800; }}
    </style>
    <section class="auto-box">
      <h2>جلب صور تلقائي</h2>
      <p>النظام يبحث عن صور مقترحة للمنتجات بدون صور، ويحفظها في صندوق مراجعة. لا يتم نشر أي صورة إلا بعد اعتمادها.</p>
      <div class="warning-note">مهم: راجعي الصورة قبل اعتمادها، لأن بعض المنتجات لها أحجام أو عبوات متشابهة.</div>
      <form class="search" method="post" action="/merchant/auto-images/fetch">
        <input type="hidden" name="csrf_token" value="{_h(csrf_token)}">
        <div class="search-input-wrap"><span class="search-icon">⌕</span><input name="q" value="{_h(q)}" placeholder="مثال: CeraVe أو Bioderma" dir="auto"></div>
        <select name="category">{''.join(options)}</select>
        <input name="limit" value="{_h(limit)}" type="number" min="1" max="50" title="عدد المنتجات">
        <button type="submit">جلب مقترحات</button>
      </form>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <a class="btn secondary" href="/merchant/auto-images/candidates">مراجعة الصور المقترحة</a>
        <a class="btn secondary" href="/merchant/catalog-images">إدارة الصور اليدوية</a>
      </div>
    </section>
    <section class="auto-box">
      <h3>عينة المنتجات التي سيبدأ بها النظام</h3>
      <ul>{sample_html}</ul>
    </section>
    '''
    return _shell("جلب صور تلقائي", body, active="account")


@router.post("/merchant/auto-images/fetch")
def merchant_auto_images_fetch(
    request: Request,
    csrf_token: str = Form(""),
    q: str = Form(""),
    category: str = Form(""),
    limit: int = Form(10),
    per_product: int = Form(3),
):
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    csrf_resp = _merchant_csrf_response(request, csrf_token)
    if csrf_resp:
        return csrf_resp
    _ensure_auto_image_schema()
    limit = max(1, min(int(limit or 10), 50))
    per_product = max(1, min(int(per_product or 3), 4))
    products = _auto_missing_products(q=q, category=category, limit=limit)
    report = []
    for product in products:
        report.append(_fetch_candidates_for_product(product, per_product=per_product))
    created = sum(int(x.get("created") or 0) for x in report)
    return RedirectResponse(f"/merchant/auto-images/candidates?updated=fetch&created={created}", status_code=303)


@router.get("/merchant/auto-images/candidates", response_class=HTMLResponse)
def merchant_auto_image_candidates(request: Request, status: str = Query("pending"), q: str = Query("", max_length=140), updated: str = Query(""), created: int = Query(0)) -> HTMLResponse:
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    _ensure_auto_image_schema()
    csrf_token = _merchant_csrf_token(request)
    rows = _candidate_rows(status=status, q=q, limit=120)
    cards = "".join(_candidate_card(row, csrf_token) for row in rows) or '<div class="empty">لا توجد صور مقترحة حالياً.</div>'
    notice = ""
    if updated == "fetch":
        notice = f'<div class="success-notice">تم جلب {int(created)} صورة مقترحة. راجعي واعتمدي الصور الصحيحة فقط.</div>'
    elif updated == "approved":
        notice = '<div class="success-notice">تم اعتماد الصورة وظهرت في الكتالوج.</div>'
    elif updated == "rejected":
        notice = '<div class="success-notice">تم رفض الصورة.</div>'
    status_options = []
    for val, label in [("pending", "قيد المراجعة"), ("approved", "المعتمدة"), ("rejected", "المرفوضة"), ("all", "الكل")]:
        selected = " selected" if val == status else ""
        status_options.append(f'<option value="{val}"{selected}>{label}</option>')
    body = f'''
    <style>
      .candidate-card {{ background:white; border:1px solid var(--line); border-radius:26px; box-shadow:var(--shadow); padding:12px; margin:12px 0; display:grid; grid-template-columns:260px 1fr; gap:14px; }}
      .candidate-images {{ display:grid; grid-template-columns:1fr 1fr; gap:8px; }}
      .candidate-images div {{ border:1px dashed #d5dce7; border-radius:18px; padding:6px; min-height:132px; display:grid; align-content:start; gap:4px; background:#f8fafc; }}
      .candidate-images img {{ width:100%; height:112px; object-fit:contain; background:white; border-radius:12px; }}
      .candidate-images small {{ color:var(--muted); font-size:11px; }}
      .candidate-info strong {{ display:block; font-size:18px; margin-bottom:5px; }}
      .candidate-info small {{ display:block; color:var(--muted); margin:3px 0; }}
      .candidate-actions {{ display:flex; gap:8px; flex-wrap:wrap; margin-top:12px; }}
      .candidate-actions form {{ margin:0; }}
      .danger {{ background:#fee2e2 !important; color:#991b1b !important; }}
      .success-notice {{ background:#ecfdf5; color:#065f46; border:1px solid #bbf7d0; border-radius:18px; padding:12px 14px; margin:12px 0; font-weight:850; }}
      @media (max-width:760px) {{ .candidate-card {{ grid-template-columns:1fr; }} .candidate-images img {{ height:150px; }} }}
    </style>
    <section class="image-admin-head">
      <h2>مراجعة الصور المقترحة</h2>
      <p>اعتمدي الصورة الصحيحة فقط. عند الاعتماد تنقل الصورة إلى صور الكتالوج الرسمية.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <a class="btn" href="/merchant/auto-images">جلب صور جديدة</a>
        <a class="btn secondary" href="/merchant/catalog-images">إدارة الصور اليدوية</a>
      </div>
    </section>
    <section class="search-panel compact">
      <form class="search" method="get" action="/merchant/auto-images/candidates">
        <div class="search-input-wrap"><span class="search-icon">⌕</span><input name="q" value="{_h(q)}" placeholder="بحث داخل المقترحات" dir="auto"></div>
        <select name="status">{''.join(status_options)}</select>
        <button type="submit">فلترة</button>
      </form>
    </section>
    {notice}
    {cards}
    '''
    return _shell("مراجعة الصور المقترحة", body, active="account")


@router.post("/merchant/auto-images/approve")
def merchant_auto_image_approve(request: Request, candidate_id: int = Form(...), csrf_token: str = Form("")):
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    csrf_resp = _merchant_csrf_response(request, csrf_token)
    if csrf_resp:
        return csrf_resp
    _ensure_auto_image_schema()
    with _connect_rw() as conn:
        row = conn.execute("SELECT * FROM catalog_image_candidates WHERE id=?", (int(candidate_id),)).fetchone()
        if not row:
            return PlainTextResponse("الصورة المقترحة غير موجودة.", status_code=404)
        src_url = str(row["local_url"] or "")
        src_path = _safe_candidate_image_path(src_url)
        if not src_path or not src_path.exists():
            return PlainTextResponse("ملف الصورة المقترحة غير موجود.", status_code=404)
        ext = src_path.suffix.lower() or ".jpg"
        final_name = f"p{int(row['product_id'])}_{uuid.uuid4().hex[:10]}{ext}"
        final_path = _final_image_base_dir() / final_name
        shutil.copyfile(src_path, final_path)
        final_url = f"/static/catalog_images/{final_name}"
        old = conn.execute("SELECT catalog_image_url FROM products WHERE id=?", (int(row["product_id"]),)).fetchone()
        old_path = _safe_static_image_path(old["catalog_image_url"] or "") if old else None
        conn.execute("UPDATE products SET catalog_image_url=? WHERE id=?", (final_url, int(row["product_id"])))
        conn.execute("UPDATE catalog_image_candidates SET status='approved', approved_at=? WHERE id=?", (_utc_now(), int(candidate_id)))
        conn.commit()
    if old_path and old_path.exists():
        try:
            old_path.unlink()
        except Exception:
            pass
    return RedirectResponse("/merchant/auto-images/candidates?updated=approved", status_code=303)


@router.post("/merchant/auto-images/reject")
def merchant_auto_image_reject(request: Request, candidate_id: int = Form(...), csrf_token: str = Form("")):
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    csrf_resp = _merchant_csrf_response(request, csrf_token)
    if csrf_resp:
        return csrf_resp
    _ensure_auto_image_schema()
    with _connect_rw() as conn:
        conn.execute("UPDATE catalog_image_candidates SET status='rejected' WHERE id=?", (int(candidate_id),))
        conn.commit()
    return RedirectResponse("/merchant/auto-images/candidates?updated=rejected", status_code=303)


@router.get("/catalog-health")
def catalog_health() -> JSONResponse:
    try:
        with _connect() as conn:
            cols = _columns(conn)
            total = int(conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"] or 0)
            available = int(conn.execute(f"SELECT COUNT(*) AS c FROM products WHERE {_available_condition(cols)}").fetchone()["c"] or 0)
            image_expr = _coalesce(cols, IMAGE_COLUMNS, "")
            with_images = int(conn.execute(f"SELECT COUNT(*) AS c FROM products WHERE TRIM(CAST(({image_expr}) AS TEXT)) != ''").fetchone()["c"] or 0)
        return JSONResponse({
            "ok": True,
            "service": "pricebot_catalog",
            "db_path": str(_db_file()),
            "readonly": True,
            "products_count": total,
            "available_count": available,
            "products_with_images": with_images,
            "page_size": PAGE_SIZE,
        })
    except Exception as exc:
        return JSONResponse({
            "ok": False,
            "service": "pricebot_catalog",
            "db_path": str(_db_file()),
            "error": repr(exc),
        }, status_code=500)
