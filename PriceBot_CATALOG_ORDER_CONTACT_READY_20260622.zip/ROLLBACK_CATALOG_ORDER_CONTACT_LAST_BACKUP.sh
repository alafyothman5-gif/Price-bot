#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
LAST="$(ls -td "$APP_DIR"/backups/catalog-order-contact-* 2>/dev/null | head -n 1 || true)"
if [ -z "$LAST" ]; then
  echo "No catalog-order-contact backup found"
  exit 1
fi
cp -a "$LAST/catalog_web.py" "$APP_DIR/catalog_web.py" 2>/dev/null || true
cp -a "$LAST/app.py" "$APP_DIR/app.py" 2>/dev/null || true
sudo systemctl restart pricebot.service
sleep 5
curl -s http://127.0.0.1:8090/catalog-health || true
echo "Rolled back from $LAST"
