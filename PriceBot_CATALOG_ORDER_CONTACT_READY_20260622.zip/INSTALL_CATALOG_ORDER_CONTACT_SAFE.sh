#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/pricebot_clean"
STAMP="$(date +%F_%H-%M-%S)"
BACKUP_DIR="$APP_DIR/backups/catalog-order-contact-$STAMP"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "$APP_DIR"

echo "===== Backup current catalog files ====="
mkdir -p "$BACKUP_DIR"
cp -a catalog_web.py "$BACKUP_DIR/" 2>/dev/null || true
cp -a app.py "$BACKUP_DIR/" 2>/dev/null || true
cp -a pricebot.db "$BACKUP_DIR/" 2>/dev/null || true

echo "===== Check Python syntax ====="
python3 -m py_compile "$SRC_DIR/catalog_web.py"

echo "===== Install catalog order/contact readiness ====="
cp -a "$SRC_DIR/catalog_web.py" "$APP_DIR/catalog_web.py"

echo "===== Ensure catalog router in app.py ====="
python3 - <<'PY'
from pathlib import Path
p = Path('/opt/pricebot_clean/app.py')
s = p.read_text()
changed = False
if 'import catalog_web' not in s and 'from catalog_web import router as catalog_router' not in s:
    marker = 'import merchant\n'
    if marker in s:
        s = s.replace(marker, marker + 'import catalog_web\n', 1)
    else:
        s = 'import catalog_web\n' + s
    changed = True
if 'app.include_router(catalog_web.router)' not in s:
    # Add after app creation/router area if possible; app.include_router works after FastAPI app exists.
    marker = 'app.include_router(merchant.router)'
    if marker in s:
        s = s.replace(marker, 'app.include_router(catalog_web.router)\n' + marker, 1)
    else:
        s += '\n# Catalog website router\napp.include_router(catalog_web.router)\n'
    changed = True
if changed:
    p.write_text(s)
PY

echo "===== Restart PriceBot only ====="
sudo systemctl restart pricebot.service
sleep 7

echo "===== Catalog health ====="
curl -s http://127.0.0.1:8090/catalog-health || true

echo ""
echo "DONE. Open: https://46.101.148.246.sslip.io/catalog?v=ready1"
echo "Contact: https://46.101.148.246.sslip.io/contact"
echo "Backup saved to: $BACKUP_DIR"
