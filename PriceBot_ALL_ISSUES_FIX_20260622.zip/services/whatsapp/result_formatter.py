from __future__ import annotations

"""Customer-facing WhatsApp result formatting without technical labels."""

from typing import Any, Dict, List, Sequence

from normalizer import normalize_text

CATEGORY_LABELS = {
    "medicine": "أدوية", "supplement": "مكملات غذائية", "cosmetic": "عناية", "baby": "أطفال",
    "personal_care": "عناية شخصية", "medical_device": "مستلزمات طبية", "device": "مستلزمات طبية", "other": "",
    "unknown": "", "unclassified": "", "medicine_unspecified": "", "supplement_unspecified": "",
}
FORM_LABELS = {
    "tablet": "أقراص", "capsule": "كبسولات", "syrup": "شراب", "suspension": "معلق", "cream": "كريم",
    "ointment": "مرهم", "gel": "جل", "cleanser": "غسول", "lotion": "لوشن", "serum": "سيروم",
    "drops": "قطرات", "spray": "بخاخ", "sachet": "أكياس", "shampoo": "شامبو", "conditioner": "بلسم",
    "solution": "محلول", "injection": "حقن", "suppository": "تحاميل", "oil": "زيت", "mask": "ماسك",
    "unknown": "", "unclassified": "", "medicine_unspecified": "", "supplement_unspecified": "",
}
TECHNICAL_BAD = {"unknown", "unclassified", "medicine_unspecified", "supplement_unspecified", "other", "غير مصنف", "غير معروف"}




def product_display_name(product: Dict[str, Any]) -> str:
    canonical = str(product.get("canonical_display_name") or "").strip()
    if canonical:
        return canonical
    normalized = str(product.get("normalized_name") or "").strip()
    raw_name = str(product.get("name") or product.get("original_name") or "").strip()
    if normalized:
        # Prefer an approved alias whose normalized text equals the corrected normalized_name;
        # this avoids showing raw Excel typos such as PETROLEEUM to customers.
        for alias in str(product.get("aliases") or "").replace(";", "|").split("|"):
            alias = alias.strip()
            if alias and normalize_text(alias) == normalize_text(normalized):
                return alias
        if raw_name and normalize_text(raw_name) != normalize_text(normalized):
            return normalized
    return raw_name or "منتج"

def display_label(value: Any, labels: Dict[str, str]) -> str:
    raw = str(value or "").strip()
    n = normalize_text(raw)
    if not raw or n in TECHNICAL_BAD:
        return ""
    return labels.get(n, labels.get(raw, raw))


def product_option_lines(products: Sequence[Dict[str, Any]], max_items: int = 10) -> str:
    lines: List[str] = []
    for i, p in enumerate(products[:max_items], 1):
        name = product_display_name(p)
        form = display_label(p.get("form") or p.get("medicine_form") or p.get("product_type"), FORM_LABELS)
        size = str(p.get("size") or "").strip()
        strength = str(p.get("strength") or "").strip()
        lines.append(f"{i}. {name}")
        if form:
            lines.append(f"   الشكل: {form}")
        if size:
            lines.append(f"   الحجم: {size}")
        if strength:
            lines.append(f"   التركيز: {strength}")
    return "\n".join(lines)


def _ltr(value: Any) -> str:
    # LRI/PDI keeps English product names stable inside Arabic WhatsApp bubbles.
    return "\u2066" + str(value or "").strip() + "\u2069"


def clarification_message(products: Sequence[Dict[str, Any]], title: str = "🔍 نتائج البحث") -> str:
    if not products:
        return "🔍 لم أجد المنتج في قائمة الصيدلية.\nيرجى التأكد من الاسم، أو إرسال صورة أوضح للمنتج."
    from normalizer import safe_price
    lines: List[str] = [title, "───────────────"]
    for i, p in enumerate(products[:7], 1):
        name = product_display_name(p)
        price = safe_price(p.get("price"))
        currency = str(p.get("currency") or "د.ل").replace("LYD", "د.ل")
        lines.append("")
        lines.append(f"{i}) {_ltr(name)}")
        if str(price).strip():
            lines.append(f"   السعر: {_ltr(price)} {currency}")
    if len(products) > 7:
        lines.append("")
        lines.append("… توجد نتائج أخرى، افتح القائمة لاختيار المنتج.")
    lines.extend(["", "───────────────", "اختر المنتج من القائمة أو أرسل رقم المنتج."])
    return "\n".join(lines)


def list_row_description(product: Dict[str, Any], include_price: bool = False) -> str:
    form = display_label(product.get("form") or product.get("medicine_form") or product.get("product_type"), FORM_LABELS)
    size = str(product.get("size") or "").strip()
    strength = str(product.get("strength") or "").strip()
    parts = [x for x in [form, size or strength] if x]
    if include_price:
        from normalizer import safe_price
        price = safe_price(product.get("price"))
        currency = str(product.get("currency") or "د.ل").replace("LYD", "د.ل")
        if price:
            parts.append(f"{price} {currency}")
    return " • ".join(parts) if parts else "اضغط لعرض التفاصيل"
