#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Safe PriceBot product-navigation index rebuild.

Builds product_nav_index through a temporary table and verifies products count
is unchanged. It never deletes or replaces products.
"""
from __future__ import annotations
import os
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database  # noqa: E402
from tools import db_safety  # noqa: E402
from services.product_navigator import build_nav_index  # noqa: E402
from services.search_engine import invalidate_runtime_cache  # noqa: E402

MIN_PRODUCTS = int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "0") or "0")


def _assert_products_healthy(count: int, stage: str) -> None:
    if MIN_PRODUCTS and count < MIN_PRODUCTS:
        raise RuntimeError(f"DB_PROTECTION_FAILED | stage={stage} | products_count={count} | min={MIN_PRODUCTS}")


def rebuild_product_nav_index() -> dict:
    db_safety.validate_database(database.DB_FILE, min_products=MIN_PRODUCTS, label="before_nav_index")
    database.init_db()
    before = database.count_products()
    _assert_products_healthy(before, "before_nav_index")
    products = database.load_products()
    rows = build_nav_index(products)
    stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
    tmp = f"product_nav_index_tmp_{stamp}"
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    counts = {}

    with database.get_db_connection() as conn:
        conn.execute(f"""
            CREATE TABLE {tmp} (
                product_id TEXT,
                section TEXT,
                product_type TEXT,
                use_case TEXT,
                skin_type TEXT,
                body_area TEXT,
                medicine_form TEXT,
                strength TEXT,
                confidence REAL,
                tags_json TEXT,
                created_at TEXT
            )
        """)
        try:
            for row in rows:
                counts[row["section"]] = counts.get(row["section"], 0) + 1
                conn.execute(
                    f"""
                    INSERT INTO {tmp}(product_id,section,product_type,use_case,skin_type,body_area,medicine_form,strength,confidence,tags_json,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (row["product_id"], row["section"], row["product_type"], row["use_case"], row["skin_type"], row["body_area"], row["medicine_form"], row["strength"], row["confidence"], row["tags_json"], now),
                )
            conn.execute(f"CREATE INDEX idx_{tmp}_section ON {tmp}(section)")
            conn.execute(f"CREATE INDEX idx_{tmp}_type ON {tmp}(product_type)")
            conn.execute(f"CREATE INDEX idx_{tmp}_pid ON {tmp}(product_id)")
            conn.commit()
            after_build = database.count_products()
            if after_build != before:
                raise RuntimeError(f"DB_PROTECTION_FAILED | stage=after_build_nav_index | before={before} | after={after_build}")
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DROP TABLE IF EXISTS product_nav_index")
            conn.execute(f"ALTER TABLE {tmp} RENAME TO product_nav_index")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_nav_section ON product_nav_index(section)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_nav_type ON product_nav_index(product_type)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_product_nav_pid ON product_nav_index(product_id)")
            conn.commit()
        except Exception:
            conn.rollback()
            try:
                conn.execute(f"DROP TABLE IF EXISTS {tmp}")
                conn.commit()
            except Exception:
                pass
            raise

    after = database.count_products()
    if after != before:
        raise RuntimeError(f"DB_PROTECTION_FAILED | stage=after_nav_index | before={before} | after={after}")
    db_safety.validate_database(database.DB_FILE, min_products=MIN_PRODUCTS, expected_count=before, label="after_nav_index")
    invalidate_runtime_cache()
    return {"products_before": before, "products_after": after, "indexed": len(rows), "sections": counts}


def main() -> None:
    report = rebuild_product_nav_index()
    print("PRICEBOT_PRODUCT_NAV_INDEX_REBUILD_OK")
    print(f"INDEX_REBUILD_OK | products_before={report['products_before']} | products_after={report['products_after']} | indexed={report['indexed']}")
    for k, v in sorted(report["sections"].items()):
        print(f"section_{k}: {v}")


if __name__ == "__main__":
    main()
