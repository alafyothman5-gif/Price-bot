#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Restore the newest valid PriceBot SQLite DB backup.

A valid backup must pass PRAGMA integrity_check and contain at least the minimum
product count (defaults to PRICEBOT_MIN_PRODUCTS_GUARD or 1000 for production).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tools import db_safety  # noqa: E402


def find_valid_backup(backup_root: Path, min_products: int) -> Path:
    candidates = sorted(backup_root.glob("*/pricebot.db"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    errors = []
    for db in candidates:
        try:
            db_safety.validate_database(db, min_products=min_products, label="candidate_backup")
            return db
        except Exception as exc:
            errors.append({"path": str(db), "error": str(exc)[:250]})
    raise RuntimeError("NO_VALID_DB_BACKUP_FOUND | " + json.dumps({"backup_root": str(backup_root), "checked": len(candidates), "errors": errors[:10]}, ensure_ascii=False))


def main() -> None:
    ap = argparse.ArgumentParser(description="Restore newest valid PriceBot DB backup")
    ap.add_argument("--backup-root", default="/root/pricebot_backups")
    ap.add_argument("--db", default=str(ROOT / "pricebot.db"))
    ap.add_argument("--min-products", type=int, default=int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000))
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    backup = find_valid_backup(Path(args.backup_root), args.min_products)
    if args.dry_run:
        print("DB_RESTORE_DRY_RUN_OK | " + json.dumps({"backup": str(backup), "target": args.db}, ensure_ascii=False))
        return
    result = db_safety.restore_database(backup, args.db, min_products=args.min_products)
    print("DB_RESTORE_LAST_GOOD_OK | " + json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
