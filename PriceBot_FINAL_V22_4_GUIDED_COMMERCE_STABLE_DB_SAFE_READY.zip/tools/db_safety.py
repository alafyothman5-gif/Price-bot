#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SQLite safety helpers for PriceBot deploy/restore.

This module is intentionally independent from database.py so it can validate a
DB before application migrations or PRAGMA writes run. It never creates product
data and never writes to products.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = Path(os.getenv("PRICEBOT_DB_FILE", str(ROOT / "pricebot.db")))
if not DEFAULT_DB.is_absolute():
    DEFAULT_DB = ROOT / DEFAULT_DB
SQLITE_MAGIC = b"SQLite format 3\x00"


def _json(data: Dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True)


def sqlite_magic_ok(path: Path) -> bool:
    try:
        if not path.exists() or path.stat().st_size < len(SQLITE_MAGIC):
            return False
        with path.open("rb") as fh:
            return fh.read(len(SQLITE_MAGIC)) == SQLITE_MAGIC
    except Exception:
        return False


def validate_database(db_path: Path | str = DEFAULT_DB, *, min_products: int = 0, expected_count: Optional[int] = None,
                      require_products: bool = True, label: str = "validate") -> Dict[str, Any]:
    path = Path(db_path)
    result: Dict[str, Any] = {"label": label, "db_path": str(path), "exists": path.exists(), "ok": False}
    if not path.exists():
        result["error"] = "db_not_found"
        raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result))
    if not sqlite_magic_ok(path):
        result["error"] = "not_sqlite_file"
        result["size"] = path.stat().st_size if path.exists() else 0
        raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result))
    try:
        con = sqlite3.connect(str(path), timeout=15)
        con.row_factory = sqlite3.Row
        try:
            integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
            result["integrity_check"] = integrity
            if str(integrity).lower() != "ok":
                result["error"] = "integrity_check_failed"
                raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result))
            products_count = None
            if require_products:
                table = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='products'").fetchone()
                if not table:
                    result["error"] = "products_table_missing"
                    raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result))
                products_count = int((con.execute("SELECT COUNT(*) FROM products").fetchone()[0]) or 0)
                result["products_count"] = products_count
                if min_products and products_count < int(min_products):
                    result["error"] = "products_below_min_guard"
                    result["min_products"] = int(min_products)
                    raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result))
                if expected_count is not None and products_count < int(expected_count):
                    result["error"] = "products_count_decreased"
                    result["expected_count"] = int(expected_count)
                    raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result))
            result["ok"] = True
            return result
        finally:
            con.close()
    except RuntimeError:
        raise
    except Exception as exc:
        result["error"] = str(exc)
        raise RuntimeError("DB_VALIDATION_FAILED | " + _json(result)) from exc


def online_backup(db_path: Path | str, out_dir: Path | str, *, min_products: int = 0, label: str = "backup") -> Path:
    src = Path(db_path)
    dest_dir = Path(out_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    validate_database(src, min_products=min_products, label=f"{label}_source")
    dest = dest_dir / "pricebot.db"
    tmp = dest_dir / f"pricebot.db.tmp.{os.getpid()}.{int(time.time())}"
    src_con = sqlite3.connect(str(src), timeout=30)
    dst_con = sqlite3.connect(str(tmp), timeout=30)
    try:
        src_con.backup(dst_con)
        dst_con.commit()
    finally:
        dst_con.close()
        src_con.close()
    validate_database(tmp, min_products=min_products, label=f"{label}_copy")
    os.replace(tmp, dest)
    return dest


def restore_database(backup_db: Path | str, target_db: Path | str = DEFAULT_DB, *, min_products: int = 0) -> Dict[str, Any]:
    src = Path(backup_db)
    dst = Path(target_db)
    valid = validate_database(src, min_products=min_products, label="restore_source")
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(f"{dst.name}.restore_tmp.{os.getpid()}.{int(time.time())}")
    shutil.copy2(src, tmp)
    validate_database(tmp, min_products=min_products, label="restore_tmp")
    for suffix in ("-wal", "-shm"):
        try:
            (dst.parent / f"{dst.name}{suffix}").unlink(missing_ok=True)
        except Exception:
            pass
    os.replace(tmp, dst)
    final = validate_database(dst, min_products=min_products, label="restore_final")
    return {"restored": True, "source": str(src), "target": str(dst), "products_count": final.get("products_count"), "source_products_count": valid.get("products_count")}


def table_count(db_path: Path | str, table: str) -> int:
    path = Path(db_path)
    con = sqlite3.connect(str(path), timeout=10)
    try:
        row = con.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()
        return int((row[0] if row else 0) or 0)
    finally:
        con.close()


def main() -> None:
    p = argparse.ArgumentParser(description="PriceBot SQLite DB safety utility")
    sub = p.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate")
    v.add_argument("--db", default=str(DEFAULT_DB))
    v.add_argument("--min-products", type=int, default=int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "0") or 0))
    v.add_argument("--expected-count", type=int)
    v.add_argument("--label", default="validate")
    b = sub.add_parser("backup")
    b.add_argument("--db", default=str(DEFAULT_DB))
    b.add_argument("--out-dir", required=True)
    b.add_argument("--min-products", type=int, default=int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "0") or 0))
    r = sub.add_parser("restore")
    r.add_argument("--backup", required=True)
    r.add_argument("--db", default=str(DEFAULT_DB))
    r.add_argument("--min-products", type=int, default=int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "0") or 0))
    c = sub.add_parser("count")
    c.add_argument("--db", default=str(DEFAULT_DB))
    c.add_argument("--table", default="products")
    args = p.parse_args()
    if args.cmd == "validate":
        print("DB_VALIDATION_OK | " + _json(validate_database(args.db, min_products=args.min_products, expected_count=args.expected_count, label=args.label)))
    elif args.cmd == "backup":
        out = online_backup(args.db, args.out_dir, min_products=args.min_products)
        print("DB_BACKUP_OK | " + _json({"backup_db": str(out)}))
    elif args.cmd == "restore":
        print("DB_RESTORE_OK | " + _json(restore_database(args.backup, args.db, min_products=args.min_products)))
    elif args.cmd == "count":
        print(table_count(args.db, args.table))


if __name__ == "__main__":
    main()
