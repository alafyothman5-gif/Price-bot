#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build V22.1 catalog-alignment workbooks from the current DB or an Excel file.

Usage on production server, without replacing the live catalog:
  python tools/build_v22_company_catalog.py --db pricebot.db --out-dir catalog_v22_alignment

Or from an Excel export:
  python tools/build_v22_company_catalog.py --input PriceList.xlsx --out-dir catalog_v22_alignment

Outputs:
  products_v22_company_catalog_ready.xlsx
  products_v22_needs_review.xlsx
  catalog_v22_alignment_report.xlsx
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, List, Sequence

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.catalog_alignment import READY_COLUMNS, align_products  # noqa: E402

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
except Exception as exc:  # pragma: no cover
    raise SystemExit("openpyxl is required. Install requirements.txt first.") from exc


def _read_db(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Database not found: {path}")
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    try:
        try:
            rows = conn.execute("SELECT * FROM products").fetchall()
            return [dict(r) for r in rows]
        except sqlite3.OperationalError as exc:
            if "no such table" in str(exc).lower():
                return []
            raise
    finally:
        conn.close()


def _read_xlsx(path: Path) -> List[Dict[str, Any]]:
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    # Prefer a product-like sheet if present.
    sheet = None
    for name in wb.sheetnames:
        if name.lower() in {"products", "products_bot_upload", "products_upload", "sheet1"}:
            sheet = wb[name]; break
    sheet = sheet or wb[wb.sheetnames[0]]
    rows = list(sheet.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(h or "").strip() for h in rows[0]]
    out: List[Dict[str, Any]] = []
    for values in rows[1:]:
        if not values or not any(v not in (None, "") for v in values):
            continue
        row = {headers[i]: values[i] if i < len(values) else "" for i in range(len(headers)) if headers[i]}
        # Normalize common Arabic/legacy column names.
        mapped = dict(row)
        for src, dst in {"Product": "name", "product": "name", "Name": "name", "السعر": "price", "Price": "price", "الاسم": "name"}.items():
            if src in row and dst not in mapped:
                mapped[dst] = row[src]
        out.append(mapped)
    return out


def _demo_products() -> List[Dict[str, Any]]:
    # Used only when explicitly requested to show workbook shape without a live catalog.
    return [
        {"id": 1, "name": "+Photoblok 50", "price": "70", "category": "other", "form": "product", "available": "متوفر"},
        {"id": 2, "name": "Cera Ve sa smoothing cleanser", "price": "110", "category": "other", "form": "product", "available": "متوفر"},
        {"id": 3, "name": "CeraVe Hydrating Cleanser Dry Skin 236ml", "price": "125", "category": "other", "form": "product", "available": "متوفر"},
        {"id": 4, "name": "Baby wash gentle 200ml", "price": "40", "category": "other", "form": "product", "available": "متوفر"},
        {"id": 5, "name": "Head and Shoulders Shampoo", "price": "35", "category": "other", "form": "product", "available": "متوفر"},
        {"id": 6, "name": "gyno-daktarin vag cream", "price": "55", "category": "other", "form": "product", "available": "متوفر"},
    ]


def _write_sheet(path: Path, title: str, columns: Sequence[str], rows: Sequence[Dict[str, Any]]) -> None:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]
    ws.append(list(columns))
    for row in rows:
        ws.append([row.get(c, "") for c in columns])
    header_fill = PatternFill("solid", fgColor="0F766E")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for col in ws.columns:
        letter = col[0].column_letter
        max_len = min(max(len(str(c.value or "")) for c in col[:200]) + 2, 42)
        ws.column_dimensions[letter].width = max(12, max_len)
    wb.save(path)


def _write_report(path: Path, counts: Dict[str, Any]) -> None:
    wb = openpyxl.Workbook()
    ws = wb.active; ws.title = "Summary"
    ws.append(["metric", "value"])
    for k in ["total", "ready", "needs_review"]:
        ws.append([k, counts.get(k, 0)])
    ws.append([]); ws.append(["category", "count"])
    for k, v in sorted((counts.get("sections") or {}).items()):
        ws.append([k, v])
    ws2 = wb.create_sheet("Review Reasons")
    ws2.append(["reason", "count"])
    for k, v in sorted((counts.get("review_reasons") or {}).items(), key=lambda x: (-x[1], x[0])):
        ws2.append([k, v])
    for sheet in wb.worksheets:
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1D4ED8")
        sheet.freeze_panes = "A2"
        for col in sheet.columns:
            sheet.column_dimensions[col[0].column_letter].width = min(max(max(len(str(c.value or "")) for c in col) + 2, 12), 42)
    wb.save(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", help="Excel catalog file (.xlsx)")
    parser.add_argument("--db", help="SQLite pricebot.db path. Defaults to PRICEBOT_DB_FILE or ./pricebot.db")
    parser.add_argument("--out-dir", default=".")
    parser.add_argument("--demo-if-missing", action="store_true", help="Create demo outputs if no DB/input exists; do not use for production.")
    args = parser.parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    source_note = ""
    if args.input:
        products = _read_xlsx(Path(args.input))
        source_note = f"input={args.input}"
    else:
        db_path = Path(args.db or os.getenv("PRICEBOT_DB_FILE", str(ROOT / "pricebot.db")))
        if db_path.exists():
            products = _read_db(db_path)
            source_note = f"db={db_path}"
            if not products and args.demo_if_missing:
                products = _demo_products()
                source_note = "demo_catalog_empty_db"
        elif args.demo_if_missing:
            products = _demo_products()
            source_note = "demo_catalog_no_live_db_found"
        else:
            raise SystemExit(f"No catalog source found. Pass --input, --db, or --demo-if-missing. Looked for: {db_path}")
    ready, review, counts = align_products(products)
    counts["source"] = source_note
    ready_path = out_dir / "products_v22_company_catalog_ready.xlsx"
    review_path = out_dir / "products_v22_needs_review.xlsx"
    report_path = out_dir / "catalog_v22_alignment_report.xlsx"
    _write_sheet(ready_path, "ready", READY_COLUMNS, ready)
    _write_sheet(review_path, "needs_review", READY_COLUMNS, review)
    _write_report(report_path, counts)
    print("PRICEBOT_V22_CATALOG_ALIGNMENT_OK")
    print(f"source: {source_note}")
    print(f"total: {counts.get('total', 0)}")
    print(f"ready: {counts.get('ready', 0)}")
    print(f"needs_review: {counts.get('needs_review', 0)}")
    print(f"ready_file: {ready_path}")
    print(f"review_file: {review_path}")
    print(f"report_file: {report_path}")


if __name__ == "__main__":
    main()
