#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PriceBot V22.3 diagnostic command.

Read-only diagnostic. It does not modify products, indexes, .env, or service
configuration.
"""
from __future__ import annotations
import json
import os
import sqlite3
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database  # noqa: E402
import matcher  # noqa: E402
from tools import db_safety  # noqa: E402
from services import search_engine  # noqa: E402

PORT = int(os.getenv("PRICEBOT_PORT", "8000"))
DB_PATH = str(database.DB_FILE)


def count_table(name: str) -> int:
    try:
        with database.get_db_connection() as conn:
            row = conn.execute(f"SELECT COUNT(*) AS c FROM {name}").fetchone()
            return int(row["c"] or 0)
    except Exception:
        return -1


def health_status() -> str:
    url = f"http://127.0.0.1:{PORT}/health"
    try:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return f"HTTP {resp.status} | " + resp.read(300).decode("utf-8", "replace")
    except Exception as exc:
        return f"UNREACHABLE | {exc}"


def service_port_status() -> str:
    try:
        out = subprocess.check_output(["bash", "-lc", f"ss -ltnp 2>/dev/null | grep ':{PORT} ' || true"], text=True, timeout=3)
        return out.strip() or f"NO_LISTENER_ON_{PORT}"
    except Exception as exc:
        return f"PORT_CHECK_ERROR: {exc}"


def last_errors(limit: int = 50):
    errors = []
    try:
        with database.get_db_connection() as conn:
            if database._table_exists(conn, "product_inquiries"):
                rows = conn.execute(
                    """
                    SELECT created_at, raw_query, status, matched_product
                    FROM product_inquiries
                    WHERE status LIKE '%error%' OR status LIKE '%timeout%' OR status IN ('fallback','low_confidence')
                    ORDER BY datetime(created_at) DESC
                    LIMIT ?
                    """,
                    (limit,),
                ).fetchall()
                errors.extend([dict(r) for r in rows])
    except Exception as exc:
        errors.append({"diagnostic_error": str(exc)})
    if len(errors) < limit:
        try:
            out = subprocess.check_output(["journalctl", "-u", "pricebot", "-n", "80", "--no-pager"], text=True, timeout=5, stderr=subprocess.DEVNULL)
            for line in out.splitlines():
                low = line.lower()
                if any(x in low for x in ["error", "timeout", "traceback", "failed"]):
                    errors.append({"journal": line[-500:]})
                    if len(errors) >= limit:
                        break
        except Exception:
            pass
    return errors[:limit]


def time_call(label: str, fn):
    start = time.perf_counter()
    try:
        result = fn()
        ok = True
    except Exception as exc:
        result = f"ERROR: {exc}"
        ok = False
    ms = (time.perf_counter() - start) * 1000
    return {"label": label, "ok": ok, "ms": round(ms, 2), "result": result}


def exact_lookup_result(query: str):
    decision = search_engine.search_products_db(query, allow_guided=False, exact_only=True, timeout_ms=250)
    return {"decision": decision.decision, "reason": decision.reason, "product": (decision.product or {}).get("name", ""), "elapsed_ms": round(decision.elapsed_ms, 2)}


def menu_result():
    result = matcher.handle_text_query_result("diagnose_user", "السلام عليكم", database.get_user_state("diagnose_user"))
    return {"decision": result.decision, "reply_head": result.reply.splitlines()[0] if result.reply else ""}


def db_integrity() -> dict:
    try:
        return db_safety.validate_database(DB_PATH, min_products=0, label="diagnose")
    except Exception as exc:
        return {"ok": False, "error": str(exc), "db_path": DB_PATH}


def main() -> None:
    data = {
        "db_path": DB_PATH,
        "db_integrity_check": db_integrity(),
        "products_count": count_table("products"),
        "search_index_count": count_table("product_search_index"),
        "nav_index_count": count_table("product_nav_index"),
        "guided_catalog_index_count": count_table("guided_catalog_index"),
        "service_port": PORT,
        "port_status": service_port_status(),
        "health_status": health_status(),
        "exact_lookup_photoblok_50_plus": time_call("Photoblok 50+", lambda: exact_lookup_result("Photoblok 50+")),
        "menu_response_timing": time_call("السلام عليكم", menu_result),
        "guided_catalog_summary": database.guided_catalog_summary()[:40] if hasattr(database, "guided_catalog_summary") else [],
        "last_50_errors": last_errors(50),
    }
    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
