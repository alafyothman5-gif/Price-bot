#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run V22.1 catalog acceptance checks against a live DB or Excel catalog.

This is intentionally separate from pytest because production catalogs vary. It
validates that the current catalog can support the market flows required by V22.
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.catalog_alignment import align_product  # noqa: E402
from services.search_engine import DECISION_EXACT, DECISION_NOT_AVAILABLE, search_products  # noqa: E402
from services import guided_finder, product_navigator  # noqa: E402

try:
    import openpyxl
except Exception:  # pragma: no cover
    openpyxl = None


def _read_db(path: Path) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(str(path)); conn.row_factory = sqlite3.Row
    try:
        
        try:
            return [dict(r) for r in conn.execute("SELECT * FROM products").fetchall()]
        except sqlite3.OperationalError as exc:
            if "no such table" in str(exc).lower():
                return []
            raise
    finally:
        conn.close()


def _read_xlsx(path: Path) -> List[Dict[str, Any]]:
    if openpyxl is None:
        raise SystemExit("openpyxl is required. Install requirements.txt first.")
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    headers = [str(h or "").strip() for h in rows[0]] if rows else []
    out = []
    for values in rows[1:]:
        if not values or not any(v not in (None, "") for v in values):
            continue
        row = {headers[i]: values[i] if i < len(values) else "" for i in range(len(headers)) if headers[i]}
        if "name" not in row:
            for alt in ["Name", "Product", "product", "الاسم"]:
                if alt in row:
                    row["name"] = row[alt]; break
        out.append(row)
    return out


def _demo_products() -> List[Dict[str, Any]]:
    return [
        {"id": "p1", "name": "+Photoblok 50", "price": "70", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p2", "name": "1,2,3 Extra", "aliases": "Extra 1,2,3", "price": "20", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p3", "name": "gyno-daktarin vag cream", "price": "55", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p4", "name": "CeraVe Foaming Facial Cleanser Normal to Oily Skin", "price": "130", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p5", "name": "CeraVe Hydrating Cleanser Dry Skin", "price": "125", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p6", "name": "Baby gentle wash", "price": "30", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p7", "name": "Body wash fresh", "price": "30", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p8", "name": "Nizoral shampoo", "price": "65", "category": "other", "form": "product", "available": "متوفر"},
        {"id": "p9", "name": "Flagyl tablet 500mg", "price": "15", "category": "medicine", "form": "tablet", "strength": "500mg", "available": "متوفر"},
    ]


def _aligned(products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for p in products:
        a = align_product(p)
        merged = dict(p); merged.update({k: v for k, v in a.items() if v not in (None, "")})
        out.append(merged)
    return out


def _check(cond: bool, name: str, details: str = "") -> None:
    if not cond:
        raise AssertionError(f"{name} FAILED {details}".strip())
    print(f"OK - {name}")


def _search_exact(products: List[Dict[str, Any]], query: str) -> None:
    d = search_products(query, products, allow_guided=False)
    _check(d.decision == DECISION_EXACT, f"{query} exact match", f"decision={d.decision} reason={d.reason}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", help="SQLite pricebot.db path")
    parser.add_argument("--input", help="Excel catalog path")
    parser.add_argument("--demo-if-missing", action="store_true")
    args = parser.parse_args()
    if args.input:
        products = _read_xlsx(Path(args.input))
    else:
        db_path = Path(args.db or os.getenv("PRICEBOT_DB_FILE", str(ROOT / "pricebot.db")))
        if db_path.exists():
            products = _read_db(db_path)
            if not products and args.demo_if_missing:
                products = _demo_products()
        elif args.demo_if_missing:
            products = _demo_products()
        else:
            raise SystemExit(f"No catalog source found. Pass --input, --db, or --demo-if-missing. Looked for {db_path}")
    products = _aligned(products)
    _check(bool(products), "catalog has products")
    _search_exact(products, "Photoblok 50+")
    _search_exact(products, "+Photoblok 50")
    # The real catalog should include either product 123 or an alias for Extra 1,2,3.
    d123 = search_products("123", products, allow_guided=False)
    _check(d123.decision == DECISION_EXACT, "123 exact match", f"decision={d123.decision}")
    _search_exact(products, "Extra 1,2,3")
    _search_exact(products, "gyno-daktarin vag cream")
    formag = search_products("Formag", products, allow_guided=False)
    _check(formag.decision == DECISION_NOT_AVAILABLE, "Formag not available", f"decision={formag.decision}")
    gf = guided_finder.handle_guided_query("test", "غسول", {}, products)
    _check(gf and gf.handled and "غسول وجه" in gf.reply, "غسول guided flow")
    gf2 = guided_finder.handle_guided_query("test", "غسول وجه", {}, products)
    _check(gf2 and gf2.handled and "نوع البشرة" in gf2.reply, "غسول وجه asks skin type")
    gf3 = guided_finder.handle_guided_query("test", "غسول للبشرة الدهنية", {}, products)
    _check(gf3 and gf3.handled, "oily face cleanser handled")
    opts = gf3.options or []
    if not opts and gf3.state_update:
        opts = (((gf3.state_update or {}).get("guided_finder") or {}).get("last_options") or [])
    _check(bool(opts), "oily face cleanser returns products")
    names = " | ".join(str(o.get("name") or o.get("label") or "") for o in opts).lower()
    _check("baby" not in names and "body wash" not in names, "no baby/body wash in face cleanser")
    _check("hydrating cleanser" not in names or "foaming" in names or "oily" in names, "no dry cleanser for oily query")
    sections = product_navigator.available_sections(products)
    sec_ids = {s.get("id") for s in sections}
    _check("medicine" in sec_ids, "medicine section has products")
    shampoo_slots = {"selected_category": "hair_care", "selected_product_type": "shampoo", "body_area": "hair", "form": "shampoo"}
    hair = guided_finder.filter_products_by_guided_slots(shampoo_slots, products, limit=10)
    _check(all("shampoo" in (str(p.get("name") or "") + " " + str(p.get("form") or "") + " " + str(p.get("product_type") or "")).lower() for p in hair), "shampoo shows hair products only")
    state = {"guided_finder": {"current_flow": "browse", "step": "results", "last_options": opts, "last_options_type": "products", "expires_at": 9999999999}}
    sel = guided_finder.handle_guided_query("test", "1", state, products)
    _check(sel and sel.product, "numeric selection returns product")
    print("PRICEBOT_V22_CATALOG_ACCEPTANCE_OK")


if __name__ == "__main__":
    main()
