#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final V22.4 DB safety + Guided Commerce acceptance tests.

All checks run on isolated temporary SQLite files. This test must never touch
/opt/pricebot/pricebot.db or a real .env.
"""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

TMP_DIR = Path(tempfile.mkdtemp(prefix="pricebot_v22_4_acceptance_"))
os.environ["PRICEBOT_DB_FILE"] = str(TMP_DIR / "acceptance_v22_4.db")
os.environ["PRICEBOT_MIN_PRODUCTS_GUARD"] = "1"
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-code"
os.environ["PRICEBOT_ENV"] = "test"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"

ROOT = Path(__file__).resolve().parent

import database  # noqa: E402
import matcher  # noqa: E402
from services import guided_finder, search_engine  # noqa: E402
from tools import db_safety  # noqa: E402
from tools.rebuild_search_index import rebuild_search_index  # noqa: E402
from tools.rebuild_product_nav_index import rebuild_product_nav_index  # noqa: E402
from tools.build_guided_catalog_index import main as _unused_build_main  # noqa: F401,E402


def seed_master_catalog() -> None:
    database.init_db()
    rows = [
        # exact-only product: searchable by full name, hidden from guided menus
        {"product_id":"PHOTOBLOK50","name":"Photoblok 50+","normalized_name":"photoblok 50","brand":"Photoblok","section":"عناية بالبشرة","product_type":"sunscreen","use_case":"sun_protection","skin_type":"normal_combination_skin","body_area":"face","search_mode":"exact_only","quality_status":"verified","aliases":"Photoblok 50+","ocr_keywords":"photoblok spf 50 sunscreen","price":"70","available":"true"},
        {"product_id":"ZOF4","name":"Zofran 4 mg tablets","normalized_name":"zofran 4 mg tablets","brand":"Zofran","section":"أدوية","category":"medicine","product_type":"stomach_vomiting","use_case":"antiemetic","form":"tablet","strength":"4 mg","search_mode":"guided","quality_status":"verified","aliases":"Ondansetron 4mg; Zofran 4 mg","ocr_keywords":"zofran ondansetron 4 mg","price":"22","available":"true"},
        {"product_id":"PAN1","name":"Panadol 500mg Tablets","normalized_name":"panadol 500mg tablets","brand":"Panadol","section":"أدوية","category":"medicine","product_type":"pain_fever","use_case":"pain_fever","form":"tablet","strength":"500mg","search_mode":"guided","quality_status":"verified","aliases":"Paracetamol 500mg","ocr_keywords":"panadol paracetamol 500","price":"8","available":"true"},
        {"product_id":"FLAG1","name":"Flagyl 500mg Tablets","normalized_name":"flagyl 500mg tablets","brand":"Flagyl","section":"أدوية","category":"medicine","product_type":"antibiotic","use_case":"antibiotic","form":"tablet","strength":"500mg","search_mode":"guided","quality_status":"verified","aliases":"فلاجيل 500","ocr_keywords":"flagyl metronidazole 500","price":"9","available":"true"},
        {"product_id":"FLAG2","name":"Flagyl Syrup 125mg/5ml","normalized_name":"flagyl syrup 125mg 5ml","brand":"Flagyl","section":"أدوية","category":"medicine","product_type":"antibiotic","use_case":"antibiotic","form":"syrup","strength":"125mg/5ml","search_mode":"guided","quality_status":"verified","aliases":"فلاجيل شراب","ocr_keywords":"flagyl metronidazole syrup","price":"10","available":"true"},
        {"product_id":"IRON1","name":"Feroglobin Iron Capsules","normalized_name":"feroglobin iron capsules","brand":"Feroglobin","section":"مكملات وفيتامينات","category":"supplement","product_type":"iron","use_case":"iron","form":"capsule","search_mode":"guided","quality_status":"verified","aliases":"حديد feroglobin","ocr_keywords":"iron ferrous feroglobin حديد","price":"35","available":"true"},
        {"product_id":"VITD1","name":"Vitamin D3 5000 IU","normalized_name":"vitamin d3 5000 iu","brand":"D3","section":"مكملات وفيتامينات","category":"supplement","product_type":"vitamin_d","use_case":"vitamin_d","form":"softgel","search_mode":"guided","quality_status":"verified","aliases":"فيتامين د","ocr_keywords":"vitamin d d3","price":"28","available":"true"},
        {"product_id":"OILY1","name":"Bioderma Sebium Gel Moussant 200ml","normalized_name":"bioderma sebium gel moussant 200ml","brand":"Bioderma","section":"عناية بالبشرة","category":"cosmetic","product_type":"face_cleanser","use_case":"oil_control","skin_type":"oily_skin","body_area":"face","search_mode":"guided","quality_status":"verified","aliases":"غسول للبشرة الدهنية","ocr_keywords":"sebium oily face cleanser","price":"65","available":"true"},
        {"product_id":"DRY1","name":"CeraVe Hydrating Cleanser Dry Skin","normalized_name":"cerave hydrating cleanser dry skin","brand":"CeraVe","section":"عناية بالبشرة","category":"cosmetic","product_type":"face_cleanser","use_case":"hydration","skin_type":"dry_skin","body_area":"face","search_mode":"guided","quality_status":"verified","aliases":"cerave hydrating cleanser","ocr_keywords":"cerave dry face cleanser","price":"125","available":"true"},
        {"product_id":"BABYWASH1","name":"Johnson Baby Wash","normalized_name":"johnson baby wash","brand":"Johnson","section":"أطفال","category":"baby","product_type":"baby_wash","use_case":"baby_wash","body_area":"baby","search_mode":"guided","quality_status":"verified","aliases":"غسول اطفال","ocr_keywords":"baby wash kids","price":"18","available":"true"},
        {"product_id":"BODYWASH1","name":"Nivea Body Wash","normalized_name":"nivea body wash","brand":"Nivea","section":"عناية بالبشرة","category":"cosmetic","product_type":"body_care","use_case":"body_care","body_area":"body","search_mode":"guided","quality_status":"verified","aliases":"body wash","ocr_keywords":"body wash shower gel","price":"25","available":"true"},
        {"product_id":"SHAMP1","name":"Vichy Dercos Anti Dandruff Shampoo","normalized_name":"vichy dercos anti dandruff shampoo","brand":"Vichy","section":"عناية بالشعر","category":"hair_care","product_type":"shampoo","use_case":"dandruff","body_area":"hair","search_mode":"guided","quality_status":"verified","aliases":"شامبو قشرة","ocr_keywords":"shampoo hair dandruff","price":"80","available":"true"},
        {"product_id":"DEVICE1","name":"Omron Blood Pressure Monitor","normalized_name":"omron blood pressure monitor","brand":"Omron","section":"أجهزة ومستلزمات","category":"device","product_type":"blood_pressure","use_case":"blood_pressure","body_area":"","search_mode":"guided","quality_status":"verified","aliases":"جهاز قياس ضغط","ocr_keywords":"pressure device monitor","price":"180","available":"true"},
        # hidden rows must not appear to customer
        {"product_id":"REV1","name":"Review Only Cream","normalized_name":"review only cream","brand":"X","section":"عناية بالبشرة","category":"cosmetic","product_type":"moisturizer","use_case":"hydration","skin_type":"dry_skin","body_area":"face","search_mode":"review_only","quality_status":"needs_review","aliases":"","ocr_keywords":"","price":"11","available":"true"},
    ]
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        conn.execute("DELETE FROM conversation_state")
        for p in rows:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,section,category,product_type,use_case,skin_type,body_area,form,strength,search_mode,quality_status,aliases,ocr_keywords,image_ocr_keywords,price,available)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p.get("product_id"), p.get("name"), p.get("normalized_name"), p.get("brand"), p.get("section"), p.get("category"), p.get("product_type"), p.get("use_case"), p.get("skin_type",""), p.get("body_area",""), p.get("form",""), p.get("strength",""), p.get("search_mode",""), p.get("quality_status",""), p.get("aliases",""), p.get("ocr_keywords",""), p.get("ocr_keywords",""), p.get("price",""), p.get("available","true")),
            )
        conn.commit()
    rows_idx = guided_finder.build_guided_catalog_rows(database.load_products())
    rep = database.replace_guided_catalog_index(rows_idx)
    assert rep["products_before"] == rep["products_after"] == len(rows), rep
    matcher.invalidate_product_cache()
    search_engine.invalidate_runtime_cache()


def ask(phone: str, text: str):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))


def assert_no_customer_hidden(reply: str) -> None:
    forbidden = ["Review Only", "Johnson Baby Wash", "Nivea Body Wash"]
    for word in forbidden:
        assert word not in reply, reply


def test_db_safety_helpers() -> None:
    db_safety.validate_database(database.DB_FILE, min_products=1, label="acceptance_valid")
    before = database.count_products()
    backup_dir = TMP_DIR / "backup_good"
    backup = db_safety.online_backup(database.DB_FILE, backup_dir, min_products=1)
    corrupt = TMP_DIR / "corrupt.db"
    corrupt.write_text("not sqlite", encoding="utf-8")
    try:
        db_safety.validate_database(corrupt, min_products=1, label="corrupt_should_fail")
    except RuntimeError as exc:
        assert "not_sqlite_file" in str(exc) or "DB_VALIDATION_FAILED" in str(exc)
    else:
        raise AssertionError("corrupt DB passed validation")
    target = TMP_DIR / "restored.db"
    result = db_safety.restore_database(backup, target, min_products=1)
    assert result["products_count"] == before, result
    db_safety.validate_database(target, min_products=1, expected_count=before, label="restored_valid")


def test_indexes_do_not_change_products() -> None:
    before = database.count_products()
    r1 = rebuild_search_index(); assert r1["products_before"] == r1["products_after"] == before, r1
    r2 = rebuild_product_nav_index(); assert r2["products_before"] == r2["products_after"] == before, r2
    rows = guided_finder.build_guided_catalog_rows(database.load_products())
    r3 = database.replace_guided_catalog_index(rows); assert r3["products_before"] == r3["products_after"] == before, r3
    db_safety.validate_database(database.DB_FILE, min_products=1, expected_count=before, label="after_all_indexes")


def test_deploy_script_safety_contract() -> None:
    script = (ROOT / "deploy_pricebot_v22_4.sh").read_text(encoding="utf-8")
    assert "tools/db_safety.py validate" in script
    assert "tools/db_safety.py backup" in script
    assert "--exclude='./pricebot.db'" in script
    assert "timeout --preserve-status" in script
    assert "run_timeout 90 env PRICEBOT_DB_FILE" in script
    assert "PRICEBOT_MIN_PRODUCTS_GUARD=1" in script
    assert "products_master_v22_ready.xlsx" in script


def test_guided_routes_and_master_catalog_filters() -> None:
    r = ask("u_main", "السلام عليكم")
    assert r.decision == "guided_main_menu" and "أدوية" in r.reply and "بحث باسم منتج" in r.reply, r.reply

    meds = ask("u_meds", "أدوية")
    assert meds.decision == "guided_medicine_menu" and "معدة" in meds.reply and "مسكنات" in meds.reply, meds.reply
    assert "السعر" not in meds.reply

    supp = ask("u_supp", "مكملات وفيتامينات")
    assert supp.decision.startswith("guided") and "حديد" in supp.reply and "فيتامين D" in supp.reply, supp.reply
    iron = ask("u_supp", "1")
    assert iron.decision == "guided_products" and "Feroglobin" in iron.reply and "Vitamin D" not in iron.reply, iron.reply

    skin = ask("u_skin", "عناية بالبشرة")
    assert skin.decision.startswith("guided") and "غسول وجه" in skin.reply, skin.reply
    face = ask("u_skin", "غسول وجه")
    assert face.decision == "guided_ask_skin_type", face.reply
    oily = ask("u_skin", "دهنية")
    assert oily.decision == "guided_products" and "Bioderma Sebium" in oily.reply, oily.reply
    assert "CeraVe Hydrating" not in oily.reply, oily.reply
    assert_no_customer_hidden(oily.reply)

    hair = ask("u_hair", "عناية بالشعر")
    assert hair.decision.startswith("guided") and "شامبو" in hair.reply, hair.reply
    shampoo = ask("u_hair", "شامبو")
    assert shampoo.decision == "guided_products" and "Shampoo" in shampoo.reply and "Bioderma" not in shampoo.reply, shampoo.reply

    baby = ask("u_baby", "أطفال")
    assert baby.decision.startswith("guided") and "شامبو/غسول أطفال" in baby.reply, baby.reply
    bw = ask("u_baby", "شامبو/غسول أطفال")
    assert bw.decision == "guided_products" and "Johnson Baby Wash" in bw.reply and "Bioderma" not in bw.reply, bw.reply

    dev = ask("u_dev", "أجهزة ومستلزمات")
    assert dev.decision.startswith("guided") and "قياس ضغط" in dev.reply, dev.reply
    bp = ask("u_dev", "قياس ضغط")
    assert bp.decision == "guided_products" and "Omron" in bp.reply and "Shampoo" not in bp.reply, bp.reply


def test_number_pagination_exact_search_and_orders() -> None:
    first = ask("u_order", "مكملات وفيتامينات")
    assert first.decision.startswith("guided"), first.reply
    products = ask("u_order", "حديد")
    assert products.decision == "guided_products", products.reply
    selected = ask("u_order", "1")
    assert selected.decision == "guided_product_selected" and "السعر" in selected.reply and "للحجز" in selected.reply, selected.reply
    yes = ask("u_order", "نعم")
    assert yes.decision == "order_quantity_requested" and "كم الكمية" in yes.reply, yes.reply
    done = ask("u_order", "2")
    assert done.decision == "order_created", done.reply

    exact = ask("u_exact", "Photoblok 50+")
    assert exact.decision in {"matched", "matched_unknown_availability"} and "Photoblok" in exact.reply and "السعر" in exact.reply, exact.reply
    zofran = ask("u_zof", "Zofran 4 mg tablets")
    assert zofran.decision in {"matched", "matched_unknown_availability"} and "Zofran" in zofran.reply and "السعر" in zofran.reply, zofran.reply

    generic = ask("u_generic", "Cerave")
    assert generic.decision.startswith("guided") and "السعر" not in generic.reply, generic.reply
    flagyl = ask("u_flagyl", "Flagyl")
    assert "بديل" not in flagyl.reply and "السعر" not in flagyl.reply, flagyl.reply


def main() -> None:
    assert not str(database.DB_FILE).startswith("/opt/pricebot"), database.DB_FILE
    seed_master_catalog()
    test_db_safety_helpers()
    test_indexes_do_not_change_products()
    test_deploy_script_safety_contract()
    test_guided_routes_and_master_catalog_filters()
    test_number_pagination_exact_search_and_orders()
    print("ACCEPTANCE_TESTS_FINAL_V22_4_DB_SAFETY_GUIDED_OK")
    print(f"DB_PROTECTION_OK | temp_db={database.DB_FILE} | products_count={database.count_products()} | guided_rows={database.count_guided_catalog_index()}")


if __name__ == "__main__":
    try:
        main()
    finally:
        shutil.rmtree(TMP_DIR, ignore_errors=True)
