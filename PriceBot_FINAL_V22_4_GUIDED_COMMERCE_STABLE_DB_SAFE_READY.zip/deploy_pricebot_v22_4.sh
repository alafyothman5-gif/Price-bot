#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/pricebot"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
DB_PATH="${PRICEBOT_DB_FILE:-$APP_DIR/pricebot.db}"
MIN_PRODUCTS="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
BACKUP_ROOT="/root/pricebot_backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/pricebot_v22_4_predeploy_$STAMP"

log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') | $*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }
run_timeout(){ local seconds="$1"; shift; timeout --preserve-status "${seconds}s" "$@"; }

[[ "$(pwd)" == "$APP_DIR" ]] || fail "Run from $APP_DIR only. Refusing to touch other projects."
[[ -f app.py && -f database.py && -d services && -d tools ]] || fail "This is not a PriceBot project directory."
if [[ -d /opt/medmcq || -d /opt/MedMCQ ]]; then
  log "SAFE_CHECK: MedMCQ detected and will not be touched."
fi
[[ -f "$DB_PATH" ]] || fail "pricebot.db not found at $DB_PATH. This deploy refuses to create or replace production product DB."

validate_db(){
  local stage="$1"
  local expected_arg=()
  if [[ "${2:-}" != "" ]]; then expected_arg=(--expected-count "$2"); fi
  PRICEBOT_DB_FILE="$DB_PATH" python3 tools/db_safety.py validate --db "$DB_PATH" --min-products "$MIN_PRODUCTS" --label "$stage" "${expected_arg[@]}"
}

restore_and_fail(){
  local reason="$1"
  log "DEPLOY_ROLLBACK_START | reason=$reason"
  sudo systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true
  if [[ -f "$BACKUP_DIR/pricebot.db" ]]; then
    PRICEBOT_DB_FILE="$DB_PATH" python3 tools/db_safety.py restore --backup "$BACKUP_DIR/pricebot.db" --db "$DB_PATH" --min-products "$MIN_PRODUCTS" || true
  fi
  if [[ -f "$BACKUP_DIR/code.tar.gz" ]]; then
    tar -xzf "$BACKUP_DIR/code.tar.gz" -C "$APP_DIR" || true
  fi
  sudo systemctl start "$SERVICE_NAME" >/dev/null 2>&1 || true
  fail "$reason | rollback_attempted=1 | backup=$BACKUP_DIR"
}

log "DB validation before deploy."
validate_db "before_deploy"
PRODUCTS_BEFORE="$(PRICEBOT_DB_FILE="$DB_PATH" python3 tools/db_safety.py count --db "$DB_PATH" --table products)"
[[ "$PRODUCTS_BEFORE" =~ ^[0-9]+$ ]] || fail "Invalid products count: $PRODUCTS_BEFORE"
if (( PRODUCTS_BEFORE < MIN_PRODUCTS )); then
  fail "DB_PROTECTION_FAILED | stage=before_deploy | products_count=$PRODUCTS_BEFORE | min=$MIN_PRODUCTS"
fi
log "DB_PROTECTION_OK | stage=before_deploy | products_count=$PRODUCTS_BEFORE"

mkdir -p "$BACKUP_DIR"
log "Creating safe pre-deploy backup: $BACKUP_DIR"
tar --exclude='./venv' --exclude='./.venv' --exclude='./__pycache__' --exclude='./.pytest_cache' --exclude='./.git' --exclude='./backups' \
    --exclude='./pricebot.db' --exclude='./pricebot.db-*' --exclude='./.env' \
    -czf "$BACKUP_DIR/code.tar.gz" -C "$APP_DIR" .
PRICEBOT_DB_FILE="$DB_PATH" python3 tools/db_safety.py backup --db "$DB_PATH" --out-dir "$BACKUP_DIR" --min-products "$MIN_PRODUCTS"
[[ -f "$APP_DIR/.env" ]] && cp -a "$APP_DIR/.env" "$BACKUP_DIR/.env"
[[ -d "$APP_DIR/media" ]] && tar -czf "$BACKUP_DIR/media.tar.gz" -C "$APP_DIR" media
[[ -d "$APP_DIR/uploads" ]] && tar -czf "$BACKUP_DIR/uploads.tar.gz" -C "$APP_DIR" uploads
[[ -f "/etc/systemd/system/$SERVICE_NAME" ]] && cp -a "/etc/systemd/system/$SERVICE_NAME" "$BACKUP_DIR/$SERVICE_NAME"
log "PRICEBOT_BACKUP_OK | path=$BACKUP_DIR"

log "Installing dependencies safely."
python3 -m venv venv
# shellcheck disable=SC1091
source venv/bin/activate
run_timeout 60 python -m pip install --upgrade pip || restore_and_fail "pip upgrade failed"
run_timeout 120 pip install -r requirements.txt || restore_and_fail "requirements install failed"

log "Compile check."
run_timeout 60 python -m compileall -q . || restore_and_fail "compileall failed"

log "Running tests on isolated temp DB only."
TEST_DB_DIR="$(mktemp -d /tmp/pricebot_v22_4_tests_XXXXXX)"
run_timeout 90 env PRICEBOT_DB_FILE="$TEST_DB_DIR/pytest.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python -m pytest -q || restore_and_fail "pytest failed"
run_timeout 90 env PRICEBOT_DB_FILE="$TEST_DB_DIR/v22_2.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_2_stability_speed.py || restore_and_fail "V22.2 acceptance failed"
run_timeout 90 env PRICEBOT_DB_FILE="$TEST_DB_DIR/company.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_company_grade.py || restore_and_fail "V22 company-grade acceptance failed"
run_timeout 90 env PRICEBOT_DB_FILE="$TEST_DB_DIR/v22_3.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_3_guided_commerce.py || restore_and_fail "V22.3 guided acceptance failed"
run_timeout 120 env PRICEBOT_DB_FILE="$TEST_DB_DIR/v22_4.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_4_db_safety_guided.py || restore_and_fail "V22.4 DB safety/guided acceptance failed"
validate_db "after_tests" "$PRODUCTS_BEFORE" || restore_and_fail "DB changed during isolated tests"

log "Running additive migrations inside production DB guard."
run_timeout 30 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python - <<'PY' || restore_and_fail "migration failed"
import database
from tools import db_safety
before = database.count_products()
db_safety.validate_database(database.DB_FILE, min_products=int(__import__('os').getenv('PRICEBOT_MIN_PRODUCTS_GUARD','1000')), expected_count=before, label='before_migration')
database.init_db()
database.ensure_v19_tables()
database.ensure_v22_tables()
after = database.count_products()
if after != before:
    raise SystemExit(f"DB_PROTECTION_FAILED | stage=migration | before={before} | after={after}")
db_safety.validate_database(database.DB_FILE, min_products=int(__import__('os').getenv('PRICEBOT_MIN_PRODUCTS_GUARD','1000')), expected_count=before, label='after_migration')
print(f"DB_PROTECTION_OK | stage=migration | products_count={after}")
PY
validate_db "after_migration" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after migration"

log "Rebuilding search index safely."
run_timeout 75 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/rebuild_search_index.py || restore_and_fail "search index rebuild failed"
validate_db "after_search_index" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after search index"

log "Rebuilding product navigator index safely."
run_timeout 75 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/rebuild_product_nav_index.py || restore_and_fail "product nav index rebuild failed"
validate_db "after_nav_index" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after nav index"

log "Rebuilding guided catalog index safely."
if [[ -f "$APP_DIR/products_master_v22_ready.xlsx" ]]; then
  log "GUIDED_CATALOG_SOURCE | source=products_master_v22_ready.xlsx"
  run_timeout 75 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/build_guided_catalog_index.py --input "$APP_DIR/products_master_v22_ready.xlsx" --write-db --report "$APP_DIR/guided_catalog_tree_report.xlsx" --min-products "$MIN_PRODUCTS" || restore_and_fail "guided catalog index rebuild from master Excel failed"
else
  log "GUIDED_CATALOG_SOURCE | source=production_db_products"
  run_timeout 75 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/build_guided_catalog_index.py --db --write-db --report "$APP_DIR/guided_catalog_tree_report.xlsx" --min-products "$MIN_PRODUCTS" || restore_and_fail "guided catalog index rebuild from DB failed"
fi
validate_db "after_guided_index" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after guided index"

log "Restarting service without long hang."
sudo systemctl daemon-reload || true
if ! run_timeout 15 sudo systemctl stop "$SERVICE_NAME"; then
  log "SERVICE_STOP_TIMEOUT | action=term_kill_continue"
  sudo systemctl kill -s TERM "$SERVICE_NAME" || true
  sleep 2
fi
run_timeout 20 sudo systemctl start "$SERVICE_NAME" || restore_and_fail "service start failed"

log "Waiting for health check."
HEALTH_OK=0
for _ in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${PRICEBOT_PORT}/health" >/tmp/pricebot_v22_4_health.json 2>/dev/null; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done
if [[ "$HEALTH_OK" != "1" ]]; then
  sudo systemctl status "$SERVICE_NAME" --no-pager -l || true
  restore_and_fail "health check failed after 20s"
fi
cat /tmp/pricebot_v22_4_health.json && echo
validate_db "after_health" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after health"

log "PRICEBOT_V22_4_GUIDED_COMMERCE_STABLE_DB_SAFE_DEPLOY_OK | products_count=$PRODUCTS_BEFORE | backup=$BACKUP_DIR"
