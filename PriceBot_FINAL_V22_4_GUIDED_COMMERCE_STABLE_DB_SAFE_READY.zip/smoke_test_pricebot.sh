#!/usr/bin/env bash
set -Eeuo pipefail
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
cd "$(dirname "$0")"

python -m compileall -q .
SMOKE_TMP="$(mktemp -d /tmp/pricebot_smoke_XXXXXX)"
timeout 90 env PRICEBOT_DB_FILE="$SMOKE_TMP/v22_2.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_2_stability_speed.py
timeout 90 env PRICEBOT_DB_FILE="$SMOKE_TMP/company.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_company_grade.py
timeout 90 env PRICEBOT_DB_FILE="$SMOKE_TMP/v22_3.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_3_guided_commerce.py
timeout 120 env PRICEBOT_DB_FILE="$SMOKE_TMP/v22_4.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_4_db_safety_guided.py

if [[ -f pricebot.db ]]; then
  python tools/db_safety.py validate --db pricebot.db --min-products "${PRICEBOT_MIN_PRODUCTS_GUARD:-0}" --label smoke_before
  BEFORE=$(python tools/db_safety.py count --db pricebot.db --table products)
  timeout 75 env PRICEBOT_MIN_PRODUCTS_GUARD=0 python tools/rebuild_search_index.py >/tmp/pricebot_search_index_smoke.log || cat /tmp/pricebot_search_index_smoke.log
  timeout 75 env PRICEBOT_MIN_PRODUCTS_GUARD=0 python tools/rebuild_product_nav_index.py >/tmp/pricebot_nav_index_smoke.log || cat /tmp/pricebot_nav_index_smoke.log
  timeout 75 env PRICEBOT_MIN_PRODUCTS_GUARD=0 python tools/build_guided_catalog_index.py --db --write-db --report guided_catalog_tree_report.xlsx >/tmp/pricebot_guided_index_smoke.log || cat /tmp/pricebot_guided_index_smoke.log
  AFTER=$(python tools/db_safety.py count --db pricebot.db --table products)
  if [[ "$BEFORE" != "$AFTER" ]]; then
    echo "DB_PROTECTION_FAILED | before=$BEFORE | after=$AFTER" >&2
    exit 1
  fi
  python tools/db_safety.py validate --db pricebot.db --min-products "${PRICEBOT_MIN_PRODUCTS_GUARD:-0}" --expected-count "$BEFORE" --label smoke_after
  echo "DB_PROTECTION_OK | products_count=$AFTER"
else
  echo "INFO: pricebot.db not found in current directory; skipped live index smoke."
fi

if curl -fsS "http://127.0.0.1:${PRICEBOT_PORT}/health" >/tmp/pricebot_health_smoke.log 2>/dev/null; then
  cat /tmp/pricebot_health_smoke.log
  echo
else
  echo "INFO: local service not running on 127.0.0.1:${PRICEBOT_PORT}; code-level smoke passed."
fi

echo "PRICEBOT_V22_4_GUIDED_COMMERCE_STABLE_DB_SAFE_SMOKE_TEST_OK"
