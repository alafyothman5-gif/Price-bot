# PriceBot V22.1 Catalog Alignment

هذه النسخة لا تعيد كتابة محرك Matching/Vision. التغيير الأساسي هو جعل V22 يعمل مع الكتالوج الحالي حتى لو كانت الأعمدة ضعيفة مثل `category=other` و `form=product` وغياب `skin_type/use_case`.

## الجديد

- إضافة `services/catalog_alignment.py` لاستنتاج آمن من الاسم والـ aliases والـ OCR keywords.
- إضافة `tools/build_v22_company_catalog.py` لإنتاج:
  - `products_v22_company_catalog_ready.xlsx`
  - `products_v22_needs_review.xlsx`
  - `catalog_v22_alignment_report.xlsx`
- إضافة `tools/run_v22_catalog_acceptance.py` لاختبار الكتالوج الحقيقي أو ملف Excel.
- إضافة `acceptance_tests_final_v22_1_catalog_aligned.py`.
- تحديث Search Engine وNavigator للاستفادة من alignment دون تعديل قاعدة المنتجات.
- تحديث deploy/smoke حتى يستخدم `PRICEBOT_PORT` بدل تثبيت 8000.

## ما لم يتغير

- لا يوجد legacy fuzzy fallback.
- لا سعر عند الغموض.
- لا بدائل دوائية تلقائية.
- لا AI يقرر السعر أو التوفر.
- لا حذف أو استبدال للمنتجات الحالية.

## تشغيل alignment على السيرفر

```bash
cd /opt/pricebot
python tools/build_v22_company_catalog.py --db pricebot.db --out-dir catalog_v22_alignment
python tools/run_v22_catalog_acceptance.py --db pricebot.db
```

## ملاحظة

ملفات Excel المرفقة مع التسليم تم توليدها في بيئة لا تحتوي على `pricebot.db` الإنتاجية، لذلك هي نموذج/قالب توضيحي. الملفات النهائية الفعلية يجب توليدها على السيرفر من قاعدة المنتجات الحالية بالأوامر أعلاه.
