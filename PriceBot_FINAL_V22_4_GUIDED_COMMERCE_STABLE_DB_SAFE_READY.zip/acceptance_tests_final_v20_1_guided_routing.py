#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V20.1 urgent Guided Finder routing acceptance tests.

These tests cover the production bug where the main menu appeared correctly,
but the next reply ("2" / "تصفح الأقسام" / WhatsApp list id) fell through to
product search and returned NOT_AVAILABLE.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

TMP_DIR = tempfile.mkdtemp(prefix="pricebot_v20_1_guided_")
os.environ["PRICEBOT_DB_FILE"] = str(Path(TMP_DIR) / "acceptance_v20_1.db")
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["PRICEBOT_DEBUG_ENDPOINTS"] = "false"
os.environ["PRICEBOT_ENV"] = "production"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-v20-1-code"
os.environ["MERCHANT_PORTAL_ENABLED"] = "true"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"
os.environ["PRICEBOT_WHATSAPP_INTERACTIVE_ENABLED"] = "true"

import database  # noqa: E402
import matcher  # noqa: E402
from app import extract_interactive_text  # noqa: E402

CATALOG = [
    {"product_id":"P1","name":"Photoblok 50+","brand":"Photoblok","product_family":"Photoblok 50+","category":"cosmetic","form":"sunscreen","body_area":"face","use_case":"sun_protection","skin_type":"normal_combination_skin","size":"50ml","aliases":"Photoblok 50+","ocr_keywords":"photoblok 50 spf sunscreen face","price":"70","available":"متوفر"},
    {"product_id":"C1","name":"CeraVe Hydrating Cleanser 236ml","brand":"CeraVe","product_family":"Hydrating Cleanser","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"236ml","aliases":"cerave hydrating cleanser","ocr_keywords":"cerave hydrating cleanser dry skin face wash","price":"70","available":"متوفر"},
    {"product_id":"C2","name":"Bioderma Sebium Gel Moussant 200ml","brand":"Bioderma","product_family":"Sebium Gel Moussant","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"200ml","aliases":"bioderma sebium gel moussant","ocr_keywords":"bioderma sebium cleanser oily skin acne face wash","price":"65","available":"متوفر"},
    {"product_id":"C3","name":"La Roche Posay Effaclar Gel Cleanser 200ml","brand":"La Roche Posay","product_family":"Effaclar Gel","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"normal_oily_skin","size":"200ml","aliases":"laroche effaclar gel cleanser","ocr_keywords":"effaclar gel cleanser normal oily acne face wash","price":"75","available":"متوفر"},
    {"product_id":"C4","name":"Baby Gentle Wash 250ml","brand":"BabyBrand","product_family":"Gentle Wash","category":"cosmetic","form":"cleanser","body_area":"baby","use_case":"baby_care","skin_type":"sensitive_skin","size":"250ml","aliases":"baby wash","ocr_keywords":"baby wash kids","price":"20","available":"متوفر"},
    {"product_id":"C5","name":"Body Wash Rose 500ml","brand":"BodyBrand","product_family":"Rose Body Wash","category":"cosmetic","form":"cleanser","body_area":"body","use_case":"body_care","skin_type":"","size":"500ml","aliases":"body wash","ocr_keywords":"body wash shower gel","price":"25","available":"متوفر"},
]


def seed_catalog() -> None:
    database.init_db()
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        conn.execute("DELETE FROM conversation_state")
        for p in CATALOG:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,product_family,category,form,body_area,use_case,skin_type,size,aliases,ocr_keywords,image_ocr_keywords,price,available)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p["product_id"], p["name"], p["name"].lower(), p["brand"], p["product_family"], p["category"], p["form"], p["body_area"], p["use_case"], p["skin_type"], p["size"], p["aliases"], p["ocr_keywords"], p["ocr_keywords"], p["price"], p["available"]),
            )
        conn.commit()
    matcher.invalidate_product_cache()


def ask(phone: str, text: str):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))


def assert_not_not_available(reply: str) -> None:
    assert "غير موجود في قائمة الصيدلية" not in reply, reply
    assert "المنتج المطلوب غير موجود" not in reply, reply


def test_main_menu_number_2_opens_categories():
    phone = "route_number"
    first = ask(phone, "السلام عليكم")
    assert first.decision == "guided_main_menu", first.reply
    second = ask(phone, "2")
    assert second.decision == "guided_categories", second.reply
    assert "اختر القسم" in second.reply
    assert_not_not_available(second.reply)


def test_main_menu_label_opens_categories():
    phone = "route_label"
    first = ask(phone, "القائمة")
    assert first.decision == "guided_main_menu"
    second = ask(phone, "تصفح الأقسام")
    assert second.decision == "guided_categories", second.reply
    assert "عناية بالبشرة" in second.reply
    assert_not_not_available(second.reply)


def test_number_2_with_last_options_does_not_go_to_product_search():
    phone = "route_no_search"
    ask(phone, "مرحبا")
    result = ask(phone, "2")
    assert result.decision.startswith("guided"), result.reply
    assert result.decision != "not_available"
    assert_not_not_available(result.reply)


def test_category_label_opens_skin_care_menu():
    phone = "route_skin"
    ask(phone, "السلام عليكم")
    ask(phone, "2")
    result = ask(phone, "عناية بالبشرة")
    assert result.decision == "guided_skin_care", result.reply
    assert "ماذا تريد" in result.reply and "غسول وجه" in result.reply
    assert_not_not_available(result.reply)


def test_skin_care_face_cleanser_asks_skin_type():
    phone = "route_cleanser"
    ask(phone, "السلام عليكم")
    ask(phone, "2")
    ask(phone, "عناية بالبشرة")
    result = ask(phone, "غسول وجه")
    assert result.decision == "guided_ask_skin_type", result.reply
    assert "نوع البشرة" in result.reply and "دهنية" in result.reply
    assert "السعر" not in result.reply


def test_oily_skin_selection_filters_products():
    phone = "route_oily"
    ask(phone, "السلام عليكم")
    ask(phone, "2")
    ask(phone, "عناية بالبشرة")
    ask(phone, "غسول وجه")
    result = ask(phone, "دهنية")
    assert result.decision == "guided_products", result.reply
    assert "Bioderma Sebium" in result.reply or "Effaclar" in result.reply
    assert "Hydrating Cleanser" not in result.reply
    assert "Body Wash" not in result.reply
    assert "Baby Gentle" not in result.reply


def test_bare_number_without_menu_state_does_not_search_random_product():
    result = ask("route_bare_number", "2")
    assert result.decision == "guided_main_menu", result.reply
    assert "اختر طريقة البحث" in result.reply
    assert_not_not_available(result.reply)


def test_exact_product_still_returns_price():
    result = ask("route_exact", "Photoblok 50+")
    assert result.decision in {"matched", "matched_unknown_availability"}, result.reply
    assert "Photoblok 50+" in result.reply and "السعر" in result.reply


def test_whatsapp_interactive_payload_ids_are_extracted_and_routed():
    phone = "route_interactive"
    ask(phone, "السلام عليكم")
    raw = extract_interactive_text({"interactive": {"list_reply": {"id": "browse_categories", "title": "تصفح الأقسام"}}})
    assert raw == "browse_categories"
    result = ask(phone, raw)
    assert result.decision == "guided_categories", result.reply
    assert "اختر القسم" in result.reply


def main():
    seed_catalog()
    test_main_menu_number_2_opens_categories()
    test_main_menu_label_opens_categories()
    test_number_2_with_last_options_does_not_go_to_product_search()
    test_category_label_opens_skin_care_menu()
    test_skin_care_face_cleanser_asks_skin_type()
    test_oily_skin_selection_filters_products()
    test_bare_number_without_menu_state_does_not_search_random_product()
    test_exact_product_still_returns_price()
    test_whatsapp_interactive_payload_ids_are_extracted_and_routed()
    print("ACCEPTANCE_TESTS_FINAL_V20_1_GUIDED_ROUTING_OK")


if __name__ == "__main__":
    main()
