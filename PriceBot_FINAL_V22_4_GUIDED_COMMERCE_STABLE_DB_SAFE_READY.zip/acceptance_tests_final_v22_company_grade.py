#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V22 Company-Grade Search + Navigator Engine acceptance tests."""
from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path

TMP_DIR = tempfile.mkdtemp(prefix="pricebot_v22_")
os.environ["PRICEBOT_DB_FILE"] = str(Path(TMP_DIR) / "acceptance_v22.db")
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["PRICEBOT_DEBUG_ENDPOINTS"] = "false"
os.environ["PRICEBOT_ENV"] = "production"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-v22-code"
os.environ["MERCHANT_PORTAL_ENABLED"] = "true"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"
os.environ["PRICEBOT_WHATSAPP_INTERACTIVE_ENABLED"] = "true"

import database  # noqa: E402
import matcher  # noqa: E402
import matcher_v4  # noqa: E402
from matcher_v2 import DecisionType  # noqa: E402
from services import guided_finder, product_navigator, search_engine  # noqa: E402
from tools.rebuild_search_index import rebuild_search_index  # noqa: E402
from tools.rebuild_product_nav_index import rebuild_product_nav_index  # noqa: E402

CATALOG = [
    {"product_id":"P1","name":"Photoblok 50+","brand":"Photoblok","product_family":"Photoblok 50+","category":"cosmetic","form":"sunscreen","body_area":"face","use_case":"sun_protection","skin_type":"normal_combination_skin","size":"50ml","aliases":"Photoblok 50+","ocr_keywords":"photoblok 50 spf sunscreen face","price":"70","available":"متوفر"},
    {"product_id":"P2","name":"123 Extra","brand":"123","product_family":"Extra","category":"medicine","form":"tablet","strength":"","size":"","aliases":"123, Extra 1,2,3, 1 2 3 Extra","ocr_keywords":"123 extra","price":"15","available":"متوفر"},
    {"product_id":"G1","name":"Gyno-Daktarin Vag Cream 40g","brand":"Gyno-Daktarin","product_family":"Gyno-Daktarin","category":"medicine","form":"cream","strength":"","size":"40g","aliases":"gyno-daktarin vag cream, gyno daktarin vaginal cream","ocr_keywords":"gyno daktarin vag cream","price":"33","available":"متوفر"},
    {"product_id":"F1","name":"Flagyl Tablet 500mg","brand":"Flagyl","product_family":"Flagyl","category":"medicine","form":"tablet","strength":"500mg","aliases":"فلاجيل 500 اقراص, flagyl 500 tablet","ocr_keywords":"flagyl tablet 500mg","price":"20","available":"متوفر"},
    {"product_id":"F2","name":"Flagyl Suppository 500mg","brand":"Flagyl","product_family":"Flagyl","category":"medicine","form":"suppository","strength":"500mg","aliases":"فلاجيل 500 تحاميل, flagyl 500 suppository","ocr_keywords":"flagyl suppository 500mg","price":"22","available":"متوفر"},
    {"product_id":"F3","name":"Flagyl Syrup 125mg/5ml","brand":"Flagyl","product_family":"Flagyl","category":"medicine","form":"syrup","strength":"125mg/5ml","aliases":"فلاجيل شراب, flagyl syrup","ocr_keywords":"flagyl syrup 125mg 5ml","price":"18","available":"متوفر"},
    {"product_id":"A1","name":"Amoclan Syrup 457mg/5ml","brand":"Amoclan","product_family":"Amoclan","category":"medicine","form":"syrup","strength":"457mg/5ml","aliases":"amoclan syrup 457, اموكلان شراب 457","ocr_keywords":"amoclan syrup 457","price":"31","available":"متوفر"},
    {"product_id":"C1","name":"CeraVe Hydrating Cleanser 236ml","brand":"CeraVe","product_family":"Hydrating Cleanser","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"236ml","aliases":"cerave hydrating cleanser","ocr_keywords":"cerave hydrating cleanser dry skin face wash","price":"70","available":"متوفر"},
    {"product_id":"C2","name":"Bioderma Sebium Gel Moussant 200ml","brand":"Bioderma","product_family":"Sebium Gel Moussant","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"200ml","aliases":"bioderma sebium gel moussant","ocr_keywords":"bioderma sebium cleanser oily skin acne face wash","price":"65","available":"متوفر"},
    {"product_id":"C3","name":"La Roche Posay Effaclar Gel Cleanser 200ml","brand":"La Roche Posay","product_family":"Effaclar Gel","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"normal_oily_skin","size":"200ml","aliases":"laroche effaclar gel cleanser","ocr_keywords":"effaclar gel cleanser normal oily acne face wash","price":"75","available":"متوفر"},
    {"product_id":"C4","name":"Baby Gentle Wash 250ml","brand":"BabyBrand","product_family":"Gentle Wash","category":"cosmetic","form":"cleanser","body_area":"baby","use_case":"baby_care","skin_type":"sensitive_skin","size":"250ml","aliases":"baby wash","ocr_keywords":"baby wash kids","price":"20","available":"متوفر"},
    {"product_id":"C5","name":"Body Wash Rose 500ml","brand":"BodyBrand","product_family":"Rose Body Wash","category":"cosmetic","form":"cleanser","body_area":"body","use_case":"body_care","skin_type":"","size":"500ml","aliases":"body wash","ocr_keywords":"body wash shower gel","price":"25","available":"متوفر"},
]
# Add many oily face cleansers to test pagination.
for i in range(1, 12):
    CATALOG.append({"product_id":f"O{i}","name":f"Oily Face Cleanser {i} 150ml","brand":"OilyBrand","product_family":f"Oily Cleanser {i}","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"150ml","aliases":f"oily cleanser {i}","ocr_keywords":f"oily acne face cleanser {i}","price":str(40+i),"available":"متوفر"})


def seed_catalog() -> None:
    database.init_db()
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        conn.execute("DELETE FROM conversation_state")
        for p in CATALOG:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,product_family,category,form,strength,body_area,use_case,skin_type,size,aliases,ocr_keywords,image_ocr_keywords,price,available,quality_status,search_mode)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p.get("product_id"), p["name"], p["name"].lower(), p.get("brand",""), p.get("product_family",""), p.get("category",""), p.get("form",""), p.get("strength",""), p.get("body_area",""), p.get("use_case",""), p.get("skin_type",""), p.get("size",""), p.get("aliases",""), p.get("ocr_keywords",""), p.get("ocr_keywords",""), p.get("price",""), p.get("available",""), p.get("quality_status",""), p.get("search_mode","")),
            )
        conn.commit()
    matcher.invalidate_product_cache()


def ask(phone: str, text: str):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))


def test_rebuild_indexes():
    report1 = rebuild_search_index()
    report2 = rebuild_product_nav_index()
    assert report1["indexed"] == len(CATALOG), report1
    assert report2["indexed"] == len(CATALOG), report2
    sections = product_navigator.available_sections(CATALOG)
    labels = {x["label"] for x in sections}
    assert "أدوية" in labels and "عناية بالبشرة" in labels


def assert_fast_exact(query: str, expected: str):
    started = time.perf_counter()
    r = ask("exact_" + expected, query)
    elapsed_ms = (time.perf_counter() - started) * 1000
    assert elapsed_ms < 300, f"exact lookup too slow {query}: {elapsed_ms:.1f}ms"
    assert r.decision in {"matched", "matched_unknown_availability"}, (query, r.decision, r.reply)
    assert expected.lower() in r.reply.lower(), r.reply
    assert "السعر" in r.reply, r.reply


def test_exact_fast_paths():
    assert_fast_exact("Photoblok 50+", "Photoblok")
    assert_fast_exact("123", "123")
    assert_fast_exact("Extra 1,2,3", "123")
    assert_fast_exact("gyno-daktarin vag cream", "Gyno-Daktarin")


def test_specific_unavailable_and_generic_guided():
    r = ask("formag", "Formag")
    assert r.decision in {"unavailable", "low_confidence"}
    assert "السعر" not in r.reply
    g = ask("wash", "غسول")
    assert g.decision.startswith("guided") and "السعر" not in g.reply


def test_skin_care_flow_and_filters():
    r1 = ask("faceflow", "غسول وجه")
    assert r1.decision == "guided_ask_skin_type"
    r2 = ask("oilyflow", "غسول للبشرة الدهنية")
    assert r2.decision == "guided_products", r2.reply
    assert "Hydrating Cleanser" not in r2.reply
    assert "Body Wash" not in r2.reply and "Baby Gentle" not in r2.reply
    assert "المزيد" in r2.reply
    r3 = ask("oilyflow", "المزيد")
    assert r3.decision == "guided_products" and "Oily Face Cleanser" in r3.reply


def test_brand_and_medicine_navigator():
    b = ask("ceravebrand", "Cerave")
    assert b.decision == "guided_brand_type" and "السعر" not in b.reply
    m = ask("mednav", "أدوية")
    assert m.decision == "guided_medicine_menu", m.reply
    assert "مسكنات" in m.reply or "بحث باسم دواء" in m.reply


def test_flagyl_ambiguous_and_no_price():
    r = ask("flagyl", "فلاجيل")
    assert r.decision in {"ambiguous", "ask_form", "ask_strength"}, (r.decision, r.reply)
    assert "Flagyl" in r.reply or "فلاجيل" in r.reply
    assert "السعر" not in r.reply


def test_number_selection_and_order():
    first = ask("select_v22", "غسول للبشرة الدهنية")
    assert first.decision == "guided_products"
    selected = ask("select_v22", "1")
    assert selected.decision == "guided_product_selected"
    assert "السعر" in selected.reply
    qty_prompt = ask("select_v22", "نعم")
    assert qty_prompt.decision == "order_quantity_requested" and "كم الكمية" in qty_prompt.reply, qty_prompt.reply
    order = ask("select_v22", "1")
    assert order.decision == "order_created", order.reply


def test_active_guided_prevents_numeric_product_search():
    ask("activeflow", "السلام عليكم")
    r = ask("activeflow", "2")
    assert r.decision == "guided_categories" and "المنتج المطلوب غير موجود" not in r.reply


def test_search_engine_policy_direct():
    d = search_engine.search_products("كريم", CATALOG)
    assert d.decision == search_engine.DECISION_GUIDED
    d2 = search_engine.search_products("Formag", CATALOG)
    assert d2.decision == search_engine.DECISION_NOT_AVAILABLE


def test_invalid_vision_output_rejected():
    ci = matcher_v4.build_catalog_index(CATALOG)
    d = matcher_v4.resolve_image_extraction_from_index({
        "image_type":"product_packaging", "clarity":"good", "confidence":0.95,
        "brand":"CeraVe", "product_name":"Hydrating Cleanser", "price":"50", "availability":"available",
    }, ci)
    assert d.decision_type == DecisionType.LOW_CONFIDENCE


def main():
    seed_catalog()
    test_rebuild_indexes()
    test_exact_fast_paths()
    test_specific_unavailable_and_generic_guided()
    test_skin_care_flow_and_filters()
    test_brand_and_medicine_navigator()
    test_flagyl_ambiguous_and_no_price()
    test_number_selection_and_order()
    test_active_guided_prevents_numeric_product_search()
    test_search_engine_policy_direct()
    test_invalid_vision_output_rejected()
    print("ACCEPTANCE_TESTS_FINAL_V22_COMPANY_GRADE_OK")


if __name__ == "__main__":
    main()
