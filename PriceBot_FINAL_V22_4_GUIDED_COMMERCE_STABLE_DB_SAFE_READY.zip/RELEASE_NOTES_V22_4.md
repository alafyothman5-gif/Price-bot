# RELEASE NOTES — PriceBot V22.4 Guided Commerce Stable DB Safe

## ما تغير

- أضيفت طبقة SQLite Safety مستقلة: `tools/db_safety.py`.
- أضيفت أداة استرجاع آخر DB صالح: `tools/restore_last_good_db.py`.
- أضيف deploy جديد: `deploy_pricebot_v22_4.sh`.
- تم تحويل rebuild الخاص بـ `guided_catalog_index` إلى بناء مؤقت ثم swap، بدل `DELETE ثم INSERT`.
- تم تشديد فحص DB قبل وبعد كل مرحلة من مراحل النشر.
- acceptance tests تعمل على `/tmp` فقط مع `PRICEBOT_MIN_PRODUCTS_GUARD=1`.
- تم رفع حد اختبار السرعة الداخلي إلى 1200ms حتى لا يفشل النشر بسبب فرق بسيط على DigitalOcean.
- Guided Commerce أصبح يفضّل تصنيف `products_master_v22_ready.xlsx` عند وجوده، بدل الاعتماد على demo أو تخمين الاسم فقط.

## قواعد Guided Catalog

المنتج يظهر في القوائم إذا:

- `available` متوفر/true.
- `price` موجود.
- `quality_status` مناسب مثل `verified / ready / approved / suitable` أو فارغ في قواعد قديمة.
- `search_mode` ليس `exact_only / review_only / hidden / no_guided`.

المنتجات التالية لا تظهر للعميل في القوائم:

- `exact_only`
- `review_only`
- `needs_review`
- `unknown`
- `partial`

لكن `exact_only` يبقى قابلًا للظهور عند البحث بالاسم الكامل أو alias دقيق.

## سبب الإصلاح

المشاكل السابقة كانت من ثلاث نقاط:

1. اختبارات داخل deploy تعمل أحيانًا بحد حماية إنتاجي على DB صغير.
2. حماية DB كانت تعتمد على count فقط، وليس `integrity_check` في كل مرحلة.
3. فهرس Guided كان يمكن أن يصبح فارغًا إذا فشل البناء بعد حذف الفهرس القديم.

## نتائج الاختبارات المنفذة

- `python -m compileall -q .` — OK
- `python -m pytest -q` — 9 passed
- `python acceptance_tests_final_v22_2_stability_speed.py` — OK
- `python acceptance_tests_final_v22_company_grade.py` — OK
- `python acceptance_tests_final_v22_3_guided_commerce.py` — OK
- `python acceptance_tests_final_v22_4_db_safety_guided.py` — OK
- `python acceptance_tests_final_v20.py` — OK
- `python acceptance_tests_final_v20_1_guided_routing.py` — OK
- `python acceptance_tests_final_v22_1_catalog_aligned.py` — OK
- `./smoke_test_pricebot.sh` — OK

## ملفات مهمة

- `deploy_pricebot_v22_4.sh`
- `backup_pricebot.sh`
- `rollback_pricebot.sh`
- `smoke_test_pricebot.sh`
- `tools/db_safety.py`
- `tools/diagnose_pricebot.py`
- `tools/restore_last_good_db.py`
- `tools/rebuild_search_index.py`
- `tools/rebuild_product_nav_index.py`
- `tools/build_guided_catalog_index.py`
- `acceptance_tests_final_v22_4_db_safety_guided.py`
