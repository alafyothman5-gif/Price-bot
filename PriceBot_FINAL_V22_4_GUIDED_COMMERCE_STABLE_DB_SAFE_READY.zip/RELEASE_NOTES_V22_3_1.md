# PriceBot V22.3.1 Guided Commerce Full Pass

## Scope
This is a corrective release over V22.3. It does not add new product features and does not include `.env`, `pricebot.db`, or catalog/demo Excel files.

## Root cause
`test_brand_and_medicine_navigator` failed because V22.3 routed brand-only cosmetic input such as `Cerave` too late. The exact fast path correctly refused to price brand-only input, but Guided Commerce did not consume the brand-only query before the strict V4 matcher. V4 returned a safe clarification with decision `ambiguous`, while the company-grade acceptance test requires the Guided decision `guided_brand_type`.

## Fix
- Restored brand-only cosmetic routing inside `services/guided_finder.py` before free-text product matching.
- Added brand type menus for common skincare brands without returning price or availability.
- Kept Medicine Navigator intact: medicine families such as Flagyl still use medicine-variant clarification and do not become product search guesses.
- Kept exact full-name search before broad guided routing, so names such as `Photoblok 50+`, `123`, and `gyno-daktarin vag cream` still resolve quickly.
- Prevented `exact_only` products from appearing in broad Guided product lists while preserving exact lookup.
- Preserved V22.3 order flow: selecting a product, typing `نعم`, then entering quantity creates the order.

## Test results
Passed:

```bash
python -m compileall -q .
python -m pytest -q
python acceptance_tests_final_v20.py
python acceptance_tests_final_v20_1_guided_routing.py
python acceptance_tests_final_v22_1_catalog_aligned.py
python acceptance_tests_final_v22_2_stability_speed.py
python acceptance_tests_final_v22_company_grade.py
python acceptance_tests_final_v22_3_guided_commerce.py
```

Required command set passed:

```bash
python -m compileall -q .
python -m pytest -q
python acceptance_tests_final_v22_2_stability_speed.py
python acceptance_tests_final_v22_company_grade.py
python acceptance_tests_final_v22_3_guided_commerce.py
```
