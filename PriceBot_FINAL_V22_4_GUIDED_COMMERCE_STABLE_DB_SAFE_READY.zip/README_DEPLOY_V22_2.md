# PriceBot FINAL V22.2 — Stable / Fast / Safe Deploy

اسم النسخة:

`PriceBot_FINAL_V22_2_STABLE_FAST_SAFE_READY.zip`

هدف هذه النسخة ليس إضافة ميزات جديدة. الهدف هو حماية قاعدة المنتجات، تسريع الردود النصية والقوائم، ومنع تعطل البوت بسبب الفهرسة أو إعادة التشغيل.

## القواعد التي تطبقها النسخة

- لا تلمس MedMCQ.
- لا ترفع ولا تستبدل `.env`.
- لا ترفع ولا تستبدل `pricebot.db`.
- لا تحذف جدول `products` ولا تفرغه.
- لا تعمل `replace` للمنتجات.
- `rebuild_search_index` و `rebuild_product_nav_index` يبنيان جداول فهرسة فقط.
- إذا فشل بناء الفهرس، يعمل البوت على الفهرس القديم أو exact DB fallback.
- التحية والقوائم لا تدخل product search.
- exact lookup يعمل عبر SQLite/index fast path قبل أي matcher ثقيل.

## أمر النشر

بعد رفع الملفات إلى `/opt/pricebot`، شغل:

```bash
cd /opt/pricebot && chmod +x deploy_pricebot_v22_2.sh backup_pricebot.sh rollback_pricebot.sh smoke_test_pricebot.sh tools/*.py && ./deploy_pricebot_v22_2.sh
```

السكربت يرفض التشغيل خارج `/opt/pricebot` حتى لا يلمس مشاريع أخرى.

## ماذا يفعل deploy_pricebot_v22_2.sh؟

1. يعمل backup كامل قبل أي خطوة داخل `/root/pricebot_backups/`.
2. يحفظ `.env` و `pricebot.db` و `media` و `uploads` خارج تبديل الكود.
3. يفحص عدد المنتجات قبل النشر، ويوقف النشر إذا كان أقل من `1000` افتراضيًا.
4. يشغل compile check واختبارات V22.2 على قاعدة مؤقتة معزولة.
5. يشغل migrations additive فقط.
6. يفحص أن عدد المنتجات لم يتغير بعد migration.
7. يبني `product_search_index` و `product_nav_index` بمهلة 60 ثانية لكل فهرس.
8. إذا فشلت الفهرسة، لا يسقط الخدمة.
9. يعيد تشغيل الخدمة بمهلة واضحة حتى لا يعلق `systemctl`.
10. يفحص `/health` خلال 20 ثانية.
11. يفحص عدد المنتجات بعد restart.
12. إذا تغير عدد المنتجات في أي مرحلة، يوقف النشر ويرجع نسخة DB الاحتياطية.

## أوامر الفحص

تشخيص الحالة:

```bash
cd /opt/pricebot && source venv/bin/activate && python tools/diagnose_pricebot.py
```

اختبار سريع:

```bash
cd /opt/pricebot && ./smoke_test_pricebot.sh
```

Backup يدوي:

```bash
cd /opt/pricebot && ./backup_pricebot.sh
```

Rollback للكود فقط، مع الحفاظ على DB و `.env` الحاليين:

```bash
cd /opt/pricebot && ./rollback_pricebot.sh 1
```

Rollback مع DB فقط عند الحاجة القصوى:

```bash
cd /opt/pricebot && RESTORE_DB=true ./rollback_pricebot.sh 1
```

## متغيرات اختيارية

```bash
PRICEBOT_MIN_PRODUCTS_GUARD=1000
PRICEBOT_TEXT_TIMEOUT_SECONDS=1.5
PRICEBOT_QUEUE_MAXSIZE=500
PRICEBOT_WORKERS=5
```

لا تغيّر `PRICEBOT_MIN_PRODUCTS_GUARD` إلى قيمة منخفضة على السيرفر الحقيقي إلا إذا كنت تعرف أن قاعدة المنتجات أقل من 1000.

## معيار النجاح السريع

بعد النشر يجب أن ترى في اللوجات أمثلة مثل:

```text
DB_PROTECTION_OK | stage=before_deploy | products_count=4991
INDEX_REBUILD_OK | products_before=4991 | products_after=4991
ROUTE_DECISION | type=guided_main_menu | ms=...
EXACT_FAST_PATH_DONE | query=Photoblok 50+ | ms=...
PRICEBOT_V22_2_DEPLOY_OK
```

## ملاحظة مهمة

هذه النسخة لا تطلب إعادة رفع Excel. تعمل فوق قاعدة `pricebot.db` الحالية. لا تضع `pricebot.db` ولا `.env` داخل GitHub أو داخل ZIP.
