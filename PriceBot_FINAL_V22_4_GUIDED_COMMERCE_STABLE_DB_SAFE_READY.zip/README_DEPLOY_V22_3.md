# Deploy V22.3

ارفع محتوى ZIP إلى GitHub ثم على السيرفر من داخل `/opt/pricebot` شغّل:

```bash
chmod +x deploy_pricebot_v22_3.sh smoke_test_pricebot.sh backup_pricebot.sh rollback_pricebot.sh tools/*.py
./deploy_pricebot_v22_3.sh
```

النشر يحافظ على:

- `.env`
- `pricebot.db`
- `media/`
- `uploads/`
- `backups/`

ولا يلمس MedMCQ.

بعد النشر:

```bash
./smoke_test_pricebot.sh
python tools/diagnose_pricebot.py
```
