# PriceBot V20.1 Guided Routing Fix

## الهدف
إصلاح خطأ الإنتاج الذي جعل القائمة الرئيسية تظهر، لكن اختيار `2` أو `تصفح الأقسام` أو رد WhatsApp interactive يسقط إلى Product Search ويظهر رد `المنتج المطلوب غير موجود`.

## ما تغير
- أصبح Guided Finder يطابق الاختيار بالرقم أو `id` أو النص الظاهر في الزر/القائمة.
- تم حفظ state للقائمة الرئيسية بأسماء واضحة: `current_flow=main_menu`, `last_options_type=main_menu`.
- تم حفظ state لقائمة الأقسام: `current_flow=browse_categories`, `last_options_type=categories`.
- عند وجود Guided state، يتم تنفيذ Guided handler قبل منطق الحجز أو البحث عن المنتجات.
- النصوص مثل `تصفح الأقسام` و`عناية بالبشرة` لم تعد تذهب إلى البحث الحر.
- الرقم المفرد بدون سياق لا يبحث كمنتج عشوائي؛ يعرض القائمة الرئيسية من جديد.
- تم اختبار استخراج `interactive.list_reply.id/title` و`interactive.button_reply.id/title`.

## ما لم يتغير
- لم يتم تعديل جوهر Matching أو Vision.
- لم يتم لمس قاعدة المنتجات أو `.env` أو `pricebot.db`.
- لم تتم إضافة أي fallback fuzzy قديم.
