# -*- coding: utf-8 -*-
from services.catalog_alignment import align_product
from services.search_engine import search_products, DECISION_EXACT, DECISION_NOT_AVAILABLE
from services import guided_finder, product_navigator

products_raw = [
    {"id": "p1", "name": "+Photoblok 50", "price": "70", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p2", "name": "1,2,3 Extra", "aliases": "Extra 1,2,3", "price": "20", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p3", "name": "gyno-daktarin vag cream", "price": "55", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p4", "name": "CeraVe Foaming Facial Cleanser Normal to Oily Skin", "price": "130", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p5", "name": "CeraVe Hydrating Cleanser Dry Skin", "price": "125", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p6", "name": "Baby gentle wash", "price": "30", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p7", "name": "Body wash fresh", "price": "30", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p8", "name": "Nizoral shampoo", "price": "65", "category": "other", "form": "product", "available": "متوفر"},
    {"id": "p9", "name": "Flagyl tablet 500mg", "price": "15", "category": "medicine", "form": "tablet", "strength": "500mg", "available": "متوفر"},
]
products = []
for p in products_raw:
    a = align_product(p)
    merged = dict(p); merged.update({k: v for k, v in a.items() if v not in (None, "")})
    products.append(merged)

def assert_exact(query):
    d = search_products(query, products, allow_guided=False)
    assert d.decision == DECISION_EXACT, (query, d.decision, d.reason)

assert_exact("Photoblok 50+")
assert_exact("+Photoblok 50")
assert_exact("123")
assert_exact("Extra 1,2,3")
assert_exact("gyno-daktarin vag cream")
assert search_products("Formag", products, allow_guided=False).decision == DECISION_NOT_AVAILABLE

r = guided_finder.handle_guided_query("u", "غسول", {}, products)
assert r and r.handled and "غسول وجه" in r.reply
r = guided_finder.handle_guided_query("u", "غسول وجه", {}, products)
assert r and r.handled and "نوع البشرة" in r.reply
r = guided_finder.handle_guided_query("u", "غسول للبشرة الدهنية", {}, products)
assert r and r.handled
opts = r.options or (((r.state_update or {}).get("guided_finder") or {}).get("last_options") or [])
assert opts, "oily face cleanser should return products"
names = " | ".join(o.get("name", "") or o.get("label", "") for o in opts).lower()
assert "foaming" in names or "oily" in names
assert "baby" not in names and "body wash" not in names
assert "hydrating cleanser" not in names, names
sections = product_navigator.available_sections(products)
assert any(s.get("id") == "medicine" for s in sections)
shampoo = guided_finder.filter_products_by_guided_slots({"selected_category": "hair_care", "selected_product_type": "shampoo", "body_area": "hair", "form": "shampoo"}, products, limit=10)
assert shampoo and all("shampoo" in (p.get("name", "") + " " + p.get("form", "") + " " + p.get("product_type", "")).lower() for p in shampoo)
state = {"guided_finder": {"current_flow": "browse", "step": "results", "last_options": opts, "last_options_type": "products", "expires_at": 9999999999}}
sel = guided_finder.handle_guided_query("u", "1", state, products)
assert sel and sel.product, "number selection should choose product"
print("ACCEPTANCE_TESTS_FINAL_V22_1_CATALOG_ALIGNED_OK")
