#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final V22.3 Guided Commerce acceptance tests."""
from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path

TMP_DIR = tempfile.mkdtemp(prefix="pricebot_v22_3_guided_")
os.environ["PRICEBOT_DB_FILE"] = str(Path(TMP_DIR) / "acceptance_v22_3.db")
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-v22-3-code"
os.environ["PRICEBOT_DEBUG_ENDPOINTS"] = "false"
os.environ["PRICEBOT_ENV"] = "production"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"

import database  # noqa: E402
import matcher  # noqa: E402
from services import guided_finder  # noqa: E402
from tools.rebuild_search_index import rebuild_search_index  # noqa: E402
from tools.rebuild_product_nav_index import rebuild_product_nav_index  # noqa: E402

CATALOG = [
    {"product_id":"P1","name":"Photoblok 50+","brand":"Photoblok","product_family":"Photoblok 50+","category":"cosmetic","form":"sunscreen","body_area":"face","use_case":"sun_protection","skin_type":"normal_combination_skin","size":"50ml","aliases":"Photoblok 50+","ocr_keywords":"photoblok 50 spf sunscreen face","price":"70","available":"متوفر"},
    {"product_id":"P123","name":"1,2,3 Extra","brand":"","product_family":"123 Extra","category":"other","form":"product","body_area":"","use_case":"","skin_type":"","size":"","aliases":"123; Extra 1,2,3","ocr_keywords":"123 extra","price":"20","available":"متوفر"},
    {"product_id":"MED1","name":"Panadol 500mg Tablets","brand":"Panadol","product_family":"Panadol","category":"medicine","form":"tablet","active_ingredient":"paracetamol","strength":"500mg","aliases":"panadol paracetamol","ocr_keywords":"pain fever paracetamol","price":"12","available":"متوفر"},
    {"product_id":"MED2","name":"Zofran Ondansetron 4mg Tablets","brand":"Zofran","product_family":"Ondansetron","category":"medicine","form":"tablet","active_ingredient":"ondansetron","strength":"4mg","aliases":"ondansetron zofran","ocr_keywords":"antiemetic vomiting stomach","price":"40","available":"متوفر"},
    {"product_id":"MED3","name":"Gyno-Daktarin Vag Cream","brand":"Gyno-Daktarin","product_family":"Gyno-Daktarin","category":"medicine","form":"cream","body_area":"feminine","aliases":"gyno daktarin vag cream","ocr_keywords":"vaginal feminine","price":"55","available":"متوفر"},
    {"product_id":"MED4","name":"Flagyl 500mg Tablets","brand":"Flagyl","product_family":"Flagyl","category":"medicine","form":"tablet","active_ingredient":"metronidazole","strength":"500mg","aliases":"flagyl metronidazole","ocr_keywords":"antibiotic antiparasitic","price":"18","available":"متوفر"},
    {"product_id":"S1","name":"Feroglobin Iron Capsules","brand":"Feroglobin","product_family":"Feroglobin","category":"supplement","form":"capsule","active_ingredient":"iron","aliases":"ferro ferrous iron حديد","ocr_keywords":"iron ferrous ferro feroglobin","price":"35","available":"متوفر"},
    {"product_id":"S2","name":"Vitamin D3 5000 IU","brand":"VitD","product_family":"Vitamin D3","category":"supplement","form":"tablet","aliases":"vitamin d d3","ocr_keywords":"vitamin d3","price":"25","available":"متوفر"},
    {"product_id":"C1","name":"Bioderma Sebium Gel Moussant 200ml","brand":"Bioderma","product_family":"Sebium Gel Moussant","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","aliases":"bioderma sebium gel moussant","ocr_keywords":"face wash cleanser oily skin acne","price":"65","available":"متوفر"},
    {"product_id":"C2","name":"CeraVe Hydrating Cleanser 236ml","brand":"CeraVe","product_family":"Hydrating Cleanser","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"hydration","skin_type":"dry_skin","aliases":"cerave hydrating cleanser","ocr_keywords":"face wash cleanser dry skin","price":"125","available":"متوفر"},
    {"product_id":"C3","name":"Baby Gentle Wash 250ml","brand":"BabyBrand","product_family":"Gentle Wash","category":"cosmetic","form":"cleanser","body_area":"baby","use_case":"baby_care","skin_type":"sensitive_skin","aliases":"baby wash","ocr_keywords":"baby wash kids","price":"20","available":"متوفر"},
    {"product_id":"C4","name":"Body Wash Rose 500ml","brand":"BodyBrand","product_family":"Rose Body Wash","category":"cosmetic","form":"cleanser","body_area":"body","use_case":"body_care","aliases":"body wash","ocr_keywords":"body wash shower gel","price":"25","available":"متوفر"},
    {"product_id":"H1","name":"Nizoral Anti Dandruff Shampoo","brand":"Nizoral","product_family":"Nizoral","category":"cosmetic","form":"shampoo","body_area":"hair","use_case":"dandruff","aliases":"anti dandruff shampoo","ocr_keywords":"shampoo dandruff hair","price":"50","available":"متوفر"},
    {"product_id":"H2","name":"Hair Keratin Conditioner","brand":"HairBrand","product_family":"Keratin","category":"cosmetic","form":"conditioner","body_area":"hair","aliases":"conditioner hair","ocr_keywords":"conditioner hair","price":"32","available":"متوفر"},
    {"product_id":"B1","name":"Baby Diapers Small","brand":"BabyBrand","product_family":"Diapers","category":"baby","form":"diaper","body_area":"baby","aliases":"diaper حفاض","ocr_keywords":"baby diaper","price":"45","available":"متوفر"},
    {"product_id":"D1","name":"Digital Blood Pressure Monitor","brand":"DeviceCo","product_family":"Pressure Monitor","category":"device","form":"device","aliases":"pressure meter","ocr_keywords":"device meter pressure قياس ضغط","price":"180","available":"متوفر"},
    {"product_id":"D2","name":"Digital Thermometer","brand":"DeviceCo","product_family":"Thermometer","category":"device","form":"device","aliases":"thermometer ترمومتر","ocr_keywords":"device thermometer","price":"30","available":"متوفر"},
    {"product_id":"UN1","name":"Unavailable Shampoo","brand":"NoStock","category":"cosmetic","form":"shampoo","body_area":"hair","price":"10","available":"غير متوفر"},
]


def seed_catalog() -> None:
    database.init_db()
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        conn.execute("DELETE FROM conversation_state")
        for p in CATALOG:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,product_family,category,form,body_area,use_case,skin_type,size,aliases,ocr_keywords,image_ocr_keywords,active_ingredient,strength,price,available)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p.get("product_id",""), p.get("name",""), p.get("name","").lower(), p.get("brand",""), p.get("product_family",""), p.get("category",""), p.get("form",""), p.get("body_area",""), p.get("use_case",""), p.get("skin_type",""), p.get("size",""), p.get("aliases",""), p.get("ocr_keywords",""), p.get("ocr_keywords",""), p.get("active_ingredient",""), p.get("strength",""), p.get("price",""), p.get("available","")),
            )
        conn.commit()
    matcher.invalidate_product_cache()
    rows = guided_finder.build_guided_catalog_rows(database.load_products())
    report = database.replace_guided_catalog_index(rows)
    assert report["products_before"] == report["products_after"] == len(CATALOG)


def ask(phone: str, text: str):
    start = time.perf_counter()
    result = matcher.handle_text_query_result(phone, text, database.get_user_state(phone))
    elapsed_ms = (time.perf_counter() - start) * 1000
    assert elapsed_ms < 1000, f"{text} timed out: {elapsed_ms:.1f}ms"
    return result


def assert_no_price(reply: str):
    assert "السعر" not in reply, reply
    assert "د.ل" not in reply, reply


def main() -> None:
    seed_catalog()
    before = database.count_products()
    assert before == len(CATALOG)
    assert database.count_guided_catalog_index() == len(CATALOG)

    # V22.2 data-protection rebuilds still do not alter products.
    r1 = rebuild_search_index(); assert r1["products_before"] == before and r1["products_after"] == before
    r2 = rebuild_product_nav_index(); assert r2["products_before"] == before and r2["products_after"] == before
    assert database.count_products() == before

    r = ask("u1", "السلام عليكم")
    assert r.decision == "guided_main_menu" and "أدوية" in r.reply and "بحث باسم منتج" in r.reply, r.reply

    r = ask("u2", "أدوية")
    assert r.decision.startswith("guided") and "مسكنات" in r.reply and "معدة" in r.reply, r.reply
    assert_no_price(r.reply)

    # Choosing a medicine section is guided, not product search, and no medicine alternatives are suggested.
    ask("u3", "السلام عليكم")
    ask("u3", "أدوية")
    r = ask("u3", "مضادات حيوية")
    assert r.decision == "guided_products" and "Flagyl" in r.reply, r.reply
    assert "بديل" not in r.reply and "بدائل" not in r.reply

    r = ask("u4", "مكملات وفيتامينات")
    assert "حديد" in r.reply and "فيتامين D" in r.reply, r.reply
    r = ask("u4", "حديد")
    assert "Feroglobin" in r.reply and "Vitamin D3" not in r.reply, r.reply

    ask("u5", "عناية بالبشرة")
    ask("u5", "غسول وجه")
    r = ask("u5", "دهنية")
    assert "Bioderma Sebium" in r.reply, r.reply
    assert "Baby Gentle" not in r.reply and "Body Wash" not in r.reply and "Hydrating Cleanser" not in r.reply, r.reply

    ask("u6", "عناية بالشعر")
    r = ask("u6", "شامبو")
    assert "Nizoral" in r.reply and "Bioderma" not in r.reply and "CeraVe" not in r.reply, r.reply

    ask("u7", "أطفال")
    r = ask("u7", "شامبو/غسول أطفال")
    assert "Baby Gentle Wash" in r.reply and "Bioderma" not in r.reply, r.reply

    r = ask("u8", "أجهزة ومستلزمات")
    assert "قياس ضغط" in r.reply and "ترمومتر" in r.reply, r.reply
    r = ask("u8", "قياس ضغط")
    assert "Digital Blood Pressure" in r.reply and "Panadol" not in r.reply, r.reply

    # Number from product list selects product; more paginates or says no more safely.
    ask("u9", "عناية بالشعر")
    ask("u9", "شامبو")
    r = ask("u9", "1")
    assert r.decision == "guided_product_selected" and "للحجز اكتب" in r.reply and "السعر" in r.reply, r.reply
    r = ask("u9", "نعم")
    assert r.decision == "order_quantity_requested" and "كم الكمية" in r.reply, r.reply
    r = ask("u9", "2")
    assert r.decision == "order_created" and "الكمية: 2" in r.reply, r.reply

    r = ask("u11", "بحث باسم منتج")
    assert r.decision == "guided_search_instruction" and "اكتب اسم المنتج الكامل" in r.reply, r.reply
    r = ask("u11", "Photoblok 50+")
    assert r.decision in {"matched", "matched_unknown_availability"} and "Photoblok 50+" in r.reply and "السعر" in r.reply, r.reply

    r = ask("u12", "غسول")
    assert r.decision.startswith("guided") and ("غسول وجه" in r.reply or "نوع البشرة" in r.reply), r.reply
    assert_no_price(r.reply)

    assert database.count_products() == before
    print("ACCEPTANCE_TESTS_FINAL_V22_3_GUIDED_COMMERCE_OK")
    print(f"DB_PROTECTION_OK | products_count={before} | guided_rows={database.count_guided_catalog_index()}")


if __name__ == "__main__":
    main()
