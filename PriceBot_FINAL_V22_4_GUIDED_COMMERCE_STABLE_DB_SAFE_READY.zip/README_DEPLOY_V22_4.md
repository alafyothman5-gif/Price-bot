# PriceBot V22.4 Deploy — Guided Commerce + Stable DB Safety

## الهدف
نسخة V22.4 تركّز على الاستقرار، حماية `pricebot.db`، وفهرس Guided Commerce مبني من `products_master_v22_ready.xlsx` عند وجوده، أو من جدول المنتجات الحالي عند عدم وجود ملف master.

## ممنوعات مضمّنة في النشر
- لا يتم نسخ أو استبدال `pricebot.db` من الحزمة.
- لا يتم تضمين `.env` داخل الحزمة.
- لا يتم لمس MedMCQ.
- لا يتم تشغيل acceptance tests على قاعدة الإنتاج.
- لا يتم حذف أو تفريغ جدول `products`.
- إعادة بناء الفهارس تلمس فقط:
  - `product_search_index`
  - `product_nav_index`
  - `guided_catalog_index`

## أمر النشر
شغّل من داخل `/opt/pricebot` فقط:

```bash
chmod +x deploy_pricebot_v22_4.sh backup_pricebot.sh rollback_pricebot.sh smoke_test_pricebot.sh tools/*.py && ./deploy_pricebot_v22_4.sh
```

## حماية قاعدة البيانات
`deploy_pricebot_v22_4.sh` يفحص في كل مرحلة:

- SQLite file magic.
- `PRAGMA integrity_check = ok`.
- وجود جدول `products`.
- `products_count >= PRICEBOT_MIN_PRODUCTS_GUARD`، والافتراضي 1000 في الإنتاج.
- عدم نقص عدد المنتجات عن العدد قبل النشر.

المراحل المحمية:

1. before deploy
2. after isolated tests
3. after migration
4. after search index rebuild
5. after nav index rebuild
6. after guided index rebuild
7. after health check

عند الفشل بعد أخذ backup، يحاول السكربت إيقاف الخدمة، استرجاع DB من backup صالح، استرجاع الكود السابق، ثم تشغيل الخدمة.

## مصدر Guided Catalog
إذا كان الملف موجودًا في `/opt/pricebot/products_master_v22_ready.xlsx`، يتم بناء `guided_catalog_index` منه مباشرة:

```bash
python tools/build_guided_catalog_index.py --input /opt/pricebot/products_master_v22_ready.xlsx --write-db --report /opt/pricebot/guided_catalog_tree_report.xlsx --min-products 1000
```

إذا لم يكن الملف موجودًا، يتم البناء من جدول `products` الحالي:

```bash
python tools/build_guided_catalog_index.py --db --write-db --report /opt/pricebot/guided_catalog_tree_report.xlsx --min-products 1000
```

المنتج يظهر في القوائم فقط إذا كان متوفرًا، لديه سعر، وليس `exact_only / review_only / needs_review / partial / unknown`.

## أدوات التشخيص والاسترجاع

تشخيص:

```bash
python tools/diagnose_pricebot.py
```

استرجاع آخر قاعدة سليمة:

```bash
python tools/restore_last_good_db.py --min-products 1000
```

Smoke test محلي:

```bash
./smoke_test_pricebot.sh
```
