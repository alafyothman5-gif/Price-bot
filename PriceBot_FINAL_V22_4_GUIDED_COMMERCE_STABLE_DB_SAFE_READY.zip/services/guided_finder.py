# -*- coding: utf-8 -*-
"""Guided Commerce Engine for PriceBot V22.3.

This is the default customer journey: browse sections -> submenus -> available
products -> product details -> reservation. It is intentionally deterministic:
no medicine alternatives, no therapeutic advice, no global fuzzy search from
menu/generic words, and no unavailable products in guided lists.
"""
from __future__ import annotations

import html
import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from functools import lru_cache

GUIDED_STATE_KEY = "guided_finder"  # keep old key so existing routing remains compatible
GUIDED_TTL_SECONDS = int(os.getenv("GUIDED_FINDER_TTL_SECONDS", "1200"))
PAGE_SIZE = 10
_PAGE_MORE_WORDS = {"المزيد", "مزيد", "more", "التالي", "next"}

# ---------------------------------------------------------------------------
# Menu definitions
# ---------------------------------------------------------------------------
_MAIN_ORDER = [
    ("medicine", "أدوية"),
    ("supplements", "مكملات وفيتامينات"),
    ("skin_care", "عناية بالبشرة"),
    ("hair_care", "عناية بالشعر"),
    ("baby", "أطفال"),
    ("devices", "أجهزة ومستلزمات"),
    ("search_by_name", "بحث باسم منتج"),
    ("send_image", "إرسال صورة"),
]

_MEDICINE_MENU = [
    ("pain_fever", "مسكنات وخافض حرارة"),
    ("stomach_vomiting", "معدة وقيء"),
    ("allergy_cold", "حساسية وزكام"),
    ("dermatology", "جلدية"),
    ("gynecology", "نسائية"),
    ("antibiotic", "مضادات حيوية"),
    ("chronic", "سكري وضغط وقلب"),
    ("drops", "قطرات وعيون/أنف/أذن"),
    ("search_medicine", "بحث باسم دواء"),
]

_SUPPLEMENTS_MENU = [
    ("iron", "حديد"),
    ("vitamin_d", "فيتامين D"),
    ("calcium", "كالسيوم"),
    ("magnesium", "مغنيسيوم"),
    ("zinc", "زنك"),
    ("vitamin_c", "فيتامين C"),
    ("multivitamin", "Multivitamin"),
    ("kids_vitamins", "فيتامينات أطفال"),
    ("pregnancy_supplements", "مكملات الحمل"),
]

_SKIN_MENU = [
    ("face_cleanser", "غسول وجه"),
    ("moisturizer", "مرطب"),
    ("sunscreen", "واقي شمس"),
    ("serum", "سيروم"),
    ("acne_treatment", "علاج حبوب"),
    ("exfoliator", "مقشر"),
    ("body_care", "عناية بالجسم"),
]

_SKIN_TYPE_MENU = [
    ("oily_skin", "دهنية"),
    ("dry_skin", "جافة"),
    ("sensitive_skin", "حساسة"),
    ("normal_combination_skin", "عادية/مختلطة"),
    ("unknown", "لا أعرف"),
]

_HAIR_MENU = [
    ("shampoo", "شامبو"),
    ("conditioner", "بلسم"),
    ("hair_oil_serum", "زيت/سيروم شعر"),
    ("dandruff", "قشرة"),
    ("hair_loss", "تساقط"),
    ("baby_hair", "عناية أطفال بالشعر"),
]

_BABY_MENU = [
    ("diapers", "حفاضات"),
    ("baby_wash", "شامبو/غسول أطفال"),
    ("baby_creams", "كريمات أطفال"),
    ("baby_milk_food", "حليب وأغذية"),
    ("baby_supplies", "مستلزمات أطفال"),
]

_DEVICES_MENU = [
    ("blood_pressure", "قياس ضغط"),
    ("glucose_meter", "قياس سكر"),
    ("thermometer", "ترمومتر"),
    ("respiratory_devices", "أجهزة تنفس"),
    ("masks_supplies", "كمامات ومستلزمات"),
    ("bandage_gauze", "ضمادات وشاش"),
]

_MENU_BY_SECTION = {
    "medicine": _MEDICINE_MENU,
    "supplements": _SUPPLEMENTS_MENU,
    "skin_care": _SKIN_MENU,
    "hair_care": _HAIR_MENU,
    "baby": _BABY_MENU,
    "devices": _DEVICES_MENU,
}

_SUB_LABELS = dict(_MEDICINE_MENU + _SUPPLEMENTS_MENU + _SKIN_MENU + _HAIR_MENU + _BABY_MENU + _DEVICES_MENU + _MAIN_ORDER + _SKIN_TYPE_MENU)

_MAIN_TRIGGERS = {
    "السلام", "السلام عليكم", "مرحبا", "مرحب", "هلا", "اهلا", "أهلا", "ابدأ", "ابدا", "القائمة", "قائمه", "منتجات", "menu", "start", "hi", "hello"
}
_GENERIC_TO_ROUTE = {
    "ادويه": ("medicine", None), "ادوية": ("medicine", None), "أدوية": ("medicine", None), "دواء": ("medicine", None),
    "مكملات": ("supplements", None), "فيتامينات": ("supplements", None), "فيتامين": ("supplements", None),
    "حديد": ("supplements", "iron"), "iron": ("supplements", "iron"),
    "عنايه": ("skin_care", None), "عناية": ("skin_care", None), "بشره": ("skin_care", None), "بشرة": ("skin_care", None),
    "غسول": ("skin_care", "face_cleanser"), "غسول وجه": ("skin_care", "face_cleanser"), "cleanser": ("skin_care", "face_cleanser"),
    "كريم": ("skin_care", None), "لوشن": ("skin_care", "moisturizer"), "lotion": ("skin_care", "moisturizer"), "مرطب": ("skin_care", "moisturizer"), "سيروم": ("skin_care", "serum"), "serum": ("skin_care", "serum"), "واقي": ("skin_care", "sunscreen"), "واقي شمس": ("skin_care", "sunscreen"),
    "شامبو": ("hair_care", "shampoo"), "shampoo": ("hair_care", "shampoo"), "شعر": ("hair_care", None),
    "اطفال": ("baby", None), "أطفال": ("baby", None), "بيبي": ("baby", None),
    "اجهزه": ("devices", None), "أجهزة": ("devices", None), "جهاز": ("devices", None),
}

_UNAVAILABLE_TERMS = {"غير متوفر", "غير موجود", "نافذ", "نفذ", "0", "no", "out of stock", "unavailable", "false"}

_BRAND_ALIASES = {
    "cerave": ("cerave", "CeraVe"), "cera ve": ("cerave", "CeraVe"), "سيرافي": ("cerave", "CeraVe"), "سيرا في": ("cerave", "CeraVe"),
    "rilastil": ("rilastil", "Rilastil"), "ريلاستيل": ("rilastil", "Rilastil"),
    "bioderma": ("bioderma", "Bioderma"), "بيوديرما": ("bioderma", "Bioderma"), "بايودرما": ("bioderma", "Bioderma"),
    "la roche": ("la_roche", "La Roche"), "laroche": ("la_roche", "La Roche"), "la roche posay": ("la_roche", "La Roche"), "لاروش": ("la_roche", "La Roche"), "لاروش بوزيه": ("la_roche", "La Roche"),
    "eucerin": ("eucerin", "Eucerin"), "يوسرين": ("eucerin", "Eucerin"),
}


# Canonical values used by products_master_v22_ready.xlsx.  The master file is
# authoritative when these fields are present; name-based inference is only a
# fallback for older DB rows that have not yet been enriched.
_SECTION_ALIASES = {
    "medicine": "medicine", "ادويه": "medicine", "ادوية": "medicine", "أدوية": "medicine", "دواء": "medicine",
    "supplements": "supplements", "supplement": "supplements", "vitamins": "supplements", "مكملات": "supplements", "مكملات وفيتامينات": "supplements", "فيتامينات": "supplements",
    "skin_care": "skin_care", "skin care": "skin_care", "cosmetic": "skin_care", "عناية بالبشرة": "skin_care", "عنايه بالبشره": "skin_care", "بشرة": "skin_care",
    "hair_care": "hair_care", "hair care": "hair_care", "عناية بالشعر": "hair_care", "عنايه بالشعر": "hair_care", "شعر": "hair_care",
    "baby": "baby", "children": "baby", "kids": "baby", "أطفال": "baby", "اطفال": "baby", "طفل": "baby",
    "devices": "devices", "device": "devices", "medical_devices": "devices", "devices_supplies": "devices", "أجهزة ومستلزمات": "devices", "اجهزة ومستلزمات": "devices", "أجهزة": "devices", "اجهزه": "devices",
}

_MENU_ALIASES = {
    # medicine
    "pain_fever": "pain_fever", "مسكنات وخافض حرارة": "pain_fever", "مسكن": "pain_fever", "fever": "pain_fever", "pain": "pain_fever",
    "stomach_vomiting": "stomach_vomiting", "antiemetic": "stomach_vomiting", "معدة وقيء": "stomach_vomiting", "معده وقيء": "stomach_vomiting",
    "allergy_cold": "allergy_cold", "حساسية وزكام": "allergy_cold", "زكام": "allergy_cold", "allergy": "allergy_cold",
    "dermatology": "dermatology", "جلدية": "dermatology", "جلديه": "dermatology",
    "gynecology": "gynecology", "نسائية": "gynecology", "نسائيه": "gynecology", "vaginal": "gynecology",
    "antibiotic": "antibiotic", "antibiotics": "antibiotic", "مضادات حيوية": "antibiotic", "مضاد حيوي": "antibiotic",
    "chronic": "chronic", "سكري وضغط وقلب": "chronic", "diabetes": "chronic", "pressure": "chronic", "heart": "chronic",
    "drops": "drops", "قطرات وعيون/أنف/أذن": "drops", "قطرات": "drops",
    # supplements
    "iron": "iron", "حديد": "iron", "ferrous": "iron", "ferro": "iron",
    "vitamin_d": "vitamin_d", "vitamin d": "vitamin_d", "vit d": "vitamin_d", "d3": "vitamin_d", "فيتامين د": "vitamin_d",
    "calcium": "calcium", "كالسيوم": "calcium",
    "magnesium": "magnesium", "مغنيسيوم": "magnesium",
    "zinc": "zinc", "زنك": "zinc",
    "vitamin_c": "vitamin_c", "vitamin c": "vitamin_c", "vit c": "vitamin_c", "فيتامين c": "vitamin_c", "فيتامين سي": "vitamin_c",
    "multivitamin": "multivitamin", "multi vitamin": "multivitamin",
    "kids_vitamins": "kids_vitamins", "فيتامينات أطفال": "kids_vitamins", "فيتامينات اطفال": "kids_vitamins",
    "pregnancy_supplements": "pregnancy_supplements", "مكملات الحمل": "pregnancy_supplements", "pregnancy": "pregnancy_supplements", "prenatal": "pregnancy_supplements",
    # skin
    "face_cleanser": "face_cleanser", "cleanser": "face_cleanser", "face wash": "face_cleanser", "غسول وجه": "face_cleanser", "غسول": "face_cleanser",
    "moisturizer": "moisturizer", "moisturiser": "moisturizer", "lotion": "moisturizer", "cream": "moisturizer", "مرطب": "moisturizer", "لوشن": "moisturizer", "كريم": "moisturizer",
    "sunscreen": "sunscreen", "sunblock": "sunscreen", "spf": "sunscreen", "واقي شمس": "sunscreen", "واقي": "sunscreen",
    "serum": "serum", "سيروم": "serum",
    "acne_treatment": "acne_treatment", "acne": "acne_treatment", "علاج حبوب": "acne_treatment", "حبوب": "acne_treatment",
    "exfoliator": "exfoliator", "مقشر": "exfoliator",
    "body_care": "body_care", "body": "body_care", "body_wash": "body_care", "عناية بالجسم": "body_care", "جسم": "body_care",
    # hair
    "shampoo": "shampoo", "شامبو": "shampoo",
    "conditioner": "conditioner", "بلسم": "conditioner",
    "hair_oil_serum": "hair_oil_serum", "hair oil": "hair_oil_serum", "hair serum": "hair_oil_serum", "زيت/سيروم شعر": "hair_oil_serum",
    "dandruff": "dandruff", "قشرة": "dandruff", "قشره": "dandruff",
    "hair_loss": "hair_loss", "تساقط": "hair_loss",
    "baby_hair": "baby_hair", "عناية أطفال بالشعر": "baby_hair", "عناية اطفال بالشعر": "baby_hair",
    # baby
    "diapers": "diapers", "حفاضات": "diapers", "diaper": "diapers",
    "baby_wash": "baby_wash", "شامبو/غسول أطفال": "baby_wash", "شامبو/غسول اطفال": "baby_wash", "baby shampoo": "baby_wash", "baby wash": "baby_wash",
    "baby_creams": "baby_creams", "كريمات أطفال": "baby_creams", "كريمات اطفال": "baby_creams",
    "baby_milk_food": "baby_milk_food", "حليب وأغذية": "baby_milk_food", "حليب واغذية": "baby_milk_food", "formula": "baby_milk_food",
    "baby_supplies": "baby_supplies", "مستلزمات أطفال": "baby_supplies", "مستلزمات اطفال": "baby_supplies",
    # devices
    "blood_pressure": "blood_pressure", "قياس ضغط": "blood_pressure", "pressure": "blood_pressure",
    "glucose_meter": "glucose_meter", "قياس سكر": "glucose_meter", "glucose": "glucose_meter",
    "thermometer": "thermometer", "ترمومتر": "thermometer",
    "respiratory_devices": "respiratory_devices", "أجهزة تنفس": "respiratory_devices", "اجهزة تنفس": "respiratory_devices", "nebulizer": "respiratory_devices",
    "masks_supplies": "masks_supplies", "كمامات ومستلزمات": "masks_supplies", "mask": "masks_supplies",
    "bandage_gauze": "bandage_gauze", "ضمادات وشاش": "bandage_gauze", "bandage": "bandage_gauze", "gauze": "bandage_gauze",
}

_SKIN_ALIASES = {
    "oily": "oily_skin", "oily_skin": "oily_skin", "دهنية": "oily_skin", "دهنيه": "oily_skin", "acne_prone_skin": "oily_skin",
    "dry": "dry_skin", "dry_skin": "dry_skin", "جافة": "dry_skin", "جافه": "dry_skin", "very_dry_skin": "dry_skin",
    "sensitive": "sensitive_skin", "sensitive_skin": "sensitive_skin", "حساسة": "sensitive_skin", "حساسه": "sensitive_skin",
    "normal": "normal_combination_skin", "combination": "normal_combination_skin", "normal_combination_skin": "normal_combination_skin", "mixed": "normal_combination_skin", "عادية/مختلطة": "normal_combination_skin", "عاديه/مختلطه": "normal_combination_skin",
    "all": "", "all_skin_types": "", "compatible": "", "مناسب للجميع": "",
}

_BODY_ALIASES = {
    "face": "face", "facial": "face", "وجه": "face", "بشرة": "face", "بشره": "face",
    "body": "body", "جسم": "body",
    "baby": "baby", "kids": "baby", "children": "baby", "اطفال": "baby", "أطفال": "baby",
    "hair": "hair", "شعر": "hair",
    "mouth": "mouth", "oral": "mouth", "feminine": "feminine", "vaginal": "feminine",
}

_HIDDEN_QUALITY = {"review_only", "needs_review", "unknown", "partial", "exact_only", "reject", "rejected", "مراجعة", "يحتاج_مراجعة"}
_ALLOWED_QUALITY = {"", "verified", "ready", "approved", "guided", "suitable", "محقق", "جاهز", "مناسب"}
_EXACT_ONLY_MODES = {"exact_only", "review_only", "hidden", "no_guided", "search_only", "manual_review"}


def _canon(mapping: Dict[str, str], value: Any) -> str:
    q = normalize_text(value)
    if not q:
        return ""
    if q in mapping:
        return mapping[q]
    compact = q.replace("-", "_").replace(" ", "_")
    if compact in mapping:
        return mapping[compact]
    return ""


def _master_section(product: dict) -> str:
    return _canon(_SECTION_ALIASES, _field(product, "section", "menu_section", "guided_section"))


def _master_menu(product: dict, section: str) -> str:
    for key in ("menu_level_1", "submenu", "guided_submenu", "guided_category"):
        val = _canon(_MENU_ALIASES, _field(product, key))
        if val:
            return val
    # Use master classification columns before free-name inference.
    for key in ("product_type", "use_case", "form", "category"):
        val = _canon(_MENU_ALIASES, _field(product, key))
        if val:
            if section == "supplements" and val in {x[0] for x in _SUPPLEMENTS_MENU}:
                return val
            if section == "skin_care" and val in {x[0] for x in _SKIN_MENU}:
                return val
            if section == "hair_care" and val in {x[0] for x in _HAIR_MENU}:
                return val
            if section == "baby" and val in {x[0] for x in _BABY_MENU}:
                return val
            if section == "devices" and val in {x[0] for x in _DEVICES_MENU}:
                return val
            if section == "medicine" and val in {x[0] for x in _MEDICINE_MENU}:
                return val
    return ""


def _master_skin(product: dict) -> str:
    return _canon(_SKIN_ALIASES, _field(product, "skin_type", "skin", "skin_category"))


def _master_body_area(product: dict) -> str:
    return _canon(_BODY_ALIASES, _field(product, "body_area", "area", "target_area"))


def _has_master_guided_fields(product: dict) -> bool:
    return any(str(product.get(k) or "").strip() for k in ["section", "product_type", "use_case", "skin_type", "body_area", "quality_status", "search_mode"])


def _is_guided_visible(product: dict) -> bool:
    if not _is_available(product):
        return False
    if not str(product.get("price") or "").strip():
        return False
    search_mode = normalize_text(_field(product, "search_mode"))
    quality = normalize_text(_field(product, "quality_status", "review_status"))
    if search_mode in _EXACT_ONLY_MODES or quality in _HIDDEN_QUALITY:
        return False
    # Master rows with an explicit quality must be approved/verified/suitable.
    if str(product.get("quality_status") or "").strip() and quality not in _ALLOWED_QUALITY:
        return False
    # Legacy rows without master columns remain visible to preserve deployed DB behavior.
    return True

_BRAND_PRODUCT_MENUS = {
    "cerave": [("face_cleanser", "غسول وجه"), ("moisturizer", "مرطب/لوشن"), ("sunscreen", "واقي شمس"), ("serum", "سيروم"), ("body_care", "عناية بالجسم")],
    "rilastil": [("face_cleanser", "غسول وجه"), ("moisturizer", "مرطب/بلسم"), ("sunscreen", "واقي شمس"), ("serum", "سيروم"), ("body_care", "عناية بالجسم")],
    "bioderma": [("face_cleanser", "غسول وجه"), ("moisturizer", "مرطب"), ("sunscreen", "واقي شمس"), ("serum", "سيروم"), ("body_care", "عناية بالجسم")],
    "la_roche": [("face_cleanser", "غسول وجه"), ("moisturizer", "مرطب"), ("sunscreen", "واقي شمس"), ("serum", "سيروم"), ("acne_treatment", "علاج حبوب")],
    "eucerin": [("face_cleanser", "غسول وجه"), ("moisturizer", "مرطب"), ("sunscreen", "واقي شمس"), ("serum", "سيروم"), ("body_care", "عناية بالجسم")],
}


@dataclass
class GuidedResult:
    handled: bool
    reply: str = ""
    decision: str = "guided_commerce"
    state_update: Dict[str, Any] = field(default_factory=dict)
    clear_state: bool = False
    product: Optional[dict] = None
    options: List[dict] = field(default_factory=list)
    order_item: Optional[dict] = None


def _h(value: Any) -> str:
    return html.escape(str(value or ""), quote=False)


@lru_cache(maxsize=20000)
def _normalize_cached(raw: str) -> str:
    text = str(raw or "").strip().lower()
    for src, dst in {"أ": "ا", "إ": "ا", "آ": "ا", "ة": "ه", "ى": "ي", "ؤ": "و", "ئ": "ي", "ٱ": "ا", "ڤ": "ف", "ک": "ك", "ی": "ي", "گ": "ك", "چ": "ج", "پ": "ب"}.items():
        text = text.replace(src, dst)
    text = text.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    text = re.sub(r"[\u064b-\u065f]", "", text)
    text = re.sub(r"[^\w\s/+.-]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def normalize_text(value: Any) -> str:
    return _normalize_cached(str(value or ""))


def _contains(blob: str, phrase: str) -> bool:
    p = normalize_text(phrase)
    return bool(p and f" {p} " in f" {blob} ")


def _field(product: dict, *keys: str) -> str:
    for key in keys:
        val = product.get(key)
        if val not in (None, ""):
            return str(val)
    return ""


def _identity(product: dict) -> str:
    return normalize_text(" ".join(_field(product, k) for k in [
        "name", "brand", "company", "product_family", "category", "category_guess", "subcategory",
        "form", "type", "product_type", "active_ingredient", "use_case", "skin_type", "body_area",
        "age_group", "aliases", "ocr_keywords", "image_ocr_keywords", "keywords", "size", "pack"
    ]))


def _is_available(product: dict) -> bool:
    raw = normalize_text(_field(product, "available", "availability", "stock"))
    if not raw:
        return True
    return not any(term in raw for term in _UNAVAILABLE_TERMS)


def _price_text(product: dict) -> str:
    price = str(product.get("price") or "").strip()
    if not price:
        return ""
    if "د" in price or "lyd" in price.lower():
        return price
    return f"{price} د.ل"


def _pid(product: dict) -> str:
    return str(product.get("product_id") or product.get("id") or "")


def _state(flow: str, step: str, **data: Any) -> Dict[str, Any]:
    payload = {"current_flow": flow, "step": step, "expires_at": int(time.time()) + GUIDED_TTL_SECONDS}
    payload.update(data)
    if payload.get("last_options") and not payload.get("last_options_type"):
        payload["last_options_type"] = "menu"
    return {GUIDED_STATE_KEY: payload}


def _guided_state(user_state: dict) -> dict:
    state = (user_state or {}).get(GUIDED_STATE_KEY) or {}
    if not isinstance(state, dict):
        return {}
    try:
        if int(state.get("expires_at") or 0) < int(time.time()):
            return {}
    except Exception:
        return {}
    return state


def _option_rows(options: Sequence[dict]) -> str:
    return "\n".join(f"{i}. {_h(opt.get('label') or opt.get('name') or opt.get('id'))}" for i, opt in enumerate(options, 1))


def _menu_reply(title: str, options: Sequence[dict]) -> str:
    if not options:
        return f"{title}\n\nلا توجد منتجات متوفرة حالياً داخل هذا القسم."
    return f"{title}\n\n{_option_rows(options)}"


def _pharmacy_name() -> str:
    return os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")


def _canonical_brand_query(text: str) -> Optional[Tuple[str, str]]:
    q = normalize_text(text)
    return _BRAND_ALIASES.get(q)


def _ask_brand_type(brand_query: str, products: Sequence[dict]) -> GuidedResult:
    canon = _canonical_brand_query(brand_query) or (normalize_text(brand_query).replace(" ", "_"), str(brand_query or "").strip() or "العلامة")
    brand_key, label = canon
    configured = _BRAND_PRODUCT_MENUS.get(brand_key, _BRAND_PRODUCT_MENUS.get("cerave", []))
    # Keep the menu dynamic when the catalog has products for the brand, but do
    # not fall through to product search if the brand is present with only one
    # row. Brand-only always asks for type and never returns price.
    available_types = set()
    for prod in _available_products(products):
        brand_blob = normalize_text(" ".join([_field(prod, "brand", "company"), _field(prod, "name"), _field(prod, "aliases")]))
        if label and normalize_text(label) not in brand_blob and brand_key.replace("_", " ") not in brand_blob:
            continue
        row = guided_index_row(prod)
        if row.get("section") in {"skin_care", "hair_care", "baby"} and row.get("menu_level_1"):
            available_types.add(row["menu_level_1"])
    opts = []
    for cid, opt_label in configured:
        if not available_types or cid in available_types:
            opts.append({"id": cid, "label": opt_label})
    if not opts:
        opts = [{"id": cid, "label": opt_label} for cid, opt_label in configured[:4]]
    reply = _menu_reply(f"أي نوع من {label}؟", opts)
    return GuidedResult(True, reply, "guided_brand_type", _state("brand", "brand_product_type", brand=brand_key, brand_label=label, last_options=opts, last_options_type="brand_type"), options=opts)


def _brand_matches_product(product: dict, brand_key: str, brand_label: str = "") -> bool:
    if not brand_key and not brand_label:
        return True
    blob = normalize_text(" ".join([_field(product, "brand", "company"), _field(product, "name"), _field(product, "aliases"), _field(product, "ocr_keywords", "image_ocr_keywords")]))
    needles = {normalize_text(brand_label), normalize_text(brand_key.replace("_", " ")), normalize_text(brand_key)}
    if brand_key == "la_roche":
        needles.update({"la roche", "laroche", "la roche posay", "لاروش"})
    if brand_key == "cerave":
        needles.update({"cerave", "cera ve", "سيرافي"})
    return any(n and n in blob for n in needles)


def _selected_option(text: str, options: Sequence[dict]) -> Optional[dict]:
    q_raw = str(text or "").strip()
    q = normalize_text(q_raw)
    if q.isdigit():
        idx = int(q) - 1
        if 0 <= idx < len(options):
            return dict(options[idx])
    for opt in options or []:
        if q and q == normalize_text(opt.get("id")):
            return dict(opt)
        if q and q == normalize_text(opt.get("label") or opt.get("name") or ""):
            return dict(opt)
    # Accept labels even when the current state belongs to another menu.
    for cid, label in _MAIN_ORDER:
        if q == normalize_text(label) or q == normalize_text(cid):
            return {"id": cid, "label": label}
    for cid, label in _MEDICINE_MENU + _SUPPLEMENTS_MENU + _SKIN_MENU + _HAIR_MENU + _BABY_MENU + _DEVICES_MENU + _SKIN_TYPE_MENU:
        if q == normalize_text(label) or q == normalize_text(cid):
            return {"id": cid, "label": label}
    return None

# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------

def infer_product_type(product: dict) -> str:
    explicit = _canon(_MENU_ALIASES, _field(product, "product_type"))
    if explicit:
        return explicit
    raw = normalize_text(_field(product, "product_type", "form", "type", "subcategory"))
    blob = _identity(product)
    if raw in {"cleanser", "face_cleanser", "face wash", "wash"} or any(_contains(blob, w) for w in ["face wash", "cleanser", "gel moussant", "foaming cleanser", "غسول وجه"]):
        return "face_cleanser"
    checks = [
        ("body_wash", ["body wash", "shower gel", "غسول جسم"]),
        ("baby_wash", ["baby wash", "kids wash", "غسول اطفال", "شامبو اطفال"]),
        ("shampoo", ["shampoo", "شامبو"]),
        ("conditioner", ["conditioner", "بلسم"]),
        ("hair_oil_serum", ["hair oil", "hair serum", "زيت شعر", "سيروم شعر"]),
        ("sunscreen", ["sunscreen", "sunblock", "spf", "واقي شمس", "sun block"]),
        ("serum", ["serum", "سيروم"]),
        ("moisturizer", ["moisturizer", "moisturising", "moisturizing", "hydrating", "مرطب"]),
        ("cream", ["cream", "كريم", "baume", "balm"]),
        ("lotion", ["lotion", "لوشن"]),
        ("exfoliator", ["exfoliating", "exfoliator", "peeling", "scrub", "مقشر"]),
        ("acne_treatment", ["acne", "effaclar duo", "حبوب"]),
        ("diapers", ["diaper", "حفاض"]),
        ("thermometer", ["thermometer", "ترمومتر"]),
        ("blood_pressure", ["blood pressure", "pressure monitor", "قياس ضغط", "جهاز ضغط"]),
        ("glucose_meter", ["glucose meter", "glucometer", "قياس سكر", "جهاز سكر"]),
        ("respiratory_devices", ["nebulizer", "spirometer", "oxygen", "جهاز تنفس"]),
        ("masks_supplies", ["mask", "كمامه", "كمامة"]),
        ("bandage_gauze", ["bandage", "gauze", "ضماد", "شاش"]),
    ]
    for typ, words in checks:
        if raw == typ or any(_contains(blob, w) for w in words):
            return typ
    if raw:
        return raw
    return "product"


def infer_skin_type(product: dict) -> str:
    explicit = _master_skin(product)
    if explicit:
        return explicit
    raw = normalize_text(_field(product, "skin_type"))
    blob = _identity(product)
    compact = raw.replace(" ", "_")
    if compact in {"oily", "oily_skin", "normal_oily_skin", "acne", "acne_prone_skin"}:
        return "oily_skin"
    if compact in {"dry", "dry_skin", "very_dry_skin"}:
        return "dry_skin"
    if compact in {"sensitive", "sensitive_skin"}:
        return "sensitive_skin"
    if compact in {"normal", "combination", "normal_combination_skin", "mixed"}:
        return "normal_combination_skin"
    if any(w in blob for w in ["oily", "sebium", "effaclar", "cleanance", "acne", "blemish", "sebum", "دهنيه", "دهنية"]):
        return "oily_skin"
    if any(w in blob for w in ["dry", "hydrating", "atoderm", "xerolact", "lipikar", "جافه", "جافة"]):
        return "dry_skin"
    if any(w in blob for w in ["sensitive", "toleriane", "حساس"]):
        return "sensitive_skin"
    if any(w in blob for w in ["normal", "combination", "مختلط"]):
        return "normal_combination_skin"
    return ""


def infer_body_area(product: dict) -> str:
    explicit = _master_body_area(product)
    if explicit:
        return explicit
    raw = normalize_text(_field(product, "body_area", "area"))
    blob = _identity(product)
    if raw in {"face", "body", "baby", "hair", "mouth", "feminine"}:
        return raw
    if any(_contains(blob, w) for w in ["baby", "kids", "اطفال", "طفل", "حفاض"]):
        return "baby"
    if any(_contains(blob, w) for w in ["hair", "scalp", "shampoo", "conditioner", "شعر", "شامبو"]):
        return "hair"
    if any(_contains(blob, w) for w in ["body wash", "body lotion", "body", "corps", "جسم"]):
        return "body"
    if any(_contains(blob, w) for w in ["vag", "vaginal", "feminine", "نسائي", "نسائية"]):
        return "feminine"
    if any(_contains(blob, w) for w in ["face", "facial", "visage", "cleanser", "serum", "spf", "وجه", "بشرة"]):
        return "face"
    return ""


def infer_use_case(product: dict) -> str:
    explicit = _canon(_MENU_ALIASES, _field(product, "use_case"))
    if explicit:
        return explicit
    raw = normalize_text(_field(product, "use_case"))
    blob = _identity(product)
    if raw:
        return raw.replace(" ", "_")
    if any(w in blob for w in ["acne", "blemish", "effaclar", "sebium", "cleanance", "حبوب"]):
        return "acne"
    if any(w in blob for w in ["hydrating", "moisturizing", "atoderm", "xerolact", "lipikar", "مرطب"]):
        return "hydration"
    if any(w in blob for w in ["spf", "sunscreen", "sunblock", "واقي"]):
        return "sun_protection"
    if any(w in blob for w in ["dandruff", "anti dandruff", "قشره", "قشرة"]):
        return "dandruff"
    if any(w in blob for w in ["hair loss", "anti hair loss", "تساقط"]):
        return "hair_loss"
    return ""


def infer_section(product: dict) -> Tuple[str, float]:
    explicit = _master_section(product)
    if explicit:
        return explicit, 0.99
    cat = normalize_text(_field(product, "category", "category_guess"))
    # category can also carry a final guided section in products_master_v22_ready.xlsx.
    cat_section = _canon(_SECTION_ALIASES, cat)
    if cat_section and cat_section not in {"skin_care"} or cat in {"medicine", "ادويه", "ادوية"}:
        if cat_section:
            return cat_section, 0.94
    blob = _identity(product)
    ptype = infer_product_type(product)
    # Specific sections first to avoid baby wash/body wash becoming face cleanser.
    if any(w in blob for w in ["baby", "kids", "اطفال", "طفل", "حفاض", "infant"]):
        return "baby", 0.88
    if ptype in {"blood_pressure", "glucose_meter", "thermometer", "respiratory_devices", "masks_supplies", "bandage_gauze"} or any(w in blob for w in ["device", "meter", "glucose", "pressure", "thermometer", "nebulizer", "spirometer", "mask", "bandage", "gauze", "جهاز", "قياس", "كمامة", "شاش"]):
        return "devices", 0.88
    if ptype in {"shampoo", "conditioner", "hair_oil_serum"} or any(w in blob for w in ["hair", "scalp", "shampoo", "conditioner", "dandruff", "keratin", "شعر", "شامبو", "قشرة", "تساقط"]):
        return "hair_care", 0.86
    if infer_supplement_category(product):
        return "supplements", 0.87
    if cat in {"medicine", "ادويه", "ادوية"}:
        return "medicine", 0.86
    if cat in {"cosmetic", "skin_care", "beauty"} or ptype in {"face_cleanser", "moisturizer", "sunscreen", "serum", "acne_treatment", "exfoliator", "cream", "lotion", "body_wash"} or any(w in blob for w in ["skin", "face", "cleanser", "cream", "lotion", "serum", "sunscreen", "spf", "بشرة", "وجه", "كريم", "غسول", "لوشن"]):
        return "skin_care", 0.82
    medicine_signal = any(w in blob for w in ["tablet", "capsule", "syrup", "suppository", "injection", "mg", "panadol", "flagyl", "amoclan", "zofran", "ondansetron", "gyno daktarin"])
    if medicine_signal:
        return "medicine", 0.82
    return "other", 0.35


def infer_medicine_category(product: dict) -> str:
    blob = _identity(product)
    if any(w in blob for w in ["panadol", "paracetamol", "ibuprofen", "brufen", "cataflam", "voltaren", "diclofenac", "pain", "fever", "مسكن", "خافض"]):
        return "pain_fever"
    if any(w in blob for w in ["ondansetron", "zofran", "motilium", "domperidone", "omeprazole", "esomeprazole", "gaviscon", "antiemetic", "stomach", "معده", "معدة", "قيء"]):
        return "stomach_vomiting"
    if any(w in blob for w in ["zyrtec", "telfast", "claritine", "cetirizine", "loratadine", "allergy", "cold", "congestal", "زكام", "حساسي"]):
        return "allergy_cold"
    if any(w in blob for w in ["skin", "derm", "ointment", "cream", "جلديه", "جلدية"]):
        return "dermatology"
    if any(w in blob for w in ["gyno", "vag", "vaginal", "daktarin", "نسائي", "نسائية"]):
        return "gynecology"
    if any(w in blob for w in ["antibiotic", "amoclan", "augmentin", "amoxicillin", "azithro", "flagyl", "metronidazole", "مضاد"]):
        return "antibiotic"
    if any(w in blob for w in ["concor", "glucophage", "metformin", "insulin", "amlodipine", "pressure", "diabetes", "سكر", "ضغط", "قلب"]):
        return "chronic"
    if any(w in blob for w in ["drops", "drop", "eye", "ear", "nasal", "قطرة", "قطرات", "انف", "اذن", "عين"]):
        return "drops"
    return ""


def infer_supplement_category(product: dict) -> str:
    blob = _identity(product)
    if any(w in blob for w in ["iron", "ferro", "ferrous", "feroglobin", "ferritin", "حديد"]):
        return "iron"
    if any(w in blob for w in ["vitamin d", "vit d", "d3", "cholecalciferol", "فيتامين د"]):
        return "vitamin_d"
    if any(w in blob for w in ["calcium", "كالسيوم"]):
        return "calcium"
    if any(w in blob for w in ["magnesium", "مغنيسيوم"]):
        return "magnesium"
    if any(w in blob for w in ["zinc", "زنك"]):
        return "zinc"
    if any(w in blob for w in ["vitamin c", "vit c", "ascorbic", "فيتامين سي"]):
        return "vitamin_c"
    if any(w in blob for w in ["multivitamin", "multi vitamin", "centrum", "سنتروم"]):
        return "multivitamin"
    if any(w in blob for w in ["kids vitamin", "children vitamin", "pediatric vitamin", "اطفال فيتامين", "فيتامينات اطفال"]):
        return "kids_vitamins"
    if any(w in blob for w in ["pregnancy", "pregnacare", "prenatal", "حمل", "الحمل"]):
        return "pregnancy_supplements"
    return ""


def infer_hair_category(product: dict) -> str:
    blob = _identity(product)
    ptype = infer_product_type(product)
    if any(w in blob for w in ["baby", "kids", "اطفال"]):
        return "baby_hair"
    if ptype == "conditioner":
        return "conditioner"
    if ptype == "hair_oil_serum" or any(w in blob for w in ["hair oil", "hair serum", "زيت شعر", "سيروم شعر"]):
        return "hair_oil_serum"
    if ptype == "shampoo":
        return "shampoo"
    if any(w in blob for w in ["dandruff", "anti dandruff", "قشره", "قشرة"]):
        return "dandruff"
    if any(w in blob for w in ["hair loss", "anti hair loss", "تساقط"]):
        return "hair_loss"
    return ""


def infer_baby_category(product: dict) -> str:
    blob = _identity(product)
    ptype = infer_product_type(product)
    if ptype == "diapers" or any(w in blob for w in ["diaper", "حفاض"]):
        return "diapers"
    if ptype in {"baby_wash", "shampoo"} or any(w in blob for w in ["baby wash", "kids wash", "baby shampoo", "غسول اطفال", "شامبو اطفال"]):
        return "baby_wash"
    if any(w in blob for w in ["baby cream", "diaper cream", "كريم اطفال", "كريم حفاض"]):
        return "baby_creams"
    if any(w in blob for w in ["milk", "formula", "food", "حليب", "غذاء"]):
        return "baby_milk_food"
    return "baby_supplies"


def infer_device_category(product: dict) -> str:
    blob = _identity(product)
    ptype = infer_product_type(product)
    if ptype == "blood_pressure" or any(w in blob for w in ["pressure", "blood pressure", "جهاز ضغط", "قياس ضغط"]):
        return "blood_pressure"
    if ptype == "glucose_meter" or any(w in blob for w in ["glucose", "glucometer", "sugar", "جهاز سكر", "قياس سكر"]):
        return "glucose_meter"
    if ptype == "thermometer" or any(w in blob for w in ["thermometer", "ترمومتر"]):
        return "thermometer"
    if ptype == "respiratory_devices" or any(w in blob for w in ["nebulizer", "spirometer", "oxygen", "جهاز تنفس"]):
        return "respiratory_devices"
    if ptype == "masks_supplies" or any(w in blob for w in ["mask", "كمامه", "كمامة"]):
        return "masks_supplies"
    if ptype == "bandage_gauze" or any(w in blob for w in ["bandage", "gauze", "شاش", "ضماد"]):
        return "bandage_gauze"
    return ""


def guided_index_row(product: dict) -> dict:
    section, conf = infer_section(product)
    ptype = infer_product_type(product)
    skin = infer_skin_type(product)
    area = infer_body_area(product)
    use = infer_use_case(product)
    menu1 = _master_menu(product, section)
    if section == "skin_care" and ptype == "face_cleanser" and menu1 in {"", "acne_treatment", "body_care"}:
        menu1 = "face_cleanser"
    if section == "hair_care" and ptype == "shampoo" and menu1 in {"", "dandruff", "hair_loss"}:
        menu1 = "shampoo"
    if section == "baby" and ptype == "baby_wash" and menu1 in {"", "shampoo"}:
        menu1 = "baby_wash"
    if not menu1:
        if section == "medicine":
            menu1 = infer_medicine_category(product)
        elif section == "supplements":
            menu1 = infer_supplement_category(product)
        elif section == "skin_care":
            if area == "body" or ptype == "body_wash":
                menu1 = "body_care"
            elif ptype in {"face_cleanser", "moisturizer", "sunscreen", "serum", "acne_treatment", "exfoliator"}:
                menu1 = ptype
            elif ptype in {"cream", "lotion"}:
                menu1 = "moisturizer"
            else:
                menu1 = ""
        elif section == "hair_care":
            menu1 = infer_hair_category(product)
        elif section == "baby":
            menu1 = infer_baby_category(product)
        elif section == "devices":
            menu1 = infer_device_category(product)
    # Safety corrections: never let master/inference place baby/body/hair wash in adult face cleanser.
    if section == "skin_care" and menu1 == "face_cleanser" and area in {"baby", "body", "hair"}:
        menu1 = "body_care" if area == "body" else ""
        conf = min(conf, 0.45)
    guided_visible = _is_guided_visible(product)
    tags = sorted(set(filter(None, [section, menu1, ptype, skin, area, use] + _identity(product).split())))
    if _has_master_guided_fields(product) and section != "other" and menu1:
        conf = max(conf, 0.95)
    return {
        "product_id": _pid(product),
        "section": section,
        "menu_level_1": menu1,
        "menu_level_2": skin if section == "skin_care" else "",
        "menu_level_3": "",
        "product_type": ptype,
        "use_case": use,
        "skin_type": skin,
        "body_area": area,
        "is_available": 1 if guided_visible else 0,
        "confidence": conf if menu1 or section in {"other"} else min(conf, 0.55),
        "tags_json": json.dumps(tags[:80], ensure_ascii=False),
    }


def build_guided_catalog_rows(products: Sequence[dict]) -> List[dict]:
    return [guided_index_row(p) for p in products or []]


def _available_products(products: Sequence[dict]) -> List[dict]:
    # exact_only/review_only products remain available through exact name/alias/barcode lookup,
    # but must not be shown inside broad guided menus.
    return [p for p in (products or []) if _is_guided_visible(p)]


def _menu_has_products(section: str, products: Sequence[dict]) -> bool:
    for p in products or []:
        row = guided_index_row(p)
        if row["section"] == section and row["is_available"]:
            return True
    return False


def _submenu_options(section: str, products: Sequence[dict]) -> List[dict]:
    rows = [guided_index_row(p) for p in _available_products(products)]
    available_submenus = {r["menu_level_1"] for r in rows if r["section"] == section and r["is_available"]}
    opts = []
    for cid, label in _MENU_BY_SECTION.get(section, []):
        if cid.startswith("search_") or cid in available_submenus:
            opts.append({"id": cid, "label": label})
    return opts


def _main_options(products: Sequence[dict]) -> List[dict]:
    rows = [guided_index_row(p) for p in _available_products(products)]
    available_sections = {r["section"] for r in rows if r["is_available"] and r["section"] != "other"}
    opts = []
    for cid, label in _MAIN_ORDER:
        if cid in {"search_by_name", "send_image"}:
            opts.append({"id": cid, "label": label})
        elif cid in available_sections:
            opts.append({"id": cid, "label": label})
    return opts


def _filter_products(section: str, submenu: str, products: Sequence[dict], *, skin_type: str = "", brand: str = "", brand_label: str = "", limit: int = 500) -> List[dict]:
    out: List[Tuple[int, dict]] = []
    for p in _available_products(products):
        if brand and not _brand_matches_product(p, brand, brand_label):
            continue
        row = guided_index_row(p)
        if row["section"] != section or row["menu_level_1"] != submenu:
            continue
        ident = _identity(p)
        # Strong safety gates requested by the user.
        if section == "skin_care" and submenu == "face_cleanser":
            if row["body_area"] in {"baby", "body", "hair", "mouth"}:
                continue
            if any(_contains(ident, w) for w in ["baby wash", "body wash", "shower gel", "shampoo", "غسول اطفال", "غسول جسم", "شامبو"]):
                continue
            if row["product_type"] != "face_cleanser":
                continue
        if section == "hair_care" and row["body_area"] not in {"hair", ""}:
            continue
        if section == "baby" and row["body_area"] not in {"baby", ""} and not any(w in ident for w in ["baby", "kids", "اطفال", "طفل"]):
            continue
        if section == "devices" and row["product_type"] not in {"blood_pressure", "glucose_meter", "thermometer", "respiratory_devices", "masks_supplies", "bandage_gauze", "product"}:
            continue
        score = 0
        if skin_type and skin_type != "unknown" and section == "skin_care":
            pskin = row["skin_type"]
            compatible = _skin_compatible(skin_type, pskin, row["use_case"])
            if not compatible:
                continue
            if pskin == skin_type:
                score += 30
            if skin_type == "oily_skin" and row["use_case"] == "acne":
                score += 15
            if skin_type == "dry_skin" and row["use_case"] == "hydration":
                score += 15
        score += int(float(row["confidence"] or 0) * 100)
        out.append((score, p))
    out.sort(key=lambda x: (-x[0], normalize_text(x[1].get("name"))))
    return [p for _, p in out[:limit]]


def _skin_compatible(requested: str, product_skin: str, use_case: str = "") -> bool:
    if not requested or requested == "unknown":
        return True
    if not product_skin:
        return False
    if product_skin == requested:
        return True
    if requested == "oily_skin" and product_skin in {"normal_oily_skin", "acne_prone_skin", "combination_oily_skin"}:
        return True
    if requested == "oily_skin" and use_case in {"acne", "oil_control"}:
        return True
    if requested == "dry_skin" and product_skin in {"very_dry_skin", "dry_sensitive_skin"}:
        return True
    if requested == "sensitive_skin" and product_skin in {"dry_sensitive_skin", "sensitive"}:
        return True
    if requested == "normal_combination_skin" and product_skin in {"normal_skin", "combination_skin", "normal_oily_skin"}:
        return True
    return False

# ---------------------------------------------------------------------------
# Replies / flow handlers
# ---------------------------------------------------------------------------

def build_main_menu(products: Optional[Sequence[dict]] = None) -> GuidedResult:
    if products is None:
        try:
            import database
            products = database.load_products()
        except Exception:
            products = []
    opts = _main_options(products)
    reply = _menu_reply(f"أهلاً بك في {_pharmacy_name()} 🌿\nاختر القسم:\nاختر طريقة البحث أو التصفح:", opts)
    return GuidedResult(True, reply, "guided_main_menu", _state("main_menu", "main_menu", last_options=opts, last_options_type="main_menu"), options=opts)


def _browse_categories_alias(products: Sequence[dict]) -> GuidedResult:
    result = build_main_menu(products)
    result.decision = "guided_categories"
    return result


def _show_submenu(section: str, products: Sequence[dict]) -> GuidedResult:
    opts = _submenu_options(section, products)
    title = {
        "medicine": "اختر القسم من الأدوية:",
        "supplements": "اختر القسم من المكملات والفيتامينات:",
        "skin_care": "اختر القسم من عناية البشرة — ماذا تريد؟",
        "hair_care": "اختر القسم من عناية الشعر — ماذا تريد؟",
        "baby": "اختر القسم من الأطفال:",
        "devices": "اختر القسم من الأجهزة والمستلزمات:",
    }.get(section, "اختر القسم:")
    # Keep decision name broad so older V22.2 routing tests that only verify guided category routing still pass.
    decision = "guided_categories" if section in {"medicine", "supplements", "skin_care", "hair_care", "baby", "devices"} else f"guided_{section}_menu"
    return GuidedResult(True, _menu_reply(title, opts), decision, _state(section, "submenu", selected_section=section, last_options=opts, last_options_type="submenu"), options=opts)


def _ask_skin_type(section: str, submenu: str, *, brand: str = "", brand_label: str = "") -> GuidedResult:
    opts = [{"id": cid, "label": label} for cid, label in _SKIN_TYPE_MENU]
    return GuidedResult(True, _menu_reply("نوع البشرة؟", opts), "guided_ask_skin_type", _state(section, "skin_type", selected_section=section, selected_submenu=submenu, selected_brand=brand, selected_brand_label=brand_label, last_options=opts), options=opts)


def _products_reply(section: str, submenu: str, products: Sequence[dict], *, skin_type: str = "", page: int = 0, brand: str = "", brand_label: str = "") -> GuidedResult:
    hits = _filter_products(section, submenu, products, skin_type=skin_type, brand=brand, brand_label=brand_label)
    if not hits:
        label = _SUB_LABELS.get(submenu, submenu)
        return GuidedResult(True, f"لا توجد منتجات متوفرة حالياً في: {label}.\nاختر قسماً آخر أو اكتب اسم منتج كامل.", "guided_no_products", _state(section, "submenu", selected_section=section, last_options=_submenu_options(section, products)))
    page = max(0, int(page or 0))
    start = page * PAGE_SIZE
    end = start + PAGE_SIZE
    visible = hits[start:end]
    lines = []
    for i, p in enumerate(visible, 1):
        price = _price_text(p)
        price_part = f" - {price}" if price else ""
        lines.append(f"{i}. {_h(p.get('name'))}{price_part} - متوفر")
    title = f"المنتجات المتوفرة - {_SUB_LABELS.get(submenu, submenu)}:"
    reply = title + "\n\n" + "\n".join(lines)
    if end < len(hits):
        reply += "\n\nاكتب \"المزيد\" لعرض الصفحة التالية."
    reply += "\n\nاكتب رقم المنتج للحجز أو \"القائمة\" للرجوع."
    state = {
        "current_flow": "guided_results", "step": "product_selection", "selected_section": section, "selected_submenu": submenu,
        "selected_skin_type": skin_type, "selected_brand": brand, "selected_brand_label": brand_label, "last_options": visible, "all_options": hits, "page": page,
        "last_options_type": "products", "expires_at": int(time.time()) + GUIDED_TTL_SECONDS,
    }
    return GuidedResult(True, reply, "guided_products", {GUIDED_STATE_KEY: state}, options=visible)


def _product_selected(product: dict) -> GuidedResult:
    price = _price_text(product)
    reply = f"✅ المنتج متوفر\nالاسم: {_h(product.get('name'))}"
    if price:
        reply += f"\nالسعر: {price}"
    reply += "\n\nللحجز اكتب: نعم"
    return GuidedResult(True, reply, "guided_product_selected", {"last_product": product, GUIDED_STATE_KEY: None}, product=product)


def _search_instruction(medicine: bool = False) -> GuidedResult:
    if medicine:
        txt = "اكتب اسم الدواء كاملًا كما هو على العلبة. إذا كان الاسم ناقصاً سأطلب الشكل أو الجرعة قبل عرض السعر."
    else:
        txt = "اكتب اسم المنتج الكامل كما هو على العلبة. الكلمات العامة مثل غسول/كريم/حديد تبقى ضمن القوائم."
    return GuidedResult(True, txt, "guided_search_instruction", _state("free_search", "awaiting_search_query"))


def _image_instruction() -> GuidedResult:
    return GuidedResult(True, "أرسل صورة واضحة للواجهة الأمامية للمنتج، ويُفضّل أن يظهر الاسم والحجم بوضوح.", "guided_image_instruction", {GUIDED_STATE_KEY: None})


def handle_menu_selection(phone: str, text: str, user_state: dict, products: Sequence[dict]) -> Optional[GuidedResult]:
    state = _guided_state(user_state)
    if not state:
        return None
    q = normalize_text(text)

    # Free-search state: only full/specific product names are allowed to fall through to exact/search.
    if state.get("step") == "awaiting_search_query":
        if is_generic_guided_query(text):
            return GuidedResult(True, "اكتب اسم المنتج الكامل كما هو على العلبة، أو اختر من القوائم.", "guided_search_needs_full_name", _state("free_search", "awaiting_search_query"))
        return None

    if q in _PAGE_MORE_WORDS and state.get("all_options"):
        section = str(state.get("selected_section") or "")
        submenu = str(state.get("selected_submenu") or "")
        skin = str(state.get("selected_skin_type") or "")
        next_page = int(state.get("page") or 0) + 1
        return _products_reply(section, submenu, products, skin_type=skin, page=next_page, brand=str(state.get("selected_brand") or ""), brand_label=str(state.get("selected_brand_label") or ""))

    # Product number must select from last displayed product page, never enter product search.
    if state.get("last_options_type") == "products":
        chosen_product = _selected_option(text, state.get("last_options") or [])
        if chosen_product and chosen_product.get("name"):
            return _product_selected(chosen_product)
        if q.isdigit():
            return GuidedResult(True, "اختر رقم منتج من القائمة الظاهرة أو اكتب المزيد.", "guided_invalid_product_number", {GUIDED_STATE_KEY: state})

    chosen = _selected_option(text, state.get("last_options") or [])
    if not chosen:
        return None
    cid = str(chosen.get("id") or "")

    if cid == "search_by_name":
        return _search_instruction(False)
    if cid == "send_image":
        return _image_instruction()
    if cid in {"medicine", "supplements", "skin_care", "hair_care", "baby", "devices"}:
        result = _show_submenu(cid, products)
        # Numeric selection from the top main menu keeps the broad
        # guided_categories decision for V22.2 routing compatibility.
        if not (state.get("step") == "main_menu" and q.isdigit()):
            if cid == "skin_care":
                result.decision = "guided_skin_care"
            elif cid == "hair_care":
                result.decision = "guided_hair_care"
            elif cid == "medicine":
                result.decision = "guided_medicine_menu"
        return result
    if cid == "search_medicine":
        return _search_instruction(True)

    section = str(state.get("selected_section") or state.get("current_flow") or "")
    step = str(state.get("step") or "")
    if step == "brand_product_type":
        brand = str(state.get("brand") or state.get("selected_brand") or "")
        brand_label = str(state.get("brand_label") or state.get("selected_brand_label") or "")
        if cid in {"face_cleanser", "moisturizer", "sunscreen", "serum", "acne_treatment"}:
            return _ask_skin_type("skin_care", cid, brand=brand, brand_label=brand_label)
        if cid == "body_care":
            return _products_reply("skin_care", "body_care", products, brand=brand, brand_label=brand_label)
        if cid in {"shampoo", "conditioner", "hair_oil_serum", "dandruff", "hair_loss", "baby_hair"}:
            return _products_reply("hair_care", cid, products, brand=brand, brand_label=brand_label)
        return _products_reply("skin_care", cid, products, brand=brand, brand_label=brand_label)

    if step == "submenu" and section:
        if section == "skin_care" and cid in {"face_cleanser", "moisturizer", "sunscreen", "serum", "acne_treatment"}:
            return _ask_skin_type(section, cid)
        return _products_reply(section, cid, products)

    if step == "skin_type":
        section = str(state.get("selected_section") or "skin_care")
        submenu = str(state.get("selected_submenu") or "face_cleanser")
        skin_type = cid if cid != "unknown" else ""
        return _products_reply(section, submenu, products, skin_type=skin_type, brand=str(state.get("selected_brand") or ""), brand_label=str(state.get("selected_brand_label") or ""))

    return None


def is_generic_guided_query(text: str) -> bool:
    q = normalize_text(text)
    if not q:
        return False
    if q in {normalize_text(x) for x in _MAIN_TRIGGERS}:
        return True
    if q in {normalize_text(k) for k in _GENERIC_TO_ROUTE}:
        return True
    # Brand-only or type-only should browse/ask, not search freely.
    brand_only = {"cerave", "cera ve", "سيرافي", "bioderma", "بيوديرما", "rilastil", "ريلاستيل", "laroche", "la roche", "لاروش"}
    if q in {normalize_text(x) for x in brand_only}:
        return True
    generic_terms = {"غسول", "كريم", "لوشن", "سيروم", "واقي", "واقي شمس", "شامبو", "حديد", "فيتامين", "فيتامينات", "ادويه", "ادوية", "عناية", "عنايه"}
    if q in {normalize_text(x) for x in generic_terms}:
        return True
    return False


def _route_generic(text: str, products: Sequence[dict]) -> Optional[GuidedResult]:
    q = normalize_text(text)
    # Specific face-cleanser + skin-type phrases should jump directly to
    # products. Plain "غسول" remains a guided menu, not free search.
    if _contains(q, "غسول") and not _contains(q, "baby") and not _contains(q, "body"):
        if any(_contains(q, w) or normalize_text(w) in q for w in ["دهنيه", "دهنية", "oily"]):
            return _products_reply("skin_care", "face_cleanser", products, skin_type="oily_skin")
        if any(_contains(q, w) or normalize_text(w) in q for w in ["جافه", "جافة", "dry"]):
            return _products_reply("skin_care", "face_cleanser", products, skin_type="dry_skin")
        if any(_contains(q, w) or normalize_text(w) in q for w in ["حساسه", "حساسة", "sensitive"]):
            return _products_reply("skin_care", "face_cleanser", products, skin_type="sensitive_skin")
        if q == normalize_text("غسول"):
            return _show_submenu("skin_care", products)
    if q in {normalize_text("browse_categories"), normalize_text("تصفح الأقسام"), normalize_text("تصفح الاقسام"), normalize_text("الأقسام"), normalize_text("الاقسام")}:
        return _browse_categories_alias(products)
    if q in {normalize_text(x) for x in _MAIN_TRIGGERS}:
        return build_main_menu(products)
    brand_match = _canonical_brand_query(text)
    if brand_match:
        return _ask_brand_type(text, products)

    # Top-level labels without state.
    for cid, label in _MAIN_ORDER:
        if q in {normalize_text(cid), normalize_text(label)}:
            if cid == "search_by_name":
                return _search_instruction(False)
            if cid == "send_image":
                return _image_instruction()
            result = _show_submenu(cid, products)
            if cid == "skin_care":
                result.decision = "guided_skin_care"
            elif cid == "hair_care":
                result.decision = "guided_hair_care"
            elif cid == "medicine":
                result.decision = "guided_medicine_menu"
            return result
    # Submenu labels without state.
    for section, submenu_list in _MENU_BY_SECTION.items():
        for cid, label in submenu_list:
            if q in {normalize_text(cid), normalize_text(label)}:
                if section == "skin_care" and cid in {"face_cleanser", "moisturizer", "sunscreen", "serum", "acne_treatment"}:
                    return _ask_skin_type(section, cid)
                if cid == "search_medicine":
                    return _search_instruction(True)
                return _products_reply(section, cid, products)
    # Generic words.
    for key, (section, submenu) in _GENERIC_TO_ROUTE.items():
        if q == normalize_text(key):
            if submenu:
                if section == "skin_care" and submenu in {"face_cleanser", "moisturizer", "sunscreen", "serum", "acne_treatment"}:
                    return _ask_skin_type(section, submenu)
                return _products_reply(section, submenu, products)
            return _show_submenu(section, products)
    # Broad contains for common Arabic text.
    if _contains(q, "غسول") and not _contains(q, "baby") and not _contains(q, "body"):
        return _ask_skin_type("skin_care", "face_cleanser")
    if _contains(q, "شامبو"):
        return _products_reply("hair_care", "shampoo", products)
    return None


def handle_guided_query(phone: str, text: str, user_state: dict, products: Sequence[dict]) -> Optional[GuidedResult]:
    state_result = handle_menu_selection(phone, text, user_state, products)
    if state_result:
        return state_result
    q = normalize_text(text)
    if q.isdigit() and 1 <= int(q) <= 10 and not any((user_state or {}).get(k) for k in ["pending_variant_options", "pending_alternatives", "last_product", "pending_order_quantity"]):
        return build_main_menu(products)
    return _route_generic(text, products)

# ---------------------------------------------------------------------------
# Compatibility helpers used by image/matcher paths
# ---------------------------------------------------------------------------

def filter_products_by_guided_slots(slots: Dict[str, Any], products: Sequence[dict], limit: int = 8) -> List[dict]:
    section = str(slots.get("selected_category") or slots.get("selected_section") or "skin_care")
    ptype = str(slots.get("selected_product_type") or slots.get("form") or "")
    submenu = {
        "face_cleanser": "face_cleanser", "cleanser": "face_cleanser", "moisturizer": "moisturizer", "lotion": "moisturizer",
        "cream": "moisturizer", "sunscreen": "sunscreen", "serum": "serum", "shampoo": "shampoo",
    }.get(ptype, ptype or "face_cleanser")
    skin = str(slots.get("selected_skin_type") or "")
    return _filter_products(section, submenu, products, skin_type=skin, limit=limit)


def cosmetic_alternative_fit_gate(target_slots: Dict[str, Any], alternatives: Sequence[dict], limit: int = 3) -> List[dict]:
    return filter_products_by_guided_slots(target_slots, alternatives, limit=limit)


def build_image_cosmetic_clarification(ai_data: dict) -> GuidedResult:
    form = normalize_text(ai_data.get("form") or ai_data.get("product_type") or ai_data.get("type") or "")
    submenu = "face_cleanser" if form in {"cleanser", "face wash", "wash", "غسول"} else form or "face_cleanser"
    slots = {"selected_section": "skin_care", "selected_submenu": submenu}
    return _ask_skin_type("skin_care", submenu)


def build_whatsapp_list_payload(to_number: str, body: str, button_text: str, rows: Sequence[dict]) -> dict:
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "list",
            "body": {"text": str(body or "")[:1024]},
            "action": {
                "button": str(button_text or "اختر")[:20],
                "sections": [{"title": "الخيارات", "rows": [{"id": str(r.get("id") or i), "title": str(r.get("label") or r.get("name") or r.get("id"))[:24]} for i, r in enumerate(rows, 1)]}],
            },
        },
    }
