# -*- coding: utf-8 -*-
"""Deterministic company-grade product search engine for PriceBot V22.

This service complements the existing strict matcher. It never performs global
fuzzy fallback; any fuzzy/token matching is scoped by strong tokens and product
identity fields. The engine can run directly on the current products table or on
`product_search_index` built by tools/rebuild_search_index.py.
"""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from services.text_normalizer import (
    WEAK_TOKENS, compact_text, contains_phrase, is_generic_query, normalize_text,
    split_aliases, strong_tokens, token_set, tokens, weak_tokens,
)
try:
    from services.catalog_alignment import align_product, build_aliases
except Exception:  # pragma: no cover - defensive for partial deployments
    align_product = None
    build_aliases = None

DECISION_EXACT = "EXACT_MATCH"
DECISION_ASK = "ASK_CLARIFICATION"
DECISION_NOT_AVAILABLE = "NOT_AVAILABLE"
DECISION_LOW = "LOW_CONFIDENCE"
DECISION_GUIDED = "GUIDED_FLOW"

GENERAL_BRAND_QUERIES = {"cerave", "rilastil", "bioderma", "la roche", "eucerin"}

_PRODUCTS_CACHE = {"ts": 0.0, "count": -1, "products": [], "index": None}


@dataclass
class SearchHit:
    product: dict
    score: float
    layer: str
    reason: str = ""

@dataclass
class SearchDecision:
    decision: str
    query: str
    normalized_query: str
    product: Optional[dict] = None
    options: List[dict] = field(default_factory=list)
    score: float = 0.0
    reason: str = ""
    elapsed_ms: float = 0.0


def _product_id(product: dict) -> str:
    return str(product.get("product_id") or product.get("id") or "")


def _field(product: dict, *keys: str) -> str:
    for key in keys:
        val = product.get(key)
        if val not in (None, ""):
            return str(val)
    return ""


def _available(product: dict) -> bool:
    value = normalize_text(product.get("available") or "")
    return value not in {"0", "false", "no", "غير متوفر", "نفد", "unavailable"}


def _is_exact_only(product: dict) -> bool:
    mode = normalize_text(product.get("search_mode") or product.get("quality_status") or "")
    return "exact_only" in mode


def _aligned(product: dict) -> dict:
    # V22.2 stability/speed: runtime catalog alignment is intentionally disabled
    # by default because it is CPU-heavy and made index rebuild/startup slow on
    # real 4,991-row catalogs. The enrichment/alignment should be done offline.
    if not isinstance(product, dict) or product.get("__aligned_v22"):
        return product
    if os.getenv("PRICEBOT_ENABLE_RUNTIME_ALIGNMENT", "").lower() not in {"1", "true", "yes", "on"}:
        return product
    if align_product is None:
        return product
    try:
        merged = dict(product)
        a = align_product(product)
        weak_existing = {"", None, "other", "unknown", "product"}
        for key, val in a.items():
            if key in {"available", "price"}:
                continue
            if val not in (None, "") and (merged.get(key) in weak_existing or key in {"product_type", "use_case", "skin_type", "body_area", "normalized_name"}):
                merged[key] = val
        if a.get("aliases"):
            merged["aliases"] = "; ".join([str(product.get("aliases") or ""), str(a.get("aliases") or "")]).strip("; ")
        if a.get("ocr_keywords"):
            merged["ocr_keywords"] = " ".join([str(product.get("ocr_keywords") or product.get("image_ocr_keywords") or ""), str(a.get("ocr_keywords") or "")]).strip()
        merged["__aligned_v22"] = True
        return merged
    except Exception:
        return product


def _identity(product: dict) -> str:
    p = _aligned(product)
    return normalize_text(" ".join(_field(p, k) for k in [
        "name", "brand", "company", "product_family", "category", "subcategory", "form", "product_type", "strength", "size", "pack",
        "aliases", "ocr_keywords", "image_ocr_keywords", "barcode", "code", "sku", "item_code", "product_code",
    ]))


def _cheap_generated_aliases(name: str) -> List[str]:
    n = normalize_text(name)
    out = []
    if n:
        out.append(n)
        compact = compact_text(n)
        if compact and compact != n:
            out.append(compact)
        # Photoblok 50+ is often typed as +Photoblok 50 or Photoblok 50.
        if "+" in str(name or "") or "+" in n:
            no_plus = normalize_text(str(name or "").replace("+", " "))
            if no_plus:
                out.extend([no_plus, "+" + no_plus])
        # 1,2,3 / 1 2 3 should be searchable as 123.
        digit_compact = re.sub(r"\D+", "", str(name or ""))
        if len(digit_compact) >= 2:
            out.append(digit_compact)
    final = []
    for item in out:
        if item and item not in final:
            final.append(item)
    return final


def product_index_row(product: dict) -> Dict[str, Any]:
    # Fast, additive index row. No runtime enrichment here: index rebuild must be
    # bounded and must never block service deployment.
    p = product
    name = normalize_text(p.get("normalized_name") or p.get("name"))
    aliases = split_aliases(p.get("aliases") or p.get("alias") or "")
    for alias in _cheap_generated_aliases(str(p.get("name") or "")):
        if alias and alias not in aliases:
            aliases.append(alias)
    ocr = normalize_text(p.get("ocr_keywords") or p.get("image_ocr_keywords") or p.get("keywords") or "")
    identity = " ".join([name, normalize_text(p.get("brand")), normalize_text(p.get("company")), normalize_text(p.get("product_family")), ocr, " ".join(aliases)])
    ts = token_set(identity)
    strong = {t for t in ts if t not in WEAK_TOKENS and len(t) >= 3}
    weak = ts - strong
    return {
        "product_id": _product_id(p),
        "normalized_name": name,
        "normalized_brand": normalize_text(p.get("brand") or p.get("company")),
        "normalized_aliases": ";".join(aliases),
        "normalized_ocr_keywords": ocr,
        "tokens_json": json.dumps(sorted(ts), ensure_ascii=False),
        "strong_tokens_json": json.dumps(sorted(strong), ensure_ascii=False),
        "weak_tokens_json": json.dumps(sorted(weak), ensure_ascii=False),
        "category": str(p.get("category") or ""),
        "product_type": str(p.get("product_type") or p.get("form") or p.get("type") or ""),
        "form": str(p.get("form") or ""),
        "strength": str(p.get("strength") or ""),
        "size": str(p.get("size") or p.get("pack") or ""),
        "search_mode": str(p.get("search_mode") or ""),
        "quality_status": str(p.get("quality_status") or ""),
    }


def build_memory_index(products: Sequence[dict]) -> Dict[str, Any]:
    name_map: Dict[str, List[dict]] = {}
    alias_map: Dict[str, List[dict]] = {}
    barcode_map: Dict[str, List[dict]] = {}
    for raw in products or []:
        p = _aligned(raw)
        n = normalize_text(p.get("normalized_name") or p.get("name"))
        if n:
            name_map.setdefault(n, []).append(p)
            name_map.setdefault(compact_text(n), []).append(p)
        alias_values = split_aliases(p.get("aliases") or "")
        # Add safe generated aliases such as Photoblok 50+ <-> +Photoblok 50.
        if build_aliases is not None:
            try:
                alias_values.extend([normalize_text(a) for a in build_aliases(p)])
            except Exception:
                pass
        for alias in alias_values:
            if alias and alias not in WEAK_TOKENS:
                alias_map.setdefault(alias, []).append(p)
                alias_map.setdefault(compact_text(alias), []).append(p)
        for key in ["barcode", "code", "sku", "item_code", "product_code", "source_serial"]:
            val = normalize_text(p.get(key) or "")
            if val:
                barcode_map.setdefault(val, []).append(p)
    return {"name": name_map, "alias": alias_map, "barcode": barcode_map, "products": list(products or [])}


def _unique(items: Sequence[dict]) -> List[dict]:
    seen = set()
    out = []
    for item in items:
        key = _product_id(item) or normalize_text(item.get("name"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _single_or_ask(query: str, qn: str, hits: List[dict], layer: str, elapsed: float) -> SearchDecision:
    hits = _unique(hits)
    if len(hits) == 1:
        return SearchDecision(DECISION_EXACT, query, qn, product=hits[0], score=1.0 if layer != "alias" else 0.98, reason=layer, elapsed_ms=elapsed)
    if len(hits) > 1:
        return SearchDecision(DECISION_ASK, query, qn, options=hits[:10], score=0.9, reason=f"multiple_{layer}", elapsed_ms=elapsed)
    return SearchDecision(DECISION_LOW, query, qn, reason="no_hits", elapsed_ms=elapsed)


def _is_specific_unavailable(qn: str) -> bool:
    st = strong_tokens(qn)
    # A single distinctive long token such as "Formag" is treated as a specific
    # product request, not a generic category. Brand-only queries are intercepted
    # as GUIDED_FLOW before this policy.
    return len(st) >= 2 or any(len(t) >= 5 for t in st) or bool(re.search(r"\d+(?:mg|ml|g|%)", qn))


def _scoped_candidates(qn: str, products: Sequence[dict]) -> List[dict]:
    qstrong = strong_tokens(qn)
    if not qstrong:
        return []
    candidates = []
    for p in products:
        if _is_exact_only(p):
            continue
        identity = _identity(p)
        pstrong = strong_tokens(identity)
        if qstrong & pstrong:
            candidates.append(p)
    return candidates


def _score(qn: str, product: dict) -> float:
    identity = _identity(product)
    if not identity:
        return 0.0
    qstrong = strong_tokens(qn)
    pstrong = strong_tokens(identity)
    overlap = len(qstrong & pstrong)
    base = 0.0
    if qstrong:
        base = overlap / max(len(qstrong), 1)
    phrase_bonus = 0.15 if contains_phrase(identity, qn) or contains_phrase(qn, product.get("name")) else 0.0
    ratio = SequenceMatcher(None, qn, normalize_text(product.get("name"))).ratio() * 0.20
    return min(0.91, base * 0.75 + phrase_bonus + ratio)


def _rows_to_unique_products(rows: Sequence[Any]) -> List[dict]:
    seen = set()
    out: List[dict] = []
    for row in rows or []:
        p = dict(row)
        key = str(p.get("id") or p.get("product_id") or normalize_text(p.get("name")))
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def _single_or_ask_db(query: str, qn: str, hits: List[dict], layer: str, started: float) -> SearchDecision:
    hits = _unique(hits)
    elapsed = (time.perf_counter() - started) * 1000
    if len(hits) == 1:
        return SearchDecision(DECISION_EXACT, query, qn, product=hits[0], score=1.0 if layer != "alias" else 0.98, reason=layer, elapsed_ms=elapsed)
    if len(hits) > 1:
        return SearchDecision(DECISION_ASK, query, qn, options=hits[:10], score=0.9, reason=f"multiple_{layer}", elapsed_ms=elapsed)
    return SearchDecision(DECISION_LOW, query, qn, reason="no_hits", elapsed_ms=elapsed)


def _load_products_cached(max_age_seconds: float = 2.0) -> List[dict]:
    """Small process-local product cache for non-exact fallback paths."""
    import database
    now = time.perf_counter()
    try:
        count = database.count_products()
    except Exception:
        count = -1
    if _PRODUCTS_CACHE["products"] and _PRODUCTS_CACHE["count"] == count and now - float(_PRODUCTS_CACHE["ts"] or 0) <= max_age_seconds:
        return list(_PRODUCTS_CACHE["products"])
    products = database.load_products()
    _PRODUCTS_CACHE.update({"ts": now, "count": len(products), "products": list(products), "index": None})
    return products


def invalidate_runtime_cache() -> None:
    _PRODUCTS_CACHE.update({"ts": 0.0, "count": -1, "products": [], "index": None})


def _exact_lookup_db(query: str, qn: str, started: float, timeout_ms: int = 250) -> SearchDecision:
    """Exact SQLite fast path; does not load all 4,991 products."""
    import database

    keys = [qn, compact_text(qn)]
    keys = [k for i, k in enumerate(keys) if k and k not in keys[:i]]
    if not keys:
        return SearchDecision(DECISION_LOW, query, qn, reason="empty", elapsed_ms=0.0)

    def elapsed() -> float:
        return (time.perf_counter() - started) * 1000

    with database.get_db_connection() as conn:
        # 1) Search-index exact normalized name. This is the fastest production path.
        try:
            placeholders = ",".join("?" for _ in keys)
            rows = conn.execute(
                f"""
                SELECT p.*
                FROM product_search_index i
                JOIN products p ON (CAST(p.id AS TEXT)=CAST(i.product_id AS TEXT) OR CAST(p.product_id AS TEXT)=CAST(i.product_id AS TEXT))
                WHERE i.normalized_name IN ({placeholders})
                LIMIT 11
                """,
                tuple(keys),
            ).fetchall()
            hits = _rows_to_unique_products(rows)
            if hits:
                return _single_or_ask_db(query, qn, hits, "exact_name", started)
        except Exception:
            pass

        if elapsed() > timeout_ms:
            return SearchDecision(DECISION_LOW, query, qn, reason="timeout_exact_name", elapsed_ms=elapsed())

        # 2) Products table exact normalized/raw name fallback. Keeps exact search working even if index is missing.
        try:
            candidates = []
            for key in keys:
                rows = conn.execute(
                    """
                    SELECT * FROM products
                    WHERE normalized_name=? OR lower(name)=? OR name=?
                    LIMIT 11
                    """,
                    (key, key, str(query or "").strip()),
                ).fetchall()
                candidates.extend(_rows_to_unique_products(rows))
            if candidates:
                return _single_or_ask_db(query, qn, candidates, "exact_name_db", started)
        except Exception:
            pass

        if elapsed() > timeout_ms:
            return SearchDecision(DECISION_LOW, query, qn, reason="timeout_exact_db", elapsed_ms=elapsed())

        # 3) Barcode/code exact lookup.
        if re.fullmatch(r"[a-z0-9+.-]{2,}", qn):
            try:
                placeholders = ",".join("?" for _ in keys)
                cols = ["barcode", "code", "sku", "item_code", "product_code", "product_id"]
                clauses = [f"CAST({c} AS TEXT) IN ({placeholders})" for c in cols]
                params = tuple(keys) * len(cols)
                rows = conn.execute(f"SELECT * FROM products WHERE {' OR '.join(clauses)} LIMIT 11", params).fetchall()
                hits = _rows_to_unique_products(rows)
                if hits:
                    return _single_or_ask_db(query, qn, hits, "barcode", started)
            except Exception:
                pass

        if elapsed() > timeout_ms:
            return SearchDecision(DECISION_LOW, query, qn, reason="timeout_barcode", elapsed_ms=elapsed())

        # 4) Exact alias lookup through index. Stored aliases are semicolon-separated normalized values.
        try:
            like_params: List[str] = []
            clauses: List[str] = []
            for key in keys:
                clauses.extend([
                    "i.normalized_aliases=?",
                    "i.normalized_aliases LIKE ?",
                    "i.normalized_aliases LIKE ?",
                    "i.normalized_aliases LIKE ?",
                ])
                like_params.extend([key, f"{key};%", f"%;{key}", f"%;{key};%"])
            rows = conn.execute(
                f"""
                SELECT p.*, i.normalized_aliases
                FROM product_search_index i
                JOIN products p ON (CAST(p.id AS TEXT)=CAST(i.product_id AS TEXT) OR CAST(p.product_id AS TEXT)=CAST(i.product_id AS TEXT))
                WHERE {' OR '.join(clauses)}
                LIMIT 11
                """,
                tuple(like_params),
            ).fetchall()
            hits = []
            keyset = set(keys)
            for row in rows:
                d = dict(row)
                aliases = set(split_aliases(d.get("normalized_aliases") or ""))
                if aliases & keyset:
                    hits.append({k: v for k, v in d.items() if k != "normalized_aliases"})
            if hits:
                return _single_or_ask_db(query, qn, hits, "alias", started)
        except Exception:
            pass

    return SearchDecision(DECISION_LOW, query, qn, reason="exact_not_found", elapsed_ms=elapsed())


def search_products_db(query: str, *, allow_guided: bool = True, exact_only: bool = False, timeout_ms: int = 250) -> SearchDecision:
    """Production entry point with a fast exact path and bounded fallback.

    - Greetings/generic terms can be routed to Guided Flow without loading products.
    - Exact name/alias/barcode uses SQLite/index lookup first.
    - Broader matching is allowed only after the route gate and is bounded.
    """
    started = time.perf_counter()
    qn = normalize_text(query)
    if not qn:
        return SearchDecision(DECISION_LOW, query, qn, reason="empty", elapsed_ms=0.0)
    if allow_guided and (is_generic_query(qn) or qn in GENERAL_BRAND_QUERIES):
        return SearchDecision(DECISION_GUIDED, query, qn, reason="generic_query", elapsed_ms=(time.perf_counter() - started) * 1000)
    exact = _exact_lookup_db(query, qn, started, timeout_ms=timeout_ms)
    if exact.decision in {DECISION_EXACT, DECISION_ASK}:
        return exact
    if exact_only:
        return exact
    if (time.perf_counter() - started) * 1000 > timeout_ms:
        return SearchDecision(DECISION_LOW, query, qn, reason="search_timeout_before_memory", elapsed_ms=(time.perf_counter() - started) * 1000)
    products = _load_products_cached()
    remaining = max(20, int(timeout_ms - ((time.perf_counter() - started) * 1000)))
    decision = search_products(query, products, allow_guided=allow_guided)
    decision.elapsed_ms = (time.perf_counter() - started) * 1000
    if decision.elapsed_ms > timeout_ms + remaining:
        return SearchDecision(DECISION_LOW, query, qn, reason="search_timeout", elapsed_ms=decision.elapsed_ms)
    return decision


def search_products(query: str, products: Sequence[dict], *, allow_guided: bool = True, index: Optional[dict] = None) -> SearchDecision:
    started = time.perf_counter()
    qn = normalize_text(query)
    if not qn:
        return SearchDecision(DECISION_LOW, query, qn, reason="empty", elapsed_ms=0.0)
    if allow_guided and (is_generic_query(qn) or qn in GENERAL_BRAND_QUERIES):
        return SearchDecision(DECISION_GUIDED, query, qn, reason="generic_query", elapsed_ms=(time.perf_counter()-started)*1000)
    idx = index or build_memory_index(products)
    # Layer 1 exact normalized name.
    for key in [qn, compact_text(qn)]:
        if key in idx["name"]:
            return _single_or_ask(query, qn, idx["name"][key], "exact_name", (time.perf_counter()-started)*1000)
    # Layer 2 exact alias.
    for key in [qn, compact_text(qn)]:
        if key in idx["alias"]:
            return _single_or_ask(query, qn, idx["alias"][key], "alias", (time.perf_counter()-started)*1000)
    # Layer 3 barcode/code.
    if re.fullmatch(r"[a-z0-9+.-]{2,}", qn):
        for key in [qn, compact_text(qn)]:
            if key in idx["barcode"]:
                return _single_or_ask(query, qn, idx["barcode"][key], "barcode", (time.perf_counter()-started)*1000)
    # Layer 4 normalized phrase match.
    phrase_hits = [p for p in products if not _is_exact_only(p) and (contains_phrase(_identity(p), qn) or contains_phrase(qn, p.get("name")))]
    phrase_hits = _unique(phrase_hits)
    if len(phrase_hits) == 1:
        return SearchDecision(DECISION_EXACT, query, qn, product=phrase_hits[0], score=0.93, reason="phrase_match", elapsed_ms=(time.perf_counter()-started)*1000)
    if len(phrase_hits) > 1:
        return SearchDecision(DECISION_ASK, query, qn, options=phrase_hits[:10], score=0.88, reason="multiple_phrase", elapsed_ms=(time.perf_counter()-started)*1000)
    # Layer 5 scoped token match, Layer 6 safe fuzzy scoped.
    candidates = _scoped_candidates(qn, products)
    scored = sorted([( _score(qn, p), p) for p in candidates], key=lambda x: x[0], reverse=True)
    scored = [(s, p) for s, p in scored if s >= 0.70]
    elapsed = (time.perf_counter()-started)*1000
    if scored and scored[0][0] >= 0.92:
        top_score = scored[0][0]
        tied = [p for s, p in scored if abs(s - top_score) < 0.03]
        if len(tied) == 1:
            return SearchDecision(DECISION_EXACT, query, qn, product=tied[0], score=top_score, reason="scoped_token", elapsed_ms=elapsed)
    if scored:
        return SearchDecision(DECISION_ASK, query, qn, options=[p for _, p in scored[:10]], score=scored[0][0], reason="scoped_ambiguous", elapsed_ms=elapsed)
    if _is_specific_unavailable(qn):
        return SearchDecision(DECISION_NOT_AVAILABLE, query, qn, score=0.0, reason="specific_not_found", elapsed_ms=elapsed)
    return SearchDecision(DECISION_LOW, query, qn, reason="low_confidence", elapsed_ms=elapsed)
