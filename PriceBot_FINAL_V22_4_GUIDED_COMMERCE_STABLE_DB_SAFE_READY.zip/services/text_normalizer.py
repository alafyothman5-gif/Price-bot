# -*- coding: utf-8 -*-
"""Company-grade text normalization utilities for PriceBot V22.

The normalizer is deliberately deterministic and conservative. It helps the
search and navigator indexes understand common Arabic/English spelling variants
without turning generic words into product matches.
"""
from __future__ import annotations

import re
from typing import Iterable, List, Set

AR_MAP = {
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ة": "ه", "ى": "ي", "ؤ": "و", "ئ": "ي",
    "ڤ": "ف", "پ": "ب", "چ": "ج", "گ": "ك", "ک": "ك", "ی": "ي",
}
NUM_MAP = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

BRAND_SYNONYMS = {
    "cera ve": "cerave", "cera-ve": "cerave", "ceravé": "cerave", "سيرافي": "cerave", "سيرا في": "cerave",
    "rilastil": "rilastil", "ريلاستيل": "rilastil",
    "bioderma": "bioderma", "بايودرما": "bioderma", "بيوديرما": "bioderma",
    "la roche posay": "la roche", "la-roche": "la roche", "laroche": "la roche", "لاروش بوزيه": "la roche", "لاروش": "la roche",
    "photoblock": "photoblok", "photo block": "photoblok", "فوتوبلوك": "photoblok",
    "flagyl": "flagyl", "فلاجيل": "flagyl", "فلاجل": "flagyl",
    "amoclan": "amoclan", "اموكلان": "amoclan", "اموكلان": "amoclan",
    "augmentin": "augmentin", "اوجمنتين": "augmentin",
    "gyno daktarin": "gyno daktarin", "gyno-daktarin": "gyno daktarin", "جينو داكتارين": "gyno daktarin",
}

WEAK_TOKENS = {
    "cream", "gel", "wash", "cleanser", "lotion", "serum", "skin", "face", "body", "baby",
    "moisturizer", "moisturiser", "shampoo", "conditioner", "sunscreen", "spf", "oil", "normal", "dry", "oily",
    "غسول", "كريم", "جل", "لوشن", "سيروم", "بشره", "بشرة", "وجه", "مرطب", "شامبو", "واقي", "شمس", "اطفال", "جسم",
    "tablet", "tablets", "tab", "capsule", "capsules", "cap", "syrup", "suspension", "شراب", "اقراص", "حبوب", "كبسول",
}

PUNCT_RE = re.compile(r"[^\w\s/%+.-]+", re.UNICODE)
SPACE_RE = re.compile(r"\s+")


def normalize_text(value: object) -> str:
    text = str(value or "").strip().lower()
    for src, dst in AR_MAP.items():
        text = text.replace(src, dst)
    text = text.translate(NUM_MAP)
    text = re.sub(r"[\u064b-\u065f]", "", text)
    text = text.replace("٪", "%")
    text = re.sub(r"(\d+)\s*مجم\b", r"\1mg", text)
    text = re.sub(r"(\d+)\s*مل\b", r"\1ml", text)
    text = re.sub(r"(\d+)\s*جم\b", r"\1g", text)
    text = re.sub(r"(\d+)\s*mg\b", r"\1mg", text)
    text = re.sub(r"(\d+)\s*ml\b", r"\1ml", text)
    text = re.sub(r"(\d+)\s*g\b", r"\1g", text)
    text = PUNCT_RE.sub(" ", text)
    text = SPACE_RE.sub(" ", text).strip()
    for k, v in sorted(BRAND_SYNONYMS.items(), key=lambda kv: -len(kv[0])):
        nk = SPACE_RE.sub(" ", PUNCT_RE.sub(" ", k.lower())).strip()
        if nk and f" {nk} " in f" {text} ":
            text = SPACE_RE.sub(" ", f" {text} ".replace(f" {nk} ", f" {v} ")).strip()
    text = text.replace("cera ve", "cerave")
    return SPACE_RE.sub(" ", text).strip()


def compact_text(value: object) -> str:
    return normalize_text(value).replace(" ", "")


def split_aliases(value: object) -> List[str]:
    raw = str(value or "")
    parts = re.split(r"[;,|\n]+", raw)
    out: List[str] = []
    for part in parts:
        item = normalize_text(part)
        if item and item not in out:
            out.append(item)
    return out


def tokens(value: object) -> List[str]:
    return [t for t in normalize_text(value).split() if t]


def token_set(value: object) -> Set[str]:
    return set(tokens(value))


def strong_tokens(value: object) -> Set[str]:
    return {t for t in tokens(value) if len(t) >= 3 and t not in WEAK_TOKENS}


def weak_tokens(value: object) -> Set[str]:
    return {t for t in tokens(value) if t in WEAK_TOKENS or len(t) < 3}


def normalize_strength(value: object) -> str:
    text = normalize_text(value)
    m = re.search(r"(\d+(?:\.\d+)?)\s*(mg|ml|g|%)\s*(?:/\s*(\d+(?:\.\d+)?)\s*(ml|g))?", text)
    if not m:
        return ""
    if m.group(3):
        return f"{m.group(1)}{m.group(2)}/{m.group(3)}{m.group(4)}"
    return f"{m.group(1)}{m.group(2)}"


def contains_phrase(haystack: object, needle: object) -> bool:
    h = normalize_text(haystack)
    n = normalize_text(needle)
    return bool(n and f" {n} " in f" {h} ")


def is_generic_query(value: object) -> bool:
    q = normalize_text(value)
    if not q:
        return False
    if q in WEAK_TOKENS:
        return True
    generic_phrases = {"ادويه", "ادوية", "عنايه", "عناية", "عنايه بالبشره", "عناية بالبشرة", "اطفال", "اجهزه", "اجهزة", "منتجات"}
    if q in generic_phrases:
        return True
    ts = set(q.split())
    return bool(ts) and ts <= WEAK_TOKENS
