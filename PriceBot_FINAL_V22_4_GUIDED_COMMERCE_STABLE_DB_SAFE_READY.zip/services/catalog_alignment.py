# -*- coding: utf-8 -*-
"""Catalog alignment helpers for PriceBot V22.1.

These functions enrich weak current-catalog rows conservatively. They are used by
search, navigator and the offline catalog-alignment tools. No therapeutic advice
or medicine substitution data is invented; medicine fields are inferred only from
clear name tokens such as dosage/form words.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from services.text_normalizer import normalize_text, compact_text, split_aliases, tokens

READY_COLUMNS = [
    "product_id", "name", "normalized_name", "brand", "company", "category", "product_family",
    "form", "product_type", "use_case", "skin_type", "body_area", "strength", "size", "pack",
    "aliases", "ocr_keywords", "price", "available", "quality_status", "search_mode", "review_notes",
]

BRAND_PATTERNS: List[Tuple[str, Sequence[str]]] = [
    ("CeraVe", ["cerave", "cera ve", "سيرافي", "سيرا في"]),
    ("Rilastil", ["rilastil", "ريلاستيل"]),
    ("Bioderma", ["bioderma", "بيوديرما", "بايودرما"]),
    ("La Roche-Posay", ["la roche", "laroche", "la roche posay", "لاروش"]),
    ("Eucerin", ["eucerin", "يوسرين"]),
    ("Photoblok", ["photoblok", "photoblock", "photo block", "فوتوبلوك"]),
    ("Flagyl", ["flagyl", "فلاجيل", "فلاجل"]),
    ("Amoclan", ["amoclan", "اموكلان"]),
    ("Augmentin", ["augmentin", "اوجمنتين"]),
    ("Gyno-Daktarin", ["gyno daktarin", "gyno-daktarin", "داكتارين"]),
]

MEDICINE_FORM_PATTERNS = {
    "tablet": ["tablet", "tablets", "tab", "tabs", "اقراص", "حبوب"],
    "capsule": ["capsule", "capsules", "cap", "caps", "كبسول", "كبسوله"],
    "syrup": ["syrup", "suspension", "شراب", "معلق"],
    "injection": ["injection", "ampoule", "amp", "حقن", "امبول"],
    "drops": ["drops", "drop", "قطره", "قطرات"],
    "cream": ["vag cream", "cream", "كريم"],
    "ointment": ["ointment", "مرهم"],
    "gel": ["gel", "جل"],
    "suppository": ["suppository", "suppositories", "تحاميل", "لبوس"],
    "pessary": ["pessary", "vaginal tablet", "vag tab", "فرزجه"],
    "spray": ["spray", "بخاخ"],
    "solution": ["solution", "محلول"],
    "sachet": ["sachet", "sachets", "كيس", "اكياس"],
}

COSMETIC_TYPE_PATTERNS = {
    "face_cleanser": ["face cleanser", "facial cleanser", "face wash", "foaming cleanser", "gel moussant", "cleanser", "غسول وجه", "غسول"],
    "body_wash": ["body wash", "shower gel", "غسول جسم", "شاور جل"],
    "baby_wash": ["baby wash", "kids wash", "اطفال", "طفل", "baby shampoo"],
    "shampoo": ["shampoo", "شامبو"],
    "conditioner": ["conditioner", "بلسم"],
    "sunscreen": ["sunscreen", "sunblock", "spf", "واقي شمس"],
    "serum": ["serum", "سيروم"],
    "lotion": ["lotion", "لوشن"],
    "cream": ["cream", "balm", "baume", "كريم"],
    "moisturizer": ["moisturizer", "moisturising", "moisturizing", "مرطب"],
    "oil": ["oil", "زيت"],
    "gel": ["gel", "جل"],
    "toner": ["toner", "تونر"],
    "mask": ["mask", "ماسك"],
    "scrub": ["scrub", "مقشر"],
}

OILY_WORDS = ["oily", "normal oily", "normal to oily", "oil control", "blemish", "acne", "sebum", "sebium", "purifying", "foaming", "effaclar", "cleanance", "sa smoothing", "دهنية", "حبوب"]
DRY_WORDS = ["dry", "very dry", "dry to very dry", "hydrating", "moisturizing", "moisturising", "xerolact", "atoderm", "lipikar", "emollient", "barrier", "جافة", "ترطيب"]
SENSITIVE_WORDS = ["sensitive", "حساسة", "حساس"]

USE_CASE_WORDS = {
    "acne_oil_control": ["acne", "blemish", "oil control", "sebum", "sebium", "effaclar", "cleanance", "purifying", "oily", "دهنية", "حبوب"],
    "hydration": ["hydrating", "moisturizing", "moisturising", "xerolact", "atoderm", "lipikar", "emollient", "barrier", "dry", "ترطيب", "جافة"],
    "sun_protection": ["sunscreen", "sunblock", "spf", "واقي"],
    "anti_dandruff": ["dandruff", "قشرة", "قشره"],
    "hair_loss": ["hair loss", "anti hair loss", "تساقط"],
}

STR_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(mg|g|mcg|iu|%)(?:\s*/\s*(\d+(?:\.\d+)?)\s*(ml|g))?", re.I)
SIZE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(ml|g|kg|l|tab|tabs|tablet|tablets|capsule|capsules|cap|caps|sachet|sachets)\b", re.I)


def _field(row: Dict[str, Any], *keys: str) -> str:
    for k in keys:
        v = row.get(k)
        if v not in (None, ""):
            return str(v).strip()
    return ""


def _contains(identity: str, phrase: str) -> bool:
    p = normalize_text(phrase)
    return bool(p and f" {p} " in f" {identity} ")


def infer_brand(row: Dict[str, Any]) -> str:
    existing = _field(row, "brand")
    if existing:
        return existing
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "company", "aliases", "ocr_keywords", "image_ocr_keywords", "original_name"]))
    for brand, aliases in BRAND_PATTERNS:
        if any(_contains(identity, alias) or alias.replace(" ", "") in identity.replace(" ", "") for alias in aliases):
            return brand
    # Safe fallback: first alphabetic token if not generic and name starts with a brand-like word.
    name = str(row.get("name") or "").strip()
    first = name.split()[0] if name.split() else ""
    if first and len(first) >= 3 and not first.startswith(("+", "-")) and normalize_text(first) not in {"cream", "gel", "wash", "cleanser", "lotion", "syrup", "tablet"}:
        return first.strip("+-.,")
    return ""


def infer_strength(row: Dict[str, Any]) -> str:
    existing = _field(row, "strength")
    if existing:
        return existing
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "aliases", "ocr_keywords", "image_ocr_keywords", "pack", "size"]))
    m = STR_RE.search(identity)
    if not m:
        return ""
    if m.group(3):
        return f"{m.group(1)}{m.group(2).lower()}/{m.group(3)}{m.group(4).lower()}"
    return f"{m.group(1)}{m.group(2).lower()}"


def infer_size(row: Dict[str, Any]) -> str:
    existing = _field(row, "size", "pack")
    if existing and not infer_strength({"strength": existing}):
        return existing
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "pack", "aliases", "ocr_keywords", "image_ocr_keywords"]))
    # Prefer ml/g package sizes and counts. Avoid mg as package size.
    matches = [m for m in SIZE_RE.finditer(identity) if m.group(2).lower() not in {"mg", "mcg", "iu", "%"}]
    if matches:
        m = matches[-1]
        unit = m.group(2).lower()
        unit = {"tabs": "tablets", "tab": "tablets", "cap": "capsules", "caps": "capsules"}.get(unit, unit)
        return f"{m.group(1)}{unit}" if unit in {"ml", "g", "kg", "l"} else f"{m.group(1)} {unit}"
    return ""


def infer_product_type(row: Dict[str, Any]) -> str:
    existing = normalize_text(_field(row, "product_type", "form"))
    if existing and existing not in {"product", "other", "unknown"}:
        return existing.replace(" ", "_")
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "brand", "company", "aliases", "ocr_keywords", "image_ocr_keywords", "category", "form", "original_name"]))
    # Body/baby/hair must be checked before generic cleanser/cream.
    for typ in ["body_wash", "baby_wash", "shampoo", "conditioner", "face_cleanser", "sunscreen", "serum", "lotion", "moisturizer", "cream", "oil", "gel", "toner", "mask", "scrub"]:
        if any(_contains(identity, w) for w in COSMETIC_TYPE_PATTERNS[typ]):
            return typ
    for typ, words in MEDICINE_FORM_PATTERNS.items():
        if any(_contains(identity, w) for w in words):
            return typ
    return ""


def infer_category(row: Dict[str, Any]) -> str:
    existing = normalize_text(_field(row, "category"))
    if existing and existing not in {"other", "unknown", "product"}:
        if existing in {"cosmetics", "beauty", "skin_care"}:
            return "cosmetic"
        return existing
    ptype = infer_product_type(row)
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "aliases", "ocr_keywords", "image_ocr_keywords", "brand", "company"]))
    if ptype in set(MEDICINE_FORM_PATTERNS) or infer_strength(row) or any(_contains(identity, w) for w in ["flagyl", "amoclan", "augmentin", "panadol", "janumet", "cipralex", "concor"]):
        return "medicine"
    if ptype in {"face_cleanser", "body_wash", "baby_wash", "shampoo", "conditioner", "sunscreen", "serum", "lotion", "moisturizer", "cream", "oil", "gel", "toner", "mask", "scrub"}:
        return "cosmetic"
    if any(_contains(identity, w) for w in ["baby", "diaper", "حفاض", "اطفال"]):
        return "baby"
    if any(_contains(identity, w) for w in ["thermometer", "glucometer", "pressure", "device", "جهاز", "قياس"]):
        return "device"
    return "unknown"


def infer_skin_type(row: Dict[str, Any]) -> str:
    existing = normalize_text(_field(row, "skin_type"))
    if existing:
        if "oily" in existing or "دهني" in existing:
            return "oily_skin"
        if "dry" in existing or "جاف" in existing:
            return "dry_skin"
        if "sensitive" in existing or "حساس" in existing:
            return "sensitive_skin"
        return existing.replace(" ", "_")
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "aliases", "ocr_keywords", "image_ocr_keywords", "product_family"]))
    if any(_contains(identity, w) for w in OILY_WORDS):
        return "oily_skin"
    if any(_contains(identity, w) for w in DRY_WORDS):
        return "dry_skin"
    if any(_contains(identity, w) for w in SENSITIVE_WORDS):
        return "sensitive_skin"
    return ""


def infer_use_case(row: Dict[str, Any]) -> str:
    existing = normalize_text(_field(row, "use_case"))
    if existing:
        return existing.replace(" ", "_")
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "aliases", "ocr_keywords", "image_ocr_keywords", "product_family"]))
    for case, words in USE_CASE_WORDS.items():
        if any(_contains(identity, w) for w in words):
            return case
    return "daily_cleansing" if infer_product_type(row) == "face_cleanser" else ""


def infer_body_area(row: Dict[str, Any]) -> str:
    existing = normalize_text(_field(row, "body_area"))
    if existing:
        return existing.replace(" ", "_")
    ptype = infer_product_type(row)
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "aliases", "ocr_keywords", "image_ocr_keywords", "category", "form"]))
    if ptype in {"shampoo", "conditioner"} or any(_contains(identity, w) for w in ["hair", "شعر", "shampoo"]):
        return "hair"
    if ptype == "baby_wash" or any(_contains(identity, w) for w in ["baby", "اطفال", "kids"]):
        return "baby"
    if ptype == "body_wash" or any(_contains(identity, w) for w in ["body wash", "body lotion", "جسم"]):
        return "body"
    if ptype in {"face_cleanser", "sunscreen", "serum", "moisturizer", "cream", "lotion", "toner", "mask", "scrub", "gel"}:
        return "face"
    return ""


def infer_product_family(row: Dict[str, Any], brand: str = "") -> str:
    existing = _field(row, "product_family")
    if existing:
        return existing
    name = str(row.get("name") or "").strip()
    if not name:
        return ""
    family = name.strip(" +")
    bnorm = normalize_text(brand)
    if bnorm:
        parts = family.split()
        if parts and normalize_text(parts[0]) == bnorm:
            family = " ".join(parts[1:]) or family
    # Remove obvious pack/strength from family.
    family = re.sub(r"\b\d+(?:\.\d+)?\s*(?:mg|g|mcg|iu|%|ml)\b", " ", family, flags=re.I)
    family = re.sub(r"\s+", " ", family).strip(" -+,")
    return family or name


def _photoblok_alias_variants(name: str) -> List[str]:
    n = normalize_text(name)
    out: List[str] = []
    if "photoblok" in n or "photoblock" in n or "فوتوبلوك" in n:
        nums = re.findall(r"\d+", n)
        num = nums[0] if nums else "50"
        out.extend([f"Photoblok {num}+", f"+Photoblok {num}", f"Photoblok {num}", f"photoblock {num}", f"فوتوبلوك {num}"])
    return out


def _cerave_alias_variants(row: Dict[str, Any], ptype: str, skin: str, use: str) -> List[str]:
    identity = normalize_text(" ".join(_field(row, k) for k in ["name", "product_family", "aliases", "ocr_keywords", "image_ocr_keywords"]))
    if "cerave" not in identity:
        return []
    family = str(row.get("product_family") or infer_product_family(row, "CeraVe") or "").strip()
    out = [f"CeraVe {family}".strip(), f"Cerave {family}".strip()]
    if ptype == "face_cleanser":
        out.extend(["Cerave cleanser", "CeraVe Cleanser", "سيرافي غسول"])
        if skin == "oily_skin" or use == "acne_oil_control":
            out.extend(["سيرافي غسول للبشرة الدهنية", "Cerave oily cleanser", "Cerave foaming cleanser"])
        if skin == "dry_skin" or use == "hydration":
            out.extend(["سيرافي غسول للبشرة الجافة", "Cerave hydrating cleanser"])
        if "sa" in identity:
            out.extend(["Cerave SA Smoothing Cleanser", "CeraVe SA Cleanser", "سيرافي غسول sa"])
    return out


def build_aliases(row: Dict[str, Any], aligned: Dict[str, Any] | None = None) -> List[str]:
    aligned = aligned or {}
    name = str(row.get("name") or "").strip()
    brand = str(aligned.get("brand") or infer_brand(row) or "").strip()
    family = str(aligned.get("product_family") or infer_product_family(row, brand) or "").strip()
    ptype = str(aligned.get("product_type") or infer_product_type(row) or "")
    skin = str(aligned.get("skin_type") or infer_skin_type(row) or "")
    use = str(aligned.get("use_case") or infer_use_case(row) or "")
    out: List[str] = []
    for item in [name, str(row.get("original_name") or ""), family, f"{brand} {family}".strip()]:
        if item:
            out.append(item)
    out.extend(split_aliases(row.get("aliases") or ""))
    out.extend(_photoblok_alias_variants(name))
    # Numeric/code-like products often appear as "1,2,3" or "Extra 1,2,3"
    # while customers type "123". Add compact numeric aliases only when the
    # original name itself contains the sequence, never as a broad fallback.
    digits = re.sub(r"\D+", "", name)
    if digits and len(digits) >= 2:
        out.append(digits)
        if family and family != name:
            out.append(f"{family} {digits}")
    out.extend(_cerave_alias_variants({**row, "product_family": family}, ptype, skin, use))
    if normalize_text(brand) == "gyno daktarin" or "daktarin" in normalize_text(name):
        out.extend(["gyno-daktarin vag cream", "gyno daktarin vaginal cream", "جينو داكتارين كريم مهبلي"])
    # Safe Arabic/English brand aliases.
    bnorm = normalize_text(brand)
    if bnorm == "rilastil" and family:
        out.append(f"ريلاستيل {family}")
    if bnorm == "bioderma" and family:
        out.append(f"بيوديرما {family}")
    seen = set()
    cleaned: List[str] = []
    banned = {"cream", "gel", "cleanser", "lotion", "serum", "غسول", "كريم", "لوشن", "سيروم"}
    for item in out:
        item_s = str(item or "").strip(" ;,|")
        n = normalize_text(item_s)
        if not n or n in seen or n in banned:
            continue
        seen.add(n)
        cleaned.append(item_s)
    return cleaned


def build_ocr_keywords(row: Dict[str, Any], aligned: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key in ["brand", "product_family", "product_type", "form", "skin_type", "use_case", "body_area", "size", "strength"]:
        val = str(aligned.get(key) or "").strip()
        if val:
            parts.append(val)
    for key in ["name", "aliases", "ocr_keywords", "image_ocr_keywords"]:
        val = str(row.get(key) or "").strip()
        if val:
            parts.append(val)
    brand = normalize_text(aligned.get("brand"))
    if brand == "cerave": parts.extend(["سيرافي", "cera ve"])
    if brand == "photoblok": parts.extend(["photoblock", "فوتوبلوك"])
    if brand == "bioderma": parts.extend(["بيوديرما", "بايودرما"])
    if brand == "rilastil": parts.extend(["ريلاستيل"])
    if aligned.get("product_type") == "face_cleanser": parts.extend(["face wash", "غسول وجه"])
    if aligned.get("skin_type") == "oily_skin": parts.extend(["oily", "normal to oily", "دهنية"])
    if aligned.get("skin_type") == "dry_skin": parts.extend(["dry", "very dry", "جافة", "hydrating"])
    # Preserve order while removing duplicate normalized tokens/phrases.
    seen = set(); out: List[str] = []
    for part in parts:
        n = normalize_text(part)
        if n and n not in seen:
            seen.add(n); out.append(str(part))
    return " ".join(out)


def align_product(row: Dict[str, Any]) -> Dict[str, Any]:
    base = dict(row)
    brand = infer_brand(base)
    category = infer_category({**base, "brand": brand})
    ptype = infer_product_type(base)
    form = ptype if ptype else _field(base, "form")
    skin = infer_skin_type(base)
    use = infer_use_case(base)
    area = infer_body_area(base)
    strength = infer_strength(base)
    size = infer_size(base)
    family = infer_product_family(base, brand)
    quality = str(base.get("quality_status") or "").strip()
    search_mode = str(base.get("search_mode") or "").strip()
    review: List[str] = []
    if not brand:
        review.append("brand_missing")
    if category in {"unknown", "other", ""}:
        review.append("category_unknown")
    if category == "cosmetic" and not ptype:
        review.append("cosmetic_type_missing")
    if category == "medicine" and not form:
        review.append("medicine_form_missing")
    # Rows with low inferred metadata stay exact-only for safety.
    if not quality:
        quality = "ready" if not review else "needs_review"
    if not search_mode:
        if review or category == "unknown":
            search_mode = "exact_only"
        else:
            search_mode = "standard"
    aligned = {
        "product_id": str(base.get("product_id") or base.get("id") or base.get("source_serial") or ""),
        "name": str(base.get("name") or ""),
        "normalized_name": normalize_text(base.get("normalized_name") or base.get("name") or ""),
        "brand": brand,
        "company": str(base.get("company") or ""),
        "category": category,
        "product_family": family,
        "form": form,
        "product_type": ptype,
        "use_case": use,
        "skin_type": skin,
        "body_area": area,
        "strength": strength,
        "size": size,
        "pack": str(base.get("pack") or ""),
        "price": str(base.get("price") or ""),
        "available": str(base.get("available") or "متوفر"),
        "quality_status": quality,
        "search_mode": search_mode,
        "review_notes": "; ".join(review),
    }
    aligned["aliases"] = "; ".join(build_aliases(base, aligned))
    aligned["ocr_keywords"] = build_ocr_keywords(base, aligned)
    return aligned


def align_products(products: Sequence[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    ready: List[Dict[str, Any]] = []
    review: List[Dict[str, Any]] = []
    counts: Dict[str, Any] = {"total": 0, "ready": 0, "needs_review": 0, "sections": {}, "review_reasons": {}}
    for product in products or []:
        row = align_product(dict(product))
        counts["total"] += 1
        cat = row.get("category") or "unknown"
        counts["sections"][cat] = counts["sections"].get(cat, 0) + 1
        if row.get("quality_status") == "ready" and row.get("search_mode") != "exact_only":
            ready.append(row); counts["ready"] += 1
        else:
            review.append(row); counts["needs_review"] += 1
            for reason in str(row.get("review_notes") or "needs_review").split(";"):
                reason = reason.strip() or "needs_review"
                counts["review_reasons"][reason] = counts["review_reasons"].get(reason, 0) + 1
    return ready, review, counts
