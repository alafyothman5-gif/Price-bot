# PriceBot V22.3 Guided Commerce

هذه النسخة تجعل الاستخدام الأساسي للبوت Guided First:

1. العميل يرسل `السلام عليكم` / `ابدأ` / `القائمة`.
2. تظهر قائمة الأقسام الديناميكية حسب المنتجات المتوفرة فقط.
3. يختار القسم ثم النوع ثم المنتج.
4. السعر لا يظهر إلا بعد ظهور منتج محدد داخل قائمة منتجات متوفرة أو نتيجة exact واضحة.
5. عند اختيار المنتج يكتب العميل `نعم`، ثم يطلب البوت الكمية، ثم ينشئ الطلب.

## الأقسام الرئيسية

- أدوية
- مكملات وفيتامينات
- عناية بالبشرة
- عناية بالشعر
- أطفال
- أجهزة ومستلزمات
- بحث باسم منتج
- إرسال صورة

الأقسام الفارغة لا تظهر، ما عدا البحث والصورة.

## قواعد السلامة

- لا يتم حذف جدول `products`.
- لا يتم تفريغ المنتجات.
- `guided_catalog_index` جدول مستقل، ويمكن إعادة بنائه بدون لمس المنتجات.
- لا توجد بدائل دوائية تلقائية.
- الكلمات العامة مثل `غسول` و`حديد` و`شامبو` تدخل القوائم، وليس البحث الحر.
- اختيار رقم من قائمة يختار العنصر من آخر قائمة، ولا يدخل product search.

## بناء Guided Catalog Index

من قاعدة البيانات الحالية:

```bash
python tools/build_guided_catalog_index.py --db --write-db --report guided_catalog_tree_report.xlsx
```

من Excel جاهز:

```bash
python tools/build_guided_catalog_index.py --input products_master_v22_ready.xlsx --report guided_catalog_tree_report.xlsx
```

## النشر

من داخل `/opt/pricebot`:

```bash
chmod +x deploy_pricebot_v22_3.sh smoke_test_pricebot.sh tools/*.py
./deploy_pricebot_v22_3.sh
```

## الاختبار

```bash
python acceptance_tests_final_v22_3_guided_commerce.py
python acceptance_tests_final_v22_2_stability_speed.py
```

## صفحات الأدمن الجديدة

- `/admin/guided-catalog`
- `/admin/guided-unclassified`

