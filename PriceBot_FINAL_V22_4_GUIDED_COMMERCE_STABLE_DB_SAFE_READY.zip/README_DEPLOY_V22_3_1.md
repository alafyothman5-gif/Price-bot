# Deploy PriceBot V22.3.1

Use this release only over the existing PriceBot server directory `/opt/pricebot`.

## Safety rules
- Does not include `.env`.
- Does not include `pricebot.db`.
- Does not replace or truncate `products`.
- Runs with product-count protection before and after migration/index/restart.
- Does not touch MedMCQ.

## Deploy command

```bash
cd /opt/pricebot && chmod +x deploy_pricebot_v22_3_1.sh backup_pricebot.sh rollback_pricebot.sh smoke_test_pricebot.sh tools/*.py && ./deploy_pricebot_v22_3_1.sh
```

## Local verification commands

```bash
python -m compileall -q .
python -m pytest -q
python acceptance_tests_final_v22_2_stability_speed.py
python acceptance_tests_final_v22_company_grade.py
python acceptance_tests_final_v22_3_guided_commerce.py
```
