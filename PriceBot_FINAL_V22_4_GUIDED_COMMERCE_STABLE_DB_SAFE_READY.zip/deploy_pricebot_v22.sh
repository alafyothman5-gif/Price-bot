#!/usr/bin/env bash
set -Eeuo pipefail
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"

APP_DIR="/opt/pricebot"
BACKUP_SCRIPT="./backup_pricebot.sh"
SERVICE_NAME="pricebot.service"

if [[ "$(pwd)" != "$APP_DIR" ]]; then
  echo "ERROR: run this script from $APP_DIR only. Refusing to touch other projects." >&2
  exit 1
fi
if [[ -d /opt/medmcq ]]; then
  echo "SAFE_CHECK: MedMCQ detected and will not be touched." >&2
fi
if [[ ! -f app.py || ! -f matcher_v4.py || ! -f services/search_engine.py ]]; then
  echo "ERROR: not a PriceBot V22 project directory." >&2
  exit 1
fi

mkdir -p /root/pricebot_backups
if [[ -x "$BACKUP_SCRIPT" ]]; then
  "$BACKUP_SCRIPT"
else
  tar --exclude='./venv' --exclude='./.venv' --exclude='./__pycache__' -czf "/root/pricebot_backups/pricebot_pre_v22_$(date +%Y%m%d_%H%M%S).tar.gz" .
fi

if [[ -f .env ]]; then
  echo "OK: preserving existing .env"
else
  echo "WARNING: .env not found. Copy .env.example to .env and fill secrets before production."
fi
if [[ -f pricebot.db ]]; then
  echo "OK: preserving existing pricebot.db"
else
  echo "INFO: pricebot.db not found; migrations will create an empty DB. Existing production DB is never deleted by this script."
fi

python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

python -m compileall -q .
python -m pytest -q
python acceptance_tests_v3.py
python acceptance_tests_v4.py
python acceptance_tests_final_v17.py
python acceptance_tests_final_v17_1.py
python acceptance_tests_final_v17_2.py
python acceptance_tests_final_v17_4.py
python acceptance_tests_final_v17_5.py
python acceptance_tests_final_v18.py
python acceptance_tests_final_v19.py
python acceptance_tests_final_v19_1.py
python acceptance_tests_final_v19_3_guided_finder.py
python acceptance_tests_final_v20.py
python acceptance_tests_final_v20_1_guided_routing.py
python acceptance_tests_final_v22_company_grade.py
python acceptance_tests_final_v22_1_catalog_aligned.py

python - <<'PY'
import database
from tools.rebuild_search_index import rebuild_search_index
from tools.rebuild_product_nav_index import rebuild_product_nav_index

database.init_db()
database.ensure_v19_tables()
database.ensure_v22_tables()
print('PRICEBOT_V22_SAFE_MIGRATION_OK')
print(rebuild_search_index())
print(rebuild_product_nav_index())
PY
python tools/build_v22_company_catalog.py --db pricebot.db --out-dir catalog_v22_alignment || echo 'CATALOG_ALIGNMENT_WARNING: skipped; check catalog source'
python tools/run_v22_catalog_acceptance.py --db pricebot.db || echo 'CATALOG_ACCEPTANCE_WARNING: review current catalog alignment report'

sudo systemctl daemon-reload || true
sudo systemctl restart "$SERVICE_NAME"
sudo systemctl status "$SERVICE_NAME" --no-pager -l || true
sleep 2
curl -fsS http://127.0.0.1:${PRICEBOT_PORT}/health || { echo "ERROR: health check failed" >&2; exit 1; }
echo
echo "PRICEBOT_V22_DEPLOY_OK"
