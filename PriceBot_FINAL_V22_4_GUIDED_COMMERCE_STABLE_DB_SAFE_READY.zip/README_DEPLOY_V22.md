# PriceBot V22 Company-Grade Deploy

نسخة V22 تضيف Search Engine + Product Navigator فوق محرك V20.1 بدون حذف المنتجات وبدون تغيير `.env` أو `pricebot.db`.

## مكان المشروع

ضع الملفات داخل:

```bash
/opt/pricebot
```

لا تلمس `/opt/medmcq` أو أي خدمة Telegram.

## قبل التشغيل

احتفظ بملفك الحالي:

- `.env`
- `pricebot.db`

الـ ZIP لا يحتوي عليهما. لا ترفع أسرار إلى GitHub.

## تشغيل النشر

من داخل `/opt/pricebot`:

```bash
chmod +x deploy_pricebot_v22.sh rollback_pricebot.sh backup_pricebot.sh smoke_test_pricebot.sh
./deploy_pricebot_v22.sh
```

السكريبت يعمل:

1. Backup قبل التحديث.
2. يحافظ على `.env` و `pricebot.db`.
3. يشغل الاختبارات.
4. يشغل migrations آمنة فقط.
5. يبني `product_search_index`.
6. يبني `product_nav_index`.
7. يعيد تشغيل `pricebot.service`.
8. يفحص `/health`.

## فحص سريع

```bash
./smoke_test_pricebot.sh
```

## بناء الفهارس يدويًا

```bash
python tools/rebuild_search_index.py
python tools/rebuild_product_nav_index.py
```

## المسارات الجديدة في الأدمن

- `/admin/search-index`
- `/admin/product-navigator`
- `/admin/unclassified-products`
- `/admin/failed-searches`
- `/admin/learning-center`

## قواعد الأمان

- لا سعر عند الغموض.
- لا بدائل دوائية تلقائية.
- AI Vision لا يقرر السعر أو التوفر.
- brand-only/type-only يدخل Guided Flow.
- الرقم من القائمة لا يبحث كمنتج.
- `.env` و `pricebot.db` لا يدخلان داخل ZIP.

## Merchant Portal

يبقى مغلقًا في production إلا إذا ضبطت:

```env
MERCHANT_PORTAL_ENABLED=true
MERCHANT_LOGIN_CODE=ضع_كود_خاص_غير_merchant
MERCHANT_SESSION_SECRET=قيمة_عشوائية_طويلة
```

## V22.1 Catalog Alignment

بعد نشر V22.1، شغّل مواءمة الكتالوج على قاعدة المنتجات الحالية بدون حذف أو استبدال:

```bash
cd /opt/pricebot
python tools/build_v22_company_catalog.py --db pricebot.db --out-dir catalog_v22_alignment
python tools/run_v22_catalog_acceptance.py --db pricebot.db
```

النواتج ستكون داخل:

```text
/opt/pricebot/catalog_v22_alignment/products_v22_company_catalog_ready.xlsx
/opt/pricebot/catalog_v22_alignment/products_v22_needs_review.xlsx
/opt/pricebot/catalog_v22_alignment/catalog_v22_alignment_report.xlsx
```

إذا كان السيرفر يعمل على بورت غير 8000:

```env
PRICEBOT_PORT=8090
```

سكربتات deploy/smoke تقرأ `PRICEBOT_PORT` تلقائيًا.
