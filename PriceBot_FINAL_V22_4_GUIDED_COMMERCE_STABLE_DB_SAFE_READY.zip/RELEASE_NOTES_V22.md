# PriceBot V22 Company-Grade Ready

## الهدف

V22 يحوّل PriceBot من بوت بحث فقط إلى منصة أكثر قابلية للبيع:

- Search Engine حقيقي للبحث باسم المنتج.
- Product Navigator Engine للتصفح المنظم.
- Safety Policy تمنع التخمين والسعر الخاطئ.
- Admin tools لتعليم البوت وتحسينه بدون تعديل كود.

## ما تمت إضافته

### Search Engine

ملف جديد:

- `services/search_engine.py`

طبقات البحث:

1. exact normalized name
2. exact alias
3. barcode/code
4. normalized phrase match
5. scoped token match
6. safe fuzzy داخل نطاق ضيق فقط

لا يوجد global fuzzy fallback.

### Search Index

جدول جديد:

- `product_search_index`

سكريبت:

```bash
python tools/rebuild_search_index.py
```

### Text Normalizer

ملف جديد:

- `services/text_normalizer.py`

يدعم Arabic/English normalization، أرقام عربية/إنجليزية، mg/ml/g، synonyms للبراندات الشائعة.

### Product Navigator

ملف جديد:

- `services/product_navigator.py`

جدول جديد:

- `product_nav_index`

سكريبت:

```bash
python tools/rebuild_product_nav_index.py
```

### Admin Tools

صفحات جديدة:

- `/admin/search-index`
- `/admin/product-navigator`
- `/admin/unclassified-products`
- `/admin/failed-searches`

### Guided/Navigator Behavior

- الكلمات العامة تدخل Guided Flow.
- أدوية تفتح قائمة أقسام أدوية.
- اختيار الرقم من قائمة لا يتحول إلى بحث منتج.
- دعم `المزيد` لعرض صفحة إضافية.

## ما لم يتغير

- لم يتم حذف أو استبدال المنتجات.
- لم يتم تغيير `.env`.
- لم يتم تضمين `pricebot.db`.
- لم يتم لمس MedMCQ.
- لم يتم السماح ببدائل دوائية تلقائية.
- لم يتم السماح بسعر عند الغموض.

## الاختبارات

أضيف:

```bash
python acceptance_tests_final_v22_company_grade.py
```

ويتم تشغيله مع كل اختبارات V17/V18/V19/V20 السابقة.

## حدود النسخة

V22 جاهزة كسوق تجريبي قوي. جودة النتائج النهائية تعتمد على جودة الكتالوج الحالي، لذلك يجب استخدام Learning Center وSearch/Navigator dashboards لتحسين aliases والتصنيفات تدريجيًا.
