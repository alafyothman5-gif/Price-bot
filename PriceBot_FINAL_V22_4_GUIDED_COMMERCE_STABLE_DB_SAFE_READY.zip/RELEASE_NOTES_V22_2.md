# RELEASE NOTES — PriceBot FINAL V22.2 STABLE FAST SAFE

## الهدف

إصلاح جذري لمسار الاستقرار والسرعة وحماية البيانات بعد مشاكل V20/V22.1، خصوصاً:

- timeout أو عدم رد البوت.
- تفريغ جدول المنتجات أثناء deploy.
- تعليق rebuild index.
- تعليق restart/stop.
- دخول الرسائل البسيطة مثل "السلام عليكم" إلى search engine.

## أهم التغييرات

### 1. Deploy آمن

أضيف `deploy_pricebot_v22_2.sh`:

- backup قبل أي خطوة.
- فحص `products_count` قبل وبعد migration/index/restart.
- إيقاف النشر إذا كان عدد المنتجات أقل من 1000.
- rollback تلقائي لقاعدة البيانات إذا تغير عدد المنتجات.
- timeouts واضحة: migration 30s، search index 60s، nav index 60s، health 20s.
- لا يستبدل `.env` ولا `pricebot.db`.

### 2. Rebuild index آمن وغير مدمّر

تمت إعادة كتابة:

- `tools/rebuild_search_index.py`
- `tools/rebuild_product_nav_index.py`

السلوك الجديد:

- بناء جدول مؤقت أولاً.
- swap ذري للفهرس بعد نجاح البناء.
- لا يوجد `DROP products`.
- لا يوجد `DELETE FROM products`.
- لا يوجد `REPLACE pricebot.db`.
- يفشل بأمان إذا تغير عدد المنتجات.

### 3. Fast route gate

تم تعديل ترتيب مسار النص:

1. active guided flow.
2. yes/no/order cancellation.
3. greeting/menu مباشرة.
4. short bare menu numbers مثل `1` و `2` بدون state ترجع القائمة.
5. exact fast path.
6. guided generic flow.
7. strict matcher.

بهذا:

- `السلام عليكم` يرجع القائمة بدون بحث منتجات.
- `القائمة` يرجع القائمة بدون بحث منتجات.
- `2` بعد القائمة يفتح الأقسام.
- `غسول` يذهب Guided Flow وليس global search.

### 4. Exact fast path عبر SQLite/index

أضيف `search_products_db` في `services/search_engine.py`:

- exact normalized name.
- exact alias.
- barcode/code/product identifiers.
- لا يحمل كل المنتجات للـ exact lookup.
- bounded timeout logic.

أمثلة الاختبار:

- `Photoblok 50+`
- `123`
- `Extra 1,2,3`
- `gyno-daktarin vag cream`

### 5. تعطيل runtime alignment الثقيل افتراضياً

تم تعطيل catalog alignment أثناء runtime/index rebuild افتراضياً لأن هذا كان سبب بطء شديد وتعليق الفهرسة على كتالوج كبير.

يمكن تفعيله فقط لغرض خاص عبر:

```bash
PRICEBOT_ENABLE_RUNTIME_ALIGNMENT=1
```

لكن لا يُنصح به على السيرفر أثناء التشغيل العادي. التجهيز يجب أن يكون offline.

### 6. Fallback آمن عند timeout

بدل الرد العام المتكرر:

> عذرًا، استغرق البحث وقتًا أطول...

تمت إضافة fallback آمن:

- التحية ترجع القائمة.
- الرقم القصير يرجع القائمة.
- المنتج الواضح يجرب exact DB lookup.
- غير ذلك يطلب كتابة الاسم الكامل أو اختيار القائمة.

### 7. Shutdown bounded

تم ضبط shutdown بحيث لا ينتظر background tasks للأبد. يوجد حد 5 ثوانٍ لتجميع المهام الملغاة.

### 8. Diagnostic tool

أضيف:

`tools/diagnose_pricebot.py`

يعرض:

- products count.
- search index count.
- nav index count.
- DB path.
- port status.
- health status.
- timing لـ `Photoblok 50+`.
- timing للقائمة.
- آخر 20 خطأ من DB/journal عند توفرها.

### 9. Acceptance tests

أضيف:

`acceptance_tests_final_v22_2_stability_speed.py`

يغطي:

- عدم تغير products أثناء migration.
- عدم تغير products أثناء rebuild_search_index.
- عدم تغير products أثناء rebuild_product_nav_index.
- `السلام عليكم` → main menu بدون product search.
- `2` بعد main menu → browse categories.
- `Photoblok 50+` exact fast.
- `123` exact fast.
- `غسول` → guided flow وليس global search.
- رقم بدون state لا يبحث كمنتج.
- timeout fallback آمن.
- warmup background.
- shutdown bounded.

## اختبارات تم تشغيلها أثناء التجهيز

- `python acceptance_tests_final_v22_2_stability_speed.py`
- `python acceptance_tests_final_v20_1_guided_routing.py`
- `python acceptance_tests_final_v22_1_catalog_aligned.py`
- `python acceptance_tests_final_v22_company_grade.py`
- `python -m compileall -q .`

## ملفات التسليم الأساسية

- `deploy_pricebot_v22_2.sh`
- `smoke_test_pricebot.sh`
- `backup_pricebot.sh`
- `rollback_pricebot.sh`
- `tools/diagnose_pricebot.py`
- `tools/rebuild_search_index.py`
- `tools/rebuild_product_nav_index.py`
- `acceptance_tests_final_v22_2_stability_speed.py`
- `README_DEPLOY_V22_2.md`
- `RELEASE_NOTES_V22_2.md`
