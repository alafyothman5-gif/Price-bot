#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/pricebot"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
MIN_PRODUCTS="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
BACKUP_ROOT="/root/pricebot_backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/pricebot_v22_3_predeploy_$STAMP"

log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') | $*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }
run_timeout(){ local seconds="$1"; shift; timeout --preserve-status "${seconds}s" "$@"; }

[[ "$(pwd)" == "$APP_DIR" ]] || fail "Run from $APP_DIR only. Refusing to touch other projects."
[[ -f app.py && -f database.py && -d services ]] || fail "This is not a PriceBot project directory."
if [[ -d /opt/medmcq || -d /opt/MedMCQ ]]; then
  log "SAFE_CHECK: MedMCQ detected and will not be touched."
fi

mkdir -p "$BACKUP_DIR"
log "Creating pre-deploy backup: $BACKUP_DIR"
tar --exclude='./venv' --exclude='./.venv' --exclude='./__pycache__' --exclude='./.git' --exclude='./backups' \
    --exclude='./pricebot.db' --exclude='./pricebot.db-*' --exclude='./.env' \
    -czf "$BACKUP_DIR/code.tar.gz" -C "$APP_DIR" .
[[ -f "$APP_DIR/pricebot.db" ]] && cp -a "$APP_DIR/pricebot.db" "$BACKUP_DIR/pricebot.db"
[[ -f "$APP_DIR/.env" ]] && cp -a "$APP_DIR/.env" "$BACKUP_DIR/.env"
[[ -d "$APP_DIR/media" ]] && tar -czf "$BACKUP_DIR/media.tar.gz" -C "$APP_DIR" media
[[ -d "$APP_DIR/uploads" ]] && tar -czf "$BACKUP_DIR/uploads.tar.gz" -C "$APP_DIR" uploads
[[ -f "/etc/systemd/system/$SERVICE_NAME" ]] && cp -a "/etc/systemd/system/$SERVICE_NAME" "$BACKUP_DIR/$SERVICE_NAME"
log "PRICEBOT_BACKUP_OK | path=$BACKUP_DIR"

product_count(){
  python3 - <<'PY'
import os, sqlite3, sys
path = os.environ.get('PRICEBOT_DB_FILE') or '/opt/pricebot/pricebot.db'
try:
    con = sqlite3.connect(path)
    cur = con.execute("SELECT COUNT(*) FROM products")
    print(int(cur.fetchone()[0] or 0))
except Exception as exc:
    print(f"COUNT_ERROR:{exc}")
    sys.exit(2)
PY
}

[[ -f "$APP_DIR/pricebot.db" ]] || fail "pricebot.db not found. This deploy is for the existing production database; it will not create/replace product data."
PRODUCTS_BEFORE="$(product_count)" || fail "Could not count products before deploy."
[[ "$PRODUCTS_BEFORE" =~ ^[0-9]+$ ]] || fail "Invalid products count before deploy: $PRODUCTS_BEFORE"
if (( PRODUCTS_BEFORE < MIN_PRODUCTS )); then
  fail "DB_PROTECTION_FAILED | stage=before_deploy | products_count=$PRODUCTS_BEFORE | min=$MIN_PRODUCTS"
fi
log "DB_PROTECTION_OK | stage=before_deploy | products_count=$PRODUCTS_BEFORE"

log "Installing dependencies safely."
python3 -m venv venv
# shellcheck disable=SC1091
source venv/bin/activate
run_timeout 60 python -m pip install --upgrade pip
run_timeout 120 pip install -r requirements.txt

log "Compile check."
run_timeout 45 python -m compileall -q .

log "Running V22.2/V22.3 stability and guided-commerce acceptance tests on isolated temp DB."
PRICEBOT_SKIP_MIGRATION_BACKUP=1 run_timeout 45 python acceptance_tests_final_v22_2_stability_speed.py
PRICEBOT_SKIP_MIGRATION_BACKUP=1 run_timeout 45 python acceptance_tests_final_v22_3_guided_commerce.py

log "Running additive migrations with 30s timeout."
PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" run_timeout 30 python - <<'PY'
import database
before = database.count_products()
database.init_db()
database.ensure_v19_tables()
database.ensure_v22_tables()
after = database.count_products()
if before != after:
    raise SystemExit(f"DB_PROTECTION_FAILED | stage=migration | before={before} | after={after}")
print(f"DB_PROTECTION_OK | stage=migration | products_count={after}")
PY

PRODUCTS_AFTER_MIGRATION="$(product_count)" || fail "Could not count products after migration."
if [[ "$PRODUCTS_AFTER_MIGRATION" != "$PRODUCTS_BEFORE" ]]; then
  log "DB_PROTECTION_FAILED | stage=after_migration | before=$PRODUCTS_BEFORE | after=$PRODUCTS_AFTER_MIGRATION"
  cp -a "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
  fail "Database count changed. Restored backup DB and stopped deploy."
fi
log "DB_PROTECTION_OK | stage=after_migration | products_count=$PRODUCTS_AFTER_MIGRATION"

log "Rebuilding search indexes with timeout; failure will not stop the bot."
if PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" run_timeout 60 python tools/rebuild_search_index.py; then
  log "SEARCH_INDEX_REBUILD_OK"
else
  log "SEARCH_INDEX_REBUILD_WARNING | using_existing_index_or_runtime_db_fallback"
fi
PRODUCTS_AFTER_SEARCH_INDEX="$(product_count)" || fail "Could not count products after search index."
if [[ "$PRODUCTS_AFTER_SEARCH_INDEX" != "$PRODUCTS_BEFORE" ]]; then
  cp -a "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
  fail "DB_PROTECTION_FAILED | stage=after_search_index | before=$PRODUCTS_BEFORE | after=$PRODUCTS_AFTER_SEARCH_INDEX | restored_db=1"
fi

if PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" run_timeout 60 python tools/rebuild_product_nav_index.py; then
  log "NAV_INDEX_REBUILD_OK"
else
  log "NAV_INDEX_REBUILD_WARNING | using_existing_nav_index_or_guided_runtime_fallback"
fi
PRODUCTS_AFTER_NAV_INDEX="$(product_count)" || fail "Could not count products after nav index."
if [[ "$PRODUCTS_AFTER_NAV_INDEX" != "$PRODUCTS_BEFORE" ]]; then
  cp -a "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
  fail "DB_PROTECTION_FAILED | stage=after_nav_index | before=$PRODUCTS_BEFORE | after=$PRODUCTS_AFTER_NAV_INDEX | restored_db=1"
fi

if PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" run_timeout 60 python tools/build_guided_catalog_index.py --db --write-db --report guided_catalog_tree_report.xlsx; then
  log "GUIDED_CATALOG_REBUILD_OK"
else
  log "GUIDED_CATALOG_REBUILD_WARNING | bot_will_use_runtime_guided_fallback"
fi
PRODUCTS_AFTER_GUIDED_INDEX="$(product_count)" || fail "Could not count products after guided index."
if [[ "$PRODUCTS_AFTER_GUIDED_INDEX" != "$PRODUCTS_BEFORE" ]]; then
  cp -a "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
  fail "DB_PROTECTION_FAILED | stage=after_guided_index | before=$PRODUCTS_BEFORE | after=$PRODUCTS_AFTER_GUIDED_INDEX | restored_db=1"
fi
log "DB_PROTECTION_OK | stage=after_indexes | products_count=$PRODUCTS_AFTER_GUIDED_INDEX"

log "Restarting service without hanging."
sudo systemctl daemon-reload || true
if ! run_timeout 15 sudo systemctl stop "$SERVICE_NAME"; then
  log "SERVICE_STOP_TIMEOUT | action=kill_then_continue"
  sudo systemctl kill -s TERM "$SERVICE_NAME" || true
  sleep 2
fi
run_timeout 15 sudo systemctl start "$SERVICE_NAME" || {
  log "SERVICE_START_FAILED | attempting_db_restore"
  cp -a "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
  sudo systemctl start "$SERVICE_NAME" || true
  fail "Service failed to start. DB backup restored. Check journalctl -u $SERVICE_NAME -n 100 --no-pager"
}

log "Waiting for health check."
HEALTH_OK=0
for _ in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${PRICEBOT_PORT}/health" >/tmp/pricebot_v22_3_health.json 2>/dev/null; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done
if [[ "$HEALTH_OK" != "1" ]]; then
  sudo systemctl status "$SERVICE_NAME" --no-pager -l || true
  fail "Health check failed after 20s. DB was not modified; backup path: $BACKUP_DIR"
fi
cat /tmp/pricebot_v22_3_health.json && echo

PRODUCTS_AFTER_RESTART="$(product_count)" || fail "Could not count products after restart."
if [[ "$PRODUCTS_AFTER_RESTART" != "$PRODUCTS_BEFORE" ]]; then
  cp -a "$BACKUP_DIR/pricebot.db" "$APP_DIR/pricebot.db"
  sudo systemctl restart "$SERVICE_NAME" || true
  fail "DB_PROTECTION_FAILED | stage=after_restart | before=$PRODUCTS_BEFORE | after=$PRODUCTS_AFTER_RESTART | restored_db=1"
fi
log "DB_PROTECTION_OK | stage=after_restart | products_count=$PRODUCTS_AFTER_RESTART"
log "PRICEBOT_V22_3_GUIDED_COMMERCE_DEPLOY_OK | backup=$BACKUP_DIR"
