from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, BackgroundTasks, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

import database
from services.catalog.staging_workflow import approve_staging_job
from tasks.catalog_tasks import catalog_stage_import
from services.security import csrf
try:
    import product_identity
    import search_engine
except Exception:
    product_identity = None
    search_engine = None

router = APIRouter()
templates = Jinja2Templates(directory="templates")
SESSION_COOKIE = "pricebot_admin_session"
SESSION_TTL_SECONDS = int(os.getenv("PRICEBOT_ADMIN_SESSION_TTL_SECONDS", "21600") or 21600)
ADMIN_USERNAME = os.getenv("PRICEBOT_ADMIN_USERNAME") or os.getenv("ADMIN_USERNAME") or "owner"
ADMIN_PASSWORD = os.getenv("PRICEBOT_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD") or ""
_RATE: Dict[str, list] = {}


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return forwarded or (request.client.host if request.client else "unknown")


def _rate_ok(request: Request, limit: int = 30, window: int = 60) -> bool:
    ip = _client_ip(request)
    now = time.time()
    bucket = _RATE.setdefault(ip, [])
    bucket[:] = [x for x in bucket if now - x < window]
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def _hash_password(password: str, salt: Optional[bytes] = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 260_000)
    return base64.b64encode(salt).decode("ascii"), base64.b64encode(digest).decode("ascii")


def _verify_password(password: str, salt_b64: str, digest_b64: str) -> bool:
    try:
        salt = base64.b64decode(salt_b64.encode("ascii"))
        _, candidate = _hash_password(password, salt=salt)
        return hmac.compare_digest(candidate, digest_b64)
    except Exception:
        return False


def _ensure_auth_schema() -> None:
    with database.connect() as conn:
        database.add_column(conn, "admin_users", "password_salt", "TEXT DEFAULT ''")
        database.add_column(conn, "admin_users", "password_hash", "TEXT DEFAULT ''")
        database.add_column(conn, "admin_users", "display_name", "TEXT DEFAULT ''")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_admin_sessions_hash ON admin_sessions(session_hash)")


def _bootstrap_owner_if_needed() -> None:
    _ensure_auth_schema()
    with database.connect() as conn:
        row = conn.execute("SELECT COUNT(*) AS c FROM admin_users WHERE active=1 AND password_hash <> ''").fetchone()
        if int(row[0] if row else 0) > 0:
            return
        if not ADMIN_PASSWORD or len(ADMIN_PASSWORD) < 10:
            return
        salt, digest = _hash_password(ADMIN_PASSWORD)
        conn.execute(
            """
            INSERT INTO admin_users(username, role, active, password_salt, password_hash, display_name)
            VALUES(?, 'owner', 1, ?, ?, ?)
            ON CONFLICT(username) DO UPDATE SET
                role='owner', active=1, password_salt=excluded.password_salt,
                password_hash=excluded.password_hash, display_name=excluded.display_name,
                updated_at=CURRENT_TIMESTAMP
            """,
            (ADMIN_USERNAME, salt, digest, ADMIN_USERNAME),
        )


def validate_admin_config(strict: bool = True) -> None:
    _bootstrap_owner_if_needed()
    if not strict:
        return
    with database.connect() as conn:
        row = conn.execute("SELECT COUNT(*) AS c FROM admin_users WHERE active=1 AND password_hash <> ''").fetchone()
        if int(row[0] if row else 0) <= 0:
            raise RuntimeError("ADMIN_UI_AUTH_REFUSED: set PRICEBOT_ADMIN_USERNAME and PRICEBOT_ADMIN_PASSWORD, then restart PriceBot")


def _get_user(username: str) -> Optional[Dict[str, Any]]:
    _ensure_auth_schema()
    with database.connect() as conn:
        row = conn.execute("SELECT * FROM admin_users WHERE username=? AND active=1", (username.strip(),)).fetchone()
        return database.dict_row(row) if row else None


def _session_hash(token: str) -> str:
    return hashlib.sha256((token or "").encode("utf-8")).hexdigest()


def _create_session(username: str, role: str, ip: str) -> str:
    token = secrets.token_urlsafe(36)
    sh = _session_hash(token)
    with database.connect() as conn:
        conn.execute(
            """
            INSERT INTO admin_sessions(session_hash, username, role, ip, expires_at)
            VALUES(?,?,?,?,datetime('now', ? || ' seconds'))
            """,
            (sh, username, role, ip, str(SESSION_TTL_SECONDS)),
        )
    return token


def _current_user(request: Request) -> Optional[Dict[str, Any]]:
    token = request.cookies.get(SESSION_COOKIE, "")
    if not token:
        return None
    sh = _session_hash(token)
    try:
        with database.connect() as conn:
            row = conn.execute(
                """
                SELECT s.username, s.role, u.display_name
                FROM admin_sessions s
                LEFT JOIN admin_users u ON u.username=s.username
                WHERE s.session_hash=? AND datetime(s.expires_at) > datetime('now')
                LIMIT 1
                """,
                (sh,),
            ).fetchone()
            return database.dict_row(row) if row else None
    except Exception:
        return None


def _require_auth(request: Request):
    if not _rate_ok(request):
        return PlainTextResponse("rate limited", status_code=429)
    if not _current_user(request):
        return RedirectResponse("/admin/login", status_code=303)
    return None


def _actor(request: Request) -> str:
    user = _current_user(request) or {}
    return str(user.get("username") or "admin")


def _admin_nav(active: str = "dashboard") -> list[Dict[str, Any]]:
    items = [
        ("dashboard", "/admin", "📊", "الرئيسية"),
        ("catalog", "/admin/catalog", "📦", "الكتالوج"),
        ("learning", "/admin/learning", "🧠", "صندوق التعليم"),
        ("users", "/admin/users", "👥", "المستخدمون"),
        ("audit", "/admin/audit", "🧾", "التدقيق"),
        ("merchant", "/merchant", "🏪", "لوحة التاجر"),
        ("portal", "/portal", "🌐", "البوابة"),
    ]
    return [{"active": key == active, "href": href, "icon": icon, "label": label} for key, href, icon, label in items]


def _pending_orders_count(status: str = "pending") -> int:
    try:
        return len(database.list_orders(status, 5000, merchant_id=database.default_merchant_id()))
    except Exception:
        return 0


def _csrf_token(request: Request) -> str:
    return csrf.issue_token(request.cookies.get(SESSION_COOKIE, ""))


def _require_csrf(request: Request, token: str = ""):
    if not csrf.verify_token(token, request.cookies.get(SESSION_COOKIE, "")):
        database.audit_admin("csrf_rejected", actor=_actor(request), ip=_client_ip(request), details={"path": str(request.url.path)})
        return PlainTextResponse("CSRF validation failed", status_code=403)
    return None


def _render(request: Request, template: str, context: Dict[str, Any]):
    context = dict(context)
    context.setdefault("csrf_token", _csrf_token(request))
    context.setdefault("current_user", _current_user(request) or {})
    return templates.TemplateResponse(template, context)


@router.get("/admin/login", response_class=HTMLResponse)
def admin_login_form(request: Request, error: str = ""):
    warning = ""
    try:
        validate_admin_config(strict=False)
        with database.connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS c FROM admin_users WHERE active=1 AND password_hash <> ''").fetchone()
            if int(row[0] if row else 0) <= 0:
                warning = "اضبط PRICEBOT_ADMIN_USERNAME و PRICEBOT_ADMIN_PASSWORD ثم أعد التشغيل."
    except Exception as exc:
        warning = str(exc)
    return _render(request,
        "login.html",
        {
            "request": request,
            "title": "Admin Login",
            "heading": "دخول الإدارة",
            "subtitle": "تسجيل دخول احترافي باسم مستخدم وكلمة مرور.",
            "error": error,
            "warning": warning,
        },
    )


@router.post("/admin/login")
def admin_login(request: Request, username: str = Form(...), password: str = Form(...)):
    if not _rate_ok(request, limit=10, window=60):
        return PlainTextResponse("rate limited", status_code=429)
    validate_admin_config(strict=False)
    user = _get_user(username)
    if not user or not _verify_password(password, user.get("password_salt") or "", user.get("password_hash") or ""):
        database.audit_admin("admin_login_failed", actor=username, ip=_client_ip(request))
        return RedirectResponse("/admin/login?error=بيانات الدخول غير صحيحة", status_code=303)
    token = _create_session(user["username"], user.get("role") or "owner", _client_ip(request))
    database.audit_admin("admin_login_ok", actor=user["username"], ip=_client_ip(request))
    resp = RedirectResponse("/admin", status_code=303)
    resp.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=SESSION_TTL_SECONDS,
        httponly=True,
        secure=True,
        samesite="lax",
    )
    return resp


@router.post("/admin/logout")
def admin_logout(request: Request, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        try:
            with database.connect() as conn:
                conn.execute("DELETE FROM admin_sessions WHERE session_hash=?", (_session_hash(token),))
        except Exception:
            pass
    resp = RedirectResponse("/admin/login", status_code=303)
    resp.delete_cookie(SESSION_COOKIE)
    return resp


@router.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    products = database.count_products()
    identity_count = database.count_table("product_identity_registry")
    learning_pending = len(database.list_learning_inbox("pending", 5000))
    jobs = database.list_catalog_import_jobs(10)
    return _render(request,
        "admin_dashboard.html",
        {
            "request": request,
            "title": "Admin Dashboard",
            "nav": _admin_nav("dashboard"),
            "products": products,
            "identity_count": identity_count,
            "learning_pending": learning_pending,
            "pending_orders": _pending_orders_count("pending"),
            "jobs": jobs,
        },
    )


@router.get("/admin/learning", response_class=HTMLResponse)
def learning_inbox(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    items = database.list_learning_inbox("pending", 100)
    return _render(request,
        "admin_learning.html",
        {"request": request, "title": "Learning Inbox", "nav": _admin_nav("learning"), "items": items},
    )


@router.post("/admin/learning/{learning_id}/approve")
def approve_learning(request: Request, learning_id: int, product_db_id: int = Form(...), field: str = Form("aliases"), csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    try:
        database.approve_learning_alias(int(learning_id), int(product_db_id), field=field)
        if product_identity:
            product_identity.rebuild_product_identity_registry()
        if search_engine:
            search_engine.rebuild_search_index()
            search_engine.invalidate_memory_index()
        database.audit_admin("learning_approved", actor=_actor(request), ip=_client_ip(request), details={"learning_id": learning_id, "product_db_id": product_db_id, "field": field})
    except Exception as exc:
        return PlainTextResponse(f"failed: {type(exc).__name__}: {exc}", status_code=400)
    return RedirectResponse("/admin/learning", status_code=303)


@router.post("/admin/learning/{learning_id}/not-in-catalog")
def learning_not_in_catalog(request: Request, learning_id: int, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    database.update_learning_status(learning_id, "not_in_catalog", "not_in_catalog")
    database.audit_admin("learning_not_in_catalog", actor=_actor(request), ip=_client_ip(request), details={"learning_id": learning_id})
    return RedirectResponse("/admin/learning", status_code=303)


@router.post("/admin/learning/{learning_id}/ignore")
def learning_ignore(request: Request, learning_id: int, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    database.update_learning_status(learning_id, "ignored", "ignore")
    database.audit_admin("learning_ignored", actor=_actor(request), ip=_client_ip(request), details={"learning_id": learning_id})
    return RedirectResponse("/admin/learning", status_code=303)


@router.get("/admin/catalog", response_class=HTMLResponse)
def catalog_form(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    jobs = database.list_catalog_import_jobs(30)
    return _render(request,
        "admin_catalog.html",
        {"request": request, "title": "Catalog Import", "nav": _admin_nav("catalog"), "jobs": jobs},
    )


@router.post("/admin/catalog/upload")
async def catalog_upload(request: Request, background_tasks: BackgroundTasks, file: UploadFile = File(...), csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    suffix = Path(file.filename or "upload.xlsx").suffix or ".xlsx"
    tmpdir = Path(tempfile.mkdtemp(prefix="pricebot_catalog_"))
    excel_path = tmpdir / ("upload" + suffix)
    content = await file.read()
    excel_path.write_bytes(content)
    merchant_id = database.default_merchant_id()
    job_id = database.create_catalog_import_job(file.filename or "upload.xlsx", str(excel_path), status="queued")
    database.update_catalog_import_job(job_id, job_type="staging_import", merchant_id=merchant_id, requires_approval=1, report_text="Queued for staging import. Production DB is untouched until Approve.")
    try:
        # Real Celery/Redis path when workers are running.
        if os.getenv("PRICEBOT_USE_CELERY", "").lower() in {"1", "true", "yes", "on"}:
            catalog_stage_import.delay(int(job_id), str(excel_path), int(merchant_id))
        else:
            background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(merchant_id))
    except Exception:
        background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(merchant_id))
    database.audit_admin("catalog_staging_queued", actor=_actor(request), ip=_client_ip(request), details={"job_id": job_id, "filename": file.filename, "production_untouched": True})
    return RedirectResponse(f"/admin/catalog?queued={job_id}", status_code=303)


@router.get("/admin/catalog/{job_id}/status")
def catalog_job_status(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    job = database.get_catalog_import_job(job_id)
    if not job:
        return PlainTextResponse("job not found", status_code=404)
    return {
        "id": job.get("id"),
        "filename": job.get("filename"),
        "status": job.get("status"),
        "added": job.get("added"),
        "updated": job.get("updated"),
        "duplicate_conflicts": job.get("duplicate_conflicts"),
        "report_text": job.get("report_text"),
        "created_at": job.get("created_at"),
        "updated_at": job.get("updated_at"),
    }


@router.post("/admin/catalog/{job_id}/approve")
def catalog_approve(request: Request, job_id: int, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    try:
        approve_staging_job(int(job_id), actor=_actor(request))
    except Exception as exc:
        return PlainTextResponse(f"approve failed: {type(exc).__name__}: {exc}", status_code=400)
    return RedirectResponse("/admin/catalog", status_code=303)


@router.post("/admin/catalog/{job_id}/cancel")
def catalog_cancel(request: Request, job_id: int, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    database.update_catalog_import_job(job_id, status="cancelled")
    database.audit_admin("catalog_cancelled", actor=_actor(request), ip=_client_ip(request), details={"job_id": job_id})
    return RedirectResponse("/admin/catalog", status_code=303)


@router.get("/admin/users", response_class=HTMLResponse)
def admin_users(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    with database.connect() as conn:
        rows = conn.execute("SELECT id, username, role, active, merchant_id, display_name, created_at FROM admin_users ORDER BY id").fetchall()
        users = [database.dict_row(r) for r in rows]
        roles = [database.dict_row(r) for r in conn.execute("SELECT * FROM admin_roles ORDER BY role").fetchall()]
    return _render(request, "admin_users.html", {"request": request, "title": "Users & RBAC", "nav": _admin_nav("users"), "users": users, "roles": roles})


@router.post("/admin/users/create")
def admin_user_create(request: Request, username: str = Form(...), password: str = Form(...), role: str = Form("viewer"), merchant_id: int = Form(1), display_name: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    salt, digest = _hash_password(password)
    with database.connect() as conn:
        conn.execute("""
            INSERT INTO admin_users(username, role, active, merchant_id, password_salt, password_hash, display_name)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(username) DO UPDATE SET role=excluded.role, active=1, merchant_id=excluded.merchant_id,
                password_salt=excluded.password_salt, password_hash=excluded.password_hash, display_name=excluded.display_name,
                updated_at=CURRENT_TIMESTAMP
        """, (username.strip(), role, 1, int(merchant_id), salt, digest, display_name.strip() or username.strip()))
    database.audit_admin("admin_user_upsert", actor=_actor(request), ip=_client_ip(request), details={"username": username, "role": role, "merchant_id": merchant_id})
    return RedirectResponse("/admin/users", status_code=303)


@router.post("/admin/users/{user_id}/disable")
def admin_user_disable(request: Request, user_id: int, csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    with database.connect() as conn:
        conn.execute("UPDATE admin_users SET active=0, updated_at=CURRENT_TIMESTAMP WHERE id=?", (int(user_id),))
    database.audit_admin("admin_user_disabled", actor=_actor(request), ip=_client_ip(request), details={"user_id": user_id})
    return RedirectResponse("/admin/users", status_code=303)


@router.get("/admin/audit", response_class=HTMLResponse)
def admin_audit(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    with database.connect() as conn:
        rows = conn.execute("SELECT * FROM admin_audit_log ORDER BY id DESC LIMIT 300").fetchall()
        logs = [database.dict_row(r) for r in rows]
    return _render(request, "admin_audit.html", {"request": request, "title": "Audit Log", "nav": _admin_nav("audit"), "logs": logs})


@router.post("/admin/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    auth = _require_auth(request)
    if auth:
        return auth
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status)
    database.audit_admin("order_status_update", actor=_actor(request), ip=_client_ip(request), details={"order_id": order_id, "status": status})
    return RedirectResponse("/admin", status_code=303)
