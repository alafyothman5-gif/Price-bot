from __future__ import annotations

"""Build a fresh PriceBot catalog database from ordinary pharmacy Excel files.

Accepts:
- original Libyan price lists with Arabic headers such as الصنف / سعر علبة / سعر شريط
- generic sheets containing any name-like column and any price-like column
- already organized products_master_ready.xlsx files

The importer keeps every row with a usable name.  It generates a deterministic
product_id, extracts category/form/strength/size/pack from the name, builds
aliases/OCR keywords, imports into a fresh SQLite DB, then rebuilds all indexes.
"""

import json
import os
import re
import sqlite3
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import database
from normalizer import normalize_text, safe_price
from normalizer import compact_normalize, split_multi
from query_slots import canonical_form, normalize_measure
from services.matching.excel_native_matcher import invalidate_memory_index as invalidate_excel_native_index
from services.catalog.pricelist_converter import (
    MASTER_COLUMNS,
    convert_raw_products,
    detect_raw_headers,
    read_raw_xls,
    row_from_raw,
)

NAME_HINTS = {
    "name", "product", "item", "description", "desc", "product name", "item name",
    "الصنف", "اسم الصنف", "اسم المنتج", "المنتج", "الوصف", "بيان", "item description",
}
PRICE_HINTS = {
    "price", "sale price", "selling price", "retail price", "box price", "سعر", "السعر", "سعر علبة", "سعر العلبة", "سعر البيع", "بيع",
}
STRIP_PRICE_HINTS = {"سعر شريط", "سعر الشريط", "strip price", "unit price"}
SERIAL_HINTS = {"ت", "serial", "no", "number", "#", "id"}


def _clean_header(value: object) -> str:
    return str(value or "").strip().replace("ـ", "")


def _norm_header(value: object) -> str:
    return normalize_text(_clean_header(value))


def _to_float(value: object) -> float:
    if value is None:
        return 0.0
    text = str(value).strip().replace(",", ".")
    if not text:
        return 0.0
    # Ignore numbers embedded in product names.
    try:
        return float(text)
    except Exception:
        m = re.search(r"\d+(?:\.\d+)?", text)
        if m and len(text) <= 12:
            try:
                return float(m.group(0))
            except Exception:
                return 0.0
    return 0.0


def _price_value(value: object) -> str:
    f = _to_float(value)
    if f <= 0:
        return ""
    if f.is_integer():
        return str(int(f))
    return f"{f:.2f}".rstrip("0").rstrip(".")


def _is_texty(value: object) -> bool:
    text = str(value or "").strip()
    if len(text) < 2:
        return False
    # Product names may contain digits, but not be purely numeric prices/barcodes.
    if re.fullmatch(r"[\d\s.,/-]+", text):
        return False
    return True


def _read_xlsx_matrix(path: Path) -> List[List[object]]:
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    matrix: List[List[object]] = []
    for row in ws.iter_rows(values_only=True):
        matrix.append(list(row))
    wb.close()
    return matrix


def _read_xls_matrix(path: Path) -> List[List[object]]:
    try:
        import xlrd  # type: ignore
    except Exception as exc:
        raise RuntimeError("XLS_SUPPORT_REQUIRES_xlrd==2.0.1. Install requirements.txt or upload .xlsx.") from exc
    book = xlrd.open_workbook(str(path))
    sh = book.sheet_by_index(0)
    return [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)]


def read_matrix(path: str) -> List[List[object]]:
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        return _read_xlsx_matrix(p)
    if suffix == ".xls":
        return _read_xls_matrix(p)
    if suffix == ".csv":
        import csv
        with open(p, newline="", encoding="utf-8-sig") as fh:
            return [row for row in csv.reader(fh)]
    raise RuntimeError(f"UNSUPPORTED_EXCEL_TYPE: {suffix}")


def _header_score(headers: Sequence[object]) -> int:
    score = 0
    raw = [_clean_header(h) for h in headers]
    norm = [_norm_header(h) for h in headers]
    if any(h in NAME_HINTS or n in {normalize_text(x) for x in NAME_HINTS} or "الصنف" in h for h, n in zip(raw, norm)):
        score += 5
    if any(h in PRICE_HINTS or n in {normalize_text(x) for x in PRICE_HINTS} or "سعر" in h or "price" in n for h, n in zip(raw, norm)):
        score += 5
    if sum(bool(str(h or "").strip()) for h in headers) >= 2:
        score += 1
    return score


def find_header_row(matrix: List[List[object]], max_scan: int = 25) -> Tuple[int, List[str]]:
    best_idx = 0
    best_score = -1
    for i, row in enumerate(matrix[:max_scan]):
        score = _header_score(row)
        if score > best_score:
            best_idx, best_score = i, score
    headers = [_clean_header(h) or f"Column{j+1}" for j, h in enumerate(matrix[best_idx])]
    return best_idx, headers


def _column_profiles(matrix: List[List[object]], start: int, ncols: int, sample: int = 200) -> List[Dict[str, float]]:
    profiles: List[Dict[str, float]] = []
    rows = matrix[start:start + sample]
    for c in range(ncols):
        non_empty = texty = numeric = price_like = 0
        for row in rows:
            value = row[c] if c < len(row) else None
            if str(value or "").strip():
                non_empty += 1
            if _is_texty(value):
                texty += 1
            f = _to_float(value)
            if f > 0:
                numeric += 1
                if 0 < f < 100000:
                    price_like += 1
        profiles.append({"non_empty": non_empty, "texty": texty, "numeric": numeric, "price_like": price_like})
    return profiles


def detect_columns(matrix: List[List[object]], header_idx: int, headers: List[str]) -> Dict[str, int]:
    ncols = max(len(headers), max((len(r) for r in matrix[:50]), default=0))
    raw_norm = [_norm_header(h) for h in headers]
    mapping: Dict[str, int] = {}
    # Explicit header names first.
    for i, (raw, n) in enumerate(zip(headers, raw_norm)):
        raw_clean = _clean_header(raw)
        if raw_clean in NAME_HINTS or n in {normalize_text(x) for x in NAME_HINTS} or "الصنف" in raw_clean or "product" in n or "item" in n:
            mapping.setdefault("name", i)
        if raw_clean in SERIAL_HINTS or n in {normalize_text(x) for x in SERIAL_HINTS}:
            mapping.setdefault("serial", i)
        if raw_clean in STRIP_PRICE_HINTS or n in {normalize_text(x) for x in STRIP_PRICE_HINTS}:
            mapping.setdefault("strip_price", i)
        elif raw_clean in PRICE_HINTS or n in {normalize_text(x) for x in PRICE_HINTS} or "سعر" in raw_clean or "price" in n:
            mapping.setdefault("box_price", i)
    if "name" in mapping and ("box_price" in mapping or "strip_price" in mapping):
        return mapping
    # Fallback by data profile for ordinary sheets with unclear headers.
    profiles = _column_profiles(matrix, header_idx + 1, ncols)
    if "name" not in mapping:
        text_cols = sorted(range(ncols), key=lambda c: (-profiles[c]["texty"], c))
        if text_cols and profiles[text_cols[0]]["texty"] > 0:
            mapping["name"] = text_cols[0]
    if "box_price" not in mapping and "strip_price" not in mapping:
        price_cols = [c for c in range(ncols) if c != mapping.get("name")]
        price_cols.sort(key=lambda c: (-profiles[c]["price_like"], c))
        if price_cols and profiles[price_cols[0]]["price_like"] > 0:
            mapping["box_price"] = price_cols[0]
    return mapping


def convert_any_excel_to_master_rows(path: str) -> Tuple[List[Dict[str, str]], Dict[str, object]]:
    p = Path(path)
    # Keep the existing strict raw XLS path when available because it preserves Arabic price-list semantics.
    if p.suffix.lower() == ".xls":
        try:
            rows, meta = read_raw_xls(str(p))
            meta["reader"] = "raw_xls"
            return rows, meta
        except Exception:
            # Fall through to generic matrix reader for clearer error if xlrd exists but headers differ.
            pass
    matrix = read_matrix(str(p))
    if not matrix:
        raise RuntimeError("EXCEL_EMPTY")
    # Try exact raw header detection first.
    for i, row in enumerate(matrix[:25]):
        raw_map = detect_raw_headers(row)
        if "name" in raw_map and ("box_price" in raw_map or "strip_price" in raw_map):
            raw_products = []
            for r0, vals in enumerate(matrix[i + 1:], start=i + 2):
                def get(k: str):
                    idx = raw_map.get(k)
                    return vals[idx] if idx is not None and idx < len(vals) else None
                name = get("name")
                if str(name or "").strip():
                    raw_products.append((str(name).strip(), get("serial"), get("box_price"), get("strip_price"), r0))
            rows = convert_raw_products(raw_products)
            return rows, {"reader": "raw_matrix", "header_row": i + 1, "rows_accepted": len(rows), "mapping": raw_map}
    header_idx, headers = find_header_row(matrix)
    mapping = detect_columns(matrix, header_idx, headers)
    if "name" not in mapping or not ("box_price" in mapping or "strip_price" in mapping):
        raise RuntimeError(f"CANNOT_DETECT_NAME_PRICE_COLUMNS headers={headers[:20]} mapping={mapping}")
    raw_products = []
    for r0, vals in enumerate(matrix[header_idx + 1:], start=header_idx + 2):
        def get(k: str):
            idx = mapping.get(k)
            return vals[idx] if idx is not None and idx < len(vals) else None
        name = get("name")
        if not str(name or "").strip():
            continue
        box = get("box_price")
        strip = get("strip_price")
        if not _price_value(box) and not _price_value(strip):
            # Keep no-price rows out of sellable DB.  They can be reviewed from source Excel.
            continue
        serial = get("serial") or len(raw_products) + 1
        raw_products.append((str(name).strip(), serial, box, strip, r0))
    rows = convert_raw_products(raw_products)
    return rows, {"reader": "generic_excel", "header_row": header_idx + 1, "rows_accepted": len(rows), "mapping": mapping, "headers": headers}



def _clean_index_key(value: object) -> str:
    key = normalize_text(value)
    if not key or len(key) <= 1:
        return ""
    return key


def _brand_from_product(p: Dict[str, str]) -> str:
    brand = normalize_text(p.get("brand"))
    if brand and brand not in {"unknown", "unclassified", "غير مصنف", "غير معروف"}:
        return brand
    toks = normalize_text(p.get("name")).split()
    return toks[0] if toks else ""


def _identity_key_for_row(p: Dict[str, str]) -> str:
    parts = [
        _brand_from_product(p),
        normalize_text(p.get("product_family") or p.get("normalized_name") or p.get("name")),
        normalize_text(p.get("category") or p.get("main_section") or p.get("section")),
        canonical_form(p.get("form") or p.get("medicine_form") or p.get("product_type") or p.get("name")) or "",
        normalize_measure(p.get("strength")),
        normalize_measure(p.get("size")),
        normalize_measure(p.get("pack")),
    ]
    return "|".join(parts)


def fast_rebuild_search_index() -> int:
    rows = database.load_product_rows(visible_only=True, guided=False)
    entries = []
    seen = set()
    def add(key: object, kind: str, pid: int, weight: int) -> None:
        k = _clean_index_key(key)
        if not k:
            return
        rec = (k, kind, pid)
        if rec in seen:
            return
        seen.add(rec)
        entries.append((k, kind, pid, weight))
        kc = compact_normalize(k)
        if kc and kc != k and len(kc) >= 4:
            rec2 = (kc, kind + "_compact", pid)
            if rec2 not in seen:
                seen.add(rec2)
                entries.append((kc, kind + "_compact", pid, max(1, weight - 5)))
    for p in rows:
        pid = int(p.get("id") or 0)
        if not pid:
            continue
        add(p.get("name"), "name", pid, 100)
        add(p.get("normalized_name"), "normalized_name", pid, 95)
        add(p.get("brand"), "brand", pid, 40)
        add(p.get("product_family"), "family", pid, 80)
        add(p.get("barcode"), "barcode", pid, 120)
        for field, kind, weight in [(p.get("aliases"), "alias", 90), (p.get("ocr_keywords"), "ocr", 85)]:
            for part in split_multi(field):
                add(part, kind, pid, weight)
    return database.replace_search_index(entries)


def fast_rebuild_identity_registry() -> int:
    rows = database.load_product_rows(visible_only=True, guided=False)
    # detect duplicate price conflicts by identity key
    groups: Dict[str, List[Dict[str, object]]] = {}
    for p in rows:
        groups.setdefault(_identity_key_for_row(p), []).append(p)
    duplicate_keys = set()
    for key, group in groups.items():
        prices = {safe_price(g.get("price")) for g in group if safe_price(g.get("price"))}
        if len(group) > 1 and len(prices) > 1:
            duplicate_keys.add(key)
    entries = []
    for p in rows:
        pid = int(p.get("id") or 0)
        if not pid:
            continue
        name = str(p.get("name") or p.get("original_name") or "").strip()
        norm = normalize_text(p.get("normalized_name") or name)
        key = _identity_key_for_row(p)
        entries.append((
            pid,
            str(p.get("product_id") or ""),
            key,
            name,
            norm,
            compact_normalize(norm),
            _brand_from_product(p),
            normalize_text(p.get("product_family") or name),
            canonical_form(p.get("form") or p.get("medicine_form") or p.get("product_type") or name) or "",
            normalize_measure(p.get("strength")),
            normalize_measure(p.get("size")),
            normalize_measure(p.get("pack")),
            str(p.get("barcode") or "").strip(),
            str(p.get("aliases") or ""),
            str(p.get("ocr_keywords") or ""),
            normalize_text(p.get("category") or p.get("main_section") or p.get("section")),
            "sellable_exact",
            "duplicate_price_conflict" if key in duplicate_keys else "",
        ))
    return database.replace_product_identity_registry(entries)


def fast_rebuild_guided_index() -> int:
    rows = database.load_product_rows(visible_only=True, guided=True)
    entries = []
    for p in rows:
        pid = int(p.get("id") or 0)
        if not pid:
            continue
        main = str(p.get("main_section") or p.get("section") or p.get("category") or "").strip()
        sub = str(p.get("sub_section") or p.get("subcategory") or p.get("product_type") or "").strip()
        if not main or normalize_text(main) in {"unknown", "unclassified", "غير مصنف", "غير معروف"}:
            continue
        if not sub or normalize_text(sub) in {"unknown", "unclassified", "غير مصنف", "غير معروف"}:
            continue
        entries.append((
            pid,
            main,
            sub,
            str(p.get("product_type") or p.get("form") or ""),
            str(p.get("use_case") or ""),
            str(p.get("skin_type") or ""),
            str(p.get("body_area") or ""),
            str(p.get("age_group") or ""),
            1,
            str(p.get("name") or ""),
        ))
    return database.replace_guided_index(entries)


def _insert_product(conn: sqlite3.Connection, row: Dict[str, str]) -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c in row]
    # Ensure every expected product column gets a value.
    cols = list(database.PRODUCT_COLUMNS)
    placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
    insert_cols = cols + ["created_at", "updated_at"]
    sql = f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})'
    cur = conn.execute(sql, [row.get(c, "") for c in cols])
    return int(cur.lastrowid)


def _fresh_identity_key(row: Dict[str, str]) -> str:
    parts = [
        normalize_text(row.get("brand") or row.get("company") or ""),
        normalize_text(row.get("product_family") or row.get("normalized_name") or row.get("name") or row.get("original_name") or ""),
        normalize_text(row.get("category") or row.get("main_section") or row.get("section") or ""),
        canonical_form(row.get("form") or row.get("product_type") or row.get("medicine_form") or row.get("name") or "") or "",
        normalize_measure(row.get("strength") or ""),
        normalize_measure(row.get("size") or ""),
        normalize_measure(row.get("pack") or ""),
    ]
    key = "|".join(parts)
    return key or normalize_text(row.get("name") or row.get("original_name") or "")


def _fresh_merge_values(*values: object) -> str:
    out, seen = [], set()
    for value in values:
        for part in split_multi(value):
            text = str(part or "").strip()
            norm = normalize_text(text)
            if text and norm and norm not in seen:
                seen.add(norm); out.append(text)
    return " | ".join(out)


def _strict_fresh_dedupe_rows(rows: List[Dict[str, str]]) -> Tuple[List[Dict[str, str]], Dict[str, int]]:
    grouped: Dict[str, Dict[str, str]] = {}
    stats = Counter()
    for row in rows:
        r = dict(row)
        r["identity_key"] = r.get("identity_key") or _fresh_identity_key(r)
        barcode = normalize_text(r.get("barcode") or "")
        if len(barcode.replace(" ", "")) < 4 or barcode in {"0", "00", "000"}:
            barcode = ""
        key = barcode or r["identity_key"] or normalize_text(r.get("normalized_name") or r.get("name") or "")
        if key not in grouped:
            grouped[key] = r
            continue
        old = grouped[key]
        stats["duplicate_rows_merged"] += 1
        old["price"] = safe_price(r.get("price")) or safe_price(old.get("price"))
        old["available"] = "true" if str(old.get("available") or "").lower() == "true" or str(r.get("available") or "").lower() == "true" else "false"
        old["aliases"] = _fresh_merge_values(old.get("aliases"), r.get("aliases"), r.get("name"))
        old["ocr_keywords"] = _fresh_merge_values(old.get("ocr_keywords"), r.get("ocr_keywords"), r.get("name"))
        for col in database.PRODUCT_COLUMNS:
            if col in {"price", "available", "aliases", "ocr_keywords"}:
                continue
            if not str(old.get(col) or "").strip() and str(r.get(col) or "").strip():
                old[col] = r.get(col, "")
    return list(grouped.values()), dict(stats)


def _fresh_insert_rows(rows: List[Dict[str, str]]) -> Dict[str, int]:
    database.init_db(run_production_guard=False)
    stats = Counter()
    with database.connect() as conn:
        # This function is intended for a newly created DB path.  Clearing is
        # safe here and avoids residue if a temp DB was reused.
        for table in ["product_search_index", "guided_catalog_index", "product_identity_registry", "products"]:
            if database.table_exists(conn, table):
                conn.execute(f'DELETE FROM "{table}"')
        for row in rows:
            _insert_product(conn, row)
            stats["inserted"] += 1
    return dict(stats)


def build_fresh_database_from_excel(excel_path: str, db_path: str) -> Dict[str, object]:
    db = Path(db_path)
    db.parent.mkdir(parents=True, exist_ok=True)
    if db.exists():
        db.unlink()
    database.configure_db_path(str(db))
    rows, meta = convert_any_excel_to_master_rows(excel_path)
    from services.catalog.ai_enrichment_agent import enrich_rows
    rows, enrichment_stats = enrich_rows(rows)
    rows, dedupe_stats = _strict_fresh_dedupe_rows(rows)
    meta = {**meta, "enrichment": enrichment_stats, "strict_dedupe": dedupe_stats}
    if len(rows) < 1:
        raise RuntimeError("NO_PRODUCTS_ACCEPTED")
    insert_stats = _fresh_insert_rows(rows)
    search_index = fast_rebuild_search_index()
    guided_index = fast_rebuild_guided_index()
    identity_registry = fast_rebuild_identity_registry()
    invalidate_excel_native_index()
    report = {
        "excel_path": str(excel_path),
        "db_path": str(db_path),
        "reader": meta.get("reader"),
        "header_row": meta.get("header_row"),
        "products_inserted": insert_stats.get("inserted", 0),
        "duplicate_rows_merged": dedupe_stats.get("duplicate_rows_merged", 0),
        "products_count": database.count_products(),
        "product_search_index": search_index,
        "guided_catalog_index": guided_index,
        "product_identity_registry": identity_registry,
        "meta": meta,
    }
    return report


def save_report(report: Dict[str, object], path: str) -> None:
    Path(path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
