from __future__ import annotations

"""Catalog staging workflow.

Excel uploads never write to production directly. The workflow is:
1) copy production DB into a staging DB;
2) run Smart Upsert + verification inside staging only;
3) mark job ready_for_approval or requires_review;
4) promote staging to production only when admin presses Approve.

SQLite production uses file-copy promotion. PostgreSQL production must define a
separate PRICEBOT_STAGING_DATABASE_URL; promotion is intentionally explicit and
transactional in deploy tooling because it affects live production data.
"""

import json
import os
import shutil
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional

import database
from services.catalog.smart_upsert import run_smart_upsert


def _staging_root() -> Path:
    root = Path(os.getenv("PRICEBOT_STAGING_DIR", "/opt/pricebot/staging"))
    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception:
        root = Path(tempfile.gettempdir()) / "pricebot_staging"
        root.mkdir(parents=True, exist_ok=True)
    return root


@contextmanager
def _temporary_sqlite_db(path: Path):
    old_file = database.DB_FILE
    old_source = database.DB_PATH_SOURCE
    old_backups = database.BACKUPS_DIR
    try:
        database.configure_db_path(str(path))
        yield
    finally:
        database.DB_FILE = old_file
        database.DB_PATH_SOURCE = old_source
        database.BACKUPS_DIR = old_backups


def _run_staging_acceptance() -> Dict[str, Any]:
    result: Dict[str, Any] = {"passed": True, "checks": {}}
    try:
        result["checks"]["products_count"] = database.count_products()
        result["checks"]["identity_count"] = database.count_table("product_identity_registry")
        result["checks"]["search_index_count"] = database.count_table("product_search_index")
        result["checks"]["guided_index_count"] = database.count_table("guided_catalog_index")
        result["checks"]["integrity"] = database.integrity_check()
        if result["checks"]["products_count"] <= 0:
            result["passed"] = False
            result["error"] = "NO_PRODUCTS_AFTER_STAGING_IMPORT"
        if str(result["checks"].get("integrity", "")).lower() != "ok":
            result["passed"] = False
            result["error"] = "STAGING_DB_INTEGRITY_FAILED"
    except Exception as exc:
        result["passed"] = False
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def create_and_verify_staging_job(job_id: int, excel_path: str, merchant_id: int = 1) -> Dict[str, Any]:
    """Build a staging DB and never change production rows."""
    started = time.time()
    database.update_catalog_import_job(job_id, status="staging_processing", job_type="staging_import", merchant_id=int(merchant_id), report_text="Staging import started")
    production_db = database.get_db_path()
    staging_path = _staging_root() / f"catalog_job_{int(job_id)}.staging.db"
    try:
        if database.IS_POSTGRES:
            # PostgreSQL live deployments must use a real separate staging DSN.
            # The migration/promotion commands are provided in tools/postgres_staging_promote.py.
            staging_dsn = os.getenv("PRICEBOT_STAGING_DATABASE_URL", "").strip()
            if not staging_dsn:
                raise RuntimeError("POSTGRES_STAGING_REQUIRES_PRICEBOT_STAGING_DATABASE_URL")
            raise RuntimeError("POSTGRES_STAGING_WORKFLOW_USE_tools/postgres_staging_promote.py")

        if production_db.exists():
            shutil.copy2(production_db, staging_path)
        else:
            staging_path.parent.mkdir(parents=True, exist_ok=True)
            if staging_path.exists():
                staging_path.unlink()

        with _temporary_sqlite_db(staging_path):
            database.init_db(run_production_guard=False)
            report = run_smart_upsert(excel_path, job_id=job_id, dry_run=False, run_reindex=True)
            verify = _run_staging_acceptance()
            review_items = database.list_catalog_review_items(job_id=job_id, status="pending", limit=10000)
            blocking_review = [r for r in review_items if str(r.get("severity") or "") == "blocking"]

        final_report = {
            "mode": "staging_import",
            "staging_db_path": str(staging_path),
            "production_untouched": True,
            "smart_upsert_report": report,
            "verify": verify,
            "review_items": len(review_items),
            "blocking_review_items": len(blocking_review),
            "duration_seconds": round(time.time() - started, 3),
        }
        status = "ready_for_approval" if verify.get("passed") and not blocking_review else "requires_review"
        database.update_catalog_import_job(
            job_id,
            status=status,
            staging_db_path=str(staging_path),
            added=int((report.get("stats") or {}).get("added", 0)),
            updated=int((report.get("stats") or {}).get("updated", 0)),
            duplicate_conflicts=int(report.get("price_conflicts", 0) or 0),
            verified=1 if verify.get("passed") else 0,
            acceptance_passed=1 if status == "ready_for_approval" else 0,
            report_text=json.dumps(final_report, ensure_ascii=False, indent=2, default=str)[-8000:],
        )
        database.audit_admin("catalog_staging_completed", details={"job_id": job_id, "status": status, "production_untouched": True})
        return final_report
    except Exception as exc:
        database.update_catalog_import_job(job_id, status="failed", error_text=f"{type(exc).__name__}: {exc}", report_text=f"STAGING_FAILED: {type(exc).__name__}: {exc}")
        database.audit_admin("catalog_staging_failed", details={"job_id": job_id, "error": repr(exc)})
        raise


def approve_staging_job(job_id: int, actor: str = "admin") -> Dict[str, Any]:
    """Promote a verified staging DB into production after explicit approval."""
    job = database.get_catalog_import_job(job_id)
    if not job:
        raise RuntimeError("CATALOG_JOB_NOT_FOUND")
    if job.get("status") != "ready_for_approval":
        raise RuntimeError(f"CATALOG_JOB_NOT_READY status={job.get('status')}")
    staging_path = Path(str(job.get("staging_db_path") or ""))
    if not staging_path.exists():
        raise RuntimeError("STAGING_DB_MISSING")
    if database.IS_POSTGRES:
        raise RuntimeError("POSTGRES_APPROVAL_USES_tools/postgres_staging_promote.py")

    backup = None
    if database.get_db_path().exists():
        backup = str(database.backup_db("before_staging_approve"))
    shutil.copy2(staging_path, database.get_db_path())
    # The staging DB already contains rebuilt indexes.  Invalidate in-process caches.
    try:
        import search_engine
        search_engine.invalidate_memory_index()
    except Exception:
        pass
    database.update_catalog_import_job(job_id, status="approved", approval_user=actor, approved_at="datetime('now')", report_text=(job.get("report_text") or "") + f"\nAPPROVED_BY={actor} BACKUP={backup}")
    database.audit_admin("catalog_staging_approved", actor=actor, details={"job_id": job_id, "backup": backup, "staging": str(staging_path)})
    return {"ok": True, "job_id": job_id, "backup": backup, "staging": str(staging_path)}
