from __future__ import annotations

"""Deterministic ProductVariantResolver for PriceBot.

Runs before exact/registry sellable matches. Generic family/brand names such as
Panadol, Flagyl, Gaviscon, and MEBO must ask for clarification when variants
exist. Weak one-word tokens never become catalog-wide searches.
"""

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

from normalizer import normalize_text, safe_price, tokens
from query_slots import QuerySlots, compatible_form, measure_matches, normalize_measure

WEAK_SINGLE_TOKENS = {"pro","scar","d","tab","cap","caps","syr","supp","sol","inj","gel","cream","plus","extra","advance","advanced","female","male"}

@dataclass
class VariantDecision:
    action: str = "CONTINUE"
    message: str = ""
    products: List[Dict] = field(default_factory=list)
    reason: str = ""


def _dedupe(products: Iterable[Dict], limit: int = 20) -> List[Dict]:
    out, seen = [], set()
    for p in products:
        key = (
            normalize_text(p.get("name")),
            normalize_text(p.get("form") or p.get("medicine_form") or p.get("product_type")),
            normalize_text(p.get("strength")),
            normalize_text(p.get("size")),
            normalize_text(p.get("pack")),
            safe_price(p.get("price")),
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def _scope_brand_family(slots: QuerySlots, catalog: Sequence[Dict], infer_brand: Callable[[Dict], str], display_text: Callable[[Dict], str], product_visible: Callable[[Dict], bool]) -> List[Dict]:
    key = slots.brand or (slots.strong_tokens[0] if slots.strong_tokens else "")
    if not key:
        return []
    out = []
    for p in catalog:
        if not product_visible(p):
            continue
        name = normalize_text(p.get("name"))
        family = normalize_text(p.get("product_family") or p.get("normalized_name"))
        brand = infer_brand(p)
        if brand == key or family == key or name == key or name.startswith(key + " "):
            out.append(p)
    return out


def _filter_form_measure(products: Sequence[Dict], slots: QuerySlots, display_text: Callable[[Dict], str], product_form: Callable[[Dict], str]) -> List[Dict]:
    """Narrow variants using explicit form/strength/size/pack only.

    The filter is deliberately sequential: strength narrows before pack, because
    many pharmacy rows lack pack/size values.  A missing pack must not prevent an
    otherwise exact strength match such as Pro-D3 50,000 IU from resolving.
    """
    scoped = list(products)

    requested_form = slots.form or slots.cosmetic_type
    if requested_form:
        tmp = []
        for p in scoped:
            pf = product_form(p)
            form_text = normalize_text(p.get("form") or p.get("product_type") or p.get("medicine_form") or "")
            name_text = normalize_text(p.get("name") or "")
            category_text = normalize_text(p.get("category") or p.get("main_section") or p.get("section") or "")
            soft_missing_forms = {"capsule", "tablet", "sachet"}
            # Requested form is a hard safety filter. Missing form is not a
            # match for syrup/suspension/suppository/etc.; otherwise queries
            # such as "فلاجيل شراب" can leak Flagyl tablets or supps. A narrow
            # exception is kept for supplement rows where capsule/tablet/sachet
            # is often absent from old pharmacy Excel files.
            if compatible_form(requested_form, pf, name_text) or compatible_form(requested_form, form_text, name_text):
                tmp.append(p)
            elif requested_form in soft_missing_forms and not pf and category_text == "supplement":
                tmp.append(p)
        if tmp:
            scoped = tmp
        else:
            return []

    def _filter_values(current: List[Dict], requested_values: Sequence[str], field: str) -> List[Dict]:
        if not requested_values:
            return current
        tmp = []
        for p in current:
            field_val = str(p.get(field) or "")
            display = display_text(p)
            if any(measure_matches(m, field_val) or normalize_measure(m) in normalize_measure(display) for m in requested_values):
                tmp.append(p)
        return tmp or current

    scoped = _filter_values(scoped, slots.strengths, "strength")
    scoped = _filter_values(scoped, slots.sizes, "size")
    scoped = _filter_values(scoped, slots.packs, "pack")
    return _dedupe(scoped, limit=20)


def _distinct_identity_count(products: Sequence[Dict], identity_key: Callable[[Dict], Tuple]) -> int:
    keys = set()
    for p in products:
        key = identity_key(p)
        # Keep price in the distinct count so duplicate price conflicts do not collapse to exact.
        keys.add((key, safe_price(p.get("price"))))
    return len(keys)


def maybe_resolve_generic_variant(slots: QuerySlots, catalog: Sequence[Dict], *, infer_brand: Callable[[Dict], str], identity_text: Callable[[Dict], str], display_text: Callable[[Dict], str], identity_key: Callable[[Dict], Tuple], product_form: Callable[[Dict], str], product_visible: Callable[[Dict], bool]) -> VariantDecision:
    single = len(slots.strong_tokens) == 1 and len(slots.tokens) <= 2 and not (slots.form or slots.strengths or slots.sizes or slots.packs)
    if single and slots.strong_tokens[0] in WEAK_SINGLE_TOKENS:
        return VariantDecision("LOW_CONFIDENCE", "اكتب اسم المنتج كاملًا. الكلمة وحدها غير كافية لتحديد المنتج بأمان.", reason="weak_single_token_guard")

    scoped = _scope_brand_family(slots, catalog, infer_brand, display_text, product_visible)
    if not scoped:
        return VariantDecision("CONTINUE")

    # Brand + requested family not present under the brand => missing, not fuzzy fallback.
    if slots.brand and slots.product_family and not single:
        measure_blob = normalize_measure(" ".join(slots.strengths + slots.sizes + slots.packs))
        family_tokens = [
            t for t in tokens(slots.product_family)
            if t not in {"mg","ml","g","iu"}
            and not t.isdigit()
            and len(t) > 2
            and normalize_measure(t) not in measure_blob
        ]
        if family_tokens:
            matching_family = [p for p in scoped if all(t in identity_text(p) for t in family_tokens)]
            if not matching_family and not slots.cosmetic_type:
                return VariantDecision("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.", reason="specific_brand_family_missing")
            if matching_family:
                scoped = matching_family

    narrowed = _filter_form_measure(scoped, slots, display_text, product_form)
    if single and not (slots.form or slots.strengths or slots.sizes or slots.packs):
        if len(_dedupe(scoped, limit=20)) > 1:
            return VariantDecision("ASK_CLARIFICATION", "هذا الاسم له أكثر من منتج. اختر المنتج المطلوب قبل عرض السعر:", _dedupe(scoped, limit=10), "generic_brand_or_family_multiple_variants")
        return VariantDecision("CONTINUE")

    # If an explicit requested form/type was present and no candidate survived,
    # stop here. The caller must not continue into exact/token fallback and show
    # wrong-form products.
    if not narrowed and (slots.form or slots.cosmetic_type):
        return VariantDecision("NOT_AVAILABLE", "لم أجد نفس الشكل المطلوب في قائمة الصيدلية حاليًا.", reason="requested_form_not_found")

    if narrowed and _distinct_identity_count(narrowed, identity_key) == 1 and len(narrowed) == 1:
        return VariantDecision("CANDIDATES", products=narrowed, reason="fully_resolved_variant")
    if narrowed and len(narrowed) > 1:
        return VariantDecision("ASK_CLARIFICATION", "وجدت أكثر من نسخة محتملة. اختر المنتج المطلوب قبل عرض السعر:", narrowed[:10], "partial_variant_multiple_candidates")
    return VariantDecision("CONTINUE")
