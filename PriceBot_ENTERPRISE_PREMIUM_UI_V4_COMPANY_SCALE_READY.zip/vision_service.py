import base64
import json
import os
from typing import Dict

import httpx

import config_env
from normalizer import normalize_text
from query_slots import build_vision_query

GENERIC_IMAGE_WORDS = {
    "cream", "gel", "tube", "capsule", "capsules", "tablet", "tablets", "vitamin", "female", "face", "skin",
    "lotion", "syrup", "drops", "spray", "shampoo", "conditioner", "mg", "ml", "iu", "كريم", "جل", "حبوب",
    "فيتامين", "كبسولات", "شراب", "قطره", "بخاخ", "شامبو",
}


def _log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-flash-lite").strip() or "google/gemini-2.5-flash-lite",
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def build_query_from_slots(slots: Dict[str, str]) -> str:
    # Vision matching must use product identity slots, not raw package text.
    # Generic marketing words remain in visible_text but are excluded from query.
    return build_vision_query(slots)


def _is_weak_visual_query(query: str, slots: Dict[str, str]) -> bool:
    n = normalize_text(query)
    if not n:
        return True
    tokens = n.split()
    strong = [t for t in tokens if t not in GENERIC_IMAGE_WORDS and not t.isdigit() and len(t) >= 3]
    brand = normalize_text(slots.get("brand"))
    product_name = normalize_text(slots.get("product_name"))
    # A reliable image search needs either brand/product name, or at least two strong visible words.
    if brand and product_name and product_name not in GENERIC_IMAGE_WORDS:
        return False
    if len(strong) >= 2:
        return False
    return True


async def extract_product_from_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, str]:
    if not image_bytes:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    cfg = _openrouter_config()
    if not config_env.vision_enabled():
        reason = config_env.vision_disabled_reason()
        _log("VISION_DISABLED_REASON", reason=reason)
        return {"status": "IMAGE_UNCLEAR", "message": "فحص الصور غير مفعّل حاليًا. اكتب اسم المنتج كاملًا."}

    _log("VISION_START")
    _log("VISION_PROVIDER", provider="OpenRouter")
    _log("VISION_MODEL", model=cfg["model"])

    data_url = f"data:{mime_type};base64," + base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "You are reading a pharmacy product package image. Return strict JSON only with keys: "
        "main_visible_product, brand, product_name, product_family, form, strength, size, pack, visible_text, background_text, confidence. "
        "Focus only on the largest/front/central product. Do not use background shelf products as product_name. "
        "Do not guess. If the front product name is not visible, set confidence below 0.75. "
        "Ignore generic words when no brand/product name is visible."
    )
    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]}
        ],
        "temperature": 0,
        "max_tokens": 450,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                _log("VISION_ERROR", provider="openrouter", status=resp.status_code)
                return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as exc:
        _log("VISION_ERROR", provider="openrouter", status=type(exc).__name__)
        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}

    try:
        start = content.find("{")
        end = content.rfind("}")
        data = json.loads(content[start:end + 1] if start >= 0 and end > start else content)
    except Exception:
        _log("VISION_ERROR", provider="openrouter", status="bad_json")
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    try:
        confidence = float(data.get("confidence") or 0)
    except Exception:
        confidence = 0.0
    query = build_query_from_slots(data)
    _log("VISION_EXTRACTED_NAME", value=query[:120])
    _log("VISION_CONFIDENCE", value=confidence)

    if confidence < 0.75 or _is_weak_visual_query(query, data):
        return {"status": "LOW_CONFIDENCE", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}
    data["status"] = "OK"
    data["query"] = query
    data["confidence"] = str(confidence)
    return data
