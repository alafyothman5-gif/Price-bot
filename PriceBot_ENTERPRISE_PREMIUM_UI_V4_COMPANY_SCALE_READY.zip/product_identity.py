from __future__ import annotations

"""Product Identity Registry for PriceBot.

This module builds a canonical, exact-first identity layer over the product
catalog.  It intentionally runs before any scoring/ranking so a sellable product
with a clear name/alias/OCR keyword is found, while generic words never produce
random prices.
"""

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import database
from dynamic_synonyms import apply_synonyms
from normalizer import compact_normalize, normalize_text, safe_price, split_multi, tokens
from query_slots import GENERAL_WORDS, QuerySlots, canonical_form, normalize_measure

IDENTITY_KIND_ORDER = [
    "barcode",
    "normalized_name",
    "compact_name",
    "alias",
    "ocr_keyword",
    "brand_family",
]

# Extra generic/marketing words that may appear on image packages but should not
# create product identity by themselves.
GENERIC_IDENTITY_WORDS = set(GENERAL_WORDS) | {
    "supplement", "supplements", "vitamin", "vitamins", "capsule", "capsules",
    "tablet", "tablets", "cream", "creme", "crème", "tube", "health", "supports",
    "support", "female", "male", "skin", "face", "body", "reduce", "reduces",
    "scars", "ointment", "gel", "syrup", "drops", "mg", "ml", "iu",
    "g", "kg", "paraffin", "vaseline", "glycerol", "with", "for", "plus",
}

@dataclass
class IdentityLookup:
    products: List[Dict] = field(default_factory=list)
    stage: str = ""
    matched_keys: List[str] = field(default_factory=list)
    rejected: List[Tuple[str, str]] = field(default_factory=list)


def _norm(v: object) -> str:
    return apply_synonyms(v)


def _compact(v: object) -> str:
    return compact_normalize(apply_synonyms(v))


def _split_values(v: object) -> List[str]:
    out: List[str] = []
    for piece in split_multi(v):
        n = _norm(piece)
        if n and n not in out:
            out.append(n)
    return out


def identity_tokens(value: object) -> List[str]:
    out: List[str] = []
    for t in tokens(apply_synonyms(value)):
        t = apply_synonyms(t)
        if not t:
            continue
        if t in GENERIC_IDENTITY_WORDS:
            continue
        if canonical_form(t):
            continue
        if t.isdigit():
            continue
        if len(t) <= 2 and not any(ch.isdigit() for ch in t):
            continue
        if t not in out:
            out.append(t)
    return out


def canonical_name(product: Dict) -> str:
    return str(product.get("name") or product.get("original_name") or "").strip()


def normalized_name(product: Dict) -> str:
    return _norm(product.get("normalized_name") or canonical_name(product))


def compact_name(product: Dict) -> str:
    return _compact(product.get("normalized_name") or canonical_name(product))


def canonical_brand(product: Dict) -> str:
    b = _norm(product.get("brand"))
    if b and b not in {"unknown", "غير معروف", "غير مصنف"}:
        return b
    toks = identity_tokens(canonical_name(product))
    return toks[0] if toks else ""


def canonical_family(product: Dict) -> str:
    fam = _norm(product.get("product_family"))
    if fam and fam not in {"unknown", "غير معروف", "غير مصنف"}:
        return fam
    name = normalized_name(product)
    brand = canonical_brand(product)
    if brand and name.startswith(brand + " "):
        return name[len(brand) + 1:].strip()
    return name


def canonical_product_form(product: Dict) -> str:
    """Canonical product form without unsafe category/subcategory inference.

    The category value ``supplement`` is never interpreted as a dosage form.
    If a previous bad import wrote ``suppository`` onto a supplement row because
    it matched ``supp`` inside ``supplement``, this helper ignores that stale
    value unless the product name explicitly contains a suppository term.
    """
    category = _norm(product.get("category") or product.get("main_section") or product.get("section"))
    name_norm = _norm(canonical_name(product))
    explicit_raw = product.get("form") or product.get("medicine_form") or product.get("product_type") or ""
    explicit_norm = _norm(explicit_raw)
    form = canonical_form(explicit_raw)
    if category == "supplement" and form == "suppository" and not any(x in name_norm.split() for x in ["supp", "suppository", "تحاميل"]):
        form = ""
    if form:
        return form
    # For supplements, infer only explicit package forms from the name.  Do not
    # infer any form from category/subcategory strings such as supplement_* .
    if category == "supplement":
        name_form = canonical_form(name_norm)
        return name_form if name_form in {"capsule", "tablet", "syrup", "drops", "sachet"} else ""
    return canonical_form(name_norm)


def identity_key_for_product(product: Dict) -> str:
    parts = [
        canonical_brand(product),
        canonical_family(product),
        _norm(product.get("category") or product.get("main_section") or product.get("section")),
        canonical_product_form(product),
        normalize_measure(product.get("strength")),
        normalize_measure(product.get("size")),
        normalize_measure(product.get("pack")),
    ]
    return "|".join(parts)


def _search_policy(product: Dict) -> str:
    mode = _norm(product.get("search_mode"))
    review = _norm(product.get("review_status"))
    if mode in {"hidden", "review_only", "unknown"} or review in {"unknown", "hidden", "stale_hidden"}:
        return "hidden"
    if mode == "exact_only":
        return "exact_only"
    return "sellable_exact"


def _aliases(product: Dict) -> List[str]:
    vals: List[str] = []
    for raw in _split_values(product.get("aliases")) + _split_values(product.get("ocr_keywords")):
        if raw and raw not in vals and raw not in GENERIC_IDENTITY_WORDS:
            vals.append(raw)
    # Safe aliases derived from catalog name only, not invented medical facts.
    name = normalized_name(product)
    if name and name not in vals:
        vals.append(name)
    comp = compact_normalize(name)
    if comp and comp not in vals:
        vals.append(comp)
    # Common compact/hyphen variants that are known identity equivalences.
    if "gyno daktarin" in name:
        vals += ["gyno-daktarin", "gynodaktarin", "gyno daktarin vag cream"]
    if "mebo scar" in name:
        vals += ["mebo scar ointment", "mebo scar oint", "mebo scar cream"]
    if "mebo oint" in name:
        vals += ["mebo ointment"]
    if "prod3" in name or "pro d3" in name:
        vals += ["pro-d3", "pro d3", "prod3"]
    out: List[str] = []
    for v in vals:
        n = _norm(v)
        if n and n not in out:
            out.append(n)
    return out


def build_registry_entries(products: Optional[List[Dict]] = None) -> List[Tuple]:
    rows = products if products is not None else database.load_product_rows(visible_only=True, guided=False)
    identity_groups: Dict[str, List[Dict]] = defaultdict(list)
    for p in rows:
        if database.product_visible(p, guided=False):
            identity_groups[identity_key_for_product(p)].append(p)

    duplicate_group_for: Dict[str, str] = {}
    for key, group in identity_groups.items():
        prices = {safe_price(p.get("price")) for p in group if safe_price(p.get("price"))}
        if len(group) > 1 and len(prices) > 1:
            duplicate_group_for[key] = "duplicate_price_conflict"

    entries: List[Tuple] = []
    for p in rows:
        if not database.product_visible(p, guided=False):
            continue
        ikey = identity_key_for_product(p)
        entries.append((
            int(p["id"]),
            str(p.get("product_id") or ""),
            ikey,
            canonical_name(p),
            normalized_name(p),
            compact_name(p),
            canonical_brand(p),
            canonical_family(p),
            canonical_product_form(p),
            normalize_measure(p.get("strength")),
            normalize_measure(p.get("size")),
            normalize_measure(p.get("pack")),
            str(p.get("barcode") or "").strip(),
            " | ".join(_aliases(p)),
            " | ".join(_split_values(p.get("ocr_keywords"))),
            _norm(p.get("category") or p.get("main_section") or p.get("section")),
            _search_policy(p),
            duplicate_group_for.get(ikey, ""),
        ))
    return entries


def rebuild_product_identity_registry() -> int:
    entries = build_registry_entries()
    return database.replace_product_identity_registry(entries)


def _candidate_keys_from_slots(slots: QuerySlots) -> List[Tuple[str, str]]:
    keys: List[Tuple[str, str]] = []
    if slots.barcode:
        keys.append(("barcode", slots.barcode))
    if slots.normalized:
        keys.append(("normalized_name", slots.normalized))
    if slots.compact:
        keys.append(("compact_name", slots.compact))
    # Exact alias/ocr keyword can be shorter or longer than the query if it is a
    # recognized identity equivalence from the catalog/synonyms.
    if slots.normalized:
        keys.append(("alias", slots.normalized))
        keys.append(("ocr_keyword", slots.normalized))
    if slots.brand and slots.product_family:
        keys.append(("brand_family", f"{slots.brand} {slots.product_family}".strip()))
    # Normalize and de-dupe.
    out: List[Tuple[str, str]] = []
    seen = set()
    for kind, key in keys:
        nk = _norm(key)
        if not nk:
            continue
        rec = (kind, nk)
        if rec not in seen:
            seen.add(rec); out.append(rec)
        comp = compact_normalize(nk)
        if comp and comp != nk:
            rec2 = (kind, comp)
            if rec2 not in seen:
                seen.add(rec2); out.append(rec2)
    return out


def _registry_row_matches_slots(row: Dict, slots: QuerySlots, kind: str, key: str) -> bool:
    if row.get("search_policy") == "hidden":
        return False
    if kind == "barcode":
        return bool(slots.barcode and str(row.get("barcode") or "") == slots.barcode)
    rn = _norm(row.get("normalized_name"))
    rc = _compact(row.get("compact_name") or row.get("normalized_name"))
    aliases = _split_values(row.get("aliases")) + _split_values(row.get("ocr_keywords"))
    alias_compacts = [compact_normalize(a) for a in aliases]
    keyn = _norm(key)
    keyc = compact_normalize(keyn)
    if kind in {"normalized_name", "compact_name"}:
        if keyn == rn or keyc == rc:
            return True
    if kind in {"alias", "ocr_keyword"}:
        if keyn in aliases or keyc in alias_compacts:
            return True
        # Strict subset equivalence for short catalog identities vs long OCR.
        q_tokens = identity_tokens(keyn)
        row_values = [rn, str(row.get("canonical_name") or ""), str(row.get("product_family") or "")] + aliases
        for val in row_values:
            vtoks = identity_tokens(val)
            if len(vtoks) >= 2 and all(t in q_tokens or t in keyc for t in vtoks):
                return True
            if len(q_tokens) >= 2 and all(t in vtoks or t in compact_normalize(val) for t in q_tokens):
                return True
    if kind == "brand_family":
        brand = _norm(row.get("brand"))
        fam = _norm(row.get("product_family"))
        if slots.brand and slots.product_family:
            requested = identity_tokens(f"{slots.brand} {slots.product_family}")
            rowt = identity_tokens(f"{brand} {fam} {rn} {' '.join(aliases)}")
            return len(requested) >= 2 and all(t in rowt or t in rc for t in requested)
    return False


def _limited_registry_rows_by_tokens(slots: QuerySlots, max_rows: int = 300) -> List[Dict]:
    """Small fallback candidate pool for subset equivalence.

    This avoids scanning all registry rows with expensive synonym normalization.
    It is only used after direct exact registry lookups fail.
    """
    toks = identity_tokens(slots.normalized)
    if not toks:
        return []
    rows = database.load_product_identity_registry()
    out: List[Dict] = []
    for row in rows:
        blob = " ".join(str(row.get(c) or "") for c in ["normalized_name", "compact_name", "brand", "product_family", "aliases", "ocr_keywords"])
        if any(t in blob for t in toks[:3]):
            out.append(row)
            if len(out) >= max_rows:
                break
    return out


def lookup_exact_identity_candidates(slots: QuerySlots, limit: int = 40) -> IdentityLookup:
    keys = _candidate_keys_from_slots(slots)
    matches: List[Dict] = []
    matched_keys: List[str] = []
    rejected: List[Tuple[str, str]] = []
    # Tiered exact lookup from the registry.  Stop at the first successful tier;
    # do not widen to token scoring when a product identity was found.
    for kind, key in keys:
        rows = database.find_identity_registry(kind, key, limit=limit)
        verified = [r for r in rows if _registry_row_matches_slots(r, slots, kind, key)]
        if verified:
            ids = [int(r["product_db_id"]) for r in verified]
            matches = database.get_products_by_ids(ids)
            matched_keys.append(f"{kind}:{key}")
            break
    # Safe subset fallback only over a small token-constrained registry pool.
    if not matches and slots.normalized:
        for row in _limited_registry_rows_by_tokens(slots):
            if _registry_row_matches_slots(row, slots, "alias", slots.normalized):
                ids = [int(row["product_db_id"])]
                matches.extend(database.get_products_by_ids(ids))
                matched_keys.append(f"subset:{slots.normalized}")
        # de-dupe subset results
    if not matches and keys:
        rejected.append((keys[0][1], "identity_exact_not_found"))
    out: List[Dict] = []
    seen = set()
    for p in matches:
        pid = p.get("id")
        if pid in seen:
            continue
        seen.add(pid); out.append(p)
        if len(out) >= limit:
            break
    return IdentityLookup(products=out, stage="PRODUCT_IDENTITY_REGISTRY", matched_keys=matched_keys, rejected=rejected)


def registry_counts() -> Dict[str, int]:
    rows = database.load_product_identity_registry()
    return {
        "product_identity_registry": len(rows),
        "duplicate_conflicts": sum(1 for r in rows if r.get("duplicate_group")),
        "exact_only": sum(1 for r in rows if r.get("search_policy") == "exact_only"),
    }
