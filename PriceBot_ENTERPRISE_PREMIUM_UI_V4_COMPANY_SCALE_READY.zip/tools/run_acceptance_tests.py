#!/usr/bin/env python3
from __future__ import annotations
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import search_engine
from services.matching.excel_native_matcher import invalidate_memory_index, match_text, match_vision_slots, preload_search_index


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def _products(result):
    if result.products:
        return result.products
    if result.product:
        return [result.product]
    return []


def _assert_status(label: str, result, allowed, contains: str = "") -> None:
    if isinstance(allowed, str):
        allowed = {allowed}
    _assert(result.status in allowed, f"{label}: expected {allowed}, got {result.status} message={getattr(result, 'message', '')!r}")
    if contains:
        joined = " | ".join(str(p.get("name") or "") for p in _products(result)).lower()
        _assert(contains.lower() in joined, f"{label}: expected product containing {contains!r}, got {joined!r}")
    print(f"PASS {label}: {result.status}")


def _assert_flagyl_syrup(label: str, result) -> None:
    _assert_status(label, result, {"EXACT_MATCH", "ASK_CLARIFICATION"}, "flagyl")
    ps = _products(result)
    _assert(ps, f"{label}: expected Flagyl syrup/suspension product(s), got none")
    for p in ps:
        name = str(p.get("name") or "").lower()
        form = str(p.get("form") or p.get("medicine_form") or p.get("product_type") or "").lower()
        _assert("flagyl" in name, f"{label}: non-Flagyl leaked: {p.get('name')}")
        _assert(form in {"syrup", "suspension"}, f"{label}: wrong form leaked: {p.get('name')} form={form!r}")
    print(f"PASS {label}: HARD_FORM_FILTER_OK")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db-path", required=True)
    args = parser.parse_args()
    os.environ["PRICEBOT_DB_PATH"] = args.db_path
    os.environ["PRICEBOT_MATCH_LOG"] = "0"
    database.configure_db_path(args.db_path)
    database.init_db(run_production_guard=False)
    search_engine.invalidate_memory_index()
    invalidate_memory_index()
    preload_search_index()

    products_count = database.count_products()
    registry_count = database.identity_registry_count()
    search_index_count = database.count_table("product_search_index")
    guided_index_count = database.count_table("guided_catalog_index")
    _assert(products_count >= 1000, f"products_count too low: {products_count}")
    _assert(registry_count >= 1000, f"product_identity_registry too low: {registry_count}")

    text_cases = [
        ("Panadol generic", search_engine.search_product("Panadol"), "ASK_CLARIFICATION", "panadol"),
        ("Flagyl generic", search_engine.search_product("فلاجيل"), "ASK_CLARIFICATION", "flagyl"),
        ("Flagyl 500 duplicate/form", search_engine.search_product("فلاجيل 500"), "ASK_CLARIFICATION", "flagyl"),
        ("MEBO scar", search_engine.search_product("MEBO scar"), "EXACT_MATCH", "scar"),
        ("Pro-D3 exact", search_engine.search_product("Pro-D3 50,000 IU vitamin k2 15 capsules"), "EXACT_MATCH", "Pro-D3"),
        ("Rilastil missing specific", search_engine.search_product("Rilastil xerolact PB"), "NOT_AVAILABLE", ""),
        ("Cerave cleanser no wrong type", search_engine.search_product("Cerave Hydrating Cleanser"), {"NOT_AVAILABLE", "ASK_CLARIFICATION", "COSMETIC_ALTERNATIVES"}, ""),
        ("Amoclan syrup scoped", search_engine.search_product("Amoclan syrup"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}, ""),
    ]
    passed = 0
    for label, result, allowed, contains in text_cases:
        _assert_status(label, result, allowed, contains)
        passed += 1

    _assert_flagyl_syrup("Flagyl syrup search_engine", search_engine.search_product("فلاجيل شراب")); passed += 1
    _assert_flagyl_syrup("Flagyl syrup excel_native", match_text("فلاجيل شراب")); passed += 1

    vision_cases = [
        ("Hemazym vision", match_vision_slots({"visible_text":"LIPOSOMAL Hemazym IRON SUPPLEMENT Folic Acid Vitamin B12 30 capsules", "main_visible_product":"Hemazym", "confidence":0.95}), "EXACT_MATCH", "Hemazym"),
        ("MEBO Scar vision", match_vision_slots({"visible_text":"MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym", "main_visible_product":"MEBO SCAR OINTMENT", "confidence":0.95}), "EXACT_MATCH", "scar"),
        ("Pro-D3 vision", match_vision_slots({"visible_text":"Pro-D3 50,000 IU Vitamin K2 15 capsules", "main_visible_product":"Pro-D3 50,000 IU Vitamin K2 15 capsules", "confidence":0.95}), "EXACT_MATCH", "Pro-D3"),
        ("Dexeryl vision", match_vision_slots({"visible_text":"DEXERYL crème cream 250g tube", "main_visible_product":"DEXERYL crème cream 250g tube", "confidence":0.95}), "EXACT_MATCH", "DEXERYL"),
        ("Mari Female vision", match_vision_slots({"visible_text":"MARI FEMALE Female Fertility 3600mg 30 Sachet 108g", "main_visible_product":"MARI FEMALE Female Fertility 3600mg 30 Sachet 108g", "confidence":0.95}), "EXACT_MATCH", "Mari Female"),
        ("Propoli vision", match_vision_slots({"visible_text":"PROPOLI Concentrated Fluid Food Supplement", "main_visible_product":"PROPOLI Concentrated Fluid Food Supplement", "confidence":0.95}), "EXACT_MATCH", "propoli"),
        ("Remedica partial vision", match_vision_slots({"visible_text":"100 ml oral suspension Remedica", "confidence":0.9}), {"LOW_CONFIDENCE", "IMAGE_UNCLEAR"}, ""),
    ]
    for label, result, allowed, contains in vision_cases:
        _assert_status(label, result, allowed, contains)
        passed += 1

    print(f"products_count={products_count}")
    print(f"product_identity_registry={registry_count}")
    print(f"product_search_index={search_index_count}")
    print(f"guided_catalog_index={guided_index_count}")
    print(f"ACCEPTANCE_TESTS_ALL_PASS={passed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
