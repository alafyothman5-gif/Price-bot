from __future__ import annotations

import asyncio
import csv
from pathlib import Path

import pytest

import database
from tools.import_product_aliases_from_csv import import_alias_csv


def _insert_product(conn, name: str, price: str = "10") -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": database.clean_alias_text(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def test_import_product_aliases_csv_and_unmatched(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_test.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        pid = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        _insert_product(conn, "Transition 10g", "20")
    csv_path = tmp_path / "aliases.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["original_name", "alias_text"])
        writer.writeheader()
        writer.writerow({"original_name": "Flagyl 125mg/5ml Oral Suspension 60ml", "alias_text": "FLAGYL 125mg/5ml oral suspension 60 ml"})
        writer.writerow({"original_name": "Missing Product", "alias_text": "missing alias"})
    stats = import_alias_csv(csv_path, tmp_path / "unmatched.csv")
    assert stats["aliases_inserted"] == 1
    assert stats["unmatched_products"] == 1
    with database.connect() as conn:
        row = conn.execute("SELECT product_id, alias_text, cleaned_alias, confidence, source, active FROM product_aliases WHERE cleaned_alias=?", (database.clean_alias_text("FLAGYL 125mg/5ml oral suspension 60 ml"),)).fetchone()
        assert row is not None
        assert int(row["product_id"]) == pid
        assert row["source"] == "ai_generated"
        assert int(row["active"]) == 1


def test_exact_alias_lookup_is_unique_and_does_not_cross_size(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_lookup.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        flagyl = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        transition10 = _insert_product(conn, "Transition 10g", "20")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_id, alias_text, cleaned_alias, confidence, source, active)
            VALUES(?,?,?,?, 'ai_generated', 1)
        """, (flagyl, "FLAGYL 125mg/5ml oral suspension 60 ml", database.clean_alias_text("FLAGYL 125mg/5ml oral suspension 60 ml"), 0.95))
        conn.execute("""
            INSERT INTO product_aliases(product_id, alias_text, cleaned_alias, confidence, source, active)
            VALUES(?,?,?,?, 'ai_generated', 1)
        """, (transition10, "Transition 10g", database.clean_alias_text("Transition 10g"), 0.95))
    hit = database.lookup_product_by_alias_exact(["FLAGYL 125mg/5ml oral suspension 60 ml"])
    assert hit["status"] == "EXACT_ALIAS_MATCH"
    assert int(hit["product"]["id"]) == flagyl
    miss = database.lookup_product_by_alias_exact(["Transition 4g"])
    assert miss["status"] == "NO_MATCH"


def test_image_alias_hit_requires_confirmation_before_price(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_alias_image.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        pid = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_id, alias_text, cleaned_alias, confidence, source, active)
            VALUES(?,?,?,?, 'ai_generated', 1)
        """, (pid, "FLAGYL 125mg/5ml oral suspension 60 ml", database.clean_alias_text("FLAGYL 125mg/5ml oral suspension 60 ml"), 0.95))

    async def fake_send(*args, **kwargs):
        return True

    async def fake_download(media_id):
        return b"fake-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "FLAGYL 125mg/5ml oral suspension 60 ml",
            "foreground_product_text": "FLAGYL 125mg/5ml oral suspension 60 ml",
            "primary_title": "Flagyl",
            "brand": "Flagyl",
            "form": "oral suspension",
            "strength": "125mg/5ml",
            "size": "60ml",
        }

    state = {}
    monkeypatch.setattr(app, "send_whatsapp_message", fake_send)
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = asyncio.run(app.process_image("218900000000", "media-flagyl"))
    assert "هل هذا المنتج" in reply
    assert "15" not in reply
    assert state.get("state") == "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("product_id") == pid


def test_image_alias_lookup_contains_and_subset_legacy_columns(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_contains.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        flagyl = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        transition10 = _insert_product(conn, "Transition 10g", "20")
        database.ensure_product_aliases_schema(conn)
        # Use the current/legacy columns requested by production: product_db_id,
        # alias, normalized_alias, approved, source.
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (flagyl, "flagyl 125mg", database.clean_alias_text("flagyl 125mg"), "ai_generated"))
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (flagyl, "فلاجيل 125mg", database.clean_alias_text("فلاجيل 125mg"), "ai_generated"))
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (transition10, "Transition 10g", database.clean_alias_text("Transition 10g"), "ai_generated"))

    vision_text = "flagyl 125mg 5ml metronidazole oral use 1 bottle of oral suspension 60 ml"
    hit = database.lookup_product_by_alias_image_text([vision_text])
    assert hit["status"] == "EXACT_ALIAS_MATCH"
    assert hit["match_stage"] in {"ALIAS_CONTAINED_IN_VISION_TEXT", "ALIAS_TOKENS_SUBSET_OF_VISION_TEXT"}
    assert int(hit["product"]["id"]) == flagyl

    miss = database.lookup_product_by_alias_image_text(["Transition 4g cream"])
    assert miss["status"] == "NO_MATCH"


def test_image_alias_lookup_multiple_products_returns_options(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_ambiguous.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        p1 = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        p2 = _insert_product(conn, "Flagyl 125mg Tablet", "12")
        database.ensure_product_aliases_schema(conn)
        for pid, alias in [(p1, "flagyl 125mg"), (p2, "flagyl 125mg")]:
            conn.execute("""
                INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
                VALUES(?,?,?,?,1)
            """, (pid, alias, database.clean_alias_text(alias), "ai_generated"))

    hit = database.lookup_product_by_alias_image_text(["flagyl 125mg metronidazole oral suspension 60 ml"])
    assert hit["status"] == "AMBIGUOUS"
    assert sorted(hit["product_ids"]) == sorted([p1, p2])
    assert len(hit.get("products") or []) == 2


@pytest.mark.asyncio
async def test_image_alias_contained_requires_confirmation_before_price(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_alias_image_contains.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        pid = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (pid, "flagyl 125mg", database.clean_alias_text("flagyl 125mg"), "ai_generated"))

    async def fake_send(*args, **kwargs):
        return True

    async def fake_download(media_id):
        return b"fake-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "flagyl 125mg 5ml metronidazole oral use 1 bottle of oral suspension 60 ml",
            "foreground_product_text": "flagyl 125mg 5ml metronidazole oral use 1 bottle of oral suspension 60 ml",
            "primary_title": "Flagyl",
            "brand": "Flagyl",
            "form": "oral suspension",
            "strength": "125mg/5ml",
            "size": "60ml",
        }

    state = {}
    monkeypatch.setattr(app, "send_whatsapp_message", fake_send)
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000000", "media-flagyl-contained")
    assert "هل هذا المنتج" in reply
    assert "15" not in reply
    assert state.get("state") == "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("product_id") == pid
    assert state.get("alias_match_stage") in {"ALIAS_CONTAINED_IN_VISION_TEXT", "ALIAS_TOKENS_SUBSET_OF_VISION_TEXT"}


def test_image_alias_lookup_rejects_brand_only_alias(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_brand_only.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        brand_row = _insert_product(conn, "brand LA ROCHE-POSAY", "0")
        conn.execute("UPDATE products SET brand=? WHERE id=?", ("LA ROCHE-POSAY", brand_row))
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (brand_row, "LA ROCHE-POSAY", database.clean_alias_text("LA ROCHE-POSAY"), "ai_generated"))

    hit = database.lookup_product_by_alias_image_text(["LA ROCHE-POSAY"])
    assert hit["status"] == "BRAND_ONLY"
    assert "product" not in hit


@pytest.mark.asyncio
async def test_image_brand_only_never_sets_confirmation(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_brand_only_image.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        brand_row = _insert_product(conn, "brand LA ROCHE-POSAY", "0")
        conn.execute("UPDATE products SET brand=? WHERE id=?", ("LA ROCHE-POSAY", brand_row))
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (brand_row, "LA ROCHE-POSAY", database.clean_alias_text("LA ROCHE-POSAY"), "ai_generated"))

    async def fake_send(*args, **kwargs):
        return True

    async def fake_download(media_id):
        return b"fake-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "LA ROCHE-POSAY",
            "foreground_product_text": "LA ROCHE-POSAY",
            "primary_title": "LA ROCHE-POSAY",
            "brand": "LA ROCHE-POSAY",
            "confidence": 0.95,
        }

    state = {}
    monkeypatch.setattr(app, "send_whatsapp_message", fake_send)
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000001", "media-brand-only")
    assert "هل هذا المنتج" not in reply
    assert state.get("state") != "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("pending_product_id") is None


def test_image_confirmation_yes_uses_pending_product_id_not_query(monkeypatch, tmp_path):
    import ui_flow

    database.configure_db_path(str(tmp_path / "pricebot_pending_product_id.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        correct = _insert_product(conn, "Anthelios UVMune 400 Cream", "55")
        wrong = _insert_product(conn, "brand LA ROCHE-POSAY", "0")
        conn.execute("UPDATE products SET brand=? WHERE id=?", ("LA ROCHE-POSAY", wrong))

    state = {
        "state": "WAITING_FOR_IMAGE_CONFIRMATION",
        "pending_product_id": correct,
        "confirmation_query": "LA ROCHE-POSAY",
        "extracted_slots": {"brand": "LA ROCHE-POSAY", "primary_title": "LA ROCHE-POSAY"},
    }
    monkeypatch.setattr(ui_flow.cs, "get", lambda phone: dict(state))
    monkeypatch.setattr(ui_flow.cs, "set", lambda phone, st, **data: state.update({"state": st, **data}))
    monkeypatch.setattr(ui_flow.visual_memory, "learn_from_confirmation", lambda *a, **k: {"approved": False})

    reply = ui_flow.handle_text("218900000002", "نعم")
    assert "Anthelios UVMune 400 Cream" in reply
    assert "LA ROCHE-POSAY" not in reply or "brand LA ROCHE-POSAY" not in reply
    assert "55" in reply


def test_single_token_product_alias_is_not_brand_only(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_single_token_alias.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        hemazym = _insert_product(conn, "Hemazym", "25")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (hemazym, "Hemazym", database.clean_alias_text("Hemazym"), "ai_generated"))

    hit = database.lookup_product_by_alias_image_text(["hemazym folic acid vitamin b12 supplement text"])
    assert hit["status"] == "EXACT_ALIAS_MATCH"
    assert hit["match_stage"] == "SINGLE_TOKEN_PRODUCT_ALIAS"
    assert int(hit["product"]["id"]) == hemazym


@pytest.mark.asyncio
async def test_hemazym_single_token_alias_sets_confirmation_not_low_confidence(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_hemazym_image.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        hemazym = _insert_product(conn, "Hemazym", "25")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_db_id, alias, normalized_alias, source, approved)
            VALUES(?,?,?,?,1)
        """, (hemazym, "Hemazym", database.clean_alias_text("Hemazym"), "ai_generated"))

    async def fake_send(*args, **kwargs):
        return True

    async def fake_download(media_id):
        return b"fake-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "hemazym folic acid vitamin b12",
            "foreground_product_text": "Hemazym",
            "primary_title": "Hemazym",
            "brand": "Hemazym",
            "raw_vision_text": "hemazym folic acid vitamin b12",
            "ingredients": ["folic acid", "vitamin b12"],
            "confidence": 0.95,
        }

    state = {}
    monkeypatch.setattr(app, "send_whatsapp_message", fake_send)
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000003", "media-hemazym")
    assert "هل هذا المنتج" in reply
    assert "Hemazym" in reply
    assert "25" not in reply
    assert state.get("state") == "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("pending_product_id") == hemazym
    assert state.get("alias_match_stage") in {"EXACT_PRODUCT_ALIAS", "SINGLE_TOKEN_PRODUCT_ALIAS"}
