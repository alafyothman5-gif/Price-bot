# PriceBot V16.4 - Image Product Line Strict

إصلاحات الصور:
- إذا الصورة فيها ماركة + خط منتج مثل Advancis Flexijoints، لا تعرض كل منتجات Advancis.
- إذا الصورة فيها اسم تجاري مثل Zyprexa، لا تطابق المادة الفعالة فقط مثل Olanzapine.
- تشديد cross-check للصور: المنتج المقترح يجب أن يحتوي الاسم التجاري/خط المنتج المقروء من الصورة.
