from __future__ import annotations

import asyncio
import copy
import hashlib
import hmac
import json
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse

try:
    from starlette_exporter import PrometheusMiddleware, handle_metrics
except Exception:  # optional observability dependency
    PrometheusMiddleware = None
    handle_metrics = None

import config_env

config_env.load_environment()

import database
import vision_service
import product_identity_router
import cosmetic_alternatives
from semantic_matcher import MATCHER_NAME, SemanticMatcher, looks_like_prescription, product_name, product_price
from normalizer import normalize_text
from state_store import RuntimeState, RedisTtlRateLimiter

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN") or os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "الصيدلية")
PRICEBOT_CURRENCY = os.getenv("PRICEBOT_CURRENCY", "د.ل")

TEXT_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_TEXT_QUEUE_MAXSIZE", os.getenv("PRICEBOT_QUEUE_MAXSIZE", "8000")) or 8000)
IMAGE_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_IMAGE_QUEUE_MAXSIZE", "1500") or 1500)
TEXT_WORKERS = int(os.getenv("PRICEBOT_TEXT_WORKERS", "20") or 20)
IMAGE_WORKERS = int(os.getenv("PRICEBOT_IMAGE_WORKERS", "6") or 6)
IMAGE_CONCURRENCY = int(os.getenv("PRICEBOT_IMAGE_CONCURRENCY", "5") or 5)
IMAGE_TOTAL_TIMEOUT = float(os.getenv("PRICEBOT_IMAGE_TOTAL_TIMEOUT_SECONDS", "18") or 18)
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "90") or 90)
RATE_LIMIT_IMAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_IMAGES", "15") or 15)
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60") or 60)
PRODUCT_INDEX_TTL = int(os.getenv("PRICEBOT_PRODUCT_INDEX_TTL_SECONDS", "300") or 300)
MAX_LIST_ROWS = min(10, int(os.getenv("PRICEBOT_MAX_LIST_ROWS", "10") or 10))
MAX_LIST_MESSAGES = int(os.getenv("PRICEBOT_MAX_LIST_MESSAGES", "3") or 3)
STATE_TTL = int(os.getenv("PRICEBOT_USER_STATE_TTL_SECONDS", "7200") or 7200)
CONFIRM_TTL = int(os.getenv("PRICEBOT_CONFIRMATION_TTL_SECONDS", "900") or 900)
GLOBAL_RATE_LIMIT_REQUESTS = int(os.getenv("PRICEBOT_GLOBAL_RATE_LIMIT_REQUESTS", "600") or 600)
GLOBAL_RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_GLOBAL_RATE_LIMIT_WINDOW_SECONDS", "60") or 60)
QUEUE_ITEM_TIMEOUT = float(os.getenv("PRICEBOT_QUEUE_ITEM_TIMEOUT_SECONDS", "45") or 45)
SHUTDOWN_DRAIN_TIMEOUT = float(os.getenv("PRICEBOT_SHUTDOWN_DRAIN_TIMEOUT_SECONDS", "15") or 15)
WEBHOOK_BUSY_STATUS_CODE = int(os.getenv("PRICEBOT_WEBHOOK_BUSY_STATUS_CODE", "503") or 503)
CUSTOMER_BUSY_MESSAGE = os.getenv("PRICEBOT_CUSTOMER_BUSY_MESSAGE", "النظام مشغول حاليًا. حاول بعد قليل.")
IMAGE_QUEUE_WARN_AT = int(os.getenv("PRICEBOT_IMAGE_QUEUE_WARN_AT", "60") or 60)
IMAGE_QUEUE_REJECT_AT = int(os.getenv("PRICEBOT_IMAGE_QUEUE_REJECT_AT", "240") or 240)
IMAGE_QUEUE_NOTICE_TTL = int(os.getenv("PRICEBOT_IMAGE_QUEUE_NOTICE_TTL_SECONDS", "120") or 120)
IMAGE_OVERLOAD_MESSAGE = os.getenv("PRICEBOT_IMAGE_OVERLOAD_MESSAGE", "تحليل الصور عليه ضغط حاليًا. اكتب اسم المنتج للرد أسرع أو جرّب بعد دقيقة.")
IMAGE_QUEUE_WAIT_MESSAGE = os.getenv("PRICEBOT_IMAGE_QUEUE_WAIT_MESSAGE", "تم استلام الصورة. يوجد ضغط على تحليل الصور وقد يتأخر الرد قليلًا. كتابة اسم المنتج أسرع.")
COSMETIC_ALT_TTL = int(os.getenv("PRICEBOT_COSMETIC_ALT_TTL_SECONDS", "900") or 900)
COSMETIC_ALT_MAX_RESULTS = min(10, int(os.getenv("PRICEBOT_COSMETIC_ALT_MAX_RESULTS", "5") or 5))
COSMETIC_ALT_CANDIDATES = int(os.getenv("PRICEBOT_COSMETIC_ALT_CANDIDATES", "60") or 60)
COSMETIC_ALT_TIMEOUT = float(os.getenv("PRICEBOT_COSMETIC_ALT_TIMEOUT_SECONDS", "12") or 12)
COSMETIC_ALT_CONCURRENCY = int(os.getenv("PRICEBOT_COSMETIC_ALT_CONCURRENCY", "2") or 2)


BTN_SEARCH_TEXT = "BTN_SEARCH_TEXT"
BTN_SEARCH_IMAGE = "BTN_SEARCH_IMAGE"
BTN_CONFIRM_YES = "CONFIRM_YES"
BTN_CONFIRM_NO = "CONFIRM_NO"
BTN_COSMETIC_ALT_YES = "COSMETIC_ALT_YES"
BTN_COSMETIC_ALT_NO = "COSMETIC_ALT_NO"
UNSUPPORTED_MEDIA_TOKEN = "__UNSUPPORTED_MEDIA__"
FINAL_UI_VERSION = "v16_4_image_product_line_strict"

app = FastAPI(title="PriceBot WhatsApp V16 Product Identity Router", docs_url=None, redoc_url=None, openapi_url=None)
if PrometheusMiddleware is not None and handle_metrics is not None:
    app.add_middleware(PrometheusMiddleware)
    app.add_route("/metrics", handle_metrics)
text_queue: asyncio.Queue = asyncio.Queue(maxsize=TEXT_QUEUE_MAXSIZE)
image_queue: asyncio.Queue = asyncio.Queue(maxsize=IMAGE_QUEUE_MAXSIZE)
http_client: Optional[httpx.AsyncClient] = None
image_semaphore = asyncio.Semaphore(max(1, IMAGE_CONCURRENCY))
cosmetic_alt_semaphore = asyncio.Semaphore(max(1, COSMETIC_ALT_CONCURRENCY))
state = RuntimeState(namespace=os.getenv("PRICEBOT_STATE_NAMESPACE", "pricebot"), mode_ttl=STATE_TTL, confirmation_ttl=CONFIRM_TTL)
semantic_matcher = SemanticMatcher(ttl_seconds=PRODUCT_INDEX_TTL)
text_limiter = RedisTtlRateLimiter(state, "user_text", RATE_LIMIT_WINDOW, RATE_LIMIT_MESSAGES)
image_limiter = RedisTtlRateLimiter(state, "user_image", RATE_LIMIT_WINDOW, RATE_LIMIT_IMAGES)
global_limiter = RedisTtlRateLimiter(state, "webhook_global", GLOBAL_RATE_LIMIT_WINDOW, GLOBAL_RATE_LIMIT_REQUESTS)
background_tasks: List[asyncio.Task] = []

RUNTIME_METRICS: Dict[str, int] = {
    "webhooks_total": 0,
    "webhooks_bad_signature": 0,
    "webhooks_rate_limited": 0,
    "messages_queued_total": 0,
    "messages_queue_full_total": 0,
    "messages_expired_total": 0,
    "messages_processed_total": 0,
    "messages_failed_total": 0,
    "whatsapp_send_success_total": 0,
    "whatsapp_send_failed_total": 0,
    "image_backpressure_total": 0,
    "image_rejected_overload_total": 0,
    "cosmetic_alt_offered_total": 0,
    "cosmetic_alt_generated_total": 0,
    "cosmetic_alt_failed_total": 0,
}
STARTED_AT = time.time()
STARTUP_WARNINGS: List[str] = []


def metric_inc(name: str, count: int = 1) -> None:
    try:
        RUNTIME_METRICS[name] = int(RUNTIME_METRICS.get(name, 0)) + int(count or 1)
    except Exception:
        pass


_DIGITS_TRANS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def log(event: str, **kw: Any) -> None:
    payload: Dict[str, Any] = {"ts": round(time.time(), 3), "event": str(event or "EVENT")}
    for k, v in kw.items():
        key = str(k)
        if any(x in key.lower() for x in ["token", "secret", "authorization", "key"]):
            v = "HIDDEN"
        if key in {"phone", "to", "from_", "from"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        try:
            json.dumps(v, ensure_ascii=False)
        except Exception:
            v = repr(v)
        payload[key] = v
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), flush=True)


def _wa_text(body: str) -> Dict[str, Any]:
    return {"__wa_payload": {"type": "text", "text": {"body": str(body or "")[:3900]}}}


def _wa_buttons(body: str, buttons: List[Tuple[str, str]]) -> Dict[str, Any]:
    return {
        "__wa_payload": {
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": str(body or "")[:1000]},
                "action": {"buttons": [{"type": "reply", "reply": {"id": bid, "title": title[:20]}} for bid, title in buttons[:3]]},
            },
        }
    }


def _welcome_menu() -> Dict[str, Any]:
    return _wa_buttons(
        f"مرحبًا بك في {PHARMACY_NAME} 🌿\n\nاختر طريقة البحث عن توفر وسعر الدواء أو المنتج:",
        [(BTN_SEARCH_TEXT, "بحث باسم دواء"), (BTN_SEARCH_IMAGE, "بحث بصورة")],
    )


def _ask_text() -> Dict[str, Any]:
    return _wa_buttons("🔎 اكتب اسم المنتج فقط. اكتب الاسم كاملًا قدر الإمكان", [(BTN_SEARCH_IMAGE, "بحث بالصورة"), ("MENU", "القائمة")])


def _ask_image() -> Dict[str, Any]:
    return _wa_buttons("📷 أرسل صورة واضحة لعلبة الدواء أو المنتج فقط.", [(BTN_SEARCH_TEXT, "بحث بالاسم"), ("MENU", "القائمة")])


def _unavailable(extra: str = "") -> Dict[str, Any]:
    # Customer-facing unavailable response must stay short and must never leak OCR/Gemini text.
    return _wa_buttons("غير متوفر حاليًا في الصيدلية.", [(BTN_SEARCH_TEXT, "بحث جديد"), (BTN_SEARCH_IMAGE, "بحث بصورة")])


def _prescription_payload() -> Dict[str, Any]:
    return _wa_buttons("عذرًا، لا يمكنني قراءة الروشتات الطبية. فضلاً أرسل صورة واضحة لعلبة الدواء أو المنتج فقط.", [(BTN_SEARCH_IMAGE, "بحث بصورة"), ("MENU", "القائمة")])


def _product_reply(product: Dict[str, Any]) -> Dict[str, Any]:
    price = product_price(product, PRICEBOT_CURRENCY)
    if not price:
        return _unavailable()
    return _wa_buttons(f"✅ متوفر\nالسعر: {price}\n\nهل تحتاج مساعدة أخرى؟", [(BTN_SEARCH_TEXT, "بحث جديد"), ("MENU", "القائمة")])


def _short(value: str, limit: int) -> str:
    value = re.sub(r"\s+", " ", str(value or "")).strip()
    return value if len(value) <= limit else value[:limit - 1].rstrip() + "…"


def _product_list(candidates: List[Dict[str, Any]], *, start: int = 0, title: str = "المنتجات المتوفرة", body: str = "وجدت أكثر من منتج متوفر بهذا الاسم. اختر المنتج المطلوب من القائمة:") -> Dict[str, Any]:
    rows = []
    for p in candidates[start:start + MAX_LIST_ROWS]:
        pid = int(p.get("id") or 0)
        name = product_name(p)
        price = product_price(p, PRICEBOT_CURRENCY)
        rows.append({"id": f"PROD:{pid}", "title": _short(name, 24), "description": _short(f"{price} - {name}" if price else name, 72)})
    return {"__wa_payload": {"type": "interactive", "interactive": {"type": "list", "body": {"text": body[:1000]}, "action": {"button": "اختر المنتج", "sections": [{"title": title[:24], "rows": rows}]}}}}


def _product_lists(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payloads: List[Dict[str, Any]] = []
    pages = min(MAX_LIST_MESSAGES, (len(candidates) + MAX_LIST_ROWS - 1) // MAX_LIST_ROWS)
    for i in range(pages):
        payloads.append(_product_list(candidates, start=i * MAX_LIST_ROWS, title=f"القائمة {i + 1}"))
    if len(candidates) > pages * MAX_LIST_ROWS:
        payloads.append(_wa_text("ظهرت نتائج كثيرة. اكتب الاسم بشكل أدق إذا لم تجد المنتج المطلوب."))
    return payloads


def _cosmetic_alt_lists(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payloads: List[Dict[str, Any]] = []
    body = "وجدت بدائل تجميلية قريبة بنفس النوع/المادة من شركات أخرى. اختر المنتج المطلوب من القائمة:"
    pages = min(MAX_LIST_MESSAGES, (len(candidates) + MAX_LIST_ROWS - 1) // MAX_LIST_ROWS)
    for i in range(pages):
        payloads.append(_product_list(candidates, start=i * MAX_LIST_ROWS, title=f"بدائل {i + 1}", body=body))
    return payloads or [_wa_text("لم أجد بدائل مطابقة متوفرة حاليًا.")]


def _confirm_payload(product: Dict[str, Any]) -> Dict[str, Any]:
    return _wa_buttons(f"هل تقصد هذا المنتج؟\n{product_name(product)}\n\nاختر نعم للتأكيد أو لا لإعادة المحاولة.", [(BTN_CONFIRM_YES, "نعم"), (BTN_CONFIRM_NO, "لا")])


def _is_menu(raw: str) -> bool:
    n = normalize_text(raw or "")
    return n in {"", "السلام عليكم", "سلام", "مرحبا", "اهلا", "أهلا", "hi", "hello", "menu", "start", "القائمة", "القائمه", "menu"}


def _is_text_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_TEXT), "بحث باسم دواء", "بحث بنص", "بحث نص", "بحث بالاسم", "اسم", "1"}


def _is_image_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_IMAGE), "بحث بصورة", "بحث صوره", "صورة", "صوره", "2"}


def _is_yes(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_CONFIRM_YES), "نعم", "اي", "ايوة", "أيوة", "تمام", "صح", "yes", "y", "ok", "1"}


def _is_no(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_CONFIRM_NO), "لا", "لأ", "مش هو", "غلط", "no", "n", "0"}


def _clean_image_identity_piece(value: Any) -> str:
    value = str(value or "").replace("\\n", " ").replace("\r", " ")
    value = re.sub(r"[•●|؛]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" -_|:;,.،")
    marketing_phrases = [
        "high absorption", "potent formula base", "potent formula", "formula base",
        "food supplement", "dietary supplement", "iron supplement",
        "dermatologically tested", "clinically proven", "for dry skin", "for very dry skin",
        "dry to very dry", "normal to dry", "sensitive skin", "oily skin", "made in",
        "keep out", "store below", "read leaflet", "supports health",
    ]
    for phrase in marketing_phrases:
        value = re.sub(r"(?i)(?<!\w)" + re.escape(phrase) + r"(?!\w)", " ", value)
    return re.sub(r"\s+", " ", value).strip(" -_|:;,.،")


def _extract_candidate_texts(extracted: Dict[str, Any]) -> List[str]:
    parts: List[str] = []
    # Raw OCR is intentionally last and used only as a final fallback.
    for key in [
        "product_identity", "query", "primary_name", "primary_title", "product_name",
        "brand", "variant", "product_family", "form", "strength", "size", "pack",
        "foreground_product_text", "visible_text", "raw_vision_text",
    ]:
        value = _clean_image_identity_piece((extracted or {}).get(key))
        if value and value not in parts:
            parts.append(value)
    return parts


def _image_evidence_text(extracted: Dict[str, Any]) -> str:
    """Return the clean image query for semantic_matcher.

    V11 rule: product_identity/query first. Do not send full OCR/JSON to the
    matcher unless all identity slots are missing.
    """
    extracted = extracted or {}
    for key in ["product_identity", "query"]:
        value = _clean_image_identity_piece(extracted.get(key))
        if value:
            return value[:180]

    parts: List[str] = []
    seen: set[str] = set()
    for key in ["primary_name", "primary_title", "product_name", "brand", "variant", "product_family", "form", "strength", "size", "pack"]:
        value = _clean_image_identity_piece(extracted.get(key))
        n = normalize_text(value)
        if value and n and n not in seen:
            parts.append(value)
            seen.add(n)
    if parts:
        return " ".join(parts).strip()[:180]
    return " ".join(_extract_candidate_texts(extracted)).strip()[:180]


def _image_fallback_query(extracted: Dict[str, Any], original_query: str) -> str:
    """Short retry query used only when image semantic matching returns unavailable."""
    extracted = extracted or {}
    original_norm = normalize_text(original_query or "")
    for key in ["primary_name", "primary_title", "product_name", "brand"]:
        value = _clean_image_identity_piece(extracted.get(key))
        if value and normalize_text(value) != original_norm:
            return value[:80]
    identity = _clean_image_identity_piece(extracted.get("product_identity") or extracted.get("query") or original_query)
    tokens = [t for t in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}|[\u0600-\u06FF]{3,}", identity) if normalize_text(t) not in {"liposomal", "cream", "tablet", "tablets", "capsules", "supplement"}]
    if tokens:
        fallback = tokens[0]
        if normalize_text(fallback) != original_norm:
            return fallback[:80]
    return ""

_IMAGE_CROSSCHECK_STOPWORDS = {
    "cream", "gel", "tablet", "tablets", "cap", "caps", "capsule", "capsules", "mg", "ml", "oral", "tab", "x1", "x2", "x3", "x4",
    "كريم", "حبوب", "شراب", "كبسول", "كبسولات", "قرص", "اقراص", "ملجم", "مجم",
}

def _match_tokens_for_crosscheck(value: Any) -> set[str]:
    text = normalize_text(str(value or "").replace("/", " ").replace("-", " "))
    out: set[str] = set()
    for token in re.findall(r"[a-z][a-z0-9]{2,}|[\u0600-\u06FF]{3,}|\d+(?:\.\d+)?", text):
        t = normalize_text(token)
        if t and t not in _IMAGE_CROSSCHECK_STOPWORDS:
            out.add(t)
    return out

def _image_visible_tokens(extracted: Dict[str, Any]) -> set[str]:
    parts: List[str] = []
    for key in ["product_identity", "foreground_product_text", "primary_name", "primary_title", "product_name", "brand", "variant", "visible_text", "raw_vision_text"]:
        v = _clean_image_identity_piece((extracted or {}).get(key))
        if v:
            parts.append(v)
    return _match_tokens_for_crosscheck(" ".join(parts))

def _product_tokens_for_crosscheck(product: Dict[str, Any]) -> set[str]:
    parts: List[str] = []
    for key in ["name", "canonical_display_name", "original_name", "brand", "product_family", "aliases", "strength", "size", "pack"]:
        v = str((product or {}).get(key) or "").strip()
        if v:
            parts.append(v)
    return _match_tokens_for_crosscheck(" ".join(parts))

def _token_overlap(a: set[str], b: set[str]) -> bool:
    if not a or not b:
        return False
    if a & b:
        return True
    for x in a:
        for y in b:
            if len(x) >= 4 and len(y) >= 4 and (x in y or y in x):
                return True
    return False

def _image_brand_tokens(extracted: Dict[str, Any]) -> set[str]:
    # Tokens that are likely brand/trade-name tokens. If Vision sees a trade name,
    # the matched product must contain it. This prevents Zyprexa images from
    # matching only the active ingredient Olanzapine.
    parts: List[str] = []
    for key in ["brand", "primary_name", "primary_title", "product_name"]:
        v = _clean_image_identity_piece((extracted or {}).get(key))
        if v:
            parts.append(v)
    tokens = _match_tokens_for_crosscheck(" ".join(parts))
    return {t for t in tokens if not t.isdigit() and len(t) >= 4}

def _image_query_tokens(extracted: Dict[str, Any]) -> set[str]:
    parts: List[str] = []
    for key in ["product_identity", "query", "foreground_product_text", "visible_text", "raw_vision_text"]:
        v = _clean_image_identity_piece((extracted or {}).get(key))
        if v:
            parts.append(v)
    tokens = _match_tokens_for_crosscheck(" ".join(parts))
    # Remove weak marketing/form words. Keep product-line words like flexijoints, effaclar, cicaplast.
    weak = {"film", "kapli", "pain", "relief", "joint", "joints", "care", "tablet", "tablets", "capsules", "supplement", "oral", "contains"}
    return {t for t in tokens if t not in weak and not t.isdigit()}

def _image_candidate_allowed(product: Dict[str, Any], extracted: Dict[str, Any]) -> bool:
    product_tokens = _product_tokens_for_crosscheck(product or {})
    visible = _image_visible_tokens(extracted or {})
    if not visible or not product_tokens:
        return False

    # If a visible brand/trade-name token exists, require it in the product.
    # This blocks active-ingredient-only matches when the box clearly shows a brand.
    brand_tokens = _image_brand_tokens(extracted or {})
    if brand_tokens and not _token_overlap(brand_tokens, product_tokens):
        return False

    # If Vision extracted product-line tokens beyond the brand, require at least one
    # of those line tokens in the candidate. This prevents an Advancis Flexijoints
    # image from listing every Advancis product.
    query_tokens = _image_query_tokens(extracted or {})
    line_tokens = query_tokens - brand_tokens
    if len(query_tokens) >= 2 and line_tokens:
        if not _token_overlap(line_tokens, product_tokens):
            return False

    return _token_overlap(visible, product_tokens)

def _filter_image_candidates(candidates: List[Dict[str, Any]], extracted: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for p in candidates or []:
        try:
            pid = int((p or {}).get("id") or 0)
        except Exception:
            pid = 0
        if not pid or pid in seen:
            continue
        if _image_candidate_allowed(p, extracted or {}):
            out.append(p)
            seen.add(pid)
    return out

def _image_match_crosscheck(product: Dict[str, Any], extracted: Dict[str, Any]) -> bool:
    return _image_candidate_allowed(product or {}, extracted or {})

def _image_uncertain_reply() -> Dict[str, Any]:
    return _wa_buttons(
        "الصورة غير واضحة أو لم أستطع تأكيد اسم المنتج من الواجهة الأمامية. أرسل صورة أوضح للعلبة كاملة أو اكتب الاسم كاملًا.",
        [(BTN_SEARCH_IMAGE, "بحث بصورة"), (BTN_SEARCH_TEXT, "بحث بالاسم")],
    )


_ELASTIC_FORM_STOPWORDS = {
    "cream", "gel", "lotion", "serum", "tablet", "tablets", "capsule", "capsules", "cap", "caps",
    "syrup", "spray", "drops", "drop", "solution", "suspension", "soap", "wash", "cleanser",
    "supplement", "liposomal", "original", "new", "advanced", "extra", "plus", "complex",
    "كريم", "جل", "حبوب", "كبسولات", "شراب", "بخاخ", "قطرة", "غسول", "لوشن",
}

_ELASTIC_BRAND_STOPWORDS = {
    "la", "roche", "posay", "laroche", "cerave", "bioderma", "rilastil", "eucerin", "vichy",
    "avene", "uriage", "isis", "svr", "mustela", "nuxe", "ordinary", "ordinary.", "the",
}


def _elastic_tokens(value: Any) -> List[str]:
    text = _clean_image_identity_piece(value)
    if not text:
        return []
    # If a JSON-like image payload reaches this layer, extract the readable string
    # values instead of matching against braces/field names.
    try:
        if text[:1] in {"{", "["}:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                parts = []
                for key in ["product_identity", "primary_name", "product_name", "brand", "variant", "query", "foreground_product_text"]:
                    val = parsed.get(key)
                    if val:
                        parts.append(str(val))
                text = " ".join(parts) or text
    except Exception:
        pass
    return re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}|[\u0600-\u06FF]{3,}", text)


def _strong_primary_query(raw_query: Any, extracted: Optional[Dict[str, Any]] = None) -> str:
    """Return a compact retry query for the second semantic attempt.

    For images, prefer Vision's explicit primary slots. For text, keep the
    strongest distinctive token and intentionally skip very common brand/form
    words when another stronger token exists. Example: "Rilastil Xerolact" ->
    "Xerolact".
    """
    extracted = extracted or {}
    original_norm = normalize_text(raw_query or "")
    for key in ["primary_name", "primary_title", "product_name"]:
        value = _clean_image_identity_piece(extracted.get(key))
        if value and normalize_text(value) != original_norm:
            return value[:80]

    tokens = _elastic_tokens(raw_query)
    if not tokens:
        return ""

    cleaned: List[str] = []
    seen: set[str] = set()
    for token in tokens:
        n = normalize_text(token)
        if not n or len(n) < 3 or n in seen:
            continue
        seen.add(n)
        cleaned.append(token)

    if not cleaned:
        return ""

    preferred = []
    for token in cleaned:
        n = normalize_text(token)
        if n in _ELASTIC_FORM_STOPWORDS:
            continue
        if len(cleaned) > 1 and n in _ELASTIC_BRAND_STOPWORDS:
            continue
        preferred.append(token)

    if not preferred:
        preferred = cleaned

    # Prefer the most distinctive token. This improves cases such as
    # "Rilastil Xerolact" while still allowing single-token queries.
    best = max(preferred, key=lambda t: (len(normalize_text(t)), len(t)))
    if normalize_text(best) == original_norm:
        return ""
    return best[:80]


def _row_to_dict(row: Any) -> Dict[str, Any]:
    if not row:
        return {}
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _safe_table_columns(conn: Any, table: str) -> set[str]:
    try:
        return set(database.table_columns(conn, table))
    except Exception:
        return set()


def _safe_table_exists(conn: Any, table: str) -> bool:
    try:
        return bool(database.table_exists(conn, table))
    except Exception:
        return False


def _elastic_product_display_name(product: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key in ["name", "canonical_display_name", "original_name", "brand", "product_family", "form", "strength", "size", "pack"]:
        value = str(product.get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    return " ".join(parts).strip()


def _db_partial_product_candidates(query: str, limit: int = 8) -> List[Dict[str, Any]]:
    """Safe final fallback candidate retrieval.

    This function never returns a final match and never shows a price directly.
    It only returns visible product candidates from DB partial/fuzzy text lookup.
    The user must confirm by choosing from the returned list, or the result must
    already have been verified by semantic_matcher before reaching this stage.
    """
    q = _clean_image_identity_piece(query)
    if not q or len(normalize_text(q)) < 3:
        return []

    search_terms = [q]
    for token in sorted(_elastic_tokens(q), key=lambda x: len(normalize_text(x)), reverse=True):
        n = normalize_text(token)
        if len(n) >= 3 and token not in search_terms:
            search_terms.append(token)

    found_ids: List[int] = []
    try:
        with database.connect() as conn:
            product_cols = _safe_table_columns(conn, "products")
            search_cols = [c for c in ["name", "normalized_name", "product_family", "aliases", "original_name", "brand"] if c in product_cols]
            if not search_cols:
                return []

            select_cols = [c for c in ["id", "name", "price", "search_mode", "review_status", "quality_status", "product_family", "aliases", "original_name", "brand", "form", "strength", "size", "pack"] if c in product_cols]
            if "id" not in select_cols:
                return []

            for term in search_terms[:5]:
                pattern = f"%{term}%"
                prefix = f"{term}%"
                where = " OR ".join([f"LOWER(CAST({col} AS TEXT)) LIKE LOWER(?)" for col in search_cols])
                order = "CASE WHEN LOWER(CAST(name AS TEXT)) = LOWER(?) THEN 0 WHEN LOWER(CAST(name AS TEXT)) LIKE LOWER(?) THEN 1 ELSE 2 END, LENGTH(CAST(name AS TEXT)) ASC"
                sql = f"SELECT {', '.join(select_cols)} FROM products WHERE ({where}) ORDER BY {order} LIMIT ?"
                params = tuple([pattern] * len(search_cols) + [term, prefix, int(limit)])
                for row in conn.execute(sql, params).fetchall():
                    d = _row_to_dict(row)
                    pid = int(d.get("id") or 0)
                    if pid and pid not in found_ids:
                        found_ids.append(pid)

                if _safe_table_exists(conn, "product_aliases"):
                    alias_cols = _safe_table_columns(conn, "product_aliases")
                    id_col = "product_db_id" if "product_db_id" in alias_cols else ("product_id" if "product_id" in alias_cols else "")
                    alias_search_cols = [c for c in ["alias_text", "alias", "cleaned_alias", "normalized_alias", "alias_normalized"] if c in alias_cols]
                    if id_col and alias_search_cols:
                        where_alias = " OR ".join([f"LOWER(CAST(pa.{col} AS TEXT)) LIKE LOWER(?)" for col in alias_search_cols])
                        sql_alias = f"""
                            SELECT p.id
                            FROM product_aliases pa
                            JOIN products p ON p.id = pa.{id_col}
                            WHERE ({where_alias})
                            ORDER BY LENGTH(CAST(p.name AS TEXT)) ASC
                            LIMIT ?
                        """
                        params_alias = tuple([pattern] * len(alias_search_cols) + [int(limit)])
                        for row in conn.execute(sql_alias, params_alias).fetchall():
                            d = _row_to_dict(row)
                            pid = int(d.get("id") or 0)
                            if pid and pid not in found_ids:
                                found_ids.append(pid)

                if len(found_ids) >= limit:
                    break
    except Exception as exc:
        log("ELASTIC_DB_PARTIAL_ERROR", query=q[:120], error=repr(exc))
        return []

    out: List[Dict[str, Any]] = []
    for pid in found_ids[:limit]:
        product = database.get_product(pid)
        if product and database.product_visible(product, guided=False):
            out.append(product)
    return out


def _db_partial_product_lookup(query: str, limit: int = 8) -> Optional[Dict[str, Any]]:
    candidates = _db_partial_product_candidates(query, limit=limit)
    return candidates[0] if candidates else None


def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET or not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


def _transient_http_status(status_code: int) -> bool:
    return int(status_code or 0) in {408, 409, 425, 429, 500, 502, 503, 504}


async def send_whatsapp_message(to_number: str, content: Any) -> bool:
    if not content:
        return False
    if isinstance(content, list):
        ok = True
        for item in content:
            ok = (await send_whatsapp_message(to_number, item)) and ok
        return ok
    if isinstance(content, dict) and "__wa_payload" in content:
        payload = copy.deepcopy(content["__wa_payload"])
        payload["messaging_product"] = "whatsapp"
        payload["to"] = to_number
    else:
        payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": str(content or "")[:3900]}}
    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number)
        return True
    assert http_client is not None
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    delay = 0.4
    max_attempts = int(os.getenv("PRICEBOT_WHATSAPP_SEND_RETRY_ATTEMPTS", "3") or 3)
    for attempt in range(1, max_attempts + 1):
        try:
            resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
            if resp.status_code < 400:
                metric_inc("whatsapp_send_success_total")
                return True
            log("SEND_ERROR", attempt=attempt, status=resp.status_code, transient=_transient_http_status(resp.status_code), response=resp.text[:500])
            if not _transient_http_status(resp.status_code):
                metric_inc("whatsapp_send_failed_total")
                return False
        except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError) as exc:
            log("SEND_TRANSIENT_EXCEPTION", attempt=attempt, error=repr(exc))
        except Exception as exc:
            log("SEND_EXCEPTION", attempt=attempt, error=repr(exc))
            metric_inc("whatsapp_send_failed_total")
            return False
        if attempt < max_attempts:
            await asyncio.sleep(delay)
            delay = min(delay * 2, 5.0)
    metric_inc("whatsapp_send_failed_total")
    return False


def _valid_whatsapp_media_id(media_id: str) -> bool:
    value = str(media_id or "").strip()
    return bool(6 <= len(value) <= 256 and re.fullmatch(r"[A-Za-z0-9_.:-]+", value))


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not _valid_whatsapp_media_id(media_id):
        log("MEDIA_ID_REJECTED", media_id="invalid")
        return b"", "image/jpeg"
    if not META_TOKEN:
        return b"", "image/jpeg"
    assert http_client is not None
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    max_attempts = int(os.getenv("PRICEBOT_MEDIA_DOWNLOAD_RETRY_ATTEMPTS", "3") or 3)
    delay = 0.4
    last_mime = "image/jpeg"
    for attempt in range(1, max_attempts + 1):
        try:
            meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
            if meta.status_code >= 400:
                log("MEDIA_META_ERROR", attempt=attempt, status=meta.status_code, transient=_transient_http_status(meta.status_code))
                if not _transient_http_status(meta.status_code):
                    meta.raise_for_status()
                raise httpx.HTTPStatusError("transient media metadata status", request=meta.request, response=meta)
            info = meta.json()
            url = info.get("url", "")
            last_mime = info.get("mime_type", "image/jpeg") or "image/jpeg"
            if not url:
                return b"", last_mime
            data = await http_client.get(url, headers=headers, timeout=20)
            if data.status_code >= 400:
                log("MEDIA_DATA_ERROR", attempt=attempt, status=data.status_code, transient=_transient_http_status(data.status_code))
                if not _transient_http_status(data.status_code):
                    data.raise_for_status()
                raise httpx.HTTPStatusError("transient media data status", request=data.request, response=data)
            return data.content, last_mime
        except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError, httpx.HTTPStatusError) as exc:
            if attempt >= max_attempts:
                raise
            log("MEDIA_DOWNLOAD_RETRY", attempt=attempt, error=repr(exc))
            await asyncio.sleep(delay)
            delay = min(delay * 2, 5.0)
    return b"", last_mime


def extract_messages(payload: Dict[str, Any]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        br = inter.get("button_reply") or {}
                        text = br.get("id") or br.get("title") or ""
                    elif inter.get("type") == "list_reply":
                        lr = inter.get("list_reply") or {}
                        text = lr.get("id") or lr.get("title") or ""
                elif mtype in {"document", "audio", "video", "sticker"}:
                    text = UNSUPPORTED_MEDIA_TOKEN
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out



async def _set_cosmetic_alt_request(phone: str, query: str, clean_query: str = "", source: str = "text") -> None:
    await state.set_json(f"cosmetic_alt:{phone}", {"query": str(query or "")[:500], "clean_query": str(clean_query or "")[:500], "source": source, "ts": time.time()}, COSMETIC_ALT_TTL)


async def _get_cosmetic_alt_request(phone: str) -> Optional[Dict[str, Any]]:
    return await state.get_json(f"cosmetic_alt:{phone}")


async def _clear_cosmetic_alt_request(phone: str) -> None:
    await state.delete(f"cosmetic_alt:{phone}")


def _cosmetic_alt_offer_payload() -> Dict[str, Any]:
    return _wa_buttons(
        "غير متوفر حاليًا في الصيدلية.\nهل تريد بدائل تجميلية قريبة بنفس النوع/المادة من شركات أخرى؟",
        [(BTN_COSMETIC_ALT_YES, "نعم بدائل"), (BTN_COSMETIC_ALT_NO, "لا")],
    )


async def _build_cosmetic_alternative_reply(phone: str, query: str) -> Any:
    if not cosmetic_alternatives.is_cosmetic_request(query):
        return _wa_buttons("لا أقدر أقترح بدائل إلا لمنتجات التجميل فقط.", [(BTN_SEARCH_TEXT, "بحث جديد"), (BTN_SEARCH_IMAGE, "بحث بصورة")])
    pool, features = cosmetic_alternatives.candidate_pool(query, limit=COSMETIC_ALT_CANDIDATES)
    if not pool:
        log("COSMETIC_ALT_NO_POOL", phone=phone, query=str(query)[:120], features={k: list(v) if isinstance(v, set) else v for k, v in features.items()})
        return _wa_buttons("لم أجد بدائل تجميلية مطابقة متوفرة حاليًا.", [(BTN_SEARCH_TEXT, "بحث جديد"), (BTN_SEARCH_IMAGE, "بحث بصورة")])
    try:
        async with cosmetic_alt_semaphore:
            ids = await cosmetic_alternatives.gemini_select_alternatives(query, pool, client=http_client, max_results=COSMETIC_ALT_MAX_RESULTS, timeout=COSMETIC_ALT_TIMEOUT)
        selected = cosmetic_alternatives.postfilter_selected(query, pool, ids, max_results=COSMETIC_ALT_MAX_RESULTS)
    except Exception as exc:
        metric_inc("cosmetic_alt_failed_total")
        log("COSMETIC_ALT_ERROR", phone=phone, error=repr(exc), query=str(query)[:120])
        selected = []
    if not selected:
        metric_inc("cosmetic_alt_failed_total")
        log("COSMETIC_ALT_NONE_SELECTED", phone=phone, query=str(query)[:120], pool=len(pool))
        return _wa_buttons("لم أجد بدائل مطابقة بشكل آمن. اكتب اسم المادة/النوع بشكل أدق لو تريد بحث جديد.", [(BTN_SEARCH_TEXT, "بحث جديد"), (BTN_SEARCH_IMAGE, "بحث بصورة")])
    metric_inc("cosmetic_alt_generated_total")
    log("COSMETIC_ALT_GENERATED", phone=phone, query=str(query)[:120], selected=[int(p.get("id") or 0) for p in selected], pool=len(pool))
    return _cosmetic_alt_lists(selected)


async def _handle_cosmetic_alt_choice(phone: str, raw: str) -> Optional[Any]:
    value = normalize_text(str(raw or ""))
    if value not in {normalize_text(BTN_COSMETIC_ALT_YES), normalize_text(BTN_COSMETIC_ALT_NO), "نعم بدائل", "لا"}:
        return None
    pending = await _get_cosmetic_alt_request(phone)
    if value in {normalize_text(BTN_COSMETIC_ALT_NO), "لا"}:
        await _clear_cosmetic_alt_request(phone)
        await state.set_mode(phone, "awaiting_text")
        return _ask_text()
    await _clear_cosmetic_alt_request(phone)
    if not pending:
        return _ask_text()
    return await _build_cosmetic_alternative_reply(phone, str(pending.get("query") or pending.get("clean_query") or ""))


async def _send_image_queue_notice(phone: str, *, rejected: bool, qsize: int) -> None:
    if not phone:
        return
    suffix = f"notice:image_busy:{phone}"
    try:
        existing = await state.get_json(suffix)
        if existing:
            return
        await state.set_json(suffix, {"ts": time.time(), "qsize": int(qsize), "rejected": bool(rejected)}, IMAGE_QUEUE_NOTICE_TTL)
    except Exception:
        # If Redis is temporarily unavailable, still avoid failing webhook processing.
        pass
    try:
        await send_whatsapp_message(phone, IMAGE_OVERLOAD_MESSAGE if rejected else IMAGE_QUEUE_WAIT_MESSAGE)
    except Exception as exc:
        log("IMAGE_QUEUE_NOTICE_SEND_WARNING", phone=phone, error=repr(exc), rejected=rejected, qsize=qsize)


async def _handle_confirmation(phone: str, raw: str) -> Optional[Any]:
    pending = await state.get_confirmation(phone)
    if not pending:
        return None
    if _is_no(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "awaiting_text")
        log("SEMANTIC_CONFIRM_REJECTED", phone=phone, product_id=pending.get("product_id"), query=str(pending.get("query") or "")[:120])
        return _ask_text()
    if not _is_yes(raw):
        return None
    product = database.get_product(int(pending.get("product_id") or 0))
    await state.clear_confirmation(phone)
    await state.set_mode(phone, "awaiting_text")
    if not product or not database.product_visible(product, guided=False):
        return _unavailable()
    query = str(pending.get("query") or "")
    try:
        await semantic_matcher.remember_confirmation(query, int(product.get("id") or 0), float(pending.get("confidence") or 1.0))
    except Exception as exc:
        log("SEMANTIC_MEMORY_SAVE_WARNING", error=repr(exc), product_id=product.get("id"), query=query[:120])
    try:
        image_hash = str(pending.get("image_hash") or "")
        media_id = str(pending.get("media_id") or "")
        if image_hash or media_id:
            database.set_image_cache(image_hash, media_id, pending.get("extracted") or {}, int(product.get("id") or 0), "V10_SEMANTIC_CONFIRMED", str(pending.get("confidence") or ""))
    except Exception as exc:
        log("IMAGE_CACHE_SAVE_WARNING", error=repr(exc))
    return _product_reply(product)


async def _confirm_candidate(phone: str, product: Dict[str, Any], query: str, source: str, image_hash: str = "", media_id: str = "", extracted: Optional[Dict[str, Any]] = None, confidence: float = 0.0) -> Any:
    await state.set_confirmation(phone, {"product_id": int(product.get("id") or 0), "query": str(query or "")[:1000], "source": source, "image_hash": image_hash, "media_id": media_id, "extracted": extracted or {}, "confidence": float(confidence or 0.0)})
    return _confirm_payload(product)


async def process_text(phone: str, raw: str) -> Any:
    raw = str(raw or "").strip()
    if raw == UNSUPPORTED_MEDIA_TOKEN:
        return _prescription_payload()
    confirmation_reply = await _handle_confirmation(phone, raw)
    if confirmation_reply is not None:
        return confirmation_reply
    cosmetic_alt_reply = await _handle_cosmetic_alt_choice(phone, raw)
    if cosmetic_alt_reply is not None:
        return cosmetic_alt_reply
    if raw.startswith("PROD:"):
        try:
            pid = int(raw.split(":", 1)[1])
        except Exception:
            pid = 0
        product = database.get_product(pid) if pid else None
        if product and database.product_visible(product, guided=False):
            await state.set_mode(phone, "awaiting_text")
            return _product_reply(product)
        return _unavailable()
    if raw in {"MENU", "القائمة", "القائمه"} or _is_menu(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "idle")
        return _welcome_menu()
    if _is_text_button(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "awaiting_text")
        return _ask_text()
    if _is_image_button(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "awaiting_image")
        return _ask_image()
    await state.set_mode(phone, "awaiting_text")
    if looks_like_prescription(raw):
        return _prescription_payload()

    async def handle_text_decision(dec, query: str, stage: str) -> Optional[Any]:
        if dec.action == "direct" and dec.product:
            await state.set_mode(phone, "awaiting_text")
            log("TEXT_SEMANTIC_DIRECT", phone=phone, product_id=dec.product_id, confidence=round(dec.confidence, 6), similarity=round(dec.similarity, 6), source=dec.source, query=query[:120], stage=stage)
            return _product_reply(dec.product)
        if dec.action == "confirm" and dec.product:
            await state.set_mode(phone, "awaiting_text")
            log("TEXT_SEMANTIC_CONFIRM", phone=phone, product_id=dec.product_id, confidence=round(dec.confidence, 6), similarity=round(dec.similarity, 6), source=dec.source, query=query[:120], stage=stage, candidates=len(dec.candidates or []))
            if len(dec.candidates or []) > 1:
                return _product_lists((dec.candidates or [])[:MAX_LIST_ROWS])
            return await _confirm_candidate(phone, dec.product, query, dec.source or "semantic_confirm", confidence=dec.confidence)
        return None

    # V16: deterministic Product Identity Router.
    # No Gemini text verification and no embedding search for text messages.
    decision = product_identity_router.route_product_query(raw, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES, source_context="text")
    resolved = await handle_text_decision(decision, raw, "v16_product_identity_router")
    if resolved is not None:
        return resolved

    log("TEXT_V16_ROUTER_UNAVAILABLE", phone=phone, reason=decision.reason, confidence=round(decision.confidence, 6), query=raw[:120], clean_query=decision.query_text[:120])
    if cosmetic_alternatives.is_cosmetic_request(raw):
        await _set_cosmetic_alt_request(phone, raw, decision.query_text, "text")
        metric_inc("cosmetic_alt_offered_total")
        log("COSMETIC_ALT_OFFERED", phone=phone, query=raw[:120], clean_query=decision.query_text[:120], source="text")
        return _cosmetic_alt_offer_payload()
    return _unavailable()


async def process_image(phone: str, media_id: str) -> Any:
    await state.set_mode(phone, "awaiting_text")
    if not media_id:
        return _prescription_payload()
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return _prescription_payload()
    if not image_bytes:
        return _prescription_payload()
    image_hash = hashlib.sha256(image_bytes).hexdigest()
    vision_cache_key = state.key(f"vision:{image_hash}")
    extracted: Optional[Dict[str, Any]] = None

    # V14 Vision cache: prevents repeated Gemini Vision calls for the same image.
    try:
        if await state.ensure_redis():
            assert state.redis is not None
            cached = await state.redis.get(vision_cache_key)
            if cached:
                cached_data = json.loads(cached)
                if isinstance(cached_data, dict):
                    extracted = cached_data
                    log("VISION_CACHE_HIT", phone=phone, image_hash=image_hash[:16])
    except Exception as exc:
        log("VISION_CACHE_READ_WARNING", error=repr(exc))
        extracted = None

    if extracted is None:
        try:
            async with image_semaphore:
                extracted = await asyncio.wait_for(vision_service.extract_product_from_image(image_bytes, mime), timeout=IMAGE_TOTAL_TIMEOUT)
        except asyncio.TimeoutError:
            return _prescription_payload()
        except Exception as exc:
            log("VISION_ERROR", error=repr(exc))
            return _prescription_payload()
        try:
            if await state.ensure_redis():
                assert state.redis is not None
                await state.redis.set(vision_cache_key, json.dumps(extracted, ensure_ascii=False, separators=(",", ":")), ex=3600)
                log("VISION_CACHE_SET", phone=phone, image_hash=image_hash[:16])
        except Exception as exc:
            log("VISION_CACHE_WRITE_WARNING", error=repr(exc))
    evidence = _image_evidence_text(extracted)
    status = str(extracted.get("status") or "")
    if not evidence:
        if status == "LOW_CONFIDENCE":
            return _wa_buttons(str(extracted.get("message") or "الصورة غير واضحة. أرسل صورة للعلبة كاملة أو اكتب الاسم.")[:1000], [(BTN_SEARCH_IMAGE, "بحث بصورة"), (BTN_SEARCH_TEXT, "بحث بالاسم")])
        return _prescription_payload()
    if looks_like_prescription(evidence):
        return _prescription_payload()
    if status not in {"OK", "LOW_CONFIDENCE"} and not evidence:
        return _prescription_payload()
    log(
        "VISION_EXTRACTED",
        phone=phone,
        product_identity=str(extracted.get("product_identity") or "")[:120],
        primary_name=str(extracted.get("primary_name") or extracted.get("primary_title") or extracted.get("product_name") or "")[:80],
        query=evidence[:120],
        confidence=str(extracted.get("confidence") or "")[:20],
    )
    log("IMAGE_EVIDENCE", phone=phone, text=evidence[:160])

    # V16: Vision extracts text only; deterministic router performs product matching.
    decision = product_identity_router.route_product_query(evidence, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES, source_context="image")

    async def handle_image_decision(dec, query: str, *, retry: bool = False) -> Optional[Any]:
        if dec.action == "direct" and dec.product:
            if not _image_match_crosscheck(dec.product, extracted or {}):
                log("IMAGE_CROSSCHECK_REJECTED", phone=phone, product_id=dec.product_id, product=product_name(dec.product)[:120], query=query[:120])
                return _image_uncertain_reply()
            try:
                database.set_image_cache(image_hash, media_id, extracted or {}, int(dec.product_id or 0), "V16_IMAGE_IDENTITY_ROUTER_VERIFIED", str(dec.confidence or ""))
            except Exception as exc:
                log("IMAGE_CACHE_SAVE_WARNING", error=repr(exc))
            log("IMAGE_SEMANTIC_DIRECT", phone=phone, product_id=dec.product_id, confidence=round(dec.confidence, 6), similarity=round(dec.similarity, 6), source=dec.source, query=query[:120], retry=retry)
            return _product_reply(dec.product)
        if dec.action == "confirm" and dec.product:
            if not _image_match_crosscheck(dec.product, extracted or {}):
                log("IMAGE_CROSSCHECK_REJECTED", phone=phone, product_id=dec.product_id, product=product_name(dec.product)[:120], query=query[:120])
                return _image_uncertain_reply()
            safe_image_candidates = _filter_image_candidates(dec.candidates or [dec.product], extracted or {})
            log("IMAGE_SEMANTIC_CONFIRM", phone=phone, product_id=dec.product_id, confidence=round(dec.confidence, 6), similarity=round(dec.similarity, 6), source=dec.source, query=query[:120], retry=retry, candidates=len(dec.candidates or []), safe_candidates=len(safe_image_candidates))
            if len(safe_image_candidates) > 1:
                return _product_lists(safe_image_candidates[:MAX_LIST_ROWS])
            if len(safe_image_candidates) == 1:
                return await _confirm_candidate(phone, safe_image_candidates[0], query, dec.source or "image_semantic_confirm", image_hash=image_hash, media_id=media_id, extracted=extracted, confidence=dec.confidence)
            log("IMAGE_CANDIDATES_FILTERED_OUT", phone=phone, query=query[:120], product_id=dec.product_id)
            return _image_uncertain_reply()
        return None

    resolved = await handle_image_decision(decision, evidence, retry=False)
    if resolved is not None:
        return resolved

    # V15: no raw DB/semantic fallback for images. If Vision+Gemini cannot agree, ask for a clearer image/text.
    log("IMAGE_V16_ROUTER_UNAVAILABLE", phone=phone, reason=decision.reason, confidence=round(decision.confidence, 6), query=evidence[:120], clean_query=decision.query_text[:120])
    if cosmetic_alternatives.is_cosmetic_request(evidence):
        await _set_cosmetic_alt_request(phone, evidence, decision.query_text, "image")
        metric_inc("cosmetic_alt_offered_total")
        log("COSMETIC_ALT_OFFERED", phone=phone, query=evidence[:120], clean_query=decision.query_text[:120], source="image")
        return _cosmetic_alt_offer_payload()
    return _image_uncertain_reply()


async def worker(worker_id: int, worker_queue: asyncio.Queue, queue_name: str) -> None:
    while True:
        item = await worker_queue.get()
        try:
            phone = item.get("phone", "")
            message_id = item.get("id", "")
            request_id = item.get("request_id", "")
            enqueued_at = float(item.get("enqueued_at") or time.time())
            age = time.time() - enqueued_at
            if age > QUEUE_ITEM_TIMEOUT:
                metric_inc("messages_expired_total")
                log("QUEUE_ITEM_EXPIRED", request_id=request_id, message_id=message_id, queue=queue_name, age_seconds=round(age, 2), phone=phone)
                if message_id:
                    try:
                        database.mark_processed(message_id)
                    except Exception:
                        pass
                await send_whatsapp_message(phone, CUSTOMER_BUSY_MESSAGE)
                continue

            is_image = bool(item.get("type") == "image" or item.get("media_id"))
            limiter = image_limiter if is_image else text_limiter
            limit = RATE_LIMIT_IMAGES if is_image else RATE_LIMIT_MESSAGES
            if not await limiter.allow(phone, limit):
                log("USER_RATE_LIMITED", request_id=request_id, message_id=message_id, phone=phone, type=item.get("type"))
                await send_whatsapp_message(phone, "طلبات كثيرة بسرعة. حاول بعد قليل.")
                continue
            if message_id and not database.mark_processed(message_id):
                log("DUPLICATE_MESSAGE_SKIPPED", request_id=request_id, message_id=message_id, phone=phone)
                continue
            async with state.user_lock(phone):
                if is_image:
                    reply = await process_image(phone, item.get("media_id", ""))
                else:
                    log("MESSAGE_RECEIVED", request_id=request_id, message_id=message_id, phone=phone, text=str(item.get("text", ""))[:100])
                    reply = await process_text(phone, item.get("text", ""))
                await send_whatsapp_message(phone, reply)
                metric_inc("messages_processed_total")
        except Exception as exc:
            metric_inc("messages_failed_total")
            log("WORKER_ERROR", worker=f"{queue_name}-{worker_id}", error=repr(exc), item_type=item.get("type"), request_id=item.get("request_id"), message_id=item.get("id"))
            try:
                await send_whatsapp_message(item.get("phone", ""), "حدث خطأ مؤقت. حاول مرة أخرى.")
            except Exception:
                pass
        finally:
            worker_queue.task_done()


async def periodic_cleanup() -> None:
    while True:
        try:
            text_limiter.cleanup()
            image_limiter.cleanup()
            global_limiter.cleanup()
            await state.cleanup_memory()
        except Exception as exc:
            log("PERIODIC_CLEANUP_WARNING", error=repr(exc))
        await asyncio.sleep(300)


async def periodic_semantic_maintenance() -> None:
    while True:
        try:
            database.invalidate_runtime_caches()
            if os.getenv("PRICEBOT_SEMANTIC_PERIODIC_INDEX", "0").strip().lower() in {"1", "true", "yes", "on"}:
                await semantic_matcher.rebuild_missing_embeddings(limit=int(os.getenv("PRICEBOT_SEMANTIC_PERIODIC_INDEX_LIMIT", "500") or 500))
        except Exception as exc:
            log("SEMANTIC_MAINTENANCE_WARNING", error=repr(exc))
        await asyncio.sleep(max(300, PRODUCT_INDEX_TTL))


@app.on_event("startup")
async def startup() -> None:
    global http_client, STARTUP_WARNINGS
    STARTUP_WARNINGS = startup_validation_warnings()
    for warning in STARTUP_WARNINGS:
        log("STARTUP_CONFIG_WARNING", warning=warning)
    semantic_matcher.set_logger(log)
    if database.IS_POSTGRES:
        with database.connect() as startup_lock_conn:
            startup_lock_conn.execute("SELECT pg_advisory_lock(809015)")
            try:
                database.init_db(run_production_guard=True)
                try:
                    log("DB_PERFORMANCE_HARDENING", **database.apply_performance_hardening())
                except Exception as exc:
                    log("DB_PERFORMANCE_HARDENING_WARNING", error=repr(exc))
                try:
                    log("FINAL_SCHEMA", **database.ensure_final_hardening_schema())
                except Exception as exc:
                    log("FINAL_SCHEMA_WARNING", error=repr(exc))
                try:
                    log("RUNTIME_CLEANUP", **database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30)))
                except Exception as exc:
                    log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
                await semantic_matcher.initialize(auto_index=False)
            finally:
                startup_lock_conn.execute("SELECT pg_advisory_unlock(809015)")
    else:
        database.init_db(run_production_guard=True)
        try:
            log("DB_PERFORMANCE_HARDENING", **database.apply_performance_hardening())
        except Exception as exc:
            log("DB_PERFORMANCE_HARDENING_WARNING", error=repr(exc))
        try:
            log("FINAL_SCHEMA", **database.ensure_final_hardening_schema())
        except Exception as exc:
            log("FINAL_SCHEMA_WARNING", error=repr(exc))
        try:
            log("RUNTIME_CLEANUP", **database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30)))
        except Exception as exc:
            log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
        await semantic_matcher.initialize(auto_index=False)
    await state.connect()
    limits = httpx.Limits(max_keepalive_connections=int(os.getenv("PRICEBOT_HTTP_KEEPALIVE", "60") or 60), max_connections=int(os.getenv("PRICEBOT_HTTP_MAX_CONNECTIONS", "160") or 160))
    http_client = httpx.AsyncClient(limits=limits, timeout=20)
    for i in range(TEXT_WORKERS):
        background_tasks.append(asyncio.create_task(worker(i + 1, text_queue, "text")))
    for i in range(IMAGE_WORKERS):
        background_tasks.append(asyncio.create_task(worker(i + 1, image_queue, "image")))
    background_tasks.append(asyncio.create_task(periodic_cleanup()))
    background_tasks.append(asyncio.create_task(periodic_semantic_maintenance()))
    log("PRICEBOT_V16_4_STARTED", version=FINAL_UI_VERSION, matcher="v16_product_identity_router", semantic=semantic_matcher.health(), product_router=product_identity_router.health(), cosmetic_alternatives=cosmetic_alternatives.health(), redis_state_enabled=state.enabled, redis_required=state.redis_required, text_workers=TEXT_WORKERS, image_workers=IMAGE_WORKERS, gemini_text="disabled", vision="enabled" if config_env.vision_enabled() else config_env.vision_disabled_reason())


@app.on_event("shutdown")
async def shutdown() -> None:
    try:
        await asyncio.wait_for(asyncio.gather(text_queue.join(), image_queue.join()), timeout=SHUTDOWN_DRAIN_TIMEOUT)
        log("SHUTDOWN_QUEUE_DRAINED")
    except asyncio.TimeoutError:
        log("SHUTDOWN_DRAIN_TIMEOUT", text_queue_size=text_queue.qsize(), image_queue_size=image_queue.qsize())
    for task in background_tasks:
        task.cancel()
    if background_tasks:
        await asyncio.gather(*background_tasks, return_exceptions=True)
    if http_client:
        await http_client.aclose()
    await state.close()
    try:
        database.close_database_pool()
    except Exception as exc:
        log("DB_POOL_CLOSE_WARNING", error=repr(exc))


def startup_validation_warnings() -> List[str]:
    warnings: List[str] = []
    if not META_TOKEN:
        warnings.append("WHATSAPP_ACCESS_TOKEN_missing")
    if not PHONE_ID:
        warnings.append("WHATSAPP_PHONE_NUMBER_ID_missing")
    if not config_env.resolve_openrouter_api_key():
        warnings.append("OPENROUTER_API_KEY_missing_for_vision_only")
    if not os.getenv("REDIS_URL", "").strip():
        warnings.append("REDIS_URL_missing_cache_and_state_will_not_scale")
    try:
        db_info = database.database_engine_info()
        if db_info.get("engine") != "postgres" and str(os.getenv("PRICEBOT_REQUIRE_POSTGRES_PRODUCTION", "")).lower() in {"1", "true", "yes", "on"}:
            warnings.append("postgres_required_but_not_enabled")
        elif db_info.get("engine") != "postgres":
            warnings.append("sqlite_mode_postgres_recommended_for_final_production")
    except Exception as exc:
        warnings.append("database_engine_check_failed")
    if REQUIRE_SIGNATURE and not META_APP_SECRET:
        warnings.append("signature_required_but_META_APP_SECRET_missing")
    if not REQUIRE_SIGNATURE:
        warnings.append("meta_signature_not_required")
    return warnings


def _security_warnings() -> List[str]:
    warnings: List[str] = []
    if not META_APP_SECRET:
        warnings.append("META_APP_SECRET_missing")
    if not REQUIRE_SIGNATURE:
        warnings.append("PRICEBOT_REQUIRE_META_SIGNATURE_false")
    if REQUIRE_SIGNATURE and not META_APP_SECRET:
        warnings.append("signature_required_but_secret_missing")
    return warnings


@app.get("/health")
async def health() -> Dict[str, Any]:
    redis_health = state.health()
    warnings = _security_warnings()
    if state.redis_required and not state.enabled:
        warnings.append("redis_required_but_unavailable")
    semantic_health = semantic_matcher.health()
    return {
        "ok": bool(not (state.redis_required and not state.enabled) and database.count_products() > 0),
        "service": "pricebot-whatsapp-only",
        "matcher": "v16_product_identity_router",
        "semantic_matcher": semantic_health,
        "products_count": database.count_products(),
        "text_queue_size": text_queue.qsize(),
        "image_queue_size": image_queue.qsize(),
        "text_queue_maxsize": TEXT_QUEUE_MAXSIZE,
        "image_queue_maxsize": IMAGE_QUEUE_MAXSIZE,
        "queue_item_timeout_seconds": QUEUE_ITEM_TIMEOUT,
        "workers": TEXT_WORKERS + IMAGE_WORKERS,
        "text_workers": TEXT_WORKERS,
        "image_workers": IMAGE_WORKERS,
        "gemini_configured": bool(config_env.resolve_openrouter_api_key()),
        "gemini_text_enabled": False,
        "text_embeddings_enabled": False,
        "product_identity_router": product_identity_router.health(),
        "cosmetic_alternatives": cosmetic_alternatives.health(),
        "overload_protection": {"image_queue_warn_at": IMAGE_QUEUE_WARN_AT, "image_queue_reject_at": IMAGE_QUEUE_REJECT_AT, "image_queue_notice_ttl": IMAGE_QUEUE_NOTICE_TTL, "cosmetic_alt_concurrency": COSMETIC_ALT_CONCURRENCY},
        "vision_enabled": config_env.vision_enabled(),
        "whatsapp_token_configured": bool(META_TOKEN),
        "whatsapp_phone_id_configured": bool(PHONE_ID),
        "webhook_signature_required": bool(REQUIRE_SIGNATURE),
        "meta_app_secret_configured": bool(META_APP_SECRET),
        "security_warnings": warnings,
        "web_pages_enabled": False,
        "final_ui_enabled": True,
        "final_ui_version": FINAL_UI_VERSION,
        "uptime_seconds": round(time.time() - STARTED_AT, 2),
        "startup_warnings": STARTUP_WARNINGS,
        "runtime_metrics": dict(RUNTIME_METRICS),
        "semantic_memory_enabled": bool(getattr(semantic_matcher, "enable_memory_decisions", False)),
        "pgvector_enabled": bool(semantic_health.get("schema_ready")),
        "redis_state_enabled": bool(state.enabled),
        "redis": redis_health,
        "rate_limiters": {
            "global": global_limiter.health(),
            "text": text_limiter.health(),
            "image": image_limiter.health(),
        },
        "send_retry": f"{int(os.getenv('PRICEBOT_WHATSAPP_SEND_RETRY_ATTEMPTS', '3') or 3)}_attempts_transient_exponential_backoff",
        "media_download_retry": f"{int(os.getenv('PRICEBOT_MEDIA_DOWNLOAD_RETRY_ATTEMPTS', '3') or 3)}_attempts_transient_exponential_backoff",
        "vision_retry": f"{int(os.getenv('PRICEBOT_VISION_RETRY_ATTEMPTS', '3') or 3)}_attempts_transient_only",
        "queue_safety_enabled": True,
        "redis_rate_limit_enabled": True,
        "graceful_shutdown_enabled": True,
        "customer_ocr_leak_protection": True,
        "v10_semantic_gemini_core": True,
        "v13_lite_hybrid_safe_confirm": True,
        "v14_safe_decision_layer": True,
        "v15_gemini_router_clean": True,
        "v15_1_deterministic_family_router": True,
        "v16_product_identity_router": True,
        "v16_1_overload_cosmetic_alternatives": True,
        "v16_2_vision_redis_stability": True,
        "v16_4_image_product_line_strict": True,
        "v16_4_image_product_line_strict": True,
        "v11_image_identity_retry": True,
        "internal_reload_index_enabled": bool(os.getenv("PRICEBOT_INTERNAL_RELOAD_TOKEN", "").strip()),
        "database_engine": database.database_engine_info(),
        "runtime_cache": database.runtime_cache_stats(),
    }


@app.get("/")
def root() -> Dict[str, Any]:
    return {"ok": True, "service": "pricebot-whatsapp-v16-1-overload-cosmetic-alternatives", "webhook": "/webhook", "web_pages_enabled": False, "final_ui_version": FINAL_UI_VERSION, "matcher": "v16_1_overload_cosmetic_alternatives"}




@app.post("/internal/reload-index")
async def internal_reload_index(request: Request) -> JSONResponse:
    """Internal-only V10 semantic embedding rebuild endpoint.

    Use after importing/updating products. Protect it with PRICEBOT_INTERNAL_RELOAD_TOKEN.
    It fills missing pgvector embeddings and returns semantic matcher health.
    """
    token = os.getenv("PRICEBOT_INTERNAL_RELOAD_TOKEN", "").strip()
    supplied = request.headers.get("x-pricebot-token", "") or request.query_params.get("token", "")
    if not token or not hmac.compare_digest(str(supplied), token):
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=403)
    request_id = hashlib.sha256(f"reload:{time.time()}".encode()).hexdigest()[:16]
    try:
        database.invalidate_runtime_caches()
        result = await semantic_matcher.rebuild_missing_embeddings(limit=int(os.getenv("PRICEBOT_SEMANTIC_REBUILD_LIMIT", "10000") or 10000))
        log("INTERNAL_SEMANTIC_INDEX_REBUILT", request_id=request_id, result=result, semantic=semantic_matcher.health())
        return JSONResponse({"ok": True, "request_id": request_id, "semantic": semantic_matcher.health(), "rebuild": result})
    except Exception as exc:
        log("INTERNAL_SEMANTIC_INDEX_REBUILD_FAILED", request_id=request_id, error=repr(exc))
        return JSONResponse({"ok": False, "request_id": request_id, "error": "reload_failed"}, status_code=500)


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    metric_inc("webhooks_total")
    body = await request.body()
    request_id = hashlib.sha1(body + str(time.time()).encode()).hexdigest()[:16]
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        metric_inc("webhooks_bad_signature")
        log("WEBHOOK_BAD_SIGNATURE", request_id=request_id)
        return PlainTextResponse("bad signature", status_code=403)

    if not await global_limiter.allow("global", GLOBAL_RATE_LIMIT_REQUESTS):
        status_code = 503 if (state.redis_required and not state.enabled) else 429
        metric_inc("webhooks_rate_limited")
        log("WEBHOOK_GLOBAL_RATE_LIMIT", request_id=request_id, status_code=status_code, redis_state_enabled=state.enabled)
        return JSONResponse({"ok": False, "error": "rate_limited_or_temporarily_unavailable", "request_id": request_id}, status_code=status_code, headers={"Retry-After": "5"})

    try:
        payload = json.loads(body.decode("utf-8")) if body else {}
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json", "request_id": request_id}, status_code=400)

    queued = 0
    dropped = 0
    messages = extract_messages(payload)
    now = time.time()
    for msg in messages:
        try:
            is_image_msg = bool(msg.get("type") == "image" or msg.get("media_id"))
            queue = image_queue if is_image_msg else text_queue
            msg["request_id"] = request_id
            msg["enqueued_at"] = now
            if is_image_msg:
                qsize = image_queue.qsize()
                if qsize >= IMAGE_QUEUE_REJECT_AT:
                    dropped += 1
                    metric_inc("messages_queue_full_total")
                    metric_inc("image_rejected_overload_total")
                    log("IMAGE_QUEUE_REJECTED_OVERLOAD", request_id=request_id, phone=msg.get("phone"), image_queue_size=qsize, reject_at=IMAGE_QUEUE_REJECT_AT)
                    asyncio.create_task(_send_image_queue_notice(msg.get("phone", ""), rejected=True, qsize=qsize))
                    continue
                if qsize >= IMAGE_QUEUE_WARN_AT:
                    metric_inc("image_backpressure_total")
                    log("IMAGE_QUEUE_BACKPRESSURE", request_id=request_id, phone=msg.get("phone"), image_queue_size=qsize, warn_at=IMAGE_QUEUE_WARN_AT)
                    asyncio.create_task(_send_image_queue_notice(msg.get("phone", ""), rejected=False, qsize=qsize))
            if queue.full():
                raise asyncio.QueueFull
            queue.put_nowait(msg)
            queued += 1
            metric_inc("messages_queued_total")
        except asyncio.QueueFull:
            dropped += 1
            metric_inc("messages_queue_full_total")
            log("QUEUE_FULL", request_id=request_id, phone=msg.get("phone"), type=msg.get("type"), text_queue_size=text_queue.qsize(), image_queue_size=image_queue.qsize())

    if dropped:
        # For overload shedding we notify the customer and ACK Meta to avoid retry storms.
        # If some messages were still queued, report partial busy but keep HTTP 200.
        return JSONResponse({"ok": True, "queued": queued, "busy": dropped, "request_id": request_id, "mode": "whatsapp_only", "overload_protected": True}, status_code=200)

    log("WEBHOOK_QUEUED", request_id=request_id, queued=queued, messages=len(messages), text_queue_size=text_queue.qsize(), image_queue_size=image_queue.qsize())
    return {"ok": True, "queued": queued, "busy": 0, "request_id": request_id, "mode": "whatsapp_only"}
