import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import ui_flow
import conversation_state as cs
import search_engine
import config_env


def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)


def main():
    db_path = os.environ.get("PRICEBOT_DB_PATH") or "/tmp/pricebot_acceptance.sqlite"
    database.configure_db_path(db_path)
    phone = "acceptance_user"
    database.init_db(run_production_guard=False)
    database.clear_state(phone)

    r = ui_flow.handle_text(phone, "مرحبا")
    assert_true("ابدأ الاستخدام" in r or "ابدأ" in r, "greeting_start_button_fallback")
    r = ui_flow.handle_text(phone, "ابدأ")
    assert_true("البحث عن منتج" in r and "تصفح الأقسام" in r, "main_menu")
    r = ui_flow.handle_text(phone, "1")
    assert_true("البحث بالاسم" in r and "البحث بالصورة" in r, "search_submenu")
    r = ui_flow.handle_text(phone, "1")
    assert_true("اكتب اسم المنتج" in r, "name_search_prompt")
    r = ui_flow.handle_text(phone, "gaviscon")
    assert_true("حدد" in r or "اختر" in r or "أكثر" in r, "gaviscon_clarification")
    assert_true(cs.get(phone).get("state") == cs.WAITING_FOR_CLARIFICATION, "state_clarification")
    r = ui_flow.handle_text(phone, "2")
    assert_true("المنتج متوفر" in r and "للحجز" not in r, "product_detail_no_booking")
    r = ui_flow.handle_text(phone, "نعم")
    assert_true("الحجز غير متوفر" in r or "القائمة" in r, "booking_disabled")
    r = ui_flow.handle_text(phone, "القائمة")
    assert_true("اختر خدمة" in r, "menu_reset")
    r = ui_flow.handle_text(phone, "2")
    assert_true("اختر القسم" in r, "browse_categories")
    r = ui_flow.handle_text(phone, "1")
    assert_true("رجوع" in r, "subcategories")
    r = ui_flow.handle_text(phone, "رجوع")
    assert_true("اختر القسم" in r or "اختر خدمة" in r, "back_works")

    for q in ["Pro-D3 50,000 IU", "Ovanice"]:
        result = search_engine.search_product(q)
        assert_true(result.status in {"EXACT_MATCH", "ASK_CLARIFICATION", "PRODUCT_LIST"}, f"search_{q}")
        if result.status == "EXACT_MATCH":
            assert_true(result.product and result.product.get("price"), f"search_price_{q}")

    result = search_engine.search_product("غسول")
    assert_true(result.status == "ASK_CLARIFICATION", "generic_no_random")

    print("ACCEPTANCE_TESTS_PASS=23")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
