"""Guided category browsing for pharmacy products."""
from __future__ import annotations

from typing import Dict, List

import database
import guided_commerce
import orders
from normalizer import normalize_text

MAIN_CATEGORIES = [
    "أدوية",
    "مكملات وفيتامينات",
    "عناية بالبشرة",
    "عناية بالشعر",
    "أطفال",
    "أجهزة ومستلزمات",
    "أخرى",
]

# User-facing labels requested for the new flow.  We map them to the stricter
# guided index sections already built from the Excel catalog.
SUBCATEGORY_LABELS = {
    "أدوية": [
        "مسكنات وخافض حرارة",
        "معدة وقيء",
        "حساسية وزكام",
        "جلدية",
        "نسائية",
        "مضادات حيوية",
        "سكري وضغط وقلب",
        "عيون / أنف / أذن",
        "بحث باسم دواء",
    ],
    "مكملات وفيتامينات": [
        "حديد",
        "فيتامين D",
        "كالسيوم",
        "مغنيسيوم",
        "زنك",
        "فيتامين C",
        "Multivitamin",
        "فيتامينات أطفال",
        "مكملات الحمل",
    ],
    "عناية بالبشرة": [
        "غسول وجه",
        "كريم",
        "سيروم",
        "واقي شمس",
        "مرطب",
        "علاج حب الشباب",
    ],
    "عناية بالشعر": [
        "شامبو",
        "بلسم",
        "زيت / سيروم شعر",
        "قشرة",
        "تساقط",
        "عناية أطفال بالشعر",
    ],
    "أطفال": [
        "حفاضات",
        "شامبو / غسول أطفال",
        "كريمات أطفال",
        "حليب وأغذية",
        "مستلزمات أطفال",
    ],
    "أجهزة ومستلزمات": [
        "قياس ضغط",
        "قياس سكر",
        "ترمومتر",
        "أجهزة تنفس",
        "كمامات ومستلزمات",
        "ضمادات وشاش",
    ],
    "أخرى": ["منتجات أخرى"],
}

SUBCATEGORY_ALIASES = {
    "كريم": "مرطب",
    "علاج حب الشباب": "علاج حبوب",
    "منتجات مميزة": "",
    "منتجات أخرى": "",
}


def _guided_sub(main: str, sub: str) -> str:
    return SUBCATEGORY_ALIASES.get(sub, sub)


def available_main_categories() -> List[str]:
    # Keep the commercial ordering but hide sections with no products.  Offers
    # may be empty because the catalog does not always define featured items.
    visible: List[str] = []
    available = set(guided_commerce.available_main_sections() or [])
    for cat in MAIN_CATEGORIES:
        if cat == "أخرى":
            if database.guided_count("أخرى") > 0 or database.guided_count("عناية شخصية") > 0:
                visible.append(cat)
            continue
        if cat in available or database.guided_count(cat) > 0:
            visible.append(cat)
    return visible or [c for c in MAIN_CATEGORIES if c != "أخرى"]


def available_subcategories(main: str) -> List[str]:
    # Source of truth is the guided index built from Excel category/subcategory.
    # Keep the preferred business ordering from SUBCATEGORY_LABELS, then append
    # any extra subcategories that exist in the pharmacy catalog.
    lookup_main = "عناية شخصية" if main == "أخرى" and database.guided_count("أخرى") == 0 else main
    db_subs = guided_commerce.available_sub_sections(lookup_main)
    preferred = SUBCATEGORY_LABELS.get(main, [])
    out: List[str] = []
    for label in preferred:
        if label in db_subs or label == "بحث باسم دواء":
            out.append(label)
    for label in db_subs:
        if label not in out:
            out.append(label)
    return out


def format_main_categories() -> str:
    cats = available_main_categories()
    lines = ["🗂️ اختر القسم:", ""]
    for i, cat in enumerate(cats, 1):
        lines.append(f"{i}. {cat}")
    lines.append("0. رجوع")
    lines.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(lines)


def format_subcategories(main: str) -> str:
    subs = available_subcategories(main)
    if not subs:
        return "لا توجد منتجات متوفرة في هذا القسم حاليًا.\n0. رجوع"
    lines = [f"{main}:", ""]
    for i, sub in enumerate(subs, 1):
        lines.append(f"{i}. {sub}")
    lines.append("0. رجوع")
    lines.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(lines)


def skin_type_menu() -> str:
    return "اختر نوع البشرة:\n\n1. دهنية\n2. جافة\n3. حساسة\n4. عادية / مختلطة\n5. لا أعرف\n0. رجوع"


def needs_skin_type(main: str, sub: str) -> bool:
    return main == "عناية بالبشرة" and sub in {"غسول وجه", "كريم", "سيروم", "واقي شمس", "مرطب", "علاج حب الشباب"}


def skin_type_from_choice(text: str) -> str:
    return guided_commerce.skin_type_from_choice(text)


def products_for(main: str, sub: str, skin_type: str = "", limit: int = 120) -> List[Dict]:
    guided_sub = _guided_sub(main, sub)
    if sub in {"منتجات مميزة", "منتجات أخرى"}:
        guided_sub = ""
    if main == "أخرى" and database.guided_count("أخرى") == 0:
        main = "عناية شخصية"
    rows = database.guided_products(main, guided_sub, skin_type=skin_type, page=0, page_size=limit)
    safe = [p for p in rows if guided_commerce.product_allowed_in_subsection(p, main, guided_sub or sub, skin_type)]
    # Additional hard filters for the labels requested in the UI.
    if main == "عناية بالبشرة":
        nsub = normalize_text(sub)
        def hay(p: Dict) -> str:
            return normalize_text(" ".join(str(p.get(c) or "") for c in ["name", "product_type", "form", "use_case", "body_area", "age_group", "section", "category", "subcategory", "ocr_keywords"]))
        if "غسول" in nsub:
            safe = [p for p in safe if "shampoo" not in hay(p) and "body wash" not in hay(p) and "baby" not in hay(p)]
        if "سيروم" in nsub:
            safe = [p for p in safe if "serum" in hay(p) or "سيروم" in hay(p)]
        if "شامبو" in nsub:
            safe = []
    if main == "عناية بالشعر":
        safe = [p for p in safe if normalize_text(" ".join(str(p.get(c) or "") for c in ["name", "product_type", "use_case", "section", "subcategory", "ocr_keywords"])).find("skin") == -1]
    return safe[:limit]


def format_product_page(title: str, products: List[Dict], page: int = 0, page_size: int = 10) -> str:
    if not products:
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار.\nاكتب رجوع للعودة."
    start = page * page_size
    chunk = products[start:start + page_size]
    lines = [f"{title} - صفحة {page + 1}", ""]
    for i, product in enumerate(chunk, 1):
        lines.append(orders.format_product_line(i, product))
    lines.append("")
    lines.append("اكتب رقم المنتج للتفاصيل.")
    if start + page_size < len(products):
        lines.append('اكتب "التالي" لعرض المزيد.')
    if page > 0:
        lines.append('اكتب "السابق" للصفحة السابقة.')
    lines.append('اكتب "رجوع" للعودة أو "القائمة" للقائمة الرئيسية.')
    return "\n".join(lines)
