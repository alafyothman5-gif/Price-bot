# PriceBot testing

Run:

```bash
./venv/bin/python -m compileall .
./venv/bin/python tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/pricebot_identity_test.sqlite
./venv/bin/python tools/verify_production.py --db-path /tmp/pricebot_identity_test.sqlite --excel-path products_master_ready.xlsx
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_identity_test.sqlite
```

Expected:

```text
products count: 5791
search index count: >0
guided index count: >0
product identity registry count: >0
schema learning_inbox: OK
ACCEPTANCE_TESTS_ALL_PASS=84
```

The safe matching tests check displayed product names, not only decision labels.
