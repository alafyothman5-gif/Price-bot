"""Dynamic synonym loader for PriceBot matching.

Synonyms live in SQLite table dynamic_synonyms when present, plus
`data/dynamic_synonyms.json` as the safe default source.  This keeps matching
updates independent from Python code changes.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List

from normalizer import normalize_text

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_SYNONYM_FILE = BASE_DIR / "data" / "dynamic_synonyms.json"
_CACHE: Dict[str, str] = {}
_LOADED = False


def _load_file() -> Dict[str, str]:
    if not DEFAULT_SYNONYM_FILE.exists():
        return {}
    try:
        raw = json.loads(DEFAULT_SYNONYM_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    out: Dict[str, str] = {}
    for k, v in (raw or {}).items():
        nk = normalize_text(k)
        nv = normalize_text(v)
        if nk and nv:
            out[nk] = nv
    return out


def _load_db() -> Dict[str, str]:
    try:
        import database  # local import avoids startup cycles
        with database.connect() as conn:
            if not database.table_exists(conn, "dynamic_synonyms"):
                return {}
            rows = conn.execute("SELECT source, target FROM dynamic_synonyms WHERE enabled=1").fetchall()
            return {normalize_text(r[0]): normalize_text(r[1]) for r in rows if normalize_text(r[0]) and normalize_text(r[1])}
    except Exception:
        return {}


def load_dynamic_synonyms(force: bool = False) -> Dict[str, str]:
    global _CACHE, _LOADED
    if _LOADED and not force:
        return dict(_CACHE)
    merged = _load_file()
    merged.update(_load_db())
    _CACHE = merged
    _LOADED = True
    return dict(_CACHE)


def invalidate_cache() -> None:
    global _LOADED
    _LOADED = False


def apply_synonyms(text: object) -> str:
    n = normalize_text(text)
    if not n:
        return ""
    synonyms = load_dynamic_synonyms()
    words = n.split()
    # Replace normalized token sequences, not substrings.  This prevents
    # cap->capsule from corrupting words like capsules into capsulesule.
    phrases = sorted(((src.split(), dst.split()) for src, dst in synonyms.items() if src), key=lambda x: len(x[0]), reverse=True)
    out = []
    i = 0
    while i < len(words):
        matched = False
        for src_words, dst_words in phrases:
            if src_words and words[i:i+len(src_words)] == src_words:
                out.extend(dst_words)
                i += len(src_words)
                matched = True
                break
        if not matched:
            out.append(words[i])
            i += 1
    return normalize_text(" ".join(out))


def token_synonym(token: str) -> str:
    n = normalize_text(token)
    return load_dynamic_synonyms().get(n, n)
