from typing import Dict, List

import config_env
import database
from normalizer import safe_price


def format_product_line(i: int, product: Dict) -> str:
    price = safe_price(product.get("price"))
    currency = product.get("currency") or "د.ل"
    return f"{i}. {product.get('name') or 'منتج'} - {price} {currency}".replace("LYD", "د.ل")


def format_product_list(products: List[Dict], page: int = 0, page_size: int = 10) -> str:
    if not products:
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار."
    start = page * page_size
    chunk = products[start:start + page_size]
    lines = ["منتجات متوفرة:", ""]
    for i, p in enumerate(chunk, 1):
        lines.append(format_product_line(i, p))
    lines.append("")
    lines.append("اكتب رقم المنتج للتفاصيل" + (" أو اكتب \"المزيد\"." if start + page_size < len(products) else "."))
    lines.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(lines)


def format_product_details(product: Dict) -> str:
    price = safe_price(product.get("price"))
    currency = (product.get("currency") or "د.ل").replace("LYD", "د.ل")
    name = product.get("name") or ""
    category = product.get("main_section") or product.get("section") or product.get("category") or ""
    form = product.get("form") or product.get("medicine_form") or product.get("product_type") or ""
    strength = product.get("strength") or ""
    size = product.get("size") or ""
    measure = " / ".join(x for x in [strength, size] if str(x).strip())
    details = [
        "✅ المنتج متوفر",
        "",
        f"📦 الاسم: {name}",
        f"💵 السعر: {price} {currency}",
    ]
    if category:
        details.append(f"🏷️ التصنيف: {category}")
    if form:
        details.append(f"💊 الشكل: {form}")
    if measure:
        details.append(f"📏 التركيز/الحجم: {measure}")
    details.append("")
    details.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(details)


def create_order(phone: str, product: Dict, quantity: int) -> int:
    return database.create_order(phone, product, quantity)


def format_my_orders(phone: str) -> str:
    rows = database.recent_orders_for_phone(phone, limit=5)
    if not rows:
        return "لا توجد طلبات مسجلة لك حاليًا."
    lines = ["آخر طلباتك:"]
    for r in rows:
        lines.append(f"#{r['id']} - {r['product_name']} - الكمية {r['quantity']} - الحالة: {r['status']}")
    return "\n".join(lines)
