# PriceBot Product Identity Registry + Safe Matching + Learning Inbox

## Scope
This release keeps the existing WhatsApp UI and deployment flow, and replaces the risky broad matching behavior with a product identity layer that runs before any ranking/token scoring.

## Product Identity Layer
A derived table named `product_identity_registry` is created from `products` during import. It contains:

- `product_db_id`
- `product_id`
- `identity_key`
- `canonical_name`
- `normalized_name`
- `compact_name`
- `brand`
- `product_family`
- `form`
- `strength`
- `size`
- `pack`
- `barcode`
- `aliases`
- `ocr_keywords`
- `category`
- `search_policy`
- `duplicate_group`

The registry is rebuilt after Excel import and does not modify product rows except when an admin explicitly approves a learning entry.

## Matching Order
Matching now starts in this order:

1. Barcode exact.
2. Normalized exact name.
3. Compact exact name.
4. Exact alias.
5. Exact OCR keyword.
6. Brand + product family exact.
7. Form/strength/size verification.
8. Limited ranking only inside the same identity/category scope.

Global token scoring is not allowed to return a product before registry/exact matching fails.

## Vision Matching
Vision matching no longer sends raw package text into product search. It expects/extracts:

- `main_visible_product`
- `brand`
- `product_name`
- `product_family`
- `form`
- `strength`
- `size`
- `pack`
- `visible_text`
- `background_text`
- `confidence`

Only the foreground/main product identity is matched. Background text is kept out of matching to prevent cases such as MEBO Scar image selecting Hemazym from the background.

## Duplicate Conflict System
The registry builds `identity_key` from normalized brand/family/category/form/strength/size/pack. If the same identity has multiple prices, matching returns `ASK_CLARIFICATION` instead of taking the first row.

## Learning Inbox
A new table `learning_inbox` captures failed/uncertain queries:

- `customer_query`
- `vision_text`
- `candidate_products`
- `decision`
- `reason`
- `admin_action`

Admin route:

```text
/admin/learning?key=ADMIN_KEY
```

When an admin approves the correct product, the system appends the failed query to `aliases` or `ocr_keywords` and rebuilds `product_identity_registry`. This makes the same failure teachable once instead of recurring.

## Guarded Cases
The release includes tests for:

- `Gyno daktarin` → Gyno-Daktarin identity only.
- `MEBO SCAR OINTMENT REDUCE SCARS 30g` → `mebo scar`.
- MEBO Scar image with Hemazym in background → MEBO only, not Hemazym.
- `Pro-D3 50,000 IU Vitamin K2` → Pro-D3 50,000 IU only.
- `Dexeryl crème 250g` → DEXERYL CREAM / Dexeryl-only clarification.
- `Rilastil xerolact PB` not in catalog → `NOT_AVAILABLE` without other Rilastil products.
- `Cerave Hydrating Cleanser` → cleanser-only alternatives; no lotion/moisturizer/cream.
- `Flagyl 500mg`, `Janumet 50/1000mg`, `Cipralex 10mg` duplicate prices → clarification/review, no first-price shortcut.

## Acceptance Result

```text
COMPILEALL_OK=OK
IMPORT_TEMP_DB_PRODUCTS_AFTER=5791
SEARCH_INDEX_BUILT=40346
GUIDED_INDEX_BUILT=3574
PRODUCT_IDENTITY_REGISTRY=5791
LEARNING_INBOX_SCHEMA=OK
VERIFY_PRODUCTION_OK=OK
UI_ACCEPTANCE_PASS=23
SAFE_MATCHING_ACCEPTANCE_PASS=61
ACCEPTANCE_TESTS_ALL_PASS=84
NO_DB_IN_ZIP=OK
NO_ENV_IN_ZIP=OK
NO_SECRETS_IN_ZIP=OK
```


## V1 fix: form normalization guard

- `canonical_form("supplement")` returns empty string, not `suppository`.
- Short aliases such as `supp`, `cap`, `tab`, and `sol` are matched only as whole tokens.
- Product Identity Registry no longer derives a suppository form from `supplement` / `supplement_unspecified`.
- A supplement with clear identity is not rejected solely because the query/image form says `capsule`.
- Mandatory regression: `Pro-D3 50,000 IU vitamin k2 15 capsules` => `EXACT_MATCH` Pro-D3 50,000 IU.


## READY-2 fixes

Scope: Product Identity / Query Slots / Vision matching only. No UI, deploy, DB schema, or booking changes.

Implemented:
- Added Arabic dynamic synonyms for Flagyl: `فلاجيل`, `فلاجل`, `فلاجيل شراب`, `فلاجيل حبوب`, `فلاجيل أقراص`, `فلاجيل تحاميل`.
- Added Arabic form synonym verification for syrup/tablet/suppository/injection/drops/ointment/cream.
- Vision foreground identity now wins over `background_text` and noisy OCR text.
- MEBO Scar foreground identity is locked to `mebo scar`; background text such as Hemazym is ignored after foreground identity is detected.
- Removed singular `scar` from generic identity words so `mebo scar` remains a valid Product Identity token.

Acceptance:
- `فلاجيل` => `ASK_CLARIFICATION` within Flagyl products.
- `فلاجيل شراب` => syrup/suspension Flagyl only.
- `فلاجيل 500` => `ASK_CLARIFICATION`, not first-price `EXACT_MATCH`.
- `MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym` => `EXACT_MATCH mebo scar`.
- Pro-D3 / supplement / Gyno-Daktarin / Dexeryl / Rilastil / Cerave regressions remain covered.

## READY-3 Vision Brand-Locked Identity Fix

This release fixes a production failure where Vision extracted `brand=MEBO` and `product_name=MEBO SCAR OINTMENT`, but the matcher returned an ASK_CLARIFICATION list containing `First Scar 30g` and `mebo scar`.

Changes:
- Added a strict Vision brand lock before `_exact_or_clarify`.
- If `slots.source == "vision"` and `slots.brand` exists, every candidate must match the extracted brand via explicit/inferred brand or product identity text.
- `First Scar 30g` is rejected when extracted brand is `MEBO`, even if it shares `scar` and `30g` tokens.
- `background_text` such as `Hemazym` does not override or invalidate the foreground identity.

Mandatory test:
`MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym` => `EXACT_MATCH mebo scar`, with `First Scar 30g` forbidden.
