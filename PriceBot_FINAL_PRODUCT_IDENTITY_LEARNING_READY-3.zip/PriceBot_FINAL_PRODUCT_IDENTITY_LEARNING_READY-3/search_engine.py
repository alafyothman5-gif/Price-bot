from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import database
import product_identity
from dynamic_synonyms import apply_synonyms
from normalizer import compact_normalize, is_generic_query, normalize_text, safe_price, split_multi, tokens
from query_slots import (
    COSMETIC_TYPES,
    GENERAL_WORDS,
    QuerySlots,
    build_vision_query,
    canonical_form,
    compatible_form,
    extract_query_slots,
    measure_matches,
    normalize_measure,
)

ALLOWED_DECISIONS = {
    "EXACT_MATCH",
    "ASK_CLARIFICATION",
    "NOT_AVAILABLE",
    "COSMETIC_ALTERNATIVES",
    "LOW_CONFIDENCE",
    "IMAGE_UNCLEAR",
}

@dataclass
class SearchResult:
    status: str
    message: str = ""
    products: List[Dict] = field(default_factory=list)
    product: Optional[Dict] = None
    clarification: Optional[str] = None
    diagnostics: Dict = field(default_factory=dict)


_PRODUCT_CACHE: Optional[List[Dict]] = None
_BRAND_CACHE: Optional[set] = None
_INDEX_BUILT_AT: float = 0.0


def _log_match(decision: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["token", "secret", "key", "authorization"]):
            v = "HIDDEN"
        if isinstance(v, (dict, list, tuple)):
            v = json.dumps(v, ensure_ascii=False, default=str)[:900]
        safe.append(f"{k}={v}")
    print("MATCH_DECISION" + f" decision={decision}" + (" | " + " | ".join(safe) if safe else ""), flush=True)


def invalidate_memory_index() -> None:
    global _PRODUCT_CACHE, _BRAND_CACHE, _INDEX_BUILT_AT
    _PRODUCT_CACHE = None
    _BRAND_CACHE = None
    _INDEX_BUILT_AT = 0.0


def _catalog() -> List[Dict]:
    global _PRODUCT_CACHE, _BRAND_CACHE, _INDEX_BUILT_AT
    if _PRODUCT_CACHE is None:
        _PRODUCT_CACHE = database.load_product_rows(visible_only=True, guided=False)
        brands = set()
        for p in _PRODUCT_CACHE:
            # Precompute normalized identity fields once.  This keeps warm search
            # latency low and avoids repeated normalization over the full catalog.
            explicit_brand = normalize_text(p.get("brand"))
            inferred_brand = ""
            name_norm = apply_synonyms(p.get("name") or "")
            if name_norm.split():
                inferred_brand = name_norm.split()[0]
            brand_norm = apply_synonyms(explicit_brand) if explicit_brand and explicit_brand not in {"unknown", "غير مصنف", "غير معروف"} and explicit_brand not in GENERAL_WORDS else inferred_brand
            p["_brand_norm"] = brand_norm
            p["_category_norm"] = normalize_text(p.get("category") or p.get("main_section") or p.get("section"))
            p["_form_norm"] = canonical_form(p.get("form") or p.get("medicine_form") or p.get("name") or "")
            p["_identity_norm"] = apply_synonyms(" ".join(str(p.get(c) or "") for c in ["name", "normalized_name", "brand", "product_family", "active_ingredient", "aliases", "ocr_keywords", "barcode"]))
            p["_identity_compact"] = compact_normalize(p["_identity_norm"])
            p["_display_norm"] = apply_synonyms(" ".join(str(p.get(c) or "") for c in ["name", "brand", "product_family", "form", "strength", "size", "pack"]))
            p["_identity_key"] = (
                p["_brand_norm"],
                apply_synonyms(p.get("product_family") or p.get("normalized_name") or p.get("name") or ""),
                p["_category_norm"],
                p["_form_norm"],
                normalize_measure(p.get("strength")),
                normalize_measure(p.get("size")),
                normalize_measure(p.get("pack")),
            )
            # Use explicit catalog brand only for slot extraction.  Inferring every
            # first token as a brand pollutes extraction with words like hydrating/vitamin.
            if explicit_brand and explicit_brand not in {"unknown", "غير مصنف", "غير معروف"} and explicit_brand not in GENERAL_WORDS:
                brands.add(apply_synonyms(explicit_brand))
        _BRAND_CACHE = brands
        _INDEX_BUILT_AT = time.time()
    return _PRODUCT_CACHE


def catalog_brands() -> set:
    _catalog()
    return _BRAND_CACHE or set()


def preload_search_index() -> int:
    """Warm the in-memory product identity index at startup."""
    return len(_catalog())


def _field_text(p: Dict, fields: Sequence[str]) -> str:
    return apply_synonyms(" ".join(str(p.get(c) or "") for c in fields))


def _infer_brand(p: Dict) -> str:
    if p.get("_brand_norm"):
        return str(p.get("_brand_norm") or "")
    brand = normalize_text(p.get("brand"))
    if brand and brand not in {"unknown", "غير مصنف", "غير معروف"}:
        return apply_synonyms(brand)
    name = normalize_text(p.get("name"))
    parts = name.split()
    return apply_synonyms(parts[0]) if parts else ""


def _identity_text(p: Dict) -> str:
    return str(p.get("_identity_norm") or _field_text(p, ["name", "normalized_name", "brand", "product_family", "active_ingredient", "aliases", "ocr_keywords", "barcode"]))


def _display_identity_text(p: Dict) -> str:
    return str(p.get("_display_norm") or _field_text(p, ["name", "brand", "product_family", "form", "strength", "size", "pack"]))


def _product_category(p: Dict) -> str:
    return str(p.get("_category_norm") or normalize_text(p.get("category") or p.get("main_section") or p.get("section")))


def _product_form(p: Dict) -> str:
    return str(p.get("_form_norm") or canonical_form(p.get("form") or p.get("medicine_form") or p.get("name") or ""))


def _identity_key(p: Dict) -> Tuple[str, str, str, str, str, str, str]:
    if p.get("_identity_key"):
        return tuple(p.get("_identity_key"))  # type: ignore[return-value]
    # Name is included as fallback because many catalog rows still lack brand/family.
    name = apply_synonyms(p.get("product_family") or p.get("normalized_name") or p.get("name") or "")
    return (
        _infer_brand(p),
        normalize_text(name),
        _product_category(p),
        _product_form(p),
        normalize_measure(p.get("strength")),
        normalize_measure(p.get("size")),
        normalize_measure(p.get("pack")),
    )


def product_identity_key(p: Dict) -> Tuple[str, str, str, str, str, str, str]:
    return _identity_key(p)


def _dedupe_products(products: Iterable[Dict], limit: int = 20) -> List[Dict]:
    out: List[Dict] = []
    seen = set()
    for p in products:
        if not p or not database.product_visible(p, guided=False):
            continue
        key = p.get("id") or _identity_key(p)
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def dedupe_products(products: List[Dict], limit: int = 20) -> List[Dict]:
    return _dedupe_products(products, limit=limit)


def _price_set(products: Sequence[Dict]) -> set:
    return {safe_price(p.get("price")) for p in products if safe_price(p.get("price"))}


def _duplicate_conflict(products: Sequence[Dict]) -> bool:
    if len(products) <= 1:
        return False
    groups: Dict[Tuple, List[Dict]] = {}
    for p in products:
        groups.setdefault(_identity_key(p), []).append(p)
    return any(len(group) > 1 and len(_price_set(group)) > 1 for group in groups.values())


def _same_identity(products: Sequence[Dict]) -> bool:
    return bool(products) and len({_identity_key(p) for p in products}) == 1


def _clean_ocr_keyword(keyword: str) -> str:
    k = apply_synonyms(keyword)
    bad = {"unknown", "unclassified", "غير معروف", "غير مصنف"}
    if k in bad or not k:
        return ""
    if k in GENERAL_WORDS:
        return ""
    return k


def build_search_index_entries() -> List[Tuple[str, str, int, int]]:
    entries: List[Tuple[str, str, int, int]] = []
    seen = set()

    def add(key: str, kind: str, pid: int, weight: int) -> None:
        key = apply_synonyms(key)
        if not key:
            return
        rec = (key, kind, pid)
        if rec in seen:
            return
        seen.add(rec)
        entries.append((key, kind, pid, weight))
        compact = compact_normalize(key)
        if compact and compact != key:
            rec2 = (compact, "compact_" + kind, pid)
            if rec2 not in seen:
                seen.add(rec2)
                entries.append((compact, "compact_" + kind, pid, max(1, weight - 5)))

    for p in database.load_product_rows(visible_only=True, guided=False):
        pid = int(p["id"])
        add(p.get("name") or p.get("original_name") or "", "name", pid, 120)
        add(p.get("normalized_name") or "", "name", pid, 118)
        add(p.get("barcode") or "", "barcode", pid, 140)
        # Safe aliases from the name and compact identity variants.
        name = str(p.get("name") or "")
        if name:
            add(name.replace("-", " "), "alias", pid, 100)
            add(name.replace(" ", ""), "alias", pid, 100)
        # Specific high-value supplement/vision variants.
        nname = apply_synonyms(name)
        if "prod3" in nname:
            add("pro d3 " + " ".join([str(p.get("strength") or ""), str(p.get("pack") or "")]), "alias", pid, 110)
            add("pro-d3 " + str(p.get("strength") or ""), "alias", pid, 110)
        if "ovanice" in nname:
            add("ovanice female fertility", "alias", pid, 105)
        for alias in split_multi(p.get("aliases")):
            add(alias, "alias", pid, 100)
        for keyword in split_multi(p.get("ocr_keywords")):
            k = _clean_ocr_keyword(keyword)
            if k:
                add(k, "ocr_keyword", pid, 88)
    return entries


def rebuild_search_index() -> int:
    count = database.replace_search_index(build_search_index_entries())
    invalidate_memory_index()
    return count


def rebuild_product_identity_registry() -> int:
    count = product_identity.rebuild_product_identity_registry()
    invalidate_memory_index()
    return count



def _identity_phrase_tokens(value: object) -> List[str]:
    """Non-generic tokens that can identify a product name/family/alias.

    Forms, marketing words, units, and standalone numbers are intentionally
    removed.  This lets strict matching accept "mebo scar ointment" for the
    catalog row "mebo scar", while rejecting generic phrases such as
    "cream tube 250g".
    """
    n = apply_synonyms(value)
    out: List[str] = []
    for t in tokens(n):
        t = apply_synonyms(t)
        if not t:
            continue
        if t in GENERAL_WORDS:
            continue
        if canonical_form(t):
            continue
        if t in {"mg", "mcg", "g", "kg", "ml", "l", "iu", "unit", "units"}:
            continue
        if t.isdigit():
            continue
        if len(t) <= 2 and not any(ch.isdigit() for ch in t):
            continue
        if t not in out:
            out.append(t)
    return out


def _identity_field_values(p: Dict) -> List[str]:
    vals: List[str] = []
    for col in ["name", "normalized_name", "product_family", "aliases", "ocr_keywords", "barcode"]:
        raw = str(p.get(col) or "").strip()
        if not raw:
            continue
        for piece in split_multi(raw):
            nv = apply_synonyms(piece)
            if nv and nv not in vals:
                vals.append(nv)
    # Always include combined display identity as a fallback for older rows with
    # weak aliases but useful brand/family/name data.
    for raw in [_identity_text(p), _display_identity_text(p)]:
        nv = apply_synonyms(raw)
        if nv and nv not in vals:
            vals.append(nv)
    return vals


def _strict_identity_match(product: Dict, slots: QuerySlots, required_tokens: Optional[Sequence[str]] = None) -> bool:
    q_norm = slots.normalized
    q_compact = compact_normalize(q_norm)
    if slots.barcode and normalize_text(product.get("barcode")) == slots.barcode:
        return True
    req_tokens = list(required_tokens or _identity_phrase_tokens(q_norm))
    if len(req_tokens) < 2 and not slots.barcode:
        return False

    # Brand/product explicit guard: when the user/vision supplied a clear brand,
    # it must be present in the row identity.  Do not accept same-form/general rows.
    if slots.brand:
        hay_all = _identity_text(product)
        hay_compact_all = str(product.get("_identity_compact") or compact_normalize(hay_all))
        if not (slots.brand in hay_all or slots.brand in hay_compact_all or _infer_brand(product) == slots.brand):
            return False

    for value in _identity_field_values(product):
        if not value:
            continue
        v_compact = compact_normalize(value)
        if q_norm and (q_norm == value or q_compact == v_compact):
            return True
        # Safe subset match in both directions.  Examples:
        # - query "gyno daktarin" matches row "gyno daktarin vag cream"
        # - vision "mebo scar ointment reduce scars 30g" matches row "mebo scar"
        # It is still strict because all identity tokens must appear in the same
        # product identity field, never across arbitrary category words.
        field_tokens = _identity_phrase_tokens(value)
        if req_tokens and all(t in field_tokens or t in v_compact for t in req_tokens):
            return True
        # Inverse subset: product identity is shorter but clearly present in the
        # request.  Require at least two product tokens and no contradiction.
        if len(field_tokens) >= 2 and all(t in req_tokens or t in q_compact for t in field_tokens):
            return True
    return False


def _strict_normalized_exact_candidates(slots: QuerySlots, required_tokens: Optional[Sequence[str]] = None, limit: int = 30) -> List[Dict]:
    """STRICT_NORMALIZED_EXACT_FIRST.

    This stage runs before token ranking.  It checks normalized equality and
    compact/subset identity against name, normalized_name, product_family,
    aliases, and ocr_keywords.  It is intentionally conservative: generic words
    and dosage forms do not create matches by themselves.
    """
    req_tokens = list(required_tokens or _identity_phrase_tokens(slots.normalized))
    if len(req_tokens) < 2 and not slots.barcode:
        return []
    candidates: List[Dict] = []
    for product in _catalog():
        if not database.product_visible(product, guided=False):
            continue
        if _strict_identity_match(product, slots, req_tokens):
            candidates.append(product)
    return _dedupe_products(candidates, limit=limit)


def _known_foreground_identity_text(value: object) -> str:
    """Return a trusted foreground identity from noisy Vision text when present.

    Vision/OCR may read background shelf products after the main pack text.
    Once a known strong identity such as MEBO SCAR is visible, later words like
    Hemazym/background marketing text must not override or invalidate it.
    """
    n = apply_synonyms(value)
    if not n:
        return ""
    c = compact_normalize(n)
    if "meboscar" in c or "mebo scar" in n:
        return "mebo scar"
    if "prod3" in c:
        return "prod3"
    if "gynodaktarin" in c or "gyno daktarin" in n:
        return "gyno daktarin"
    if "dexeryl" in n:
        return "dexeryl"
    if "flagyl" in n:
        return "flagyl"
    return ""


def _foreground_identity_tokens(slots_dict: Dict[str, object], slots: QuerySlots) -> List[str]:
    """Extract central product identity from Vision slots.

    Prefer main_visible_product/product_name over full visible_text.  If noisy
    OCR includes background products, a known foreground identity wins and
    background words are ignored.
    """
    product_text = slots_dict.get("main_visible_product") or slots_dict.get("product_name") or slots_dict.get("product_family") or slots_dict.get("product") or slots_dict.get("name") or ""
    brand_text = slots_dict.get("brand") or ""
    visible_text = str(slots_dict.get("visible_text") or "")

    known = _known_foreground_identity_text(product_text) or _known_foreground_identity_text(brand_text) or _known_foreground_identity_text(visible_text)
    if known:
        return _strong_identity_tokens_from_text(known, slots)

    if not product_text:
        visible = visible_text
        # Keep the likely foreground/front-label part.  Words such as reduce,
        # supports, ingredients, and a second unrelated brand often appear after
        # the main product identity.
        visible = re.split(r"\b(?:reduce|reduces|support|supports|for|with|contains|ingredients|health|skin|tube|glycerol|vaseline|paraffin)\b", visible, flags=re.I)[0]
        product_text = visible
    toks = _strong_identity_tokens_from_text(product_text, slots)
    brand_toks = _strong_identity_tokens_from_text(brand_text, slots)
    identity = toks or brand_toks
    if any(t == "prod3" for t in identity):
        identity = ["prod3"]
    if "mebo" in identity and "scar" in identity:
        identity = [t for t in identity if t not in {"hemazym", "reduce", "reduces", "scars", "background"}]
    return [t for t in identity if t not in GENERAL_WORDS]

def _exact_index_candidates(slots: QuerySlots) -> List[Dict]:
    keys = [slots.normalized, slots.compact]
    if slots.barcode:
        keys.insert(0, slots.barcode)
    candidates: List[Dict] = []
    for key in keys:
        if not key:
            continue
        kinds = ["name", "alias", "ocr_keyword", "barcode"] if key != slots.compact else ["compact_name", "compact_alias", "compact_ocr_keyword"]
        candidates.extend(database.find_by_exact_index(key, kinds))
    return _dedupe_products(candidates, limit=30)


def _token_candidates(slots: QuerySlots, limit: int = 80) -> List[Dict]:
    if not slots.strong_tokens:
        return []
    out: List[Tuple[int, Dict, List[str]]] = []
    for p in _catalog():
        hay = _identity_text(p)
        display = _display_identity_text(p)
        reasons = []
        # A candidate needs either all strong identity tokens, or a strong brand
        # plus one family/name token. Generic form/size tokens are never enough.
        hay_compact = str(p.get("_identity_compact") or compact_normalize(hay))
        hits = [t for t in slots.strong_tokens if t and (t in hay or t in hay_compact)]
        if not hits:
            continue
        brand = _infer_brand(p)
        brand_ok = bool(slots.brand and (slots.brand == brand or slots.brand in hay))
        if len(slots.strong_tokens) >= 2:
            if not all(t in hay or t in hay_compact for t in slots.strong_tokens):
                # Vision/product text often includes marketing words; require at least brand + product core.
                if not (brand_ok and len(hits) >= 2):
                    continue
        elif not brand_ok and slots.strong_tokens[0] not in {brand, normalize_text(p.get("name"))}:
            continue
        score = 0
        if brand_ok:
            score += 60; reasons.append("brand")
        score += 12 * len(hits)
        name_norm = apply_synonyms(p.get("name"))
        for t in hits:
            if t in name_norm:
                score += 8
        # Strong measure hits improve ranking but do not override identity.
        for s in slots.strengths:
            if measure_matches(s, p.get("strength")) or normalize_measure(s) in normalize_measure(display):
                score += 20; reasons.append("strength")
        for s in slots.sizes:
            if measure_matches(s, p.get("size")) or normalize_measure(s) in normalize_measure(display):
                score += 12; reasons.append("size")
        for s in slots.packs:
            if measure_matches(s, p.get("pack")) or normalize_measure(s) in normalize_measure(display):
                score += 10; reasons.append("pack")
        out.append((score, p, reasons))
    out.sort(key=lambda x: (-x[0], str(x[1].get("name") or "")))
    return _dedupe_products([p for _score, p, _reasons in out], limit=limit)


def _form_filter(products: Sequence[Dict], slots: QuerySlots, allow_missing_form: bool = False) -> Tuple[List[Dict], List[Tuple[str, str]]]:
    if not slots.form:
        return list(products), []
    accepted: List[Dict] = []
    rejected: List[Tuple[str, str]] = []
    for p in products:
        pform = _product_form(p)
        pcat = _product_category(p)
        # Supplements often have incomplete form in pharmacy files.  If identity
        # is strong and there is no competing variant, do not reject solely for
        # missing capsule/tablet form.
        if pcat == "supplement" and slots.form in {"capsule", "tablet", "sachet", "drops", "syrup", "powder"} and allow_missing_form:
            # Supplement rows may have incomplete/stale form values from older
            # imports.  When a strict identity match already happened, a query
            # form such as "capsule" must not be rejected solely because the
            # product row has an old wrong medicine form like suppository.
            accepted.append(p)
        elif not pform and allow_missing_form:
            # Strict identity already matched name/family/alias/ocr.  Missing
            # catalog form should not convert an existing product into
            # NOT_AVAILABLE, especially for image labels such as
            # "MEBO SCAR OINTMENT 30g" when the row is stored as "mebo scar".
            accepted.append(p)
        elif not pform and pcat == "supplement" and slots.form in {"capsule", "tablet", "sachet", "drops", "syrup"}:
            accepted.append(p)
        elif compatible_form(slots.form, pform, p.get("name") or ""):
            accepted.append(p)
        else:
            rejected.append((str(p.get("name") or ""), f"form_mismatch:{slots.form}!={pform}"))
    return accepted, rejected


def _measure_filter(products: Sequence[Dict], slots: QuerySlots) -> Tuple[List[Dict], List[Tuple[str, str]]]:
    accepted: List[Dict] = []
    rejected: List[Tuple[str, str]] = []
    for p in products:
        reject = False
        display = _display_identity_text(p)
        # Requested measures are strict when the catalog has a comparable value.
        # If the catalog row lacks size/pack, do not reject an otherwise exact
        # brand/product match solely because the image saw the package size.
        if slots.strengths:
            p_strength = p.get("strength") or ""
            if p_strength and not any(measure_matches(s, p_strength) or normalize_measure(s) in normalize_measure(display) for s in slots.strengths):
                rejected.append((str(p.get("name") or ""), "strength_mismatch")); reject = True
        if slots.sizes and not reject:
            p_size = p.get("size") or ""
            if p_size and not any(measure_matches(s, p_size) or normalize_measure(s) in normalize_measure(display) for s in slots.sizes):
                rejected.append((str(p.get("name") or ""), "size_mismatch")); reject = True
        if slots.packs and not reject:
            p_pack = p.get("pack") or ""
            if p_pack and not any(measure_matches(s, p_pack) or normalize_measure(s) in normalize_measure(display) for s in slots.packs):
                rejected.append((str(p.get("name") or ""), "pack_mismatch")); reject = True
        if not reject:
            accepted.append(p)
    return accepted, rejected


def _filter_candidates(products: Sequence[Dict], slots: QuerySlots, allow_missing_form: bool = False) -> Tuple[List[Dict], List[Tuple[str, str]]]:
    rejected: List[Tuple[str, str]] = []
    cand = [p for p in products if database.product_visible(p, guided=False)]
    cand2, rej = _form_filter(cand, slots, allow_missing_form=allow_missing_form); rejected.extend(rej)
    cand3, rej = _measure_filter(cand2, slots); rejected.extend(rej)
    # Cross-category guard: if query indicates cosmetic type, reject non-cosmetic or different type.
    if slots.cosmetic_type:
        filtered = []
        for p in cand3:
            pcat = _product_category(p)
            unknown_pcat = pcat in {"", "unknown", "غير معروف", "غير مصنف", "unclassified"}
            if pcat and pcat not in {"cosmetic", "عنايه بالبشره", "عناية بالبشرة", "عنايه بالشعر", "عناية بالشعر"}:
                if not (allow_missing_form and unknown_pcat):
                    rejected.append((str(p.get("name") or ""), "category_mismatch_cosmetic")); continue
            p_requested_form = p.get("form") or p.get("product_type") or ""
            if normalize_text(p_requested_form) in {"unknown", "غير معروف", "غير مصنف", "unclassified"}:
                p_requested_form = ""
            if not p_requested_form and allow_missing_form:
                filtered.append(p); continue
            if not compatible_form(slots.cosmetic_type, p_requested_form, p.get("name") or ""):
                rejected.append((str(p.get("name") or ""), f"cosmetic_type_mismatch:{slots.cosmetic_type}")); continue
            filtered.append(p)
        cand3 = filtered
    return _dedupe_products(cand3, limit=60), rejected


def _group_forms(products: Sequence[Dict]) -> List[str]:
    vals = []
    for p in products:
        f = _product_form(p) or normalize_text(p.get("form") or p.get("medicine_form") or p.get("product_type"))
        if not f:
            # infer common name abbreviations
            f = canonical_form(p.get("name"))
        if f and f not in vals:
            vals.append(f)
    return sorted(vals)


def _group_strengths(products: Sequence[Dict]) -> List[str]:
    vals = []
    for p in products:
        s = normalize_text(p.get("strength"))
        if s and s not in vals:
            vals.append(s)
    return sorted(vals)


def _variant_clarification(products: Sequence[Dict], slots: QuerySlots) -> Optional[str]:
    if not products:
        return None
    meds = [p for p in products if _product_category(p) == "medicine" or normalize_text(p.get("main_section")) == normalize_text("أدوية")]
    if len(meds) <= 1:
        return None
    forms = _group_forms(meds)
    strengths = _group_strengths(meds)
    prices = _price_set(meds)
    if _duplicate_conflict(meds):
        return "يوجد أكثر من سجل لنفس المنتج بأسعار مختلفة. يحتاج مراجعة قبل عرض السعر. اكتب تفاصيل أكثر أو راجع الصيدلية."
    if len(forms) > 1 and not slots.form:
        return "هذا الدواء له أكثر من شكل. حدد المطلوب: أقراص / شراب / كبسول / حقن / تحاميل."
    if len(strengths) > 1 and not slots.strength:
        return "هذا المنتج له أكثر من تركيز. اكتب التركيز المطلوب قبل عرض السعر."
    return None


def _brand_family_specific_missing(slots: QuerySlots, all_candidates: Sequence[Dict]) -> bool:
    if not slots.brand:
        return False
    # Specific query when brand plus at least one family/non-generic token or a requested type/strength exists.
    specific = bool(slots.product_family or slots.form or slots.strength or len(slots.strong_tokens) >= 2)
    if not specific:
        return False
    brand_products = [p for p in _catalog() if _infer_brand(p) == slots.brand or slots.brand in _identity_text(p)]
    if not brand_products:
        return False
    return not bool(all_candidates)


def _cosmetic_alternatives(slots: QuerySlots) -> List[Dict]:
    if not slots.cosmetic_type:
        return []
    alts = []
    for p in _catalog():
        if not database.product_visible(p, guided=False):
            continue
        if slots.brand and not (_infer_brand(p) == slots.brand or slots.brand in _identity_text(p)):
            continue
        if compatible_form(slots.cosmetic_type, p.get("form") or p.get("product_type") or "", p.get("name") or ""):
            alts.append(p)
    return _dedupe_products(alts, limit=10)



def _strong_identity_tokens_from_text(value: object, slots: QuerySlots) -> List[str]:
    """Return non-generic product identity tokens from Vision brand/name text."""
    n = apply_synonyms(value)
    measure_blob = normalize_measure(" ".join(slots.strengths + slots.sizes + slots.packs))
    out: List[str] = []
    for t in tokens(n):
        t = apply_synonyms(t)
        if not t:
            continue
        if t in GENERAL_WORDS:
            continue
        if canonical_form(t):
            continue
        if t in {"mg", "g", "ml", "iu", "unit", "units"}:
            continue
        # Measures and stray package counts are handled in strength/size/pack slots.
        # They are not product identity tokens and must not scope Vision matches.
        if t.isdigit():
            continue
        if t in measure_blob:
            continue
        if len(t) <= 2 and not any(ch.isdigit() for ch in t):
            continue
        if t not in out:
            out.append(t)
    return out


def _same_requested_identity(product: Dict, identity_tokens: Sequence[str], slots: QuerySlots) -> bool:
    hay = _identity_text(product)
    hay_compact = str(product.get("_identity_compact") or compact_normalize(hay))
    if identity_tokens:
        return all(t in hay or t in hay_compact for t in identity_tokens)
    if slots.brand:
        return _product_matches_brand(product, slots.brand)
    return False


def _product_matches_brand(product: Dict, brand: str) -> bool:
    """Strict brand guard used for Vision extracted brands.

    If Vision says brand=MEBO, words like scar/30g must not pull in
    First Scar 30g.  A product survives only when its explicit/inferred brand
    or identity text contains the extracted brand itself.
    """
    b = apply_synonyms(brand)
    if not b:
        return True
    hay = _identity_text(product)
    hay_compact = str(product.get("_identity_compact") or compact_normalize(hay))
    return _infer_brand(product) == b or b in hay or b in hay_compact


def _brand_lock_products(products: Sequence[Dict], slots: QuerySlots) -> Tuple[List[Dict], List[Tuple[str, str]]]:
    if slots.source != "vision" or not slots.brand:
        return list(products), []
    kept: List[Dict] = []
    rejected: List[Tuple[str, str]] = []
    for p in products:
        if _product_matches_brand(p, slots.brand):
            kept.append(p)
        else:
            rejected.append((str(p.get("name") or ""), f"vision_brand_lock:{slots.brand}"))
    return kept, rejected


def _vision_scoped_candidates(slots_dict: Dict[str, object], slots: QuerySlots) -> Tuple[List[Dict], List[Tuple[str, str]], List[str]]:
    """Scope image matches to the extracted product identity before scoring.

    Vision text often contains broad category words such as vitamin/capsules or
    cream/tube.  Those words must never widen the candidate list.  If brand or
    product name is clear, only rows containing that same identity can survive.
    """
    identity_tokens = _foreground_identity_tokens(slots_dict, slots)

    rejected: List[Tuple[str, str]] = []
    if not identity_tokens and not slots.brand:
        return [], [("", "vision_missing_brand_product_identity")], []

    scoped: List[Dict] = []
    for product in _catalog():
        if not database.product_visible(product, guided=False):
            continue
        if slots.brand and not _product_matches_brand(product, slots.brand):
            if len(rejected) < 20:
                rejected.append((str(product.get("name") or ""), f"vision_brand_lock:{slots.brand}"))
            continue
        if _same_requested_identity(product, identity_tokens, slots):
            scoped.append(product)
        else:
            # Keep a compact reject sample only; never show it to users.
            if len(rejected) < 20:
                rejected.append((str(product.get("name") or ""), "identity_scope_mismatch"))

    filtered, filter_rejects = _filter_candidates(scoped, slots)
    rejected.extend(filter_rejects)
    return filtered, rejected, identity_tokens

def _exact_or_clarify(products: Sequence[Dict], slots: QuerySlots, stage: str, latency_ms: int, rejected: List = None) -> SearchResult:
    products = _dedupe_products(products, limit=30)
    rejected = rejected or []
    products, brand_rejected = _brand_lock_products(products, slots)
    rejected.extend(brand_rejected)
    products = _dedupe_products(products, limit=30)
    if not products:
        return SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.", diagnostics={"stage": stage, "brand_lock_rejected": brand_rejected[:10]})
    if _duplicate_conflict(products):
        msg = "يوجد أكثر من سجل لنفس المنتج بأسعار مختلفة. يحتاج مراجعة قبل عرض السعر. اختر من القائمة أو راجع الصيدلية."
        _log_match("ASK_CLARIFICATION", matched_stage=stage, reason="duplicate_price_conflict", query_slots=slots.__dict__, products=[p.get("name") for p in products[:10]], latency_ms=latency_ms)
        return SearchResult("ASK_CLARIFICATION", msg, products=list(products[:10]), diagnostics={"stage": stage, "duplicate_conflict": True})
    clarification = _variant_clarification(products, slots)
    if clarification:
        _log_match("ASK_CLARIFICATION", matched_stage=stage, reason="medicine_variant", query_slots=slots.__dict__, forms=_group_forms(products), strengths=_group_strengths(products), latency_ms=latency_ms)
        return SearchResult("ASK_CLARIFICATION", clarification, products=list(products[:10]), diagnostics={"stage": stage})
    if len(products) == 1 or _same_identity(products):
        p = products[0]
        _log_match("EXACT_MATCH", matched_stage=stage, query_slots=slots.__dict__, matched_fields=_identity_key(p), latency_ms=latency_ms)
        return SearchResult("EXACT_MATCH", product=p, products=[p], diagnostics={"stage": stage})
    # Multiple products from same family but distinct size/strength/form require user choice.
    _log_match("ASK_CLARIFICATION", matched_stage=stage, reason="multiple_candidates", query_slots=slots.__dict__, products=[p.get("name") for p in products[:10]], latency_ms=latency_ms)
    return SearchResult("ASK_CLARIFICATION", "وجدت أكثر من منتج قريب من بحثك. اختر المنتج المطلوب:", products=list(products[:10]), diagnostics={"stage": stage})


def _record_learning_inbox(query: str = "", vision_text: str = "", result: Optional[SearchResult] = None, reason: str = "") -> None:
    try:
        candidates = []
        if result and result.products:
            candidates = [{"id": p.get("id"), "name": p.get("name"), "price": p.get("price")} for p in result.products[:10]]
        database.record_learning_event(
            customer_query=query,
            vision_text=vision_text,
            candidate_products=candidates,
            decision=(result.status if result else ""),
            reason=reason or ((result.diagnostics or {}).get("stage") if result else ""),
        )
    except Exception:
        pass


def generic_redirect_message(q: str) -> str:
    n = normalize_text(q)
    if n in {"غسول", "cleanser", "wash"}:
        return "هل تقصد غسول وجه، غسول جسم، أم غسول أطفال؟ اختر من تصفح الأقسام لتجنب النتائج الخاطئة."
    if n in {"كريم", "cream", "مرطب", "lotion"}:
        return "اكتب اسم الكريم كاملًا أو اختر القسم المناسب من تصفح الأقسام."
    if n in {"حديد", "iron"}:
        return "لمنتجات الحديد اختر: تصفح الأقسام ← مكملات وفيتامينات ← حديد."
    if n in {"فيتامين", "فيتامينات", "vitamin"}:
        return "اختر نوع الفيتامين من قسم مكملات وفيتامينات."
    if n in {"شامبو", "shampoo"}:
        return "اختر عناية بالشعر ← شامبو لعرض الشامبوهات المتوفرة فقط."
    return "الطلب عام. اختر من تصفح الأقسام أو اكتب اسم المنتج كاملًا."


def search_product(query: str, allow_guided_redirect: bool = True, source: str = "text") -> SearchResult:
    start = time.perf_counter()
    raw = str(query or "").strip()
    _catalog()  # warm in-memory index
    slots = extract_query_slots(raw, source=source, catalog_brands=catalog_brands())
    if not slots.normalized:
        return SearchResult("ASK_CLARIFICATION", "اكتب اسم المنتج كاملًا أو اختر من القائمة.")
    if source == "vision":
        measure_blob = normalize_measure(" ".join(slots.strengths + slots.sizes + slots.packs))
        identity_strong = [t for t in slots.strong_tokens if not t.isdigit() and t not in GENERAL_WORDS and t not in measure_blob]
        if not identity_strong:
            _log_match("LOW_CONFIDENCE", matched_stage="vision_generic_guard", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
            result = SearchResult("LOW_CONFIDENCE", "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.")
            _record_learning_inbox(query=raw, result=result, reason="vision_generic_guard")
            return result
    if allow_guided_redirect and is_generic_query(slots.normalized):
        _log_match("ASK_CLARIFICATION", matched_stage="generic_guard", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
        return SearchResult("ASK_CLARIFICATION", generic_redirect_message(slots.normalized), clarification="guided")
    if slots.has_type_only:
        _log_match("ASK_CLARIFICATION", matched_stage="type_only_guard", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
        return SearchResult("ASK_CLARIFICATION", generic_redirect_message(slots.form), clarification="guided")

    identity_hit = product_identity.lookup_exact_identity_candidates(slots)
    if identity_hit.products:
        identity_products, identity_rejected = _filter_candidates(identity_hit.products, slots, allow_missing_form=True)
        if identity_products:
            return _exact_or_clarify(identity_products, slots, "PRODUCT_IDENTITY_REGISTRY", int((time.perf_counter()-start)*1000), identity_rejected + identity_hit.rejected)

    strict_exact = _strict_normalized_exact_candidates(slots)
    strict_exact, strict_rejected = _filter_candidates(strict_exact, slots, allow_missing_form=True)
    if strict_exact:
        return _exact_or_clarify(strict_exact, slots, "STRICT_NORMALIZED_EXACT_FIRST", int((time.perf_counter()-start)*1000), strict_rejected)

    exact = _exact_index_candidates(slots)
    exact, rejected = _filter_candidates(exact, slots)
    if exact:
        return _exact_or_clarify(exact, slots, "exact_index", int((time.perf_counter()-start)*1000), rejected)

    # Fast safe brand-only path.  A single known product family/brand token must
    # ask for clarification instead of falling through to expensive/global token
    # scoring.  This preserves safety for Flagyl/Gaviscon/Panadol-style queries.
    if len(slots.strong_tokens) == 1 and slots.brand and not (slots.form or slots.strengths or slots.sizes or slots.packs):
        brand_matches = [p for p in _catalog() if _infer_brand(p) == slots.brand or slots.brand in _identity_text(p)]
        brand_matches = _dedupe_products(brand_matches, limit=10)
        if brand_matches:
            if len(brand_matches) == 1 and safe_price(brand_matches[0].get("price")):
                _log_match("EXACT_MATCH", matched_stage="brand_only_single_identity", reason="single_sellable_identity", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
                return SearchResult("EXACT_MATCH", product=brand_matches[0], products=brand_matches, diagnostics={"stage":"brand_only_single_identity"})
            _log_match("ASK_CLARIFICATION", matched_stage="brand_only_identity", reason="brand_only_no_price", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
            return SearchResult("ASK_CLARIFICATION", "اكتب اسم المنتج كاملًا أو اختر المنتج المطلوب:", products=brand_matches, diagnostics={"stage":"brand_only_identity"})

    candidates = _token_candidates(slots, limit=80)
    filtered, rejected2 = _filter_candidates(candidates, slots)

    if filtered:
        return _exact_or_clarify(filtered, slots, "identity_tokens", int((time.perf_counter()-start)*1000), rejected2)

    if slots.cosmetic_type:
        alts = _cosmetic_alternatives(slots)
        if alts:
            identity_tokens = _strong_identity_tokens_from_text(slots.raw, slots)
            same_requested = [p for p in alts if _same_requested_identity(p, identity_tokens, slots)]
            if same_requested:
                return _exact_or_clarify(same_requested, slots, "same_product_cosmetic_recovery", int((time.perf_counter()-start)*1000), rejected2)
            _log_match("COSMETIC_ALTERNATIVES", matched_stage="same_type_alternatives", query_slots=slots.__dict__, products=[p.get("name") for p in alts], latency_ms=int((time.perf_counter()-start)*1000))
            return SearchResult("COSMETIC_ALTERNATIVES", "المنتج المطلوب غير موجود، لكن توجد منتجات من نفس النوع. اختر منتجًا لعرض السعر:", products=alts)

    if _brand_family_specific_missing(slots, filtered):
        _log_match("NOT_AVAILABLE", matched_stage="brand_family_guard", reason="brand_family_specific_missing", query_slots=slots.__dict__, rejected_candidates=rejected2[:10], latency_ms=int((time.perf_counter()-start)*1000))
        result = SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.")
        _record_learning_inbox(query=raw, result=result, reason="brand_family_specific_missing")
        return result

    # Single brand only should ask, not guess.
    if len(slots.strong_tokens) <= 1:
        brand_matches = [p for p in _catalog() if slots.brand and (_infer_brand(p) == slots.brand or slots.brand in _identity_text(p))]
        brand_matches = _dedupe_products(brand_matches, limit=10)
        if brand_matches:
            if len(brand_matches) == 1 and safe_price(brand_matches[0].get("price")):
                _log_match("EXACT_MATCH", matched_stage="brand_only_single", reason="single_sellable_identity", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
                return SearchResult("EXACT_MATCH", product=brand_matches[0], products=brand_matches)
            _log_match("ASK_CLARIFICATION", matched_stage="brand_only", reason="brand_only_no_price", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
            return SearchResult("ASK_CLARIFICATION", "اكتب اسم المنتج كاملًا أو اختر المنتج المطلوب:", products=brand_matches)

    _log_match("NOT_AVAILABLE", matched_stage="no_safe_candidate", query_slots=slots.__dict__, rejected_candidates=rejected2[:10], latency_ms=int((time.perf_counter()-start)*1000))
    result = SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.")
    _record_learning_inbox(query=raw, result=result, reason="no_safe_candidate")
    return result

def search_from_vision_slots(slots_dict: Dict[str, object]) -> SearchResult:
    start = time.perf_counter()
    query = build_vision_query(slots_dict)
    if not query:
        _log_match("LOW_CONFIDENCE", matched_stage="vision_slots_empty")
        result = SearchResult("LOW_CONFIDENCE", "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.")
        _record_learning_inbox(query="", vision_text=str(slots_dict.get("visible_text") or ""), result=result, reason="vision_slots_empty")
        return result
    _catalog()
    slots = extract_query_slots(query, source="vision", catalog_brands=catalog_brands())
    extracted_brand = apply_synonyms(slots_dict.get("brand") or "")
    if extracted_brand and extracted_brand not in GENERAL_WORDS:
        slots.brand = extracted_brand

    # If Vision returns only generic words, do not convert to NOT_AVAILABLE.
    measure_blob = normalize_measure(" ".join(slots.strengths + slots.sizes + slots.packs))
    identity_strong = [t for t in slots.strong_tokens if not t.isdigit() and t not in GENERAL_WORDS and t not in {"50", "100", "150", "200", "250", "500", "1000"} and t not in measure_blob]
    if not identity_strong:
        _log_match("LOW_CONFIDENCE", matched_stage="vision_generic_only", query_slots=slots.__dict__)
        result = SearchResult("LOW_CONFIDENCE", "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.")
        _record_learning_inbox(query=query, vision_text=str(slots_dict.get("visible_text") or ""), result=result, reason="vision_generic_only")
        return result

    foreground_tokens = _foreground_identity_tokens(slots_dict, slots)
    identity_hit = product_identity.lookup_exact_identity_candidates(slots)
    if identity_hit.products:
        identity_products, identity_rejected = _filter_candidates(identity_hit.products, slots, allow_missing_form=True)
        if identity_products:
            return _exact_or_clarify(identity_products, slots, "VISION_PRODUCT_IDENTITY_REGISTRY", int((time.perf_counter()-start)*1000), identity_rejected + identity_hit.rejected)

    strict_exact = _strict_normalized_exact_candidates(slots, required_tokens=foreground_tokens)
    strict_exact, strict_rejected = _filter_candidates(strict_exact, slots, allow_missing_form=True)
    if strict_exact:
        return _exact_or_clarify(strict_exact, slots, "VISION_STRICT_NORMALIZED_EXACT_FIRST", int((time.perf_counter()-start)*1000), strict_rejected)

    scoped, rejected, identity_tokens = _vision_scoped_candidates(slots_dict, slots)
    if scoped:
        # Never widen a clear image to same-section products.  If the scoped
        # identity finds one row, return it; if variants/duplicates remain, ask.
        return _exact_or_clarify(scoped, slots, "vision_identity_scope", int((time.perf_counter()-start)*1000), rejected)

    # Clear brand/product identity but no catalog row means NOT_AVAILABLE.
    # Generic image text was already stopped above as LOW_CONFIDENCE.
    if identity_tokens or slots.brand:
        _log_match("NOT_AVAILABLE", matched_stage="vision_identity_scope", reason="clear_identity_missing", query_slots=slots.__dict__, rejected_candidates=rejected[:10], latency_ms=int((time.perf_counter()-start)*1000))
        result = SearchResult("NOT_AVAILABLE", "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا.")
        _record_learning_inbox(query=query, vision_text=str(slots_dict.get("visible_text") or ""), result=result, reason="vision_identity_missing")
        return result

    _log_match("LOW_CONFIDENCE", matched_stage="vision_no_safe_identity", query_slots=slots.__dict__, latency_ms=int((time.perf_counter()-start)*1000))
    return SearchResult("LOW_CONFIDENCE", "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.")
