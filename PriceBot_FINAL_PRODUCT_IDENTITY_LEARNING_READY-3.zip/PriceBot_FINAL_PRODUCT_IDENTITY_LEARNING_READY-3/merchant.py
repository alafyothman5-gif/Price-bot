import html
import os
from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse

import database

router = APIRouter()
MERCHANT_CODE = os.getenv("MERCHANT_CODE", "1234")


def page(body: str) -> str:
    return f"<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><style>body{{font-family:Arial;margin:30px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ddd;padding:8px}}</style></head><body>{body}</body></html>"


@router.get("/merchant/login", response_class=HTMLResponse)
def login():
    return page("<h2>دخول التاجر</h2><form method='post'><input name='code' placeholder='الكود'><button>دخول</button></form>")


@router.post("/merchant/login")
def do_login(code: str = Form(...)):
    if code != MERCHANT_CODE:
        return HTMLResponse(page("كود غير صحيح"), status_code=401)
    return RedirectResponse("/merchant?ok=1", status_code=303)


@router.get("/merchant", response_class=HTMLResponse)
def merchant_home(ok: str = ""):
    if ok != "1":
        return RedirectResponse("/merchant/login", status_code=303)
    orders = database.list_orders("pending", 100)
    rows = "".join(f"<tr><td>{o['id']}</td><td>{html.escape(o['phone'])}</td><td>{html.escape(o['product_name'])}</td><td>{o['quantity']}</td><td>{html.escape(o['price'])}</td></tr>" for o in orders) or "<tr><td colspan='5'>لا توجد طلبات</td></tr>"
    return page(f"<h2>طلبات الصيدلية</h2><p>عدد المنتجات: {database.count_products()}</p><table><tr><th>#</th><th>الهاتف</th><th>المنتج</th><th>الكمية</th><th>السعر</th></tr>{rows}</table>")
