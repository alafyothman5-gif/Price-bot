# PriceBot deploy

This ZIP is code-only. It must not contain `.env`, `pricebot.db`, `venv`, backups, or secrets.

## Clean install

```bash
cd /tmp
unzip PriceBot_FINAL_PRODUCT_IDENTITY_LEARNING_READY.zip
cd PriceBot_FINAL_PRODUCT_IDENTITY_LEARNING_READY
sudo ./clean_install_pricebot.sh
```

The clean installer:

1. Stops `pricebot.service`.
2. Backs up only `.env`, current DB if present, and the systemd unit.
3. Creates `/opt/pricebot_clean`.
4. Copies clean code and `products_master_ready.xlsx`.
5. Copies `.env` from the current PriceBot installation.
6. Builds a temporary DB outside the project directory.
7. Runs Excel import, search index build, guided index build, and product identity registry build.
8. Verifies the temporary DB.
9. Copies the verified DB to `/opt/pricebot_clean/pricebot.db`.
10. Switches `pricebot.service` to `/opt/pricebot_clean`.
11. Starts the service.

No MedMCQ files are touched.

## Verify

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot_clean/pricebot.db --excel-path /opt/pricebot_clean/products_master_ready.xlsx
./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot_clean/pricebot.db
```

## Admin Learning Inbox

```text
/admin/learning?key=ADMIN_KEY
```

Use this page to approve a failed query as an alias or OCR keyword for the correct product. The registry is rebuilt after approval.
