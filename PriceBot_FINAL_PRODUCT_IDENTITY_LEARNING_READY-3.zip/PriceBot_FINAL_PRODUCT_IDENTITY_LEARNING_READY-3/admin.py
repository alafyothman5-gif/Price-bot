import html
import os
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse

import database
try:
    import product_identity
except Exception:
    product_identity = None

router = APIRouter()
ADMIN_KEY = os.getenv("ADMIN_KEY", "change_me")


def _authorized(request: Request) -> bool:
    return request.query_params.get("key") == ADMIN_KEY


def _layout(title: str, body: str) -> str:
    return f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>
<title>{html.escape(title)}</title><style>body{{font-family:Arial,sans-serif;margin:30px;background:#f7f7f7}}table{{border-collapse:collapse;background:white;width:100%}}td,th{{border:1px solid #ddd;padding:8px;vertical-align:top}}.card{{background:white;padding:16px;border-radius:10px;margin-bottom:16px}}input,select,button{{padding:6px;margin:2px}}</style></head><body>{body}</body></html>"""


@router.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request):
    if not _authorized(request):
        return HTMLResponse("Unauthorized", status_code=401)
    products = database.count_products()
    identity_count = database.count_table("product_identity_registry")
    learning_pending = database.count_table("learning_inbox")
    pending = database.list_orders("pending", 50)
    rows = "".join(
        f"<tr><td>{o['id']}</td><td>{html.escape(o['phone'])}</td><td>{html.escape(o['product_name'])}</td><td>{o['quantity']}</td><td>{html.escape(o['price'])}</td><td>{html.escape(o['status'])}</td></tr>"
        for o in pending
    ) or "<tr><td colspan='6'>لا توجد طلبات معلقة</td></tr>"
    key = html.escape(request.query_params.get("key", ""))
    body = f"<div class='card'><h2>لوحة PriceBot</h2><p>عدد المنتجات: {products}</p><p>Product Identity Registry: {identity_count}</p><p>Learning Inbox: <a href='/admin/learning?key={key}'>فتح الصندوق</a> ({learning_pending})</p><p>Integrity: {html.escape(database.integrity_check())}</p></div><div class='card'><h3>الطلبات المعلقة</h3><table><tr><th>#</th><th>الهاتف</th><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الحالة</th></tr>{rows}</table></div>"
    return _layout("PriceBot Admin", body)


@router.get("/admin/learning", response_class=HTMLResponse)
def learning_inbox(request: Request):
    if not _authorized(request):
        return HTMLResponse("Unauthorized", status_code=401)
    key = html.escape(request.query_params.get("key", ""))
    items = database.list_learning_inbox("pending", 100)
    rows = []
    for item in items:
        candidates = html.escape(str(item.get("candidate_products") or ""))[:1000]
        rows.append(f"""
        <tr>
          <td>{item.get('id')}</td>
          <td>{html.escape(item.get('customer_query') or '')}</td>
          <td>{html.escape(item.get('vision_text') or '')[:500]}</td>
          <td>{html.escape(item.get('decision') or '')}<br>{html.escape(item.get('reason') or '')}</td>
          <td><pre>{candidates}</pre></td>
          <td>
            <form method='get' action='/admin/learning/{item.get('id')}/approve'>
              <input type='hidden' name='key' value='{key}' />
              <input name='product_db_id' placeholder='product DB id' />
              <select name='field'><option value='aliases'>alias</option><option value='ocr_keywords'>ocr_keyword</option></select>
              <button type='submit'>اعتماد وتعليم</button>
            </form>
          </td>
        </tr>
        """)
    body = f"""
    <div class='card'><h2>Learning Inbox</h2><p>أي فشل بحث أو صورة غير واثقة يظهر هنا. عند اختيار المنتج الصحيح يتم إضافة alias/OCR keyword ثم إعادة بناء Product Identity Registry.</p></div>
    <table><tr><th>#</th><th>query</th><th>vision text</th><th>decision/reason</th><th>candidates</th><th>admin action</th></tr>{''.join(rows) or "<tr><td colspan='6'>لا توجد عناصر pending</td></tr>"}</table>
    """
    return _layout("Learning Inbox", body)


@router.get("/admin/learning/{learning_id}/approve")
def approve_learning(request: Request, learning_id: int, product_db_id: int, field: str = "aliases"):
    if not _authorized(request):
        return PlainTextResponse("Unauthorized", status_code=401)
    try:
        database.approve_learning_alias(int(learning_id), int(product_db_id), field=field)
        if product_identity:
            product_identity.rebuild_product_identity_registry()
    except Exception as exc:
        return PlainTextResponse(f"failed: {type(exc).__name__}: {exc}", status_code=400)
    key = request.query_params.get("key", "")
    return RedirectResponse(url=f"/admin/learning?key={key}", status_code=303)


@router.post("/admin/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str):
    if not _authorized(request):
        return PlainTextResponse("Unauthorized", status_code=401)
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status)
    return {"ok": True}
