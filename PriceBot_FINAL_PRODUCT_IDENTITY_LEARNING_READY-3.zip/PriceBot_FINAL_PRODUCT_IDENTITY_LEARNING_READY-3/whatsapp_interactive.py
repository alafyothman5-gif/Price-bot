"""WhatsApp Cloud API interactive payload builders.

The app always has a text fallback.  These builders keep secrets out of the
code and only build payloads; sending is handled by app.py.
"""
from __future__ import annotations

from typing import Dict, List


def start_button_payload(to_number: str, body: str) -> Dict:
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "button",
            "body": {"text": body[:1024]},
            "action": {"buttons": [{"type": "reply", "reply": {"id": "START_USE", "title": "ابدأ الاستخدام"}}]},
        },
    }


def main_menu_payload(to_number: str, body: str) -> Dict:
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "list",
            "body": {"text": body[:1024]},
            "action": {
                "button": "اختر",
                "sections": [{
                    "title": "القائمة الرئيسية",
                    "rows": [
                        {"id": "MAIN_SEARCH", "title": "🔎 البحث عن منتج"},
                        {"id": "MAIN_BROWSE", "title": "🗂️ تصفح الأقسام"},
                        {"id": "MAIN_INFO", "title": "ℹ️ معلومات الصيدلية"},
                    ],
                }],
            },
        },
    }


def list_payload(to_number: str, body: str, button: str, title: str, rows: List[Dict[str, str]]) -> Dict:
    safe_rows = []
    for row in rows[:10]:
        safe_rows.append({"id": row.get("id", row.get("title", ""))[:200], "title": row.get("title", "")[:24]})
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "list",
            "body": {"text": body[:1024]},
            "action": {"button": button[:20], "sections": [{"title": title[:24], "rows": safe_rows}]},
        },
    }
