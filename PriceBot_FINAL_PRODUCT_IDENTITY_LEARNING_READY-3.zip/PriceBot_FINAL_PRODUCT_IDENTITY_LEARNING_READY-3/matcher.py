from typing import Dict

from search_engine import ALLOWED_DECISIONS, SearchResult, preload_search_index, search_from_vision_slots, search_product


def match_text(query: str) -> SearchResult:
    result = search_product(query)
    if result.status not in ALLOWED_DECISIONS:
        return SearchResult("LOW_CONFIDENCE", "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل أو أرسل صورة أوضح.")
    return result


def match_vision_slots(slots: Dict[str, object]) -> SearchResult:
    result = search_from_vision_slots(slots)
    if result.status not in ALLOWED_DECISIONS:
        return SearchResult("LOW_CONFIDENCE", "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.")
    return result
