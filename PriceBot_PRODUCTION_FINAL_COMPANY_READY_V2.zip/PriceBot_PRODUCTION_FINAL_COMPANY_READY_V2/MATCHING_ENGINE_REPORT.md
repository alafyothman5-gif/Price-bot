# Matching Engine Report - V2

## Scope
This V2 patch fixes the production blockers found in `PriceBot_PRODUCTION_FINAL_COMPANY_READY.zip` without rebuilding the bot from scratch.

## Critical fixes

### 1. Variant Resolver
Added `services/matching/variant_resolver.py` and called it before product identity exact matching.

It prevents general family/brand queries from returning a direct price when variants exist.

Examples now handled safely:
- `Panadol` -> `ASK_CLARIFICATION`.
- `Flagyl` / `فلاجيل` -> `ASK_CLARIFICATION`.
- `Gaviscon` -> `ASK_CLARIFICATION`.
- `MEBO` -> `ASK_CLARIFICATION` if multiple MEBO products exist.

Exact match is allowed only when enough identity is present, such as:
- `Panadol Advance 500mg 96tab`.
- `Pro-D3 50,000 IU`.
- `MEBO scar`.
- `DEXERYL CREAM`.

### 2. Duplicate price conflict guard
Added `services/matching/duplicate_resolver.py` and integrated duplicate-price protection before final `EXACT_MATCH`.

If the same sellable identity has multiple prices, the bot asks for clarification/review instead of showing the first price.

Verified cases:
- `Flagyl 500mg` -> `ASK_CLARIFICATION`.
- `Janumet 50/1000mg` -> `ASK_CLARIFICATION`.
- `Cipralex 10mg` -> `ASK_CLARIFICATION`.

### 3. Unsafe token fallback removed
The old broad token fallback was restricted.

Rules now enforced:
- No catalog-wide substring scan for short/weak terms.
- `pro` does not match protein/probiotics/Proviron.
- `scar` does not pull unrelated scar products by itself.
- Ranking is scoped to safe brand/family/type identity.
- Unknown weak queries return `LOW_CONFIDENCE` or clarification, not random catalog rows.

### 4. Vision matching hardening
Vision matching now keeps foreground identity and measures when known identity is detected.

Verified cases:
- MEBO Scar image text resolves to `mebo scar`, excluding `First Scar 30g` and `Hemazym`.
- Pro-D3 image with `50,000 IU` resolves to the 50,000 IU variant, not 800 IU.
- Remedica partial image returns `LOW_CONFIDENCE` and asks for a front-view image.

### 5. Cosmetic type safety
Cosmetic alternatives are restricted to the same type. Example:
- `Cerave Hydrating Cleanser` returns cleanser-only alternatives, not lotion/serum/moisturizer.

## Performance/safety notes
- Dynamic synonyms are cached to reduce repeated normalization cost.
- Matching logs can be disabled using `PRICEBOT_MATCH_LOG=0` during tests.
- `search_candidates_by_tokens` no longer performs unsafe broad substring matching.
