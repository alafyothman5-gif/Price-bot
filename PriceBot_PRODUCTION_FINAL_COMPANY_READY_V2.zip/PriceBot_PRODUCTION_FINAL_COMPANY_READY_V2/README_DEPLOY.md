# README_DEPLOY - PriceBot V2

## Files intentionally not included
This release ZIP intentionally excludes:
- `.env`
- `pricebot.db`
- `venv`
- backups
- `__pycache__`
- secrets or API keys

## Required environment
Create/update `.env` on the server only. Do not commit it.

Required values include:
```bash
ADMIN_KEY=<strong random admin password/token>
OPENROUTER_API_KEY=<server only, if vision is enabled>
META_VERIFY_TOKEN=<server only>
META_ACCESS_TOKEN=<server only>
```

`ADMIN_KEY` must be strong. The app refuses weak/default keys such as `change_me`.

## Safe deploy outline
From the project directory on the server:

```bash
sudo systemctl stop pricebot
cp -a /opt/pricebot /opt/pricebot_backup_$(date +%Y%m%d_%H%M%S)
# copy the new code files, keeping server .env and pricebot.db
./venv/bin/python -m py_compile app.py admin.py database.py search_engine.py query_slots.py ui_flow.py
./venv/bin/python tools/import_master_excel.py products_master_ready.xlsx --db-path /opt/pricebot/pricebot.db
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot/pricebot.db
sudo systemctl start pricebot
sudo systemctl status pricebot --no-pager -l
```

## Admin catalog import
The admin panel supports Excel upload/import from the browser:
1. Login through `/admin/login`.
2. Upload Excel from catalog import.
3. Review report.
4. Approve or cancel.

On approve, the app rebuilds registry/search/guided indexes and clears the memory cache.

## Health checks
- `/health`: light health check.
- `/deep-health`: deeper database/index status.
