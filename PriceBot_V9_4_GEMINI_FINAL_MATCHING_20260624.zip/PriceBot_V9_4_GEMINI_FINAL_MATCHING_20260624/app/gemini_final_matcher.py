from __future__ import annotations

import base64
import io
import json
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import httpx

import config_env
from normalizer import normalize_text

try:  # Pillow is already used by vision_service; keep this optional for test/import safety.
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None  # type: ignore


def _log(event: str, **kw: Any) -> None:
    payload: Dict[str, Any] = {"ts": round(time.time(), 3), "event": str(event or "EVENT")}
    for k, v in kw.items():
        key = str(k)
        if any(x in key.lower() for x in ["token", "secret", "authorization", "key"]):
            v = "HIDDEN"
        try:
            json.dumps(v, ensure_ascii=False)
        except Exception:
            v = repr(v)
        payload[key] = v
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), flush=True)


@dataclass
class GeminiFinalDecision:
    decision: str
    selected_product_id: Optional[int] = None
    selected_product_name: str = ""
    confidence: float = 0.0
    reason: str = ""
    raw: Optional[Dict[str, Any]] = None

    @property
    def is_match(self) -> bool:
        return self.decision == "match" and bool(self.selected_product_id) and self.confidence >= 0.85

    @property
    def is_confirmation(self) -> bool:
        return self.decision == "needs_confirmation" and bool(self.selected_product_id)


_GENERIC_WORDS = {
    "mg", "mcg", "g", "gm", "ml", "iu", "tab", "tabs", "tablet", "tablets", "cap", "caps", "capsule", "capsules",
    "syrup", "cream", "creme", "gel", "spray", "drop", "drops", "solution", "oral", "coated", "film", "enteric",
    "pack", "box", "pcs", "piece", "tube", "bottle", "new", "original", "complex", "supplement", "capsules", "capsule",
    "iron", "folic", "acid", "vitamin", "zinc", "collagen", "hyaluronic", "spf", "extract", "formula", "plus",
    "دواء", "الدواء", "علبة", "علبه", "حبوب", "كبسول", "كبسولات", "شراب", "مرهم", "كريم", "جل", "قطرة", "بخاخ",
    "اقراص", "أقراص", "شريط", "حبة", "حبه", "منتج", "المنتج", "سعر", "متوفر", "عندكم",
}


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "base_url": os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").rstrip("/"),
        "model": config_env.openrouter_gemini_model(
            ["OPENROUTER_IMAGE_MATCH_MODEL", "OPENROUTER_TEXT_MODEL", "OPENROUTER_MODEL", "OPENROUTER_VISION_MODEL"],
            default=config_env.GEMINI_DEFAULT_MODEL,
        ),
    }


def _resize_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> tuple[bytes, str]:
    if not image_bytes or Image is None:
        return image_bytes or b"", mime_type or "image/jpeg"
    try:
        with Image.open(io.BytesIO(image_bytes)) as im:
            im = im.convert("RGB")
            max_side = int(os.getenv("PRICEBOT_FINAL_MATCH_IMAGE_MAX_SIDE", "1024") or 1024)
            w, h = im.size
            if max(w, h) > max_side:
                scale = max_side / float(max(w, h))
                im = im.resize((max(1, int(w * scale)), max(1, int(h * scale))))
            out = io.BytesIO()
            im.save(out, format="JPEG", quality=int(os.getenv("PRICEBOT_FINAL_MATCH_IMAGE_JPEG_QUALITY", "86") or 86), optimize=True)
            return out.getvalue(), "image/jpeg"
    except Exception:
        return image_bytes, mime_type or "image/jpeg"


def _safe_json_loads(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        pass
    # Gemini/OpenRouter sometimes wraps JSON in fences. Keep recovery strict and bounded.
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I).strip()
    raw = re.sub(r"\s*```$", "", raw).strip()
    try:
        return json.loads(raw)
    except Exception:
        pass
    m = re.search(r"\{.*\}", raw, flags=re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return {}
    return {}


def _to_int_id(value: Any) -> Optional[int]:
    try:
        if value is None or str(value).strip() == "":
            return None
        return int(float(str(value).strip()))
    except Exception:
        return None


def _to_float(value: Any) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except Exception:
        return 0.0


def candidate_payload(candidates: Sequence[Dict[str, Any]], *, limit: int = 30) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for p in list(candidates or [])[: max(1, int(limit or 30))]:
        pid = _to_int_id(p.get("id") or p.get("product_id"))
        name = str(p.get("canonical_display_name") or p.get("name") or p.get("original_name") or "").strip()
        if not pid or not name or pid in seen:
            continue
        seen.add(pid)
        price = str(p.get("price") or "").strip()
        currency = str(p.get("currency") or "").strip()
        out.append({
            "product_id": pid,
            "name": name[:180],
            "price": (f"{price} {currency}".strip() if price else "")[:80],
            "normalized_name": normalize_text(name)[:180],
        })
    return out


def _validate_decision(data: Dict[str, Any], candidates: Sequence[Dict[str, Any]]) -> GeminiFinalDecision:
    allowed = {int(c["product_id"]): c for c in candidate_payload(candidates, limit=60)}
    decision = str(data.get("decision") or "no_match").strip().lower()
    if decision not in {"match", "no_match", "needs_confirmation"}:
        decision = "no_match"
    pid = _to_int_id(data.get("selected_product_id"))
    confidence = _to_float(data.get("confidence"))
    reason = str(data.get("reason") or "").strip()[:500]
    selected_name = str(data.get("selected_product_name") or "").strip()[:220]

    if pid and pid not in allowed:
        return GeminiFinalDecision("no_match", None, "", 0.0, "Gemini selected a product outside candidates; rejected.", data)

    if pid and not selected_name:
        selected_name = str(allowed.get(pid, {}).get("name") or "")

    if decision == "match" and (not pid or confidence < 0.85):
        decision = "needs_confirmation" if pid else "no_match"

    return GeminiFinalDecision(decision, pid, selected_name, confidence, reason, data)


def identity_tokens(text: Any) -> List[str]:
    n = normalize_text(str(text or ""))
    raw = re.findall(r"[a-zA-Z0-9]+|[\u0600-\u06FF]+", n)
    out: List[str] = []
    seen = set()
    for t in raw:
        token = t.strip().lower()
        if len(token) < 3 or token in _GENERIC_WORDS:
            continue
        if token.isdigit() or re.fullmatch(r"\d+(?:mg|ml|g|gm|mcg|iu)?", token):
            continue
        if token not in seen:
            out.append(token)
            seen.add(token)
    return out[:8]


def _base_prompt() -> str:
    return (
        "You are a strict pharmacy product matcher. Return JSON only. "
        "You must choose only from the provided candidates. Never invent a product. "
        "Allowed output schema exactly: "
        "{\"decision\":\"match|no_match|needs_confirmation\",\"selected_product_id\":\"...\","
        "\"selected_product_name\":\"...\",\"confidence\":0.0,\"reason\":\"...\"}. "
        "Use confidence 0.85 or higher only when the commercial product name clearly matches. "
        "Use needs_confirmation when the likely product is present but strength/pack/variant is ambiguous. "
        "Use no_match when candidates do not contain the main product."
    )


def _image_prompt(extracted: Dict[str, Any], candidates_payload: List[Dict[str, Any]]) -> str:
    compact_extracted = {k: str((extracted or {}).get(k) or "")[:240] for k in [
        "query", "primary_title", "product_name", "product_family", "brand", "form", "strength", "size", "pack",
        "foreground_product_text", "visible_text", "raw_vision_text", "ingredients", "confidence",
    ] if str((extracted or {}).get(k) or "").strip()}
    return (
        _base_prompt()
        + "\nIMAGE RULES:\n"
        + "- Focus on the largest/clearest product in the foreground/center.\n"
        + "- Ignore side products, shelf/background text, and other packages.\n"
        + "- Do not choose ingredients or descriptors as product names.\n"
        + "- Do not choose terms such as Iron Supplement, Folic Acid, Complex, Capsules, Tablet, Syrup, Cream, Gel, or strength values unless they are the visible commercial brand/product name.\n"
        + "- Example rule: if the main commercial title is Hemazym, selecting Folic Acid 500mcg is wrong because it is an ingredient/description, not the product name.\n"
        + "- If multiple products appear and the main product is not clear, return needs_confirmation or no_match.\n"
        + "- A match is valid only when the selected candidate is the main visible product, not a background/side product.\n"
        + "\nVISION_EXTRACTED_JSON:\n"
        + json.dumps(compact_extracted, ensure_ascii=False)
        + "\nCANDIDATES_JSON:\n"
        + json.dumps(candidates_payload, ensure_ascii=False)
    )


def _text_prompt(original_text: str, extracted_queries: Sequence[str], candidates_payload: List[Dict[str, Any]]) -> str:
    return (
        _base_prompt()
        + "\nTEXT RULES:\n"
        + "- The user may write Arabic, Libyan dialect, Arabizi-like spelling, or English.\n"
        + "- Ignore customer words like available, price, do you have, عندكم, متوفر, نبي, سعر.\n"
        + "- Select from candidates only when the intended commercial product name is clear.\n"
        + "- If the text does not specify strength/pack and several candidate variants remain plausible, return needs_confirmation.\n"
        + "- Do not choose a product solely because of a generic ingredient/description.\n"
        + "\nORIGINAL_CUSTOMER_TEXT:\n"
        + str(original_text or "")[:500]
        + "\nEXTRACTED_QUERY_CANDIDATES_JSON:\n"
        + json.dumps(list(extracted_queries or [])[:30], ensure_ascii=False)
        + "\nCANDIDATES_JSON:\n"
        + json.dumps(candidates_payload, ensure_ascii=False)
    )


async def _call_gemini(messages: List[Dict[str, Any]], *, max_tokens: int = 320) -> Dict[str, Any]:
    cfg = _openrouter_config()
    if not cfg["api_key"]:
        raise RuntimeError("missing_openrouter_api_key")
    payload = {
        "model": cfg["model"],
        "messages": messages,
        "temperature": 0,
        "max_tokens": max_tokens,
    }
    # Some OpenRouter/Gemini routes reject response_format. Keep strict JSON in
    # the prompt by default and enable provider-level JSON mode only when asked.
    if str(os.getenv("PRICEBOT_GEMINI_FINAL_MATCH_RESPONSE_FORMAT", "") or "").lower() in {"1", "true", "yes", "on"}:
        payload["response_format"] = {"type": "json_object"}
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    timeout = float(os.getenv("PRICEBOT_GEMINI_FINAL_MATCH_TIMEOUT_SECONDS", "12") or 12)
    max_attempts = int(os.getenv("PRICEBOT_GEMINI_FINAL_MATCH_RETRY_ATTEMPTS", "2") or 2)
    transient_statuses = {408, 409, 425, 429, 500, 502, 503, 504}
    last_error = ""
    async with httpx.AsyncClient(timeout=timeout) as client:
        delay = 0.35
        for attempt in range(1, max_attempts + 1):
            try:
                resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
                if resp.status_code < 400:
                    content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
                    return _safe_json_loads(content)
                last_error = f"http_{resp.status_code}"
                _log("GEMINI_FINAL_MATCH_HTTP_ERROR", attempt=attempt, status=resp.status_code, transient=resp.status_code in transient_statuses)
                if resp.status_code not in transient_statuses:
                    break
            except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError) as exc:
                last_error = type(exc).__name__
                _log("GEMINI_FINAL_MATCH_TRANSIENT_ERROR", attempt=attempt, error=last_error)
            if attempt < max_attempts:
                import asyncio
                await asyncio.sleep(delay)
                delay = min(delay * 2, 3.0)
    raise RuntimeError(last_error or "gemini_final_match_failed")


async def select_image_match(
    *,
    image_bytes: bytes,
    mime_type: str,
    extracted: Dict[str, Any],
    candidates: Sequence[Dict[str, Any]],
) -> GeminiFinalDecision:
    payload_candidates = candidate_payload(candidates, limit=int(os.getenv("PRICEBOT_GEMINI_FINAL_MATCH_CANDIDATE_LIMIT", "30") or 30))
    if not payload_candidates:
        return GeminiFinalDecision("no_match", None, "", 0.0, "No inventory candidates.")
    image_bytes, mime_type = _resize_image(image_bytes, mime_type)
    data_url = f"data:{mime_type or 'image/jpeg'};base64," + base64.b64encode(image_bytes).decode("ascii")
    messages = [{"role": "user", "content": [
        {"type": "text", "text": _image_prompt(extracted or {}, payload_candidates)},
        {"type": "image_url", "image_url": {"url": data_url}},
    ]}]
    try:
        data = await _call_gemini(messages)
    except Exception as exc:
        _log("IMAGE_GEMINI_FINAL_MATCH_ERROR", error=repr(exc))
        return GeminiFinalDecision("no_match", None, "", 0.0, f"Gemini final matcher error: {type(exc).__name__}")
    return _validate_decision(data, payload_candidates)


async def select_text_match(
    *,
    original_text: str,
    extracted_queries: Sequence[str],
    candidates: Sequence[Dict[str, Any]],
) -> GeminiFinalDecision:
    payload_candidates = candidate_payload(candidates, limit=int(os.getenv("PRICEBOT_GEMINI_FINAL_MATCH_CANDIDATE_LIMIT", "30") or 30))
    if not payload_candidates:
        return GeminiFinalDecision("no_match", None, "", 0.0, "No inventory candidates.")
    messages = [{"role": "user", "content": _text_prompt(original_text, extracted_queries, payload_candidates)}]
    try:
        data = await _call_gemini(messages)
    except Exception as exc:
        _log("TEXT_GEMINI_FINAL_MATCH_ERROR", error=repr(exc))
        return GeminiFinalDecision("no_match", None, "", 0.0, f"Gemini final matcher error: {type(exc).__name__}")
    return _validate_decision(data, payload_candidates)
