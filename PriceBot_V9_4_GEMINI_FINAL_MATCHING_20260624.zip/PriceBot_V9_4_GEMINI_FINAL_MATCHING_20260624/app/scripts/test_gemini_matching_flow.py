#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import mimetypes
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Sequence

APP_DIR = Path(__file__).resolve().parents[1]
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

# Import app-level helpers without starting FastAPI workers or sending WhatsApp messages.
import app as pricebot_app  # noqa: E402
import gemini_final_matcher  # noqa: E402
import vision_service  # noqa: E402
from matcher_index import product_name  # noqa: E402
from normalizer import normalize_text  # noqa: E402
from text_query_understanding import extract_product_query_from_customer_text  # noqa: E402

TEXT_CASES = [
    "Hemazym",
    "متوفر عندكم اموكلان",
    "هل عندكم إموكلان؟",
    "عندكم amoclan",
    "نبي سعر فيروكسيل",
    "هل في عندكم فيروكسيل",
    "متوفر عندكم بندول",
    "كم سعر panadol",
    "السلام عليكم عندكم amoclan",
]

SIMULATED_IMAGE_EXTRACTION = {
    "status": "OK",
    "primary_title": "Hemazym",
    "product_name": "Hemazym",
    "foreground_product_text": "Hemazym Folic Acid 500mcg Iron Supplement 30 Capsules",
    "raw_vision_text": "Hemazym Folic Acid 500mcg Iron Supplement 30 Capsules",
    "confidence": "0.94",
    "query": "Hemazym",
}


def _mock_pick_from_candidates(target_text: str, candidates: Sequence[Dict[str, Any]]) -> gemini_final_matcher.GeminiFinalDecision:
    target = normalize_text(target_text).replace(" ", "")
    if not target:
        return gemini_final_matcher.GeminiFinalDecision("no_match", None, "", 0.0, "mock: empty target")
    best = None
    for p in candidates:
        name = product_name(p)
        n = normalize_text(name).replace(" ", "")
        if target and (target in n or n in target):
            best = p
            break
    if best is None:
        # Secondary token overlap, but avoid generic ingredient-only selections.
        target_tokens = gemini_final_matcher.identity_tokens(target_text)
        for p in candidates:
            n = normalize_text(product_name(p)).replace(" ", "")
            if any(t in n for t in target_tokens):
                best = p
                break
    if best is None:
        return gemini_final_matcher.GeminiFinalDecision("no_match", None, "", 0.0, "mock: no candidate matches primary product")
    return gemini_final_matcher.GeminiFinalDecision(
        "match",
        int(best.get("id") or 0),
        product_name(best),
        0.93,
        "mock: final selector chose from retrieved PostgreSQL candidates only",
    )


async def _final_text_decision(text: str, candidates: List[Dict[str, Any]], extracted: List[str], live: bool) -> gemini_final_matcher.GeminiFinalDecision:
    if live:
        return await gemini_final_matcher.select_text_match(original_text=text, extracted_queries=extracted, candidates=candidates)
    for target in list(extracted or []) + [text]:
        decision = _mock_pick_from_candidates(target, candidates)
        if decision.decision != "no_match":
            return decision
    return gemini_final_matcher.GeminiFinalDecision("no_match", None, "", 0.0, "mock: no extracted candidate matched inventory candidates")


async def _final_image_decision(extracted: Dict[str, Any], candidates: List[Dict[str, Any]], image_path: Path | None, live: bool) -> gemini_final_matcher.GeminiFinalDecision:
    if live and image_path is not None:
        data = image_path.read_bytes()
        mime = mimetypes.guess_type(str(image_path))[0] or "image/jpeg"
        return await gemini_final_matcher.select_image_match(image_bytes=data, mime_type=mime, extracted=extracted, candidates=candidates)
    primary = pricebot_app._best_primary_product_text(extracted)
    return _mock_pick_from_candidates(primary, candidates)


async def run_text_tests(live: bool) -> None:
    print("\n=== TEXT FLOW: extraction -> PostgreSQL candidate retrieval -> Gemini final selector ===")
    for text in TEXT_CASES:
        extracted = extract_product_query_from_customer_text(text)
        candidates, queries = await pricebot_app._retrieve_inventory_candidates_from_queries([text], limit=30, log_prefix="TEST_TEXT")
        decision = await _final_text_decision(text, candidates, extracted, live=live) if candidates else gemini_final_matcher.GeminiFinalDecision("no_match", None, "", 0.0, "no candidates")
        print("\nTEXT:", text)
        print("  extracted_candidates:", extracted)
        print("  retrieval_queries:", queries[:8])
        print("  candidate_count:", len(candidates))
        print("  top_candidates:", [product_name(p) for p in candidates[:8]])
        print("  final_decision:", {
            "decision": decision.decision,
            "selected_product_id": decision.selected_product_id,
            "selected_product_name": decision.selected_product_name,
            "confidence": decision.confidence,
            "reason": decision.reason,
        })


async def run_image_test(image_path: Path | None, live: bool, live_vision: bool) -> None:
    print("\n=== IMAGE FLOW: Gemini Vision extraction -> PostgreSQL candidates -> Gemini final selector ===")
    if image_path and live_vision:
        data = image_path.read_bytes()
        mime = mimetypes.guess_type(str(image_path))[0] or "image/jpeg"
        extracted = await vision_service.extract_product_from_image(data, mime)
    else:
        extracted = dict(SIMULATED_IMAGE_EXTRACTION)
    primary = pricebot_app._best_primary_product_text(extracted)
    image_query_inputs = pricebot_app._dedupe_text_queries([primary, pricebot_app._image_evidence_text(extracted)] + pricebot_app._extract_candidate_texts(extracted), limit=35)
    candidates, queries = await pricebot_app._retrieve_inventory_candidates_from_queries(image_query_inputs, limit=30, log_prefix="TEST_IMAGE")
    decision = await _final_image_decision(extracted, candidates, image_path, live=live) if candidates else gemini_final_matcher.GeminiFinalDecision("no_match", None, "", 0.0, "no candidates")
    print("IMAGE:", str(image_path) if image_path else "simulated Hemazym extraction")
    print("  primary_product:", primary)
    print("  extracted:", extracted)
    print("  retrieval_queries:", queries[:8])
    print("  candidate_count:", len(candidates))
    print("  top_candidates:", [product_name(p) for p in candidates[:10]])
    print("  final_decision:", {
        "decision": decision.decision,
        "selected_product_id": decision.selected_product_id,
        "selected_product_name": decision.selected_product_name,
        "confidence": decision.confidence,
        "reason": decision.reason,
    })
    if decision.selected_product_name and "folic" in normalize_text(decision.selected_product_name) and "hemazym" in normalize_text(primary):
        print("  ASSERTION_FAIL: Hemazym primary product was matched to Folic Acid.")
        raise SystemExit(2)


async def main() -> None:
    parser = argparse.ArgumentParser(description="Test V9.4 Gemini final matching flow without sending WhatsApp messages or changing DB.")
    parser.add_argument("--live-gemini", action="store_true", help="Call real Gemini/OpenRouter final selector. Default uses local mock selector for safe offline flow validation.")
    parser.add_argument("--image", type=Path, default=None, help="Optional image file for live image final matching.")
    parser.add_argument("--live-vision", action="store_true", help="With --image, call Gemini Vision extraction instead of simulated extraction.")
    args = parser.parse_args()

    print("V9.4_GEMINI_MATCHING_FINAL test script")
    print("WhatsApp sending: disabled")
    print("Database writes: disabled")
    print("Final selector:", "LIVE Gemini/OpenRouter" if args.live_gemini else "MOCK Gemini-compatible selector")
    if args.live_gemini and not os.getenv("OPENROUTER_API_KEY") and not os.getenv("AI_OPENROUTER_KEYS") and not os.getenv("OPENROUTER_KEY"):
        print("WARNING: no OpenRouter key found; live final selector will return no_match errors.")

    try:
        await pricebot_app.product_index.ensure_fresh()
        print("Loaded available products:", len(pricebot_app.product_index.products))
    except Exception as exc:
        print("ERROR: could not load products from PostgreSQL/local DB:", repr(exc))
        print("Run this script on the server where current PostgreSQL product DB is configured.")
        raise SystemExit(1)

    await run_text_tests(live=args.live_gemini)
    await run_image_test(args.image, live=args.live_gemini, live_vision=args.live_vision)


if __name__ == "__main__":
    asyncio.run(main())
