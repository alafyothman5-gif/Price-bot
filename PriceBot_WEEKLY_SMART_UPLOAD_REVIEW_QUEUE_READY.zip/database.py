import json
import os
import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from normalizer import normalize_text, split_multi, truthy, safe_price

BASE_DIR = Path(__file__).resolve().parent
DATABASE_URL_RAW = (os.getenv("DATABASE_URL") or os.getenv("POSTGRES_DSN") or "").strip()
IS_POSTGRES = DATABASE_URL_RAW.startswith(("postgres://", "postgresql://"))


def _sqlite_path_from_database_url(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    # Accept a direct sqlite path because some deploy/test environments set
    # DATABASE_URL=/tmp/test.sqlite instead of a URL.
    if value.startswith("/") or value.startswith("./") or value.startswith("../"):
        return value
    if value.startswith("sqlite:///"):
        # sqlite:////opt/pricebot/pricebot.db -> /opt/pricebot/pricebot.db
        return value.replace("sqlite:///", "", 1)
    if value.startswith("sqlite://"):
        # sqlite://relative.db -> relative.db
        return value.replace("sqlite://", "", 1)
    return ""


def resolve_db_path(explicit_path: str = "") -> Path:
    """Resolve DB path safely.

    Priority:
    1. explicit_path / --db-path
    2. PRICEBOT_DB_PATH
    3. DATABASE_URL when it is a sqlite path or direct sqlite file path
    4. /opt/pricebot/pricebot.db as the last production fallback

    The resolver intentionally does not default to BASE_DIR/pricebot.db, because
    production ZIPs must never create or carry a database inside the project.
    """
    raw = (explicit_path or "").strip()
    if raw:
        source = "--db-path"
    else:
        raw = (os.getenv("PRICEBOT_DB_PATH") or "").strip()
        if raw:
            source = "PRICEBOT_DB_PATH"
        else:
            raw = _sqlite_path_from_database_url(os.getenv("DATABASE_URL", ""))
            if raw:
                source = "DATABASE_URL"
            else:
                raw = "/opt/pricebot/pricebot.db"
                source = "fallback:/opt/pricebot/pricebot.db"
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    return path.resolve(), source


DB_FILE, DB_PATH_SOURCE = resolve_db_path()
BACKUPS_DIR = DB_FILE.parent / "backups"
READ_ONLY_MODE = False


def set_read_only_mode(enabled: bool = True) -> None:
    global READ_ONLY_MODE
    READ_ONLY_MODE = bool(enabled)


def configure_db_path(path: str) -> None:
    """Override DB path at runtime for safe tools and tests."""
    global DB_FILE, DB_PATH_SOURCE, BACKUPS_DIR
    DB_FILE, DB_PATH_SOURCE = resolve_db_path(path)
    BACKUPS_DIR = DB_FILE.parent / "backups"

PRODUCT_COLUMNS = [
    "merchant_id", "product_id", "identity_key", "name", "normalized_name", "brand", "company", "category", "main_section", "sub_section", "subcategory", "section", "product_family",
    "form", "product_type", "active_ingredient", "strength", "size", "pack", "barcode", "aliases",
    "ocr_keywords", "use_case", "skin_type", "body_area", "age_group", "gender", "medicine_form",
    "medicine_route", "available", "price", "currency", "search_mode", "quality_status", "is_substitutable",
    "substitution_group_id", "review_status", "review_notes", "source_serial", "original_name",
]
TEXT_COLUMNS = {c: "TEXT DEFAULT ''" for c in PRODUCT_COLUMNS}
# SQLite does not allow ALTER TABLE ... ADD COLUMN with non-constant
# defaults such as CURRENT_TIMESTAMP. These timestamp columns are therefore
# added without defaults during migrations. Insert/update code is responsible
# for writing datetime('now'), and init_db backfills old rows idempotently.
TEXT_COLUMNS.update({
    "created_at": "TEXT",
    "updated_at": "TEXT",
})

VISIBLE_REVIEW = {"", "ok", "ready", "approved", "valid"}
VISIBLE_QUALITY = {"", "ok", "ready", "approved", "verified", "partial", "good"}
HIDDEN_SEARCH_MODES = {"review_only", "needs_review", "unknown", "hidden"}
GUIDED_HIDDEN_SEARCH_MODES = HIDDEN_SEARCH_MODES | {"exact_only"}


def _env_true(name: str) -> bool:
    return str(os.getenv(name, "")).strip().lower() in {"1", "true", "yes", "on", "production"}


def _min_products_guard() -> int:
    try:
        return int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000)
    except Exception:
        return 1000


def get_db_path() -> Path:
    return DB_FILE


class CompatRow(dict):
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


def _to_compat_row(row):
    if row is None:
        return None
    if isinstance(row, CompatRow):
        return row
    if isinstance(row, dict):
        return CompatRow(row)
    return row


class PgCursorCompat:
    def __init__(self, cur):
        self.cur = cur
        self.lastrowid = None
        self.rowcount = -1

    def fetchone(self):
        return _to_compat_row(self.cur.fetchone())

    def fetchall(self):
        return [_to_compat_row(r) for r in self.cur.fetchall()]

    def __iter__(self):
        for r in self.cur:
            yield _to_compat_row(r)


class PgConnectionCompat:
    def __init__(self, conn):
        self.conn = conn

    def _translate(self, sql: str, params=None):
        import re
        text = str(sql)
        stripped = text.strip()
        upper = stripped.upper()
        if upper.startswith("PRAGMA"):
            return None, params
        # SQLite DDL compatibility.
        text = text.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
        text = text.replace("AUTOINCREMENT", "")
        # SQLite current-time helpers.
        text = text.replace("datetime('now', ? || ' seconds')", "(CURRENT_TIMESTAMP + (%s || ' seconds')::interval)")
        text = text.replace("datetime('now', ?)", "(CURRENT_TIMESTAMP + (%s)::interval)")
        text = text.replace("datetime('now','+6 hours')", "(CURRENT_TIMESTAMP + interval '6 hours')")
        text = text.replace("datetime('now', '+6 hours')", "(CURRENT_TIMESTAMP + interval '6 hours')")
        text = text.replace("datetime('now')", "CURRENT_TIMESTAMP")
        # INSERT OR IGNORE -> ON CONFLICT DO NOTHING.
        if upper.startswith("INSERT OR IGNORE INTO"):
            text = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT INTO", text, flags=re.I)
            if " ON CONFLICT " not in text.upper():
                text += " ON CONFLICT DO NOTHING"
        # INSERT OR REPLACE is only used for derived indexes. Since callers clear
        # those tables first, plain INSERT is sufficient and avoids SQLite-only syntax.
        if upper.startswith("INSERT OR REPLACE INTO"):
            text = re.sub(r"INSERT\s+OR\s+REPLACE\s+INTO", "INSERT INTO", text, flags=re.I)
        # Placeholder conversion after literal date helper rewrites.
        out = []
        in_single = False
        for ch in text:
            if ch == "'":
                in_single = not in_single
                out.append(ch)
            elif ch == "?" and not in_single:
                out.append("%s")
            else:
                out.append(ch)
        text = "".join(out)
        return text, params

    def execute(self, sql: str, params: Sequence[Any] = ()):  # sqlite-like API
        translated, params = self._translate(sql, params)
        wrapper = PgCursorCompat(self.conn.cursor())
        if translated is None:
            wrapper.rowcount = -1
            return wrapper
        # Add RETURNING id for simple inserts where code expects lastrowid.
        needs_last_id = translated.strip().upper().startswith("INSERT INTO") and "RETURNING" not in translated.upper() and "ON CONFLICT DO NOTHING" not in translated.upper()
        exec_sql = translated + " RETURNING id" if needs_last_id else translated
        try:
            wrapper.cur.execute(exec_sql, params or ())
        except Exception:
            if needs_last_id:
                wrapper.cur.execute(translated, params or ())
            else:
                raise
        wrapper.rowcount = wrapper.cur.rowcount
        try:
            if needs_last_id:
                row = wrapper.cur.fetchone()
                if row:
                    row = _to_compat_row(row)
                    wrapper.lastrowid = row[0]
        except Exception:
            pass
        return wrapper

    def executemany(self, sql: str, seq_of_params):
        translated, _ = self._translate(sql, ())
        wrapper = PgCursorCompat(self.conn.cursor())
        if translated is None:
            return wrapper
        wrapper.cur.executemany(translated, seq_of_params)
        wrapper.rowcount = wrapper.cur.rowcount
        return wrapper

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()


@contextmanager
def connect() -> Iterable[Any]:
    if IS_POSTGRES:
        try:
            import psycopg
            from psycopg.rows import dict_row as pg_dict_row
        except Exception as exc:
            raise RuntimeError("POSTGRES_PRODUCTION_REQUIRES_psycopg_binary") from exc
        if READ_ONLY_MODE:
            # Read-only enforcement is database/role-level for PostgreSQL.
            pass
        conn = psycopg.connect(DATABASE_URL_RAW, row_factory=pg_dict_row, autocommit=False)
        compat = PgConnectionCompat(conn)
        try:
            yield compat
            if not READ_ONLY_MODE:
                compat.commit()
        except Exception:
            if not READ_ONLY_MODE:
                compat.rollback()
            raise
        finally:
            compat.close()
        return

    if READ_ONLY_MODE:
        if not DB_FILE.exists():
            raise FileNotFoundError(f"DB not found for read-only connection: {DB_FILE}")
        uri = f"file:{DB_FILE}?mode=ro"
        conn = sqlite3.connect(uri, timeout=30, uri=True)
    else:
        DB_FILE.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_FILE), timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA foreign_keys=ON")
        if not READ_ONLY_MODE:
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
            except Exception:
                pass
        yield conn
        if not READ_ONLY_MODE:
            conn.commit()
    except Exception:
        if not READ_ONLY_MODE:
            conn.rollback()
        raise
    finally:
        conn.close()


def dict_row(row: Optional[Any]) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    return {k: row[k] for k in row.keys()}


def table_exists(conn: Any, table: str) -> bool:
    if IS_POSTGRES:
        row = conn.execute("SELECT to_regclass(%s) AS exists", (table,)).fetchone()
        return bool(row and row[0])
    return bool(conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def table_columns(conn: Any, table: str) -> List[str]:
    if not table_exists(conn, table):
        return []
    if IS_POSTGRES:
        rows = conn.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s ORDER BY ordinal_position",
            (table,),
        ).fetchall()
        return [str(r[0]) for r in rows]
    return [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()]


def _sqlite_safe_add_column_type(ddl_type: str) -> str:
    """Return an ADD COLUMN-safe declaration for SQLite migrations.

    SQLite rejects ALTER TABLE ... ADD COLUMN when the column has a
    non-constant default such as CURRENT_TIMESTAMP, CURRENT_DATE,
    CURRENT_TIME, or expression defaults. CREATE TABLE may still use those
    defaults, but migrations must not.
    """
    ddl = str(ddl_type or "TEXT").strip() or "TEXT"
    upper = ddl.upper()
    non_constant_defaults = ("CURRENT_TIMESTAMP", "CURRENT_DATE", "CURRENT_TIME")
    if " DEFAULT " in upper and any(token in upper for token in non_constant_defaults):
        before_default = upper.split(" DEFAULT ", 1)[0].strip()
        for affinity in ("INTEGER", "REAL", "NUMERIC", "BLOB", "TEXT"):
            if affinity in before_default.split():
                return affinity
        return "TEXT"
    return ddl


def _pg_column_type(ddl_type: str) -> str:
    ddl = str(ddl_type or "TEXT").strip() or "TEXT"
    ddl = ddl.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
    ddl = ddl.replace("AUTOINCREMENT", "")
    return ddl


def add_column(conn: Any, table: str, col: str, ddl_type: str) -> None:
    if col not in table_columns(conn, table):
        if IS_POSTGRES:
            conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}" {_pg_column_type(ddl_type)}')
        else:
            safe_type = _sqlite_safe_add_column_type(ddl_type)
            conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}" {safe_type}')




def clean_alias_text(value: object, ignore_articles: bool = False) -> str:
    """Clean alias strings for exact alias matching.

    This is intentionally stricter than fuzzy search: lowercase, Unicode/Arabic
    normalization through normalize_text(), punctuation removal, and whitespace
    collapse only.  It does not perform approximate matching.
    """
    text = normalize_text(value)
    if ignore_articles and text:
        text = " ".join(t for t in text.split() if t not in {"the", "a", "an"})
    return " ".join(text.split()).strip()


def ensure_product_aliases_schema(conn: Any) -> None:
    """Create/upgrade product_aliases without touching products.

    Required fields for the uploaded AI alias dictionary are: product_id,
    alias_text, cleaned_alias, confidence, source, active.  Older PriceBot
    builds also used alias/alias_normalized/normalized_alias/is_active, so those
    columns remain available for existing Catalog Ingestion code.
    """
    conn.execute("""
        CREATE TABLE IF NOT EXISTS product_aliases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            alias_text TEXT,
            cleaned_alias TEXT,
            confidence REAL DEFAULT 0.95,
            source TEXT DEFAULT 'ai_generated',
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    for col, ddl in {
        "product_id": "INTEGER",
        "product_db_id": "INTEGER",
        "alias_text": "TEXT",
        "cleaned_alias": "TEXT",
        "confidence": "REAL DEFAULT 0.95",
        "source": "TEXT DEFAULT 'ai_generated'",
        "active": "INTEGER DEFAULT 1",
        "alias": "TEXT DEFAULT ''",
        "alias_normalized": "TEXT",
        "normalized_alias": "TEXT DEFAULT ''",
        "is_active": "INTEGER DEFAULT 1",
        "approved": "INTEGER DEFAULT 1",
        "created_at": "TEXT",
        "updated_at": "TEXT",
    }.items():
        add_column(conn, "product_aliases", col, ddl)
    # Keep old/new column names synchronized for exact lookups.
    try:
        conn.execute("UPDATE product_aliases SET product_db_id=COALESCE(product_db_id, product_id) WHERE product_db_id IS NULL AND product_id IS NOT NULL")
        conn.execute("UPDATE product_aliases SET product_id=COALESCE(product_id, product_db_id) WHERE product_id IS NULL AND product_db_id IS NOT NULL")
        conn.execute("UPDATE product_aliases SET alias_text=COALESCE(NULLIF(alias_text,''), alias) WHERE (alias_text IS NULL OR alias_text='') AND alias<>''")
        conn.execute("UPDATE product_aliases SET alias=COALESCE(NULLIF(alias,''), alias_text) WHERE (alias IS NULL OR alias='') AND alias_text<>''")
        conn.execute("UPDATE product_aliases SET cleaned_alias=COALESCE(NULLIF(cleaned_alias,''), alias_normalized, normalized_alias) WHERE (cleaned_alias IS NULL OR cleaned_alias='')")
        conn.execute("UPDATE product_aliases SET alias_normalized=COALESCE(NULLIF(alias_normalized,''), cleaned_alias, normalized_alias) WHERE (alias_normalized IS NULL OR alias_normalized='')")
        conn.execute("UPDATE product_aliases SET normalized_alias=COALESCE(NULLIF(normalized_alias,''), cleaned_alias, alias_normalized) WHERE (normalized_alias IS NULL OR normalized_alias='')")
        conn.execute("UPDATE product_aliases SET active=COALESCE(active, is_active, approved, 1) WHERE active IS NULL")
        conn.execute("UPDATE product_aliases SET is_active=COALESCE(is_active, active, approved, 1) WHERE is_active IS NULL")
    except Exception:
        pass
    conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_cleaned ON product_aliases(cleaned_alias, active)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_product ON product_aliases(product_id, active)")
    try:
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_product_aliases_ai_active ON product_aliases(product_id, cleaned_alias, source) WHERE active=1")
    except Exception:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_ai_active_nonunique ON product_aliases(product_id, cleaned_alias, source, active)")



def lookup_product_by_alias_exact(texts: Sequence[object], ignore_articles: bool = False) -> Dict[str, Any]:
    """Return one product for exact alias match, or an ambiguity/no-match result.

    The image path uses this only as a confirmation candidate.  It never displays
    price directly from an alias hit.
    """
    cleaned_values = []
    seen = set()
    for value in texts or []:
        clean = clean_alias_text(value, ignore_articles=False)
        if clean and clean not in seen:
            cleaned_values.append(clean); seen.add(clean)
        if ignore_articles:
            clean2 = clean_alias_text(value, ignore_articles=True)
            if clean2 and clean2 not in seen:
                cleaned_values.append(clean2); seen.add(clean2)
    if not cleaned_values:
        return {"status": "NO_MATCH", "cleaned_values": []}
    placeholders = ",".join("?" for _ in cleaned_values)
    with connect() as conn:
        if not table_exists(conn, "product_aliases"):
            return {"status": "NO_MATCH", "cleaned_values": cleaned_values}
        ensure_product_aliases_schema(conn)
        rows = conn.execute(f"""
            SELECT pa.*, p.name AS product_name
            FROM product_aliases pa
            JOIN products p ON p.id = pa.product_id
            WHERE COALESCE(pa.active, pa.is_active, pa.approved, 1)=1
              AND pa.cleaned_alias IN ({placeholders})
            ORDER BY pa.confidence DESC, pa.id ASC
        """, tuple(cleaned_values)).fetchall()
        matches = [dict_row(r) for r in rows if r]
        product_ids = sorted({int(m.get("product_id") or 0) for m in matches if int(m.get("product_id") or 0)})
        if not product_ids:
            return {"status": "NO_MATCH", "cleaned_values": cleaned_values}
        if len(product_ids) > 1:
            return {"status": "AMBIGUOUS", "product_ids": product_ids, "matches": matches, "cleaned_values": cleaned_values}
        product = get_product(product_ids[0])
        if not product:
            return {"status": "NO_MATCH", "cleaned_values": cleaned_values}
        return {"status": "EXACT_ALIAS_MATCH", "product": product, "matches": matches, "cleaned_values": cleaned_values}

def integrity_check() -> str:
    if IS_POSTGRES:
        with connect() as conn:
            conn.execute("SELECT 1")
        return "ok"
    if not DB_FILE.exists():
        return "missing"
    with connect() as conn:
        row = conn.execute("PRAGMA integrity_check").fetchone()
        return str(row[0] if row else "failed")


def validate_production_db_or_fail(min_products: Optional[int] = None) -> None:
    if not (_env_true("PRICEBOT_PRODUCTION_MODE") or _env_true("PRICEBOT_STRICT_DB_STARTUP")):
        return
    min_products = _min_products_guard() if min_products is None else int(min_products)
    if IS_POSTGRES:
        with connect() as conn:
            if not table_exists(conn, "products"):
                raise RuntimeError("PRODUCTION_DB_STARTUP_FAILED | postgres products_table_missing")
            count = conn.execute("SELECT COUNT(*) AS count FROM products").fetchone()[0]
            if int(count) < min_products:
                raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | postgres products={count} | min={min_products}")
        return
    if _env_true("PRICEBOT_REQUIRE_POSTGRES_PRODUCTION"):
        raise RuntimeError("PRODUCTION_REQUIRES_POSTGRES_DATABASE_URL")
    if not DB_FILE.exists():
        raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | db_missing | {DB_FILE}")
    with DB_FILE.open("rb") as fh:
        if fh.read(16) != b"SQLite format 3\x00":
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | not_sqlite | {DB_FILE}")
    with connect() as conn:
        result = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if str(result).lower() != "ok":
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | integrity={result}")
        if not table_exists(conn, "products"):
            raise RuntimeError("PRODUCTION_DB_STARTUP_FAILED | products_table_missing")
        count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count < min_products:
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | products={count} | min={min_products}")


def init_db(run_production_guard: bool = True) -> None:
    if run_production_guard:
        validate_production_db_or_fail()
    with connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL DEFAULT '')")
        for col, ddl in TEXT_COLUMNS.items():
            add_column(conn, "products", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_norm ON products(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_product_id ON products(product_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)")
        # Weekly stock-tracking columns. These are additive only; weekly uploads
        # never delete products and never replace pricebot.db.
        add_column(conn, "products", "is_available", "INTEGER DEFAULT 1")
        add_column(conn, "products", "last_seen_in_upload", "TEXT")
        add_column(conn, "products", "needs_review", "INTEGER DEFAULT 0")
        conn.execute("UPDATE products SET is_available=1 WHERE is_available IS NULL")
        conn.execute("UPDATE products SET needs_review=0 WHERE needs_review IS NULL")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_merchant ON products(merchant_id, available)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_weekly_stock ON products(merchant_id, is_available, needs_review)")

        # AI/generated product aliases used by Vision confirmation.
        # This table is additive and safe for existing deployments: no product
        # rows are deleted or rewritten, and legacy alias columns are preserved
        # for Catalog Ingestion compatibility.
        ensure_product_aliases_schema(conn)
        # Idempotent timestamp backfill for old/existing product rows after
        # SQLite-safe ADD COLUMN migrations. No DROP/DELETE is used.
        product_cols = set(table_columns(conn, "products"))
        if "created_at" in product_cols:
            conn.execute("UPDATE products SET created_at=datetime('now') WHERE created_at IS NULL OR created_at=''")
        if "updated_at" in product_cols:
            conn.execute("UPDATE products SET updated_at=datetime('now') WHERE updated_at IS NULL OR updated_at=''")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_search_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL,
                kind TEXT NOT NULL,
                product_db_id INTEGER NOT NULL,
                weight INTEGER DEFAULT 0,
                UNIQUE(key, kind, product_db_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_index_key ON product_search_index(key)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS guided_catalog_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                main_section TEXT NOT NULL,
                sub_section TEXT DEFAULT '',
                product_type TEXT DEFAULT '',
                use_case TEXT DEFAULT '',
                skin_type TEXT DEFAULT '',
                body_area TEXT DEFAULT '',
                age_group TEXT DEFAULT '',
                visible INTEGER DEFAULT 1,
                sort_name TEXT DEFAULT '',
                UNIQUE(product_db_id, main_section, sub_section, skin_type)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_guided_main ON guided_catalog_index(main_section, sub_section, visible)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversation_state (
                phone TEXT PRIMARY KEY,
                state_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            )
        """)
        add_column(conn, "conversation_state", "created_at", "TEXT")
        add_column(conn, "conversation_state", "expires_at", "TEXT")
        conn.execute("UPDATE conversation_state SET created_at=COALESCE(NULLIF(created_at,''), datetime('now')) WHERE created_at IS NULL OR created_at=''")
        conn.execute("UPDATE conversation_state SET expires_at=datetime('now','+6 hours') WHERE expires_at IS NULL OR expires_at=''")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT NOT NULL,
                product_db_id INTEGER,
                product_name TEXT DEFAULT '',
                quantity INTEGER DEFAULT 1,
                price TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        for col, ddl in {
            "merchant_id": "INTEGER DEFAULT 1",
            "customer_name": "TEXT DEFAULT ''",
            "notes": "TEXT DEFAULT ''",
        }.items():
            add_column(conn, "orders", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_orders_merchant_status ON orders(merchant_id, status, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS search_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER,
                product_name TEXT DEFAULT '',
                user_id TEXT DEFAULT '',
                source TEXT DEFAULT 'whatsapp_confirmation',
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_logs_product_time ON search_logs(merchant_id, product_id, timestamp)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_logs_time ON search_logs(timestamp)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_upload_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                filename TEXT DEFAULT '',
                products_count INTEGER DEFAULT 0,
                backup_path TEXT DEFAULT '',
                status TEXT DEFAULT 'success',
                message TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_upload_history_time ON product_upload_history(merchant_id, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS upload_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                upload_time TEXT DEFAULT CURRENT_TIMESTAMP,
                filename TEXT DEFAULT '',
                total_rows INTEGER DEFAULT 0,
                new_products INTEGER DEFAULT 0,
                updated_products INTEGER DEFAULT 0,
                deactivated_products INTEGER DEFAULT 0,
                review_products INTEGER DEFAULT 0,
                status TEXT DEFAULT 'success',
                message TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_upload_history_time ON upload_history(merchant_id, upload_time)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS review_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_name TEXT DEFAULT '',
                similar_existing_id INTEGER,
                temp_product_id INTEGER,
                uploaded_price TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                resolved INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                resolved_at TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_review_queue_status ON review_queue(merchant_id, resolved, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS processed_messages (
                message_id TEXT PRIMARY KEY,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS dynamic_synonyms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                target TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(source, target)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_dynamic_synonyms_source ON dynamic_synonyms(source, enabled)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS image_product_cache (
                image_hash TEXT PRIMARY KEY,
                media_id TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                confidence TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_image_cache_media ON image_product_cache(media_id)")


        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_identity_registry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                product_id TEXT DEFAULT '',
                identity_key TEXT NOT NULL,
                canonical_name TEXT DEFAULT '',
                normalized_name TEXT DEFAULT '',
                compact_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                aliases TEXT DEFAULT '',
                ocr_keywords TEXT DEFAULT '',
                category TEXT DEFAULT '',
                search_policy TEXT DEFAULT 'sellable_exact',
                duplicate_group TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_norm ON product_identity_registry(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_compact ON product_identity_registry(compact_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_barcode ON product_identity_registry(barcode)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_brand_family ON product_identity_registry(brand, product_family)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_key ON product_identity_registry(identity_key)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS learning_inbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_query TEXT DEFAULT '',
                vision_text TEXT DEFAULT '',
                candidate_products TEXT DEFAULT '[]',
                decision TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                admin_action TEXT DEFAULT '',
                selected_product_id INTEGER,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_learning_inbox_status ON learning_inbox(status, created_at)")
        # Idempotent schema upgrades for production learning/catalog/admin safety.
        for col, ddl in {
            "image_id": "TEXT DEFAULT ''",
            "media_id": "TEXT DEFAULT ''",
            "raw_vision_text": "TEXT DEFAULT ''",
            "main_visible_product": "TEXT DEFAULT ''",
            "background_text": "TEXT DEFAULT ''",
            "query_slots": "TEXT DEFAULT '{}'",
            "rejected_candidates": "TEXT DEFAULT '[]'",
            "created_by": "TEXT DEFAULT ''",
            "merchant_id": "INTEGER DEFAULT 1",
        }.items():
            add_column(conn, "learning_inbox", col, ddl)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                actor TEXT DEFAULT '',
                ip TEXT DEFAULT '',
                details TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_admin_audit_event ON admin_audit_log(event, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                role TEXT DEFAULT 'owner',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_roles (
                role TEXT PRIMARY KEY,
                permissions TEXT DEFAULT '[]',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_hash TEXT UNIQUE NOT NULL,
                username TEXT DEFAULT 'owner',
                role TEXT DEFAULT 'owner',
                ip TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            )
        """)
        for _role, _perms in {
            'owner': ['*'],
            'admin': ['catalog:*', 'learning:*', 'orders:*', 'users:*', 'merchants:*'],
            'pharmacist': ['learning:*', 'orders:*', 'products:edit', 'catalog:upload'],
            'viewer': ['read:*'],
        }.items():
            conn.execute("INSERT OR IGNORE INTO admin_roles(role, permissions) VALUES(?, ?)", (_role, json.dumps(_perms)))
        add_column(conn, "admin_users", "merchant_id", "INTEGER DEFAULT 1")
        add_column(conn, "admin_users", "password_salt", "TEXT DEFAULT ''")
        add_column(conn, "admin_users", "password_hash", "TEXT DEFAULT ''")
        add_column(conn, "admin_users", "display_name", "TEXT DEFAULT ''")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS merchants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL DEFAULT '',
                slug TEXT UNIQUE DEFAULT '',
                whatsapp_number TEXT DEFAULT '',
                phone_number_id TEXT DEFAULT '',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("INSERT OR IGNORE INTO merchants(id, name, slug, whatsapp_number, active) VALUES(1, ?, 'default', '', 1)", (os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),))

        # Self-Learning Visual Overlay tables. These are derived layers only;
        # they do not edit products or the source Excel.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS visual_product_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                image_signature TEXT NOT NULL,
                canonical_name TEXT NOT NULL,
                excel_name TEXT NOT NULL,
                product_id INTEGER,
                brand TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                confidence INTEGER DEFAULT 1,
                last_seen_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            )
        """)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_visual_signature ON visual_product_memory(merchant_id, image_signature)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_visual_product_memory_product ON visual_product_memory(product_id, confidence)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_identity_overlay (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                original_excel_name TEXT NOT NULL,
                normalized_excel_name TEXT NOT NULL,
                brand TEXT,
                canonical_name TEXT NOT NULL,
                form TEXT,
                strength TEXT,
                size TEXT,
                pack TEXT,
                source TEXT DEFAULT 'auto_learned',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            )
        """)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_overlay_unique ON product_identity_overlay(merchant_id, normalized_excel_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_overlay_active ON product_identity_overlay(merchant_id, is_active, brand, form, strength, size)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS merchant_settings (
                merchant_id INTEGER PRIMARY KEY,
                pharmacy_name TEXT DEFAULT '',
                whatsapp_number TEXT DEFAULT '',
                qr_message TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_review_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                merchant_id INTEGER DEFAULT 1,
                issue_type TEXT DEFAULT '',
                severity TEXT DEFAULT 'review',
                row_json TEXT DEFAULT '{}',
                duplicate_key TEXT DEFAULT '',
                price_old TEXT DEFAULT '',
                price_new TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_review_job ON catalog_review_items(job_id, status, issue_type)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_import_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT DEFAULT '',
                staging_db_path TEXT DEFAULT '',
                status TEXT DEFAULT 'uploaded',
                added INTEGER DEFAULT 0,
                updated INTEGER DEFAULT 0,
                duplicate_conflicts INTEGER DEFAULT 0,
                needs_review INTEGER DEFAULT 0,
                unclassified INTEGER DEFAULT 0,
                missing_form_strength_size INTEGER DEFAULT 0,
                report_text TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_import_status ON catalog_import_jobs(status, created_at)")
        for col, ddl in {
            "job_type": "TEXT DEFAULT ''",
            "started_at": "TEXT",
            "finished_at": "TEXT",
            "error_text": "TEXT DEFAULT ''",
            "merchant_id": "INTEGER DEFAULT 1",
            "requires_approval": "INTEGER DEFAULT 1",
            "verified": "INTEGER DEFAULT 0",
            "acceptance_passed": "INTEGER DEFAULT 0",
            "approval_user": "TEXT DEFAULT ''",
            "approved_at": "TEXT",
        }.items():
            add_column(conn, "catalog_import_jobs", col, ddl)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_import_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                report_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Preferred name requested by the production spec. Keep the old
        # image_product_cache table for backward compatibility.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS image_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                image_hash TEXT UNIQUE,
                media_id TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                confidence TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_image_cache_media ON image_cache(media_id)")


def backup_db(label: str = "manual") -> Path:
    if IS_POSTGRES:
        # PostgreSQL production imports are transactional.  This marker records
        # the migration/import point without pretending to create a SQLite file.
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        marker = BACKUPS_DIR / f"postgres_transactional_backup_marker_{label}_{stamp}.txt"
        marker.write_text("PostgreSQL import uses transaction rollback plus migrated source backup.\n", encoding="utf-8")
        return marker
    if not DB_FILE.exists():
        raise FileNotFoundError(f"DB not found: {DB_FILE}")
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = BACKUPS_DIR / f"pricebot_{label}_{stamp}.db"
    src = sqlite3.connect(str(DB_FILE), timeout=30)
    dst = sqlite3.connect(str(backup), timeout=30)
    try:
        src.backup(dst)
    finally:
        src.close(); dst.close()
    return backup


def restore_db_from_backup(backup_path: Path) -> None:
    if IS_POSTGRES:
        raise RuntimeError("POSTGRES_RESTORE_USES_DATABASE_BACKUP_TOOLING_NOT_SQLITE_COPY")
    backup_path = Path(backup_path)
    if not backup_path.exists():
        raise FileNotFoundError(str(backup_path))
    test = sqlite3.connect(str(backup_path), timeout=10)
    try:
        res = test.execute("PRAGMA integrity_check").fetchone()[0]
        if str(res).lower() != "ok":
            raise RuntimeError(f"backup integrity failed: {res}")
    finally:
        test.close()
    if DB_FILE.exists():
        emergency = backup_db("before_restore")
        print(f"PRE_RESTORE_BACKUP={emergency}")
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(backup_path, DB_FILE)


def audit(event: str, details: Any = None) -> None:
    try:
        payload = json.dumps(details or {}, ensure_ascii=False, default=str)
        with connect() as conn:
            if table_exists(conn, "audit_logs"):
                conn.execute("INSERT INTO audit_logs(event, details) VALUES(?, ?)", (event, payload))
            if table_exists(conn, "admin_audit_log"):
                conn.execute("INSERT INTO admin_audit_log(event, details) VALUES(?, ?)", (event, payload))
    except Exception:
        pass

def audit_admin(event: str, actor: str = "admin", ip: str = "", details: Any = None) -> None:
    try:
        payload = json.dumps(details or {}, ensure_ascii=False, default=str)
        with connect() as conn:
            conn.execute("INSERT INTO admin_audit_log(event, actor, ip, details) VALUES(?,?,?,?)", (event, actor, ip, payload))
    except Exception:
        pass


def _name_not_garbage(name: object) -> bool:
    n = normalize_text(name)
    if len(n) < 2:
        return False
    # Pure 1-2 digit fragments and obvious placeholders are not sellable by search.
    if n in {"unknown", "غير معروف", "غير مصنف", "none", "null", "na"}:
        return False
    return True


def product_visible(product: Dict[str, Any], guided: bool = False) -> bool:
    """Return whether a product can be shown to customers.

    Exact search is allowed for sellable rows from the final Excel even if
    review_status is still needs_review. Guided browsing stays stricter: it
    requires usable category/subcategory so unclassified items do not pollute
    commercial menus.
    """
    if not truthy(product.get("available")):
        return False
    if not str(product.get("price") or "").strip():
        return False
    if not _name_not_garbage(product.get("name") or product.get("original_name")):
        return False

    quality = normalize_text(product.get("quality_status"))
    review = normalize_text(product.get("review_status"))
    search_mode = normalize_text(product.get("search_mode"))

    if review in {"unknown", "stale_hidden", "hidden"}:
        return False
    if quality in {"unknown", "bad", "invalid", "hidden"}:
        return False
    if search_mode in (GUIDED_HIDDEN_SEARCH_MODES if guided else HIDDEN_SEARCH_MODES):
        return False

    if guided:
        cat = normalize_text(product.get("category") or product.get("main_section") or product.get("section"))
        sub = normalize_text(product.get("subcategory") or product.get("sub_section") or product.get("section") or product.get("product_type"))
        if cat in {"", "unknown", "غير معروف", "غير مصنف"}:
            return False
        if sub in {"", "unknown", "unclassified", "غير معروف", "غير مصنف"}:
            return False
    return True


def count_products() -> int:
    with connect() as conn:
        if not table_exists(conn, "products"):
            return 0
        return int(conn.execute("SELECT COUNT(*) FROM products").fetchone()[0])


def count_table(table: str) -> int:
    with connect() as conn:
        if not table_exists(conn, table):
            return 0
        return int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])


def get_product(product_db_id: int) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        row = conn.execute("SELECT * FROM products WHERE id=?", (int(product_db_id),)).fetchone()
        return dict_row(row)


def load_product_rows(limit: Optional[int] = None, visible_only: bool = False, guided: bool = False) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM products ORDER BY name COLLATE NOCASE"
    if limit:
        sql += f" LIMIT {int(limit)}"
    with connect() as conn:
        rows = [dict_row(r) for r in conn.execute(sql).fetchall()]
    rows = [r for r in rows if r]
    if visible_only:
        rows = [r for r in rows if product_visible(r, guided=guided)]
    return rows


def find_by_exact_index(key: str, kinds: Sequence[str]) -> List[Dict[str, Any]]:
    if not key:
        return []
    placeholders = ",".join("?" for _ in kinds)
    with connect() as conn:
        rows = conn.execute(f"""
            SELECT p.*, i.kind, i.weight
            FROM product_search_index i
            JOIN products p ON p.id = i.product_db_id
            WHERE i.key=? AND i.kind IN ({placeholders})
            ORDER BY i.weight DESC, p.name COLLATE NOCASE
            LIMIT 30
        """, (key, *kinds)).fetchall()
        return [dict_row(r) for r in rows]


def search_candidates_by_tokens(query_tokens: Sequence[str], limit: int = 20) -> List[Dict[str, Any]]:
    """Safe legacy token lookup.

    Compatibility path only. It rejects weak single tokens and never performs
    a broad 10k substring scan across the whole catalog.
    """
    clean = [normalize_text(t) for t in query_tokens if normalize_text(t)]
    clean = [t for t in clean if t and (len(t) >= 4 or any(ch.isdigit() for ch in t))]
    if not clean:
        return []
    if len(clean) == 1 and clean[0] in {"pro", "scar", "tab", "cap", "syr", "supp", "d"}:
        return []
    with connect() as conn:
        rows = conn.execute("""
            SELECT * FROM products
            WHERE available IS NOT NULL
            ORDER BY name COLLATE NOCASE
            LIMIT 2000
        """).fetchall()
        out = []
        for row in rows:
            p = dict_row(row)
            if not product_visible(p, guided=False):
                continue
            hay = normalize_text(" ".join(str(p.get(c) or "") for c in ["name", "aliases", "brand", "product_family", "active_ingredient", "form", "strength", "size", "barcode"]))
            hay_words = set(hay.split())
            hay_compact = hay.replace(" ", "")
            if all(t in hay_words or (len(t) >= 5 and t in hay_compact) for t in clean):
                name_words = set(normalize_text(p.get("name")).split())
                score = sum(10 for t in clean if t in name_words) + sum(4 for t in clean if t in hay_words)
                p["_score"] = score
                out.append(p)
        out.sort(key=lambda x: (-int(x.get("_score") or 0), str(x.get("name") or "")))
        return out[:limit]



def replace_product_identity_registry(entries: List[Tuple]) -> int:
    """Replace identity registry atomically from the current products table.

    Does not touch the products table.  It only refreshes the derived identity
    layer used by exact-first matching.
    """
    with connect() as conn:
        conn.execute("DELETE FROM product_identity_registry")
        conn.executemany("""
            INSERT OR REPLACE INTO product_identity_registry(
                product_db_id, product_id, identity_key, canonical_name, normalized_name, compact_name,
                brand, product_family, form, strength, size, pack, barcode, aliases, ocr_keywords,
                category, search_policy, duplicate_group, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
        """, entries)
        return int(conn.execute("SELECT COUNT(*) FROM product_identity_registry").fetchone()[0])


def load_product_identity_registry() -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "product_identity_registry"):
            return []
        rows = conn.execute("SELECT * FROM product_identity_registry ORDER BY canonical_name COLLATE NOCASE").fetchall()
        return [dict_row(r) for r in rows if r]


def identity_registry_count() -> int:
    return count_table("product_identity_registry")


def get_products_by_ids(ids: Sequence[int]) -> List[Dict[str, Any]]:
    clean = []
    for value in ids:
        try:
            clean.append(int(value))
        except Exception:
            pass
    if not clean:
        return []
    placeholders = ",".join("?" for _ in clean)
    with connect() as conn:
        rows = conn.execute(f"SELECT * FROM products WHERE id IN ({placeholders})", tuple(clean)).fetchall()
        by_id = {int(r["id"]): dict_row(r) for r in rows}
        return [by_id[i] for i in clean if i in by_id]


def record_learning_event(customer_query: str = "", vision_text: str = "", candidate_products: Any = None, decision: str = "", reason: str = "", image_id: str = "", media_id: str = "", main_visible_product: str = "", background_text: str = "", query_slots: Any = None, rejected_candidates: Any = None) -> int:
    candidate_products = candidate_products or []
    rejected_candidates = rejected_candidates or []
    query_slots = query_slots or {}
    try:
        payload = json.dumps(candidate_products, ensure_ascii=False, default=str)
    except Exception:
        payload = "[]"
    try:
        slots_payload = json.dumps(query_slots, ensure_ascii=False, default=str)
    except Exception:
        slots_payload = "{}"
    try:
        rejected_payload = json.dumps(rejected_candidates, ensure_ascii=False, default=str)
    except Exception:
        rejected_payload = "[]"
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO learning_inbox(
                customer_query, vision_text, raw_vision_text, candidate_products, decision, reason, status,
                image_id, media_id, main_visible_product, background_text, query_slots, rejected_candidates
            ) VALUES(?,?,?,?,? ,?,'pending',?,?,?,?,?,?)
        """, (
            str(customer_query or "")[:1000], str(vision_text or "")[:2000], str(vision_text or "")[:2000],
            payload[:5000], str(decision or "")[:80], str(reason or "")[:500],
            str(image_id or "")[:200], str(media_id or "")[:200], str(main_visible_product or "")[:500],
            str(background_text or "")[:1000], slots_payload[:4000], rejected_payload[:4000],
        ))
        return int(cur.lastrowid)


def list_learning_inbox(status: str = "pending", limit: int = 100) -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "learning_inbox"):
            return []
        rows = conn.execute("SELECT * FROM learning_inbox WHERE status=? ORDER BY id DESC LIMIT ?", (status, int(limit))).fetchall()
        return [dict_row(r) for r in rows if r]


def append_product_alias_or_ocr(product_db_id: int, value: str, field: str = "aliases") -> None:
    field = "ocr_keywords" if field == "ocr_keywords" else "aliases"
    value = str(value or "").strip()
    if not value:
        return
    with connect() as conn:
        row = conn.execute(f"SELECT {field} FROM products WHERE id=?", (int(product_db_id),)).fetchone()
        if not row:
            raise ValueError("product_not_found")
        existing = str(row[0] or "")
        parts = [x.strip() for x in existing.replace(";", "|").replace(",", "|").split("|") if x.strip()]
        if value not in parts:
            parts.append(value)
        conn.execute(f"UPDATE products SET {field}=?, updated_at=datetime('now') WHERE id=?", (" | ".join(parts), int(product_db_id)))


def approve_learning_alias(learning_id: int, product_db_id: int, field: str = "aliases") -> None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM learning_inbox WHERE id=?", (int(learning_id),)).fetchone()
        if not row:
            raise ValueError("learning_event_not_found")
        d = dict_row(row)
    learned = (d.get("customer_query") or d.get("vision_text") or "").strip()
    append_product_alias_or_ocr(int(product_db_id), learned, field=field)
    with connect() as conn:
        conn.execute("""
            UPDATE learning_inbox
            SET admin_action=?, selected_product_id=?, status='approved', updated_at=datetime('now')
            WHERE id=?
        """, (f"add_{field}", int(product_db_id), int(learning_id)))




def update_learning_status(learning_id: int, status: str, action: str = "") -> None:
    with connect() as conn:
        conn.execute("UPDATE learning_inbox SET status=?, admin_action=?, updated_at=datetime('now') WHERE id=?", (status, action or status, int(learning_id)))

def create_catalog_import_job(filename: str, staging_db_path: str, status: str = "uploaded", report_text: str = "") -> int:
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO catalog_import_jobs(filename, staging_db_path, status, report_text, created_at, updated_at)
            VALUES(?,?,?,?,datetime('now'),datetime('now'))
        """, (filename, staging_db_path, status, report_text))
        return int(cur.lastrowid)

def update_catalog_import_job(job_id: int, **fields: Any) -> None:
    allowed = {"status", "added", "updated", "duplicate_conflicts", "needs_review", "unclassified", "missing_form_strength_size", "report_text", "staging_db_path", "job_type", "started_at", "finished_at", "error_text", "merchant_id", "requires_approval", "verified", "acceptance_passed", "approval_user", "approved_at"}
    clean = {k: v for k, v in fields.items() if k in allowed}
    if not clean:
        return
    assignments = ", ".join(f"{k}=?" for k in clean) + ", updated_at=datetime('now')"
    with connect() as conn:
        conn.execute(f"UPDATE catalog_import_jobs SET {assignments} WHERE id=?", (*clean.values(), int(job_id)))

def list_catalog_import_jobs(limit: int = 30) -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "catalog_import_jobs"):
            return []
        rows = conn.execute("SELECT * FROM catalog_import_jobs ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict_row(r) for r in rows if r]

def get_catalog_import_job(job_id: int) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "catalog_import_jobs"):
            return None
        return dict_row(conn.execute("SELECT * FROM catalog_import_jobs WHERE id=?", (int(job_id),)).fetchone())

def cleanup_old_runtime_rows(days: int = 30) -> Dict[str, int]:
    stats: Dict[str, int] = {}
    with connect() as conn:
        if table_exists(conn, "processed_messages"):
            cur = conn.execute("DELETE FROM processed_messages WHERE created_at < datetime('now', ?)", (f"-{int(days)} days",))
            stats["processed_messages_deleted"] = int(cur.rowcount or 0)
        if table_exists(conn, "conversation_state"):
            cur = conn.execute("DELETE FROM conversation_state WHERE expires_at IS NOT NULL AND expires_at < datetime('now')")
            stats["conversation_state_deleted"] = int(cur.rowcount or 0)
        for table in ["image_product_cache", "image_cache"]:
            if table_exists(conn, table):
                cur = conn.execute(f"DELETE FROM {table} WHERE updated_at < datetime('now', ?)", (f"-{int(days)} days",))
                stats[f"{table}_deleted"] = int(cur.rowcount or 0)
        if table_exists(conn, "learning_inbox"):
            cur = conn.execute("DELETE FROM learning_inbox WHERE status IN ('approved','ignored','not_in_catalog') AND updated_at < datetime('now', '-90 days')")
            stats["learning_inbox_archived_deleted"] = int(cur.rowcount or 0)
    return stats

def find_identity_registry(kind: str, key: str, limit: int = 80) -> List[Dict[str, Any]]:
    key = normalize_text(key)
    if not key or not table_exists_safe("product_identity_registry"):
        return []
    compact = key.replace(" ", "")
    with connect() as conn:
        if kind == "barcode":
            rows = conn.execute("SELECT * FROM product_identity_registry WHERE barcode=? LIMIT ?", (key, int(limit))).fetchall()
        elif kind == "normalized_name":
            rows = conn.execute("SELECT * FROM product_identity_registry WHERE normalized_name=? LIMIT ?", (key, int(limit))).fetchall()
        elif kind == "compact_name":
            rows = conn.execute("SELECT * FROM product_identity_registry WHERE compact_name=? LIMIT ?", (compact or key, int(limit))).fetchall()
        elif kind == "brand_family":
            toks = [t for t in key.split() if t]
            if len(toks) >= 2:
                brand, fam = toks[0], " ".join(toks[1:])
                rows = conn.execute("""
                    SELECT * FROM product_identity_registry
                    WHERE brand=? AND (product_family=? OR product_family LIKE ? OR normalized_name LIKE ? OR aliases LIKE ?)
                    LIMIT ?
                """, (brand, fam, f"%{fam}%", f"%{brand}%{fam}%", f"%{brand}%{fam}%", int(limit))).fetchall()
            else:
                rows = []
        else:
            # aliases and ocr_keywords are normalized pipe-separated blobs.  LIKE
            # is used only inside the exact-first identity registry, then product
            # slots still pass form/strength/size verification in search_engine.
            col = "ocr_keywords" if kind == "ocr_keyword" else "aliases"
            rows = conn.execute(f"""
                SELECT * FROM product_identity_registry
                WHERE {col}=? OR {col} LIKE ? OR {col} LIKE ? OR {col} LIKE ?
                LIMIT ?
            """, (key, f"%| {key}%", f"%{key} |%", f"%{key}%", int(limit))).fetchall()
        return [dict_row(r) for r in rows if r]


def table_exists_safe(table: str) -> bool:
    try:
        with connect() as conn:
            return table_exists(conn, table)
    except Exception:
        return False


def replace_search_index(entries: List[Tuple[str, str, int, int]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM product_search_index")
        conn.executemany("INSERT OR IGNORE INTO product_search_index(key, kind, product_db_id, weight) VALUES(?,?,?,?)", entries)
        return int(conn.execute("SELECT COUNT(*) FROM product_search_index").fetchone()[0])


def replace_guided_index(entries: List[Tuple[int, str, str, str, str, str, str, str, int, str]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM guided_catalog_index")
        conn.executemany("""
            INSERT OR IGNORE INTO guided_catalog_index(
                product_db_id, main_section, sub_section, product_type, use_case, skin_type, body_area, age_group, visible, sort_name
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
        """, entries)
        return int(conn.execute("SELECT COUNT(*) FROM guided_catalog_index").fetchone()[0])


def guided_products(main_section: str, sub_section: str = "", skin_type: str = "", page: int = 0, page_size: int = 10) -> List[Dict[str, Any]]:
    params: List[Any] = [main_section]
    filters = "g.visible=1 AND g.main_section=?"
    if sub_section:
        filters += " AND g.sub_section=?"
        params.append(sub_section)
    if skin_type:
        filters += " AND (g.skin_type=? OR g.skin_type='' OR g.skin_type='unknown')"
        params.append(skin_type)
    params.extend([int(page_size), int(page) * int(page_size)])
    with connect() as conn:
        rows = conn.execute(f"""
            SELECT p.*, g.main_section, g.sub_section, g.skin_type AS guided_skin_type
            FROM guided_catalog_index g
            JOIN products p ON p.id = g.product_db_id
            WHERE {filters}
            ORDER BY g.sort_name COLLATE NOCASE
            LIMIT ? OFFSET ?
        """, params).fetchall()
        out = []
        for row in rows:
            p = dict_row(row)
            if p and product_visible(p, guided=True):
                out.append(p)
        return out


def guided_count(main_section: str, sub_section: str = "") -> int:
    params: List[Any] = [main_section]
    filters = "visible=1 AND main_section=?"
    if sub_section:
        filters += " AND sub_section=?"
        params.append(sub_section)
    with connect() as conn:
        return int(conn.execute(f"SELECT COUNT(*) FROM guided_catalog_index WHERE {filters}", params).fetchone()[0])


def _state_ttl_seconds() -> int:
    try:
        return int(os.getenv("PRICEBOT_STATE_TTL_SECONDS", "21600") or 21600)
    except Exception:
        return 21600


def cleanup_expired_states() -> int:
    with connect() as conn:
        if not table_exists(conn, "conversation_state"):
            return 0
        cols = set(table_columns(conn, "conversation_state"))
        if "expires_at" not in cols:
            return 0
        cur = conn.execute("DELETE FROM conversation_state WHERE expires_at IS NOT NULL AND expires_at!='' AND expires_at < datetime('now')")
        return int(cur.rowcount or 0)


def get_state(phone: str) -> Dict[str, Any]:
    with connect() as conn:
        if not table_exists(conn, "conversation_state"):
            return {}
        cols = set(table_columns(conn, "conversation_state"))
        if "expires_at" in cols:
            row = conn.execute("SELECT state_json, expires_at FROM conversation_state WHERE phone=?", (phone,)).fetchone()
            if not row:
                return {}
            expires_at = str(row[1] or "")
            if expires_at:
                expired = conn.execute("SELECT CASE WHEN ? < datetime('now') THEN 1 ELSE 0 END", (expires_at,)).fetchone()[0]
                if int(expired or 0):
                    conn.execute("DELETE FROM conversation_state WHERE phone=?", (phone,))
                    return {}
            payload = row[0]
        else:
            row = conn.execute("SELECT state_json FROM conversation_state WHERE phone=?", (phone,)).fetchone()
            if not row:
                return {}
            payload = row[0]
        try:
            state = json.loads(payload or "{}")
            return state if isinstance(state, dict) else {}
        except Exception:
            return {}


def set_state(phone: str, state: Dict[str, Any]) -> None:
    payload = json.dumps(state or {}, ensure_ascii=False)
    ttl = _state_ttl_seconds()
    with connect() as conn:
        cols = set(table_columns(conn, "conversation_state"))
        if "expires_at" in cols and "created_at" in cols:
            conn.execute("""
                INSERT INTO conversation_state(phone, state_json, created_at, updated_at, expires_at)
                VALUES(?, ?, datetime('now'), datetime('now'), datetime('now', ? || ' seconds'))
                ON CONFLICT(phone) DO UPDATE SET
                    state_json=excluded.state_json,
                    updated_at=datetime('now'),
                    expires_at=datetime('now', ? || ' seconds')
            """, (phone, payload, str(ttl), str(ttl)))
        else:
            conn.execute("""
                INSERT INTO conversation_state(phone, state_json, updated_at) VALUES(?,?,datetime('now'))
                ON CONFLICT(phone) DO UPDATE SET state_json=excluded.state_json, updated_at=datetime('now')
            """, (phone, payload))


def clear_state(phone: str) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM conversation_state WHERE phone=?", (phone,))


def mark_processed(message_id: str) -> bool:
    if not message_id:
        return True
    try:
        with connect() as conn:
            conn.execute("INSERT INTO processed_messages(message_id) VALUES(?)", (message_id,))
        return True
    except sqlite3.IntegrityError:
        return False


def default_merchant_id() -> int:
    try:
        return int(os.getenv("PRICEBOT_DEFAULT_MERCHANT_ID", "1") or 1)
    except Exception:
        return 1


def create_order(phone: str, product: Dict[str, Any], quantity: int = 1, merchant_id: Optional[int] = None) -> int:
    quantity = max(1, int(quantity or 1))
    mid = int(merchant_id or product.get("merchant_id") or default_merchant_id())
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO orders(merchant_id, phone, product_db_id, product_name, quantity, price, status)
            VALUES(?,?,?,?,?,?,'pending')
        """, (mid, phone, product.get("id"), product.get("name") or "", quantity, safe_price(product.get("price"))))
        return int(cur.lastrowid)


def list_orders(status: str = "pending", limit: int = 100, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders WHERE merchant_id=? AND status=? ORDER BY id DESC LIMIT ?", (mid, status, int(limit))).fetchall()
        return [dict_row(r) for r in rows]


def recent_orders_for_phone(phone: str, limit: int = 5, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders WHERE merchant_id=? AND phone=? ORDER BY id DESC LIMIT ?", (mid, phone, int(limit))).fetchall()
        return [dict_row(r) for r in rows]


def update_order_status(order_id: int, status: str, merchant_id: Optional[int] = None) -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        conn.execute("UPDATE orders SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND merchant_id=?", (status, int(order_id), mid))




def record_search_log(product_id: int, product_name: str = "", user_id: str = "", merchant_id: Optional[int] = None, source: str = "whatsapp_confirmation") -> None:
    """Record a successful user-confirmed product lookup for merchant analytics."""
    try:
        pid = int(product_id or 0)
    except Exception:
        pid = 0
    if not pid:
        return
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "search_logs"):
            return
        conn.execute(
            """
            INSERT INTO search_logs(merchant_id, product_id, product_name, user_id, source, timestamp)
            VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
            """,
            (mid, pid, str(product_name or "")[:500], str(user_id or "")[:100], str(source or "whatsapp_confirmation")[:100]),
        )


def top_searched_products(days: int = 7, limit: int = 10, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """Return top confirmed products from search_logs for dashboard statistics."""
    mid = int(merchant_id or default_merchant_id())
    days = max(1, int(days or 7))
    limit = max(1, min(50, int(limit or 10)))
    with connect() as conn:
        if not table_exists(conn, "search_logs"):
            return []
        rows = conn.execute(
            """
            SELECT s.product_id AS product_id, COALESCE(NULLIF(s.product_name,''), p.name, '') AS product_name, COUNT(*) AS hits
            FROM search_logs s
            LEFT JOIN products p ON p.id=s.product_id
            WHERE s.merchant_id=? AND s.timestamp >= datetime('now', ?)
            GROUP BY s.product_id, COALESCE(NULLIF(s.product_name,''), p.name, '')
            ORDER BY hits DESC, product_name COLLATE NOCASE
            LIMIT ?
            """,
            (mid, f"-{days} days", limit),
        ).fetchall()
        return [dict_row(r) for r in rows]


def record_product_upload(filename: str, products_count: int, backup_path: str = "", status: str = "success", message: str = "", merchant_id: Optional[int] = None) -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "product_upload_history"):
            return
        conn.execute(
            """
            INSERT INTO product_upload_history(merchant_id, filename, products_count, backup_path, status, message, created_at)
            VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
            """,
            (mid, str(filename or "")[:300], int(products_count or 0), str(backup_path or "")[:1000], str(status or "")[:50], str(message or "")[:1000]),
        )


def list_product_upload_history(limit: int = 5, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        limit_i = int(limit or 5)
        if table_exists(conn, "upload_history"):
            rows = conn.execute(
                """
                SELECT id, filename, total_rows AS products_count, status, message, upload_time AS created_at,
                       new_products, updated_products, deactivated_products, review_products
                FROM upload_history
                WHERE merchant_id=?
                ORDER BY id DESC
                LIMIT ?
                """,
                (mid, limit_i),
            ).fetchall()
            return [dict_row(r) for r in rows]
        if not table_exists(conn, "product_upload_history"):
            return []
        rows = conn.execute(
            "SELECT * FROM product_upload_history WHERE merchant_id=? ORDER BY id DESC LIMIT ?",
            (mid, limit_i),
        ).fetchall()
        return [dict_row(r) for r in rows]


def record_weekly_upload_history(
    *,
    filename: str,
    total_rows: int,
    new_products: int,
    updated_products: int,
    deactivated_products: int,
    review_products: int,
    status: str = "success",
    message: str = "",
    merchant_id: Optional[int] = None,
) -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if table_exists(conn, "upload_history"):
            conn.execute(
                """
                INSERT INTO upload_history(merchant_id, filename, total_rows, new_products, updated_products, deactivated_products, review_products, status, message, upload_time)
                VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                """,
                (mid, str(filename or "")[:300], int(total_rows or 0), int(new_products or 0), int(updated_products or 0), int(deactivated_products or 0), int(review_products or 0), str(status or "")[:50], str(message or "")[:1000]),
            )
        # Keep the previous dashboard table populated for backwards compatibility.
        if table_exists(conn, "product_upload_history"):
            conn.execute(
                """
                INSERT INTO product_upload_history(merchant_id, filename, products_count, backup_path, status, message, created_at)
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                """,
                (mid, str(filename or "")[:300], int(total_rows or 0), "", str(status or "")[:50], str(message or "")[:1000]),
            )


def list_review_queue(limit: int = 50, merchant_id: Optional[int] = None, include_resolved: bool = False) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "review_queue"):
            return []
        where = "rq.merchant_id=?" if include_resolved else "rq.merchant_id=? AND COALESCE(rq.resolved,0)=0"
        rows = conn.execute(
            f"""
            SELECT rq.*, p.name AS similar_existing_name, tp.name AS temp_product_name
            FROM review_queue rq
            LEFT JOIN products p ON p.id=rq.similar_existing_id
            LEFT JOIN products tp ON tp.id=rq.temp_product_id
            WHERE {where}
            ORDER BY rq.id DESC
            LIMIT ?
            """,
            (mid, int(limit or 50)),
        ).fetchall()
        return [dict_row(r) for r in rows]


def count_review_queue(merchant_id: Optional[int] = None) -> int:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "review_queue"):
            return 0
        return int(conn.execute("SELECT COUNT(*) FROM review_queue WHERE merchant_id=? AND COALESCE(resolved,0)=0", (mid,)).fetchone()[0])


def resolve_review_queue_item(item_id: int, action: str, existing_product_id: Optional[int] = None, merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    action = str(action or "").strip().lower()
    with connect() as conn:
        row = conn.execute("SELECT * FROM review_queue WHERE id=? AND merchant_id=?", (int(item_id), mid)).fetchone()
        item = dict_row(row)
        if not item:
            raise ValueError("review item not found")
        temp_id = int(item.get("temp_product_id") or 0)
        if action == "approve_new":
            if not temp_id:
                raise ValueError("review item has no temporary product")
            conn.execute(
                """
                UPDATE products SET needs_review=0, is_available=1, review_status='approved', search_mode='sellable', quality_status='ok', updated_at=datetime('now')
                WHERE id=? AND merchant_id=?
                """,
                (temp_id, mid),
            )
        elif action == "delete":
            if temp_id:
                conn.execute(
                    "UPDATE products SET is_available=0, needs_review=1, search_mode='hidden', review_status='hidden', updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (temp_id, mid),
                )
        elif action == "link_existing":
            target_id = int(existing_product_id or item.get("similar_existing_id") or 0)
            if not target_id:
                raise ValueError("existing product id is required")
            uploaded_price = str(item.get("uploaded_price") or "").strip()
            if uploaded_price:
                conn.execute(
                    "UPDATE products SET price=?, is_available=1, needs_review=0, review_status='approved', search_mode='sellable', last_seen_in_upload=datetime('now'), updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (safe_price(uploaded_price), target_id, mid),
                )
            else:
                conn.execute(
                    "UPDATE products SET is_available=1, needs_review=0, review_status='approved', search_mode='sellable', last_seen_in_upload=datetime('now'), updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (target_id, mid),
                )
            if temp_id:
                conn.execute(
                    "UPDATE products SET is_available=0, needs_review=1, search_mode='hidden', review_status='hidden', updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (temp_id, mid),
                )
        else:
            raise ValueError("unsupported review action")
        conn.execute("UPDATE review_queue SET resolved=1, resolved_at=CURRENT_TIMESTAMP WHERE id=? AND merchant_id=?", (int(item_id), mid))
        return item


def get_merchant(merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        row = conn.execute("SELECT * FROM merchants WHERE id=?", (mid,)).fetchone()
        return dict_row(row) or {"id": mid, "name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"), "whatsapp_number": os.getenv("BOT_WHATSAPP_NUMBER", "")}


def get_merchant_settings(merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "merchant_settings"):
            return get_merchant(mid)
        row = conn.execute("SELECT * FROM merchant_settings WHERE merchant_id=?", (mid,)).fetchone()
        data = dict_row(row) or {}
        merchant = get_merchant(mid)
        return {**merchant, **data, "merchant_id": mid}


def update_merchant_settings(merchant_id: int, pharmacy_name: str = "", whatsapp_number: str = "", qr_message: str = "") -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        conn.execute("""
            INSERT INTO merchant_settings(merchant_id, pharmacy_name, whatsapp_number, qr_message, updated_at)
            VALUES(?,?,?,?,datetime('now'))
            ON CONFLICT(merchant_id) DO UPDATE SET
                pharmacy_name=excluded.pharmacy_name, whatsapp_number=excluded.whatsapp_number,
                qr_message=excluded.qr_message, updated_at=datetime('now')
        """, (mid, str(pharmacy_name or ""), str(whatsapp_number or ""), str(qr_message or "")))
        conn.execute("UPDATE merchants SET name=COALESCE(NULLIF(?,''), name), whatsapp_number=COALESCE(NULLIF(?,''), whatsapp_number), updated_at=datetime('now') WHERE id=?", (str(pharmacy_name or ""), str(whatsapp_number or ""), mid))


def create_catalog_review_item(job_id: int, row: Dict[str, Any], issue_type: str, duplicate_key: str = "", price_old: str = "", price_new: str = "", merchant_id: Optional[int] = None, severity: str = "review") -> int:
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO catalog_review_items(job_id, merchant_id, issue_type, severity, row_json, duplicate_key, price_old, price_new, status)
            VALUES(?,?,?,?,?,?,?,?, 'pending')
        """, (int(job_id or 0), int(merchant_id or default_merchant_id()), issue_type, severity, json.dumps(row or {}, ensure_ascii=False, default=str), duplicate_key, str(price_old or ""), str(price_new or "")))
        return int(cur.lastrowid)


def list_catalog_review_items(job_id: Optional[int] = None, status: str = "pending", limit: int = 200) -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "catalog_review_items"):
            return []
        if job_id:
            rows = conn.execute("SELECT * FROM catalog_review_items WHERE job_id=? AND status=? ORDER BY id DESC LIMIT ?", (int(job_id), status, int(limit))).fetchall()
        else:
            rows = conn.execute("SELECT * FROM catalog_review_items WHERE status=? ORDER BY id DESC LIMIT ?", (status, int(limit))).fetchall()
        return [dict_row(r) for r in rows if r]


def get_image_cache(image_hash: str = "", media_id: str = "") -> Optional[Dict[str, Any]]:
    if not image_hash and not media_id:
        return None
    with connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if not table_exists(conn, table):
                continue
            if image_hash:
                row = conn.execute(f"SELECT * FROM {table} WHERE image_hash=?", (image_hash,)).fetchone()
            else:
                row = conn.execute(f"SELECT * FROM {table} WHERE media_id=? ORDER BY updated_at DESC LIMIT 1", (media_id,)).fetchone()
            found = dict_row(row)
            if found:
                return found
        return None


def clear_image_cache() -> int:
    """Clear stored image-to-product decisions after Learning Inbox approvals."""
    deleted = 0
    with connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if not table_exists(conn, table):
                continue
            try:
                cur = conn.execute(f"DELETE FROM {table}")
                deleted += int(cur.rowcount or 0)
            except Exception:
                continue
    return deleted


def set_image_cache(image_hash: str, media_id: str, extracted_slots: Dict[str, Any], matched_product_id: Optional[int], decision: str, confidence: str = "") -> None:
    if not image_hash:
        return
    payload = json.dumps(extracted_slots or {}, ensure_ascii=False)
    with connect() as conn:
        for table in ["image_product_cache", "image_cache"]:
            if not table_exists(conn, table):
                continue
            conn.execute(
                f"""
                INSERT INTO {table}(image_hash, media_id, extracted_slots, matched_product_id, decision, confidence, created_at, updated_at)
                VALUES(?,?,?,?,?,?,datetime('now'),datetime('now'))
                ON CONFLICT(image_hash) DO UPDATE SET
                    media_id=excluded.media_id,
                    extracted_slots=excluded.extracted_slots,
                    matched_product_id=excluded.matched_product_id,
                    decision=excluded.decision,
                    confidence=excluded.confidence,
                    updated_at=datetime('now')
                """,
                (image_hash, media_id or "", payload, matched_product_id, decision or "", confidence or ""),
            )


# cleanup_old_runtime_rows defined above with image/cache cleanup

