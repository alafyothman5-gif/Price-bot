#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%F_%H-%M-%S)"
BACKUP_DIR="$APP_DIR/backups/names-product-organizer-$STAMP"
cd "$APP_DIR"
echo "===== Backup current catalog UI ====="
mkdir -p "$BACKUP_DIR"
cp -a catalog_web.py "$BACKUP_DIR/catalog_web.py" 2>/dev/null || true
mkdir -p "$BACKUP_DIR/static"
cp -a static/badr_logo.png "$BACKUP_DIR/static/badr_logo.png" 2>/dev/null || true

echo "===== Check Python syntax ====="
python3 -m py_compile "$SRC_DIR/catalog_web.py"

echo "===== Install cleaned names + organized products UI ====="
mkdir -p "$APP_DIR/static"
cp -a "$SRC_DIR/catalog_web.py" "$APP_DIR/catalog_web.py"
cp -a "$SRC_DIR/badr_logo.png" "$APP_DIR/static/badr_logo.png"

echo "===== Ensure catalog router is included ====="
python3 - <<'PY'
from pathlib import Path
p = Path('/opt/pricebot_clean/app.py')
s = p.read_text(encoding='utf-8')
changed = False
if 'import catalog_web' not in s and 'from catalog_web import router as catalog_router' not in s:
    marker = 'import merchant\n'
    if marker in s:
        s = s.replace(marker, marker + 'import catalog_web\n', 1)
    else:
        s = 'import catalog_web\n' + s
    changed = True
if 'app.include_router(catalog_web.router)' not in s:
    marker = 'app.include_router(merchant.router)'
    if marker in s:
        s = s.replace(marker, 'app.include_router(catalog_web.router)\n' + marker, 1)
    else:
        s += '\n# Catalog website router\napp.include_router(catalog_web.router)\n'
    changed = True
if changed:
    p.write_text(s, encoding='utf-8')
print('router ok')
PY

echo "===== Restart PriceBot only ====="
sudo systemctl restart pricebot.service
sleep 8

echo "===== Health ====="
curl -s http://127.0.0.1:8090/catalog-health || true
echo ""
echo "DONE. Open: https://46.101.148.246.sslip.io/catalog?v=names2"
echo "Backup saved to: $BACKUP_DIR"
