#!/usr/bin/env bash
set -euo pipefail
echo "=== health ==="
curl -s http://127.0.0.1:8090/catalog-health || true
echo ""
echo "=== sample catalog html checks ==="
curl -s 'http://127.0.0.1:8090/catalog?v=names2' | grep -Eio 'Aspirin|Parol|Panadol|CeraVe|Rilastil|منتجات مميزة' | head -n 20 || true
echo ""
echo "=== service ==="
sudo systemctl status pricebot.service --no-pager -l | head -n 25
