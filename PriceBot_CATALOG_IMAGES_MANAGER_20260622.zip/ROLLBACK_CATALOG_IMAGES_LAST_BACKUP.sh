#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
cd "$APP_DIR"
LAST_BACKUP="$(ls -td backups/catalog-images-* 2>/dev/null | head -n 1 || true)"
if [ -z "$LAST_BACKUP" ]; then
  echo "No catalog-images backup found"
  exit 1
fi

echo "Restoring from: $LAST_BACKUP"
cp -a "$LAST_BACKUP/catalog_web.py" "$APP_DIR/catalog_web.py" 2>/dev/null || true
# Do not restore pricebot.db automatically to avoid deleting images uploaded after backup.
# Restore DB manually only if specifically needed:
# cp -a "$LAST_BACKUP/pricebot.db" "$APP_DIR/pricebot.db"
sudo systemctl restart pricebot.service
sleep 6
curl -s http://127.0.0.1:8090/catalog-health || true
