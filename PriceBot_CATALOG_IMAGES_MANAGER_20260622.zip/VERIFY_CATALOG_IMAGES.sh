#!/usr/bin/env bash
set -euo pipefail
cd /opt/pricebot_clean

echo "===== Service ====="
sudo systemctl status pricebot.service --no-pager -l | head -n 25 || true

echo "===== DB image column ====="
sqlite3 pricebot.db "PRAGMA table_info(products);" | grep -E 'catalog_image_url|image_url|photo_url' || true

echo "===== Image files ====="
ls -lah static/catalog_images 2>/dev/null | head -n 30 || echo "No catalog_images folder"

echo "===== Health ====="
curl -s http://127.0.0.1:8090/catalog-health || true

echo ""
echo "Open: https://46.101.148.246.sslip.io/merchant/catalog-images"
