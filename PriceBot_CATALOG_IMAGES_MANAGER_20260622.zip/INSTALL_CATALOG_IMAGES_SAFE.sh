#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/pricebot_clean"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$APP_DIR/backups/catalog-images-$(date +%F_%H-%M-%S)"

echo "===== Backup current files/database ====="
mkdir -p "$BACKUP_DIR"
cd "$APP_DIR"
cp -a catalog_web.py "$BACKUP_DIR/catalog_web.py" 2>/dev/null || true
cp -a pricebot.db "$BACKUP_DIR/pricebot.db"
if [ -d static/catalog_images ]; then
  mkdir -p "$BACKUP_DIR/static"
  cp -a static/catalog_images "$BACKUP_DIR/static/catalog_images"
fi

echo "===== Check Python syntax ====="
python3 -m py_compile "$SCRIPT_DIR/catalog_web.py"

echo "===== Install catalog image manager ====="
mkdir -p "$APP_DIR/static/catalog_images"
cp -a "$SCRIPT_DIR/catalog_web.py" "$APP_DIR/catalog_web.py"

echo "===== Add catalog_image_url column if missing ====="
python3 - <<'PY'
import os, sqlite3
from pathlib import Path
app = Path('/opt/pricebot_clean')
db = app / 'pricebot.db'
conn = sqlite3.connect(str(db), timeout=20)
try:
    cols = {row[1] for row in conn.execute('PRAGMA table_info(products)').fetchall()}
    if 'catalog_image_url' not in cols:
        conn.execute('ALTER TABLE products ADD COLUMN catalog_image_url TEXT')
        conn.commit()
        print('Added column: catalog_image_url')
    else:
        print('Column already exists: catalog_image_url')
finally:
    conn.close()
PY

echo "===== Restart PriceBot only ====="
sudo systemctl restart pricebot.service
sleep 6

echo "===== Catalog health ====="
curl -s http://127.0.0.1:8090/catalog-health || true

echo ""
echo "DONE. Open image manager: https://46.101.148.246.sslip.io/merchant/catalog-images"
echo "Catalog: https://46.101.148.246.sslip.io/catalog?v=img1"
echo "Backup saved to: $BACKUP_DIR"
