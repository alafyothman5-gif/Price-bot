from __future__ import annotations

"""Celery catalog workers.

Run with:
  celery -A celery_app.celery_app worker -Q catalog --loglevel=INFO
"""

from services.catalog.staging_workflow import create_and_verify_staging_job

try:
    from celery_app import celery_app
except Exception:  # pragma: no cover
    celery_app = None


if celery_app is not None:
    @celery_app.task(name="pricebot.catalog.stage_import", queue="catalog")
    def catalog_stage_import(job_id: int, excel_path: str, merchant_id: int = 1):
        return create_and_verify_staging_job(int(job_id), str(excel_path), int(merchant_id or 1))
else:
    def catalog_stage_import(job_id: int, excel_path: str, merchant_id: int = 1):
        return create_and_verify_staging_job(int(job_id), str(excel_path), int(merchant_id or 1))
