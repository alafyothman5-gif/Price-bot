from __future__ import annotations

try:
    from celery_app import celery_app
except Exception:  # pragma: no cover
    celery_app = None


if celery_app is not None:
    @celery_app.task(name="pricebot.text.process", queue="text", acks_late=True)
    def process_text_message(payload: dict):
        return {"queued": True, "type": "text", "payload_id": (payload or {}).get("id", "")}
else:
    def process_text_message(payload: dict):
        return {"queued": True, "type": "text", "payload_id": (payload or {}).get("id", "")}
