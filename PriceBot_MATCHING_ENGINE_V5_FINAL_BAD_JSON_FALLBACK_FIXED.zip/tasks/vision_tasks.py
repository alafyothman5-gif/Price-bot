from __future__ import annotations

"""Celery vision worker entrypoint.

The FastAPI webhook should return 200 immediately. Vision messages can be routed
here by deployments that enable PRICEBOT_USE_CELERY=1.
"""

try:
    from celery_app import celery_app
except Exception:  # pragma: no cover
    celery_app = None


if celery_app is not None:
    @celery_app.task(name="pricebot.vision.process", queue="vision", acks_late=True)
    def process_vision_message(payload: dict):
        # Worker-side adapter placeholder. Production deployments should import
        # the same service processor used by routes/whatsapp.py. Kept isolated so
        # app.py does not block webhook acknowledgement on Vision AI.
        return {"queued": True, "type": "vision", "payload_id": (payload or {}).get("id", "")}
else:
    def process_vision_message(payload: dict):
        return {"queued": True, "type": "vision", "payload_id": (payload or {}).get("id", "")}
