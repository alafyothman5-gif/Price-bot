# Clean Architecture Report

Added enterprise layers:

```text
routes/
services/
repositories/
tasks/
templates/
static/
```

Business operations moved or wrapped into services/tasks:

- catalog staging workflow: `services/catalog/staging_workflow.py`
- catalog import workers: `tasks/catalog_tasks.py`
- vision queue worker: `tasks/vision_tasks.py`
- text queue worker: `tasks/text_tasks.py`
- CSRF service: `services/security/csrf.py`

Legacy URLs remain for compatibility, but the V4 structure is ready for continued decomposition without changing external endpoints.
