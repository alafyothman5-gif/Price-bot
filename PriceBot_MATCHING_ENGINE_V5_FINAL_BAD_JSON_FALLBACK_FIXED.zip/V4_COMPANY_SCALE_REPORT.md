# PriceBot ENTERPRISE PREMIUM UI V4 COMPANY SCALE Report

Version: `PriceBot_ENTERPRISE_PREMIUM_UI_V4_COMPANY_SCALE_READY`

## Implemented Requirements

### 1. Staging Workflow
Excel upload no longer writes directly to production from the Admin or Merchant portals.

Workflow:

`Excel Upload -> Staging DB -> Smart Upsert in staging -> Verify -> Acceptance Report -> Approve/Cancel`

Production is changed only by explicit admin approval through `/admin/catalog/{job_id}/approve`.

### 2. Conservative Deduplication
Automatic dedupe was changed from broad identity merge to exact duplicate merge only.

Allowed automatic merge requires same:

- normalized product name
- brand/company
- product family
- form
- strength
- size
- pack
- barcode
- price

Price conflicts are not resolved automatically. They are written to `catalog_review_items` with `issue_type=price_conflict` and `severity=blocking`. Jobs with blocking conflicts become `requires_review` instead of `ready_for_approval`.

### 3. Redis/Celery Workers
Real Celery queues are defined:

- `catalog`
- `vision`
- `text`

Files:

- `celery_app.py`
- `tasks/catalog_tasks.py`
- `tasks/vision_tasks.py`
- `tasks/text_tasks.py`

Webhook acknowledgement remains immediate. `PRICEBOT_USE_CELERY=1` routes work to Redis/Celery; otherwise it safely falls back to the in-process queue.

### 4. Multi-Merchant Isolation
Core tables now include merchant ownership fields:

- `products.merchant_id`
- `orders.merchant_id`
- `learning_inbox.merchant_id`
- `catalog_import_jobs.merchant_id`
- `catalog_review_items.merchant_id`
- `admin_users.merchant_id`

Merchant routes use `merchant_id` filters when reading or updating orders/products.

### 5. Full Merchant Portal
Merchant portal now includes:

- dashboard
- orders page
- QR & Link page
- merchant settings for WhatsApp number and QR message
- merchant Excel upload to staging
- learning inbox view
- product price edit page

### 6. RBAC + CSRF + Audit
Admin includes:

- `/admin/users` for user/role management
- `/admin/audit` for audit logs
- CSRF protection on POST forms
- `admin_audit_log` entries for critical actions

### 7. Clean Architecture Direction
New structure added:

- `routes/`
- `services/`
- `repositories/`
- `tasks/`

Webhook and admin architecture facade routes are present while preserving backward-compatible legacy URLs.

### 8. Tests and Verification
Executed checks:

- Python compile check for all `.py` files
- Jinja template parse check
- App import check
- Existing matching acceptance tests: PASS 17
- Safe matching acceptance tests: PASS 83
- Staging workflow test: PASS
- Queue/load enqueue simulation: PASS 100 text + 50 vision queued
