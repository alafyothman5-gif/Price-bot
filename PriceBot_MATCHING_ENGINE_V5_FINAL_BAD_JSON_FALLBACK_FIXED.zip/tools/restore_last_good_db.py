#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import database


def main() -> int:
    p = argparse.ArgumentParser(description="Restore a selected DB from a backup file.")
    p.add_argument("backup", nargs="?", default="", help="Backup DB file. If omitted, uses latest in selected DB backups directory.")
    p.add_argument("--db-path", default="", help="Target SQLite DB path to restore into.")
    args = p.parse_args()
    if args.db_path:
        database.configure_db_path(args.db_path)
    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"TARGET_DB_PATH={database.get_db_path()}")
    if args.backup:
        backup = Path(args.backup)
    else:
        backups = sorted(database.BACKUPS_DIR.glob("pricebot_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not backups:
            raise SystemExit("NO_BACKUP_FOUND")
        backup = backups[0]
    database.restore_db_from_backup(backup)
    print(f"RESTORE_OK from={backup} to={database.get_db_path()}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
