#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from collections import Counter

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from services.catalog.pricelist_converter import MASTER_COLUMNS, read_raw_openpyxl, read_raw_xls


def parse_args():
    p = argparse.ArgumentParser(description="Convert original pharmacy PriceList.xls/xlsx into PriceBot products_master_ready.xlsx")
    p.add_argument("input_excel")
    p.add_argument("--out", default="products_master_ready.xlsx")
    p.add_argument("--report", default="CATALOG_IMPORT_REPORT.md")
    return p.parse_args()


def load_raw(path: Path):
    if path.suffix.lower() == ".xls":
        return read_raw_xls(str(path))
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        return read_raw_openpyxl(wb.active)
    finally:
        wb.close()


def save_master(rows, out_path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "products_master"
    ws.append(["Products Master Ready - generated from original pharmacy PriceList"])
    ws.append([])
    ws.append(MASTER_COLUMNS)
    for row in rows:
        ws.append([row.get(c, "") for c in MASTER_COLUMNS])
    header_fill = PatternFill("solid", fgColor="0F766E")
    header_font = Font(bold=True, color="FFFFFF")
    thin = Side(style="thin", color="D9E2EC")
    for cell in ws[3]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(top=thin, bottom=thin, left=thin, right=thin)
    ws.freeze_panes = "A4"
    ws.auto_filter.ref = f"A3:{get_column_letter(len(MASTER_COLUMNS))}{ws.max_row}"
    widths = {
        "A": 13, "B": 32, "C": 32, "D": 18, "E": 18, "F": 14, "G": 20, "H": 30, "I": 14,
        "J": 18, "K": 22, "L": 14, "M": 12, "N": 14, "O": 16, "P": 38, "Q": 42,
        "R": 20, "S": 14, "Y": 10, "Z": 10, "AF": 16, "AG": 34,
    }
    for col_idx in range(1, len(MASTER_COLUMNS) + 1):
        letter = get_column_letter(col_idx)
        ws.column_dimensions[letter].width = widths.get(letter, 16)
    for row in ws.iter_rows(min_row=4, max_row=ws.max_row):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.row_dimensions[1].height = 22
    ws[1][0].font = Font(bold=True, size=14, color="0F172A")
    # Reports
    rep = wb.create_sheet("quality_summary")
    counts = Counter(r.get("category") or "unknown" for r in rows)
    review = Counter(r.get("review_status") or "unknown" for r in rows)
    rep.append(["Metric", "Value"])
    rep.append(["total_products", len(rows)])
    rep.append(["approved", review.get("approved", 0)])
    rep.append(["needs_review", review.get("needs_review", 0)])
    for k, v in sorted(counts.items()):
        rep.append([f"category_{k}", v])
    rep.append(["duplicate_price_conflicts", sum(1 for r in rows if r.get("duplicate_price_conflict") == "true")])
    rep.append(["unclassified", sum(1 for r in rows if r.get("category") == "unknown")])
    for cell in rep[1]:
        cell.fill = header_fill; cell.font = header_font
    rep.column_dimensions["A"].width = 32
    rep.column_dimensions["B"].width = 18
    wb.save(out_path)


def write_report(rows, meta, report_path: Path, out_path: Path):
    from collections import Counter
    counts = Counter(r.get("category") or "unknown" for r in rows)
    review = Counter(r.get("review_status") or "unknown" for r in rows)
    lines = [
        "# PriceBot Catalog Preparation Report",
        "",
        f"source_mode: {meta.get('mode')}",
        f"header_row: {meta.get('header_row')}",
        f"output_excel: {out_path.name}",
        f"total_products: {len(rows)}",
        f"approved: {review.get('approved', 0)}",
        f"needs_review: {review.get('needs_review', 0)}",
        f"duplicate_price_conflicts: {sum(1 for r in rows if r.get('duplicate_price_conflict') == 'true')}",
        f"unclassified: {sum(1 for r in rows if r.get('category') == 'unknown')}",
        "",
        "## category_counts",
    ]
    for k, v in sorted(counts.items()):
        lines.append(f"- {k}: {v}")
    lines += [
        "",
        "## important_rows_verified",
    ]
    for q in ["Hemazym", "MEBO scar", "Pro-D3 50", "DEXERYL CREAM", "Ovanice", "Mari Female", "Panadol", "Flagyl"]:
        matches = [r for r in rows if q.lower().replace(" ", "") in (r.get("name", "").lower().replace(" ", "") + r.get("aliases", "").lower().replace(" ", ""))]
        lines.append(f"- {q}: {len(matches)} match(es)")
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    args = parse_args()
    src = Path(args.input_excel).expanduser().resolve()
    if not src.exists():
        print(f"INPUT_NOT_FOUND {src}")
        return 2
    rows, meta = load_raw(src)
    if not rows:
        print("NO_ROWS_FOUND")
        return 1
    out = Path(args.out).expanduser().resolve()
    save_master(rows, out)
    write_report(rows, meta, Path(args.report).expanduser().resolve(), out)
    print(f"PRICELIST_CONVERT_OK rows={len(rows)} out={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
