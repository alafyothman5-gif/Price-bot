#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from guided_commerce import rebuild_guided_index


def main() -> int:
    p = argparse.ArgumentParser(description="Rebuild guided_catalog_index for an explicit or resolved DB path.")
    p.add_argument("--db-path", default="", help="SQLite DB path. Recommended: pass explicitly.")
    args = p.parse_args()
    if args.db_path:
        database.configure_db_path(args.db_path)
    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB_PATH={database.get_db_path()}")
    database.init_db(run_production_guard=False)
    before = database.count_products()
    count = rebuild_guided_index()
    after = database.count_products()
    print(f"GUIDED_INDEX_REBUILD_OK rows={count} products_before={before} products_after={after}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
