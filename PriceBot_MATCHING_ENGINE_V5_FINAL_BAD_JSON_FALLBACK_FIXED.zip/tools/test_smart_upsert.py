#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

from openpyxl import Workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from services.catalog.excel_native_importer import build_fresh_database_from_excel
from services.catalog.smart_upsert import run_smart_upsert
from normalizer import normalize_text


def _write_price_excel(path: Path, rows):
    wb = Workbook()
    ws = wb.active
    # Keep the familiar raw pharmacy structure: name column and box price column.
    ws.append(["", "اسم الصنف", "", "سعر البيع"])
    for name, price in rows:
        ws.append(["", name, "", price])
    wb.save(path)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    source_excel = root / "products_master_ready.xlsx"
    if not source_excel.exists():
        raise SystemExit("products_master_ready.xlsx missing")
    with tempfile.TemporaryDirectory(prefix="pricebot_smart_upsert_test_") as td:
        td = Path(td)
        db = td / "pricebot_test.db"
        report = build_fresh_database_from_excel(str(source_excel), str(db))
        database.configure_db_path(str(db))
        database.init_db(run_production_guard=False)
        with database.connect() as conn:
            first = conn.execute("SELECT id, name, price FROM products WHERE price!='' ORDER BY id LIMIT 1").fetchone()
            second = conn.execute("SELECT id, name FROM products WHERE id != ? ORDER BY id LIMIT 1", (first[0],)).fetchone()
        product_id = int(first[0])
        product_name = str(first[1])
        old_price = str(first[2])
        learned_alias = "SMART_UPSERT_ALIAS_TEST_ONLY"
        database.append_product_alias_or_ocr(product_id, learned_alias, field="aliases")

        new_price = "9999" if old_price != "9999" else "8888"
        small_excel = td / "weekly_update.xlsx"
        # Duplicate row intentionally included; highest/latest policy should merge it.
        _write_price_excel(small_excel, [(product_name, new_price), (product_name, new_price)])
        upsert_report = run_smart_upsert(str(small_excel), dry_run=False, run_reindex=True)

        with database.connect() as conn:
            updated = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
            stale = conn.execute("SELECT available, review_status FROM products WHERE id=?", (int(second[0]),)).fetchone()
            alias_hit = conn.execute(
                "SELECT COUNT(*) FROM product_search_index WHERE key=? AND product_db_id=?",
                (normalize_text(learned_alias), product_id),
            ).fetchone()[0]
        updated = database.dict_row(updated)
        errors = []
        if str(updated.get("price")) != new_price:
            errors.append(f"price_not_updated old={old_price} got={updated.get('price')} expected={new_price}")
        if learned_alias not in str(updated.get("aliases") or ""):
            errors.append("learned_alias_not_preserved")
        if int(alias_hit or 0) < 1:
            errors.append("search_index_not_updated_for_preserved_alias")
        if str(stale[0]).lower() not in {"false", "0", "no"}:
            errors.append("missing_old_product_not_marked_unavailable")
        if "stale_missing_from_latest_excel" not in str(stale[1]):
            errors.append("missing_old_product_review_status_not_marked")
        if int(upsert_report.get("duplicate_rows_merged") or 0) < 1:
            errors.append("duplicate_row_not_merged")
        out = {
            "fresh_build_products": report.get("products_count"),
            "updated_product": product_name,
            "old_price": old_price,
            "new_price": new_price,
            "upsert_stats": upsert_report.get("stats"),
            "reindex": upsert_report.get("reindex"),
            "errors": errors,
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))
        if errors:
            return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
