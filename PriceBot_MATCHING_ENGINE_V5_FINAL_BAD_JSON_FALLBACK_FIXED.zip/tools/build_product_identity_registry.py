#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
import product_identity


def main() -> int:
    p = argparse.ArgumentParser(description='Rebuild Product Identity Registry for an explicit DB path.')
    p.add_argument('--db-path', required=True, help='SQLite DB path')
    args = p.parse_args()
    database.configure_db_path(args.db_path)
    database.init_db(run_production_guard=False)
    before = database.count_products()
    count = product_identity.rebuild_product_identity_registry()
    after = database.count_products()
    print(f'PRODUCT_IDENTITY_REGISTRY_REBUILD_OK rows={count} products_before={before} products_after={after}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
