#!/usr/bin/env python3
from __future__ import annotations

"""Audit catalog identity quality for safe matching.

Produces catalog_matching_quality_report.xlsx with products whose brand/family,
aliases, OCR keywords, forms, or canonical names need review.  This tool is
read-only against the catalog database.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import database
from normalizer import normalize_text, split_multi
from query_slots import canonical_form
from services.catalog.identity_generation import BrandFamilyNormalizer, generated_aliases_for_product, WEAK_TOKENS

HEADERS = [
    "product_id",
    "name",
    "detected_brand",
    "detected_family",
    "missing_aliases",
    "missing_ocr_keywords",
    "risk_level",
    "suggested_fix",
]


def _existing(row: Dict[str, Any], field: str) -> set[str]:
    return {normalize_text(x) for x in split_multi(row.get(field)) if normalize_text(x)}


def _limit(values: List[str], n: int = 12) -> str:
    out: List[str] = []
    seen = set()
    for v in values:
        nv = normalize_text(v)
        if not nv or nv in seen:
            continue
        seen.add(nv)
        out.append(v)
        if len(out) >= n:
            break
    return " | ".join(out)


def audit_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    normalizer = BrandFamilyNormalizer(rows)
    out: List[Dict[str, str]] = []
    for row in rows:
        detected = normalizer.normalize_row_identity(row)
        generated = generated_aliases_for_product(row)
        existing_aliases = _existing(row, "aliases") | {normalize_text(row.get("name")), normalize_text(row.get("normalized_name"))}
        existing_ocr = _existing(row, "ocr_keywords")
        missing_aliases = [x for x in generated if normalize_text(x) not in existing_aliases]
        missing_ocr = [x for x in generated if normalize_text(x) not in existing_ocr and any(t not in WEAK_TOKENS for t in normalize_text(x).split())]
        name_norm = normalize_text(row.get("name") or "")
        brand_norm = normalize_text(detected.brand)
        form = canonical_form(row.get("form") or row.get("medicine_form") or row.get("product_type") or row.get("name") or "")
        issues: List[str] = []
        if brand_norm and not name_norm.startswith(brand_norm + " ") and brand_norm in name_norm.split():
            issues.append("canonical_name_not_brand_first")
        if missing_aliases:
            issues.append("missing_aliases")
        if missing_ocr:
            issues.append("missing_ocr_keywords")
        if not form and any(w in name_norm for w in ["cream", "gel", "cleanser", "syrup", "tablet", "capsule", "كريم", "جل", "غسول", "شراب"]):
            issues.append("form_type_missing")
        if not issues:
            risk = "LOW"
            fix = "ok"
        elif "canonical_name_not_brand_first" in issues or "missing_ocr_keywords" in issues:
            risk = "HIGH"
            fix = "; ".join(issues)
        else:
            risk = "MEDIUM"
            fix = "; ".join(issues)
        out.append({
            "product_id": str(row.get("id") or row.get("product_id") or ""),
            "name": str(row.get("name") or ""),
            "detected_brand": detected.brand_display or detected.brand,
            "detected_family": detected.family_display or detected.family,
            "missing_aliases": _limit(missing_aliases),
            "missing_ocr_keywords": _limit(missing_ocr),
            "risk_level": risk,
            "suggested_fix": fix,
        })
    return out


def write_xlsx(path: Path, report_rows: List[Dict[str, str]]) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except Exception as exc:
        raise RuntimeError("openpyxl is required to write catalog_matching_quality_report.xlsx") from exc
    wb = Workbook()
    ws = wb.active
    ws.title = "Matching Quality"
    ws.append(HEADERS)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for item in report_rows:
        ws.append([item.get(h, "") for h in HEADERS])
    widths = [14, 36, 20, 30, 48, 52, 12, 34]
    for idx, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        risk = str(row[6].value or "")
        if risk == "HIGH":
            row[6].fill = PatternFill("solid", fgColor="F4CCCC")
        elif risk == "MEDIUM":
            row[6].fill = PatternFill("solid", fgColor="FFF2CC")
        else:
            row[6].fill = PatternFill("solid", fgColor="D9EAD3")
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db-path", default=os.getenv("PRICEBOT_DB_PATH") or str(ROOT / "pricebot.db"))
    parser.add_argument("--output", default=str(ROOT / "catalog_matching_quality_report.xlsx"))
    parser.add_argument("--json", default="")
    args = parser.parse_args()
    database.configure_db_path(args.db_path)
    database.init_db()
    rows = database.load_product_rows(visible_only=True, guided=False)
    report = audit_rows(rows)
    output = Path(args.output)
    write_xlsx(output, report)
    if args.json:
        Path(args.json).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    counts = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
    for r in report:
        counts[r["risk_level"]] = counts.get(r["risk_level"], 0) + 1
    print(f"CATALOG_MATCHING_QUALITY_REPORT={output}")
    print(f"PRODUCTS_AUDITED={len(report)} HIGH={counts.get('HIGH',0)} MEDIUM={counts.get('MEDIUM',0)} LOW={counts.get('LOW',0)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
