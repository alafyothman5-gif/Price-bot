#!/usr/bin/env python3
from __future__ import annotations

"""Real SQLite -> PostgreSQL migration for PriceBot.

Default mode writes data into PostgreSQL.  Use --dry-run only when intentionally
checking counts.  The migration creates the PostgreSQL schema, copies rows in
batches, preserves integer ids, and uses ON CONFLICT upserts so a repeated run
is safe and does not wipe existing PostgreSQL data.
"""

import argparse
import os
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

TABLES = [
    "products",
    "product_search_index",
    "product_identity_registry",
    "guided_catalog_index",
    "conversation_state",
    "orders",
    "processed_messages",
    "learning_inbox",
    "admin_audit_log",
    "catalog_import_jobs",
    "catalog_import_reports",
    "image_cache",
    "image_product_cache",
    "dynamic_synonyms",
    "audit_logs",
    "admin_users",
    "admin_roles",
    "admin_sessions",
]

PRIMARY_KEYS = {
    "conversation_state": ["phone"],
    "processed_messages": ["message_id"],
    "image_product_cache": ["image_hash"],
    "admin_roles": ["role"],
}


def sqlite_table_exists(src: sqlite3.Connection, table: str) -> bool:
    return bool(src.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def sqlite_columns(src: sqlite3.Connection, table: str) -> List[str]:
    return [str(r[1]) for r in src.execute(f'PRAGMA table_info("{table}")').fetchall()]


def pg_columns(pg, table: str) -> List[str]:
    rows = pg.execute(
        "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s ORDER BY ordinal_position",
        (table,),
    ).fetchall()
    return [str(r[0]) for r in rows]


def pg_pk(table: str, cols: List[str]) -> List[str]:
    if "id" in cols:
        return ["id"]
    return PRIMARY_KEYS.get(table, [])


def batch(iterable: List[Dict[str, Any]], size: int):
    for i in range(0, len(iterable), size):
        yield iterable[i : i + size]


def copy_table(src: sqlite3.Connection, pg, table: str, batch_size: int = 500) -> Dict[str, int]:
    if not sqlite_table_exists(src, table):
        return {"source_missing": 1, "source_rows": 0, "written": 0}
    src_cols = sqlite_columns(src, table)
    dst_cols = pg_columns(pg, table)
    common = [c for c in src_cols if c in dst_cols]
    if not common:
        return {"source_rows": 0, "written": 0, "no_common_columns": 1}
    rows = [dict(r) for r in src.execute(f'SELECT {", ".join(chr(34)+c+chr(34) for c in common)} FROM "{table}"').fetchall()]
    if not rows:
        return {"source_rows": 0, "written": 0}
    pk = pg_pk(table, common)
    col_sql = ", ".join(f'"{c}"' for c in common)
    placeholders = ", ".join(["%s"] * len(common))
    update_cols = [c for c in common if c not in pk]
    if pk and update_cols:
        conflict = ", ".join(f'"{c}"' for c in pk)
        updates = ", ".join(f'"{c}"=EXCLUDED."{c}"' for c in update_cols)
        sql = f'INSERT INTO "{table}" ({col_sql}) VALUES ({placeholders}) ON CONFLICT ({conflict}) DO UPDATE SET {updates}'
    elif pk:
        conflict = ", ".join(f'"{c}"' for c in pk)
        sql = f'INSERT INTO "{table}" ({col_sql}) VALUES ({placeholders}) ON CONFLICT ({conflict}) DO NOTHING'
    else:
        sql = f'INSERT INTO "{table}" ({col_sql}) VALUES ({placeholders}) ON CONFLICT DO NOTHING'
    written = 0
    for chunk in batch(rows, batch_size):
        params = [tuple(row.get(c) for c in common) for row in chunk]
        pg.executemany(sql, params)
        written += len(params)
    if "id" in common:
        try:
            pg.execute(f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), COALESCE((SELECT MAX(id) FROM \"{table}\"), 1), true)")
        except Exception:
            pass
    return {"source_rows": len(rows), "written": written}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sqlite", required=True, help="Path to current SQLite DB")
    parser.add_argument("--postgres-dsn", default=os.getenv("DATABASE_URL") or os.getenv("POSTGRES_DSN") or "", help="PostgreSQL DATABASE_URL/DSN")
    parser.add_argument("--dry-run", action="store_true", help="Only print source counts; no PostgreSQL writes")
    parser.add_argument("--batch-size", type=int, default=500)
    args = parser.parse_args()

    sqlite_db = Path(args.sqlite).expanduser().resolve()
    if not sqlite_db.exists():
        raise SystemExit(f"SQLITE_NOT_FOUND: {sqlite_db}")
    if not args.postgres_dsn:
        raise SystemExit("POSTGRES_DSN_REQUIRED: pass --postgres-dsn or set DATABASE_URL")

    src = sqlite3.connect(str(sqlite_db))
    src.row_factory = sqlite3.Row
    counts = {}
    try:
        for table in TABLES:
            if sqlite_table_exists(src, table):
                counts[table] = int(src.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])
        print("MIGRATION_SOURCE_COUNTS")
        for table, count in counts.items():
            print(f"{table}={count}")
        if args.dry_run:
            print("DRY_RUN_OK no_postgres_write_performed=1")
            return 0

        try:
            import psycopg  # noqa: F401
        except Exception as exc:
            raise SystemExit("PSYCOPG_REQUIRED: install psycopg[binary]") from exc

        os.environ["DATABASE_URL"] = args.postgres_dsn
        os.environ.setdefault("PRICEBOT_REQUIRE_POSTGRES_PRODUCTION", "1")
        import database  # imported after DATABASE_URL is set

        if not database.IS_POSTGRES:
            raise SystemExit("POSTGRES_DSN_NOT_ACTIVE: DATABASE_URL must start with postgres:// or postgresql://")
        database.init_db(run_production_guard=False)
        report = {}
        with database.connect() as pg:
            for table in TABLES:
                result = copy_table(src, pg, table, batch_size=max(1, args.batch_size))
                report[table] = result
                print(f"COPY {table}: {result}")
        print("POSTGRES_MIGRATION_WRITE_OK=1")
        return 0
    finally:
        src.close()


if __name__ == "__main__":
    raise SystemExit(main())
