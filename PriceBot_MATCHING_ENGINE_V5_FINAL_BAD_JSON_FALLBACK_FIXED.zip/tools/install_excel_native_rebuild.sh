#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${PRICEBOT_TARGET_DIR:-$(cd "$SCRIPT_DIR/.." && pwd)}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
EXCEL_PATH="${1:-$TARGET_DIR/products_master_ready.xlsx}"
DB_PATH="${PRICEBOT_DB_PATH:-$TARGET_DIR/pricebot.db}"
BACKUP_DIR="${PRICEBOT_BACKUP_DIR:-$TARGET_DIR/backups}"
NEW_DB="${DB_PATH}.new"
TS="$(date +%Y%m%d_%H%M%S)"

cd "$TARGET_DIR"

if [ ! -f "$EXCEL_PATH" ]; then
  echo "EXCEL_NOT_FOUND=$EXCEL_PATH"
  exit 1
fi
if [ ! -x "./venv/bin/python" ]; then
  echo "VENVE_PYTHON_NOT_FOUND=$TARGET_DIR/venv/bin/python"
  exit 1
fi

mkdir -p "$BACKUP_DIR"
if [ -f "$DB_PATH" ]; then
  cp "$DB_PATH" "$BACKUP_DIR/pricebot_before_excel_native_${TS}.db"
fi
rm -f "$NEW_DB" "$NEW_DB-wal" "$NEW_DB-shm"

./venv/bin/python tools/rebuild_database_from_any_excel.py --excel "$EXCEL_PATH" --db-path "$NEW_DB" --report "$BACKUP_DIR/excel_native_import_${TS}.json"
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path "$NEW_DB"
./venv/bin/python tools/verify_production.py --db-path "$NEW_DB" --excel-path "$EXCEL_PATH"

if [ -f "$DB_PATH" ]; then
  mv "$DB_PATH" "$BACKUP_DIR/pricebot_replaced_${TS}.db"
fi
mv "$NEW_DB" "$DB_PATH"
rm -f "$NEW_DB-wal" "$NEW_DB-shm"
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path "$DB_PATH"

if command -v systemctl >/dev/null 2>&1; then
  systemctl restart "$SERVICE_NAME" || true
  systemctl status "$SERVICE_NAME" --no-pager -l || true
else
  echo "SYSTEMCTL_SKIPPED=1"
fi

echo "PRICEBOT_EXCEL_NATIVE_REBUILD_DONE"
echo "TARGET_DIR=$TARGET_DIR"
echo "DB_PATH=$DB_PATH"
echo "EXCEL_PATH=$EXCEL_PATH"
