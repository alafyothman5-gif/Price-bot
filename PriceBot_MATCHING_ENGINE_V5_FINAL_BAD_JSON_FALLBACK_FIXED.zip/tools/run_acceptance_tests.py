#!/usr/bin/env python3
from __future__ import annotations
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import search_engine
from services.matching.excel_native_matcher import invalidate_memory_index, match_text, match_vision_slots, preload_search_index


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def _products(result):
    if result.products:
        return result.products
    if result.product:
        return [result.product]
    return []


def _assert_status(label: str, result, allowed, contains: str = "") -> None:
    if isinstance(allowed, str):
        allowed = {allowed}
    _assert(result.status in allowed, f"{label}: expected {allowed}, got {result.status} message={getattr(result, 'message', '')!r}")
    if contains:
        joined = " | ".join(str(p.get("name") or "") for p in _products(result)).lower()
        _assert(contains.lower() in joined, f"{label}: expected product containing {contains!r}, got {joined!r}")
    print(f"PASS {label}: {result.status}")


def _assert_all_products(label: str, result, must_include_any=(), forbidden_any=()) -> None:
    ps = _products(result)
    for p in ps:
        blob = " ".join(str(p.get(k) or "") for k in ["name", "brand", "product_family", "form", "aliases", "ocr_keywords"]).lower()
        if must_include_any:
            _assert(any(str(x).lower() in blob for x in must_include_any), f"{label}: unsafe product leaked: {p.get('name')} expected one of {must_include_any}")
        if forbidden_any:
            _assert(not any(str(x).lower() in blob for x in forbidden_any), f"{label}: forbidden product leaked: {p.get('name')} forbidden={forbidden_any}")
    print(f"PASS {label}: CANDIDATE_SCOPE_OK")


def _assert_flagyl_syrup(label: str, result) -> None:
    _assert_status(label, result, {"EXACT_MATCH", "ASK_CLARIFICATION"}, "flagyl")
    ps = _products(result)
    _assert(ps, f"{label}: expected Flagyl syrup/suspension product(s), got none")
    for p in ps:
        name = str(p.get("name") or "").lower()
        form = str(p.get("form") or p.get("medicine_form") or p.get("product_type") or "").lower()
        _assert("flagyl" in name, f"{label}: non-Flagyl leaked: {p.get('name')}")
        _assert(form in {"syrup", "suspension"}, f"{label}: wrong form leaked: {p.get('name')} form={form!r}")
    print(f"PASS {label}: HARD_FORM_FILTER_OK")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db-path", required=True)
    args = parser.parse_args()
    os.environ["PRICEBOT_DB_PATH"] = args.db_path
    os.environ["PRICEBOT_MATCH_LOG"] = "0"
    database.configure_db_path(args.db_path)
    database.init_db(run_production_guard=False)
    search_engine.invalidate_memory_index()
    invalidate_memory_index()
    preload_search_index()

    products_count = database.count_products()
    registry_count = database.identity_registry_count()
    search_index_count = database.count_table("product_search_index")
    guided_index_count = database.count_table("guided_catalog_index")
    _assert(products_count >= 1000, f"products_count too low: {products_count}")
    _assert(registry_count >= 1000, f"product_identity_registry too low: {registry_count}")

    text_cases = [
        ("Panadol generic", lambda: search_engine.search_product("Panadol"), "ASK_CLARIFICATION", "panadol"),
        ("Flagyl generic", lambda: search_engine.search_product("فلاجيل"), "ASK_CLARIFICATION", "flagyl"),
        ("Flagyl 500 duplicate/form", lambda: search_engine.search_product("فلاجيل 500"), "ASK_CLARIFICATION", "flagyl"),
        ("MEBO scar", lambda: search_engine.search_product("MEBO scar"), "EXACT_MATCH", "scar"),
        ("Pro-D3 exact", lambda: search_engine.search_product("Pro-D3 50,000 IU vitamin k2 15 capsules"), "EXACT_MATCH", "Pro-D3"),
        ("Rilastil missing specific", lambda: search_engine.search_product("Rilastil xerolact PB"), "NOT_AVAILABLE", ""),
        ("Cerave cleanser no wrong type", lambda: search_engine.search_product("Cerave Hydrating Cleanser"), {"NOT_AVAILABLE", "ASK_CLARIFICATION", "COSMETIC_ALTERNATIVES"}, ""),
        ("Amoclan syrup scoped", lambda: search_engine.search_product("Amoclan syrup"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}, ""),
    ]
    passed = 0
    for label, fn, allowed, contains in text_cases:
        result = fn()
        _assert_status(label, result, allowed, contains)
        passed += 1

    weak_cases = [
        ("Weak token white", lambda: match_text("white"), {"LOW_CONFIDENCE", "ASK_CLARIFICATION"}),
        ("Weak token cream", lambda: match_text("cream"), {"ASK_CLARIFICATION", "LOW_CONFIDENCE"}),
        ("Weak measure only", lambda: match_text("100 ml"), "LOW_CONFIDENCE"),
        ("Weak token plus", lambda: match_text("plus"), {"LOW_CONFIDENCE", "ASK_CLARIFICATION"}),
    ]
    for label, fn, allowed in weak_cases:
        result = fn()
        _assert_status(label, result, allowed)
        _assert(not _products(result), f"{label}: weak token must not return product candidates")
        passed += 1

    petroleum = match_text("WHITE PETROLEUM JELLY")
    _assert_status("Petroleum jelly phrase", petroleum, {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "LOW_CONFIDENCE"})
    if _products(petroleum):
        _assert_all_products("Petroleum jelly phrase", petroleum, must_include_any=("petroleum", "jelly"), forbidden_any=("white flower", "white magic"))
    passed += 1

    vichy = match_vision_slots({"visible_text":"VICHY NORMADERM PHYTOSOLUTION GEL 200ML", "main_visible_product":"VICHY NORMADERM PHYTOSOLUTION GEL 200ML", "confidence":0.95})
    _assert_status("Vichy Normaderm reversed canonical", vichy, {"EXACT_MATCH", "ASK_CLARIFICATION"}, "normaderm")
    _assert_all_products("Vichy Normaderm scope", vichy, must_include_any=("vichy", "normaderm"))
    passed += 1

    cerave = match_text("Cerave Hydrating Cleanser")
    _assert_status("Cerave Hydrating Cleanser type safety", cerave, {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "COSMETIC_ALTERNATIVES"})
    if _products(cerave):
        _assert_all_products("Cerave cleanser only", cerave, must_include_any=("cerave", "cleanser", "hydrating"), forbidden_any=("lotion", "serum", "shampoo"))
    passed += 1

    _assert_flagyl_syrup("Flagyl syrup search_engine", search_engine.search_product("فلاجيل شراب")); passed += 1
    _assert_flagyl_syrup("Flagyl syrup excel_native", match_text("فلاجيل شراب")); passed += 1

    mebo = match_text("MEBO SCAR")
    _assert_status("MEBO Scar brand guard", mebo, {"EXACT_MATCH", "ASK_CLARIFICATION"}, "mebo")
    _assert_all_products("MEBO Scar no First Scar", mebo, must_include_any=("mebo",), forbidden_any=("first scar",))
    passed += 1

    hemazym = match_text("Hemazym")
    _assert_status("Hemazym family guard", hemazym, {"EXACT_MATCH", "ASK_CLARIFICATION"}, "hemazym")
    _assert_all_products("Hemazym only", hemazym, must_include_any=("hemazym",))
    passed += 1

    propoli = match_text("PROPOLI")
    _assert_status("PROPOLI family guard", propoli, {"EXACT_MATCH", "ASK_CLARIFICATION"}, "propoli")
    _assert_all_products("PROPOLI only", propoli, must_include_any=("propoli",))
    passed += 1

    panadol = match_text("Panadol")
    _assert_status("Panadol family clarification", panadol, "ASK_CLARIFICATION", "panadol")
    _assert_all_products("Panadol same family only", panadol, must_include_any=("panadol",))
    passed += 1

    vision_cases = [
        ("Hemazym vision", lambda: match_vision_slots({"visible_text":"LIPOSOMAL Hemazym IRON SUPPLEMENT Folic Acid Vitamin B12 30 capsules", "main_visible_product":"Hemazym", "confidence":0.95}), "EXACT_MATCH", "Hemazym"),
        ("MEBO Scar vision", lambda: match_vision_slots({"visible_text":"MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym", "main_visible_product":"MEBO SCAR OINTMENT", "confidence":0.95}), "EXACT_MATCH", "scar"),
        ("Pro-D3 vision", lambda: match_vision_slots({"visible_text":"Pro-D3 50,000 IU Vitamin K2 15 capsules", "main_visible_product":"Pro-D3 50,000 IU Vitamin K2 15 capsules", "confidence":0.95}), "EXACT_MATCH", "Pro-D3"),
        ("Dexeryl vision", lambda: match_vision_slots({"visible_text":"DEXERYL crème cream 250g tube", "main_visible_product":"DEXERYL crème cream 250g tube", "confidence":0.95}), "EXACT_MATCH", "DEXERYL"),
        ("Mari Female vision", lambda: match_vision_slots({"visible_text":"MARI FEMALE Female Fertility 3600mg 30 Sachet 108g", "main_visible_product":"MARI FEMALE Female Fertility 3600mg 30 Sachet 108g", "confidence":0.95}), "EXACT_MATCH", "Mari Female"),
        ("Propoli vision", lambda: match_vision_slots({"visible_text":"PROPOLI Concentrated Fluid Food Supplement", "main_visible_product":"PROPOLI Concentrated Fluid Food Supplement", "confidence":0.95}), "EXACT_MATCH", "propoli"),
        ("Remedica partial vision", lambda: match_vision_slots({"visible_text":"100 ml oral suspension Remedica", "confidence":0.9}), {"LOW_CONFIDENCE", "IMAGE_UNCLEAR"}, ""),
    ]
    for label, fn, allowed, contains in vision_cases:
        result = fn()
        _assert_status(label, result, allowed, contains)
        passed += 1

    print(f"products_count={products_count}")
    print(f"product_identity_registry={registry_count}")
    print(f"product_search_index={search_index_count}")
    print(f"guided_catalog_index={guided_index_count}")
    print(f"ACCEPTANCE_TESTS_ALL_PASS={passed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
