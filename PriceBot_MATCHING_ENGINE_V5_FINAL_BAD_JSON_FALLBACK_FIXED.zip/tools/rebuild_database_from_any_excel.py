#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.catalog.excel_native_importer import build_fresh_database_from_excel, save_report


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a fresh PriceBot SQLite DB from any Excel with product name + price.")
    ap.add_argument("--excel", required=True, help="Excel/CSV file path: .xls, .xlsx, .xlsm, .csv")
    ap.add_argument("--db-path", required=True, help="Output SQLite DB path. Prefer a temp/new path, then swap after success.")
    ap.add_argument("--report", default="", help="Optional JSON report path")
    args = ap.parse_args()

    excel = Path(args.excel).expanduser().resolve()
    db_path = Path(args.db_path).expanduser().resolve()
    if not excel.exists():
        raise SystemExit(f"EXCEL_NOT_FOUND: {excel}")
    if db_path.exists():
        backup = db_path.with_suffix(db_path.suffix + ".backup_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        shutil.copy2(db_path, backup)
        print(f"OLD_OUTPUT_DB_BACKUP={backup}")
    report = build_fresh_database_from_excel(str(excel), str(db_path))
    if report["products_count"] < 1 or report["product_identity_registry"] < 1:
        raise SystemExit(f"BUILD_FAILED_BAD_COUNTS {json.dumps(report, ensure_ascii=False)}")
    report_path = args.report or str(db_path.with_suffix(".import_report.json"))
    save_report(report, report_path)
    print("EXCEL_NATIVE_DB_BUILD_OK")
    for key in ["products_count", "product_identity_registry", "product_search_index", "guided_catalog_index", "reader", "header_row"]:
        print(f"{key}={report.get(key)}")
    print(f"report={report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
