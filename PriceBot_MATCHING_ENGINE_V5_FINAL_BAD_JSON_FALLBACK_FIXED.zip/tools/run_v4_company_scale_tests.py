from __future__ import annotations

import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import concurrent.futures
import statistics
import time
import database
import matcher
import ui_flow

TEXT_QUERIES = [
    "Panadol", "Panadol Advance 500mg", "فلاجيل", "فلاجيل شراب", "MEBO scar", "Pro-D3 50,000 IU",
    "Rilastil xerolact PB", "Cerave Hydrating Cleanser", "Amoclan syrup", "Cipralex 10mg",
] * 10

VISION_SLOTS = [
    {"status":"OK","query":"mebo scar 30g","brand":"MEBO","product_name":"MEBO SCAR","form":"ointment","size":"30g","confidence":0.92},
    {"status":"OK","query":"hemazym 30","brand":"Hemazym","product_name":"Hemazym","confidence":0.90},
    {"status":"OK","query":"pro-d3 50000 iu","brand":"Pro-D3","product_name":"Pro-D3 50,000 IU","strength":"50000 IU","confidence":0.90},
    {"status":"OK","query":"mari female 3600 mg 108g 30 sachet","brand":"Mari","product_name":"Mari Female","pack":"30 sachet","confidence":0.90},
    {"status":"OK","query":"propoli","brand":"Propoli","product_name":"Propoli","confidence":0.90},
] * 10


def _text_case(i: int, q: str):
    t0 = time.perf_counter()
    r = ui_flow.handle_text(f"test{i}", q)
    dt = (time.perf_counter() - t0) * 1000
    assert r and isinstance(r, str)
    return dt


def _vision_case(slots: dict):
    t0 = time.perf_counter()
    r = matcher.match_vision_slots(slots)
    dt = (time.perf_counter() - t0) * 1000
    assert r.status in {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "LOW_CONFIDENCE", "IMAGE_UNCLEAR", "COSMETIC_ALTERNATIVES"}
    return dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db-path", required=True)
    ap.add_argument("--out", default="V4_COMPANY_SCALE_TEST_RESULTS.txt")
    args = ap.parse_args()
    database.configure_db_path(args.db_path)
    database.init_db(run_production_guard=False)
    text_lat = []
    vision_lat = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
        futs = [ex.submit(_text_case, i, q) for i, q in enumerate(TEXT_QUERIES, 1)]
        for f in concurrent.futures.as_completed(futs):
            text_lat.append(f.result())
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
        futs = [ex.submit(_vision_case, s) for s in VISION_SLOTS]
        for f in concurrent.futures.as_completed(futs):
            vision_lat.append(f.result())
    out = [
        "V4_COMPANY_SCALE_TESTS_PASS",
        f"text_tests={len(text_lat)}",
        f"vision_tests={len(vision_lat)}",
        "load_test=100_concurrent_text_messages",
        f"text_latency_ms_p50={statistics.median(text_lat):.2f}",
        f"text_latency_ms_max={max(text_lat):.2f}",
        f"vision_latency_ms_p50={statistics.median(vision_lat):.2f}",
        f"vision_latency_ms_max={max(vision_lat):.2f}",
    ]
    Path(args.out).write_text("\n".join(out)+"\n", encoding="utf-8")
    print("\n".join(out))


if __name__ == "__main__":
    main()
