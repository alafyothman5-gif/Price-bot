#!/usr/bin/env python3
"""Safe explicit Excel importer for PriceBot product catalog.

Rules enforced here:
- Never runs without --db-path.
- Supports the organized catalog columns requested for production.
- Does not DROP, DELETE, empty, replace, or rename the products table.
- Uses idempotent upsert by product_id, then barcode, then normalized_name.
- Hides stale old products not present in the Excel so they do not appear to customers.
- Provides --dry-run reporting before any production write.
"""
import argparse
import sqlite3
import sys
import traceback
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
from normalizer import normalize_text, safe_price, truthy
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths
from search_engine import rebuild_search_index
from guided_commerce import rebuild_guided_index
from product_identity import rebuild_product_identity_registry
from services.catalog.pricelist_converter import find_raw_header_openpyxl, read_raw_openpyxl, read_raw_xls
from services.catalog.excel_native_importer import build_fresh_database_from_excel, save_report as save_excel_native_report
from services.catalog.smart_upsert import run_smart_upsert, build_import_plan

HEADER_ROW = 0
DATA_START_ROW = 0
MAX_HEADER_SCAN_ROWS = 15

# Minimum organized catalog contract requested by the owner.
REQUIRED_COLUMNS = [
    "product_id",
    "name",
    "brand",
    "product_family",
    "category",
    "main_section",
    "sub_section",
    "subcategory",
    "active_ingredient",
    "form",
    "strength",
    "size",
    "pack",
    "barcode",
    "aliases",
    "ocr_keywords",
    "use_case",
    "skin_type",
    "available",
    "price",
    "substitution_group_id",
    "review_status",
    "review_notes",
]

# Older V22 files use section/product_type instead of subcategory.  Keep this
# backward-compatible for transition, but prefer explicit subcategory whenever it exists.
OPTIONAL_COMPAT_COLUMNS = [
    "normalized_name", "company", "section", "product_type", "body_area", "age_group", "gender",
    "medicine_form", "medicine_route", "currency", "search_mode", "quality_status", "is_substitutable",
    "source_serial", "original_name",
]

IDENTITY_COLUMNS = ["product_id", "barcode", "normalized_name"]


def _cell_value(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        try:
            f = float(text)
            if f.is_integer():
                return str(int(f))
        except Exception:
            pass
    return text


def _headers_from_row(values) -> List[str]:
    return [_cell_value(v) for v in values]


def _missing_required(headers: List[str]) -> List[str]:
    present = set(headers)
    missing = [c for c in REQUIRED_COLUMNS if c not in present]
    # Compatibility for older V22 catalogs.  main_section can be derived from
    # category/section; sub_section/subcategory can be derived from section or
    # product_type when the explicit columns do not exist.
    if "main_section" in missing and ("section" in present or "category" in present):
        missing.remove("main_section")
    for col in ["sub_section", "subcategory"]:
        if col in missing and ("section" in present or "product_type" in present):
            missing.remove(col)
    return missing


def _find_header_row(ws) -> Tuple[int, List[str], List[List[str]]]:
    preview: List[List[str]] = []
    best = (0, [], REQUIRED_COLUMNS[:])
    max_col = ws.max_column
    max_scan = min(MAX_HEADER_SCAN_ROWS, ws.max_row)
    for row_num in range(1, max_scan + 1):
        values = next(ws.iter_rows(min_row=row_num, max_row=row_num, max_col=max_col, values_only=True))
        headers = _headers_from_row(values)
        preview.append(headers[:40])
        missing = _missing_required(headers)
        if not missing:
            return row_num, headers, preview
        if len(missing) < len(best[2]):
            best = (row_num, headers, missing)
    found_columns = [h for h in best[1] if h]
    msg = [
        "MISSING_REQUIRED_COLUMNS",
        f"BEST_HEADER_ROW={best[0]}",
        f"MISSING={best[2]}",
        f"FOUND_COLUMNS={found_columns}",
        f"FIRST_10_ROWS_PREVIEW={preview[:10]}",
    ]
    raise RuntimeError("\n".join(msg))

def _canonical_available(value: str) -> str:
    return "true" if truthy(value) else "false"




def _clean_keywords(value: str) -> str:
    bad = {"unknown", "unclassified", "غير معروف", "غير مصنف", "none", "null"}
    out = []
    for part in str(value or "").replace(";", "|").replace(",", "|").split("|"):
        txt = str(part or "").strip()
        n = normalize_text(txt)
        if not txt or n in bad:
            continue
        if txt not in out:
            out.append(txt)
    return " | ".join(out)


def _add_aliases_from_name(row: Dict[str, str]) -> None:
    name = row.get("name") or ""
    aliases = [x.strip() for x in str(row.get("aliases") or "").split("|") if x.strip()]
    n = normalize_text(name)
    candidates = []
    if "prod3" in n:
        candidates += ["Pro-D3", "Pro D3", "prod3", name.replace("<", ",")]
    if "ovanice" in n:
        candidates += ["Ovanice", "Ovanice Female Fertility"]
    if "cerave" in n:
        candidates += [name.replace("cerave", "CeraVe"), name.replace("cerave", "سيرافي")]
    for c in candidates:
        c = c.strip()
        if c and c not in aliases:
            aliases.append(c)
    row["aliases"] = " | ".join(aliases)


def _set_if_empty(row: Dict[str, str], key: str, value: str) -> None:
    if value and not str(row.get(key) or "").strip():
        row[key] = value


def _section(row: Dict[str, str], category: str, main: str, sub: str) -> None:
    row["category"] = category or row.get("category", "")
    row["main_section"] = main or row.get("main_section", "")
    row["sub_section"] = sub or row.get("sub_section", "")
    row["subcategory"] = sub or row.get("subcategory", "")
    if not row.get("section"):
        row["section"] = main or sub


def _enrich_row_from_name(row: Dict[str, str]) -> Dict[str, str]:
    name = row.get("name") or ""
    n = normalize_text(name)
    row["ocr_keywords"] = _clean_keywords(row.get("ocr_keywords") or name)
    _add_aliases_from_name(row)

    # Fill common measures when visible in the name.  Do not override existing curated values.
    strengths = extract_strengths(name)
    sizes = extract_sizes(name)
    packs = extract_packs(name)
    if strengths:
        _set_if_empty(row, "strength", "; ".join(strengths))
    if sizes:
        _set_if_empty(row, "size", sizes[0])
    if packs:
        _set_if_empty(row, "pack", packs[0])

    form = canonical_form(name)
    if form:
        _set_if_empty(row, "form", form)

    # Supplements and vitamins.  These should be searchable and appear in supplement menus when clear.
    if any(x in n for x in ["prod3", "vitamin d", "vit d", "d3", "ovanice", "centrum", "omega", "iron", "calcium", "magnesium", "zinc", "multivitamin"]):
        sub = "supplement_unspecified"
        if "prod3" in n or "vitamin d" in n or " d3" in n:
            sub = "vitamins"
            row["use_case"] = row.get("use_case") or "vitamin_d"
        elif "ovanice" in n:
            sub = "supplement_unspecified"
            row["use_case"] = row.get("use_case") or "fertility"
        elif "omega" in n:
            sub = "omega"
        elif "iron" in n:
            sub = "iron"
        elif "calcium" in n:
            sub = "calcium"
        elif "magnesium" in n:
            sub = "magnesium"
        elif "centrum" in n or "multivitamin" in n:
            sub = "multivitamin"
        _section(row, "supplement", "مكملات وفيتامينات", sub)
        if not row.get("form"):
            if any(x in n for x in ["cap", "caps", "capsule", "capsules"]): row["form"] = "capsule"
            elif any(x in n for x in ["tab", "tablet"]): row["form"] = "tablet"
            elif "syr" in n or "syrup" in n: row["form"] = "syrup"

    # Medicines by common dosage forms.
    if any(x in n for x in ["flagyl", "amoclan", "cipralex", "janumet", "panadol", "concor", "exforge", "twynsta", "amlodipine", "zofran", "gaviscon"]):
        _section(row, "medicine", "أدوية", row.get("sub_section") if row.get("sub_section") not in {"غير مصنف", "unknown"} else "medicine_unspecified")
        if "flagyl" in n and "125" in n and not row.get("form"):
            row["form"] = "syrup"
        if "gaviscon" in n and any(x in n for x in ["syr", "syrup"]):
            row["form"] = "syrup"
        if "amoclan" in n and any(x in n for x in ["5 ml", "5ml", "susp", "syr"]):
            row["form"] = row.get("form") or "suspension"
        n_tokens = set(n.split())
        if "supp" in n_tokens or "suppository" in n_tokens:
            row["form"] = "suppository"
        elif any(x in n_tokens for x in ["tab", "tabs", "tablet", "tablets"]):
            row["form"] = row.get("form") or "tablet"

    # Skincare / hair clear product types.
    skincare = {
        "cleanser": "skincare_cleanser", "wash": "skincare_cleanser", "cream": "skincare_cream", "serum": "skincare_serum",
        "sunscreen": "skincare_sunscreen", "spf": "skincare_sunscreen", "moisturizer": "skincare_moisturizer", "lotion": "skincare_lotion", "toner": "skincare_toner", "mask": "skincare_mask", "acne": "skincare_acne",
    }
    hair = {"shampoo": "hair_shampoo", "conditioner": "hair_conditioner", "hair spray": "hair_spray", "spray": "hair_spray", "hair oil": "hair_oil", "hair mask": "hair_mask"}
    if any(k in n for k in ["shampoo", "conditioner", "hair spray", "hair oil", "hair mask"]):
        sub = next((v for k, v in hair.items() if k in n), "hair_treatment")
        _section(row, "cosmetic", "عناية بالشعر", sub)
        if "shampoo" in n: row["form"] = row.get("form") or "shampoo"
        elif "conditioner" in n: row["form"] = row.get("form") or "conditioner"
        elif "spray" in n: row["form"] = row.get("form") or "spray"
        elif "oil" in n: row["form"] = row.get("form") or "oil"
        elif "mask" in n: row["form"] = row.get("form") or "mask"
        row["use_case"] = row.get("use_case") or "hair"
    elif any(k in n for k in skincare):
        sub = next((v for k, v in skincare.items() if k in n), "skincare_cream")
        _section(row, "cosmetic", "عناية بالبشرة", sub)
        f = canonical_form(n)
        if f:
            row["form"] = row.get("form") or f
        if "acne" in n or "blemish" in n:
            row["use_case"] = row.get("use_case") or "acne / blemish"


    # High-value corrections from real pharmacy image tests.  These do not
    # invent medical use; they only classify obvious product forms/sections and
    # add safe aliases from package names so image/text exact matching works.
    if "mebo scar" in n:
        _section(row, "cosmetic", "عناية بالبشرة", "skincare_cream")
        row["form"] = row.get("form") or "ointment"
        row["use_case"] = row.get("use_case") or "scar"
        aliases = [x.strip() for x in str(row.get("aliases") or "").split("|") if x.strip()]
        for c in ["mebo scar", "mebo scar ointment", "mebo scar oint", "mebo scar 30g"]:
            if c not in aliases: aliases.append(c)
        row["aliases"] = " | ".join(aliases)
    elif n.startswith("mebo oint") or "mebo oint" in n:
        _section(row, "cosmetic", "عناية بالبشرة", "skincare_cream")
        row["form"] = row.get("form") or "ointment"
    if "dexeryl" in n:
        _section(row, "cosmetic", "عناية بالبشرة", "skincare_cream")
        row["form"] = row.get("form") or "cream"
    if "hemazym" in n:
        _section(row, "supplement", "مكملات وفيتامينات", "iron")
        row["form"] = row.get("form") or "capsule"
        row["pack"] = row.get("pack") or "30 capsules"
        row["use_case"] = row.get("use_case") or "iron"
        aliases = [x.strip() for x in str(row.get("aliases") or "").split("|") if x.strip()]
        for c in ["Hemazym", "Hemazym Iron", "Liposomal Hemazym", "هيمازيم"]:
            if c not in aliases: aliases.append(c)
        row["aliases"] = " | ".join(aliases)
        ocr = [x.strip() for x in str(row.get("ocr_keywords") or "").split("|") if x.strip()]
        for c in ["Hemazym", "Liposomal Iron", "Iron Supplement", "Folic Acid", "Vitamin B12", "30 capsules", "حديد"]:
            if c not in ocr: ocr.append(c)
        row["ocr_keywords"] = " | ".join(ocr)
    if "mari female" in n:
        _section(row, "supplement", "مكملات وفيتامينات", "supplement_unspecified")
        row["form"] = row.get("form") or "sachet"
        row["use_case"] = row.get("use_case") or "fertility"
        aliases = [x.strip() for x in str(row.get("aliases") or "").split("|") if x.strip()]
        for c in ["Mari Female", "MARI FEMALE Female Fertility", "mari female fertility"]:
            if c not in aliases: aliases.append(c)
        row["aliases"] = " | ".join(aliases)
    if n.startswith("propoli") or " propoli " in f" {n} ":
        # Propoli product identity.  Do not add Propoli aliases to unrelated
        # Propolis/Luma/Ocean products, or Vision will widen to wrong brands.
        if "nasal" not in n and "drop" not in n and "syr" not in n:
            _section(row, "supplement", "مكملات وفيتامينات", "supplement_unspecified")
        aliases = [x.strip() for x in str(row.get("aliases") or "").split("|") if x.strip()]
        for c in ["Propoli", "PROPOLI Concentrated Fluid"]:
            if c not in aliases: aliases.append(c)
        row["aliases"] = " | ".join(aliases)

    # If row still has a known category but no main/sub, align it safely.
    cat = normalize_text(row.get("category"))
    if cat == "medicine":
        _set_if_empty(row, "main_section", "أدوية"); _set_if_empty(row, "sub_section", "medicine_unspecified"); _set_if_empty(row, "subcategory", row.get("sub_section"))
    elif cat == "supplement":
        _set_if_empty(row, "main_section", "مكملات وفيتامينات"); _set_if_empty(row, "sub_section", "supplement_unspecified"); _set_if_empty(row, "subcategory", row.get("sub_section"))
    elif cat == "cosmetic":
        _set_if_empty(row, "main_section", "عناية بالبشرة"); _set_if_empty(row, "sub_section", "skincare_cream"); _set_if_empty(row, "subcategory", row.get("sub_section"))

    return row
def _normalize_row(item: Dict[str, str], row_number: int) -> Dict[str, str]:
    name = item.get("name") or item.get("original_name") or ""
    normalized_name = item.get("normalized_name") or normalize_text(name)
    main_section = item.get("main_section") or item.get("section") or item.get("category") or ""
    sub_section = item.get("sub_section") or item.get("subcategory") or item.get("section") or item.get("product_type") or ""
    subcategory = item.get("subcategory") or sub_section
    product_id = item.get("product_id") or f"AUTO-{row_number}"
    row: Dict[str, str] = {c: item.get(c, "") for c in database.PRODUCT_COLUMNS}
    row.update({
        "product_id": product_id,
        "name": name,
        "normalized_name": normalized_name,
        "main_section": main_section,
        "sub_section": sub_section,
        "subcategory": subcategory,
        "currency": item.get("currency") or "LYD",
        "price": safe_price(item.get("price")),
        "available": _canonical_available(item.get("available")),
        "original_name": item.get("original_name") or name,
    })
    # Keep old section aligned for any legacy UI, but main_section/sub_section/category/subcategory are source-of-truth.
    if not row.get("section"):
        row["section"] = main_section or subcategory
    if not row.get("product_type"):
        row["product_type"] = item.get("form") or subcategory
    if not row.get("quality_status"):
        row["quality_status"] = "ready"
    if not row.get("search_mode"):
        row["search_mode"] = "searchable"
    row = _enrich_row_from_name(row)
    return row


def _finalize_rows(raw_rows: List[Dict[str, str]]) -> Tuple[List[Dict[str, str]], Dict[str, object]]:
    rows: List[Dict[str, str]] = []
    rejected: List[Dict[str, str]] = []
    missing_data: List[Dict[str, str]] = []
    seen_product_ids = set()
    seen_barcodes = set()
    duplicate_product_ids = []
    duplicate_barcodes = []
    for idx, raw in enumerate(raw_rows, start=1):
        name = raw.get("name") or raw.get("original_name") or ""
        if not name:
            rejected.append({"row": str(idx), "reason": "missing_name"})
            continue
        row = _normalize_row(raw, idx)
        pid = row.get("product_id", "").strip()
        barcode = row.get("barcode", "").strip()
        if pid and pid in seen_product_ids:
            duplicate_product_ids.append(pid)
            rejected.append({"row": str(idx), "reason": f"duplicate_product_id:{pid}"})
            continue
        if barcode and barcode in seen_barcodes:
            duplicate_barcodes.append(barcode)
            rejected.append({"row": str(idx), "reason": f"duplicate_barcode:{barcode}"})
            continue
        if pid:
            seen_product_ids.add(pid)
        if barcode:
            seen_barcodes.add(barcode)
        missing_fields = [c for c in ["category", "subcategory", "available", "price"] if not str(row.get(c) or "").strip()]
        if missing_fields:
            missing_data.append({"row": str(idx), "product_id": pid, "name": name, "missing": ",".join(missing_fields)})
        rows.append(row)
    return rows, {
        "rejected": rejected,
        "missing_data": missing_data,
        "duplicate_product_ids": duplicate_product_ids,
        "duplicate_barcodes": duplicate_barcodes,
    }


def read_excel_rows(path: Path) -> Tuple[List[str], List[Dict[str, str]], Dict[str, object]]:
    # Native support for the pharmacy's original .xls price list.  It requires xlrd,
    # listed in requirements.txt.  This path keeps all rows and converts them to
    # the organized catalog contract before DB import.
    if path.suffix.lower() == ".xls":
        raw_rows, raw_meta = read_raw_xls(str(path))
        rows, final_meta = _finalize_rows(raw_rows)
        headers = list(raw_rows[0].keys()) if raw_rows else []
        meta = {
            "excel_max_row": raw_meta.get("rows_accepted", len(raw_rows)),
            "excel_max_col": len(headers),
            "header_row": raw_meta.get("header_row", 0),
            "data_start_row": int(raw_meta.get("header_row", 0) or 0) + 1,
            "first_10_rows_preview": [headers[:40]],
            "input_mode": raw_meta.get("mode", "raw_pricelist_xls"),
            **final_meta,
        }
        return headers, rows, meta

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    max_row = ws.max_row
    max_col = ws.max_column

    # Detect the raw Arabic pharmacy PriceList format before requiring the
    # organized products_master headers.
    raw_header_row, _raw_mapping = find_raw_header_openpyxl(ws)
    if raw_header_row:
        raw_rows, raw_meta = read_raw_openpyxl(ws)
        wb.close()
        rows, final_meta = _finalize_rows(raw_rows)
        headers = list(raw_rows[0].keys()) if raw_rows else []
        meta = {
            "excel_max_row": max_row,
            "excel_max_col": max_col,
            "header_row": raw_meta.get("header_row", raw_header_row),
            "data_start_row": int(raw_meta.get("header_row", raw_header_row)) + 1,
            "first_10_rows_preview": [headers[:40]],
            "input_mode": raw_meta.get("mode", "raw_pricelist"),
            **final_meta,
        }
        return headers, rows, meta

    header_row, headers, preview = _find_header_row(ws)
    data_start_row = header_row + 1

    raw_rows: List[Dict[str, str]] = []
    rejected_initial: List[Dict[str, str]] = []
    for excel_row_num, row_values in enumerate(ws.iter_rows(min_row=data_start_row, max_row=max_row, max_col=max_col, values_only=True), start=data_start_row):
        raw: Dict[str, str] = {}
        empty = True
        for header, value in zip(headers, row_values):
            if not header:
                continue
            val = _cell_value(value)
            if val:
                empty = False
            raw[header] = val
        if empty:
            continue
        name = raw.get("name") or raw.get("original_name") or ""
        if not name:
            rejected_initial.append({"row": str(excel_row_num), "reason": "missing_name"})
            continue
        raw_rows.append(raw)
    wb.close()
    rows, final_meta = _finalize_rows(raw_rows)
    final_meta["rejected"] = rejected_initial + list(final_meta.get("rejected") or [])
    report = {
        "excel_max_row": max_row,
        "excel_max_col": max_col,
        "header_row": header_row,
        "data_start_row": data_start_row,
        "first_10_rows_preview": preview[:10],
        "input_mode": "products_master",
        **final_meta,
    }
    return headers, rows, report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Safe upsert import for organized PriceBot product Excel.")
    parser.add_argument("excel_path", help="Path to products_master_ready.xlsx or products_master_v22_ready.xlsx")
    parser.add_argument("--db-path", required=True, help="Required explicit SQLite DB path. Example: /opt/pricebot/pricebot.db")
    parser.add_argument("--dry-run", action="store_true", help="Print the import plan and do not write to the DB.")
    return parser.parse_args()


def _abort_if_project_db(db_path: Path) -> None:
    project_root = Path(__file__).resolve().parents[1]
    if db_path.resolve() == (project_root / "pricebot.db").resolve():
        raise RuntimeError("REFUSING_PROJECT_LOCAL_DB: pass an external --db-path, never project/pricebot.db")


def _existing_product_maps(conn: sqlite3.Connection):
    maps = {"product_id": {}, "barcode": {}, "normalized_name": {}}
    if not database.table_exists(conn, "products"):
        return maps, []
    rows = conn.execute("SELECT id, product_id, barcode, normalized_name, name FROM products").fetchall()
    for r in rows:
        db_id = int(r[0])
        pid = str(r[1] or "").strip()
        barcode = str(r[2] or "").strip()
        norm = normalize_text(r[3] or r[4] or "")
        if pid and pid not in maps["product_id"]:
            maps["product_id"][pid] = db_id
        if barcode and barcode not in maps["barcode"]:
            maps["barcode"][barcode] = db_id
        if norm and norm not in maps["normalized_name"]:
            maps["normalized_name"][norm] = db_id
    return maps, rows


def _match_existing(row: Dict[str, str], maps) -> Tuple[int, str]:
    pid = str(row.get("product_id") or "").strip()
    barcode = str(row.get("barcode") or "").strip()
    norm = normalize_text(row.get("normalized_name") or row.get("name"))
    # Product_id is authoritative. If the Excel row has a product_id and it is
    # not in the DB, create a new product instead of merging unrelated rows that
    # happen to share a normalized display name. Barcode may still match an old
    # product whose product_id was previously missing or changed.
    if pid:
        if pid in maps["product_id"]:
            return maps["product_id"][pid], "product_id"
        if barcode and barcode in maps["barcode"]:
            return maps["barcode"][barcode], "barcode"
        return 0, "new"
    if barcode:
        if barcode in maps["barcode"]:
            return maps["barcode"][barcode], "barcode"
        return 0, "new"
    if norm and norm in maps["normalized_name"]:
        return maps["normalized_name"][norm], "normalized_name"
    return 0, "new"


def build_plan(rows: List[Dict[str, str]], rejected_count: int) -> Dict[str, int]:
    with database.connect() as conn:
        maps, old_rows = _existing_product_maps(conn)
        old_count = len(old_rows)
        matched_by = Counter()
        matched_ids = set()
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            if db_id:
                matched_by[kind] += 1
                matched_ids.add(db_id)
            else:
                matched_by["new"] += 1
        stale_old = max(0, old_count - len(matched_ids))
    return {
        "old_products_count": old_count,
        "excel_products_count": len(rows),
        "matched_by_product_id": matched_by["product_id"],
        "matched_by_barcode": matched_by["barcode"],
        "matched_by_normalized_name": matched_by["normalized_name"],
        "new_products": matched_by["new"],
        "stale_old_products": stale_old,
        "rejected_products": rejected_count,
        "products_after_expected_minimum": old_count + matched_by["new"],
        "visible_excel_products_expected": len(rows),
    }


def print_plan(plan: Dict[str, int], meta: Dict[str, object]) -> None:
    print("IMPORT_DRY_RUN_OR_PLAN")
    for key in [
        "old_products_count", "excel_products_count", "matched_by_product_id", "matched_by_barcode",
        "matched_by_normalized_name", "new_products", "stale_old_products", "rejected_products",
        "products_after_expected_minimum", "visible_excel_products_expected",
    ]:
        print(f"{key}={plan.get(key, 0)}")
    print(f"missing_data_products={len(meta.get('missing_data') or [])}")
    print(f"duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])}")
    print(f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])}")


def _update_product(conn: sqlite3.Connection, db_id: int, row: Dict[str, str]) -> None:
    cols = list(database.PRODUCT_COLUMNS)
    assignments = ", ".join(f'"{c}"=?' for c in cols) + ', "updated_at"=datetime(\'now\')'
    params = [row.get(c, "") for c in cols] + [int(db_id)]
    conn.execute(f'UPDATE products SET {assignments} WHERE id=?', params)


def _insert_product(conn: sqlite3.Connection, row: Dict[str, str]) -> int:
    cols = list(database.PRODUCT_COLUMNS)
    insert_cols = cols + ["created_at", "updated_at"]
    placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
    sql = f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})'
    cur = conn.execute(sql, [row.get(c, "") for c in cols])
    return int(cur.lastrowid)


def safe_upsert_import(rows: List[Dict[str, str]], plan: Dict[str, int]) -> Dict[str, int]:
    database.init_db(run_production_guard=False)
    stats = Counter()
    excel_db_ids = set()
    with database.connect() as conn:
        maps, _old_rows = _existing_product_maps(conn)
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            if db_id:
                _update_product(conn, db_id, row)
                stats["updated"] += 1
            else:
                db_id = _insert_product(conn, row)
                stats["added"] += 1
                # Make following duplicate-free rows in same import able to match if needed.
                pid = str(row.get("product_id") or "").strip()
                barcode = str(row.get("barcode") or "").strip()
                norm = normalize_text(row.get("normalized_name") or row.get("name"))
                if pid:
                    maps["product_id"][pid] = db_id
                if barcode:
                    maps["barcode"][barcode] = db_id
                if norm:
                    maps["normalized_name"][norm] = db_id
            excel_db_ids.add(int(db_id))

        # Hide old products not present in the Excel source; do not delete them.
        if excel_db_ids:
            placeholders = ",".join("?" for _ in excel_db_ids)
            cur = conn.execute(
                f"""
                UPDATE products
                SET available='false', search_mode='hidden', review_status='stale_hidden', updated_at=datetime('now')
                WHERE id NOT IN ({placeholders})
                """,
                tuple(excel_db_ids),
            )
            stats["stale_hidden"] = int(cur.rowcount or 0)
        else:
            raise RuntimeError("REFUSING_TO_HIDE_ALL_PRODUCTS: Excel produced zero accepted rows")
    return dict(stats)


def write_report_file(db_path: Path, excel: Path, plan: Dict[str, int], meta: Dict[str, object], stats: Dict[str, int], search_count: int, guided_count: int, integrity: str, products_after: int, identity_count: int = 0) -> Path:
    report_path = db_path.parent / f"import_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    lines = [
        "PRICEBOT_IMPORT_REPORT",
        f"db_path={db_path}",
        f"excel_path={excel}",
        f"products_before={plan.get('old_products_count', 0)}",
        f"products_after={products_after}",
        f"products_added={stats.get('added', 0)}",
        f"products_updated={stats.get('updated', 0)}",
        f"products_rejected={plan.get('rejected_products', 0)}",
        f"stale_old_products_hidden={stats.get('stale_hidden', 0)}",
        f"missing_data_products={len(meta.get('missing_data') or [])}",
        f"duplicate_product_ids={len(meta.get('duplicate_product_ids') or [])}",
        f"duplicate_barcodes={len(meta.get('duplicate_barcodes') or [])}",
        f"search_index={search_count}",
        f"guided_index={guided_count}",
        f"product_identity_registry={identity_count}",
        f"integrity={integrity}",
    ]
    if meta.get("missing_data"):
        lines.append("MISSING_DATA_SAMPLE=" + repr((meta.get("missing_data") or [])[:20]))
    if meta.get("rejected"):
        lines.append("REJECTED_SAMPLE=" + repr((meta.get("rejected") or [])[:20]))
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report_path


def main() -> int:
    """Smart Upsert entrypoint.

    The old compatibility mode built a fresh DB.  Enterprise ingestion must keep
    the live DB, update matching rows, preserve learned aliases/OCR keywords,
    mark missing rows unavailable, and hot-rebuild indexes.
    """
    args = parse_args()
    excel = Path(args.excel_path).expanduser().resolve()
    db_path = Path(args.db_path).expanduser().resolve()
    if not excel.exists():
        print(f"EXCEL_NOT_FOUND {excel}")
        return 2
    try:
        _abort_if_project_db(db_path)
    except Exception as exc:
        print(f"IMPORT_REFUSED {type(exc).__name__}: {exc}")
        return 2

    database.configure_db_path(str(db_path))
    print(f"DB_PATH={db_path}")
    print(f"EXCEL_PATH={excel}")
    print(f"DRY_RUN={1 if args.dry_run else 0}")
    print("SMART_UPSERT_IMPORT_MASTER=1")
    try:
        if args.dry_run:
            report = run_smart_upsert(str(excel), dry_run=True, run_reindex=False)
            plan = report.get("plan", {})
            print("SMART_UPSERT_DRY_RUN_OK")
            for key in [
                "old_products_count", "excel_rows_raw", "excel_rows_after_dedupe",
                "matched_by_identity_key", "matched_by_normalized_name", "matched_by_product_id",
                "matched_by_barcode", "new_products", "stale_old_products", "duplicate_rows_merged",
            ]:
                print(f"{key}={plan.get(key, 0)}")
            print(f"report={report.get('report_path')}")
            return 0

        report = run_smart_upsert(str(excel), dry_run=False, run_reindex=True)
        stats = report.get("stats", {})
        reindex = report.get("reindex", {})
        print("SMART_UPSERT_IMPORT_OK")
        print(f"products_before={report.get('products_before')}")
        print(f"products_after={report.get('products_after')}")
        print(f"products_added={stats.get('added', 0)}")
        print(f"products_updated={stats.get('updated', 0)}")
        print(f"stale_marked_unavailable={stats.get('stale_marked_unavailable', 0)}")
        print(f"duplicate_rows_merged={report.get('duplicate_rows_merged', 0)}")
        print(f"product_identity_registry={reindex.get('product_identity_registry', 0)}")
        print(f"product_search_index={reindex.get('search_index', 0)}")
        print(f"guided_catalog_index={reindex.get('guided_catalog_index', 0)}")
        print(f"integrity={report.get('integrity')}")
        print(f"report={report.get('report_path')}")
        return 0
    except Exception as exc:
        print("SMART_UPSERT_IMPORT_FAILED")
        print(f"ERROR={type(exc).__name__}: {exc}")
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
