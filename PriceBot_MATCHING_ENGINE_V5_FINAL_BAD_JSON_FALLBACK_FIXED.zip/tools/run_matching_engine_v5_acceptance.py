#!/usr/bin/env python3
from __future__ import annotations
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import search_engine
from services.matching.excel_native_matcher import invalidate_memory_index, match_text, match_vision_slots, preload_search_index


def products(result):
    if getattr(result, "products", None):
        return result.products
    if getattr(result, "product", None):
        return [result.product]
    return []


def assert_status(label, result, allowed):
    if isinstance(allowed, str):
        allowed = {allowed}
    assert result.status in allowed, f"{label}: expected {allowed}, got {result.status}; message={getattr(result,'message','')} diagnostics={getattr(result,'diagnostics',{})}"
    print(f"PASS {label}: {result.status}")


def assert_no_forbidden(label, result, forbidden):
    blob = " | ".join(str(p.get("name") or "") + " " + str(p.get("form") or "") for p in products(result)).lower()
    for token in forbidden:
        assert token.lower() not in blob, f"{label}: forbidden token leaked: {token}; products={blob}"
    print(f"PASS {label}: forbidden scope not leaked")


def assert_all_have_any(label, result, allowed):
    ps = products(result)
    for p in ps:
        blob = " ".join(str(p.get(k) or "") for k in ["name", "brand", "product_family", "form", "aliases", "ocr_keywords"]).lower()
        assert any(a.lower() in blob for a in allowed), f"{label}: unsafe candidate {p.get('name')} not in allowed {allowed}"
    print(f"PASS {label}: candidate scope OK")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db-path", default=os.getenv("PRICEBOT_DB_PATH") or "/opt/pricebot_clean/pricebot.db")
    ap.add_argument("--require-real-db", action="store_true", help="Fail if products count is under 1000.")
    args = ap.parse_args()
    os.environ["PRICEBOT_DB_PATH"] = args.db_path
    os.environ.setdefault("PRICEBOT_MATCH_LOG", "0")
    database.configure_db_path(args.db_path)
    database.init_db(run_production_guard=False)
    search_engine.invalidate_memory_index(); invalidate_memory_index(); preload_search_index()

    counts = {
        "products": database.count_products(),
        "product_identity_registry": database.count_table("product_identity_registry"),
        "product_search_index": database.count_table("product_search_index"),
        "guided_catalog_index": database.count_table("guided_catalog_index"),
    }
    if args.require_real_db:
        assert counts["products"] >= 1000, f"real DB required; products={counts['products']}"

    text_cases = [
        ("Panadol", search_engine.search_product("Panadol"), "ASK_CLARIFICATION"),
        ("Panadol Advance 500mg", search_engine.search_product("Panadol Advance 500mg"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}),
        ("فلاجيل", search_engine.search_product("فلاجيل"), "ASK_CLARIFICATION"),
        ("فلاجيل شراب", search_engine.search_product("فلاجيل شراب"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}),
        ("فلاجيل 500", search_engine.search_product("فلاجيل 500"), {"ASK_CLARIFICATION", "NOT_AVAILABLE"}),
        ("Cerave", search_engine.search_product("Cerave"), {"ASK_CLARIFICATION", "NOT_AVAILABLE", "LOW_CONFIDENCE"}),
        ("Cerave Hydrating Cleanser", search_engine.search_product("Cerave Hydrating Cleanser"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "COSMETIC_ALTERNATIVES"}),
        ("Rilastil Xerolact PB", search_engine.search_product("Rilastil Xerolact PB"), {"NOT_AVAILABLE", "ASK_CLARIFICATION"}),
        ("cream weak", match_text("cream"), {"LOW_CONFIDENCE", "ASK_CLARIFICATION"}),
        ("white weak", match_text("white"), {"LOW_CONFIDENCE", "ASK_CLARIFICATION"}),
        ("100ml weak", match_text("100ml"), "LOW_CONFIDENCE"),
        ("Cipralex 10mg", search_engine.search_product("Cipralex 10mg"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}),
    ]
    for label, result, allowed in text_cases:
        assert_status(label, result, allowed)

    flagyl_syrup = search_engine.search_product("فلاجيل شراب")
    for p in products(flagyl_syrup):
        blob = (str(p.get("name") or "") + " " + str(p.get("form") or p.get("medicine_form") or "")).lower()
        assert "tablet" not in blob and "suppository" not in blob, f"Flagyl syrup leaked wrong form: {blob}"

    cerave = search_engine.search_product("Cerave Hydrating Cleanser")
    assert_no_forbidden("Cerave cleanser", cerave, ["serum", "lotion", "shampoo"])

    vision_cases = [
        ("MEBO Scar with Hemazym background", lambda: match_vision_slots({"brand":"MEBO", "product_name":"MEBO SCAR OINTMENT", "form":"ointment", "size":"30g", "visible_text":"MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym", "background_text":"Hemazym", "confidence":0.95}), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}),
        ("Vichy Normaderm", lambda: match_vision_slots({"visible_text":"VICHY NORMADERM PHYTOSOLUTION GEL 200ML", "main_visible_product":"VICHY NORMADERM PHYTOSOLUTION GEL 200ML", "confidence":0.95}), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}),
        ("White Petroleum Jelly", lambda: match_vision_slots({"brand":"WHITE", "visible_text":"WHITE PETROLEUM JELLY", "confidence":0.95}), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "LOW_CONFIDENCE"}),
        ("cream tube 250g", lambda: match_vision_slots({"visible_text":"cream tube 250g", "size":"250g", "confidence":0.95}), {"LOW_CONFIDENCE", "IMAGE_UNCLEAR", "NOT_AVAILABLE"}),
        ("Cerave Cleanser image", lambda: match_vision_slots({"brand":"Cerave", "product_name":"Cerave Hydrating Cleanser", "form":"cleanser", "visible_text":"Cerave Hydrating Cleanser", "confidence":0.95}), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE", "COSMETIC_ALTERNATIVES"}),
        ("Transition 4g", lambda: match_vision_slots({"brand":"Transition", "product_name":"Transition Pediatrique", "size":"4g", "visible_text":"Transition 4g Pédiatrique", "confidence":0.95}), {"ASK_CLARIFICATION", "NOT_AVAILABLE", "LOW_CONFIDENCE"}),
    ]
    vision_results = []
    for label, fn, allowed in vision_cases:
        print(f"RUN {label}", flush=True)
        result = fn()
        vision_results.append((label, result))
        assert_status(label, result, allowed)
    mebo = vision_results[0][1]
    assert_all_have_any("MEBO brand lock", mebo, ["mebo"])
    assert_no_forbidden("MEBO background", mebo, ["hemazym", "first scar"])
    transition = vision_results[-1][1]
    assert not (transition.status == "EXACT_MATCH" and transition.product), "Transition 4g must not show a direct exact price for another size"

    print("COUNTS", counts)
    print("MATCHING_ENGINE_V5_ACCEPTANCE_PASS")
    return 0


if __name__ == "__main__":
    code = main()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(int(code))
