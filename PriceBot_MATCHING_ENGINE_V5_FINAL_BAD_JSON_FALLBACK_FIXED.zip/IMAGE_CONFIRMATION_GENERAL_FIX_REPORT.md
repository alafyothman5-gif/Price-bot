# Image Confirmation General Fix

This release fixes the general cause of readable images being rejected too early.

## Problem
The image matcher was using the same strict identity requirement for both candidate suggestion and price display. If an image had brand/family visible but missing size/form, it could return LOW_CONFIDENCE and show no candidate.

## Fix
A new generic candidate-suggestion step was added. If foreground OCR/vision can produce safe candidates, the matcher returns ASK_CLARIFICATION with choices and no price. Price is displayed only after the user selects a product.

## Safety
- Images do not show price directly.
- Size/strength mismatch guard remains active.
- Background OCR does not override foreground identity.
- Image cache is not used before user confirmation.
- This is general behavior, not a product-specific alias or Vichy patch.
