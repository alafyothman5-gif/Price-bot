# Original PriceList Excel Import

This release supports the pharmacy's original price-list shape directly:

- `سعر علبة`
- `سعر شريط`
- `الصنـــــــف`
- `ت`

## Prepare a clean master Excel manually

```bash
./venv/bin/python tools/prepare_pricelist_excel.py PriceList.xls --out products_master_ready.xlsx --report CATALOG_IMPORT_REPORT.md
```

The converter keeps every product row and generates stable product IDs from the source serial:

```text
PL00001
PL02448
...
```

## Safe import to database

```bash
./venv/bin/python tools/import_master_excel.py products_master_ready.xlsx --db-path /opt/pricebot/pricebot.db --dry-run
./venv/bin/python tools/import_master_excel.py products_master_ready.xlsx --db-path /opt/pricebot/pricebot.db
```

The importer also accepts raw `.xls`/`.xlsx` uploads from the admin catalog page. `.xls` support requires `xlrd==2.0.1`, which is included in `requirements.txt`.

## What was verified in this package

```text
products_after=5791
product_search_index=64228
guided_catalog_index=3569
product_identity_registry=5791
ACCEPTANCE_TESTS_ALL_PASS=106
```

Important image/product checks included:

- Hemazym image text resolves to `Hemazym`.
- MEBO Scar image text resolves to `mebo scar`, not Hemazym or First Scar.
- Panadol remains `ASK_CLARIFICATION`.
- Pro-D3 50,000 IU resolves correctly.
