# PriceBot Matching Engine V5 Commercial Safe - Fixed Build

## Status
This build applies the required fixes before deployment:

- `tools/deploy_final_active.sh` now checks health on `http://127.0.0.1:8090/health`.
- Vision image preprocessing is enabled in `vision_service.py`:
  - resize to `PRICEBOT_VISION_MAX_IMAGE_WIDTH` default `1024`
  - JPEG quality default `78`
  - OpenRouter timeout default `8s`
  - compact JSON-only Vision prompt
- `app.py` wraps the whole Vision step with a total timeout default `10s`, so image processing returns a safe message instead of hanging the user lock.
- Image Confirmation Mode is preserved: images do not directly display price/availability; they create a confirmation flow first.
- Image candidate safety was strengthened:
  - generic visual phrases such as `cream tube 250g` return `LOW_CONFIDENCE`
  - hard form mismatch blocks wrong cosmetic type candidates, e.g. cleanser image cannot select serum/lotion/cream
  - explicit measure mismatch blocks wrong variants, e.g. 4g cannot sell 10g
  - background OCR is kept for diagnostics and not trusted as foreground identity
- `search_engine.py` remains a wrapper over `services/matching/excel_native_matcher.py` at runtime.
- `tools/run_matching_engine_v5_acceptance.py` supports real DB testing with `--require-real-db`.

## Local validation performed in build environment

- `python3 -m compileall`: PASS
- Rebuilt DB from included `products_master_ready.xlsx`: PASS
  - products = 5791
  - product_identity_registry = 5791
  - product_search_index = 178406
  - guided_catalog_index = 5791
- Spot checks against rebuilt 5791-product DB:
  - WHITE PETROLEUM JELLY image slots => EXACT_MATCH candidate only, image UI still confirms before price
  - cream tube 250g image slots => LOW_CONFIDENCE
  - Cerave Hydrating Cleanser image slots => ASK_CLARIFICATION scoped to cleanser candidates, no serum/lotion direct price
  - Transition 4g image slots => NOT_AVAILABLE / no direct 10g sale

## Required server validation after deploy

Run on the active server after deployment:

```bash
cd /opt/pricebot_clean
PRICEBOT_DB_PATH=/opt/pricebot_clean/pricebot.db PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_matching_engine_v5_acceptance.py --db-path /opt/pricebot_clean/pricebot.db --require-real-db
```

Expected final line:

```text
MATCHING_ENGINE_V5_ACCEPTANCE_PASS
```

## Deployment path

Deploy only to:

```text
/opt/pricebot_clean
```

Preserve:

- `.env`
- `pricebot.db`
- `uploads`

Do not touch MedMCQ.

## Commercial safety rules preserved

- false price target: 0
- false availability target: 0
- uncertain text: ask / low confidence / not available
- uncertain image: confirmation / low confidence / image unclear
- weekly Excel upload continues updating prices safely without replacing identity


## Final Patch: General Image Candidate Suggestion

Implemented a generic fix for readable images that contain foreground brand/family/product text but are missing size/form. The matcher now separates:

- Candidate Suggestion: allowed when OCR/vision can safely produce same-brand/same-family candidates without price.
- Price Display: still blocked until user selects a candidate or identity is complete and explicitly confirmed.

This is not a Vichy-specific fix. It applies to all images/products. Vichy Normaderm-like images should now produce a confirmation list instead of false LOW_CONFIDENCE, while Transition 4g still must not display Transition 10g price directly.

Rules preserved:
- No direct price from image.
- No image cache before confirmation.
- Candidate safety filter remains active.
- Text matching unchanged.
- Weekly Excel upload unchanged.
