# Matching Engine Report — Excel Native V3

## Accepted build path

The production catalog must be built through Excel Native:

```bash
tools/rebuild_database_from_any_excel.py --excel products_master_ready.xlsx --db-path <db>
```

`clean_install_pricebot.sh` and `tools/clean_install_pricebot.sh` now use this path directly. `tools/import_master_excel.py` is kept only for compatibility and delegates to the same Excel Native builder.

## Verified counts

```text
products_count=5791
product_identity_registry=5791
product_search_index=92817
guided_catalog_index=3558
```

## Critical acceptance results

```text
PROPOLI vision -> EXACT_MATCH
Hemazym vision -> EXACT_MATCH
Mari Female vision -> EXACT_MATCH
MEBO Scar vision -> EXACT_MATCH
Pro-D3 vision -> EXACT_MATCH
Panadol -> ASK_CLARIFICATION
فلاجيل -> ASK_CLARIFICATION
فلاجيل شراب -> only Flagyl syrup/suspension products
Remedica partial image -> LOW_CONFIDENCE
```

## Deployment safety

A clean install now builds a temporary DB, verifies it, runs acceptance tests, and only then copies it into `pricebot.db`.
