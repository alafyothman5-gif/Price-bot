# Smart Upsert / Strict Dedupe Report

## Status

Strict deduplication is mandatory.

Removed optional gates:

```text
PRICEBOT_DEDUPE_BY_IDENTITY=1
PRICEBOT_MERGE_PRICE_CONFLICTS=1
```

## Implementation

File changed:

```text
services/catalog/smart_upsert.py
services/catalog/excel_native_importer.py
```

Behavior:

- Excel duplicates are merged before database writes.
- Existing duplicate products in the live database are merged and deleted.
- Surviving row preserves aliases and OCR keywords.
- Missing products from the new Excel become unavailable/hidden instead of being deleted as stale inventory.
- Derived indexes rebuild after a successful import.

## Verification

```text
products_after_strict_dedupe=4982
excel_duplicate_rows_merged=809
duplicate_identity_keys_after=0
duplicate_barcodes_after=0
```
