# Staging Workflow Report

Production direct modification from Excel upload has been stopped.

Admin upload route now queues a staging import job. The staging workflow copies the production SQLite DB into a staging DB, runs Smart Upsert and verification in staging, and returns one of:

- `ready_for_approval`
- `requires_review`
- `failed`

Only `ready_for_approval` can be promoted by admin approval.

A test with a duplicate price conflict produced:

```text
STAGING_WORKFLOW_PASS status=requires_review production_untouched=True verified=True conflicts=1
PRODUCTION_PRODUCTS_AFTER_STAGING=0
```
