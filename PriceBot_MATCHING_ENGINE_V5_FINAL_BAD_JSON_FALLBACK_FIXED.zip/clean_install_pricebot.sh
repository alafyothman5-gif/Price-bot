#!/usr/bin/env bash
set -euo pipefail

RELEASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${PRICEBOT_TARGET_DIR:-/opt/pricebot_clean}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_clean_install_backups}"
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
OLD_ROLLBACK="${TARGET_DIR}_rollback_${STAMP}"
OLD_LEGACY_DIR="/opt/pricebot"
SERVICE_PATH="/etc/systemd/system/$SERVICE_NAME"
PRODUCTS_FILE="products_master_ready.xlsx"

if [[ "$EUID" -ne 0 ]]; then
  echo "ERROR: run with sudo" >&2
  exit 1
fi

if [[ "$RELEASE_DIR" == "$TARGET_DIR" ]]; then
  echo "ERROR: run this script from extracted ZIP directory, not from $TARGET_DIR" >&2
  exit 1
fi

mkdir -p "$BACKUP_DIR"

ENV_SOURCE=""
if [[ -f "$TARGET_DIR/.env" ]]; then ENV_SOURCE="$TARGET_DIR/.env"; fi
if [[ -z "$ENV_SOURCE" && -f "$OLD_LEGACY_DIR/.env" ]]; then ENV_SOURCE="$OLD_LEGACY_DIR/.env"; fi
if [[ -z "$ENV_SOURCE" ]]; then
  echo "ERROR: no existing .env found in $TARGET_DIR or $OLD_LEGACY_DIR" >&2
  exit 1
fi

DB_SOURCE=""
if [[ -f "$TARGET_DIR/pricebot.db" ]]; then DB_SOURCE="$TARGET_DIR/pricebot.db"; fi
if [[ -z "$DB_SOURCE" && -f "$OLD_LEGACY_DIR/pricebot.db" ]]; then DB_SOURCE="$OLD_LEGACY_DIR/pricebot.db"; fi

cp -a "$ENV_SOURCE" "$BACKUP_DIR/.env"
if [[ -n "$DB_SOURCE" ]]; then cp -a "$DB_SOURCE" "$BACKUP_DIR/pricebot.db"; fi
if [[ -f "$SERVICE_PATH" ]]; then cp -a "$SERVICE_PATH" "$BACKUP_DIR/pricebot.service"; fi

echo "BACKUP_DIR=$BACKUP_DIR"
echo "ENV_BACKUP=OK"
[[ -n "$DB_SOURCE" ]] && echo "DB_BACKUP=OK" || echo "DB_BACKUP=SKIPPED no existing DB"

got_old=0
rollback_on_error() {
  rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "CLEAN_INSTALL_FAILED rc=$rc"
    if [[ -d "$OLD_ROLLBACK" && ! -d "$TARGET_DIR" ]]; then
      mv "$OLD_ROLLBACK" "$TARGET_DIR"
      echo "ROLLBACK_DIR_RESTORED=$TARGET_DIR"
    fi
    if [[ -f "$BACKUP_DIR/pricebot.service" ]]; then
      cp -a "$BACKUP_DIR/pricebot.service" "$SERVICE_PATH"
      systemctl daemon-reload || true
    fi
    systemctl start "$SERVICE_NAME" || true
  fi
  exit $rc
}
trap rollback_on_error ERR

echo "Stopping $SERVICE_NAME..."
systemctl stop "$SERVICE_NAME" || true

if [[ -d "$TARGET_DIR" ]]; then
  mv "$TARGET_DIR" "$OLD_ROLLBACK"
  got_old=1
  echo "OLD_DIR_MOVED_TO=$OLD_ROLLBACK"
fi

mkdir -p "$TARGET_DIR"
# Copy only release files, excluding runtime/secrets/cache/database/backups.
tar \
  --exclude='./.env' \
  --exclude='./pricebot.db' \
  --exclude='./venv' \
  --exclude='./__pycache__' \
  --exclude='./backups' \
  --exclude='*.pyc' \
  --exclude='*.pyo' \
  --exclude='*.db' \
  --exclude='*.sqlite' \
  --exclude='*.zip' \
  --exclude='*.tar.gz' \
  -C "$RELEASE_DIR" -cf - . | tar -C "$TARGET_DIR" -xf -

cp -a "$BACKUP_DIR/.env" "$TARGET_DIR/.env"
chmod 600 "$TARGET_DIR/.env" || true
chmod +x "$TARGET_DIR/start_pricebot.sh" "$TARGET_DIR/clean_install_pricebot.sh" || true
find "$TARGET_DIR" -type d -name __pycache__ -prune -exec rm -rf {} + || true
find "$TARGET_DIR" -type f \( -name '*.pyc' -o -name '*.pyo' -o -name '*.zip' -o -name '*.tar.gz' \) -delete || true

cd "$TARGET_DIR"
python3 -m venv venv
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt

./venv/bin/python -m compileall .

# Build the new production database outside $TARGET_DIR first using the
# Excel Native path.  This is the only accepted build path for production: it
# accepts ordinary name+price Excel files and produces the full native index
# counts used by the matcher (PROPOLI/Hemazym/Mari/MEBO vision tests).
TMP_DB="$(mktemp /tmp/pricebot_clean_build_${STAMP}_XXXXXX.sqlite)"
IMPORT_REPORT="$BACKUP_DIR/excel_native_import_${STAMP}.json"
rm -f "$TMP_DB" "$TMP_DB-wal" "$TMP_DB-shm"
echo "BUILD_DB_TEMP=$TMP_DB"
echo "EXCEL_NATIVE_BUILD=1"
./venv/bin/python tools/rebuild_database_from_any_excel.py --excel "$TARGET_DIR/$PRODUCTS_FILE" --db-path "$TMP_DB" --report "$IMPORT_REPORT"
CATALOG_MATCH_REPORT="$BACKUP_DIR/catalog_matching_quality_report_${STAMP}.xlsx"
./venv/bin/python tools/audit_catalog_matching_quality.py --db-path "$TMP_DB" --output "$CATALOG_MATCH_REPORT"
cp -a "$CATALOG_MATCH_REPORT" "$TARGET_DIR/catalog_matching_quality_report.xlsx"
./venv/bin/python tools/verify_production.py --db-path "$TMP_DB" --excel-path "$TARGET_DIR/$PRODUCTS_FILE"
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path "$TMP_DB"
# Copy only after successful verify and acceptance tests.  Preserve any previous target DB in backup.
rm -f "$TARGET_DIR/pricebot.db" "$TARGET_DIR/pricebot.db-wal" "$TARGET_DIR/pricebot.db-shm"
cp -a "$TMP_DB" "$TARGET_DIR/pricebot.db"
rm -f "$TMP_DB" "$TMP_DB-wal" "$TMP_DB-shm"
./venv/bin/python tools/verify_production.py --db-path "$TARGET_DIR/pricebot.db" --excel-path "$TARGET_DIR/$PRODUCTS_FILE"
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path "$TARGET_DIR/pricebot.db"

cat > "$SERVICE_PATH" <<EOF
[Unit]
Description=PriceBot WhatsApp Pharmacy Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=$TARGET_DIR
ExecStart=$TARGET_DIR/start_pricebot.sh
Restart=always
RestartSec=5
User=root
Environment=PRICEBOT_APP_DIR=$TARGET_DIR
Environment=PRICEBOT_ENV_FILE=$TARGET_DIR/.env
Environment=PRICEBOT_DB_PATH=$TARGET_DIR/pricebot.db

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
systemctl restart "$SERVICE_NAME"
sleep 2
systemctl status "$SERVICE_NAME" --no-pager -l || true
curl -fsS --max-time 5 http://127.0.0.1:8090/health >/tmp/pricebot_health_${STAMP}.json
cat /tmp/pricebot_health_${STAMP}.json
printf '\nHEALTH_OK=1\n'

TOKEN="$(grep -E '^META_VERIFY_TOKEN=' "$TARGET_DIR/.env" | cut -d= -f2- | tr -d '\r' || true)"
if [[ -n "$TOKEN" ]]; then
  curl -fsS --max-time 10 "https://46.101.148.246.sslip.io/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=${TOKEN}&hub.challenge=PING" | grep -q '^PING$' && echo "WEBHOOK_VERIFY_OK=1" || echo "WEBHOOK_VERIFY_WARNING=check manually"
else
  echo "WEBHOOK_VERIFY_SKIPPED=no_META_VERIFY_TOKEN"
fi

cat > "$TARGET_DIR/ROLLBACK_INFO.txt" <<EOF
Clean install timestamp: $STAMP
Backup directory: $BACKUP_DIR
Old rollback directory: $OLD_ROLLBACK
To rollback manually:
  sudo systemctl stop $SERVICE_NAME
  sudo cp -a $BACKUP_DIR/pricebot.service $SERVICE_PATH  # if file exists
  sudo rm -rf $TARGET_DIR
  sudo mv $OLD_ROLLBACK $TARGET_DIR
  sudo systemctl daemon-reload
  sudo systemctl start $SERVICE_NAME
Do not delete $OLD_ROLLBACK for at least 48 hours.
EOF

echo "CLEAN_INSTALL_OK=1"
echo "TARGET_DIR=$TARGET_DIR"
echo "OLD_ROLLBACK_DIR=$OLD_ROLLBACK"
echo "KEEP_ROLLBACK_48H=1"
