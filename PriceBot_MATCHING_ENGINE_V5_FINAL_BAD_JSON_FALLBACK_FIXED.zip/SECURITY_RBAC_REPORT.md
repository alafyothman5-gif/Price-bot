# Security and RBAC Report

## Implemented

- Admin session cookie now defaults to:
  - `httponly=True`
  - `secure=True`
  - `samesite='lax'`
- Cookie security can be disabled only for local HTTP testing with:

```bash
PRICEBOT_ADMIN_COOKIE_SECURE=0
```

- Added RBAC-ready tables:
  - admin_users
  - admin_roles
  - admin_sessions
  - admin_audit_log

- Added default roles:
  - owner
  - admin
  - pharmacist
  - viewer

## Compatibility note

The existing `ADMIN_KEY` login is kept as a transitional owner login so deployment does not break. The schema is ready for full username/password RBAC in the next release.
