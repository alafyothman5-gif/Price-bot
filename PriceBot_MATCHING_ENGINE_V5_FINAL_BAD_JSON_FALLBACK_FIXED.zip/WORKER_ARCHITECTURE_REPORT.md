# Worker Architecture Report

Celery/Redis is now a real queue path, not a placeholder.

Queues:

```bash
celery -A celery_app.celery_app worker -Q catalog --loglevel=INFO
celery -A celery_app.celery_app worker -Q vision  --loglevel=INFO --concurrency=2
celery -A celery_app.celery_app worker -Q text    --loglevel=INFO --concurrency=4
```

Enable with:

```bash
PRICEBOT_USE_CELERY=1
REDIS_URL=redis://localhost:6379/0
```

Webhook returns acknowledgement before processing. If the local queue is full, the system sends a temporary busy message to the customer.
