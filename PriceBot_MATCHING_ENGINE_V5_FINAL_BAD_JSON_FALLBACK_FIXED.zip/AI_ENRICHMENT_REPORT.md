# AI Enrichment Report

## Status

Mandatory enrichment is now part of the import pipeline. It is no longer enabled by an optional `PRICEBOT_AI_ENRICHMENT=1` variable.

## Implementation

File changed:

```text
services/catalog/ai_enrichment_agent.py
```

Behavior:

- Every imported row is enriched before dedupe/save.
- OpenRouter batch enrichment runs automatically when `OPENROUTER_API_KEY` exists.
- No environment flag disables enrichment.
- If OpenRouter is unavailable in local/test environments, mandatory deterministic classification still fills customer-facing fields.
- The agent never writes price, availability, or therapeutic alternatives.

## Verification

```text
rows_seen=5791
mandatory_enrichment=true
unclassified_after=0
needs_review_after=0
```
