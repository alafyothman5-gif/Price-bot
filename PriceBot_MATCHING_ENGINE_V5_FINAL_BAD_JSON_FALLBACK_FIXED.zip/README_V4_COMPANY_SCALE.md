# PriceBot V4 Company Scale Deployment Notes

## Required env

```bash
PRICEBOT_ADMIN_USERNAME=owner
PRICEBOT_ADMIN_PASSWORD='use-a-strong-password'
PRICEBOT_MERCHANT_USERNAME=merchant
PRICEBOT_MERCHANT_PASSWORD='use-a-strong-password'
PRICEBOT_CSRF_SECRET='use-a-long-random-secret'
PRICEBOT_USE_CELERY=1
REDIS_URL=redis://localhost:6379/0
PRICEBOT_STAGING_DIR=/opt/pricebot/staging
```

## Start web app

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

## Start workers

```bash
celery -A celery_app.celery_app worker -Q catalog --loglevel=INFO
celery -A celery_app.celery_app worker -Q vision --loglevel=INFO --concurrency=2
celery -A celery_app.celery_app worker -Q text --loglevel=INFO --concurrency=4
```

## Critical behavior

- Excel upload does not change production directly.
- Admin approval is required before promotion.
- Exact duplicate merge only.
- Price conflicts go to review.
- Merchant data is scoped by `merchant_id`.
