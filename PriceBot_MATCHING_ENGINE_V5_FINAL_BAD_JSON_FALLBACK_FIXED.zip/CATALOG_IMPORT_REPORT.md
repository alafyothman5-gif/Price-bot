# PriceBot Catalog Preparation Report

source_mode: raw_pricelist
header_row: 5
output_excel: products_master_ready.xlsx
total_products: 5791
approved: 2430
needs_review: 3361
duplicate_price_conflicts: 234
unclassified: 2233

## category_counts
- cosmetic: 865
- medicine: 2282
- other: 89
- supplement: 322
- unknown: 2233

## important_rows_verified
- Hemazym: 1 match(es)
- MEBO scar: 1 match(es)
- Pro-D3 50: 1 match(es)
- DEXERYL CREAM: 1 match(es)
- Ovanice: 1 match(es)
- Mari Female: 1 match(es)
- Panadol: 33 match(es)
- Flagyl: 7 match(es)
