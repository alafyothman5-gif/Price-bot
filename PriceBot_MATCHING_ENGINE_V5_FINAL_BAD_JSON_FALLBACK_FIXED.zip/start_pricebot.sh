#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${PRICEBOT_APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
cd "$APP_DIR"

ENV_FILE="${PRICEBOT_ENV_FILE:-$APP_DIR/.env}"

trim() {
  local s="$1"
  s="${s#${s%%[![:space:]]*}}"
  s="${s%${s##*[![:space:]]}}"
  printf '%s' "$s"
}

load_safe_env() {
  local file="$1"
  [[ -f "$file" ]] || return 0
  local line key value
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%$'\r'}"
    line="$(trim "$line")"
    [[ -z "$line" || "${line:0:1}" == "#" ]] && continue
    [[ "$line" == export\ * ]] && line="$(trim "${line#export }")"
    [[ "$line" == *"="* ]] || continue
    key="$(trim "${line%%=*}")"
    value="${line#*=}"
    value="$(trim "$value")"
    if [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]]; then
      if [[ "${value:0:1}" == '"' && "${value: -1}" == '"' ]]; then value="${value:1:${#value}-2}"; fi
      if [[ "${value:0:1}" == "'" && "${value: -1}" == "'" ]]; then value="${value:1:${#value}-2}"; fi
      export "$key=$value"
    fi
  done < "$file"
}

load_safe_env "$ENV_FILE"

first_csv() {
  local v="$1"
  v="${v//;/,}"
  IFS=',' read -ra parts <<< "$v"
  for p in "${parts[@]}"; do
    p="$(trim "$p")"
    [[ -n "$p" ]] && { printf '%s' "$p"; return 0; }
  done
  return 0
}

if [[ -z "${OPENROUTER_API_KEY:-}" ]]; then
  candidate="$(first_csv "${AI_OPENROUTER_KEYS:-${AI_OPENROUTER_KEY:-${OPENROUTER_KEYS:-${OPENROUTER_KEY:-}}}}")"
  [[ -n "$candidate" ]] && export OPENROUTER_API_KEY="$candidate"
fi
[[ -z "${OPENROUTER_MODEL:-}" && -n "${AI_OPENROUTER_MODEL:-}" ]] && export OPENROUTER_MODEL="$AI_OPENROUTER_MODEL"
[[ -z "${OPENROUTER_BASE_URL:-}" && -n "${AI_OPENROUTER_BASE_URL:-}" ]] && export OPENROUTER_BASE_URL="$AI_OPENROUTER_BASE_URL"

export BOOKING_ENABLED="${BOOKING_ENABLED:-false}"
export RESERVATION_ENABLED="${RESERVATION_ENABLED:-false}"
export PRICEBOT_DB_PATH="${PRICEBOT_DB_PATH:-$APP_DIR/pricebot.db}"
export PYTHONUNBUFFERED=1

HOST="${PRICEBOT_HOST:-127.0.0.1}"
PORT="${PRICEBOT_PORT:-8090}"

exec "$APP_DIR/venv/bin/python" -m uvicorn app:app --host "$HOST" --port "$PORT"
