"""Learning Inbox admin action facade."""
from database import approve_learning_alias, update_learning_status
from product_identity import rebuild_product_identity_registry
from search_engine import rebuild_search_index, invalidate_memory_index
