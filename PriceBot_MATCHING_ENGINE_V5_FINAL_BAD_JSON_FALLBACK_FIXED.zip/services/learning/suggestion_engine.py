from __future__ import annotations

"""Learning suggestions for alias/OCR approval without code changes."""

from typing import Any, Dict, Iterable, List, Sequence

from normalizer import normalize_text
from services.catalog.identity_generation import WEAK_TOKENS


def _tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in normalize_text(value).split():
        if not t or t in WEAK_TOKENS or t.isdigit() or len(t) <= 2:
            continue
        if t not in out:
            out.append(t)
    return out


def suggest_learning_candidates(query: str, products: Sequence[Dict[str, Any]], limit: int = 5) -> List[Dict[str, Any]]:
    q_tokens = set(_tokens(query))
    if len(q_tokens) < 2:
        return []
    scored = []
    for p in products:
        blob = " ".join(str(p.get(k) or "") for k in ["name", "brand", "product_family", "aliases", "ocr_keywords", "active_ingredient"])
        pt = set(_tokens(blob))
        shared = q_tokens & pt
        if len(shared) < 2:
            continue
        brand = normalize_text(p.get("brand") or "").split()
        brand_bonus = 2 if brand and any(b in q_tokens for b in brand) else 0
        score = len(shared) * 10 + brand_bonus
        scored.append((score, str(p.get("name") or ""), p, sorted(shared)))
    scored.sort(key=lambda x: (-x[0], x[1].lower()))
    out = []
    for score, _name, p, shared in scored[:limit]:
        out.append({
            "id": p.get("id"),
            "name": p.get("name"),
            "price": p.get("price"),
            "suggested_product": p.get("name"),
            "reason": "same brand/family tokens" if score >= 22 else "shared strong identity tokens",
            "matched_tokens": shared,
            "missing_ocr_keyword": query,
        })
    return out
