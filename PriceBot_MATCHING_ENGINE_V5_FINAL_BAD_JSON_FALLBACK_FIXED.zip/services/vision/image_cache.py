"""Image cache facade."""
try:
    from database import get_image_cache, set_image_cache
except Exception:  # pragma: no cover
    get_image_cache = None
    set_image_cache = None
