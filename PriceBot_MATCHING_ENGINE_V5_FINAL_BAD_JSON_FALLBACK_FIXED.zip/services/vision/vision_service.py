"""Vision service facade for the organized PriceBot layout."""
from vision_service import extract_product_from_image, build_query_from_slots
