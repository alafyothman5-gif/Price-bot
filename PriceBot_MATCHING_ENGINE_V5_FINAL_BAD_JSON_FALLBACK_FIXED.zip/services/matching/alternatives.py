"""Safe alternatives facade; policy remains enforced in search_engine."""
from search_engine import search_product, dedupe_products
