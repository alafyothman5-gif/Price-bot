from __future__ import annotations

"""Duplicate price conflict resolver for PriceBot."""

from typing import Callable, Dict, Iterable, List, Tuple

from normalizer import safe_price


def duplicate_price_conflicts(products: Iterable[Dict], identity_key: Callable[[Dict], Tuple]) -> List[Dict]:
    groups = {}
    for product in products:
        groups.setdefault(identity_key(product), []).append(product)
    out: List[Dict] = []
    for group in groups.values():
        prices = {safe_price(p.get("price")) for p in group if safe_price(p.get("price"))}
        if len(group) > 1 and len(prices) > 1:
            out.extend(group)
    return out
