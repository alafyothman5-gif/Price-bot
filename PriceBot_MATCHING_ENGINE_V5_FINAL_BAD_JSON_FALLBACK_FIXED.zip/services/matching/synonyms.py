"""Dynamic synonym service facade."""
from dynamic_synonyms import apply_synonyms, load_dynamic_synonyms, invalidate_cache, token_synonym
