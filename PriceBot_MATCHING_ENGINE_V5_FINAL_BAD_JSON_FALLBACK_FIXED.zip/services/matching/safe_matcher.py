"""Compatibility wrapper for the production safe matcher.
The active implementation remains in search_engine.py to avoid risky route rewrites.
"""
from search_engine import search_product, search_from_vision_slots, SearchResult, rebuild_search_index, invalidate_memory_index
