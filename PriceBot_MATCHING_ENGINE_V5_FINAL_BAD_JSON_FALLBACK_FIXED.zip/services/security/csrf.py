from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from typing import Optional


def _secret() -> bytes:
    raw = os.getenv("PRICEBOT_CSRF_SECRET") or os.getenv("PRICEBOT_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD") or "pricebot-csrf-change-me"
    return raw.encode("utf-8")


def issue_token(session_token: str = "") -> str:
    nonce = secrets.token_urlsafe(18)
    base = f"{session_token[:12]}:{nonce}"
    sig = hmac.new(_secret(), base.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{nonce}:{sig}"


def verify_token(token: str, session_token: str = "") -> bool:
    try:
        nonce, sig = (token or "").split(":", 1)
        base = f"{session_token[:12]}:{nonce}"
        expected = hmac.new(_secret(), base.encode("utf-8"), hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, expected)
    except Exception:
        return False
