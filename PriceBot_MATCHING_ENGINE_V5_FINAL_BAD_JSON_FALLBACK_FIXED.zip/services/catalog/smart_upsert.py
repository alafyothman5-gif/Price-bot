from __future__ import annotations

"""Enterprise-safe catalog ingestion for PriceBot.

This module performs a real Smart Upsert against the live catalog.  It is
intentionally conservative:
- it never drops or replaces the products table;
- it preserves learned aliases/OCR keywords;
- old rows missing from the latest Excel are marked unavailable, not deleted;
- derived indexes are rebuilt after a successful import without restarting the app.
"""

import json
import os
import time
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import database
from normalizer import normalize_text, safe_price, split_multi, truthy
from query_slots import canonical_form, normalize_measure
from services.catalog.ai_enrichment_agent import enrich_rows
from services.catalog.excel_native_importer import (
    convert_any_excel_to_master_rows,
    fast_rebuild_guided_index,
    fast_rebuild_identity_registry,
    fast_rebuild_search_index,
    invalidate_excel_native_index,
)

UNKNOWN_VALUES = {"", "unknown", "unclassified", "غير معروف", "غير مصنف", "none", "null", "na"}
PRESERVE_MERGE_FIELDS = {"aliases", "ocr_keywords"}
PRESERVE_IF_NEW_EMPTY_FIELDS = {
    "brand",
    "company",
    "category",
    "main_section",
    "sub_section",
    "subcategory",
    "section",
    "product_family",
    "form",
    "product_type",
    "active_ingredient",
    "strength",
    "size",
    "pack",
    "barcode",
    "use_case",
    "skin_type",
    "body_area",
    "age_group",
    "gender",
    "medicine_form",
    "medicine_route",
    "currency",
    "substitution_group_id",
}


def _valid(value: object) -> bool:
    return normalize_text(value) not in UNKNOWN_VALUES and str(value or "").strip() != ""


def _clean_unknown(value: object) -> str:
    text = str(value or "").strip()
    return "" if normalize_text(text) in UNKNOWN_VALUES else text


def _brand_from_row(row: Dict[str, Any]) -> str:
    brand = _clean_unknown(row.get("brand") or row.get("company"))
    if brand:
        return normalize_text(brand)
    toks = normalize_text(row.get("name") or row.get("normalized_name")).split()
    return toks[0] if toks else ""


def identity_key_for_row(row: Dict[str, Any]) -> str:
    """Stable identity key: brand + normalized identity + form/strength/size/pack.

    Barcode is not embedded in the key because it is used as an even stronger
    direct match when present.  This keeps rows stable even when Excel line
    numbers or auto product IDs change between weekly uploads.
    """
    name_identity = normalize_text(
        row.get("product_family")
        or row.get("normalized_name")
        or row.get("original_name")
        or row.get("name")
    )
    form = canonical_form(row.get("form") or row.get("medicine_form") or row.get("product_type") or row.get("name")) or ""
    parts = [
        _brand_from_row(row),
        name_identity,
        normalize_text(row.get("category") or row.get("main_section") or row.get("section")),
        form,
        normalize_measure(row.get("strength")),
        normalize_measure(row.get("size")),
        normalize_measure(row.get("pack")),
    ]
    return "|".join(parts)


def _parts(value: object) -> List[str]:
    out: List[str] = []
    seen = set()
    for part in split_multi(value):
        text = str(part or "").strip()
        norm = normalize_text(text)
        if not text or norm in UNKNOWN_VALUES or norm in seen:
            continue
        seen.add(norm)
        out.append(text)
    return out


def merge_pipe_values(*values: object) -> str:
    out: List[str] = []
    seen = set()
    for value in values:
        for part in _parts(value):
            norm = normalize_text(part)
            if norm not in seen:
                seen.add(norm)
                out.append(part)
    return " | ".join(out)


def _price_to_float(value: object) -> float:
    text = safe_price(value)
    try:
        return float(str(text).replace(",", ".")) if text else 0.0
    except Exception:
        return 0.0


def _barcode_key(value: object) -> str:
    text = str(value or "").strip()
    norm = normalize_text(text)
    if not text or norm in UNKNOWN_VALUES or norm in {"0", "00", "000", "-"}:
        return ""
    # Treat only real-looking barcodes/codes as globally unique.  Single zero or
    # placeholder values in pharmacy exports must not merge unrelated products.
    if len(norm.replace(" ", "")) < 4:
        return ""
    return text


def _exact_duplicate_key(row: Dict[str, Any]) -> str:
    """Return a conservative duplicate key.

    Only exact commercial duplicates are eligible for automatic merge. Variants
    such as Baby/Extra, different strengths, different forms, different sizes,
    or different prices must remain separate or be sent to review.
    """
    fields = [
        _barcode_key(row.get("barcode")),
        normalize_text(row.get("name") or row.get("normalized_name") or row.get("original_name")),
        normalize_text(row.get("brand") or row.get("company")),
        normalize_text(row.get("product_family")),
        canonical_form(row.get("form") or row.get("medicine_form") or row.get("product_type")),
        normalize_measure(row.get("strength")),
        normalize_measure(row.get("size")),
        normalize_measure(row.get("pack")),
    ]
    # No automatic merge without a real name. Barcode-only rows are allowed only
    # when the barcode is real-looking.
    if not fields[1] and not fields[0]:
        return ""
    return "|".join(str(x or "") for x in fields)


def _same_exact_variant(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    return _exact_duplicate_key(a) and _exact_duplicate_key(a) == _exact_duplicate_key(b)


def _choose_price(old: object, new: object, policy: str = "latest") -> str:
    new_price = safe_price(new)
    old_price = safe_price(old)
    if not new_price:
        return old_price
    if policy == "highest" and old_price:
        return new_price if _price_to_float(new_price) >= _price_to_float(old_price) else old_price
    return new_price


def _dedupe_excel_rows(rows: List[Dict[str, str]], policy: str = "latest") -> Tuple[List[Dict[str, str]], Dict[str, int]]:
    """Conservative dedupe for imported Excel rows.

    Automatic merge is allowed only when the rows are exact commercial
    duplicates: same normalized name, brand, family, form, strength, size, pack,
    barcode, and price. Price conflicts are not resolved automatically; the
    conflicting row is excluded from automatic import and surfaced in
    catalog_review_items by the staging workflow/report.
    """
    grouped: Dict[str, Dict[str, str]] = {}
    stats = Counter()
    conflicts: List[Dict[str, Any]] = []
    for idx, row in enumerate(rows, start=1):
        prepared = dict(row)
        prepared["identity_key"] = identity_key_for_row(prepared)
        key = _exact_duplicate_key(prepared) or f"row:{idx}"
        if key not in grouped:
            grouped[key] = prepared
            continue
        existing = grouped[key]
        price_a = safe_price(existing.get("price"))
        price_b = safe_price(prepared.get("price"))
        if price_a and price_b and price_a != price_b:
            stats["price_conflicts"] += 1
            conflicts.append({
                "row_number": idx,
                "duplicate_key": key,
                "existing_name": existing.get("name") or existing.get("original_name"),
                "incoming_name": prepared.get("name") or prepared.get("original_name"),
                "price_old": price_a,
                "price_new": price_b,
                "row": prepared,
            })
            continue
        stats["duplicate_rows_merged"] += 1
        stats["exact_duplicate_rows_merged"] += 1
        # Same exact product and same price: merge only non-dangerous learned/search hints.
        existing["available"] = "true" if truthy(existing.get("available")) or truthy(prepared.get("available")) else "false"
        existing["aliases"] = merge_pipe_values(existing.get("aliases"), prepared.get("aliases"))
        existing["ocr_keywords"] = merge_pipe_values(existing.get("ocr_keywords"), prepared.get("ocr_keywords"))
        for col in database.PRODUCT_COLUMNS:
            if col in {"available", "aliases", "ocr_keywords", "price"}:
                continue
            if not _valid(existing.get(col)) and _valid(prepared.get(col)):
                existing[col] = prepared.get(col, "")
    out = dict(stats)
    out["_conflicts"] = conflicts
    return list(grouped.values()), out


def _strict_db_dedupe_key(row: Dict[str, Any]) -> str:
    key = _exact_duplicate_key(row)
    price = safe_price(row.get("price"))
    # Price is part of automatic physical dedupe. If price differs, the group
    # will not merge silently.
    return f"exact:{key}|price:{price}" if key and price else ""


def _merge_live_duplicate_payload(keeper: Dict[str, Any], dup: Dict[str, Any], price_policy: str) -> Dict[str, str]:
    payload: Dict[str, str] = {}
    for col in database.PRODUCT_COLUMNS:
        old = keeper.get(col, "")
        new = dup.get(col, "")
        if col in PRESERVE_MERGE_FIELDS:
            payload[col] = merge_pipe_values(old, new, dup.get("name"))
        elif col == "price":
            payload[col] = safe_price(old) or safe_price(new)
        elif col == "available":
            payload[col] = "true" if truthy(old) or truthy(new) else "false"
        elif col == "identity_key":
            payload[col] = old or new or identity_key_for_row(keeper)
        elif not _valid(old) and _valid(new):
            payload[col] = str(new)
        else:
            payload[col] = str(old or "")
    return payload


def _strict_dedupe_products_table(conn, price_policy: str = "latest") -> Dict[str, int]:
    """Physically remove only exact same-product/same-price duplicate rows.

    This deliberately refuses to merge variants or price conflicts. Conflicting
    variants remain visible for review instead of being collapsed into one row.
    """
    if not database.table_exists(conn, "products"):
        return {"groups": 0, "deleted": 0}
    rows = [database.dict_row(r) or {} for r in conn.execute("SELECT * FROM products ORDER BY id").fetchall()]
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        key = _strict_db_dedupe_key(row)
        if key:
            groups[key].append(row)
    deleted = 0
    merged_groups = 0
    for key, items in groups.items():
        if len(items) < 2:
            continue
        merged_groups += 1
        keeper = dict(items[0])
        keeper_id = int(keeper.get("id") or 0)
        for dup in items[1:]:
            payload = _merge_live_duplicate_payload(keeper, dup, price_policy)
            _update_product(conn, keeper_id, payload)
            # Keep dependent records pointing to the surviving product where such
            # columns exist.  These updates are best-effort and harmless when the
            # tables/columns are absent.
            dup_id = int(dup.get("id") or 0)
            for table, col in [
                ("learning_inbox", "selected_product_id"),
                ("image_cache", "matched_product_id"),
                ("image_product_cache", "matched_product_id"),
            ]:
                try:
                    if database.table_exists(conn, table) and col in database.table_columns(conn, table):
                        conn.execute(f'UPDATE "{table}" SET "{col}"=? WHERE "{col}"=?', (keeper_id, dup_id))
                except Exception:
                    pass
            conn.execute("DELETE FROM products WHERE id=?", (dup_id,))
            deleted += 1
            keeper.update(payload)
    return {"groups": merged_groups, "deleted": deleted}

def _ensure_schema() -> None:
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        if database.table_exists(conn, "products"):
            database.add_column(conn, "products", "identity_key", "TEXT DEFAULT ''")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_products_identity_key ON products(identity_key)")
        database.add_column(conn, "catalog_import_jobs", "job_type", "TEXT DEFAULT ''")
        database.add_column(conn, "catalog_import_jobs", "started_at", "TEXT")
        database.add_column(conn, "catalog_import_jobs", "finished_at", "TEXT")
        database.add_column(conn, "catalog_import_jobs", "error_text", "TEXT DEFAULT ''")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_import_lock (
                id INTEGER PRIMARY KEY CHECK (id=1),
                job_id INTEGER,
                locked_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)


@contextmanager
def _import_lock(job_id: Optional[int] = None):
    _ensure_schema()
    acquired = False
    try:
        with database.connect() as conn:
            try:
                conn.execute("INSERT INTO catalog_import_lock(id, job_id, locked_at) VALUES(1, ?, datetime('now'))", (job_id,))
                acquired = True
            except Exception as exc:
                row = conn.execute("SELECT job_id, locked_at FROM catalog_import_lock WHERE id=1").fetchone()
                raise RuntimeError(f"CATALOG_IMPORT_ALREADY_RUNNING job={row[0] if row else ''} locked_at={row[1] if row else ''}") from exc
        yield
    finally:
        if acquired:
            try:
                with database.connect() as conn:
                    conn.execute("DELETE FROM catalog_import_lock WHERE id=1")
            except Exception:
                pass


def _load_existing_maps(conn) -> Tuple[Dict[str, Dict[str, int]], Dict[int, Dict[str, Any]]]:
    maps: Dict[str, Dict[str, int]] = {"barcode": {}, "identity_key": {}, "normalized_name": {}, "product_id": {}}
    rows_by_id: Dict[int, Dict[str, Any]] = {}
    if not database.table_exists(conn, "products"):
        return maps, rows_by_id
    cols = set(database.table_columns(conn, "products"))
    select_cols = ["id", "product_id", "barcode", "identity_key", "normalized_name", "name", "brand", "product_family", "category", "main_section", "section", "form", "medicine_form", "product_type", "strength", "size", "pack"]
    select_cols = [c for c in select_cols if c in cols]
    sql = "SELECT " + ", ".join(f'"{c}"' for c in select_cols) + " FROM products"
    raw_rows = [database.dict_row(r) or {} for r in conn.execute(sql).fetchall()]
    norm_counts = Counter(normalize_text(r.get("normalized_name") or r.get("name")) for r in raw_rows)
    identity_counts = Counter((str(r.get("identity_key") or "").strip() or identity_key_for_row(r)) for r in raw_rows)
    for d in raw_rows:
        db_id = int(d.get("id") or 0)
        if not db_id:
            continue
        rows_by_id[db_id] = d
        barcode = _barcode_key(d.get("barcode"))
        if barcode:
            maps["barcode"].setdefault(barcode, db_id)
        key = str(d.get("identity_key") or "").strip() or identity_key_for_row(d)
        if key and identity_counts[key] == 1:
            maps["identity_key"].setdefault(key, db_id)
        norm = normalize_text(d.get("normalized_name") or d.get("name"))
        if norm and norm_counts[norm] == 1:
            maps["normalized_name"].setdefault(norm, db_id)
        pid = str(d.get("product_id") or "").strip()
        if pid:
            maps["product_id"].setdefault(pid, db_id)
    return maps, rows_by_id


def _match_existing(row: Dict[str, Any], maps: Dict[str, Dict[str, int]]) -> Tuple[int, str]:
    barcode = _barcode_key(row.get("barcode"))
    if barcode and barcode in maps["barcode"]:
        return maps["barcode"][barcode], "barcode"
    key = str(row.get("identity_key") or "").strip() or identity_key_for_row(row)
    if key and key in maps["identity_key"]:
        return maps["identity_key"][key], "identity_key"
    norm = normalize_text(row.get("normalized_name") or row.get("name"))
    if norm and norm in maps["normalized_name"]:
        return maps["normalized_name"][norm], "normalized_name"
    pid = str(row.get("product_id") or "").strip()
    # Use product_id last because native pharmacy sheets may generate PLxxxxx
    # IDs from row order; identity/barcode/name are safer across weekly files.
    if pid and pid in maps["product_id"]:
        return maps["product_id"][pid], "product_id"
    return 0, "new"


def _merged_update_payload(existing: Dict[str, Any], incoming: Dict[str, Any], price_policy: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for col in database.PRODUCT_COLUMNS:
        old = existing.get(col, "")
        new = incoming.get(col, "")
        if col in PRESERVE_MERGE_FIELDS:
            out[col] = merge_pipe_values(old, new, incoming.get("name"))
        elif col == "price":
            out[col] = _choose_price(old, new, policy=price_policy)
        elif col == "available":
            out[col] = "true" if truthy(new) else "false"
        elif col == "identity_key":
            out[col] = incoming.get("identity_key") or identity_key_for_row(incoming)
        elif col in PRESERVE_IF_NEW_EMPTY_FIELDS:
            out[col] = str(new if _valid(new) else old or "")
        else:
            out[col] = str(new if str(new or "").strip() else old or "")
    return out


def _insert_product(conn, row: Dict[str, Any]) -> int:
    row = dict(row)
    row["identity_key"] = row.get("identity_key") or identity_key_for_row(row)
    cols = list(database.PRODUCT_COLUMNS)
    insert_cols = cols + ["created_at", "updated_at"]
    placeholders = ["?"] * len(cols) + ["datetime('now')", "datetime('now')"]
    sql = f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in insert_cols)}) VALUES({", ".join(placeholders)})'
    cur = conn.execute(sql, [row.get(c, "") for c in cols])
    return int(cur.lastrowid)


def _update_product(conn, db_id: int, payload: Dict[str, str]) -> None:
    cols = list(database.PRODUCT_COLUMNS)
    assignments = ", ".join(f'"{c}"=?' for c in cols) + ', "updated_at"=datetime(\'now\')'
    conn.execute(f'UPDATE products SET {assignments} WHERE id=?', [payload.get(c, "") for c in cols] + [int(db_id)])


def _build_plan_from_rows(excel_path: str, rows: List[Dict[str, str]], meta: Dict[str, Any], dedupe_stats: Dict[str, int]) -> Dict[str, Any]:
    with database.connect() as conn:
        maps, existing = _load_existing_maps(conn)
        matched_by = Counter()
        matched_ids = set()
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            matched_by[kind] += 1
            if db_id:
                matched_ids.add(db_id)
        old_count = len(existing)
    return {
        "excel_path": str(excel_path),
        "reader": meta.get("reader"),
        "header_row": meta.get("header_row"),
        "old_products_count": old_count,
        "excel_rows_raw": int((meta.get("enrichment") or {}).get("rows_seen") or len(rows)),
        "excel_rows_after_dedupe": len(rows),
        "matched_by_barcode": matched_by["barcode"],
        "matched_by_identity_key": matched_by["identity_key"],
        "matched_by_normalized_name": matched_by["normalized_name"],
        "matched_by_product_id": matched_by["product_id"],
        "new_products": matched_by["new"],
        "stale_old_products": max(0, old_count - len(matched_ids)),
        "duplicate_rows_merged": dedupe_stats.get("duplicate_rows_merged", 0),
        "meta": meta,
    }


def build_import_plan(excel_path: str, price_policy: str = "latest") -> Dict[str, Any]:
    _ensure_schema()
    raw_rows, meta = convert_any_excel_to_master_rows(excel_path)
    raw_rows, enrichment_stats = enrich_rows(raw_rows)
    meta = {**meta, "enrichment": enrichment_stats}
    rows, dedupe_stats = _dedupe_excel_rows(raw_rows, policy=price_policy)
    with database.connect() as conn:
        maps, existing = _load_existing_maps(conn)
        matched_by = Counter()
        matched_ids = set()
        for row in rows:
            db_id, kind = _match_existing(row, maps)
            matched_by[kind] += 1
            if db_id:
                matched_ids.add(db_id)
        old_count = len(existing)
    return {
        "excel_path": str(excel_path),
        "reader": meta.get("reader"),
        "header_row": meta.get("header_row"),
        "old_products_count": old_count,
        "excel_rows_raw": len(raw_rows),
        "excel_rows_after_dedupe": len(rows),
        "matched_by_barcode": matched_by["barcode"],
        "matched_by_identity_key": matched_by["identity_key"],
        "matched_by_normalized_name": matched_by["normalized_name"],
        "matched_by_product_id": matched_by["product_id"],
        "new_products": matched_by["new"],
        "stale_old_products": max(0, old_count - len(matched_ids)),
        "duplicate_rows_merged": dedupe_stats.get("duplicate_rows_merged", 0),
        "meta": meta,
    }


def _save_json_report(report: Dict[str, Any], prefix: str = "smart_upsert_report") -> Path:
    path = database.get_db_path().parent / f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return path


def run_smart_upsert(
    excel_path: str,
    job_id: Optional[int] = None,
    dry_run: bool = False,
    price_policy: Optional[str] = None,
    run_reindex: bool = True,
) -> Dict[str, Any]:
    """Run a safe import.  Returns a report dict; raises on failure.

    In dry-run mode no write is performed.  In write mode the function performs
    a best-effort backup before changing production data and rebuilds derived
    indexes after the upsert.
    """
    _ensure_schema()
    excel = Path(excel_path).expanduser().resolve()
    if not excel.exists():
        raise FileNotFoundError(str(excel))
    policy = price_policy or os.getenv("PRICEBOT_IMPORT_PRICE_POLICY", "latest").strip().lower() or "latest"
    if policy not in {"latest", "highest"}:
        policy = "latest"

    raw_rows, meta = convert_any_excel_to_master_rows(str(excel))
    raw_rows, enrichment_stats = enrich_rows(raw_rows)
    meta = {**meta, "enrichment": enrichment_stats}
    rows, dedupe_stats = _dedupe_excel_rows(raw_rows, policy=policy)
    conflicts = list(dedupe_stats.get("_conflicts") or [])
    if not rows:
        raise RuntimeError("NO_PRODUCTS_ACCEPTED_FROM_EXCEL")

    plan = _build_plan_from_rows(str(excel), rows, meta, dedupe_stats)
    if job_id and conflicts:
        for conflict in conflicts[:1000]:
            try:
                database.create_catalog_review_item(
                    int(job_id),
                    conflict.get("row") or conflict,
                    issue_type="price_conflict",
                    duplicate_key=str(conflict.get("duplicate_key") or ""),
                    price_old=str(conflict.get("price_old") or ""),
                    price_new=str(conflict.get("price_new") or ""),
                    merchant_id=database.default_merchant_id(),
                    severity="blocking",
                )
            except Exception:
                pass
    if dry_run:
        report = {"mode": "dry_run", "plan": plan, "meta": meta, "dedupe": dedupe_stats}
        report["report_path"] = str(_save_json_report(report, prefix="smart_upsert_dryrun"))
        return report

    with _import_lock(job_id=job_id):
        start = time.time()
        backup = None
        if database.get_db_path().exists():
            backup = str(database.backup_db("before_smart_upsert"))
        stats = Counter()
        excel_db_ids = set()
        matched_by = Counter()
        with database.connect() as conn:
            pre_dedupe = _strict_dedupe_products_table(conn, price_policy=policy)
            maps, existing_light = _load_existing_maps(conn)
            full_existing_cache: Dict[int, Dict[str, Any]] = {}
            for row in rows:
                row = dict(row)
                row["identity_key"] = row.get("identity_key") or identity_key_for_row(row)
                db_id, kind = _match_existing(row, maps)
                matched_by[kind] += 1
                if db_id:
                    if db_id not in full_existing_cache:
                        old_row = conn.execute("SELECT * FROM products WHERE id=?", (int(db_id),)).fetchone()
                        full_existing_cache[db_id] = database.dict_row(old_row) or {}
                    payload = _merged_update_payload(full_existing_cache[db_id], row, price_policy=policy)
                    _update_product(conn, db_id, payload)
                    stats["updated"] += 1
                else:
                    db_id = _insert_product(conn, row)
                    stats["added"] += 1
                excel_db_ids.add(int(db_id))
                # Update in-memory maps so duplicates after normalization merge during this import too.
                barcode = _barcode_key(row.get("barcode"))
                key = str(row.get("identity_key") or "").strip()
                norm = normalize_text(row.get("normalized_name") or row.get("name"))
                pid = str(row.get("product_id") or "").strip()
                if barcode:
                    maps["barcode"].setdefault(barcode, int(db_id))
                if key:
                    maps["identity_key"].setdefault(key, int(db_id))
                if norm:
                    maps["normalized_name"].setdefault(norm, int(db_id))
                if pid:
                    maps["product_id"].setdefault(pid, int(db_id))

            if not excel_db_ids:
                raise RuntimeError("REFUSING_TO_HIDE_ALL_PRODUCTS")
            placeholders = ",".join("?" for _ in excel_db_ids)
            cur = conn.execute(
                f"""
                UPDATE products
                SET available='false', search_mode='hidden', review_status='stale_missing_from_latest_excel', updated_at=datetime('now')
                WHERE id NOT IN ({placeholders})
                """,
                tuple(excel_db_ids),
            )
            stats["stale_marked_unavailable"] = int(cur.rowcount or 0)
            post_dedupe = _strict_dedupe_products_table(conn, price_policy=policy)
            stats["pre_existing_duplicate_groups"] = int(pre_dedupe.get("groups", 0))
            stats["pre_existing_duplicates_deleted"] = int(pre_dedupe.get("deleted", 0))
            stats["post_import_duplicate_groups"] = int(post_dedupe.get("groups", 0))
            stats["post_import_duplicates_deleted"] = int(post_dedupe.get("deleted", 0))

        integrity = database.integrity_check()
        if str(integrity).lower() != "ok":
            raise RuntimeError(f"DB_INTEGRITY_FAILED_AFTER_UPSERT: {integrity}")

        reindex = {"search_index": 0, "product_identity_registry": 0, "guided_catalog_index": 0, "warnings": []}
        if run_reindex:
            try:
                reindex["search_index"] = fast_rebuild_search_index()
                reindex["product_identity_registry"] = fast_rebuild_identity_registry()
                try:
                    reindex["guided_catalog_index"] = fast_rebuild_guided_index()
                except Exception as exc:
                    reindex["warnings"].append(f"guided_index_warning:{type(exc).__name__}:{exc}")
                try:
                    invalidate_excel_native_index()
                except Exception as exc:
                    reindex["warnings"].append(f"memory_index_warning:{type(exc).__name__}:{exc}")
                try:
                    import search_engine
                    search_engine.invalidate_memory_index()
                except Exception as exc:
                    reindex["warnings"].append(f"search_engine_cache_warning:{type(exc).__name__}:{exc}")
            except Exception:
                # The DB rows were committed.  Restore backup only if the core index
                # failed, because stale indexes could produce wrong answers.
                if backup and not getattr(database, "IS_POSTGRES", False):
                    database.restore_db_from_backup(Path(backup))
                raise

        report = {
            "mode": "smart_upsert",
            "excel_path": str(excel),
            "db_path": str(database.get_db_path()),
            "backup": backup,
            "duration_seconds": round(time.time() - start, 3),
            "price_policy": policy,
            "products_before": plan.get("old_products_count", 0),
            "products_after": database.count_products(),
            "excel_rows_raw": len(raw_rows),
            "excel_rows_after_dedupe": len(rows),
            "duplicate_rows_merged": dedupe_stats.get("duplicate_rows_merged", 0),
            "price_conflicts": dedupe_stats.get("price_conflicts", 0),
            "matched_by": dict(matched_by),
            "stats": dict(stats),
            "reindex": reindex,
            "integrity": integrity,
            "meta": meta,
        }
        report["report_path"] = str(_save_json_report(report, prefix="smart_upsert"))
        return report


def run_job(job_id: int, excel_path: str) -> Dict[str, Any]:
    """Background-job wrapper used by admin routes."""
    database.update_catalog_import_job(job_id, status="processing", report_text="Smart Upsert started")
    try:
        database.update_catalog_import_job(job_id, status="upserting")
        report = run_smart_upsert(excel_path, job_id=job_id, dry_run=False, run_reindex=True)
        stats = report.get("stats") or {}
        reindex = report.get("reindex") or {}
        database.update_catalog_import_job(
            job_id,
            status="completed",
            added=int(stats.get("added", 0)),
            updated=int(stats.get("updated", 0)),
            duplicate_conflicts=int(report.get("duplicate_rows_merged", 0)),
            report_text=json.dumps(report, ensure_ascii=False, indent=2, default=str)[-6000:],
        )
        database.audit_admin("catalog_smart_upsert_completed", details={"job_id": job_id, "stats": stats, "reindex": reindex})
        return report
    except Exception as exc:
        database.update_catalog_import_job(job_id, status="failed", report_text=f"{type(exc).__name__}: {exc}")
        database.audit_admin("catalog_smart_upsert_failed", details={"job_id": job_id, "error": repr(exc)})
        raise
