"""Auto catalog import service facade. Runtime import lives in tools/import_master_excel.py and admin routes."""
