from __future__ import annotations

"""General catalog identity generation for PriceBot.

This module is intentionally deterministic.  It does not invent prices,
availability, medical substitutions, or active ingredients.  It only normalizes
product identity strings that are already present or safely implied by the name,
brand, family, form, strength, size, and package text.
"""

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

from normalizer import compact_normalize, normalize_text, split_multi
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths, normalize_measure

UNKNOWN = {"", "unknown", "unclassified", "غير معروف", "غير مصنف", "none", "null", "na"}

# Words that may help describe a package, but must not become identity on their own.
WEAK_TOKENS: Set[str] = {
    "the", "and", "for", "with", "of", "to", "in", "new", "plus", "extra", "max", "forte", "advance", "advanced",
    "white", "black", "red", "blue", "green", "yellow", "baby", "kids", "junior", "adult",
    "cream", "creme", "gel", "ointment", "lotion", "serum", "cleanser", "wash", "foam", "soap",
    "moisturizer", "moisturizing", "moisturiser", "shampoo", "conditioner", "spray", "oil", "mask", "toner",
    "tablet", "tablets", "tab", "tabs", "capsule", "capsules", "cap", "caps", "syr", "syrup",
    "susp", "suspension", "supp", "drop", "drops", "inj", "amp", "solution", "sachet", "sachets",
    "skin", "face", "body", "hair", "care", "support", "supports", "health", "food", "supplement", "vitamin", "vitamins",
    "mg", "mcg", "ml", "g", "gm", "kg", "iu", "unit", "units", "30", "50", "100", "150", "200", "250", "500", "1000",
    "عبوه", "عبوة", "كريم", "جل", "مرهم", "لوشن", "سيروم", "غسول", "شامبو", "بلسم", "بخاخ", "زيت",
    "اقراص", "حبوب", "كبسولات", "كبسول", "شراب", "قطرات", "حقن", "اكياس", "ابيض", "ازرق", "احمر", "اسود",
}

# A conservative seed list.  The runtime dictionary is expanded from the catalog itself.
KNOWN_BRAND_SEEDS: Tuple[str, ...] = (
    "vichy", "cerave", "cera ve", "bioderma", "uriage", "eucerin", "la roche posay", "la roche", "laroche",
    "isdin", "isispharma", "acm", "rilastil", "photoblok", "dexeryl", "mebo", "panadol", "flagyl", "gaviscon",
    "amoclan", "daktarin", "gyno daktarin", "hemazym", "mari female", "propoli", "pro d3", "prod3", "ovanice",
    "luma fofo", "ocean aqua", "sinomarin", "remedica", "the ordinary", "avene", "svr", "ducray", "bepanthen",
)

# Safe OCR phrase expansions for package families whose visible label commonly
# includes stable phrase words omitted from short pharmacy price-list names.
# This is not a product-specific patch; it is an extensible identity phrase map.
FAMILY_OCR_PHRASES: Dict[str, Tuple[str, ...]] = {
    "normaderm": ("phytosolution", "phytosolution gel", "cleansing gel"),
    "hydrating cleanser": ("hydrating cleanser",),
    "foaming cleanser": ("foaming cleanser",),
    "mebo scar": ("mebo scar ointment", "reduce scars"),
    "hemazym": ("liposomal iron", "iron supplement", "folic acid", "vitamin b12"),
    "propoli": ("concentrated fluid", "food supplement"),
    "mari female": ("female fertility",),
    "prod3": ("pro d3", "pro-d3", "vitamin d3", "vitamin k2"),
    "pro d3": ("prod3", "pro-d3", "vitamin d3", "vitamin k2"),
    "dexeryl": ("dexeryl cream", "crème", "glycerol vaseline paraffin"),
}

FORM_DISPLAY_HINTS = {
    "cleanser": "Cleanser", "cream": "Cream", "ointment": "Ointment", "gel": "Gel", "lotion": "Lotion",
    "serum": "Serum", "syrup": "Syrup", "suspension": "Suspension", "tablet": "Tablet", "capsule": "Capsule",
    "drops": "Drops", "spray": "Spray", "sachet": "Sachet", "shampoo": "Shampoo",
}


def _bad(value: Any) -> bool:
    return normalize_text(value) in UNKNOWN


def _n(value: Any) -> str:
    return normalize_text(value)


def _compact(value: Any) -> str:
    return compact_normalize(value)


def _tokens(value: Any) -> List[str]:
    return [t for t in _n(value).split() if t]


def _title_from_source(norm_phrase: str, source: str = "") -> str:
    norm_phrase = _n(norm_phrase)
    if not norm_phrase:
        return ""
    source_text = str(source or "").strip()
    if source_text:
        # Preserve uppercase brand styles when the same token appears in source.
        for token in source_text.replace("-", " ").split():
            if _n(token) == norm_phrase:
                return token.strip(" ,;/()[]")
    special = {
        "vichy": "Vichy", "cerave": "Cerave", "cera ve": "Cerave", "bioderma": "Bioderma", "uriage": "Uriage",
        "eucerin": "Eucerin", "laroche": "La Roche", "la roche": "La Roche", "la roche posay": "La Roche-Posay",
        "mebo": "MEBO", "prod3": "Pro-D3", "pro d3": "Pro-D3", "hemazym": "Hemazym", "propoli": "PROPOLI",
        "mari female": "MARI FEMALE", "gyno daktarin": "Gyno Daktarin",
    }
    if norm_phrase in special:
        return special[norm_phrase]
    return " ".join(part.upper() if len(part) <= 3 and part.isalpha() else part.capitalize() for part in norm_phrase.split())


def _contains_phrase(norm_text: str, phrase: str) -> bool:
    phrase = _n(phrase)
    if not phrase:
        return False
    return norm_text == phrase or norm_text.startswith(phrase + " ") or norm_text.endswith(" " + phrase) or f" {phrase} " in f" {norm_text} "


def _remove_phrase(norm_text: str, phrase: str) -> str:
    phrase = _n(phrase)
    if not norm_text or not phrase:
        return norm_text
    pattern = r"(^|\s)" + re.escape(phrase) + r"(?=\s|$)"
    return re.sub(pattern, " ", norm_text).strip()


def _merge_values(*values: Any, limit: int = 40) -> str:
    out: List[str] = []
    seen: Set[str] = set()
    for value in values:
        vals = value if isinstance(value, (list, tuple, set)) else split_multi(value)
        if isinstance(value, str) and "|" not in value and ";" not in value and "," not in value:
            vals = [value]
        for part in vals:
            raw = str(part or "").strip()
            norm = _n(raw)
            if not raw or not norm or norm in UNKNOWN:
                continue
            if norm in seen:
                continue
            seen.add(norm)
            out.append(raw)
            if len(out) >= limit:
                return " | ".join(out)
    return " | ".join(out)


@dataclass
class BrandFamilyResult:
    brand: str
    brand_display: str
    family: str
    family_display: str
    canonical_name: str
    was_reordered: bool = False


class BrandFamilyNormalizer:
    def __init__(self, rows: Sequence[Dict[str, Any]] = (), extra_brands: Iterable[str] = ()) -> None:
        self.known_brands = self.build_known_brands(rows, extra_brands)
        self.known_brands_sorted = sorted(self.known_brands, key=len, reverse=True)
        self.known_brands_by_first: Dict[str, List[str]] = {}
        for brand in self.known_brands_sorted:
            first = brand.split()[0] if brand.split() else ""
            if first:
                self.known_brands_by_first.setdefault(first, []).append(brand)

    @staticmethod
    def build_known_brands(rows: Sequence[Dict[str, Any]], extra_brands: Iterable[str] = ()) -> Set[str]:
        brands: Set[str] = {_n(x) for x in KNOWN_BRAND_SEEDS}
        brands.update(_n(x) for x in extra_brands)
        explicit_counts: Dict[str, int] = {}
        for row in rows:
            brand = _n(row.get("brand") or row.get("company") or "")
            if brand and brand not in UNKNOWN and brand not in WEAK_TOKENS and not brand.isdigit():
                explicit_counts[brand] = explicit_counts.get(brand, 0) + 1
            name = _n(row.get("name") or row.get("original_name") or "")
            # Seed brands visible in names are trusted; arbitrary first tokens are not.
            for seed in KNOWN_BRAND_SEEDS:
                s = _n(seed)
                if s and _contains_phrase(name, s):
                    brands.add(s)
        # Add only repeated explicit brands to prevent thousands of first-token
        # pseudo-brands from making catalog generation O(N^2).
        for brand, count in explicit_counts.items():
            if count >= 2 or brand in brands:
                brands.add(brand)
        return {b for b in brands if b and len(b) >= 3}

    def detect_brand(self, row: Dict[str, Any]) -> Tuple[str, str]:
        name_raw = str(row.get("name") or row.get("original_name") or "").strip()
        name_norm = _n(name_raw)
        explicit_raw = str(row.get("brand") or row.get("company") or "").strip()
        explicit = _n(explicit_raw)
        found: List[str] = []
        candidate_brands: List[str] = []
        seen_candidates: Set[str] = set()
        for token in name_norm.split():
            for brand in self.known_brands_by_first.get(token, []):
                if brand not in seen_candidates:
                    seen_candidates.add(brand)
                    candidate_brands.append(brand)
        for brand in candidate_brands:
            if _contains_phrase(name_norm, brand):
                found.append(brand)
        # Prefer a known brand visible in the name over a bad first-token fallback.
        if found:
            b = found[0]
            return b, _title_from_source(b, name_raw or explicit_raw)
        if explicit and explicit not in UNKNOWN and explicit not in WEAK_TOKENS:
            return explicit, explicit_raw or _title_from_source(explicit, name_raw)
        toks = [t for t in str(name_raw).split() if t.strip()]
        if toks:
            first = toks[0].strip(" ,;/()[]")
            nf = _n(first)
            if nf and nf not in WEAK_TOKENS and nf not in UNKNOWN and not nf.isdigit():
                return nf, first
        return "", ""

    def normalize_row_identity(self, row: Dict[str, Any]) -> BrandFamilyResult:
        name_raw = str(row.get("name") or row.get("original_name") or "").strip()
        name_norm = _n(name_raw)
        brand, brand_display = self.detect_brand(row)
        family_raw = str(row.get("product_family") or "").strip()
        family_norm = _n(family_raw)
        if not family_norm or family_norm in UNKNOWN:
            family_norm = _remove_phrase(name_norm, brand)
        else:
            family_norm = _remove_phrase(family_norm, brand)
        # If family was just the full old name, remove the brand at either edge.
        if family_norm == name_norm and brand:
            family_norm = _remove_phrase(name_norm, brand)
        family_norm = re.sub(r"\s+", " ", family_norm).strip()
        # Keep at least two useful words where possible, but do not use pure form/size.
        if not family_norm or family_norm in WEAK_TOKENS:
            toks = [t for t in _tokens(name_norm) if t != brand and t not in WEAK_TOKENS]
            family_norm = " ".join(toks[:4])
        family_display = _title_from_source(family_norm, family_raw or name_raw)
        if brand and family_norm:
            canonical = f"{brand_display} {family_display}".strip()
            was_reordered = not _n(name_raw).startswith(brand + " ") and _contains_phrase(name_norm, brand)
        else:
            canonical = name_raw
            was_reordered = False
        return BrandFamilyResult(brand, brand_display, family_norm, family_display, canonical, was_reordered)

    def normalize_row(self, row: Dict[str, Any]) -> Dict[str, str]:
        out = dict(row)
        ident = self.normalize_row_identity(out)
        if ident.brand:
            out["brand"] = ident.brand_display
            out.setdefault("company", ident.brand_display)
            if _bad(out.get("company")):
                out["company"] = ident.brand_display
        if ident.family:
            out["product_family"] = ident.family_display
        if ident.canonical_name and ident.was_reordered:
            out.setdefault("original_name", out.get("name") or ident.canonical_name)
            out["name"] = ident.canonical_name
            out["normalized_name"] = _n(ident.canonical_name)
        elif not out.get("normalized_name"):
            out["normalized_name"] = _n(out.get("name") or "")
        return {k: str(v) if v is not None else "" for k, v in out.items()}


class CatalogAliasGenerator:
    def __init__(self, normalizer: BrandFamilyNormalizer | None = None) -> None:
        self.normalizer = normalizer or BrandFamilyNormalizer(())

    def identity_variations(self, row: Dict[str, Any]) -> Tuple[List[str], List[str]]:
        r = self.normalizer.normalize_row(row)
        ident = self.normalizer.normalize_row_identity(r)
        name = str(r.get("name") or r.get("original_name") or "").strip()
        original = str(r.get("original_name") or row.get("name") or "").strip()
        brand = ident.brand_display or str(r.get("brand") or "").strip()
        family = ident.family_display or str(r.get("product_family") or "").strip()
        form = canonical_form(r.get("form") or r.get("product_type") or r.get("medicine_form") or name) or ""
        strength = str(r.get("strength") or "").strip()
        size = str(r.get("size") or "").strip()
        pack = str(r.get("pack") or "").strip()

        aliases: List[str] = []
        ocr: List[str] = []

        def add_alias(x: Any) -> None:
            raw = str(x or "").strip()
            if raw and _n(raw) not in UNKNOWN:
                aliases.append(raw)

        def add_ocr(x: Any) -> None:
            raw = str(x or "").strip()
            if raw and _n(raw) not in UNKNOWN:
                ocr.append(raw)

        for x in [original, name, r.get("normalized_name"), _compact(name), _compact(original)]:
            add_alias(x)
        if brand and family:
            base = f"{brand} {family}".strip()
            rev = f"{family} {brand}".strip()
            for x in [base, rev, _compact(base), _compact(rev)]:
                add_alias(x)
                add_ocr(x)
            if form:
                fd = FORM_DISPLAY_HINTS.get(form, form)
                add_alias(f"{base} {fd}")
                add_ocr(f"{base} {fd}")
            for m in [strength, size, pack]:
                if m:
                    add_alias(f"{base} {m}")
                    add_ocr(f"{base} {m}")
            if form and (size or strength):
                fd = FORM_DISPLAY_HINTS.get(form, form)
                add_alias(" ".join(x for x in [base, fd, strength or size] if x))
                add_ocr(" ".join(x for x in [base, fd, strength or size] if x))
        # Exact phrase without symbols, and phrase without weak marketing descriptors.
        clean_name = re.sub(r"[^0-9A-Za-z\u0600-\u06FF]+", " ", name).strip()
        add_alias(clean_name)
        useful = " ".join(t for t in _tokens(name) if t not in WEAK_TOKENS)
        if useful:
            add_alias(useful)
            add_ocr(useful)
        # Stable package OCR phrase expansions for families.
        norm_blob = _n(" ".join([name, original, brand, family]))
        for key, phrases in FAMILY_OCR_PHRASES.items():
            if _contains_phrase(norm_blob, key):
                for phrase in phrases:
                    phrase_display = _title_from_source(phrase, phrase)
                    if brand and family:
                        base = f"{brand} {family}".strip()
                        add_alias(f"{base} {phrase_display}")
                        add_ocr(f"{base} {phrase_display}")
                        if form:
                            fd = FORM_DISPLAY_HINTS.get(form, form)
                            add_ocr(f"{base} {phrase_display} {fd}")
                        if size:
                            add_ocr(f"{base} {phrase_display} {size}")
                    add_alias(phrase_display)
                    add_ocr(phrase_display)
        return _dedupe_list(aliases, limit=50), _dedupe_list(ocr, limit=50)


def _dedupe_list(values: Iterable[Any], limit: int = 40) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for value in values:
        raw = str(value or "").strip()
        norm = _n(raw)
        if not raw or not norm or norm in UNKNOWN:
            continue
        if len(norm) <= 1:
            continue
        if norm in seen:
            continue
        seen.add(norm)
        out.append(raw)
        if len(out) >= limit:
            break
    return out


def enrich_catalog_identity(rows: Sequence[Dict[str, Any]]) -> Tuple[List[Dict[str, str]], Dict[str, int]]:
    normalizer = BrandFamilyNormalizer(rows)
    generator = CatalogAliasGenerator(normalizer)
    out: List[Dict[str, str]] = []
    stats = {"rows_seen": len(rows), "brand_family_normalized": 0, "canonical_reordered": 0, "aliases_generated": 0, "ocr_keywords_generated": 0}
    for row in rows:
        before_name = str(row.get("name") or "")
        before_brand = str(row.get("brand") or "")
        before_family = str(row.get("product_family") or "")
        r = normalizer.normalize_row(dict(row))
        aliases, ocr = generator.identity_variations(r)
        merged_aliases = _merge_values(r.get("aliases"), aliases, limit=60)
        merged_ocr = _merge_values(r.get("ocr_keywords"), ocr, limit=60)
        r["aliases"] = merged_aliases
        r["ocr_keywords"] = merged_ocr
        r["normalized_name"] = _n(r.get("name") or r.get("normalized_name") or "")
        # Fill missing safe measures/forms from name/aliases only.
        if _bad(r.get("form")):
            form = canonical_form(" ".join([r.get("name", ""), merged_aliases, merged_ocr]))
            if form:
                r["form"] = form
                r.setdefault("product_type", form)
                r.setdefault("medicine_form", form)
        if not str(r.get("strength") or "").strip():
            strengths = extract_strengths(" ".join([r.get("name", ""), merged_aliases, merged_ocr]))
            if strengths:
                r["strength"] = strengths[0]
        if not str(r.get("size") or "").strip():
            sizes = extract_sizes(" ".join([r.get("name", ""), merged_aliases, merged_ocr]))
            if sizes:
                r["size"] = sizes[0]
        if not str(r.get("pack") or "").strip():
            packs = extract_packs(" ".join([r.get("name", ""), merged_aliases, merged_ocr]))
            if packs:
                r["pack"] = packs[0]
        if str(r.get("name") or "") != before_name:
            stats["canonical_reordered"] += 1
        if str(r.get("brand") or "") != before_brand or str(r.get("product_family") or "") != before_family:
            stats["brand_family_normalized"] += 1
        stats["aliases_generated"] += len(split_multi(merged_aliases))
        stats["ocr_keywords_generated"] += len(split_multi(merged_ocr))
        out.append({k: str(v) if v is not None else "" for k, v in r.items()})
    return out, stats


def generated_aliases_for_product(product: Dict[str, Any]) -> List[str]:
    normalizer = BrandFamilyNormalizer([product])
    gen = CatalogAliasGenerator(normalizer)
    aliases, ocr = gen.identity_variations(product)
    return _dedupe_list(list(split_multi(product.get("aliases"))) + aliases + list(split_multi(product.get("ocr_keywords"))) + ocr, limit=80)
