"""Derived index rebuild facade."""
from search_engine import rebuild_search_index, invalidate_memory_index
from product_identity import rebuild_product_identity_registry
try:
    from guided_commerce import rebuild_guided_index
except Exception:  # pragma: no cover
    rebuild_guided_index = None
