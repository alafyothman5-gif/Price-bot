"""Catalog verification facade; executable verifier is tools/verify_production.py."""
