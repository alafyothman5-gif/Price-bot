from __future__ import annotations

"""Catalog upload staging workflow.

Weekly merchant Excel files are price lists, not the master catalog.  This file
keeps the historical function names used by routes/tasks, but delegates to the
final Catalog Ingestion Master pipeline:
Upload -> Staging -> Normalize -> Match Existing -> Dedupe -> Review -> Approve -> Promote.
"""

from typing import Any, Dict

import database
from services.catalog.catalog_ingestion_master import (
    approve_ingestion_job,
    create_ingestion_plan,
    reject_ingestion_job,
)


def create_and_verify_staging_job(job_id: int, excel_path: str, merchant_id: int = 1) -> Dict[str, Any]:
    """Stage and analyze an Excel upload without changing production products."""
    database.update_catalog_import_job(
        int(job_id),
        status="staging_processing",
        job_type="catalog_ingestion_master",
        merchant_id=int(merchant_id or 1),
        report_text="Catalog Ingestion Master started. Production products are untouched until approval.",
    )
    try:
        return create_ingestion_plan(int(job_id), str(excel_path), int(merchant_id or 1))
    except Exception as exc:
        database.update_catalog_import_job(
            int(job_id),
            status="failed",
            error_text=f"{type(exc).__name__}: {exc}",
            report_text=f"CATALOG_INGESTION_FAILED: {type(exc).__name__}: {exc}",
        )
        database.audit_admin("catalog_ingestion_failed", details={"job_id": int(job_id), "error": repr(exc)})
        raise


def approve_staging_job(job_id: int, actor: str = "admin", *, full_inventory_upload: bool = False, mark_missing_unavailable: bool = False) -> Dict[str, Any]:
    """Promote only safe approved actions after backup, reindex and tests."""
    return approve_ingestion_job(
        int(job_id),
        actor=actor,
        full_inventory_upload=bool(full_inventory_upload),
        mark_missing_unavailable=bool(mark_missing_unavailable),
    )


def reject_staging_job(job_id: int, actor: str = "admin", reason: str = "") -> Dict[str, Any]:
    return reject_ingestion_job(int(job_id), actor=actor, reason=reason)
