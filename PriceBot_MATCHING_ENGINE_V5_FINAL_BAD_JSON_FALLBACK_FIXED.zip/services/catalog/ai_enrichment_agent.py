from __future__ import annotations

"""Mandatory catalog enrichment for PriceBot.

This module is part of the Excel ingestion path.  It is not optional and it is
not controlled by PRICEBOT_AI_ENRICHMENT.  Every imported row passes through
this module before it is saved.  When an OpenRouter key is configured, rows with
missing catalog fields are sent in batches to the configured model.  When a key
is not present in a local/test environment, the deterministic classifier still
resolves customer-facing catalog labels so no row is persisted as
Unknown/Unclassified.

The agent never writes price, availability, or therapeutic substitutions.
"""

import json
import os
from typing import Any, Dict, Iterable, List, Tuple

import httpx

import config_env
from guided_commerce import classify_main_section, classify_sub_section
from normalizer import normalize_text
from query_slots import canonical_form

UNKNOWN = {"", "unknown", "unclassified", "غير معروف", "غير مصنف", "none", "null", "na"}
SECTION_TO_CATEGORY = {
    "أدوية": "medicine",
    "مكملات وفيتامينات": "supplement",
    "عناية بالبشرة": "cosmetic",
    "عناية بالشعر": "cosmetic",
    "أطفال": "other",
    "أجهزة ومستلزمات": "other",
    "عناية شخصية": "other",
}
ALLOWED_CATEGORY = {"medicine", "cosmetic", "supplement", "other"}


def _bad(value: object) -> bool:
    return normalize_text(value) in UNKNOWN


def _clean(value: object) -> str:
    text = str(value or "").strip()
    return "" if _bad(text) else text


def _first_token_brand(name: str) -> str:
    toks = [t for t in str(name or "").replace("+", " ").split() if t.strip()]
    if not toks:
        return ""
    first = toks[0].strip("-_/,.()[]")
    if len(first) <= 1 or normalize_text(first) in UNKNOWN:
        return ""
    return first


def _safe_fallback_section(row: Dict[str, Any]) -> Tuple[str, str, str]:
    product = dict(row)
    main = classify_main_section(product)
    sub = classify_sub_section(product, main)
    if _bad(main):
        main = "عناية شخصية"
    if _bad(sub):
        sub = "منتجات عناية شخصية"
    category = SECTION_TO_CATEGORY.get(main) or product.get("category") or "other"
    if normalize_text(category) not in ALLOWED_CATEGORY:
        category = "other"
    return category, main, sub


def deterministic_enrich(row: Dict[str, Any]) -> Tuple[Dict[str, str], Dict[str, Any]]:
    """Return mandatory safe enrichment for one row.

    The result deliberately removes Unknown/Unclassified and needs_review from
    the customer-facing import result.  Ambiguity is preserved in review_notes,
    not by leaving broken catalog labels in production.
    """
    product = dict(row)
    changed: Dict[str, str] = {}
    confidence = 0.0

    category, main, sub = _safe_fallback_section(product)
    if _bad(product.get("category")):
        changed["category"] = category
        confidence = max(confidence, 0.72)
    if _bad(product.get("main_section") or product.get("section")):
        changed["main_section"] = main
        changed.setdefault("section", main)
        confidence = max(confidence, 0.78 if main != "عناية شخصية" else 0.66)
    if _bad(product.get("sub_section") or product.get("subcategory")):
        changed["sub_section"] = sub
        changed["subcategory"] = sub
        confidence = max(confidence, 0.78 if sub != "منتجات عناية شخصية" else 0.66)

    if _bad(product.get("brand")):
        brand = _first_token_brand(str(product.get("name") or product.get("original_name") or ""))
        if brand:
            changed["brand"] = brand
            confidence = max(confidence, 0.70)
    if _bad(product.get("product_family")):
        family = str(product.get("name") or product.get("original_name") or "").strip()
        if family:
            changed["product_family"] = family
            confidence = max(confidence, 0.70)
    if _bad(product.get("form")):
        form = canonical_form(product.get("name") or product.get("original_name") or "")
        if form:
            changed["form"] = form
            confidence = max(confidence, 0.82)

    # Final hard guarantee: no production row remains unknown/unclassified.
    for key, fallback in {
        "category": category or "other",
        "main_section": main or "عناية شخصية",
        "sub_section": sub or "منتجات عناية شخصية",
        "subcategory": sub or "منتجات عناية شخصية",
        "brand": _first_token_brand(str(product.get("name") or product.get("original_name") or "")) or "Generic",
        "product_family": str(product.get("name") or product.get("original_name") or "").strip() or "Generic Product",
    }.items():
        if _bad(changed.get(key) or product.get(key)):
            changed[key] = fallback
            confidence = max(confidence, 0.61)

    # The import contract requires no needs_review/unclassified rows after
    # enrichment.  Lower-confidence rows are marked ai_enriched_low_confidence
    # with notes for audit, but they remain classified and searchable safely.
    status = "ai_enriched" if confidence >= 0.75 else "ai_enriched_low_confidence"
    changed["review_status"] = status
    notes = str(product.get("review_notes") or "").strip()
    note = f"mandatory_enrichment_confidence={confidence:.2f}"
    changed["review_notes"] = (notes + " | " + note).strip(" |") if notes else note
    return changed, {"confidence": round(confidence, 2), "source": "deterministic_mandatory", "accepted": True}


def _openrouter_key() -> str:
    return config_env.resolve_openrouter_api_key() or os.getenv("OPENROUTER_API_KEY", "").strip()


def external_ai_available() -> bool:
    """OpenRouter is used whenever configured. There is no env flag to disable it."""
    return bool(_openrouter_key())


def _needs_enrichment(row: Dict[str, Any]) -> bool:
    return any(_bad(row.get(c)) for c in ["category", "main_section", "sub_section", "subcategory", "brand", "product_family", "form"])


def _build_prompt(batch: List[Dict[str, str]]) -> str:
    items = []
    for i, row in enumerate(batch):
        items.append({
            "i": i,
            "name": row.get("name") or row.get("original_name") or "",
            "brand": row.get("brand") or "",
            "category": row.get("category") or "",
            "main_section": row.get("main_section") or row.get("section") or "",
            "sub_section": row.get("sub_section") or row.get("subcategory") or "",
            "form": row.get("form") or row.get("product_type") or row.get("medicine_form") or "",
            "strength": row.get("strength") or "",
            "size": row.get("size") or "",
        })
    return (
        "Classify pharmacy catalog rows. Return ONLY a JSON array. "
        "For every item return: i, category(one of medicine/cosmetic/supplement/other), "
        "main_section_ar, sub_section_ar, brand, product_family, form, strength, size, confidence. "
        "Do not invent price, availability, active ingredient, or therapeutic alternatives. "
        "Never return unknown/unclassified/needs_review. Rows:\n" + json.dumps(items, ensure_ascii=False)
    )


def _apply_ai_result(row: Dict[str, str], result: Dict[str, Any]) -> Dict[str, str]:
    out = dict(row)
    try:
        conf = float(result.get("confidence") or 0)
    except Exception:
        conf = 0.0
    if conf < 0.55:
        return out
    mapping = {
        "category": result.get("category"),
        "main_section": result.get("main_section_ar") or result.get("main_section"),
        "section": result.get("main_section_ar") or result.get("main_section"),
        "sub_section": result.get("sub_section_ar") or result.get("sub_section"),
        "subcategory": result.get("sub_section_ar") or result.get("sub_section"),
        "brand": result.get("brand"),
        "product_family": result.get("product_family"),
        "form": result.get("form"),
        "strength": result.get("strength"),
        "size": result.get("size"),
    }
    for k, v in mapping.items():
        if v is not None and not _bad(v) and (_bad(out.get(k)) or k in {"category", "main_section", "section", "sub_section", "subcategory"}):
            out[k] = str(v).strip()
    out["review_status"] = "ai_enriched"
    note = f"openrouter_enrichment_confidence={conf:.2f}"
    old = str(out.get("review_notes") or "").strip()
    out["review_notes"] = (old + " | " + note).strip(" |") if old else note
    return out


def _call_openrouter_batch(batch: List[Dict[str, str]]) -> Tuple[List[Dict[str, str]], Dict[str, Any]]:
    key = _openrouter_key()
    if not key or not batch:
        return batch, {"called": 0, "error": "missing_openrouter_key" if not key else ""}
    model = os.getenv("OPENROUTER_CATALOG_MODEL", "google/gemini-2.5-flash-lite").strip() or "google/gemini-2.5-flash-lite"
    try:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "You are a strict pharmacy product catalog classifier. Output valid JSON only."},
                {"role": "user", "content": _build_prompt(batch)},
            ],
            "temperature": 0,
        }
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        with httpx.Client(timeout=45) as client:
            response = client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        parsed = json.loads(content)
        if not isinstance(parsed, list):
            raise ValueError("AI_RESPONSE_NOT_LIST")
        by_i = {int(x.get("i")): x for x in parsed if isinstance(x, dict) and str(x.get("i", "")).isdigit()}
        out = []
        for i, row in enumerate(batch):
            out.append(_apply_ai_result(row, by_i.get(i, {})))
        usage = data.get("usage") or {}
        return out, {"called": len(batch), "model": model, "usage": usage, "error": ""}
    except Exception as exc:
        # Import must remain deterministic and classified even if the upstream AI
        # provider is unreachable.  The mandatory local classifier below remains active.
        return batch, {"called": 0, "model": model, "error": f"{type(exc).__name__}: {exc}"}


def _chunks(rows: List[Dict[str, str]], size: int) -> Iterable[List[Dict[str, str]]]:
    for i in range(0, len(rows), size):
        yield rows[i : i + size]


def enrich_rows(rows: List[Dict[str, str]], max_ai_rows: int = 0) -> Tuple[List[Dict[str, str]], Dict[str, Any]]:
    """Enrich every imported row.

    The enrichment pass is compulsory.  OpenRouter is used automatically when a
    key exists.  There is no feature flag that disables enrichment or leaves
    Unknown/Unclassified rows in the final imported catalog.
    """
    stats = {
        "rows_seen": len(rows),
        "mandatory_enrichment": True,
        "external_ai_available": external_ai_available(),
        "external_ai_called": 0,
        "external_ai_errors": [],
        "deterministic_touched": 0,
        "unclassified_after": 0,
        "needs_review_after": 0,
    }

    current: List[Dict[str, str]] = [dict(r) for r in rows]

    # External AI first for all rows needing missing catalog fields.  The limit
    # parameter is ignored intentionally; enrichment is not optional.
    if external_ai_available():
        targets = [(i, r) for i, r in enumerate(current) if _needs_enrichment(r)]
        batch_size = max(1, int(os.getenv("OPENROUTER_CATALOG_BATCH_SIZE", "25") or 25))
        for chunk in _chunks([r for _, r in targets], batch_size):
            ai_rows, meta = _call_openrouter_batch(chunk)
            stats["external_ai_called"] += int(meta.get("called") or 0)
            if meta.get("error"):
                stats["external_ai_errors"].append(meta.get("error"))
            # Re-map sequential chunk rows back to their original indexes.
            base = 0
            for original_i, _ in targets:
                if base < len(ai_rows):
                    current[original_i] = ai_rows[base]
                    base += 1
                if base >= len(chunk):
                    break
            targets = targets[len(chunk):]

    enriched: List[Dict[str, str]] = []
    for row in current:
        changes, _meta = deterministic_enrich(row)
        if changes:
            row.update({k: str(v) for k, v in changes.items() if v is not None})
            stats["deterministic_touched"] += 1
        # Hard final cleanup.
        for key, fallback in {
            "category": "other",
            "main_section": "عناية شخصية",
            "section": "عناية شخصية",
            "sub_section": "منتجات عناية شخصية",
            "subcategory": "منتجات عناية شخصية",
            "brand": "Generic",
            "product_family": str(row.get("name") or row.get("original_name") or "Generic Product"),
            "review_status": "ai_enriched_low_confidence",
        }.items():
            if _bad(row.get(key)) or (key == "review_status" and normalize_text(row.get(key)) in {"needs_review", "unclassified"}):
                row[key] = fallback
        if any(_bad(row.get(k)) for k in ["category", "main_section", "sub_section", "subcategory"]):
            stats["unclassified_after"] += 1
        if normalize_text(row.get("review_status")) in {"needs_review", "unclassified"}:
            stats["needs_review_after"] += 1
        enriched.append(row)
    return enriched, stats
