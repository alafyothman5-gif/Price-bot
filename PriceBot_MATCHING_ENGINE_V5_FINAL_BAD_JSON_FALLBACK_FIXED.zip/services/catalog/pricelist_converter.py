from __future__ import annotations

"""Raw pharmacy price-list converter.

This module converts the original pharmacy Excel shape:
    سعر علبة | سعر شريط | الصنـــــــف | ت
into the organized PriceBot products_master_ready.xlsx schema.

Rules:
- Keep every product row. Never collapse duplicate names.
- Use source serial as product_id (PL00001, PL02448, ...), so rows remain stable.
- Do not invent medical facts. Only classify obvious forms/categories and put uncertain rows in needs_review.
- Add OCR/alias terms needed for image matching when the package identity is obvious.
"""

import re
from collections import Counter
from typing import Dict, Iterable, List, Tuple

from normalizer import normalize_text, compact_normalize, safe_price
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths

RAW_NAME_HEADERS = {"الصنـــــــف", "الصنف", "الصنـف", "المنتج", "اسم الصنف", "name", "product", "item"}
RAW_SERIAL_HEADERS = {"ت", "serial", "no", "#"}
RAW_BOX_PRICE_HEADERS = {"سعر علبة", "سعر العلبة", "box price", "price box"}
RAW_STRIP_PRICE_HEADERS = {"سعر شريط", "سعر الشريط", "strip price", "price strip"}

# Output contract. The first 35 columns match database.PRODUCT_COLUMNS in this project.
MASTER_COLUMNS = [
    "product_id", "name", "normalized_name", "brand", "company", "category", "section", "product_family",
    "form", "product_type", "active_ingredient", "strength", "size", "pack", "barcode", "aliases", "ocr_keywords",
    "use_case", "skin_type", "body_area", "age_group", "gender", "medicine_form", "medicine_route", "available",
    "price", "currency", "search_mode", "quality_status", "is_substitutable", "substitution_group_id",
    "review_status", "review_notes", "source_serial", "original_name",
    # Extra audit columns: ignored by DB importer but useful for humans.
    "box_price", "strip_price", "price_source", "raw_row_number", "duplicate_name_count", "duplicate_price_conflict",
]

MULTIWORD_BRANDS = [
    "la roche posay", "la roche", "the ordinary", "uriage bariederm", "bioderma atoderm", "bioderma sebium",
    "eucerin aquaphor", "cerave sa", "gyno daktarin", "pro d3", "pro-d3", "mari female", "mari erectom",
    "mebo scar", "mebo oint", "panadol advance", "panadol extra", "panadol cold", "panadol baby", "panadol night",
    "gaviscon double", "amoclan forte", "luma fofo", "ocean aqua", "sinomarin adult", "sinomarin babies",
]

SUPPLEMENT_MARKERS = {
    "vitamin", "vit", "d3", "omega", "iron", "fer", "folic", "b12", "calcium", "magnesium", "zinc", "centrum",
    "collagen", "probiotic", "supplement", "fertility", "mari", "ovanice", "globifer", "hemazym", "multivitamin",
    "propolis", "propoli", "marine collagen", "folate", "hyaluronics",
}
COSMETIC_MARKERS = {
    "cream", "serum", "cleanser", "lotion", "moistur", "sunscreen", "spf", "sunblock", "shampoo", "conditioner",
    "mask", "toner", "gel", "ointment", "scar", "acne", "blemish", "retinol", "hydrating", "foaming",
    "body milk", "oil cleanser", "hair", "skin", "foot cream", "dexeryl", "mebo", "cerave", "rilastil", "bioderma",
    "uriage", "eucerin", "photoblok", "laroche", "la roche", "vichy", "isispharma", "luma fofo",
}
OTHER_MARKERS = {
    "diaper", "glove", "syringe", "needle", "spirometer", "thermometer", "mask n95", "test", "strip", "lancet",
    "bandage", "walker", "wheelchair", "catheter", "gauze", "pad", "equipment", "compressor", "nebulizer",
}
MEDICINE_MARKERS = {
    "mg", "mcg", "iu", "susp", "syp", "syr", "syrup", "tab", "tablet", "caps", "cap", "supp", "inj", "amp", "drop",
    "flagyl", "amoclan", "panadol", "gaviscon", "cipralex", "janumet", "concor", "exforge", "twynsta", "zofran",
}

KNOWN_PACKAGE_OCR = {
    "hemazym": {
        "category": "supplement", "main_section": "مكملات وفيتامينات", "sub_section": "iron", "form": "capsule",
        "pack": "30 capsules", "use_case": "iron", "aliases": ["Hemazym", "Hemazym Iron", "Liposomal Hemazym"],
        "ocr": ["Hemazym", "Liposomal Iron", "Iron Supplement", "Folic Acid", "Vitamin B12", "30 capsules", "حديد", "كبسولات حديد"],
    },
    "mari female": {
        "category": "supplement", "main_section": "مكملات وفيتامينات", "sub_section": "fertility", "form": "sachet",
        "pack": "30 sachet", "use_case": "fertility", "aliases": ["Mari Female", "MARI FEMALE Female Fertility", "mari female fertility"],
        "ocr": ["MARI FEMALE", "Female Fertility", "3600mg", "30 Sachet", "108g"],
    },
    "mebo scar": {
        "category": "cosmetic", "main_section": "عناية بالبشرة", "sub_section": "skincare_scar", "form": "ointment",
        "size": "30g", "use_case": "scar", "aliases": ["mebo scar", "mebo scar ointment", "mebo scar 30g"],
        "ocr": ["MEBO SCAR", "MEBO SCAR OINTMENT", "REDUCE SCARS", "30g"],
    },
    "propoli": {
        "category": "supplement", "main_section": "مكملات وفيتامينات", "sub_section": "supplement_unspecified",
        "aliases": ["Propoli", "PROPOLI Concentrated Fluid"],
        "ocr": ["PROPOLI", "Concentrated Fluid", "Food Supplement"],
    },
    "pro d3": {
        "category": "supplement", "main_section": "مكملات وفيتامينات", "sub_section": "vitamins", "use_case": "vitamin_d",
        "aliases": ["Pro-D3", "Pro D3", "prod3"], "ocr": ["Pro-D3", "Vitamin D3", "Vitamin K2"],
    },
    "prod3": {
        "category": "supplement", "main_section": "مكملات وفيتامينات", "sub_section": "vitamins", "use_case": "vitamin_d",
        "aliases": ["Pro-D3", "Pro D3", "prod3"], "ocr": ["Pro-D3", "Vitamin D3", "Vitamin K2"],
    },
    "ovanice": {
        "category": "supplement", "main_section": "مكملات وفيتامينات", "sub_section": "fertility", "form": "capsule",
        "pack": "90 capsules", "use_case": "fertility", "aliases": ["Ovanice", "Ovanice Female Fertility"],
        "ocr": ["Ovanice", "Female Fertility", "90 capsules", "850mg"],
    },
    "dexeryl": {
        "category": "cosmetic", "main_section": "عناية بالبشرة", "sub_section": "skincare_cream", "form": "cream",
        "aliases": ["DEXERYL CREAM", "Dexeryl cream"], "ocr": ["DEXERYL", "DEXERYL cream", "crème", "250g tube"],
    },
}

ARABIC_ALIASES = {
    "panadol": ["بنادول", "بانادول"],
    "flagyl": ["فلاجيل"],
    "gaviscon": ["جافيسكون"],
    "amoclan": ["اموكلان"],
    "cerave": ["سيرافي", "سيرا في"],
    "mebo": ["ميبو"],
    "hemazym": ["هيمازيم"],
}

# Conservative catalog normalization for well-known pharmacy price-list rows
# where the original Excel gives a family + strength but omits the dosage form.
# These rules are intentionally narrow. They prevent queries like "فلاجيل شراب"
# from showing tablets/suppositories, while allowing the common Flagyl 125mg
# suspension row to be selected when that is the only syrup/suspension variant.
KNOWN_MEDICINE_FORM_OVERRIDES = [
    (re.compile(r"^flagyl\s*125\s*mg$", re.I), "suspension", ["flagyl syrup", "flagyl suspension", "فلاجيل شراب", "فلاجيل معلق"]),
]


def _clean_header(v: object) -> str:
    return str(v or "").strip().replace("ـ", "")


def _norm(v: object) -> str:
    return normalize_text(v)


def _num(value: object) -> float:
    if value is None or str(value).strip() == "":
        return 0.0
    try:
        return float(str(value).replace(",", "."))
    except Exception:
        return 0.0


def _price_text(value: float) -> str:
    if not value:
        return ""
    if float(value).is_integer():
        return str(int(value))
    return f"{value:.2f}".rstrip("0").rstrip(".")


def choose_price(box_price: object, strip_price: object) -> Tuple[str, str]:
    box = _num(box_price)
    strip = _num(strip_price)
    if box > 0:
        return _price_text(box), "box_price"
    if strip > 0:
        return _price_text(strip), "strip_price"
    return "", "missing"


def detect_raw_headers(values: Iterable[object]) -> Dict[str, int]:
    vals = [_clean_header(v) for v in values]
    norm_vals = [_norm(v) for v in vals]
    result: Dict[str, int] = {}
    for idx, (raw, n) in enumerate(zip(vals, norm_vals)):
        if raw in RAW_NAME_HEADERS or n in {normalize_text(x) for x in RAW_NAME_HEADERS} or "الصنف" in raw:
            result["name"] = idx
        elif raw in RAW_SERIAL_HEADERS or n in {normalize_text(x) for x in RAW_SERIAL_HEADERS}:
            result["serial"] = idx
        elif raw in RAW_BOX_PRICE_HEADERS or n in {normalize_text(x) for x in RAW_BOX_PRICE_HEADERS}:
            result["box_price"] = idx
        elif raw in RAW_STRIP_PRICE_HEADERS or n in {normalize_text(x) for x in RAW_STRIP_PRICE_HEADERS}:
            result["strip_price"] = idx
    return result


def find_raw_header_openpyxl(ws, max_scan_rows: int = 20) -> Tuple[int, Dict[str, int]]:
    for r in range(1, min(max_scan_rows, ws.max_row) + 1):
        vals = list(next(ws.iter_rows(min_row=r, max_row=r, values_only=True)))
        mapping = detect_raw_headers(vals)
        if "name" in mapping and ("box_price" in mapping or "strip_price" in mapping):
            return r, mapping
    return 0, {}


def find_raw_header_matrix(rows: List[List[object]], max_scan_rows: int = 20) -> Tuple[int, Dict[str, int]]:
    for r, vals in enumerate(rows[:max_scan_rows], start=1):
        mapping = detect_raw_headers(vals)
        if "name" in mapping and ("box_price" in mapping or "strip_price" in mapping):
            return r, mapping
    return 0, {}


def is_probable_barcode(name: str) -> bool:
    n = re.sub(r"\D", "", str(name or ""))
    return bool(n and len(n) in {8, 12, 13, 14} and n == re.sub(r"\D", "", str(name or "")))


def extract_brand(name: str) -> str:
    raw = str(name or "").strip().lstrip("+").strip()
    n = _norm(raw)
    if not raw:
        return ""
    for brand in MULTIWORD_BRANDS:
        if n.startswith(_norm(brand)):
            # Preserve capitalization from configured phrase.
            return brand.replace("prod3", "Pro-D3").replace("pro d3", "Pro-D3")
    toks = raw.split()
    if not toks:
        return raw
    # If first token is a short code with punctuation, keep it.
    first = toks[0].strip(" ,;/")
    if first.lower() in {"the", "la", "dr"} and len(toks) >= 2:
        return f"{toks[0]} {toks[1]}".strip()
    return first


def infer_category(name: str, brand: str) -> Tuple[str, str, str]:
    n = _norm(name)
    b = _norm(brand)
    if is_probable_barcode(name) or re.fullmatch(r"[0-9\s/\-]+", n or ""):
        return "unknown", "غير مصنف", "unclassified"
    # Known package identities first.
    for key, data in KNOWN_PACKAGE_OCR.items():
        if key == "propoli" and "propolis" in n:
            continue
        if key in n:
            return data.get("category", "unknown"), data.get("main_section", "غير مصنف"), data.get("sub_section", "unclassified")
    if any(x in n for x in OTHER_MARKERS):
        return "other", "معدات ومستلزمات", "medical_supplies"
    if any(x in n for x in COSMETIC_MARKERS):
        if any(x in n for x in ["shampoo", "conditioner", "hair", "luma fofo"]):
            return "cosmetic", "عناية بالشعر", infer_subcategory(name, "cosmetic")
        return "cosmetic", "عناية بالبشرة", infer_subcategory(name, "cosmetic")
    if any(x in n for x in SUPPLEMENT_MARKERS):
        return "supplement", "مكملات وفيتامينات", infer_subcategory(name, "supplement")
    if any(x in n for x in MEDICINE_MARKERS):
        return "medicine", "أدوية", "medicine_unspecified"
    # Names with clear pharmaceutical form/strength are probably medicine.
    if extract_strengths(name) or canonical_form(name) in {"tablet", "capsule", "syrup", "suspension", "suppository", "injection", "drops"}:
        return "medicine", "أدوية", "medicine_unspecified"
    return "unknown", "غير مصنف", "unclassified"


def infer_subcategory(name: str, category: str) -> str:
    n = _norm(name)
    if category == "supplement":
        if any(x in n for x in ["iron", "fer", "hemazym", "globifer"]): return "iron"
        if any(x in n for x in ["d3", "vitamin d", "prod3", "pro d3"]): return "vitamins"
        if "omega" in n: return "omega"
        if "calcium" in n: return "calcium"
        if "magnesium" in n: return "magnesium"
        if "zinc" in n: return "zinc"
        if any(x in n for x in ["fertility", "mari female", "ovanice"]): return "fertility"
        if "collagen" in n: return "collagen"
        if "propolis" in n or "propoli" in n: return "propolis"
        return "supplement_unspecified"
    if category == "cosmetic":
        if "cleanser" in n or "wash" in n or "foam" in n: return "skincare_cleanser"
        if "sunscreen" in n or "spf" in n or "sunblock" in n or "photoblok" in n: return "skincare_sunscreen"
        if "serum" in n: return "skincare_serum"
        if "lotion" in n or "moistur" in n or "baume" in n: return "skincare_moisturizer"
        if "shampoo" in n: return "hair_shampoo"
        if "conditioner" in n: return "hair_conditioner"
        if "hair" in n: return "hair_treatment"
        if "mask" in n: return "skincare_mask"
        if "toner" in n: return "skincare_toner"
        if "scar" in n: return "skincare_scar"
        if "acne" in n or "blemish" in n: return "skincare_acne"
        if "ointment" in n or "oint" in n: return "skincare_ointment"
        if "cream" in n or "dexeryl" in n: return "skincare_cream"
        return "skincare_unspecified"
    return "unclassified"


def infer_form(name: str, category: str) -> str:
    n = _norm(name)
    for key, data in KNOWN_PACKAGE_OCR.items():
        if key == "propoli" and "propolis" in n:
            continue
        if key in n and data.get("form"):
            return str(data["form"])
    for pattern, forced_form, _aliases in KNOWN_MEDICINE_FORM_OVERRIDES:
        if pattern.match(n):
            return forced_form
    f = canonical_form(name)
    if f:
        return f
    if "syp" in n or "syr" in n or "syrup" in n: return "syrup"
    if "susp" in n: return "suspension"
    if "caps" in n or "cap" in n: return "capsule"
    if "tab" in n or "film" in n: return "tablet"
    if "supp" in n: return "suppository"
    if "inj" in n or "amp" in n: return "injection"
    if category == "cosmetic":
        sub = infer_subcategory(name, category)
        if sub.startswith("hair_shampoo"): return "shampoo"
        if sub.startswith("skincare_cleanser"): return "cleanser"
        if sub.startswith("skincare_sunscreen"): return "sunscreen"
        if sub.startswith("skincare_serum"): return "serum"
        if sub.startswith("skincare_moisturizer"): return "moisturizer"
        if sub.startswith("skincare_cream"): return "cream"
        if sub.startswith("skincare_ointment"): return "ointment"
    return ""


def product_family_from_name(name: str, brand: str) -> str:
    clean = str(name or "").strip()
    b = str(brand or "").strip()
    if not clean:
        return ""
    if b and _norm(clean).startswith(_norm(b)):
        rest = clean[len(b):].strip(" -_/|,")
        return f"{b} {rest}".strip() if rest else b
    return clean


def add_unique(out: List[str], values: Iterable[object]) -> None:
    seen_norm = {_norm(x) for x in out}
    for v in values:
        text = str(v or "").strip()
        n = _norm(text)
        if text and n and n not in seen_norm:
            out.append(text)
            seen_norm.add(n)


def build_aliases_ocr(name: str, brand: str, family: str, form: str, strength: str, size: str, pack: str) -> Tuple[str, str]:
    n = _norm(name)
    aliases: List[str] = []
    ocr: List[str] = []
    add_unique(aliases, [name, brand, family])
    # Hyphen/compact equivalences.
    add_unique(aliases, [name.replace("-", " "), name.replace(" ", "-")])
    compact = compact_normalize(name)
    if compact and len(compact) >= 4:
        add_unique(aliases, [compact])
    for token, ar in ARABIC_ALIASES.items():
        if token in n:
            add_unique(aliases, ar)
    for pattern, _forced_form, extra_aliases in KNOWN_MEDICINE_FORM_OVERRIDES:
        if pattern.match(n):
            add_unique(aliases, extra_aliases)
            add_unique(ocr, extra_aliases)
    for key, data in KNOWN_PACKAGE_OCR.items():
        if key == "propoli" and "propolis" in n:
            continue
        if key in n:
            add_unique(aliases, data.get("aliases", []))
            add_unique(ocr, data.get("ocr", []))
    add_unique(ocr, [name, brand, family, form, strength, size, pack])
    # Keep useful OCR tokens but avoid broad one-letter/marketing noise.
    useful = []
    for t in _norm(name).split():
        if len(t) >= 3 and t not in {"the", "and", "with", "for", "new", "plus", "cream", "tablet", "capsule", "syrup", "supplement"}:
            useful.append(t)
    add_unique(ocr, useful)
    return " | ".join(aliases), " | ".join(ocr)


def row_from_raw(name: str, serial: object, box_price: object, strip_price: object, raw_row_number: int, duplicate_count: int = 1, duplicate_price_conflict: bool = False) -> Dict[str, str]:
    name = str(name or "").strip()
    serial_int = int(_num(serial) or max(raw_row_number - 5, 1))
    product_id = f"PL{serial_int:05d}"
    price, price_source = choose_price(box_price, strip_price)
    brand = extract_brand(name)
    category, section, subcategory = infer_category(name, brand)
    form = infer_form(name, category)
    family = product_family_from_name(name, brand)
    strengths = extract_strengths(name)
    sizes = extract_sizes(name)
    packs = extract_packs(name)
    strength = strengths[0] if strengths else ""
    size = sizes[0] if sizes else ""
    pack = packs[0] if packs else ""
    # Known package data may fill visible package slots not present in raw list.
    n = _norm(name)
    for key, data in KNOWN_PACKAGE_OCR.items():
        if key == "propoli" and "propolis" in n:
            continue
        if key in n:
            category = data.get("category", category)
            section = data.get("main_section", section)
            subcategory = data.get("sub_section", subcategory)
            form = data.get("form", form)
            strength = data.get("strength", strength)
            size = data.get("size", size)
            pack = data.get("pack", pack)
    aliases, ocr_keywords = build_aliases_ocr(name, brand, family, form, strength, size, pack)
    notes: List[str] = []
    if category in {"unknown", ""}:
        notes.append("unclassified")
    if duplicate_count > 1:
        notes.append(f"duplicate_name_count={duplicate_count}")
    if duplicate_price_conflict:
        notes.append("duplicate_price_conflict")
    if is_probable_barcode(name):
        notes.append("name_looks_like_barcode")
    review_status = "approved" if not notes else "needs_review"
    quality_status = "ready" if price else "needs_price"
    search_mode = "searchable" if price and category != "unknown" else "exact_only" if price else "review_only"
    use_case = ""
    for key, data in KNOWN_PACKAGE_OCR.items():
        if key in n and data.get("use_case"):
            use_case = str(data.get("use_case") or "")
    if not use_case:
        if category == "supplement": use_case = infer_subcategory(name, "supplement")
        elif category == "cosmetic": use_case = infer_subcategory(name, "cosmetic").replace("skincare_", "").replace("hair_", "hair_")
    barcode = name if is_probable_barcode(name) else ""
    medicine_form = form if category == "medicine" else ""
    return {
        "product_id": product_id,
        "name": name,
        "normalized_name": _norm(name),
        "brand": brand,
        "company": brand,
        "category": category,
        "section": section,
        "main_section": section,
        "sub_section": subcategory,
        "subcategory": subcategory,
        "product_family": family,
        "form": form,
        "product_type": form or subcategory,
        "active_ingredient": "",
        "strength": strength,
        "size": size,
        "pack": pack,
        "barcode": barcode,
        "aliases": aliases,
        "ocr_keywords": ocr_keywords,
        "use_case": use_case,
        "skin_type": "unknown",
        "body_area": "unknown",
        "age_group": "adult_or_unknown",
        "gender": "unisex_or_unknown",
        "medicine_form": medicine_form,
        "medicine_route": "",
        "available": "true" if price else "false",
        "price": safe_price(price),
        "currency": "LYD",
        "search_mode": search_mode,
        "quality_status": quality_status,
        "is_substitutable": "false",
        "substitution_group_id": "",
        "review_status": review_status,
        "review_notes": "; ".join(notes),
        "source_serial": str(serial_int),
        "original_name": name,
        "box_price": _price_text(_num(box_price)),
        "strip_price": _price_text(_num(strip_price)),
        "price_source": price_source,
        "raw_row_number": str(raw_row_number),
        "duplicate_name_count": str(duplicate_count),
        "duplicate_price_conflict": "true" if duplicate_price_conflict else "false",
    }


def _duplicate_maps(raw_products: List[Tuple[str, object, object, object, int]]) -> Tuple[Counter, Dict[str, bool]]:
    counts = Counter(_norm(name) for name, *_ in raw_products if _norm(name))
    prices_by_name: Dict[str, set] = {}
    for name, _serial, box, strip, _rownum in raw_products:
        n = _norm(name)
        p, _src = choose_price(box, strip)
        prices_by_name.setdefault(n, set()).add(p)
    conflicts = {n: len({p for p in prices if p}) > 1 for n, prices in prices_by_name.items()}
    return counts, conflicts


def convert_raw_products(raw_products: List[Tuple[str, object, object, object, int]]) -> List[Dict[str, str]]:
    counts, conflicts = _duplicate_maps(raw_products)
    rows: List[Dict[str, str]] = []
    seen_ids = set()
    for name, serial, box, strip, raw_row_number in raw_products:
        if not str(name or "").strip():
            continue
        n = _norm(name)
        row = row_from_raw(name, serial, box, strip, raw_row_number, counts.get(n, 1), conflicts.get(n, False))
        # Ensure product_id is unique even if the source serial is duplicated/missing.
        pid = row["product_id"]
        if pid in seen_ids:
            base = pid
            i = 2
            while f"{base}-{i}" in seen_ids:
                i += 1
            row["product_id"] = f"{base}-{i}"
        seen_ids.add(row["product_id"])
        rows.append(row)
    return rows


def read_raw_openpyxl(ws) -> Tuple[List[Dict[str, str]], Dict[str, object]]:
    header_row, mapping = find_raw_header_openpyxl(ws)
    if not header_row:
        raise RuntimeError("RAW_PRICELIST_HEADER_NOT_FOUND")
    raw_products: List[Tuple[str, object, object, object, int]] = []
    for offset, vals in enumerate(ws.iter_rows(min_row=header_row + 1, max_row=ws.max_row, values_only=True), start=header_row + 1):
        vals = list(vals)
        def get(key):
            idx = mapping.get(key)
            return vals[idx] if idx is not None and idx < len(vals) else None
        name = get("name")
        if not str(name or "").strip():
            continue
        raw_products.append((str(name).strip(), get("serial"), get("box_price"), get("strip_price"), offset))
    rows = convert_raw_products(raw_products)
    meta = {"mode": "raw_pricelist", "header_row": header_row, "rows_accepted": len(rows), "mapping": mapping}
    return rows, meta


def read_raw_xls(path: str) -> Tuple[List[Dict[str, str]], Dict[str, object]]:
    try:
        import xlrd  # type: ignore
    except Exception as exc:
        raise RuntimeError("XLS_SUPPORT_REQUIRES_XLRD: install xlrd==2.0.1 or upload .xlsx") from exc
    book = xlrd.open_workbook(path)
    sh = book.sheet_by_index(0)
    matrix = [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)]
    header_row, mapping = find_raw_header_matrix(matrix)
    if not header_row:
        raise RuntimeError("RAW_PRICELIST_HEADER_NOT_FOUND")
    raw_products: List[Tuple[str, object, object, object, int]] = []
    for r0 in range(header_row, sh.nrows):
        vals = matrix[r0]
        def get(key):
            idx = mapping.get(key)
            return vals[idx] if idx is not None and idx < len(vals) else None
        name = get("name")
        if not str(name or "").strip():
            continue
        raw_products.append((str(name).strip(), get("serial"), get("box_price"), get("strip_price"), r0 + 1))
    rows = convert_raw_products(raw_products)
    meta = {"mode": "raw_pricelist_xls", "header_row": header_row, "rows_accepted": len(rows), "mapping": mapping}
    return rows, meta
