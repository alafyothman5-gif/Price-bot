from __future__ import annotations

from typing import Any, Dict, List, Optional

import database


def get_job(job_id: int) -> Optional[Dict[str, Any]]:
    return database.get_catalog_import_job(int(job_id))


def list_jobs(limit: int = 30) -> List[Dict[str, Any]]:
    return database.list_catalog_import_jobs(int(limit))


def mark(job_id: int, status: str, **fields: Any) -> None:
    database.update_catalog_import_job(int(job_id), status=status, **fields)
