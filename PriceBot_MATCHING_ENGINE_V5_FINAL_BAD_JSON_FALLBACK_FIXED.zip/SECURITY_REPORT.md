# Security Report - V2

## Admin security
- `ADMIN_KEY=change_me` and weak admin keys are rejected.
- The admin panel uses `/admin/login` and a signed session cookie.
- `?key=` links are not used for protected admin actions.
- Admin login is rate-limited.
- Sensitive admin actions use POST forms, not GET.
- Learning approve/delete/update actions are POST-only.
- Catalog import approve/cancel actions are POST-only.

## Audit logging
`admin_audit_log` is used for important admin activity, including:
- login success/failure
- catalog import upload
- catalog import approve/cancel
- learning alias/OCR approval
- product/settings changes where implemented

## Secrets handling
The ZIP must not include:
- `.env`
- `pricebot.db`
- OpenRouter tokens
- Meta tokens
- Admin secrets
- `venv`
- backups
- `__pycache__`

## Health endpoints
- `/health` remains light.
- `/deep-health` exists for deeper database/index checks.

## Result
Security blockers from the review were addressed for the V2 delivery.
