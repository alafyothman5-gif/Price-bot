# Vision Bad JSON Fallback Fix

## Problem
Some Vision/OpenRouter responses were fast but not valid JSON (`status=bad_json`). The bot then returned IMAGE_UNCLEAR even when the response text still contained useful product identity words such as brand + family.

## Fix
- Added `response_format={"type":"json_object"}` to the Vision request.
- Added a generic bad-JSON fallback parser in `vision_service.py`.
- If JSON parsing fails but the model response contains at least two strong product identity words, the response is converted into safe Vision slots.
- The fallback still uses Image Confirmation Mode: it only suggests candidates for confirmation and does not display price directly.
- Weak text still returns IMAGE_UNCLEAR.

## Safety
- No hardcoded Vichy-specific fix.
- Applies to all products.
- Does not change Excel behavior.
- Does not include `.env`, `pricebot.db`, `venv`, or backups.
