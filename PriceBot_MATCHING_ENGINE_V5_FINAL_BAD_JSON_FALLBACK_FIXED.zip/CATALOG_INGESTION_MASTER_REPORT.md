# PriceBot FINAL Catalog Ingestion Master - FIXED

## Scope
This build closes the final weekly-upload issues around safe price updates, duplicates, review-only rows, missing-from-upload handling, canonical display names, and immediate searchability after approval.

## Implemented fixes

1. **Weekly price update rule**
   - A changed price for a safely matched existing product is now `UPDATE_PRICE`, not `PRICE_CONFLICT`.
   - Example behavior: `Panadol 500mg old=10`, weekly Excel `Panadol 500mg=12` → after approval price becomes `12`.
   - Price changes are written to `catalog_audit_log` with `old_price`, `new_price`, `upload_id`, `updated_at` via log timestamp, and `source_row`.

2. **Duplicate rows in one weekly Excel**
   - Same identity + same price → `EXACT_DUPLICATE_MERGED`.
   - Same identity + different prices → `UPDATE_PRICE`, final value is the last row in the uploaded file.
   - Warning added: `DUPLICATE_PRICE_LAST_VALUE_USED`.
   - This does not enter Review when product identity is clear.

3. **Review is only for real identity risk**
   - Review is not triggered by normal old-price/new-price changes.
   - Review is not triggered by safe exact duplicates.
   - Review remains for incomplete/ambiguous identity such as `Flagyl` with multiple forms/strengths.

4. **Cipralex duplicate exact fix**
   - Matching now collapses canonical duplicate rows when they share the same identity/name.
   - `Cipralex 10mg` returns `EXACT_MATCH` instead of `ASK_CLARIFICATION`, even if duplicate physical rows exist.
   - Different strengths such as `Cipralex 10mg` vs `Cipralex 20mg` remain variants.

5. **Missing-from-upload safety**
   - Missing products are report-only by default: `MISSING_FROM_UPLOAD_REPORT_ONLY`.
   - Products are not marked unavailable unless the caller explicitly uses full inventory mode / mark missing unavailable.

6. **Approval refresh after writes**
   - Approval performs backup, database transaction, price/inventory updates, alias/OCR keyword insertions, index rebuilds, cache invalidation, acceptance checks, and rollback on critical failure.
   - Rebuilds include `product_search_index`, `product_identity_registry`, and `guided_catalog_index` when available.

7. **Canonical display names**
   - Corrected canonical names are preserved for customer display.
   - Example: `WHITE PETROLEEUM JELLY` can store raw source text, but customer-facing display prefers `WHITE PETROLEUM JELLY`.

8. **Vision fallback remains fixed**
   - `brand=WHITE`, `product_name=""`, `visible_text="WHITE PETROLEUM JELLY"` uses the full OCR phrase and returns `EXACT_MATCH` when the product exists.

## Test confirmation

- `python -m compileall -q .` passed.
- `PYTHONPATH=. python tests/test_catalog_ingestion_master.py` passed.
- `PYTHONPATH=. python tools/rebuild_database_from_any_excel.py --excel products_master_ready.xlsx --db-path /tmp/pricebot.db --report /tmp/report.json` passed.
- `PYTHONPATH=. python -u tests/test_excel_native_engine.py --db-path /tmp/pricebot.db` passed.
- Targeted real-catalog check: `Cipralex 10mg` returns `EXACT_MATCH`.

## Real catalog counts from products_master_ready.xlsx

- products_count: 5791
- product_identity_registry count: 5791
- product_search_index count: 178406
- guided_catalog_index count: 5791

## Required confirmations

- Cipralex 10mg exact duplicate returns: `EXACT_MATCH`.
- Old price `10` → new weekly upload price `12` returns: `UPDATE_PRICE` and final price `12` after approval.
- Duplicate same identity with different prices uses the last value in the file and records warning: `DUPLICATE_PRICE_LAST_VALUE_USED`.
