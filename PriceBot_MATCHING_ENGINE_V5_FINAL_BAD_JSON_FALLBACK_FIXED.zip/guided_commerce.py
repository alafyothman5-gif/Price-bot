from typing import Dict, List, Tuple

import database
from normalizer import normalize_text

MAIN_SECTIONS = [
    "أدوية",
    "مكملات وفيتامينات",
    "عناية بالبشرة",
    "عناية بالشعر",
    "أطفال",
    "أجهزة ومستلزمات",
    "عناية شخصية",
]

MEDICINE_SUBS = [
    ("مسكنات وخافض حرارة", ["paracetamol", "panadol", "ibuprofen", "brufen", "diclofenac", "مسكن", "خافض", "باراسيتامول"]),
    ("معدة وقيء", ["ondansetron", "zofran", "metoclopramide", "motilium", "omeprazole", "esomeprazole", "معده", "قيء", "غثيان"]),
    ("حساسية وزكام", ["cetirizine", "loratadine", "allergy", "cold", "حساسيه", "زكام", "رشح"]),
    ("جلدية", ["skin", "derma", "topical", "cream", "ointment", "جلديه", "مرهم"]),
    ("نسائية", ["gyno", "vag", "vaginal", "miconazole", "daktarin", "نسائيه", "مهبل"]),
    ("مضادات حيوية", ["antibiotic", "amoxicillin", "amoclan", "azithromycin", "cef", "cipro", "flagyl", "metronidazole", "مضاد"]),
    ("سكري وضغط وقلب", ["diabetes", "insulin", "metformin", "pressure", "cardio", "سكر", "ضغط", "قلب"]),
    ("عيون / أنف / أذن", ["eye", "oph", "nasal", "ear", "drops", "عين", "انف", "اذن"]),
]
SUPPLEMENT_SUBS = [
    ("حديد", ["iron", "fer", "ferr", "حديد"]),
    ("فيتامين D", ["vitamin d", "vit d", "d3", "فيتامين د"]),
    ("كالسيوم", ["calcium", "كالسيوم"]),
    ("مغنيسيوم", ["magnesium", "مغنيسيوم"]),
    ("زنك", ["zinc", "زنك"]),
    ("فيتامين C", ["vitamin c", "vit c", "ascorbic", "فيتامين سي"]),
    ("Multivitamin", ["multivitamin", "multi vitamin", "مولتي"]),
    ("فيتامينات أطفال", ["kids", "children", "baby", "اطفال"]),
    ("مكملات الحمل", ["pregnancy", "pregna", "prenatal", "حمل"]),
]
SKINCARE_SUBS = [
    ("غسول وجه", ["cleanser", "face wash", "wash gel", "غسول وجه", "غسول"]),
    ("مرطب", ["moisturizer", "moisturizing", "lotion", "cream", "مرطب"]),
    ("واقي شمس", ["sunscreen", "sun protection", "spf", "واقي شمس"]),
    ("سيروم", ["serum", "سيروم"]),
    ("علاج حبوب", ["acne", "anti acne", "حبوب"]),
    ("مقشر", ["exfol", "peeling", "scrub", "مقشر"]),
]
HAIR_SUBS = [
    ("شامبو", ["shampoo", "شامبو"]),
    ("بلسم", ["conditioner", "بلسم"]),
    ("زيت / سيروم شعر", ["hair oil", "hair serum", "زيت شعر", "سيروم شعر"]),
    ("قشرة", ["dandruff", "anti dandruff", "قشره"]),
    ("تساقط", ["hair loss", "anti hair loss", "تساقط"]),
    ("عناية أطفال بالشعر", ["baby shampoo", "kids shampoo", "اطفال"]),
]
CHILD_SUBS = [
    ("حفاضات", ["diaper", "nappy", "حفاض"]),
    ("شامبو / غسول أطفال", ["baby wash", "baby shampoo", "kids wash", "غسول اطفال", "شامبو اطفال"]),
    ("كريمات أطفال", ["baby cream", "rash cream", "كريم اطفال"]),
    ("حليب وأغذية", ["milk", "formula", "food", "حليب", "غذاء"]),
    ("مستلزمات أطفال", ["baby", "kids", "pacifier", "bottle", "اطفال"]),
]
DEVICE_SUBS = [
    ("قياس ضغط", ["pressure monitor", "blood pressure", "قياس ضغط"]),
    ("قياس سكر", ["glucose", "glucometer", "sugar", "قياس سكر"]),
    ("ترمومتر", ["thermometer", "ترمومتر", "حراره"]),
    ("أجهزة تنفس", ["nebulizer", "inhaler", "oxygen", "تنفس"]),
    ("كمامات ومستلزمات", ["mask", "كمامه", "مستلزمات"]),
    ("ضمادات وشاش", ["bandage", "gauze", "dressing", "ضماد", "شاش"]),
]
STATIC_SUBS = {
    "أدوية": [x[0] for x in MEDICINE_SUBS] + ["بحث باسم دواء"],
    "مكملات وفيتامينات": [x[0] for x in SUPPLEMENT_SUBS],
    "عناية بالبشرة": [x[0] for x in SKINCARE_SUBS],
    "عناية بالشعر": [x[0] for x in HAIR_SUBS],
    "أطفال": [x[0] for x in CHILD_SUBS],
    "أجهزة ومستلزمات": [x[0] for x in DEVICE_SUBS],
    "عناية شخصية": ["منتجات عناية شخصية"],
}
SKIN_TYPE_MAP = {
    "1": "oily", "دهنية": "oily", "دهنيه": "oily", "oily": "oily",
    "2": "dry", "جافة": "dry", "جافه": "dry", "dry": "dry",
    "3": "sensitive", "حساسة": "sensitive", "حساسه": "sensitive", "sensitive": "sensitive",
    "4": "normal_combination", "عادية": "normal_combination", "مختلطة": "normal_combination", "عاديه": "normal_combination", "normal": "normal_combination", "combination": "normal_combination",
    "5": "unknown", "لا أعرف": "unknown", "لا اعرف": "unknown", "unknown": "unknown",
}

CATEGORY_ALIASES = {
    "medicine": "أدوية", "medicines": "أدوية", "drug": "أدوية", "drugs": "أدوية", "ادويه": "أدوية", "ادوية": "أدوية", "دواء": "أدوية",
    "supplement": "مكملات وفيتامينات", "supplements": "مكملات وفيتامينات", "vitamin": "مكملات وفيتامينات", "vitamins": "مكملات وفيتامينات", "مكمل": "مكملات وفيتامينات", "مكملات": "مكملات وفيتامينات", "فيتامين": "مكملات وفيتامينات", "فيتامينات": "مكملات وفيتامينات",
    "cosmetic": "عناية بالبشرة", "cosmetics": "عناية بالبشرة", "skincare": "عناية بالبشرة", "skin care": "عناية بالبشرة", "عنايه بالبشره": "عناية بالبشرة", "عناية بالبشرة": "عناية بالبشرة",
    "hair": "عناية بالشعر", "haircare": "عناية بالشعر", "hair care": "عناية بالشعر", "عنايه بالشعر": "عناية بالشعر", "عناية بالشعر": "عناية بالشعر",
    "baby": "أطفال", "kids": "أطفال", "children": "أطفال", "اطفال": "أطفال", "طفل": "أطفال",
    "device": "أجهزة ومستلزمات", "devices": "أجهزة ومستلزمات", "supplies": "أجهزة ومستلزمات", "medical supplies": "أجهزة ومستلزمات", "اجهزه": "أجهزة ومستلزمات", "اجهزه ومستلزمات": "أجهزة ومستلزمات",
    "personal care": "عناية شخصية", "other": "عناية شخصية", "personal": "عناية شخصية", "عناية شخصية": "عناية شخصية",
}
SUBCATEGORY_ALIASES = {
    "cleanser": "غسول وجه", "face wash": "غسول وجه", "wash gel": "غسول وجه", "غسول": "غسول وجه", "غسول وجه": "غسول وجه",
    "cream": "مرطب", "moisturizer": "مرطب", "moisturiser": "مرطب", "lotion": "مرطب", "مرطب": "مرطب", "كريم": "مرطب",
    "sunscreen": "واقي شمس", "spf": "واقي شمس", "واقي": "واقي شمس", "واقي شمس": "واقي شمس",
    "serum": "سيروم", "سيروم": "سيروم",
    "shampoo": "شامبو", "شامبو": "شامبو",
    "iron": "حديد", "حديد": "حديد",
    "vitamin d": "فيتامين D", "vit d": "فيتامين D", "d3": "فيتامين D", "فيتامين د": "فيتامين D",
    "calcium": "كالسيوم", "كالسيوم": "كالسيوم",
    "zinc": "زنك", "زنك": "زنك",
    "magnesium": "مغنيسيوم", "مغنيسيوم": "مغنيسيوم",
    "diaper": "حفاضات", "حفاض": "حفاضات", "حفاضات": "حفاضات",
}
BROAD_SUBCATEGORY_VALUES = {
    "", "medicine", "medicines", "drug", "drugs", "ادويه", "ادوية", "دواء",
    "cosmetic", "cosmetics", "skin care", "skincare", "عنايه بالبشره",
    "supplement", "supplements", "vitamin", "vitamins", "مكملات", "فيتامينات",
    "hair", "hair care", "haircare", "عنايه بالشعر",
    "baby", "kids", "children", "اطفال",
    "device", "devices", "medical supplies", "اجهزه", "اجهزه ومستلزمات",
    "other", "personal care", "عنايه شخصيه",
}


def _hay(p: Dict) -> str:
    return normalize_text(" ".join(str(p.get(c) or "") for c in [
        "name", "normalized_name", "brand", "company", "category", "subcategory", "section", "product_family", "form", "product_type",
        "active_ingredient", "use_case", "skin_type", "body_area", "age_group", "original_name", "aliases", "ocr_keywords"
    ]))


def _has_any(hay: str, words: List[str]) -> bool:
    return any(normalize_text(w) and normalize_text(w) in hay for w in words)


def canonical_category(value: object) -> str:
    n = normalize_text(value)
    if not n:
        return ""
    return CATEGORY_ALIASES.get(n, str(value or "").strip())


def canonical_subcategory(value: object, main_section: str = "") -> str:
    raw = str(value or "").strip()
    n = normalize_text(raw)
    if n in BROAD_SUBCATEGORY_VALUES:
        return ""
    if n in SUBCATEGORY_ALIASES:
        return SUBCATEGORY_ALIASES[n]
    # If the source already has an Arabic/business label, use it directly.
    return raw


def classify_main_section(product: Dict) -> str:
    explicit = str(product.get("main_section") or "").strip()
    if explicit and normalize_text(explicit) not in {"unknown", "غير معروف", "غير مصنف"}:
        return explicit
    direct = canonical_category(product.get("category"))
    if direct in MAIN_SECTIONS:
        return direct
    h = _hay(product)
    if _has_any(h, ["medicine", "ondansetron", "zofran", "daktarin", "gyno", "flagyl", "metronidazole", "amoxicillin", "paracetamol", "ibuprofen"]):
        return "أدوية"
    if _has_any(h, ["vitamin", "supplement", "iron", "calcium", "zinc", "magnesium", "فيتامين", "مكمل", "حديد"]):
        return "مكملات وفيتامينات"
    if _has_any(h, ["baby", "kids", "children", "diaper", "اطفال", "حفاض"]):
        return "أطفال"
    if _has_any(h, ["shampoo", "conditioner", "hair", "dandruff", "شامبو", "بلسم", "شعر", "قشره"]):
        return "عناية بالشعر"
    if _has_any(h, ["cosmetic", "cleanser", "sunscreen", "moisturizer", "serum", "spf", "acne", "skin", "غسول", "مرطب", "واقي", "سيروم", "بشره"]):
        return "عناية بالبشرة"
    if _has_any(h, ["device", "monitor", "thermometer", "glucometer", "mask", "bandage", "gauze", "جهاز", "قياس", "كمامه", "ضماد", "شاش"]):
        return "أجهزة ومستلزمات"
    return "عناية شخصية"


def classify_sub_section(product: Dict, main_section: str) -> str:
    explicit = canonical_subcategory(product.get("sub_section"), main_section)
    if explicit:
        return explicit
    direct = canonical_subcategory(product.get("subcategory"), main_section)
    if direct:
        return direct
    h = _hay(product)
    groups = {
        "أدوية": MEDICINE_SUBS,
        "مكملات وفيتامينات": SUPPLEMENT_SUBS,
        "عناية بالبشرة": SKINCARE_SUBS,
        "عناية بالشعر": HAIR_SUBS,
        "أطفال": CHILD_SUBS,
        "أجهزة ومستلزمات": DEVICE_SUBS,
    }.get(main_section, [])
    for label, words in groups:
        if _has_any(h, words):
            return label
    if main_section == "أدوية":
        return "بحث باسم دواء"
    if main_section == "عناية شخصية":
        return "منتجات عناية شخصية"
    return "أخرى"


def product_allowed_in_subsection(product: Dict, main_section: str, sub_section: str, skin_type: str = "") -> bool:
    # The guided index is built from category/subcategory.  This guard only
    # prevents obvious commercial mistakes inside sensitive sections.
    h = _hay(product)
    if main_section == "عناية بالبشرة" and sub_section in {"غسول وجه", "غسول"}:
        forbidden = ["baby", "kids", "children", "body wash", "shampoo", "hair", "غسول جسم", "اطفال", "شامبو", "شعر"]
        if _has_any(h, forbidden):
            return False
        if not _has_any(h, ["cleanser", "face wash", "wash gel", "غسول وجه", "غسول"]):
            return False
        if skin_type and skin_type != "unknown":
            pst = normalize_text(product.get("skin_type"))
            if pst and pst != "unknown" and skin_type not in pst:
                if skin_type == "normal_combination" and not any(x in pst for x in ["normal", "combination", "mixed"]):
                    return False
                if skin_type != "normal_combination":
                    return False
    if main_section == "عناية بالشعر" and _has_any(h, ["skin cleanser", "face wash", "body lotion", "بشره"]):
        return False
    if main_section == "أطفال" and not _has_any(h, ["baby", "kids", "children", "diaper", "اطفال", "حفاض", "حليب"]):
        # Allow explicit catalog category/subcategory to override if the row was tagged by the pharmacy.
        return canonical_category(product.get("category")) == "أطفال"
    return True


def build_guided_index_entries() -> List[Tuple[int, str, str, str, str, str, str, str, int, str]]:
    rows = database.load_product_rows(visible_only=True, guided=True)
    entries: List[Tuple[int, str, str, str, str, str, str, str, int, str]] = []
    for p in rows:
        main = classify_main_section(p)
        sub = classify_sub_section(p, main)
        if not product_allowed_in_subsection(p, main, sub):
            continue
        entries.append((
            int(p["id"]), main, sub,
            normalize_text(p.get("product_type") or p.get("form")), normalize_text(p.get("use_case")), normalize_text(p.get("skin_type")),
            normalize_text(p.get("body_area")), normalize_text(p.get("age_group")), 1,
            normalize_text(p.get("name")) or str(p.get("name") or ""),
        ))
    return entries


def rebuild_guided_index() -> int:
    return database.replace_guided_index(build_guided_index_entries())


def available_main_sections() -> List[str]:
    available = set()
    with database.connect() as conn:
        if database.table_exists(conn, "guided_catalog_index"):
            rows = conn.execute("SELECT DISTINCT main_section FROM guided_catalog_index WHERE visible=1 ORDER BY main_section COLLATE NOCASE").fetchall()
            available = {str(r[0]) for r in rows if str(r[0] or "").strip()}
    ordered = [s for s in MAIN_SECTIONS if s in available]
    ordered.extend(sorted(s for s in available if s not in ordered))
    return ordered


def available_sub_sections(main_section: str) -> List[str]:
    db_subs: List[str] = []
    with database.connect() as conn:
        if database.table_exists(conn, "guided_catalog_index"):
            rows = conn.execute("""
                SELECT DISTINCT sub_section FROM guided_catalog_index
                WHERE visible=1 AND main_section=? AND sub_section IS NOT NULL AND sub_section!=''
                ORDER BY sub_section COLLATE NOCASE
            """, (main_section,)).fetchall()
            db_subs = [str(r[0]) for r in rows if str(r[0] or "").strip()]
    static = STATIC_SUBS.get(main_section, [])
    ordered = [s for s in static if s in db_subs or s == "بحث باسم دواء"]
    ordered.extend([s for s in db_subs if s not in ordered])
    return ordered


def skin_type_from_choice(choice: str) -> str:
    return SKIN_TYPE_MAP.get(str(choice).strip(), SKIN_TYPE_MAP.get(normalize_text(choice), ""))


def skin_type_menu() -> str:
    return "اختر نوع البشرة:\n1. دهنية\n2. جافة\n3. حساسة\n4. عادية / مختلطة\n5. لا أعرف"


def format_main_menu() -> str:
    sections = available_main_sections() or MAIN_SECTIONS
    lines = ["اختر القسم:"]
    for i, s in enumerate(sections, 1):
        lines.append(f"{i}. {s}")
    return "\n".join(lines)


def format_sub_menu(main_section: str) -> str:
    subs = available_sub_sections(main_section)
    if not subs:
        return "لا توجد منتجات متوفرة في هذا القسم حاليًا."
    lines = [f"{main_section}:"]
    for i, s in enumerate(subs, 1):
        lines.append(f"{i}. {s}")
    return "\n".join(lines)
