from __future__ import annotations

"""PriceBot Celery app with real Redis queues.

Queues:
- catalog: Excel staging/import/reindex jobs
- vision: product image OCR/Vision extraction jobs
- text: text message processing jobs

Example workers:
  celery -A celery_app.celery_app worker -Q catalog --loglevel=INFO
  celery -A celery_app.celery_app worker -Q vision  --loglevel=INFO --concurrency=2
  celery -A celery_app.celery_app worker -Q text    --loglevel=INFO --concurrency=4
"""

import os

try:
    from celery import Celery  # type: ignore
    from kombu import Queue  # type: ignore
except Exception:  # pragma: no cover
    Celery = None  # type: ignore
    Queue = None  # type: ignore


if Celery is not None:
    broker = os.getenv("CELERY_BROKER_URL") or os.getenv("REDIS_URL") or "redis://localhost:6379/0"
    backend = os.getenv("CELERY_RESULT_BACKEND") or os.getenv("REDIS_URL") or "redis://localhost:6379/1"
    celery_app = Celery(
        "pricebot",
        broker=broker,
        backend=backend,
        include=["tasks.catalog_tasks", "tasks.vision_tasks", "tasks.text_tasks"],
    )
    celery_app.conf.update(
        task_track_started=True,
        worker_prefetch_multiplier=1,
        task_acks_late=True,
        task_reject_on_worker_lost=True,
        task_time_limit=int(os.getenv("PRICEBOT_TASK_TIME_LIMIT", "600") or 600),
        broker_connection_retry_on_startup=True,
        task_default_queue="text",
        task_queues=(
            Queue("catalog"),
            Queue("vision"),
            Queue("text"),
        ) if Queue is not None else None,
        task_routes={
            "pricebot.catalog.*": {"queue": "catalog"},
            "pricebot.vision.*": {"queue": "vision"},
            "pricebot.text.*": {"queue": "text"},
        },
    )
else:
    celery_app = None
