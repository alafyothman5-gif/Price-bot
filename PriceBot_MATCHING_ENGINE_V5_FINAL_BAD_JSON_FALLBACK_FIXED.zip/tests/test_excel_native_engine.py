#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
from services.matching.excel_native_matcher import invalidate_memory_index, match_text, match_vision_slots, preload_search_index


def assert_status(label: str, result, allowed, product_contains: str = "") -> None:
    if isinstance(allowed, str):
        allowed = {allowed}
    if result.status not in allowed:
        raise AssertionError(f"{label}: expected {allowed}, got {result.status}, message={result.message!r}, diagnostics={result.diagnostics}")
    if product_contains:
        name = (result.product or {}).get("name", "") if result.product else ""
        if product_contains.lower() not in str(name).lower():
            raise AssertionError(f"{label}: expected product containing {product_contains!r}, got {name!r}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db-path", default=os.getenv("PRICEBOT_DB_PATH", ""))
    args = ap.parse_args()
    if args.db_path:
        database.configure_db_path(args.db_path)
    database.init_db(run_production_guard=False)
    invalidate_memory_index()
    preload_search_index()
    products_count = database.count_products()
    registry_count = database.identity_registry_count()
    search_index_count = database.count_table("product_search_index")
    guided_index_count = database.count_table("guided_catalog_index")
    if products_count < 1000:
        raise AssertionError(f"products_count too low: {products_count}")
    if registry_count < 1000:
        raise AssertionError(f"product_identity_registry too low: {registry_count}")
    tests = []

    tests.append(("Hemazym text", match_text("Hemazym"), "EXACT_MATCH", "Hemazym"))
    tests.append(("Hemazym vision", match_vision_slots({"visible_text":"LIPOSOMAL Hemazym IRON SUPPLEMENT Folic Acid Vitamin B12 30 capsules", "main_visible_product":"Hemazym", "confidence":0.95}), "EXACT_MATCH", "Hemazym"))
    tests.append(("Panadol generic", match_text("Panadol"), "ASK_CLARIFICATION", ""))
    tests.append(("Flagyl generic", match_text("Flagyl"), "ASK_CLARIFICATION", ""))
    tests.append(("فلاجيل generic", match_text("فلاجيل"), "ASK_CLARIFICATION", ""))
    tests.append(("فلاجيل شراب hard form filter", match_text("فلاجيل شراب"), {"EXACT_MATCH", "ASK_CLARIFICATION"}, "flagyl"))
    tests.append(("Flagyl 500 duplicate", match_text("Flagyl 500mg"), "ASK_CLARIFICATION", ""))
    tests.append(("MEBO scar", match_text("MEBO scar"), "EXACT_MATCH", "scar"))
    tests.append(("MEBO scar vision", match_vision_slots({"visible_text":"MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym", "main_visible_product":"MEBO SCAR OINTMENT", "confidence":0.95}), "EXACT_MATCH", "scar"))
    tests.append(("Pro-D3 vision", match_vision_slots({"visible_text":"Pro-D3 50,000 IU Vitamin K2 15 capsules", "main_visible_product":"Pro-D3 50,000 IU Vitamin K2 15 capsules", "confidence":0.95}), "EXACT_MATCH", "Pro-D3"))
    tests.append(("Dexeryl vision", match_vision_slots({"visible_text":"DEXERYL crème cream 250g tube", "main_visible_product":"DEXERYL crème cream 250g tube", "confidence":0.95}), "EXACT_MATCH", "DEXERYL"))
    tests.append(("Ovanice vision", match_vision_slots({"visible_text":"Ovanice Female Fertility 90 capsules 850mg", "main_visible_product":"Ovanice Female Fertility 90 capsules 850mg", "confidence":0.95}), "EXACT_MATCH", "Ovanice"))
    tests.append(("Mari Female vision", match_vision_slots({"visible_text":"MARI FEMALE Female Fertility 3600mg 30 Sachet 108g", "main_visible_product":"MARI FEMALE Female Fertility 3600mg 30 Sachet 108g", "confidence":0.95}), "EXACT_MATCH", "Mari Female"))
    tests.append(("Propoli vision", match_vision_slots({"visible_text":"PROPOLI Concentrated Fluid Food Supplement", "main_visible_product":"PROPOLI Concentrated Fluid Food Supplement", "confidence":0.95}), "EXACT_MATCH", "propoli"))
    tests.append(("Remedica partial vision", match_vision_slots({"visible_text":"100 ml oral suspension Remedica", "confidence":0.9}), {"LOW_CONFIDENCE", "IMAGE_UNCLEAR"}, ""))
    # Catalog-dependent policy: if Cerave Hydrating Cleanser exists it may be an EXACT_MATCH;
    # if absent or variant-ambiguous it must not leak unrelated Cerave lotion/cream products.
    tests.append(("Cerave Hydrating Cleanser strict policy", match_text("Cerave Hydrating Cleanser"), {"EXACT_MATCH", "NOT_AVAILABLE", "ASK_CLARIFICATION"}, ""))
    tests.append(("Amoclan syrup scoped", match_text("Amoclan syrup"), {"EXACT_MATCH", "ASK_CLARIFICATION", "NOT_AVAILABLE"}, ""))
    tests.append(("Photoblok speed/exact", match_text("Photoblok 50+"), "EXACT_MATCH", "Photoblok"))

    passed = 0
    for label, result, allowed, product_contains in tests:
        assert_status(label, result, allowed, product_contains)
        if label == "فلاجيل شراب hard form filter":
            products = result.products or ([result.product] if result.product else [])
            if not products:
                raise AssertionError("فلاجيل شراب: expected Flagyl syrup/suspension product(s), got none")
            for p in products:
                name = str(p.get("name") or "").lower()
                form = str(p.get("form") or p.get("medicine_form") or p.get("product_type") or "").lower()
                if "flagyl" not in name:
                    raise AssertionError(f"فلاجيل شراب: non-Flagyl product leaked: {p.get('name')}")
                if form not in {"syrup", "suspension"}:
                    raise AssertionError(f"فلاجيل شراب: wrong form leaked: {p.get('name')} form={form!r}")
        if label == "Cerave Hydrating Cleanser strict policy":
            products = result.products or ([result.product] if result.product else [])
            for p in products:
                name = str(p.get("name") or "").lower()
                form = str(p.get("form") or p.get("product_type") or "").lower()
                if "cerave" not in name:
                    raise AssertionError(f"Cerave cleanser: non-Cerave product leaked: {p.get('name')}")
                if "cleanser" not in name and form != "cleanser":
                    raise AssertionError(f"Cerave cleanser: non-cleanser product leaked: {p.get('name')} form={form!r}")
        passed += 1
        print(f"PASS {label}: {result.status} {(result.product or {}).get('name','') if result.product else ''}")
    print("EXCEL_NATIVE_ACCEPTANCE_ALL_PASS")
    print(f"products_count={products_count}")
    print(f"product_identity_registry={registry_count}")
    print(f"product_search_index={search_index_count}")
    print(f"guided_catalog_index={guided_index_count}")
    print(f"tests_passed={passed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
