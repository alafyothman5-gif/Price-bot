from services.matching.excel_native_matcher import ExcelNativeMatcher

_ENGINE = ExcelNativeMatcher()
_ENGINE.preload()


def _match(slots):
    return _ENGINE.match_vision_slots(slots)


def test_white_petroleum_jelly_vision_exact():
    result = _match({
        "brand": "WHITE",
        "product_name": "",
        "visible_text": "WHITE PETROLEUM JELLY",
        "confidence": "0.95",
    })
    assert result.status == "EXACT_MATCH"
    assert result.product and "petrol" in result.product.get("name", "").lower()


def test_noisy_vichy_normaderm_ocr_exact():
    result = _match({
        "brand": "Vichy",
        "product_name": "",
        "visible_text": "aderm vichy laboratoires v normaderm physiologic al daily purif",
        "confidence": "0.9",
    })
    assert result.status == "EXACT_MATCH"
    assert result.product and "normaderm" in result.product.get("name", "").lower()


def test_noisy_panadol_extra_ocr_not_not_available():
    result = _match({
        "brand": "Panadol",
        "product_name": "",
        "visible_text": "dol extra advance panadol extra panadol extra advance zorb p",
        "confidence": "0.95",
    })
    assert result.status in {"EXACT_MATCH", "ASK_CLARIFICATION"}
    if result.status == "EXACT_MATCH":
        assert result.product and "panadol" in result.product.get("name", "").lower()
    else:
        assert result.products
        assert any("panadol" in p.get("name", "").lower() for p in result.products)
