import os
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import search_engine
import query_slots
import product_identity
import ui_flow
import conversation_state as cs


def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)


def names(products):
    return [str(p.get('name') or '') for p in products]


def assert_no_forbidden(products, forbidden, msg):
    joined = ' | '.join(names(products)).lower()
    for word in forbidden:
        assert_true(word.lower() not in joined, f"{msg}: forbidden {word} in {joined}")


def main():
    db_path = os.environ.get('PRICEBOT_DB_PATH') or '/tmp/pricebot_acceptance.sqlite'
    database.configure_db_path(db_path)
    database.init_db(run_production_guard=False)
    phone='acceptance_safe_user'
    database.clear_state(phone)

    # UI basics and booking disabled
    r=ui_flow.handle_text(phone,'مرحبا'); assert_true('ابدأ' in r, 'greeting')
    r=ui_flow.handle_text(phone,'ابدأ'); assert_true('كيف تريد البحث' in r and 'تصفح الأقسام' in r, 'main menu')
    r=ui_flow.handle_text(phone,'1'); assert_true('اكتب اسم المنتج' in r, 'main menu name search prompt')
    r=ui_flow.handle_text(phone,'القائمة'); assert_true('كيف تريد البحث' in r, 'back to main menu')
    r=ui_flow.handle_text(phone,'بحث'); assert_true('اكتب اسم المنتج' in r and 'أرسل صورة المنتج' in r, 'search submenu')
    r=ui_flow.handle_text(phone,'1'); assert_true('اكتب اسم المنتج' in r, 'search prompt')

    # Regression: form normalization must not match short aliases inside longer words.
    assert_true(query_slots.canonical_form('supplement') == '', 'supplement must not become suppository')
    assert_true(query_slots.canonical_form('supplement_unspecified') == '', 'supplement_unspecified must not become suppository')
    assert_true(query_slots.canonical_form('supp') == 'suppository', 'whole-word supp alias should still work')

    # Arabic drug synonyms must normalize to English product identity, not NOT_AVAILABLE.
    flagyl_slots = query_slots.extract_query_slots('فلاجيل')
    assert_true(flagyl_slots.normalized == 'flagyl', f'Arabic فلاجيل did not normalize to flagyl: {flagyl_slots.normalized}')
    flagyl_syr_slots = query_slots.extract_query_slots('فلاجيل شراب')
    assert_true(flagyl_syr_slots.normalized == 'flagyl syrup' and flagyl_syr_slots.form in {'syrup','suspension'}, f'Arabic Flagyl syrup slots wrong: {flagyl_syr_slots}')

    # Vision long text should resolve to the exact product, not raw token failure.
    cases_exact = {
        'Pro-D3 50,000 IU vitamin k2 15 capsules': 'Pro-D3',
        'Pro Bio Pro-D3 50,000 IU Vitamin K2': 'Pro-D3',
        'Ovanice Female Fertility 90 capsules 850mg': 'Ovanice',
        'Pro-D3 50,000 IU': 'Pro-D3',
        'Ovanice': 'Ovanice',
    }
    for q, expected_name in cases_exact.items():
        result = search_engine.search_product(q)
        assert_true(result.status == 'EXACT_MATCH', f'{q} expected exact got {result.status}')
        assert_true(result.product and expected_name.lower() in (result.product.get('name') or '').lower(), f'{q} wrong product {result.product}')
        assert_true(result.product.get('price'), f'{q} no price')
    prod3 = search_engine.search_product('Pro-D3 50,000 IU vitamin k2 15 capsules')
    assert_true(prod3.status == 'EXACT_MATCH' and prod3.product and 'Pro-D3' in (prod3.product.get('name') or ''), 'mandatory prod3 vitamin k2 exact regression')


    # Brand/family guard: do not show other Rilastil products.
    result=search_engine.search_product('Rilastil xerolact PB متوفر')
    assert_true(result.status == 'NOT_AVAILABLE', f'rilastil expected not available got {result.status}')
    assert_true(not result.products, 'rilastil must not list other products')

    # Cosmetic type guard.
    result=search_engine.search_product('Cerave Hydrating Cleanser')
    assert_true(result.status in {'EXACT_MATCH','NOT_AVAILABLE','COSMETIC_ALTERNATIVES'}, f'cerave cleanser status {result.status}')
    assert_no_forbidden(result.products, ['moisturizing lotion','moisturising lotion','serum','cream 454'], 'cerave cleanser type guard')
    for p in result.products:
        form=(p.get('form') or '').lower()
        name=(p.get('name') or '').lower()
        assert_true('cleanser' in form or 'cleanser' in name or 'micellair' in name, f'non-cleanser alternative {p.get("name")}')

    # Cross-category guard.
    result=search_engine.search_product('Amoclan syrup')
    assert_true(result.status in {'ASK_CLARIFICATION','EXACT_MATCH','NOT_AVAILABLE'}, f'amoclan status {result.status}')
    assert_no_forbidden(result.products, ['vitamin syrup'], 'amoclan no supplement syrup')
    for p in result.products:
        assert_true((p.get('category') or '') == 'medicine', f'amoclan non-medicine {p.get("name")}')


    # Production V2 variant resolver: generic brand/family names must never expose a first price.
    result=search_engine.search_product('Panadol')
    assert_true(result.status == 'ASK_CLARIFICATION', f'Panadol generic should clarify variants, got {result.status}')
    assert_true(result.products and all('panadol' in (p.get('name') or '').lower() for p in result.products), f'Panadol wrong products {names(result.products)}')

    result=search_engine.search_product('Panadol Advance 500mg 96tab')
    assert_true(result.status == 'EXACT_MATCH' and result.product and 'panadol advance' in (result.product.get('name') or '').lower(), f'Panadol full variant should exact match, got {result.status} {result.product}')

    for q in ['pro','scar']:
        result=search_engine.search_product(q)
        assert_true(result.status in {'LOW_CONFIDENCE','ASK_CLARIFICATION'} and not result.products, f'{q} weak token should not return catalog products: {result.status} {names(result.products)}')

    # Medicine variants and duplicates.
    result=search_engine.search_product('فلاجيل')
    assert_true(result.status == 'ASK_CLARIFICATION', f'Arabic Flagyl should clarify variants, got {result.status}')
    assert_true(result.products and all('flagyl' in (p.get('name') or '').lower() for p in result.products), f'Arabic Flagyl wrong products {names(result.products)}')
    result=search_engine.search_product('فلاجيل شراب')
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION','NOT_AVAILABLE'}, 'flagyl syrup status')
    for p in result.products:
        assert_true('flagyl' in (p.get('name') or '').lower(), f'flagyl syrup non-flagyl {p.get("name")}')
        assert_true((p.get('form') or '') in {'syrup','suspension'}, f'flagyl syrup wrong form {p.get("name")}')
    result=search_engine.search_product('فلاجيل 500')
    assert_true(result.status == 'ASK_CLARIFICATION', f'Arabic Flagyl 500 should clarify duplicate/form, got {result.status}')
    assert_true(result.products and all('flagyl' in (p.get('name') or '').lower() for p in result.products), f'Arabic Flagyl 500 wrong products {names(result.products)}')
    # Enterprise strict dedupe removes same-identity duplicate price rows.
    result=search_engine.search_product('Cipralex 10mg')
    assert_true(result.status == 'EXACT_MATCH', f'Cipralex 10mg deduped exact should match, got {result.status}')
    for q in ['Flagyl 500mg','Janumet 50/1000mg']:
        result=search_engine.search_product(q)
        assert_true(result.status in {'ASK_CLARIFICATION','EXACT_MATCH'}, f'{q} should be dedupe-safe, got {result.status}')
        assert_true(result.products, f'{q} should still return safe scoped products')

    # Vision slot matcher.
    result=search_engine.search_from_vision_slots({'brand':'Pro-D3','product_name':'Pro-D3','strength':'50,000 IU','pack':'15 capsules','visible_text':'Pro-D3 50,000 IU vitamin k2 15 capsules','confidence':0.92})
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION'}, f'vision prod3 status {result.status}')
    assert_no_forbidden(result.products, ['probiotics','protein','proviron','cypro','enteroplex','fokids','pro biovit'], 'vision prod3 scoped')
    assert_true(all('Pro-D3' in (p.get('name') or '') for p in result.products), f'vision prod3 non Pro-D3 result {names(result.products)}')

    result=search_engine.search_from_vision_slots({'brand':'','product_name':'Pro-D3 50,000 IU Vitamin K2 15 capsules','visible_text':'Pro-D3 50,000 IU vitamin k2 15 capsules','confidence':0.92})
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION'}, f'vision prod3 raw product_name status {result.status}')
    assert_no_forbidden(result.products, ['probiotics','protein','proviron','cypro','enteroplex','fokids','pro biovit'], 'vision prod3 raw scoped')
    assert_true(all('Pro-D3' in (p.get('name') or '') for p in result.products), f'vision prod3 raw non Pro-D3 result {names(result.products)}')

    result=search_engine.search_from_vision_slots({'brand':'Ovanice','product_name':'Ovanice Female Fertility','strength':'850mg','pack':'90 capsules','visible_text':'Ovanice Female Fertility 90 capsules 850mg','confidence':0.9})
    assert_true(result.status == 'EXACT_MATCH' and 'Ovanice' in result.product.get('name',''), 'vision ovanice')

    result=search_engine.search_from_vision_slots({'brand':'Dexeryl','product_name':'DEXERYL crème','form':'cream','size':'250g','visible_text':'DEXERYL crème cream 250g tube glycerol vaseline paraffin','confidence':0.9})
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION'}, f'vision dexeryl should not be not_available+alt, got {result.status}')
    assert_true(all('DEXERYL' in (p.get('name') or '').upper() for p in result.products), f'vision dexeryl wrong product {names(result.products)}')

    # Strict normalized exact matching before any ranking.  These are real
    # catalog products that may be stored with a longer/shorter name than the
    # user's text or Vision OCR.
    result=search_engine.search_product('Gyno daktarin')
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION'}, f'gyno daktarin should find catalog row, got {result.status}')
    assert_true(all(('gyno' in (p.get('name') or '').lower() or 'daktarin' in (p.get('name') or '').lower()) for p in result.products), f'gyno wrong products {names(result.products)}')
    assert_true(any('daktarin' in (p.get('name') or '').lower() for p in result.products), f'gyno no daktarin product {names(result.products)}')

    result=search_engine.search_product('MEBO scar')
    assert_true(result.status == 'EXACT_MATCH' and result.product and (result.product.get('name') or '').lower() == 'mebo scar', f'mebo scar wrong {result.status} {result.product}')

    result=search_engine.search_product('Mebo ointment')
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION'}, f'mebo ointment should match/clarify, got {result.status}')
    assert_true(all('mebo' in (p.get('name') or '').lower() for p in result.products), f'mebo ointment wrong products {names(result.products)}')

    result=search_engine.search_from_vision_slots({'brand':'MEBO','product_name':'MEBO SCAR OINTMENT','form':'ointment','size':'30g','visible_text':'MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym','confidence':0.9})
    assert_true(result.status == 'EXACT_MATCH' and result.product and (result.product.get('name') or '').lower() == 'mebo scar', f'vision mebo scar brand-locked wrong {result.status} {result.product} {names(result.products)}')
    assert_no_forbidden(result.products, ['First Scar', 'Hemazym'], 'vision MEBO brand lock must exclude First Scar/background')

    result=search_engine.search_from_vision_slots({'brand':'','product_name':'MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym','form':'ointment','visible_text':'MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym','confidence':0.9})
    assert_true(result.status == 'EXACT_MATCH' and result.product and (result.product.get('name') or '').lower() == 'mebo scar', f'vision foreground chose wrong/background product {result.status} {result.product} {names(result.products)}')
    assert_no_forbidden(result.products, ['hemazym'], 'vision foreground must not choose background product')

    result=search_engine.search_from_vision_slots({'brand':'','product_name':'','main_visible_product':'MEBO SCAR OINTMENT REDUCE SCARS 30g','background_text':'Hemazym','form':'ointment','visible_text':'MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym','confidence':0.9})
    assert_true(result.status == 'EXACT_MATCH' and result.product and (result.product.get('name') or '').lower() == 'mebo scar', f'vision main_visible_product/background wrong {result.status} {result.product} {names(result.products)}')
    assert_no_forbidden(result.products, ['hemazym'], 'vision background_text must not choose background product')

    result=search_engine.search_from_vision_slots({'brand':'','product_name':'','form':'ointment','visible_text':'MEBO SCAR OINTMENT REDUCE SCARS 30g Hemazym','confidence':0.9})
    assert_true(result.status == 'EXACT_MATCH' and result.product and (result.product.get('name') or '').lower() == 'mebo scar', f'vision visible_text-only MEBO background wrong {result.status} {result.product} {names(result.products)}')
    assert_no_forbidden(result.products, ['hemazym'], 'vision visible_text-only must not choose background product')

    result=search_engine.search_from_vision_slots({'brand':'Gyno Daktarin','product_name':'Gyno Daktarin Vag Cream','form':'cream','visible_text':'Gyno Daktarin Vag Cream','confidence':0.9})
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION'}, f'vision gyno daktarin status {result.status}')
    assert_true(all('daktarin' in (p.get('name') or '').lower() for p in result.products), f'vision gyno wrong products {names(result.products)}')

    result=search_engine.search_from_vision_slots({'brand':'','product_name':'cream tube','size':'250g','visible_text':'cream tube 250g','confidence':0.9})
    assert_true(result.status in {'LOW_CONFIDENCE','IMAGE_UNCLEAR'}, f'generic image should not match {result.status}')


    # Production final image cases: clear foreground product, missing catalog review, and front-view low confidence.
    result=search_engine.search_from_vision_slots({'brand':'MARI','main_visible_product':'MARI FEMALE','product_name':'MARI FEMALE','strength':'3600mg','pack':'30 Sachet','size':'108g','visible_text':'MARI FEMALE Female Fertility 3600mg 30 Sachet 108g','confidence':0.93})
    assert_true(result.status == 'EXACT_MATCH' and result.product and 'mari female' in (result.product.get('name') or '').lower(), f'vision mari female wrong {result.status} {names(result.products)}')

    result=search_engine.search_from_vision_slots({'brand':'PROPOLI','main_visible_product':'PROPOLI Concentrated Fluid','product_name':'PROPOLI Concentrated Fluid','visible_text':'PROPOLI Concentrated Fluid Food Supplement','confidence':0.91})
    assert_true(result.status == 'EXACT_MATCH' and result.product and 'propoli' in (result.product.get('name') or '').lower(), f'vision propoli wrong {result.status} {names(result.products)}')
    assert_no_forbidden(result.products, ['Luma', 'Ocean', 'Propolis & Pollen'], 'vision propoli must not choose other propolis/background products')

    result=search_engine.search_from_vision_slots({'brand':'Hemazym','main_visible_product':'Hemazym','product_name':'Hemazym','form':'capsule','pack':'30 capsules','visible_text':'Liposomal Hemazym Iron Supplement High Absorption Folic Acid Vitamin B12 30 capsules','confidence':0.93})
    assert_true(result.status == 'EXACT_MATCH' and result.product and 'hemazym' in (result.product.get('name') or '').lower(), f'vision hemazym wrong {result.status} {names(result.products)}')

    before_learning2 = database.count_table('learning_inbox')
    result=search_engine.search_from_vision_slots({'brand':'Remedica','product_name':'','form':'oral suspension','size':'100 ml','visible_text':'100 ml oral suspension Remedica','confidence':0.88})
    assert_true(result.status in {'LOW_CONFIDENCE','IMAGE_UNCLEAR'}, f'remedica front-view partial should not be NOT_AVAILABLE {result.status}')
    after_learning2 = database.count_table('learning_inbox')
    assert_true(after_learning2 >= before_learning2 + 1, 'learning inbox did not capture partial Remedica image')

    # Required production tables exist.
    with database.connect() as conn:
        for table in ['dynamic_synonyms','learning_inbox','admin_audit_log','catalog_import_jobs','catalog_import_reports','image_cache','product_identity_registry']:
            assert_true(database.table_exists(conn, table), f'missing production table {table}')

    # Product Identity Registry must exist and Learning Inbox must capture safe failures.
    assert_true(database.count_table('product_identity_registry') == database.count_products(), 'identity registry must match strict deduped products count')
    before_learning = database.count_table('learning_inbox')
    result = search_engine.search_product('definitely missing product zzz 12345')
    assert_true(result.status == 'NOT_AVAILABLE', 'missing product should be not available')
    after_learning = database.count_table('learning_inbox')
    assert_true(after_learning >= before_learning + 1, 'learning inbox did not capture failure')

    print('SAFE_MATCHING_ACCEPTANCE_PASS=83')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
