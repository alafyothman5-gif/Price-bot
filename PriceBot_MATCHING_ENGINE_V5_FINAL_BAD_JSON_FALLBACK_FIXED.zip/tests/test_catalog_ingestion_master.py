from __future__ import annotations

import tempfile
from pathlib import Path

import database
from normalizer import normalize_text
from services.catalog.catalog_ingestion_master import (
    DECISION_AMBIGUOUS_VARIANT,
    DECISION_EXACT_DUPLICATE_MERGED,
    DECISION_UPDATE_PRICE,
    WARNING_DUPLICATE_PRICE_LAST_VALUE_USED,
    approve_ingestion_job,
    approve_review_item,
    create_ingestion_plan,
    ensure_schema,
)
from services.catalog.excel_native_importer import (
    fast_rebuild_guided_index,
    fast_rebuild_identity_registry,
    fast_rebuild_search_index,
)


def _insert_product(conn, **fields) -> int:
    row = {c: "" for c in database.PRODUCT_COLUMNS}
    row.update(fields)
    defaults = {
        "merchant_id": "1",
        "available": "true",
        "search_mode": "sellable",
        "quality_status": "approved",
        "review_status": "approved",
        "currency": "LYD",
    }
    for k, v in defaults.items():
        if not row.get(k):
            row[k] = v
    cols = list(database.PRODUCT_COLUMNS)
    table_cols = {r[1] for r in conn.execute("PRAGMA table_info(products)").fetchall()}
    if "canonical_display_name" not in table_cols:
        conn.execute("ALTER TABLE products ADD COLUMN canonical_display_name TEXT DEFAULT ''")
    cols_plus = cols + (["canonical_display_name"] if "canonical_display_name" not in cols else [])
    row["canonical_display_name"] = row.get("canonical_display_name") or row.get("name") or ""
    placeholders = ["?"] * len(cols_plus) + ["datetime('now')", "datetime('now')"]
    cur = conn.execute(
        f'INSERT INTO products({", ".join(chr(34)+c+chr(34) for c in cols_plus + ["created_at", "updated_at"])}) VALUES({", ".join(placeholders)})',
        [row.get(c, "") for c in cols_plus],
    )
    return int(cur.lastrowid)


def _xlsx(path: Path, rows):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["اسم المنتج", "السعر"])
    for row in rows:
        ws.append(row)
    wb.save(path)
    wb.close()


def _new_job(path: Path) -> int:
    return database.create_catalog_import_job(path.name, str(path), status="queued")


def _decisions(job_id: int):
    with database.connect() as conn:
        return {r[0]: r[1] for r in conn.execute("SELECT decision, COUNT(*) FROM catalog_staging_items WHERE job_id=? GROUP BY decision", (job_id,)).fetchall()}


def _seed_catalog():
    with database.connect() as conn:
        panadol_id = _insert_product(
            conn,
            name="Panadol 500mg Tablet",
            normalized_name=normalize_text("Panadol 500mg Tablet"),
            brand="panadol",
            product_family="",
            category="medicine",
            form="tablet",
            strength="500mg",
            price="10",
            aliases="Panadol 500mg | Panadol 500mg Tablet",
            ocr_keywords="Panadol 500mg",
            identity_key="panadol||medicine|tablet|500mg||",
        )
        cipralex_1 = _insert_product(
            conn,
            name="Cipralex 10mg",
            normalized_name=normalize_text("Cipralex 10mg"),
            brand="cipralex",
            product_family="",
            category="medicine",
            form="tablet",
            strength="10mg",
            price="20",
            aliases="Cipralex 10mg",
            ocr_keywords="Cipralex 10mg",
            identity_key="cipralex||medicine|tablet|10mg||",
        )
        cipralex_2 = _insert_product(
            conn,
            name="Cipralex 10mg",
            normalized_name=normalize_text("Cipralex 10mg"),
            brand="cipralex",
            product_family="",
            category="medicine",
            form="tablet",
            strength="10mg",
            price="20",
            aliases="Cipralex 10mg",
            ocr_keywords="Cipralex 10mg",
            identity_key="cipralex||medicine|tablet|10mg||",
        )
        _insert_product(
            conn,
            name="Cipralex 20mg",
            normalized_name=normalize_text("Cipralex 20mg"),
            brand="cipralex",
            product_family="",
            category="medicine",
            form="tablet",
            strength="20mg",
            price="30",
            aliases="Cipralex 20mg",
            ocr_keywords="Cipralex 20mg",
            identity_key="cipralex||medicine|tablet|20mg||",
        )
        flagyl_tab = _insert_product(
            conn,
            name="Flagyl 500mg Tablet",
            normalized_name=normalize_text("Flagyl 500mg Tablet"),
            brand="flagyl",
            product_family="",
            category="medicine",
            form="tablet",
            strength="500mg",
            price="15",
            aliases="Flagyl 500mg tablet | فلاجيل 500",
            ocr_keywords="Flagyl 500mg tablet",
            identity_key="flagyl||medicine|tablet|500mg||",
        )
        _insert_product(
            conn,
            name="Flagyl 125mg Syrup",
            normalized_name=normalize_text("Flagyl 125mg Syrup"),
            brand="flagyl",
            product_family="",
            category="medicine",
            form="syrup",
            strength="125mg",
            price="18",
            aliases="Flagyl syrup | فلاجيل شراب",
            ocr_keywords="Flagyl 125mg Syrup",
            identity_key="flagyl||medicine|syrup|125mg||",
        )
        white_id = _insert_product(
            conn,
            name="WHITE PETROLEUM JELLY",
            normalized_name=normalize_text("WHITE PETROLEUM JELLY"),
            brand="",
            product_family="petroleum jelly",
            category="cosmetic",
            form="jelly",
            price="8",
            aliases="WHITE PETROLEUM JELLY | WHITE PETROLEEUM JELLY",
            ocr_keywords="WHITE PETROLEUM JELLY",
            identity_key="|petroleum jelly|cosmetic|jelly|||",
        )
        _insert_product(
            conn,
            name="Old Missing Product",
            normalized_name=normalize_text("Old Missing Product"),
            brand="oldbrand",
            product_family="missing",
            category="other",
            price="9",
            identity_key="oldbrand|missing|other||||",
        )
    fast_rebuild_search_index(); fast_rebuild_identity_registry(); fast_rebuild_guided_index()
    return {"panadol": panadol_id, "cipralex_1": cipralex_1, "cipralex_2": cipralex_2, "flagyl_tab": flagyl_tab, "white": white_id}


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        db = Path(td) / "pricebot.db"
        database.configure_db_path(str(db))
        ensure_schema()
        ids = _seed_catalog()

        import search_engine
        from services.matching.excel_native_matcher import invalidate_memory_index, match_vision_slots

        search_engine.invalidate_memory_index(); invalidate_memory_index()
        result = search_engine.search_product("Cipralex 10mg")
        assert result.status == "EXACT_MATCH", f"Cipralex 10mg deduped exact should match, got {result.status}"

        vision = match_vision_slots({"brand": "WHITE", "product_name": "", "visible_text": "WHITE PETROLEUM JELLY", "confidence": 0.95})
        assert vision.status == "EXACT_MATCH", f"WHITE PETROLEUM JELLY vision should EXACT_MATCH, got {vision.status} {vision.diagnostics}"

        # Test 1: old catalog price changes normally; not PRICE_CONFLICT/review.
        excel = Path(td) / "weekly_panadol_12.xlsx"
        _xlsx(excel, [["Panadol 500mg tablet", 12]])
        job_id = _new_job(excel)
        report = create_ingestion_plan(job_id, str(excel), 1)
        assert database.get_product(ids["panadol"])["price"] == "10", "production changed before approval"
        assert report["summary"]["prices_updated"] == 1, report
        assert report["summary"]["price_conflicts"] == 0, report
        approved = approve_ingestion_job(job_id, actor="test")
        assert database.get_product(ids["panadol"])["price"] == "12", "old price 10 -> new price 12 did not apply"
        assert approved["summary"]["Updated prices"] == 1, approved

        # Test 2: duplicate same product same price merges and search remains exact.
        excel = Path(td) / "weekly_cipralex_dup_same.xlsx"
        _xlsx(excel, [["Cipralex 10mg", 20], ["Cipralex 10mg", 20]])
        job_id = _new_job(excel)
        report = create_ingestion_plan(job_id, str(excel), 1)
        decisions = _decisions(job_id)
        assert decisions.get(DECISION_EXACT_DUPLICATE_MERGED, 0) == 1, decisions
        approve_ingestion_job(job_id, actor="test")
        search_engine.invalidate_memory_index(); invalidate_memory_index()
        result = search_engine.search_product("Cipralex 10mg")
        assert result.status == "EXACT_MATCH", f"Cipralex duplicate same price should EXACT_MATCH, got {result.status}"

        # Test 3: duplicate same product different price uses the last uploaded price with warning, not review.
        excel = Path(td) / "weekly_panadol_dup_diff.xlsx"
        _xlsx(excel, [["Panadol 500mg tablet", 10], ["Panadol 500mg tablet", 12]])
        job_id = _new_job(excel)
        report = create_ingestion_plan(job_id, str(excel), 1)
        assert report["summary"]["duplicate_rows_with_last_price_used"] == 1, report
        assert report["summary"]["price_conflicts"] == 0, report
        approve_ingestion_job(job_id, actor="test")
        assert database.get_product(ids["panadol"])["price"] == "12", "duplicate different prices did not use last value"

        # Test 4: ambiguous product name does not update price.
        excel = Path(td) / "weekly_flagyl_ambiguous.xlsx"
        _xlsx(excel, [["Flagyl", 10], ["Flagyl", 12]])
        job_id = _new_job(excel)
        report = create_ingestion_plan(job_id, str(excel), 1)
        decisions = _decisions(job_id)
        assert decisions.get(DECISION_AMBIGUOUS_VARIANT, 0) >= 1, (report, decisions)
        assert database.get_product(ids["flagyl_tab"])["price"] == "15", "ambiguous Flagyl changed price before approval"

        # Test 5: clear variant duplicate different price uses last value.
        excel = Path(td) / "weekly_flagyl_clear_variant.xlsx"
        _xlsx(excel, [["Flagyl 500mg tablet", 10], ["Flagyl 500mg tablet", 12]])
        job_id = _new_job(excel)
        report = create_ingestion_plan(job_id, str(excel), 1)
        assert report["summary"]["duplicate_rows_with_last_price_used"] == 1, report
        approve_ingestion_job(job_id, actor="test")
        assert database.get_product(ids["flagyl_tab"])["price"] == "12", "clear Flagyl variant did not use last value"

        # Missing rows are report-only unless full inventory upload is explicitly selected.
        assert any(d.get("decision") == "MISSING_FROM_UPLOAD" for d in report["examples"].get("MISSING_FROM_UPLOAD", []) ) or report["summary"]["missing_from_upload_report_only"] >= 1

        # New review item approval appears in search immediately without restart.
        excel = Path(td) / "weekly_new_product.xlsx"
        _xlsx(excel, [["NewSafe Product 100ml", 44]])
        job_id = _new_job(excel)
        create_ingestion_plan(job_id, str(excel), 1)
        with database.connect() as conn:
            review_id = conn.execute("SELECT id FROM catalog_review_items WHERE job_id=? AND status='pending' ORDER BY id DESC LIMIT 1", (job_id,)).fetchone()[0]
        approve_review_item(review_id, actor="test", suggested_brand="newsafe", suggested_family="product", suggested_category="cosmetic", suggested_form="gel", suggested_size="100ml", suggested_aliases="NewSafe Product 100ml")
        search_engine.invalidate_memory_index(); invalidate_memory_index()
        result = search_engine.search_product("NewSafe Product 100ml")
        assert result.status == "EXACT_MATCH", f"approved review item not searchable immediately: {result.status}"

        print("CATALOG_INGESTION_MASTER_ACCEPTANCE_PASS")
        print(f"products_count={database.count_products()}")
        print(f"product_identity_registry={database.count_table('product_identity_registry')}")
        print(f"product_search_index={database.count_table('product_search_index')}")
        print(f"guided_catalog_index={database.count_table('guided_catalog_index')}")
        print("cipralex_10mg_duplicate_exact=EXACT_MATCH")
        print("old_price_10_to_12=UPDATE_PRICE")
        print(f"duplicate_different_prices_warning={WARNING_DUPLICATE_PRICE_LAST_VALUE_USED}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
