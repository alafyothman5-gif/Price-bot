# PriceBot Vision OCR Bridge Fix

Fixed image matching failures where Vision/OCR successfully read package text but the WhatsApp image pipeline sent a long noisy OCR phrase to the strict matcher and received `NOT_AVAILABLE`.

## Main changes

- Added image OCR candidate-query generation in `services/matching/excel_native_matcher.py`.
- Preserves the strict matcher; no global fuzzy fallback was added.
- Cleans OCR marketing/background words before matching.
- Generates ordered candidates from structured Vision slots, cleaned OCR, known product phrases, brand+family tokens, and safe OCR n-grams.
- Tries all image candidate queries and returns the first `EXACT_MATCH`.
- If no exact match is found but a candidate returns clarification/list, returns that instead of a false `NOT_AVAILABLE`.
- Keeps diagnostics: `vision_query`, `vision_stage`, and `vision_candidates`.
- Added tests in `tests/test_vision_ocr_bridge.py`.

## Fixed examples

- `WHITE PETROLEUM JELLY` image OCR → `EXACT_MATCH`.
- Noisy Vichy OCR such as `aderm vichy laboratoires v normaderm physiologic ...` → `Vichy Normaderm` `EXACT_MATCH`.
- Noisy Panadol OCR such as `dol extra advance panadol extra ... zorb p` → `Panadol Extra optizorb` `EXACT_MATCH` when available, otherwise safe clarification.

## Local verification

Tested against `products_master_ready.xlsx` rebuilt DB:

- `products=5791`
- `product_identity_registry=5791`
- `product_search_index=178406`
- `guided_catalog_index=5791`

Additional tests passed:

- `test_white_petroleum_jelly_vision_exact`
- `test_noisy_vichy_normaderm_ocr_exact`
- `test_noisy_panadol_extra_ocr_not_not_available`
