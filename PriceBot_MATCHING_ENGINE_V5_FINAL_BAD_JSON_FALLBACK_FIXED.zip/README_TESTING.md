# Testing

Build a clean test database from the included Excel:

```bash
python3 tools/rebuild_database_from_any_excel.py --excel products_master_ready.xlsx --db-path /tmp/pricebot_excel_native_test.db --report /tmp/pricebot_excel_native_test_report.json
```

Run acceptance tests:

```bash
PRICEBOT_MATCH_LOG=0 python3 tools/run_acceptance_tests.py --db-path /tmp/pricebot_excel_native_test.db
```

Expected result:

```text
products_count=5791
product_identity_registry=5791
product_search_index=92817
guided_catalog_index=3558
ACCEPTANCE_TESTS_ALL_PASS=17
```

The test suite includes the mandatory clean-install behaviors:

```text
PROPOLI vision -> EXACT_MATCH
Hemazym vision -> EXACT_MATCH
Mari Female vision -> EXACT_MATCH
MEBO Scar vision -> EXACT_MATCH
فلاجيل شراب -> Flagyl only, syrup/suspension only
Panadol -> ASK_CLARIFICATION
```
