# PriceBot Enterprise Ingestion V2

Implemented mandatory changes requested after review.

## Mandatory AI Enrichment

- Removed optional `PRICEBOT_AI_ENRICHMENT=1` gate.
- Every Excel import row now passes through `services/catalog/ai_enrichment_agent.py`.
- OpenRouter is called automatically when `OPENROUTER_API_KEY` is configured.
- Local deterministic mandatory fallback still resolves all catalog labels in test/local environments.
- Final imported catalog does not persist `needs_review`, `unknown`, or `unclassified` as customer-facing classification values.

## Strict Deduplication

- Removed optional `PRICEBOT_DEDUPE_BY_IDENTITY=1` behavior.
- Excel rows are deduplicated by barcode, identity_key, or normalized name before save.
- Live DB duplicate product rows are merged and deleted.
- Aliases and OCR keywords are merged into the surviving row.
- Price conflicts are resolved by the configured price policy, default `latest`.

## PostgreSQL Production Migration

- Added PostgreSQL runtime path through `DATABASE_URL=postgresql://...`.
- Added `psycopg[binary]` dependency.
- Added real write migration script: `tools/migrate_sqlite_to_postgres.py`.
- Migration creates schema, copies all supported tables, preserves integer ids, and upserts on conflict without wiping PostgreSQL tables.
- Production can enforce PostgreSQL with `PRICEBOT_REQUIRE_POSTGRES_PRODUCTION=1`.

## Verified Local Build

```text
products_count=4982
product_identity_registry=4982
product_search_index=79861
guided_catalog_index=4982
ACCEPTANCE_TESTS_ALL_PASS=17
SAFE_MATCHING_ACCEPTANCE_PASS=83
needs_review_after=0
unclassified_customer_fields_after=0
duplicate_identity_keys_after=0
duplicate_barcodes_after=0
excel_duplicate_rows_merged=809
```

## Notes

The sandbox does not include a running PostgreSQL server, so the migration write path is implemented and syntax-compiled, while live PostgreSQL copy must be run on the server after installing requirements and providing a real `DATABASE_URL`.
