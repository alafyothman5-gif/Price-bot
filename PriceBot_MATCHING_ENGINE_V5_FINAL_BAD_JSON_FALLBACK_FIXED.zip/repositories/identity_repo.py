"""Identity registry repository facade."""
from database import load_product_identity_registry, replace_product_identity_registry, count_table
