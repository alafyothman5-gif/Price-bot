"""Learning inbox repository facade."""
from database import record_learning_event, list_learning_inbox, approve_learning_alias, update_learning_status
