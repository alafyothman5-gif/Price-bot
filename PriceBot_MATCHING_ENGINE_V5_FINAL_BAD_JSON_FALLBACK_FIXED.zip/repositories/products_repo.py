"""Products repository facade for the organized PriceBot layout."""
from database import get_product, load_product_rows, product_visible, count_products
try:
    from database import get_products_by_ids
except Exception:  # pragma: no cover
    get_products_by_ids = None
