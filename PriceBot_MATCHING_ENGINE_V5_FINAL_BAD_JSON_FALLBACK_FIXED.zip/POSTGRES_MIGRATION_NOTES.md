# PostgreSQL Migration Notes

## Status

A real write migration tool is included. The previous dry-run-only refusal was removed.

## Files

```text
tools/migrate_sqlite_to_postgres.py
database.py
requirements.txt
```

## Required dependency

```bash
pip install -r requirements.txt
```

`requirements.txt` includes:

```text
psycopg[binary]==3.2.3
```

## Migration command

```bash
python tools/migrate_sqlite_to_postgres.py \
  --sqlite /opt/pricebot/pricebot.db \
  --postgres-dsn "$DATABASE_URL"
```

## Production environment

```bash
export DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/pricebot'
export PRICEBOT_REQUIRE_POSTGRES_PRODUCTION=1
export PRICEBOT_PRODUCTION_MODE=1
```

## Behavior

- Creates PostgreSQL schema through `database.init_db()`.
- Copies tables in batches.
- Preserves integer ids.
- Uses `ON CONFLICT` upserts instead of wiping tables.
- Repeated runs are safe.
- Runtime `database.connect()` switches to PostgreSQL when `DATABASE_URL` starts with `postgres://` or `postgresql://`.

## Local verification

Dry-run source count worked against the rebuilt SQLite catalog:

```text
products=4982
product_search_index=79861
product_identity_registry=4982
guided_catalog_index=4982
DRY_RUN_OK no_postgres_write_performed=1
```

Live PostgreSQL write requires an actual PostgreSQL server and valid `DATABASE_URL` on the deployment server.
