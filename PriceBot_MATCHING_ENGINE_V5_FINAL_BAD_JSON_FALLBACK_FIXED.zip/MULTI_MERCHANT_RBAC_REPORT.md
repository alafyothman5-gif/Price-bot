# Multi-Merchant + RBAC Report

Implemented merchant isolation fields:

- products: `merchant_id`
- orders: `merchant_id`
- learning_inbox: `merchant_id`
- catalog import jobs: `merchant_id`
- catalog review items: `merchant_id`
- admin users: `merchant_id`

Merchant dashboard operations use merchant-scoped queries and updates. Admin users now support roles:

- owner
- admin
- pharmacist
- viewer

CSRF protection is applied to POST forms in admin and merchant portals. Critical actions are written to `admin_audit_log`.
