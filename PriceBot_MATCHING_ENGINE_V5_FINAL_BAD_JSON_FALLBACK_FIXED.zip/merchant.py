from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import tempfile
import time
from io import BytesIO
from pathlib import Path
from typing import Dict

import qrcode
from fastapi import APIRouter, BackgroundTasks, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates

import database
from services.security import csrf
from tasks.catalog_tasks import catalog_stage_import
from services.catalog.catalog_ingestion_master import (
    approve_review_item,
    job_report,
    pending_reviews,
    reject_review_item,
)
from services.catalog.staging_workflow import approve_staging_job, reject_staging_job

router = APIRouter()
templates = Jinja2Templates(directory="templates")
MERCHANT_USERNAME = os.getenv("PRICEBOT_MERCHANT_USERNAME") or os.getenv("MERCHANT_USERNAME") or "merchant"
MERCHANT_PASSWORD = os.getenv("PRICEBOT_MERCHANT_PASSWORD") or os.getenv("MERCHANT_PASSWORD") or os.getenv("MERCHANT_CODE", "")
MERCHANT_COOKIE = "pricebot_merchant_session"
MERCHANT_TTL_SECONDS = int(os.getenv("PRICEBOT_MERCHANT_SESSION_TTL_SECONDS", "21600") or 21600)
_RATE: Dict[str, list] = {}


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return forwarded or (request.client.host if request.client else "unknown")


def _rate_ok(request: Request, limit: int = 30, window: int = 60) -> bool:
    ip = _client_ip(request)
    now = time.time()
    bucket = _RATE.setdefault(ip, [])
    bucket[:] = [x for x in bucket if now - x < window]
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def _secret() -> bytes:
    key = os.getenv("PRICEBOT_MERCHANT_SESSION_SECRET") or os.getenv("PRICEBOT_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD") or MERCHANT_PASSWORD
    return (key or "missing-merchant-secret").encode("utf-8")


def _sign(payload: str) -> str:
    return hmac.new(_secret(), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _make_session(username: str) -> str:
    ts = str(int(time.time()))
    nonce = secrets.token_urlsafe(18)
    payload = f"{username}:{ts}:{nonce}"
    return f"{payload}:{_sign(payload)}"


def _session_ok(token: str) -> bool:
    try:
        username, ts, nonce, sig = (token or "").split(":", 3)
        payload = f"{username}:{ts}:{nonce}"
        return username == MERCHANT_USERNAME and hmac.compare_digest(sig, _sign(payload)) and time.time() - int(ts) <= MERCHANT_TTL_SECONDS
    except Exception:
        return False


def _require_auth(request: Request):
    if not _rate_ok(request):
        return PlainTextResponse("rate limited", status_code=429)
    if not _session_ok(request.cookies.get(MERCHANT_COOKIE, "")):
        return RedirectResponse("/merchant/login", status_code=303)
    return None


def _csrf_token(request: Request) -> str:
    return csrf.issue_token(request.cookies.get(MERCHANT_COOKIE, ""))


def _require_csrf(request: Request, token: str = ""):
    if not csrf.verify_token(token, request.cookies.get(MERCHANT_COOKIE, "")):
        database.audit_admin("merchant_csrf_rejected", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"path": str(request.url.path)})
        return PlainTextResponse("CSRF validation failed", status_code=403)
    return None


def _render(request: Request, template: str, context: Dict):
    context = dict(context)
    context.setdefault("csrf_token", _csrf_token(request))
    return templates.TemplateResponse(template, context)


def _merchant_id() -> int:
    return database.default_merchant_id()


def _merchant_nav(active: str = "orders") -> list[Dict]:
    items = [
        ("dashboard", "/merchant", "📊", "الرئيسية"),
        ("orders", "/merchant/orders", "🧾", "الطلبات"),
        ("catalog", "/merchant/catalog", "📦", "رفع Excel"),
        ("learning", "/merchant/learning", "🧠", "Learning Inbox"),
        ("products", "/merchant/products", "💵", "الأسعار"),
        ("share", "/merchant/share", "🔗", "QR & Link"),
        ("portal", "/portal", "🌐", "البوابة"),
    ]
    return [{"active": key == active, "href": href, "icon": icon, "label": label} for key, href, icon, label in items]


def _settings() -> Dict:
    return database.get_merchant_settings(_merchant_id())


def _whatsapp_link() -> str:
    import urllib.parse
    s = _settings()
    number = ''.join(ch for ch in str(s.get("whatsapp_number") or os.getenv("BOT_WHATSAPP_NUMBER") or os.getenv("WHATSAPP_PUBLIC_NUMBER") or os.getenv("ADMIN_NOTIFY_PHONE") or "") if ch.isdigit()) or "218000000000"
    pharmacy = s.get("pharmacy_name") or s.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")
    msg = s.get("qr_message") or f"السلام عليكم، أريد الاستفسار عن منتج من {pharmacy}"
    return f"https://wa.me/{number}?text={urllib.parse.quote(msg)}"


def _orders_count(status: str) -> int:
    try:
        return len(database.list_orders(status, 5000, merchant_id=_merchant_id()))
    except Exception:
        return 0


@router.get("/merchant/login", response_class=HTMLResponse)
def login(request: Request, error: str = ""):
    warning = "" if MERCHANT_PASSWORD else "اضبط PRICEBOT_MERCHANT_USERNAME و PRICEBOT_MERCHANT_PASSWORD في .env."
    return templates.TemplateResponse("login.html", {"request": request, "title": "Merchant Login", "heading": "دخول التاجر", "subtitle": "إدارة الطلبات والكتالوج ورابط واتساب.", "error": error, "warning": warning})


@router.post("/merchant/login")
def do_login(request: Request, username: str = Form(...), password: str = Form(...)):
    if not _rate_ok(request, limit=10, window=60):
        return PlainTextResponse("rate limited", status_code=429)
    if not MERCHANT_PASSWORD or username != MERCHANT_USERNAME or not hmac.compare_digest(password, MERCHANT_PASSWORD):
        database.audit_admin("merchant_login_failed", actor=username, ip=_client_ip(request))
        return RedirectResponse("/merchant/login?error=بيانات الدخول غير صحيحة", status_code=303)
    token = _make_session(username)
    database.audit_admin("merchant_login_ok", actor=username, ip=_client_ip(request), details={"merchant_id": _merchant_id()})
    resp = RedirectResponse("/merchant", status_code=303)
    resp.set_cookie(MERCHANT_COOKIE, token, max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
    return resp


@router.post("/merchant/logout")
def logout(request: Request, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    resp = RedirectResponse("/merchant/login", status_code=303)
    resp.delete_cookie(MERCHANT_COOKIE)
    return resp


@router.get("/merchant", response_class=HTMLResponse)
def merchant_home(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    mid = _merchant_id()
    return _render(request, "merchant_dashboard.html", {
        "request": request,
        "title": "Merchant Dashboard",
        "nav": _merchant_nav("dashboard"),
        "orders": database.list_orders("pending", 20, merchant_id=mid),
        "products": database.count_products(),
        "pending_count": _orders_count("pending"),
        "confirmed_count": _orders_count("confirmed"),
        "done_count": _orders_count("done"),
        "whatsapp_link": _whatsapp_link(),
        "settings": _settings(),
    })


@router.get("/merchant/orders", response_class=HTMLResponse)
def merchant_orders(request: Request, status: str = "pending"):
    auth = _require_auth(request)
    if auth:
        return auth
    if status not in {"pending", "confirmed", "done", "rejected"}:
        status = "pending"
    return _render(request, "merchant_orders.html", {"request": request, "title": "Merchant Orders", "nav": _merchant_nav("orders"), "orders": database.list_orders(status, 300, merchant_id=_merchant_id()), "status": status})


@router.post("/merchant/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str, csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status, merchant_id=_merchant_id())
    database.audit_admin("merchant_order_status_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"order_id": order_id, "status": status, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/orders", status_code=303)


@router.get("/merchant/share", response_class=HTMLResponse)
def merchant_share(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return _render(request, "merchant_share.html", {"request": request, "title": "QR & Link", "nav": _merchant_nav("share"), "whatsapp_link": _whatsapp_link(), "settings": _settings()})


@router.post("/merchant/settings")
def merchant_settings_update(request: Request, pharmacy_name: str = Form(""), whatsapp_number: str = Form(""), qr_message: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    database.update_merchant_settings(_merchant_id(), pharmacy_name, whatsapp_number, qr_message)
    database.audit_admin("merchant_settings_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/share", status_code=303)


@router.get("/merchant/qr.png")
def merchant_qr(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    img = qrcode.make(_whatsapp_link())
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


@router.get("/merchant/catalog", response_class=HTMLResponse)
def merchant_catalog(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    jobs = database.list_catalog_import_jobs(20)
    reviews = pending_reviews(limit=80)
    return _render(request, "merchant_catalog.html", {"request": request, "title": "Merchant Catalog", "nav": _merchant_nav("catalog"), "jobs": jobs, "reviews": reviews})




@router.get("/merchant/catalog/upload", response_class=HTMLResponse)
def merchant_catalog_upload_page(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return _render(request, "merchant_catalog.html", {
        "request": request,
        "title": "Merchant Catalog Upload",
        "nav": _merchant_nav("catalog"),
        "jobs": database.list_catalog_import_jobs(20),
        "reviews": pending_reviews(limit=80),
        "upload_mode_note": "default_price_update_only",
    })


@router.get("/merchant/catalog/review", response_class=HTMLResponse)
def merchant_catalog_review_page(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return _render(request, "merchant_catalog.html", {
        "request": request,
        "title": "Catalog Review",
        "nav": _merchant_nav("catalog"),
        "jobs": database.list_catalog_import_jobs(20),
        "reviews": pending_reviews(limit=300),
        "review_mode": True,
    })


@router.post("/merchant/catalog/upload")
async def merchant_catalog_upload(request: Request, background_tasks: BackgroundTasks, file: UploadFile = File(...), upload_type: str = Form("price_update_only"), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    suffix = Path(file.filename or "upload.xlsx").suffix or ".xlsx"
    tmpdir = Path(tempfile.mkdtemp(prefix="pricebot_merchant_catalog_"))
    excel_path = tmpdir / ("upload" + suffix)
    excel_path.write_bytes(await file.read())
    job_id = database.create_catalog_import_job(file.filename or "upload.xlsx", str(excel_path), status="queued")
    mode = "full_inventory" if str(upload_type).lower() in {"full_inventory", "full", "1"} else "price_update_only"
    database.update_catalog_import_job(job_id, job_type="merchant_staging_import", merchant_id=_merchant_id(), requires_approval=1, report_text=f"Merchant upload queued for staging. mode={mode}. Production unchanged until approval. Missing products are report-only unless full inventory is explicitly approved.")
    if os.getenv("PRICEBOT_USE_CELERY", "").lower() in {"1", "true", "yes", "on"}:
        try:
            catalog_stage_import.delay(int(job_id), str(excel_path), int(_merchant_id()))
        except Exception:
            background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(_merchant_id()))
    else:
        background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(_merchant_id()))
    database.audit_admin("merchant_catalog_staging_queued", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"job_id": job_id, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/catalog", status_code=303)


@router.get("/merchant/catalog/jobs/{job_id}", response_class=HTMLResponse)
def merchant_catalog_job(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    report = job_report(int(job_id))
    return _render(request, "merchant_catalog_job.html", {"request": request, "title": f"Catalog Job #{job_id}", "nav": _merchant_nav("catalog"), "job_id": job_id, "report": report})


@router.post("/merchant/catalog/jobs/{job_id}/approve")
def merchant_catalog_job_approve(
    request: Request,
    job_id: int,
    csrf_token: str = Form(""),
    full_inventory_upload: str = Form(""),
    mark_missing_unavailable: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        approve_staging_job(
            int(job_id),
            actor=MERCHANT_USERNAME,
            full_inventory_upload=str(full_inventory_upload).lower() in {"1", "true", "yes", "on"},
            mark_missing_unavailable=str(mark_missing_unavailable).lower() in {"1", "true", "yes", "on"},
        )
    except Exception as exc:
        database.audit_admin("merchant_catalog_approve_failed", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"job_id": job_id, "error": repr(exc)})
        return PlainTextResponse(f"approval failed: {type(exc).__name__}: {exc}", status_code=500)
    return RedirectResponse(f"/merchant/catalog/jobs/{job_id}", status_code=303)


@router.post("/merchant/catalog/jobs/{job_id}/reject")
def merchant_catalog_job_reject(request: Request, job_id: int, reason: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    reject_staging_job(int(job_id), actor=MERCHANT_USERNAME, reason=reason)
    return RedirectResponse("/merchant/catalog", status_code=303)


@router.post("/merchant/catalog/review/{review_id}/approve")
def merchant_catalog_review_approve(
    request: Request,
    review_id: int,
    suggested_brand: str = Form(""),
    suggested_family: str = Form(""),
    suggested_category: str = Form(""),
    suggested_form: str = Form(""),
    suggested_strength: str = Form(""),
    suggested_size: str = Form(""),
    suggested_pack: str = Form(""),
    suggested_aliases: str = Form(""),
    review_notes: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        approve_review_item(
            int(review_id),
            actor=MERCHANT_USERNAME,
            suggested_brand=suggested_brand,
            suggested_family=suggested_family,
            suggested_category=suggested_category,
            suggested_form=suggested_form,
            suggested_strength=suggested_strength,
            suggested_size=suggested_size,
            suggested_pack=suggested_pack,
            suggested_aliases=suggested_aliases,
            review_notes=review_notes,
        )
    except Exception as exc:
        database.audit_admin("merchant_review_approve_failed", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"review_id": review_id, "error": repr(exc)})
        return PlainTextResponse(f"review approval failed: {type(exc).__name__}: {exc}", status_code=500)
    referer = request.headers.get("referer") or "/merchant/catalog"
    return RedirectResponse(referer, status_code=303)


@router.post("/merchant/catalog/review/{review_id}/reject")
def merchant_catalog_review_reject(request: Request, review_id: int, reason: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    reject_review_item(int(review_id), actor=MERCHANT_USERNAME, reason=reason)
    referer = request.headers.get("referer") or "/merchant/catalog"
    return RedirectResponse(referer, status_code=303)


@router.get("/merchant/learning", response_class=HTMLResponse)
def merchant_learning(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    items = database.list_learning_inbox("pending", 100)
    return _render(request, "merchant_learning.html", {"request": request, "title": "Merchant Learning", "nav": _merchant_nav("learning"), "items": items})


@router.get("/merchant/products", response_class=HTMLResponse)
def merchant_products(request: Request, q: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    products = []
    nq = q.strip()
    if nq:
        import normalizer
        key = f"%{normalizer.normalize_text(nq)}%"
        with database.connect() as conn:
            rows = conn.execute("SELECT * FROM products WHERE merchant_id=? AND (normalized_name LIKE ? OR name LIKE ?) ORDER BY name LIMIT 100", (_merchant_id(), key, f"%{nq}%")).fetchall()
            products = [database.dict_row(r) for r in rows]
    return _render(request, "merchant_products.html", {"request": request, "title": "Merchant Products", "nav": _merchant_nav("products"), "products": products, "q": q})


@router.post("/merchant/products/{product_id}/price")
def merchant_product_price(request: Request, product_id: int, price: str = Form(...), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    with database.connect() as conn:
        conn.execute("UPDATE products SET price=?, updated_at=datetime('now') WHERE id=? AND merchant_id=?", (price.strip(), int(product_id), _merchant_id()))
    database.audit_admin("merchant_product_price_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"product_id": product_id, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/products", status_code=303)
