"""Conversation state helpers for the WhatsApp UI flow.

State is persisted in SQLite through database.set_state/get_state.  The JSON
payload keeps the current step plus enough context for numeric choices, back
navigation, product pages, and pending clarification choices.  Database TTL is
handled by database.set_state/get_state.
"""
from __future__ import annotations

from typing import Any, Dict

import database

START = "START"
MAIN_MENU = "MAIN_MENU"
WAITING_FOR_SEARCH_METHOD = "WAITING_FOR_SEARCH_METHOD"
WAITING_FOR_PRODUCT_SEARCH = "WAITING_FOR_PRODUCT_SEARCH"
WAITING_FOR_PRODUCT_IMAGE = "WAITING_FOR_PRODUCT_IMAGE"
BROWSING_CATEGORIES = "BROWSING_CATEGORIES"
BROWSING_SUBCATEGORY = "BROWSING_SUBCATEGORY"
BROWSING_PRODUCT_PAGE = "BROWSING_PRODUCT_PAGE"
WAITING_FOR_CLARIFICATION = "WAITING_FOR_CLARIFICATION"
PRODUCT_DETAIL = "PRODUCT_DETAIL"
WAITING_FOR_QUANTITY = "WAITING_FOR_QUANTITY"


def get(phone: str) -> Dict[str, Any]:
    state = database.get_state(phone)
    return state if isinstance(state, dict) else {}


def set(phone: str, state: str, **data: Any) -> Dict[str, Any]:
    payload: Dict[str, Any] = {"state": state}
    payload.update({k: v for k, v in data.items() if v is not None})
    database.set_state(phone, payload)
    return payload


def clear(phone: str) -> None:
    database.clear_state(phone)


def current_name(state: Dict[str, Any]) -> str:
    return str((state or {}).get("state") or (state or {}).get("mode") or "")
