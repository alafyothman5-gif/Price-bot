# PriceBot Enterprise Ingestion V2 Deploy

## 1. Install dependencies

```bash
cd /opt/pricebot
./venv/bin/pip install -r requirements.txt
```

## 2. PostgreSQL production mode

Set a real PostgreSQL URL:

```bash
export DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/pricebot'
export PRICEBOT_REQUIRE_POSTGRES_PRODUCTION=1
export PRICEBOT_PRODUCTION_MODE=1
```

Migrate the existing SQLite DB once:

```bash
./venv/bin/python tools/migrate_sqlite_to_postgres.py \
  --sqlite /opt/pricebot/pricebot.db \
  --postgres-dsn "$DATABASE_URL"
```

## 3. Rebuild from Excel locally/test

```bash
./venv/bin/python tools/rebuild_database_from_any_excel.py \
  --excel products_master_ready.xlsx \
  --db-path /tmp/pricebot_test.db
```

## 4. Acceptance tests

```bash
./venv/bin/python tools/run_acceptance_tests.py --db-path /tmp/pricebot_test.db
PRICEBOT_DB_PATH=/tmp/pricebot_test.db ./venv/bin/python tests/acceptance_safe_matching.py
```

## 5. Smart Upsert import

```bash
./venv/bin/python tools/import_master_excel.py \
  --excel-path /path/to/new_products.xlsx \
  --db-path /opt/pricebot/pricebot.db
```

When `DATABASE_URL` is set to PostgreSQL, runtime connections use PostgreSQL instead of SQLite.
