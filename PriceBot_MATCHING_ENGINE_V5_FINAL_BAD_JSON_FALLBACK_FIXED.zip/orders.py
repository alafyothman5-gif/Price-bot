from typing import Dict, List

import config_env
import database
from normalizer import safe_price, normalize_text
from services.whatsapp.result_formatter import display_label, product_display_name, CATEGORY_LABELS as CUSTOMER_CATEGORY_LABELS, FORM_LABELS as CUSTOMER_FORM_LABELS, list_row_description

CATEGORY_LABELS = {**CUSTOMER_CATEGORY_LABELS, "مكملات": "مكملات غذائية"}
FORM_LABELS = {**CUSTOMER_FORM_LABELS, "skincare_cream": "كريم"}

def _display_label(value: object, labels: Dict[str, str]) -> str:
    return display_label(value, labels)


def format_product_line(i: int, product: Dict) -> str:
    desc = list_row_description(product, include_price=False)
    suffix = f" — {desc}" if desc and desc != "اضغط لعرض التفاصيل" else ""
    return f"{i}. {product_display_name(product)}{suffix}"


def format_product_list(products: List[Dict], page: int = 0, page_size: int = 10) -> str:
    if not products:
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار."
    start = page * page_size
    chunk = products[start:start + page_size]
    lines = ["منتجات متوفرة:", ""]
    for i, p in enumerate(chunk, 1):
        lines.append(format_product_line(i, p))
    lines.append("")
    lines.append("اختر المنتج من القائمة التفاعلية لعرض التفاصيل.")
    lines.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(lines)


def format_product_details(product: Dict) -> str:
    price = safe_price(product.get("price"))
    currency = (product.get("currency") or "د.ل").replace("LYD", "د.ل")
    name = product_display_name(product)
    category = _display_label(product.get("main_section") or product.get("section") or product.get("category") or "", CATEGORY_LABELS)
    form = _display_label(product.get("form") or product.get("medicine_form") or product.get("product_type") or "", FORM_LABELS)
    strength = product.get("strength") or ""
    size = product.get("size") or ""
    measure = " / ".join(x for x in [strength, size] if str(x).strip())
    details = [
        "✅ المنتج متوفر",
        "",
        f"📦 الاسم: {name}",
        f"💵 السعر: {price} {currency}",
    ]
    if category:
        details.append(f"🏷️ التصنيف: {category}")
    if form:
        details.append(f"💊 الشكل: {form}")
    if measure:
        details.append(f"📏 التركيز/الحجم: {measure}")
    details.append("")
    details.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(details)


def create_order(phone: str, product: Dict, quantity: int) -> int:
    return database.create_order(phone, product, quantity)


def format_my_orders(phone: str) -> str:
    rows = database.recent_orders_for_phone(phone, limit=5)
    if not rows:
        return "لا توجد طلبات مسجلة لك حاليًا."
    lines = ["آخر طلباتك:"]
    for r in rows:
        lines.append(f"#{r['id']} - {r['product_name']} - الكمية {r['quantity']} - الحالة: {r['status']}")
    return "\n".join(lines)
