from __future__ import annotations

"""Webhook route facade for the V4 clean architecture target.

The production app keeps the legacy app.py endpoint for backward compatibility,
but new deployments can move webhook registration here without changing service
logic. Business processing belongs in services/ and tasks/; routes only parse,
verify, and enqueue.
"""

from fastapi import APIRouter

router = APIRouter(prefix="/routes")


@router.get("/architecture/whatsapp")
def whatsapp_architecture():
    return {"ok": True, "route_layer": "routes.whatsapp", "processing_layer": "services + celery tasks"}
