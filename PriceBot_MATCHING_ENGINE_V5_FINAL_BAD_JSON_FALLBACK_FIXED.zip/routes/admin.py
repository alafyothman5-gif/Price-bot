from __future__ import annotations

"""Admin route facade marker for V4 clean architecture."""

from fastapi import APIRouter

router = APIRouter(prefix="/routes")


@router.get("/architecture/admin")
def admin_architecture():
    return {"ok": True, "route_layer": "routes.admin", "templates": "Jinja2", "security": "RBAC + CSRF + audit"}
