from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

import database

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _pending_orders_count() -> int:
    try:
        return len(database.list_orders("pending", 5000))
    except Exception:
        return 0


def _learning_pending_count() -> int:
    try:
        return len(database.list_learning_inbox("pending", 5000))
    except Exception:
        return 0


@router.get("/", response_class=HTMLResponse)
@router.get("/portal", response_class=HTMLResponse)
def unified_portal(request: Request):
    return templates.TemplateResponse(
        "portal.html",
        {
            "request": request,
            "title": "PriceBot Portal",
            "products_count": database.count_products(),
            "pending_orders": _pending_orders_count(),
            "learning_pending": _learning_pending_count(),
        },
    )
