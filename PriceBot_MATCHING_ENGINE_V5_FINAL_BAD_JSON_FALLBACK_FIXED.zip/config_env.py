"""Environment compatibility helpers for PriceBot.

Keeps legacy .env names working without exposing secret values in logs.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None

FALSE_VALUES = {"0", "false", "no", "off", "disabled", "disable"}
TRUE_VALUES = {"1", "true", "yes", "on", "enabled", "enable"}


def load_environment() -> None:
    """Load .env from the project directory or /opt/pricebot_clean if present."""
    if load_dotenv is None:
        return
    here = Path(__file__).resolve().parent
    for path in [here / ".env", Path("/opt/pricebot_clean/.env"), Path("/opt/pricebot/.env")]:
        try:
            if path.exists():
                load_dotenv(path, override=False)
                break
        except Exception:
            continue
    apply_openrouter_aliases()


def first_nonempty(names: Iterable[str], default: str = "") -> str:
    for name in names:
        value = str(os.getenv(name, "") or "").strip()
        if value:
            return value
    return default


def first_key_from(value: str) -> str:
    for part in str(value or "").replace(";", ",").split(","):
        key = part.strip().strip('"').strip("'")
        if key:
            return key
    return ""


def resolve_openrouter_api_key() -> str:
    direct = first_nonempty(["OPENROUTER_API_KEY"])
    if direct:
        return first_key_from(direct)
    return first_key_from(first_nonempty([
        "AI_OPENROUTER_KEYS",
        "AI_OPENROUTER_KEY",
        "OPENROUTER_KEYS",
        "OPENROUTER_KEY",
    ]))


def apply_openrouter_aliases() -> None:
    key = resolve_openrouter_api_key()
    if key and not os.getenv("OPENROUTER_API_KEY"):
        os.environ["OPENROUTER_API_KEY"] = key
    if not os.getenv("OPENROUTER_MODEL"):
        model = first_nonempty(["AI_OPENROUTER_MODEL"], "google/gemini-2.5-flash-lite")
        os.environ["OPENROUTER_MODEL"] = model
    if not os.getenv("OPENROUTER_BASE_URL"):
        base = first_nonempty(["AI_OPENROUTER_BASE_URL"], "https://openrouter.ai/api/v1")
        os.environ["OPENROUTER_BASE_URL"] = base.rstrip("/")


def env_false(name: str) -> bool:
    return str(os.getenv(name, "") or "").strip().lower() in FALSE_VALUES


def env_true(name: str, default: bool = False) -> bool:
    value = str(os.getenv(name, "") or "").strip().lower()
    if not value:
        return default
    if value in TRUE_VALUES:
        return True
    if value in FALSE_VALUES:
        return False
    return default


def booking_enabled() -> bool:
    # Booking/reservation is intentionally disabled by default for this release.
    if env_false("BOOKING_ENABLED") or env_false("RESERVATION_ENABLED"):
        return False
    return env_true("BOOKING_ENABLED", False) or env_true("RESERVATION_ENABLED", False)


def vision_enabled() -> bool:
    """Vision is enabled when an OpenRouter key exists unless explicitly disabled."""
    apply_openrouter_aliases()
    if not resolve_openrouter_api_key():
        return False
    for flag in ["AI_ENABLED", "VISION_ENABLED", "IMAGE_ENABLED", "OCR_ENABLED", "ENABLE_IMAGE_SEARCH"]:
        if env_false(flag):
            return False
    return True


def vision_disabled_reason() -> str:
    apply_openrouter_aliases()
    if not resolve_openrouter_api_key():
        return "missing_openrouter_api_key"
    for flag in ["AI_ENABLED", "VISION_ENABLED", "IMAGE_ENABLED", "OCR_ENABLED", "ENABLE_IMAGE_SEARCH"]:
        if env_false(flag):
            return f"{flag.lower()}_false"
    return ""
