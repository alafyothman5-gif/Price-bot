# Excel Native Rebuild

This release uses Excel Native as the single catalog build path.

## Build a fresh DB manually

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/rebuild_database_from_any_excel.py   --excel /opt/pricebot_clean/products_master_ready.xlsx   --db-path /opt/pricebot_clean/pricebot_new.db   --report /opt/pricebot_clean/backups/excel_native_report.json
```

## Test the new DB before swapping

```bash
cd /opt/pricebot_clean
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot_clean/pricebot_new.db
```

## Safe rebuild and swap

```bash
cd /opt/pricebot_clean
PRICEBOT_TARGET_DIR=/opt/pricebot_clean PRICEBOT_SERVICE_NAME=pricebot.service   ./tools/install_excel_native_rebuild.sh /opt/pricebot_clean/products_master_ready.xlsx
```

`PRICEBOT_TARGET_DIR` defaults to the project directory containing the script, so the same script also works in test directories.
