from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Dict, Optional

try:  # optional dependency
    import redis.asyncio as redis_async  # type: ignore
except Exception:  # pragma: no cover
    redis_async = None


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _json_loads(value: Any) -> Optional[Dict[str, Any]]:
    if value is None:
        return None
    if isinstance(value, bytes):
        value = value.decode("utf-8", "ignore")
    try:
        data = json.loads(str(value))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


class RuntimeState:
    """Runtime state with Redis support and safe in-memory fallback.

    Redis is used when REDIS_URL is configured. This makes user modes and
    confirmations survive process restarts and enables multiple uvicorn workers
    or horizontal instances to share the same conversation state.
    """

    def __init__(self, namespace: str = "pricebot", mode_ttl: int = 7200, confirmation_ttl: int = 900, lock_ttl: int = 35) -> None:
        self.namespace = namespace.strip() or "pricebot"
        self.mode_ttl = int(mode_ttl or 7200)
        self.confirmation_ttl = int(confirmation_ttl or 900)
        self.lock_ttl = int(lock_ttl or 35)
        self.redis_url = os.getenv("REDIS_URL", "").strip()
        self.redis = None
        self.enabled = False
        self._memory: Dict[str, tuple[float, Any]] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._last_cleanup = 0.0

    async def connect(self) -> None:
        if self.redis_url and redis_async is not None:
            self.redis = redis_async.from_url(self.redis_url, decode_responses=True)
            try:
                await self.redis.ping()
                self.enabled = True
                return
            except Exception:
                self.redis = None
                self.enabled = False
        self.enabled = False

    async def close(self) -> None:
        if self.redis is not None:
            try:
                await self.redis.aclose()
            except Exception:
                pass

    def key(self, suffix: str) -> str:
        return f"{self.namespace}:{suffix}"

    async def get_json(self, suffix: str) -> Optional[Dict[str, Any]]:
        key = self.key(suffix)
        if self.redis is not None:
            return _json_loads(await self.redis.get(key))
        item = self._memory.get(key)
        if not item:
            return None
        expires, value = item
        if expires and expires < time.time():
            self._memory.pop(key, None)
            return None
        return value if isinstance(value, dict) else None

    async def set_json(self, suffix: str, value: Dict[str, Any], ttl: int) -> None:
        key = self.key(suffix)
        ttl = max(1, int(ttl or 60))
        if self.redis is not None:
            await self.redis.set(key, _json_dumps(value), ex=ttl)
            return
        self._memory[key] = (time.time() + ttl, dict(value))

    async def delete(self, suffix: str) -> None:
        key = self.key(suffix)
        if self.redis is not None:
            await self.redis.delete(key)
            return
        self._memory.pop(key, None)

    async def get_mode(self, phone: str) -> str:
        data = await self.get_json(f"mode:{phone}")
        return str((data or {}).get("mode") or "idle")

    async def set_mode(self, phone: str, mode: str) -> None:
        await self.set_json(f"mode:{phone}", {"mode": str(mode or "idle"), "ts": time.time()}, self.mode_ttl)

    async def get_confirmation(self, phone: str) -> Optional[Dict[str, Any]]:
        return await self.get_json(f"confirm:{phone}")

    async def set_confirmation(self, phone: str, data: Dict[str, Any]) -> None:
        payload = dict(data or {})
        payload["ts"] = time.time()
        await self.set_json(f"confirm:{phone}", payload, self.confirmation_ttl)

    async def clear_confirmation(self, phone: str) -> None:
        await self.delete(f"confirm:{phone}")

    async def cleanup_memory(self) -> None:
        if self.redis is not None:
            return
        now = time.time()
        if now - self._last_cleanup < 60:
            return
        self._last_cleanup = now
        expired = [k for k, (exp, _v) in self._memory.items() if exp and exp < now]
        for key in expired:
            self._memory.pop(key, None)

    @asynccontextmanager
    async def user_lock(self, phone: str) -> AsyncIterator[None]:
        """Cross-process Redis lock when available; per-process fallback otherwise."""
        phone = str(phone or "unknown")
        if self.redis is not None:
            lock = self.redis.lock(self.key(f"lock:{phone}"), timeout=self.lock_ttl, blocking_timeout=8)
            acquired = False
            try:
                acquired = await lock.acquire()
                yield
            finally:
                if acquired:
                    try:
                        await lock.release()
                    except Exception:
                        pass
            return

        lock = self._locks.setdefault(phone, asyncio.Lock())
        async with lock:
            yield


class TtlRateLimiter:
    """In-memory TTL rate limiter with periodic cleanup, not per-request sweeping."""

    def __init__(self, window_seconds: int, default_limit: int) -> None:
        from collections import deque
        self.deque_type = deque
        self.window_seconds = int(window_seconds or 60)
        self.default_limit = int(default_limit or 60)
        self.buckets: Dict[str, Any] = {}

    def allow(self, key: str, limit: Optional[int] = None) -> bool:
        now = time.time()
        limit = int(limit or self.default_limit)
        bucket = self.buckets.get(key)
        if bucket is None:
            bucket = self.deque_type()
            self.buckets[key] = bucket
        cutoff = now - self.window_seconds
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= limit:
            return False
        bucket.append(now)
        return True

    def cleanup(self) -> None:
        now = time.time()
        cutoff = now - self.window_seconds
        empty = []
        for key, bucket in self.buckets.items():
            while bucket and bucket[0] < cutoff:
                bucket.popleft()
            if not bucket:
                empty.append(key)
        for key in empty:
            self.buckets.pop(key, None)
