# PriceBot V20 Market Ready — تشغيل مختصر

هذه النسخة تعمل فوق قاعدة المنتجات الحالية ولا تحتاج إعادة رفع Excel.

## مكان المشروع
ضع ملفات المشروع داخل:

```bash
/opt/pricebot
```

لا تلمس `/opt/medmcq` ولا أي خدمة Telegram.

## ملف البيئة
انسخ المثال مرة واحدة فقط إذا لم يكن لديك `.env`:

```bash
cp .env.example .env
nano .env
```

املأ القيم الحقيقية بدون رفعها إلى GitHub:

- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `META_VERIFY_TOKEN`
- `META_APP_SECRET`
- `OPENROUTER_API_KEY`
- `ADMIN_PASSWORD`
- `ADMIN_SESSION_SECRET`

بوابة التاجر لا تعمل في الإنتاج إلا إذا ضبطت:

```env
MERCHANT_PORTAL_ENABLED=true
MERCHANT_LOGIN_CODE=كود_خاص_غير_merchant
MERCHANT_SESSION_SECRET=قيمة_عشوائية_طويلة
```

## Guided Finder / القوائم التفاعلية
V20 يحاول إرسال WhatsApp interactive lists/buttons عند القوائم. إذا فشل الإرسال أو لم تكن الميزة متاحة، يرجع تلقائيًا إلى نص مرقم.

```env
PRICEBOT_WHATSAPP_INTERACTIVE_ENABLED=true
GUIDED_FINDER_TTL_SECONDS=900
```

## النشر بأمر واحد
من داخل `/opt/pricebot`:

```bash
chmod +x deploy_pricebot_v20.sh rollback_pricebot.sh backup_pricebot.sh smoke_test_pricebot.sh
./deploy_pricebot_v20.sh
```

السكريبت يحافظ على `.env` و `pricebot.db`، يعمل backup، يشغل الاختبارات، يشغل migration آمن، ثم يعيد تشغيل الخدمة.

## الفحص

```bash
curl -fsS http://127.0.0.1:8000/health
journalctl -u pricebot -n 100 --no-pager
```

الـ health يجب أن يرجع فقط:

```json
{"ok":true,"service":"pricebot"}
```

## الرجوع لنسخة سابقة

```bash
./rollback_pricebot.sh
```

الرجوع لا يستبدل `.env` أو `pricebot.db` إلا إذا اخترت ذلك صراحة.

## رفع المنتجات
استخدم لوحة الأدمن أو التاجر. V20 لا يعمل `replace_all` تلقائيًا ولا يحذف المنتجات الحالية.

## كلمات عامة
الكلمات مثل `غسول` و `كريم` و `Cerave` تدخل Guided Finder ولا تعرض سعرًا حتى يحدد الزبون النوع والاستخدام.
