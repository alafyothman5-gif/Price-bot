# PriceBot V19.3 Guided Finder Safe Ready

هذه نسخة تضيف Guided Shopping / Interactive Product Finder فوق محرك V18/V19 الحالي بدون إعادة كتابة Matching أو Vision.

## ما تغير

- إضافة `services/guided_finder.py`.
- إدخال الكلمات العامة مثل `غسول` و`كريم` و`Cerave` في رحلة اختيار تفاعلية بدل البحث الحر المباشر.
- حفظ حالة الرحلة في `conversation_state`:
  - `current_flow`
  - `selected_category`
  - `selected_product_type`
  - `selected_skin_type`
  - `selected_use_case`
  - `last_options`
- دعم اختيار الأرقام من آخر قائمة.
- إضافة دعم قراءة ردود WhatsApp interactive list/buttons الواردة.
- إضافة helper اختياري لإرسال WhatsApp List Messages.
- تشديد بدائل صور الكوزمتك: إذا لا توجد معلومات skin/use كافية لا يتم عرض بدائل ضعيفة، بل يسأل البوت سؤالًا توضيحيًا.
- تمرير `skin_type/use_case/body_area` من Vision إلى matcher عندما تكون الصورة فيها هوية منتج واضحة.

## كيف تمنع البدائل الخاطئة

البديل الكوزمتك لا يظهر في Guided Finder إلا إذا طابق:

- نفس `category = cosmetic`
- نفس `form/type`
- نفس `body_area`
- نفس أو compatible `skin_type`
- نفس أو compatible `use_case`

ممنوع:

- face cleanser → body wash
- face cleanser → baby wash
- oily skin → dry skin
- dry skin → oily/acne cleanser
- shampoo → cleanser
- serum → lotion
- cream → cleanser

## ما لم يتغير

- لم تتم إعادة كتابة Matching/Vision.
- لا توجد بدائل دوائية تلقائية.
- لا يوجد سعر عند الغموض.
- قواعد V18/V19/V19.1 بقيت كما هي.

## الاختبارات

أضيف:

```bash
python acceptance_tests_final_v19_3_guided_finder.py
```

ويجب أن تنجح معه كل اختبارات V17/V18/V19/V19.1 السابقة.
