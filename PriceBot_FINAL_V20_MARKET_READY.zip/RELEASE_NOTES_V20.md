# Release Notes — PriceBot V20 Market Ready

## الهدف
V20 هي نسخة سوق مستقرة مبنية فوق V19.3، مع الحفاظ على Matching/Vision المحافظ وعدم إعادة كتابة المحرك.

## أهم التحسينات

- تفعيل Guided Finder النهائي للكلمات العامة.
- دعم WhatsApp interactive reply buttons/list messages مع fallback نصي مرقم.
- منع الكلمات العامة من البحث الحر:
  - غسول
  - كريم
  - لوشن
  - سيروم
  - مرطب
  - واقي شمس
  - شامبو
  - Cerave / Rilastil / Bioderma / La Roche / Eucerin
- تشديد Cosmetic Alternative Safety:
  - نفس النوع
  - نفس منطقة الاستخدام
  - نفس أو compatible نوع البشرة
  - نفس أو compatible use_case
- إضافة exact-only protection:
  - المنتجات الناقصة يمكن أن تطابق الاسم الكامل أو alias الدقيق فقط.
  - لا تظهر في fuzzy أو البدائل أو Guided alternatives.
- تحسين رد المنتج المتوفر بصيغة أوضح للزبون.
- إضافة `services/whatsapp_interactive.py`.
- إضافة `acceptance_tests_final_v20.py`.
- إضافة `deploy_pricebot_v20.sh`.

## ما لم يتغير

- لم يتم إعادة كتابة Matching/Vision.
- لا يوجد legacy fuzzy fallback.
- لا توجد بدائل دوائية تلقائية.
- لا يوجد سعر عند الغموض.
- لا يتم حذف المنتجات الحالية.
- لا يتم رفع `.env` أو `pricebot.db`.
- لم يتم لمس MedMCQ.

## قيود مهمة

- WhatsApp Product Lists الحقيقية تحتاج Meta Commerce Catalog وربط retailer IDs؛ لذلك V20 يدعم lists/buttons العادية مع fallback نصي، ولا يدّعي تفعيل Product Catalog messages بالكامل.
- جودة البدائل تعتمد على جودة أعمدة الكتالوج مثل `form`, `skin_type`, `use_case`, `body_area`. المنتجات الناقصة يجب تعليمها كـ `exact_only` أو تصحيحها من لوحة المراجعة.

## الاختبارات

نجحت اختبارات V17/V18/V19/V19.1/V19.3 واختبار V20 الجديد.
