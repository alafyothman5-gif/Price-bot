# -*- coding: utf-8 -*-
"""WhatsApp interactive message helpers for PriceBot V20.

These helpers are optional: if Meta rejects an interactive message or the
credentials/client are not configured, callers fall back to numbered text.
No secrets are logged here.
"""
from __future__ import annotations

import os
from typing import Any, Callable, Dict, List, Sequence

GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
INTERACTIVE_ENABLED = os.getenv("PRICEBOT_WHATSAPP_INTERACTIVE_ENABLED", "true").lower() in {"1", "true", "yes", "on"}


def _label(option: dict, fallback: str) -> str:
    return str(option.get("label") or option.get("name") or option.get("title") or option.get("id") or fallback).strip()


def numbered_text(body: str, options: Sequence[dict] | None = None) -> str:
    if not options:
        return str(body or "").strip()
    lines = [str(body or "").strip(), ""]
    for i, opt in enumerate(options, 1):
        lines.append(f"{i}. {_label(opt, f'اختيار {i}')}")
    lines.append("")
    lines.append("اكتب رقم الاختيار.")
    return "\n".join(lines).strip()


def build_reply_buttons_payload(to_number: str, body: str, options: Sequence[dict]) -> Dict[str, Any]:
    buttons = []
    for i, opt in enumerate((options or [])[:3], 1):
        buttons.append({
            "type": "reply",
            "reply": {
                "id": str(opt.get("id") or i)[:256],
                "title": _label(opt, f"اختيار {i}")[:20],
            },
        })
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "button",
            "body": {"text": str(body or "")[:1024]},
            "action": {"buttons": buttons},
        },
    }


def build_list_message_payload(to_number: str, body: str, options: Sequence[dict], button_text: str = "اختر") -> Dict[str, Any]:
    rows = []
    for i, opt in enumerate((options or [])[:10], 1):
        rows.append({
            "id": str(opt.get("id") or i)[:200],
            "title": _label(opt, f"اختيار {i}")[:24],
            "description": str(opt.get("description") or "")[:72],
        })
    return {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "interactive",
        "interactive": {
            "type": "list",
            "body": {"text": str(body or "")[:1024]},
            "action": {
                "button": str(button_text or "اختر")[:20],
                "sections": [{"title": "الخيارات", "rows": rows}],
            },
        },
    }


def build_product_list_if_available(to_number: str, body: str, products: Sequence[dict]) -> Dict[str, Any] | None:
    """Placeholder for future Meta Catalog product lists.

    Cloud API product messages require a Meta commerce catalog id and retailer
    ids. PriceBot does not assume those values, so V20 uses list/buttons with a
    numbered fallback instead of pretending product lists are fully enabled.
    """
    return None


async def send_interactive_or_text(
    *,
    http_client: Any,
    access_token: str,
    phone_number_id: str,
    to_number: str,
    text: str,
    options: Sequence[dict] | None = None,
    log_event: Callable[..., None] | None = None,
) -> bool:
    async def log(name: str, **kw: Any) -> None:
        if log_event:
            try:
                log_event(name, **kw)
            except Exception:
                pass

    if not options or not INTERACTIVE_ENABLED or not http_client or not access_token or not phone_number_id:
        await log("WHATSAPP_INTERACTIVE_FALLBACK", reason="not_available")
        return False

    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    payload = build_reply_buttons_payload(to_number, text, options) if len(options) <= 3 else build_list_message_payload(to_number, text, options)
    try:
        response = await http_client.post(url, json=payload, headers=headers, timeout=10.0)
        if 200 <= response.status_code < 300:
            await log("WHATSAPP_INTERACTIVE_SEND_OK", status=response.status_code)
            return True
        await log("WHATSAPP_INTERACTIVE_SEND_ERROR", status=response.status_code, response=str(getattr(response, "text", ""))[:240])
        return False
    except Exception as exc:
        await log("WHATSAPP_INTERACTIVE_SEND_EXCEPTION", error=repr(exc))
        return False
