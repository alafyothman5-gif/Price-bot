#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final V20 Market Ready acceptance tests."""
from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path

TMP_DIR = tempfile.mkdtemp(prefix="pricebot_v20_")
os.environ["PRICEBOT_DB_FILE"] = str(Path(TMP_DIR) / "acceptance_v20.db")
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["PRICEBOT_DEBUG_ENDPOINTS"] = "false"
os.environ["PRICEBOT_ENV"] = "production"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-v20-code"
os.environ["MERCHANT_PORTAL_ENABLED"] = "true"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"
os.environ["PRICEBOT_WHATSAPP_INTERACTIVE_ENABLED"] = "true"

import database  # noqa: E402
import matcher  # noqa: E402
import matcher_v4  # noqa: E402
from matcher_v2 import DecisionType  # noqa: E402
from services import guided_finder, whatsapp_interactive  # noqa: E402

CATALOG = [
    {"product_id":"P1","name":"Photoblok 50+","brand":"Photoblok","product_family":"Photoblok 50+","category":"cosmetic","form":"sunscreen","body_area":"face","use_case":"sun_protection","skin_type":"normal_combination_skin","size":"50ml","aliases":"Photoblok 50+","ocr_keywords":"photoblok 50 spf sunscreen face","price":"70","available":"متوفر"},
    {"product_id":"P2","name":"123 Extra","brand":"123","product_family":"Extra","category":"medicine","form":"tablet","strength":"","size":"","aliases":"123, Extra 1,2,3, 1 2 3 Extra","ocr_keywords":"123 extra","price":"15","available":"متوفر"},
    {"product_id":"C1","name":"CeraVe Hydrating Cleanser 236ml","brand":"CeraVe","product_family":"Hydrating Cleanser","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"236ml","aliases":"cerave hydrating cleanser","ocr_keywords":"cerave hydrating cleanser dry skin face wash","price":"70","available":"متوفر"},
    {"product_id":"C2","name":"Bioderma Sebium Gel Moussant 200ml","brand":"Bioderma","product_family":"Sebium Gel Moussant","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"200ml","aliases":"bioderma sebium gel moussant","ocr_keywords":"bioderma sebium cleanser oily skin acne face wash","price":"65","available":"متوفر"},
    {"product_id":"C3","name":"La Roche Posay Effaclar Gel Cleanser 200ml","brand":"La Roche Posay","product_family":"Effaclar Gel","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"normal_oily_skin","size":"200ml","aliases":"laroche effaclar gel cleanser","ocr_keywords":"effaclar gel cleanser normal oily acne face wash","price":"75","available":"متوفر"},
    {"product_id":"C4","name":"Baby Gentle Wash 250ml","brand":"BabyBrand","product_family":"Gentle Wash","category":"cosmetic","form":"cleanser","body_area":"baby","use_case":"baby_care","skin_type":"sensitive_skin","size":"250ml","aliases":"baby wash","ocr_keywords":"baby wash kids","price":"20","available":"متوفر"},
    {"product_id":"C5","name":"Body Wash Rose 500ml","brand":"BodyBrand","product_family":"Rose Body Wash","category":"cosmetic","form":"cleanser","body_area":"body","use_case":"body_care","skin_type":"","size":"500ml","aliases":"body wash","ocr_keywords":"body wash shower gel","price":"25","available":"متوفر"},
    {"product_id":"C6","name":"CeraVe Moisturizing Cream 454g","brand":"CeraVe","product_family":"Moisturizing Cream","category":"cosmetic","form":"cream","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"454g","aliases":"cerave moisturizing cream","ocr_keywords":"cerave moisturizing cream dry skin","price":"90","available":"متوفر"},
    {"product_id":"X1","name":"ExactOnly Rare Cosmetic Ampoule 30ml","brand":"RareBrand","product_family":"Rare Ampoule","category":"cosmetic","form":"serum","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"30ml","aliases":"ExactOnly Rare Cosmetic Ampoule 30ml","ocr_keywords":"rare ampoule","price":"110","available":"متوفر","quality_status":"exact_only","search_mode":"exact_only"},
]


def seed_catalog() -> None:
    database.init_db()
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        for p in CATALOG:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,product_family,category,form,body_area,use_case,skin_type,size,aliases,ocr_keywords,image_ocr_keywords,price,available,quality_status,search_mode)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p.get("product_id"), p["name"], p["name"].lower(), p.get("brand",""), p.get("product_family",""), p.get("category",""), p.get("form",""), p.get("body_area",""), p.get("use_case",""), p.get("skin_type",""), p.get("size",""), p.get("aliases",""), p.get("ocr_keywords",""), p.get("ocr_keywords",""), p.get("price",""), p.get("available",""), p.get("quality_status",""), p.get("search_mode","")),
            )
        conn.commit()
    matcher.invalidate_product_cache()


def ask(phone: str, text: str):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))


def assert_fast_exact(query: str, expected: str) -> None:
    started = time.perf_counter()
    r = ask(f"phone_{expected}", query)
    elapsed = time.perf_counter() - started
    assert elapsed < 2.0, f"exact lookup too slow: {elapsed:.3f}s"
    assert r.decision in {"matched", "matched_unknown_availability"}, r.reply
    assert expected.lower() in r.reply.lower(), r.reply
    assert "السعر" in r.reply and "د.ل" in r.reply, r.reply


def test_exact_fast_path_full_names_and_aliases():
    assert_fast_exact("Photoblok 50+", "Photoblok")
    assert_fast_exact("123", "123")
    assert_fast_exact("Extra 1,2,3", "123")


def test_generic_words_enter_guided_finder_without_price():
    for text in ["غسول", "كريم", "لوشن", "سيروم", "مرطب", "واقي شمس", "شامبو"]:
        r = ask("generic_" + text, text)
        assert r.decision.startswith("guided"), (text, r.decision, r.reply)
        assert "السعر" not in r.reply and " د.ل" not in r.reply, r.reply


def test_face_cleanser_flow_and_oily_filters():
    r1 = ask("flow_face", "غسول وجه")
    assert r1.decision == "guided_ask_skin_type"
    assert "نوع البشرة" in r1.reply and "السعر" not in r1.reply
    r2 = ask("flow_oily", "غسول للبشرة الدهنية")
    assert r2.decision == "guided_products", r2.reply
    assert "Bioderma Sebium" in r2.reply or "Effaclar" in r2.reply
    assert "Hydrating Cleanser" not in r2.reply
    assert "Body Wash" not in r2.reply
    assert "Baby Gentle" not in r2.reply


def test_brand_only_enter_guided_finder_no_price():
    for brand in ["Cerave", "Rilastil", "Bioderma", "La Roche", "Eucerin"]:
        r = ask("brand_" + brand, brand)
        assert r.decision == "guided_brand_type", (brand, r.decision, r.reply)
        assert "أي نوع" in r.reply
        assert "السعر" not in r.reply and " د.ل" not in r.reply


def test_cosmetic_alternative_safety_normal_oily_and_dry_do_not_cross():
    ci = matcher_v4.build_catalog_index(CATALOG)
    oily_decision = matcher_v4.resolve_image_extraction_from_index({
        "image_type": "product_packaging", "clarity": "good", "confidence": 0.95,
        "brand": "CeraVe", "product_name": "Foaming Facial Cleanser", "form": "cleanser",
        "skin_type": "normal oily skin", "use_case": "acne", "body_area": "face", "size": "236ml",
    }, ci)
    assert oily_decision.decision_type in {DecisionType.COSMETIC_ALTERNATIVES, DecisionType.NOT_AVAILABLE}
    for alt in oily_decision.alternatives or []:
        assert "Hydrating Cleanser" not in alt.get("name", "")
        assert alt.get("body_area", "face") == "face"
        assert alt.get("form") == "cleanser"
        assert alt.get("skin_type") in {"oily_skin", "normal_oily_skin", ""}

    dry_decision = matcher_v4.resolve_image_extraction_from_index({
        "image_type": "product_packaging", "clarity": "good", "confidence": 0.95,
        "brand": "CeraVe", "product_name": "Hydrating Cleanser", "form": "cleanser",
        "skin_type": "dry skin", "use_case": "hydration", "body_area": "face", "size": "500ml",
    }, ci)
    assert dry_decision.decision_type in {DecisionType.EXACT_MATCH, DecisionType.COSMETIC_ALTERNATIVES, DecisionType.NOT_AVAILABLE}
    for alt in dry_decision.alternatives or []:
        assert "Sebium" not in alt.get("name", "") and "Effaclar" not in alt.get("name", "")
        assert alt.get("skin_type") in {"dry_skin", "dry_sensitive_skin", ""}


def test_exact_only_never_appears_in_guided_or_non_exact_matching():
    guided = guided_finder.filter_products_by_guided_slots({"selected_product_type":"serum", "form":"serum", "body_area":"face", "selected_skin_type":"dry_skin", "selected_use_case":"hydration"}, CATALOG)
    assert all("ExactOnly" not in p.get("name", "") for p in guided)
    ci = matcher_v4.build_catalog_index(CATALOG)
    fuzzy = matcher_v4.resolve_product_query_from_index("RareBrand serum", ci)
    assert fuzzy.decision_type != DecisionType.EXACT_MATCH
    exact = matcher_v4.resolve_product_query_from_index("ExactOnly Rare Cosmetic Ampoule 30ml", ci)
    assert exact.decision_type == DecisionType.EXACT_MATCH


def test_numeric_selection_uses_last_guided_options():
    first = ask("select_v20", "غسول للبشرة الدهنية")
    assert first.decision == "guided_products"
    second = ask("select_v20", "1")
    assert second.decision == "guided_product_selected"
    assert "السعر" in second.reply


def test_invalid_vision_output_rejected():
    ci = matcher_v4.build_catalog_index(CATALOG)
    d = matcher_v4.resolve_image_extraction_from_index({
        "image_type": "product_packaging", "clarity": "good", "confidence": 0.95,
        "brand": "CeraVe", "product_name": "Hydrating Cleanser", "price": "50", "availability": "available",
    }, ci)
    assert d.decision_type == DecisionType.LOW_CONFIDENCE


def test_interactive_payloads_and_fallback_text_exist():
    opts = [{"id":"a", "label":"غسول وجه"}, {"id":"b", "label":"غسول جسم"}, {"id":"c", "label":"غسول أطفال"}, {"id":"d", "label":"غسول طبي"}]
    payload = whatsapp_interactive.build_list_message_payload("21891xxxx", "اختر نوع الغسول", opts)
    assert payload["type"] == "interactive"
    assert payload["interactive"]["type"] == "list"
    txt = whatsapp_interactive.numbered_text("اختر نوع الغسول", opts)
    assert "1. غسول وجه" in txt and "4. غسول طبي" in txt


def main():
    seed_catalog()
    test_exact_fast_path_full_names_and_aliases()
    test_generic_words_enter_guided_finder_without_price()
    test_face_cleanser_flow_and_oily_filters()
    test_brand_only_enter_guided_finder_no_price()
    test_cosmetic_alternative_safety_normal_oily_and_dry_do_not_cross()
    test_exact_only_never_appears_in_guided_or_non_exact_matching()
    test_numeric_selection_uses_last_guided_options()
    test_invalid_vision_output_rejected()
    test_interactive_payloads_and_fallback_text_exist()
    print("ACCEPTANCE_TESTS_FINAL_V20_OK")


if __name__ == "__main__":
    main()
