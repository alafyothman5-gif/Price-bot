#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final V19.3 Guided Finder acceptance tests."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

TMP_DIR = tempfile.mkdtemp(prefix="pricebot_v19_3_guided_")
os.environ["PRICEBOT_DB_FILE"] = str(Path(TMP_DIR) / "acceptance_v19_3.db")
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["PRICEBOT_DEBUG_ENDPOINTS"] = "false"
os.environ["PRICEBOT_ENV"] = "production"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-v19-3-code"
os.environ["MERCHANT_PORTAL_ENABLED"] = "true"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"

import database  # noqa: E402
import matcher  # noqa: E402
import matcher_v4  # noqa: E402
from matcher_v2 import DecisionType  # noqa: E402
from services import guided_finder  # noqa: E402

CATALOG = [
    {"product_id":"C1","name":"CeraVe Hydrating Cleanser 236ml","brand":"CeraVe","product_family":"Hydrating Cleanser","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"236ml","aliases":"cerave hydrating cleanser","ocr_keywords":"cerave hydrating cleanser dry skin face wash","price":"70","available":"متوفر"},
    {"product_id":"C2","name":"Bioderma Sebium Gel Moussant 200ml","brand":"Bioderma","product_family":"Sebium Gel Moussant","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"200ml","aliases":"bioderma sebium gel moussant","ocr_keywords":"bioderma sebium cleanser oily skin acne face wash","price":"65","available":"متوفر"},
    {"product_id":"C3","name":"La Roche Posay Effaclar Gel Cleanser 200ml","brand":"La Roche Posay","product_family":"Effaclar Gel","category":"cosmetic","form":"cleanser","body_area":"face","use_case":"acne","skin_type":"oily_skin","size":"200ml","aliases":"laroche effaclar gel cleanser","ocr_keywords":"effaclar gel cleanser oily acne face wash","price":"75","available":"متوفر"},
    {"product_id":"C4","name":"Baby Gentle Wash 250ml","brand":"BabyBrand","product_family":"Gentle Wash","category":"cosmetic","form":"cleanser","body_area":"baby","use_case":"baby_care","skin_type":"sensitive_skin","size":"250ml","aliases":"baby wash","ocr_keywords":"baby wash kids","price":"20","available":"متوفر"},
    {"product_id":"C5","name":"Body Wash Rose 500ml","brand":"BodyBrand","product_family":"Rose Body Wash","category":"cosmetic","form":"cleanser","body_area":"body","use_case":"body_care","skin_type":"","size":"500ml","aliases":"body wash","ocr_keywords":"body wash shower gel","price":"25","available":"متوفر"},
    {"product_id":"C6","name":"CeraVe Moisturizing Cream 454g","brand":"CeraVe","product_family":"Moisturizing Cream","category":"cosmetic","form":"cream","body_area":"face","use_case":"hydration","skin_type":"dry_skin","size":"454g","aliases":"cerave moisturizing cream","ocr_keywords":"cerave moisturizing cream dry skin","price":"90","available":"متوفر"},
]


def seed_catalog() -> None:
    database.init_db()
    with database.get_db_connection() as conn:
        conn.execute("DELETE FROM products")
        for p in CATALOG:
            conn.execute(
                """
                INSERT INTO products(product_id,name,normalized_name,brand,product_family,category,form,body_area,use_case,skin_type,size,aliases,ocr_keywords,image_ocr_keywords,price,available)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (p["product_id"], p["name"], p["name"].lower(), p["brand"], p["product_family"], p["category"], p["form"], p["body_area"], p["use_case"], p["skin_type"], p["size"], p["aliases"], p["ocr_keywords"], p["ocr_keywords"], p["price"], p["available"]),
            )
        conn.commit()
    matcher.invalidate_product_cache()


def ask(phone: str, text: str):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))


def test_generic_cleanser_starts_guided_flow_without_products():
    r = ask("p_cleanser", "غسول")
    assert r.decision == "guided_ask_cleanser_kind"
    assert "تقصد غسول لأي استخدام" in r.reply
    assert "CeraVe" not in r.reply and "د.ل" not in r.reply


def test_face_cleanser_asks_skin_type():
    r = ask("p_face", "غسول وجه")
    assert r.decision == "guided_ask_skin_type"
    assert "نوع البشرة" in r.reply
    assert "دهنية" in r.reply and "جافة" in r.reply
    assert "د.ل" not in r.reply


def test_oily_face_cleanser_filters_only_face_oily_and_excludes_dry_body_baby():
    r = ask("p_oily", "غسول للبشرة الدهنية")
    assert r.decision == "guided_products"
    assert "Bioderma Sebium" in r.reply or "Effaclar" in r.reply
    assert "Hydrating Cleanser" not in r.reply, r.reply  # dry skin cleanser must not appear
    assert "Baby Gentle Wash" not in r.reply
    assert "Body Wash" not in r.reply


def test_cerave_brand_only_asks_type_and_no_price():
    r = ask("p_brand", "Cerave")
    assert r.decision == "guided_brand_type"
    assert "أي نوع من CeraVe" in r.reply
    assert "د.ل" not in r.reply


def test_image_missing_cerave_foaming_oily_does_not_suggest_dry_cleanser():
    ci = matcher_v4.build_catalog_index(CATALOG)
    decision = matcher_v4.resolve_image_extraction_from_index({
        "image_type": "product_packaging",
        "clarity": "good",
        "confidence": 0.95,
        "brand": "CeraVe",
        "product_name": "Foaming Facial Cleanser",
        "form": "cleanser",
        "skin_type": "oily skin",
        "use_case": "acne",
        "body_area": "face",
        "size": "236ml",
    }, ci)
    assert decision.decision_type in {DecisionType.COSMETIC_ALTERNATIVES, DecisionType.NOT_AVAILABLE}
    for alt in decision.alternatives or []:
        name = alt.get("name", "")
        assert "Hydrating Cleanser" not in name, f"dry cleanser leaked as alternative: {name}"
        assert str(alt.get("form") or "").lower() == "cleanser"
        assert str(alt.get("body_area") or "face").lower() == "face"
        assert str(alt.get("skin_type") or "").lower() in {"oily_skin", "acne", "normal_oily_skin", ""}


def test_no_suitable_alternatives_asks_instead_of_weak_suggestions():
    r = ask("p_sensitive", "غسول للبشرة الحساسة")
    assert r.decision == "guided_no_safe_options"
    assert "لم أجد بدائل مناسبة" in r.reply
    assert "Hydrating Cleanser" not in r.reply
    assert "Bioderma" not in r.reply
    assert "د.ل" not in r.reply


def test_numeric_selection_from_guided_list_selects_correct_product():
    first = ask("p_select", "غسول للبشرة الدهنية")
    assert first.decision == "guided_products"
    second = ask("p_select", "1")
    assert second.decision == "guided_product_selected"
    assert "المنتج المحدد" in second.reply
    assert "السعر" in second.reply


def test_exact_name_still_returns_price_directly():
    r = ask("p_exact", "CeraVe Hydrating Cleanser 236ml")
    assert r.decision in {"matched", "matched_unknown_availability"}
    assert "CeraVe Hydrating Cleanser" in r.reply
    assert "70" in r.reply


def test_guided_filter_utility_blocks_wrong_cosmetic_fit():
    hits = guided_finder.filter_products_by_guided_slots({"selected_product_type":"face_cleanser", "form":"cleanser", "body_area":"face", "selected_skin_type":"oily_skin"}, CATALOG)
    names = "\n".join(p["name"] for p in hits)
    assert "Bioderma Sebium" in names or "Effaclar" in names
    assert "Hydrating Cleanser" not in names
    assert "Baby Gentle" not in names
    assert "Body Wash" not in names


def main():
    seed_catalog()
    test_generic_cleanser_starts_guided_flow_without_products()
    test_face_cleanser_asks_skin_type()
    test_oily_face_cleanser_filters_only_face_oily_and_excludes_dry_body_baby()
    test_cerave_brand_only_asks_type_and_no_price()
    test_image_missing_cerave_foaming_oily_does_not_suggest_dry_cleanser()
    test_no_suitable_alternatives_asks_instead_of_weak_suggestions()
    test_numeric_selection_from_guided_list_selects_correct_product()
    test_exact_name_still_returns_price_directly()
    test_guided_filter_utility_blocks_wrong_cosmetic_fit()
    print("ACCEPTANCE_TESTS_FINAL_V19_3_GUIDED_FINDER_OK")


if __name__ == "__main__":
    main()
