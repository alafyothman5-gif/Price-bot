#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Restore the newest valid PriceBot DB backup safely.

Production behavior:
- stop pricebot.service before replacing DB
- validate backup and target
- remove WAL/SHM only after service is stopped
- start service and health-check after restore
"""
from __future__ import annotations
import argparse, json, os, shutil, sqlite3, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from tools import db_safety  # noqa

DEFAULT_TARGET = Path(os.getenv("PRICEBOT_DB_FILE", "/opt/pricebot/pricebot.db"))
BACKUP_ROOT = Path(os.getenv("PRICEBOT_BACKUP_ROOT", "/root/pricebot_backups"))
SERVICE = os.getenv("PRICEBOT_SERVICE_NAME", "pricebot.service")
PORT = os.getenv("PRICEBOT_PORT", "8000")
MIN_PRODUCTS = int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000)
SKIP_SERVICE = os.getenv("PRICEBOT_SKIP_SERVICE", "0") == "1"

def run(cmd, check=False, timeout=20):
    if SKIP_SERVICE and cmd and cmd[0] in {"systemctl", "sudo"}:
        return subprocess.CompletedProcess(cmd, 0, "SKIPPED", "")
    return subprocess.run(cmd, text=True, capture_output=True, check=check, timeout=timeout)

def stop_service():
    if SKIP_SERVICE: return
    subprocess.run(["sudo", "systemctl", "stop", SERVICE], timeout=30)
    time.sleep(1)

def start_service():
    if SKIP_SERVICE: return
    subprocess.run(["sudo", "systemctl", "start", SERVICE], timeout=30, check=True)

def health_check():
    if SKIP_SERVICE: return True
    import urllib.request
    for _ in range(20):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=2).read(100)
            return True
        except Exception:
            time.sleep(1)
    return False

def db_locked(path: Path) -> bool:
    if SKIP_SERVICE: return False
    if shutil.which("fuser"):
        p = subprocess.run(["fuser", str(path)], text=True, capture_output=True)
        return p.returncode == 0 and bool((p.stdout or p.stderr).strip())
    return False

def find_backups(root: Path):
    candidates=[]
    for p in root.rglob("*.db") if root.exists() else []:
        try:
            db_safety.validate_database(p, min_products=MIN_PRODUCTS, label="candidate")
            candidates.append(p)
        except Exception:
            continue
    return sorted(candidates, key=lambda x: x.stat().st_mtime, reverse=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--backup-root", default=str(BACKUP_ROOT))
    ap.add_argument("--target", default=str(DEFAULT_TARGET))
    ap.add_argument("--backup", default="", help="specific backup DB; otherwise newest valid DB under backup-root")
    args=ap.parse_args()
    target=Path(args.target)
    source=Path(args.backup) if args.backup else None
    if source is None:
        backups=find_backups(Path(args.backup_root))
        if not backups:
            raise SystemExit("NO_VALID_BACKUP_FOUND")
        source=backups[0]
    db_safety.validate_database(source, min_products=MIN_PRODUCTS, label="restore_source")
    stop_service()
    if db_locked(target):
        raise SystemExit(f"DB_RESTORE_ABORTED | db_still_locked={target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp=target.with_name(f"{target.name}.restore_tmp.{os.getpid()}.{int(time.time())}")
    shutil.copy2(source,tmp)
    db_safety.validate_database(tmp, min_products=MIN_PRODUCTS, label="restore_tmp")
    for suffix in ("-wal","-shm"):
        try: target.with_name(target.name+suffix).unlink(missing_ok=True)
        except Exception: pass
    os.replace(tmp,target)
    final=db_safety.validate_database(target, min_products=MIN_PRODUCTS, label="restore_final")
    start_service()
    if not health_check():
        raise SystemExit("DB_RESTORE_DONE_BUT_HEALTH_FAILED")
    print("DB_RESTORE_LAST_GOOD_OK | "+json.dumps({"source":str(source),"target":str(target),"products_count":final.get('products_count')}, ensure_ascii=False))
if __name__ == '__main__': main()
