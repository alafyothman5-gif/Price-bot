#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only PriceBot diagnostics.

Does not import database.py/matcher.py and opens SQLite with mode=ro to avoid
WAL changes, conversation state writes, or accidental DB creation.
"""
from __future__ import annotations
import json, os, sqlite3, subprocess, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = Path(os.getenv("PRICEBOT_DB_FILE", "/opt/pricebot/pricebot.db"))
if not DB.is_absolute(): DB = ROOT / DB
MIN_PRODUCTS = int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000)
SERVICE = os.getenv("PRICEBOT_SERVICE_NAME", "pricebot.service")
PORT = os.getenv("PRICEBOT_PORT", "8000")

def out(k, v): print(f"{k}: {v}")
def ro_conn():
    uri = "file:" + str(DB).replace("#", "%23").replace("?", "%3f") + "?mode=ro"
    con = sqlite3.connect(uri, uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    return con

def count_table(con, table):
    try:
        row=con.execute(f'SELECT COUNT(*) AS c FROM "{table}"').fetchone(); return int(row['c'] if row else 0)
    except Exception as exc:
        return f"ERR:{exc}"

def table_exists(con, table):
    return bool(con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())

def exact_lookup_timing(con, query="Photoblok 50+"):
    started=time.perf_counter(); q=query.lower()
    try:
        row=con.execute("SELECT name, price FROM products WHERE lower(name)=? OR lower(aliases) LIKE ? LIMIT 1", (q, f"%{q}%")).fetchone()
        return {"ms": round((time.perf_counter()-started)*1000,2), "found": bool(row), "name": row['name'] if row else ""}
    except Exception as exc:
        return {"error": str(exc)}

def service_status():
    try:
        p=subprocess.run(["systemctl","is-active",SERVICE], text=True, capture_output=True, timeout=5)
        return p.stdout.strip() or p.stderr.strip() or str(p.returncode)
    except Exception as exc: return f"ERR:{exc}"

def last_errors():
    try:
        p=subprocess.run(["journalctl","-u",SERVICE,"-n","50","--no-pager"], text=True, capture_output=True, timeout=8)
        lines=[ln for ln in (p.stdout or p.stderr).splitlines() if any(w in ln.lower() for w in ['error','failed','exception','traceback','timeout'])]
        return lines[-50:]
    except Exception as exc: return [f"ERR:{exc}"]

def health():
    try:
        started=time.perf_counter()
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=3) as r:
            body=r.read(500).decode('utf-8','replace')
        return {"ok": True, "ms": round((time.perf_counter()-started)*1000,2), "body": body}
    except Exception as exc: return {"ok": False, "error": str(exc)}

result={"db_path": str(DB), "db_exists": DB.exists(), "service": SERVICE}
try:
    con=ro_conn()
    try:
        result['integrity_check']=con.execute('PRAGMA integrity_check').fetchone()[0]
        result['products_count']=count_table(con,'products') if table_exists(con,'products') else 'missing'
        result['search_index_count']=count_table(con,'product_search_index') if table_exists(con,'product_search_index') else 0
        result['nav_index_count']=count_table(con,'product_nav_index') if table_exists(con,'product_nav_index') else 0
        result['guided_index_count']=count_table(con,'guided_catalog_index') if table_exists(con,'guided_catalog_index') else 0
        result['products_guard_ok']=isinstance(result['products_count'], int) and result['products_count'] >= MIN_PRODUCTS
        result['exact_lookup_timing']=exact_lookup_timing(con)
        result['main_menu_timing_note']='read-only diagnose does not call matcher or mutate conversation_state'
    finally: con.close()
except Exception as exc:
    result['db_error']=str(exc)
result['service_status']=service_status()
result['health']=health()
result['last_50_errors']=last_errors()
print(json.dumps(result, ensure_ascii=False, indent=2))
if result.get('integrity_check') != 'ok' or result.get('products_guard_ok') is False:
    sys.exit(2)
