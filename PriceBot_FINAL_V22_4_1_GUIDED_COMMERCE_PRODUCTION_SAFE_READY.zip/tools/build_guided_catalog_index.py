#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the authoritative Guided Commerce index safely.

Production rule:
- If products_master_v22_ready.xlsx is used, it must be a real master file.
- A small/demo Excel is rejected when PRICEBOT_MIN_PRODUCTS_GUARD > 1.
- Excel rows must match the existing DB products by product_id, barcode, or normalized name.
- This tool never deletes/updates products. It writes only guided_catalog_index.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.guided_finder import build_guided_catalog_rows, normalize_text  # noqa: E402
from tools import db_safety  # noqa: E402


def read_excel(path: Path) -> List[dict]:
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(c or "").strip() for c in rows[0]]
    products: List[dict] = []
    for row in rows[1:]:
        item = {headers[i]: (row[i] if i < len(row) else "") for i in range(len(headers)) if headers[i]}
        name = str(item.get("name") or item.get("product_name") or "").strip()
        if name:
            if "name" not in item and "product_name" in item:
                item["name"] = item.get("product_name")
            products.append(item)
    return products


def read_db(min_products: int = 0) -> List[dict]:
    import database
    db_safety.validate_database(database.DB_FILE, min_products=min_products, label="before_guided_catalog_read")
    database.init_db()
    products = database.load_products()
    if min_products and len(products) < min_products:
        raise RuntimeError(f"DB_PROTECTION_FAILED | stage=guided_catalog_read | products_count={len(products)} | min={min_products}")
    return products


def _keyset(product: dict) -> set[str]:
    keys: set[str] = set()
    for key in ("product_id", "id", "barcode", "sku", "item_code", "product_code", "code"):
        value = normalize_text(product.get(key))
        if value:
            keys.add(f"{key}:{value}")
            if key in {"product_id", "barcode"}:
                keys.add(value)
    name = normalize_text(product.get("name") or product.get("product_name"))
    if name:
        keys.add(f"name:{name}")
    return keys


def validate_excel_against_db(excel_products: Sequence[dict], *, min_products: int, min_match_ratio: float) -> Dict[str, object]:
    import database
    if min_products > 1 and len(excel_products) < min_products:
        raise RuntimeError(f"MASTER_EXCEL_REJECTED | reason=too_small | rows={len(excel_products)} | min={min_products}")
    db_safety.validate_database(database.DB_FILE, min_products=min_products, label="before_master_excel_match")
    db_products = database.load_products()
    db_keys: set[str] = set()
    for p in db_products:
        db_keys.update(_keyset(p))
    matched = 0
    unmatched_examples = []
    for row in excel_products:
        keys = _keyset(row)
        if keys and keys.intersection(db_keys):
            matched += 1
        elif len(unmatched_examples) < 10:
            unmatched_examples.append(str(row.get("name") or row.get("product_name") or row.get("product_id") or "")[:120])
    ratio = (matched / max(1, len(excel_products)))
    if min_products > 1 and ratio < min_match_ratio:
        raise RuntimeError(
            "MASTER_EXCEL_REJECTED | " + json.dumps({
                "reason": "db_match_ratio_low", "excel_rows": len(excel_products), "matched": matched,
                "ratio": round(ratio, 4), "required": min_match_ratio, "unmatched_examples": unmatched_examples,
            }, ensure_ascii=False)
        )
    return {"excel_rows": len(excel_products), "db_rows": len(db_products), "matched": matched, "match_ratio": round(ratio, 4)}


def write_report(rows: List[dict], products: List[dict], output: Path) -> Dict[str, int]:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "guided_catalog_tree"
    ws.append(["section", "submenu", "product_count", "available_count", "examples", "unclassified_count", "hidden_count", "exact_only_count", "warnings"])
    grouped: Dict[tuple, List[dict]] = defaultdict(list)
    for r in rows:
        grouped[(r.get("section") or "other", r.get("menu_level_1") or "")].append(r)
    unclassified = [r for r in rows if r.get("section") == "other" or not r.get("menu_level_1") or float(r.get("confidence") or 0) < 0.60]
    hidden_count = 0
    exact_only_count = 0
    for p in products:
        quality = normalize_text(p.get("quality_status") or p.get("review_status"))
        mode = normalize_text(p.get("search_mode"))
        if quality in {"review_only", "needs_review", "unknown", "partial"}:
            hidden_count += 1
        if mode == "exact_only":
            exact_only_count += 1
    product_by_id = {str(p.get("product_id") or p.get("id") or ""): p for p in products}
    for (section, submenu), items in sorted(grouped.items()):
        available = [r for r in items if int(r.get("is_available") or 0) == 1]
        examples = []
        for r in available[:5]:
            p = product_by_id.get(str(r.get("product_id") or "")) or {}
            if p.get("name"):
                examples.append(str(p.get("name")))
        warnings = []
        if section == "other" or not submenu:
            warnings.append("needs_manual_classification")
        if not available:
            warnings.append("empty_or_unavailable")
        ws.append([section, submenu, len(items), len(available), "; ".join(examples), len(unclassified), hidden_count, exact_only_count, "; ".join(warnings)])

    ws2 = wb.create_sheet("unclassified")
    ws2.append(["product_id", "name", "section", "submenu", "confidence", "tags"])
    for r in unclassified[:5000]:
        p = product_by_id.get(str(r.get("product_id") or "")) or {}
        ws2.append([r.get("product_id"), p.get("name"), r.get("section"), r.get("menu_level_1"), r.get("confidence"), r.get("tags_json")])

    ws3 = wb.create_sheet("summary")
    ws3.append(["metric", "value"])
    metrics = {"products_read": len(products), "guided_rows": len(rows), "unclassified_count": len(unclassified), "hidden_count": hidden_count, "exact_only_count": exact_only_count}
    for k, v in metrics.items():
        ws3.append([k, v])

    ws4 = wb.create_sheet("raw_index")
    headers = ["product_id", "section", "menu_level_1", "menu_level_2", "menu_level_3", "product_type", "use_case", "skin_type", "body_area", "is_available", "confidence", "tags_json"]
    ws4.append(headers)
    for r in rows:
        ws4.append([r.get(h, "") for h in headers])
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Guided Commerce catalog index safely")
    parser.add_argument("--input", default="products_master_v22_ready.xlsx", help="Excel master file path")
    parser.add_argument("--db", action="store_true", help="Read products from current SQLite DB. Production deploy normally forbids this unless explicitly allowed.")
    parser.add_argument("--write-db", action="store_true", help="Replace guided_catalog_index only; never touches products")
    parser.add_argument("--report", default="guided_catalog_tree_report.xlsx", help="Output XLSX report")
    parser.add_argument("--min-products", type=int, default=int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "0") or 0), help="Minimum products guard for production DB/master Excel")
    parser.add_argument("--min-match-ratio", type=float, default=float(os.getenv("PRICEBOT_MASTER_MIN_MATCH_RATIO", "0.95") or 0.95))
    parser.add_argument("--allow-db-fallback", action="store_true", help="Allow DB heuristic source when master Excel is missing. Not used by production deploy.")
    args = parser.parse_args()

    source = "db" if args.db else "excel"
    match_report = {}
    if args.db:
        products = read_db(args.min_products)
    else:
        input_path = Path(args.input)
        if not input_path.exists():
            raise SystemExit(f"MASTER_EXCEL_REQUIRED_BUT_MISSING: {input_path}")
        products = read_excel(input_path)
        if args.min_products > 1:
            match_report = validate_excel_against_db(products, min_products=args.min_products, min_match_ratio=args.min_match_ratio)

    rows = build_guided_catalog_rows(products)
    report_path = Path(args.report)
    report_metrics = write_report(rows, products, report_path)

    result = {"source": source, "products_read": len(products), "guided_rows": len(rows), "report": str(report_path), **match_report, **report_metrics}
    if args.write_db:
        import database
        db_safety.validate_database(database.DB_FILE, min_products=args.min_products, label="before_guided_catalog_write")
        before = database.count_products()
        db_result = database.replace_guided_catalog_index(rows)
        after = database.count_products()
        db_safety.validate_database(database.DB_FILE, min_products=args.min_products, expected_count=before, label="after_guided_catalog_write")
        if before != after:
            raise SystemExit(f"DB_PROTECTION_FAILED: before={before} after={after}")
        result.update(db_result)
        result["db_protection"] = "ok"
    print("GUIDED_CATALOG_INDEX_OK | " + json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
