#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${PRICEBOT_APP_DIR:-/opt/pricebot}"
DB_PATH="${PRICEBOT_DB_FILE:-$APP_DIR/pricebot.db}"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_backups}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
MIN_PRODUCTS="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
SKIP_SERVICE="${PRICEBOT_SKIP_SERVICE:-0}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="${1:-}"
if [[ -z "$BACKUP_DIR" ]]; then
  BACKUP_DIR="$(find "$BACKUP_ROOT" -maxdepth 1 -type d -name '*pricebot*backup*' -o -name 'pricebot_v22_4*' 2>/dev/null | sort | tail -1)"
fi
[[ -n "$BACKUP_DIR" && -d "$BACKUP_DIR" ]] || { echo "No backup dir found" >&2; exit 1; }
svc(){ [[ "$SKIP_SERVICE" == "1" ]] && return 0; sudo systemctl "$@"; }
svc stop "$SERVICE_NAME" || true
if [[ -d "$BACKUP_DIR/app_code" ]]; then
  rsync -a --delete \
    --exclude '.env' --exclude 'pricebot.db' --exclude 'pricebot.db-wal' --exclude 'pricebot.db-shm' \
    --exclude 'media/' --exclude 'uploads/' --exclude 'backups/' --exclude 'venv/' --exclude '.venv/' \
    --exclude 'products_master_v22_ready.xlsx' --exclude 'guided_catalog_tree_report.xlsx' \
    "$BACKUP_DIR/app_code/" "$APP_DIR/"
else
  echo "Backup app_code missing: $BACKUP_DIR" >&2; exit 1
fi
if [[ -f "$BACKUP_DIR/pricebot.db" ]]; then
  python3 "$SCRIPT_DIR/tools/db_safety.py" restore --backup "$BACKUP_DIR/pricebot.db" --db "$DB_PATH" --min-products "$MIN_PRODUCTS"
fi
[[ -f "$BACKUP_DIR/.env" ]] && cp -a "$BACKUP_DIR/.env" "$APP_DIR/.env"
[[ -f "$BACKUP_DIR/products_master_v22_ready.xlsx" ]] && cp -a "$BACKUP_DIR/products_master_v22_ready.xlsx" "$APP_DIR/products_master_v22_ready.xlsx"
[[ -f "$BACKUP_DIR/guided_catalog_tree_report.xlsx" ]] && cp -a "$BACKUP_DIR/guided_catalog_tree_report.xlsx" "$APP_DIR/guided_catalog_tree_report.xlsx"
[[ -d "$BACKUP_DIR/media" ]] && rsync -a --delete "$BACKUP_DIR/media/" "$APP_DIR/media/"
[[ -d "$BACKUP_DIR/uploads" ]] && rsync -a --delete "$BACKUP_DIR/uploads/" "$APP_DIR/uploads/"
python3 "$SCRIPT_DIR/tools/db_safety.py" validate --db "$DB_PATH" --min-products "$MIN_PRODUCTS" --label after_rollback
svc start "$SERVICE_NAME" || true
echo "PRICEBOT_ROLLBACK_CLEAN_RESTORE_OK | backup=$BACKUP_DIR"
