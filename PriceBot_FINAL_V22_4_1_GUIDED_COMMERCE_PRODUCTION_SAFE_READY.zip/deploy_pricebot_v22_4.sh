#!/usr/bin/env bash
set -Eeuo pipefail

RELEASE_DIR="${PRICEBOT_RELEASE_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
APP_DIR="${PRICEBOT_APP_DIR:-/opt/pricebot}"
SERVICE_NAME="${PRICEBOT_SERVICE_NAME:-pricebot.service}"
PRICEBOT_PORT="${PRICEBOT_PORT:-8000}"
DB_PATH="${PRICEBOT_DB_FILE:-$APP_DIR/pricebot.db}"
MIN_PRODUCTS="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_backups}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/pricebot_v22_4_clean_predeploy_$STAMP"
SKIP_SERVICE="${PRICEBOT_SKIP_SERVICE:-0}"
MASTER_REQUIRED="${PRICEBOT_GUIDED_MASTER_REQUIRED:-1}"

log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') | $*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }
run_timeout(){ local seconds="$1"; shift; timeout --preserve-status "${seconds}s" "$@"; }
service_cmd(){ if [[ "$SKIP_SERVICE" == "1" ]]; then log "SERVICE_SKIP | $*"; return 0; fi; sudo systemctl "$@"; }
service_timeout(){
  local seconds="$1"; shift
  if [[ "$SKIP_SERVICE" == "1" ]]; then log "SERVICE_SKIP | timeout=${seconds}s | $*"; return 0; fi
  timeout --preserve-status "${seconds}s" sudo systemctl "$@"
}
health_check(){
  if [[ "$SKIP_SERVICE" == "1" ]]; then return 0; fi
  local ok=0
  for _ in $(seq 1 20); do
    if curl -fsS "http://127.0.0.1:${PRICEBOT_PORT}/health" >/tmp/pricebot_v22_4_health.json 2>/dev/null; then ok=1; break; fi
    sleep 1
  done
  [[ "$ok" == "1" ]]
}

[[ -d "$RELEASE_DIR" ]] || fail "Release dir not found: $RELEASE_DIR"
[[ -f "$RELEASE_DIR/app.py" && -f "$RELEASE_DIR/database.py" && -d "$RELEASE_DIR/services" && -d "$RELEASE_DIR/tools" ]] || fail "Invalid PriceBot release directory: $RELEASE_DIR"
[[ "$APP_DIR" != "/" && "$APP_DIR" != "/opt" ]] || fail "Unsafe APP_DIR=$APP_DIR"
[[ -d "$APP_DIR" ]] || fail "APP_DIR not found: $APP_DIR"
[[ -f "$DB_PATH" ]] || fail "pricebot.db not found at $DB_PATH. Production deploy refuses to create a DB."
if [[ -d /opt/medmcq || -d /opt/MedMCQ ]]; then log "SAFE_CHECK: MedMCQ detected and will not be touched."; fi

validate_db(){
  local stage="$1" expected="${2:-}"
  local args=(validate --db "$DB_PATH" --min-products "$MIN_PRODUCTS" --label "$stage")
  [[ -n "$expected" ]] && args+=(--expected-count "$expected")
  PRICEBOT_DB_FILE="$DB_PATH" python3 "$RELEASE_DIR/tools/db_safety.py" "${args[@]}"
}
count_products(){ PRICEBOT_DB_FILE="$DB_PATH" python3 "$RELEASE_DIR/tools/db_safety.py" count --db "$DB_PATH" --table products; }

restore_and_fail(){
  local reason="$1"
  log "DEPLOY_ROLLBACK_START | reason=$reason | backup=$BACKUP_DIR"
  service_cmd stop "$SERVICE_NAME" >/dev/null 2>&1 || true
  if [[ -d "$BACKUP_DIR/app_code" ]]; then
    rsync -a --delete \
      --exclude '.env' --exclude 'pricebot.db' --exclude 'pricebot.db-wal' --exclude 'pricebot.db-shm' \
      --exclude 'media/' --exclude 'uploads/' --exclude 'backups/' --exclude 'venv/' --exclude '.venv/' \
      --exclude 'products_master_v22_ready.xlsx' --exclude 'guided_catalog_tree_report.xlsx' \
      "$BACKUP_DIR/app_code/" "$APP_DIR/" || true
  fi
  if [[ -f "$BACKUP_DIR/pricebot.db" ]]; then
    PRICEBOT_DB_FILE="$DB_PATH" python3 "$RELEASE_DIR/tools/db_safety.py" restore --backup "$BACKUP_DIR/pricebot.db" --db "$DB_PATH" --min-products "$MIN_PRODUCTS" || true
  fi
  [[ -f "$BACKUP_DIR/.env" ]] && cp -a "$BACKUP_DIR/.env" "$APP_DIR/.env" || true
  [[ -f "$BACKUP_DIR/products_master_v22_ready.xlsx" ]] && cp -a "$BACKUP_DIR/products_master_v22_ready.xlsx" "$APP_DIR/products_master_v22_ready.xlsx" || true
  [[ -f "$BACKUP_DIR/guided_catalog_tree_report.xlsx" ]] && cp -a "$BACKUP_DIR/guided_catalog_tree_report.xlsx" "$APP_DIR/guided_catalog_tree_report.xlsx" || true
  if [[ -d "$BACKUP_DIR/media" ]]; then rsync -a --delete "$BACKUP_DIR/media/" "$APP_DIR/media/" || true; fi
  if [[ -d "$BACKUP_DIR/uploads" ]]; then rsync -a --delete "$BACKUP_DIR/uploads/" "$APP_DIR/uploads/" || true; fi
  service_cmd start "$SERVICE_NAME" >/dev/null 2>&1 || true
  fail "$reason | rollback_attempted=1 | backup=$BACKUP_DIR"
}
trap 'restore_and_fail "unexpected deploy error at line $LINENO"' ERR

log "DB validation before any code copy."
validate_db "before_deploy"
PRODUCTS_BEFORE="$(count_products)"
[[ "$PRODUCTS_BEFORE" =~ ^[0-9]+$ ]] || fail "Invalid products count: $PRODUCTS_BEFORE"
(( PRODUCTS_BEFORE >= MIN_PRODUCTS )) || fail "DB_PROTECTION_FAILED | stage=before_deploy | products_count=$PRODUCTS_BEFORE | min=$MIN_PRODUCTS"
log "DB_PROTECTION_OK | stage=before_deploy | products_count=$PRODUCTS_BEFORE"

log "Creating backup of old stable code + DB + persistent files: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
rsync -a --delete \
  --exclude '.git/' --exclude '__pycache__/' --exclude '.pytest_cache/' --exclude '.env' \
  --exclude 'pricebot.db' --exclude 'pricebot.db-wal' --exclude 'pricebot.db-shm' \
  --exclude 'media/' --exclude 'uploads/' --exclude 'backups/' --exclude 'venv/' --exclude '.venv/' \
      --exclude 'products_master_v22_ready.xlsx' --exclude 'guided_catalog_tree_report.xlsx' \
  "$APP_DIR/" "$BACKUP_DIR/app_code/"
PRICEBOT_DB_FILE="$DB_PATH" python3 "$RELEASE_DIR/tools/db_safety.py" backup --db "$DB_PATH" --out-dir "$BACKUP_DIR" --min-products "$MIN_PRODUCTS"
[[ -f "$APP_DIR/.env" ]] && cp -a "$APP_DIR/.env" "$BACKUP_DIR/.env"
[[ -f "$APP_DIR/products_master_v22_ready.xlsx" ]] && cp -a "$APP_DIR/products_master_v22_ready.xlsx" "$BACKUP_DIR/products_master_v22_ready.xlsx"
[[ -f "$APP_DIR/guided_catalog_tree_report.xlsx" ]] && cp -a "$APP_DIR/guided_catalog_tree_report.xlsx" "$BACKUP_DIR/guided_catalog_tree_report.xlsx"
[[ -d "$APP_DIR/media" ]] && rsync -a "$APP_DIR/media/" "$BACKUP_DIR/media/"
[[ -d "$APP_DIR/uploads" ]] && rsync -a "$APP_DIR/uploads/" "$BACKUP_DIR/uploads/"
[[ -f "/etc/systemd/system/$SERVICE_NAME" ]] && cp -a "/etc/systemd/system/$SERVICE_NAME" "$BACKUP_DIR/$SERVICE_NAME" || true
log "PRICEBOT_BACKUP_OK | backup=$BACKUP_DIR"

log "Copying clean release to APP_DIR with persistent exclusions."
rsync -a --delete \
  --exclude '.env' --exclude 'pricebot.db' --exclude 'pricebot.db-wal' --exclude 'pricebot.db-shm' \
  --exclude 'media/' --exclude 'uploads/' --exclude 'backups/' --exclude 'venv/' --exclude '.venv/' \
      --exclude 'products_master_v22_ready.xlsx' --exclude 'guided_catalog_tree_report.xlsx' \
  --exclude '.git/' --exclude '__pycache__/' --exclude '.pytest_cache/' \
  "$RELEASE_DIR/" "$APP_DIR/"
validate_db "after_code_copy" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after code copy"
cd "$APP_DIR"

log "Installing dependencies."
if [[ "${PRICEBOT_SKIP_DEPENDENCY_INSTALL:-0}" == "1" ]]; then
  log "DEPENDENCY_INSTALL_SKIPPED_BY_EXPLICIT_FLAG | using_current_python"
else
  python3 -m venv venv
  # shellcheck disable=SC1091
  source venv/bin/activate
  run_timeout 60 python -m pip install --upgrade pip >/tmp/pricebot_pip_upgrade.log 2>&1 || { cat /tmp/pricebot_pip_upgrade.log; restore_and_fail "pip upgrade failed"; }
  run_timeout 120 pip install -r requirements.txt >/tmp/pricebot_pip_install.log 2>&1 || { cat /tmp/pricebot_pip_install.log; restore_and_fail "requirements install failed"; }
fi

log "Compile check."
run_timeout 60 python -m compileall -q . || restore_and_fail "compileall failed"

if [[ "${PRICEBOT_SKIP_INTERNAL_TESTS:-0}" != "1" ]]; then
  log "Running acceptance tests on isolated temp DB only."
  TEST_DB_DIR="$(mktemp -d /tmp/pricebot_v22_4_tests_XXXXXX)"
  run_timeout 120 env PRICEBOT_DB_FILE="$TEST_DB_DIR/pytest.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python -m pytest -q || restore_and_fail "pytest failed"
  run_timeout 120 env PRICEBOT_DB_FILE="$TEST_DB_DIR/v22_2.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_2_stability_speed.py || restore_and_fail "V22.2 acceptance failed"
  run_timeout 120 env PRICEBOT_DB_FILE="$TEST_DB_DIR/company.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_company_grade.py || restore_and_fail "V22 company-grade acceptance failed"
  run_timeout 120 env PRICEBOT_DB_FILE="$TEST_DB_DIR/v22_3.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_3_guided_commerce.py || restore_and_fail "V22.3 guided acceptance failed"
  run_timeout 180 env PRICEBOT_DB_FILE="$TEST_DB_DIR/v22_4.db" PRICEBOT_MIN_PRODUCTS_GUARD=1 PRICEBOT_SKIP_MIGRATION_BACKUP=1 python acceptance_tests_final_v22_4_db_safety_guided.py || restore_and_fail "V22.4 DB safety/guided acceptance failed"
  validate_db "after_isolated_tests" "$PRODUCTS_BEFORE" || restore_and_fail "Production DB changed during isolated tests"
else
  log "INTERNAL_TESTS_SKIPPED_BY_EXPLICIT_FLAG"
fi

log "Stopping service before production DB write phases."
if ! service_timeout 20 stop "$SERVICE_NAME"; then
  log "SERVICE_STOP_TIMEOUT_BEFORE_DB_WRITE | action=term_kill_continue"
  service_cmd kill -s TERM "$SERVICE_NAME" || true
  sleep 2
fi

log "Running additive production migrations inside DB guard."
run_timeout 45 env PRICEBOT_PRODUCTION_MODE=1 PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python - <<'PY' || restore_and_fail "migration failed"
import os
import database
from tools import db_safety
before = database.count_products()
db_safety.validate_database(database.DB_FILE, min_products=int(os.getenv('PRICEBOT_MIN_PRODUCTS_GUARD','1000')), expected_count=before, label='before_migration')
database.init_db()
database.ensure_v19_tables()
database.ensure_v22_tables()
after = database.count_products()
if after != before:
    raise SystemExit(f"DB_PROTECTION_FAILED | stage=migration | before={before} | after={after}")
db_safety.validate_database(database.DB_FILE, min_products=int(os.getenv('PRICEBOT_MIN_PRODUCTS_GUARD','1000')), expected_count=before, label='after_migration')
print(f"DB_PROTECTION_OK | stage=migration | products_count={after}")
PY
validate_db "after_migration" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after migration"

log "Rebuilding search index safely."
run_timeout 90 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/rebuild_search_index.py || restore_and_fail "search index rebuild failed"
validate_db "after_search_index" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after search index"

log "Rebuilding product navigator index safely."
run_timeout 90 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/rebuild_product_nav_index.py || restore_and_fail "product nav index rebuild failed"
validate_db "after_nav_index" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after nav index"

log "Rebuilding guided catalog index from master Excel."
MASTER_FILE="$APP_DIR/products_master_v22_ready.xlsx"
if [[ ! -f "$MASTER_FILE" ]]; then
  if [[ "$MASTER_REQUIRED" == "1" ]]; then
    restore_and_fail "products_master_v22_ready.xlsx missing; guided catalog production source is required"
  fi
  run_timeout 90 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/build_guided_catalog_index.py --db --write-db --report "$APP_DIR/guided_catalog_tree_report.xlsx" --min-products "$MIN_PRODUCTS" || restore_and_fail "guided catalog index rebuild from DB failed"
else
  run_timeout 120 env PRICEBOT_DB_FILE="$DB_PATH" PRICEBOT_MIN_PRODUCTS_GUARD="$MIN_PRODUCTS" python tools/build_guided_catalog_index.py --input "$MASTER_FILE" --write-db --report "$APP_DIR/guided_catalog_tree_report.xlsx" --min-products "$MIN_PRODUCTS" --min-match-ratio "${PRICEBOT_MASTER_MIN_MATCH_RATIO:-0.95}" || restore_and_fail "guided catalog index rebuild from master Excel failed"
fi
validate_db "after_guided_index" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after guided index"
GUIDED_COUNT="$(PRICEBOT_DB_FILE="$DB_PATH" python tools/db_safety.py count --db "$DB_PATH" --table guided_catalog_index || echo 0)"
if [[ "$GUIDED_COUNT" =~ ^[0-9]+$ ]] && (( GUIDED_COUNT < MIN_PRODUCTS / 2 )); then restore_and_fail "guided_catalog_index too small: $GUIDED_COUNT"; fi

log "Restarting service."
service_cmd daemon-reload || true
if ! service_timeout 20 stop "$SERVICE_NAME"; then
  log "SERVICE_STOP_TIMEOUT | action=term_kill_continue"
  service_cmd kill -s TERM "$SERVICE_NAME" || true
  sleep 2
fi
service_timeout 25 start "$SERVICE_NAME" || restore_and_fail "service start failed"
health_check || { service_cmd status "$SERVICE_NAME" --no-pager -l || true; restore_and_fail "health check failed after restart"; }
validate_db "after_health" "$PRODUCTS_BEFORE" || restore_and_fail "DB validation failed after health"

trap - ERR
log "PRICEBOT_V22_4_CLEAN_PRODUCTION_SAFE_DEPLOY_OK | products_count=$PRODUCTS_BEFORE | guided_rows=$GUIDED_COUNT | backup=$BACKUP_DIR"
