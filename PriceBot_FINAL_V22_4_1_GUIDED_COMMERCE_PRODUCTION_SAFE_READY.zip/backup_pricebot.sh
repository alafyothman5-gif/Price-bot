#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${PRICEBOT_APP_DIR:-/opt/pricebot}"
DB_PATH="${PRICEBOT_DB_FILE:-$APP_DIR/pricebot.db}"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/root/pricebot_backups}"
MIN_PRODUCTS="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT="$BACKUP_ROOT/manual_pricebot_backup_$STAMP"
mkdir -p "$OUT"
[[ -d "$APP_DIR" ]] || { echo "APP_DIR not found: $APP_DIR" >&2; exit 1; }
[[ -f "$DB_PATH" ]] || { echo "DB not found: $DB_PATH" >&2; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/tools/db_safety.py" validate --db "$DB_PATH" --min-products "$MIN_PRODUCTS" --label before_backup
rsync -a --delete \
  --exclude '.env' --exclude 'pricebot.db' --exclude 'pricebot.db-wal' --exclude 'pricebot.db-shm' \
  --exclude 'media/' --exclude 'uploads/' --exclude 'backups/' --exclude 'venv/' --exclude '.venv/' \
  --exclude 'products_master_v22_ready.xlsx' --exclude 'guided_catalog_tree_report.xlsx' \
  --exclude '.git/' --exclude '__pycache__/' --exclude '.pytest_cache/' \
  "$APP_DIR/" "$OUT/app_code/"
python3 "$SCRIPT_DIR/tools/db_safety.py" backup --db "$DB_PATH" --out-dir "$OUT" --min-products "$MIN_PRODUCTS"
[[ -f "$APP_DIR/.env" ]] && cp -a "$APP_DIR/.env" "$OUT/.env"
[[ -f "$APP_DIR/products_master_v22_ready.xlsx" ]] && cp -a "$APP_DIR/products_master_v22_ready.xlsx" "$OUT/products_master_v22_ready.xlsx"
[[ -f "$APP_DIR/guided_catalog_tree_report.xlsx" ]] && cp -a "$APP_DIR/guided_catalog_tree_report.xlsx" "$OUT/guided_catalog_tree_report.xlsx"
[[ -d "$APP_DIR/media" ]] && rsync -a "$APP_DIR/media/" "$OUT/media/"
[[ -d "$APP_DIR/uploads" ]] && rsync -a "$APP_DIR/uploads/" "$OUT/uploads/"
echo "PRICEBOT_BACKUP_OK | $OUT"
