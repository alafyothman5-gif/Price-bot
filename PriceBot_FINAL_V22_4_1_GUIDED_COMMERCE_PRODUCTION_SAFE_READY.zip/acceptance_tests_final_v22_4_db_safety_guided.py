#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V22.4 production-safety + Guided Commerce acceptance tests.

All DBs live under /tmp. No production .env or /opt/pricebot/pricebot.db is used.
"""
from __future__ import annotations
import os, shutil, sqlite3, subprocess, sys, tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="pricebot_v22_4_acceptance_"))
DB = TMP / "acceptance_v22_4.db"
os.environ["PRICEBOT_DB_FILE"] = str(DB)
os.environ["PRICEBOT_SKIP_MIGRATION_BACKUP"] = "1"
os.environ["PRICEBOT_MIN_PRODUCTS_GUARD"] = "1"
os.environ["PRICEBOT_ENV"] = "test"
os.environ["ADMIN_PASSWORD"] = "test-admin-password"
os.environ["ADMIN_SESSION_SECRET"] = "test-admin-session-secret-long"
os.environ["MERCHANT_LOGIN_CODE"] = "test-merchant-code"
os.environ["PHARMACY_NAME"] = "صيدلية بدر البشرية"

import database  # noqa: E402
import matcher  # noqa: E402
from services import guided_finder  # noqa: E402
from tools import db_safety  # noqa: E402
from tools.rebuild_search_index import rebuild_search_index  # noqa: E402
from tools.rebuild_product_nav_index import rebuild_product_nav_index  # noqa: E402

ROOT = Path(__file__).resolve().parent

BASE = [
    ("P1","Photoblok 50+","Photoblok","skin_care","sunscreen","sun_protection","normal_combination_skin","face","Photoblok 50+","70"),
    ("Z1","Zofran Ondansetron 4 mg","Zofran","medicine","stomach_vomiting","antiemetic","","","zofran 4 ondansetron","40"),
    ("G1","Gyno-Daktarin Vag Cream","Gyno-Daktarin","medicine","gynecology","vaginal","","feminine","gyno daktarin vag cream","55"),
    ("F1","Flagyl 500mg Tablets","Flagyl","medicine","antibiotic","","","","flagyl 500 tablet","18"),
    ("S1","Feroglobin Iron Capsules","Feroglobin","supplements","iron","iron","","","ferro ferrous iron حديد","35"),
    ("VD1","Vitamin D3 5000 IU","VitD","supplements","vitamin_d","vitamin_d","","","vitamin d d3","25"),
    ("C1","Bioderma Sebium Gel Moussant 200ml","Bioderma","skin_care","face_cleanser","acne","oily_skin","face","bioderma sebium cleanser","65"),
    ("C2","Dry Skin Cleanser 200ml","DryBrand","skin_care","face_cleanser","hydration","dry_skin","face","dry cleanser","60"),
    ("Bwash","Baby Gentle Wash 250ml","BabyBrand","baby","baby_wash","baby_care","sensitive_skin","baby","baby wash","20"),
    ("BodyWash","Body Wash Rose 500ml","BodyBrand","skin_care","body_care","body_care","","body","body wash","25"),
    ("H1","Hair Shampoo Repair","HairBrand","hair_care","shampoo","","","hair","shampoo hair","30"),
    ("B1","Baby Diapers Small","BabyBrand","baby","diapers","","","baby","diaper حفاض","45"),
    ("D1","Digital Blood Pressure Monitor","DeviceCo","devices","blood_pressure","","","","device meter pressure","180"),
]

def make_products(n: int = 1015):
    rows=[]
    for pid,name,brand,section,ptype,use,skin,area,aliases,price in BASE:
        rows.append({"product_id":pid,"name":name,"brand":brand,"company":brand,"section":section,"category":section,"product_type":ptype,"use_case":use,"skin_type":skin,"body_area":area,"aliases":aliases,"ocr_keywords":aliases,"image_ocr_keywords":aliases,"price":price,"available":"متوفر","quality_status":"verified","search_mode":"guided"})
    for i in range(1,15):
        rows.append({"product_id":f"OC{i}","name":f"Oily Face Cleanser {i}","brand":"OilyBrand","company":"OilyBrand","section":"skin_care","category":"skin_care","product_type":"face_cleanser","use_case":"acne","skin_type":"oily_skin","body_area":"face","aliases":f"oily cleanser {i}","ocr_keywords":"oily face cleanser","image_ocr_keywords":"oily face cleanser","price":str(40+i),"available":"متوفر","quality_status":"verified","search_mode":"guided"})
    idx=0
    while len(rows) < n:
        rows.append({"product_id":f"X{idx}","name":f"Extra Iron Product {idx}","brand":"BulkBrand","company":"BulkBrand","section":"supplements","category":"supplements","product_type":"iron","use_case":"iron","skin_type":"","body_area":"","aliases":"iron ferro حديد","ocr_keywords":"iron ferro","image_ocr_keywords":"iron ferro","price":"9","available":"متوفر","quality_status":"verified","search_mode":"guided"})
        idx += 1
    return rows

def seed_db(products):
    database.init_db()
    with database.get_db_connection() as conn:
        # test DB only, never production
        conn.execute("DROP TABLE IF EXISTS products")
        conn.execute("DROP TABLE IF EXISTS conversation_state")
        conn.commit()
    database.init_db()
    with database.get_db_connection() as conn:
        for p in products:
            conn.execute("""
            INSERT INTO products(product_id,name,normalized_name,brand,company,section,category,product_type,use_case,skin_type,body_area,aliases,ocr_keywords,image_ocr_keywords,price,available,quality_status,search_mode)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (p['product_id'],p['name'],p['name'].lower(),p['brand'],p['company'],p['section'],p['category'],p['product_type'],p['use_case'],p['skin_type'],p['body_area'],p['aliases'],p['ocr_keywords'],p['image_ocr_keywords'],p['price'],p['available'],p['quality_status'],p['search_mode']))
        conn.commit()

def write_excel(path: Path, products):
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active
    headers=["product_id","name","brand","company","category","section","product_type","use_case","skin_type","body_area","available","price","search_mode","quality_status","aliases","ocr_keywords"]
    ws.append(headers)
    for p in products:
        ws.append([p.get(h,"") for h in headers])
    wb.save(path)

def ask(phone, text):
    return matcher.handle_text_query_result(phone, text, database.get_user_state(phone))

def assert_no_price(reply):
    assert "السعر" not in reply and "د.ل" not in reply, reply

def test_build_master_and_indexes():
    products=make_products(1015)
    seed_db(products)
    before=database.count_products()
    assert before >= 1000
    assert rebuild_search_index()["products_after"] == before
    assert rebuild_product_nav_index()["products_after"] == before
    master=TMP/"products_master_v22_ready.xlsx"; write_excel(master, products)
    cmd=[sys.executable,"tools/build_guided_catalog_index.py","--input",str(master),"--write-db","--report",str(TMP/"report.xlsx"),"--min-products","1000"]
    subprocess.run(cmd, cwd=ROOT, check=True)
    database._WAL_CONFIGURED = False
    assert db_safety.table_count(DB, "products") == before
    assert db_safety.table_count(DB, "guided_catalog_index") >= 1000
    guided_products=database.load_guided_catalog_products(require_index=True)
    assert guided_products and all(p.get('_guided_index_source') == 'guided_catalog_index' for p in guided_products[:20])

def test_small_and_mismatch_excel_fail():
    small=TMP/"small.xlsx"; write_excel(small, make_products(10))
    p=subprocess.run([sys.executable,"tools/build_guided_catalog_index.py","--input",str(small),"--write-db","--min-products","1000"], cwd=ROOT, text=True, capture_output=True)
    assert p.returncode != 0 and "too_small" in (p.stdout+p.stderr)
    mismatch=make_products(1010)
    for row in mismatch: row['product_id']='BAD_'+row['product_id']; row['name']='Mismatch '+row['name']
    mm=TMP/"mismatch.xlsx"; write_excel(mm, mismatch)
    p=subprocess.run([sys.executable,"tools/build_guided_catalog_index.py","--input",str(mm),"--write-db","--min-products","1000"], cwd=ROOT, text=True, capture_output=True)
    assert p.returncode != 0 and "db_match_ratio_low" in (p.stdout+p.stderr)

def test_guided_flow_from_index_and_pagination():
    r=ask("u1","السلام عليكم"); assert "اختر القسم" in r.reply and "أدوية" in r.reply
    r=ask("u1","عناية بالبشرة"); assert "غسول وجه" in r.reply
    r=ask("u1","غسول وجه"); assert "نوع البشرة" in r.reply
    r=ask("u1","دهنية"); assert "Oily Face Cleanser" in r.reply and "Baby Gentle Wash" not in r.reply and "Body Wash" not in r.reply and "Dry Skin" not in r.reply and "المزيد" in r.reply
    r=ask("u1","المزيد"); assert "Oily Face Cleanser" in r.reply
    r=ask("u1","1"); assert "✅ المنتج متوفر" in r.reply and "السعر" in r.reply
    r=ask("u2","مكملات وفيتامينات"); assert "حديد" in r.reply
    r=ask("u2","حديد"); assert "Iron" in r.reply or "Feroglobin" in r.reply
    r=ask("u3","عناية بالشعر"); assert "شامبو" in r.reply
    r=ask("u3","شامبو"); assert "Hair Shampoo" in r.reply and "Bioderma" not in r.reply
    r=ask("u4","أطفال"); assert "حفاضات" in r.reply or "شامبو/غسول" in r.reply
    r=ask("u4","شامبو/غسول أطفال"); assert "Baby Gentle Wash" in r.reply
    r=ask("u5","أجهزة ومستلزمات"); assert "قياس ضغط" in r.reply
    r=ask("u5","قياس ضغط"); assert "Digital Blood Pressure" in r.reply

def test_system_commands_override_state_and_safety_replies():
    r=ask("u6","بحث باسم منتج"); assert "اكتب اسم المنتج" in r.reply
    r=ask("u6","السلام عليكم"); assert "اختر القسم" in r.reply
    r=ask("u7","Cerave"); assert_no_price(r.reply)
    r=ask("u8","Flagyl"); assert_no_price(r.reply); assert "بدائل دوائية" not in r.reply
    r=ask("u9","Photoblok 50+"); assert "السعر" in r.reply

def test_corrupt_db_detected_and_restore_backup():
    corrupt=TMP/"corrupt.db"; corrupt.write_text("not a db")
    try:
        db_safety.validate_database(corrupt, min_products=1)
        raise AssertionError("corrupt DB passed validation")
    except RuntimeError:
        pass
    backup_dir=TMP/"backup"; backup_dir.mkdir()
    backup=db_safety.online_backup(DB, backup_dir, min_products=1000)
    restored=TMP/"restored.db"
    result=db_safety.restore_database(backup, restored, min_products=1000)
    assert result['products_count'] >= 1000

def test_clean_deploy_script_has_real_staging_and_clean_restore():
    script=(ROOT/"deploy_pricebot_v22_4.sh").read_text()
    assert "RELEASE_DIR" in script and "APP_DIR" in script
    assert "rsync -a --delete" in script
    assert "--exclude 'pricebot.db'" in script
    assert "PRICEBOT_SKIP_INTERNAL_TESTS" in script
    assert "products_master_v22_ready.xlsx missing" in script

def main():
    test_build_master_and_indexes()
    test_small_and_mismatch_excel_fail()
    test_guided_flow_from_index_and_pagination()
    test_system_commands_override_state_and_safety_replies()
    test_corrupt_db_detected_and_restore_backup()
    test_clean_deploy_script_has_real_staging_and_clean_restore()
    print("ACCEPTANCE_TESTS_FINAL_V22_4_DB_SAFETY_GUIDED_OK")

if __name__ == '__main__': main()
