# PriceBot V22.4.1 — Clean Production-Safe Deploy

هذه النسخة مصممة كإصلاح أمان واستقرار فوق V22.4، وليست إضافة ميزات جديدة.

## القاعدة الأساسية

- لا يتم نسخ `.env` من الحزمة.
- لا يتم نسخ أو استبدال `pricebot.db` من الحزمة.
- لا يتم حذف جدول `products`.
- لا تعمل الاختبارات الداخلية على قاعدة الإنتاج.
- `products_master_v22_ready.xlsx` ملف إنتاج مستقل يجب أن يكون موجودًا داخل `/opt/pricebot` قبل النشر إذا كان `PRICEBOT_GUIDED_MASTER_REQUIRED=1`، وهو الافتراضي.

## طريقة النشر الصحيحة

فك ZIP في مجلد مؤقت، مثل:

```bash
rm -rf /tmp/pricebot_release
mkdir -p /tmp/pricebot_release
unzip PriceBot_FINAL_V22_4_1_GUIDED_COMMERCE_PRODUCTION_SAFE_READY.zip -d /tmp/pricebot_release
cd /tmp/pricebot_release
chmod +x deploy_pricebot_v22_4.sh backup_pricebot.sh rollback_pricebot.sh smoke_test_pricebot.sh tools/*.py
./deploy_pricebot_v22_4.sh
```

السكربت ينسخ الكود من مجلد release إلى `/opt/pricebot` عبر `rsync --delete` مع استثناء الملفات الدائمة:

```text
.env
pricebot.db
pricebot.db-wal
pricebot.db-shm
products_master_v22_ready.xlsx
media/
uploads/
backups/
venv/
```

## مراحل الحماية

`deploy_pricebot_v22_4.sh` ينفذ:

1. فحص `PRAGMA integrity_check` قبل أي نسخ.
2. فحص عدد المنتجات قبل أي نسخ.
3. backup للكود القديم والـ DB والملفات الدائمة.
4. نسخ الكود الجديد من staging إلى `/opt/pricebot`.
5. اختبارات داخلية على قواعد مؤقتة فقط.
6. إيقاف الخدمة قبل مراحل الكتابة على DB.
7. migrations additive فقط.
8. rebuild للفهرسة بدون لمس `products`.
9. بناء `guided_catalog_index` من `products_master_v22_ready.xlsx` مع min guard ونسبة تطابق.
10. restart و health check.
11. rollback نظيف إذا فشلت أي مرحلة.

## Master Excel

في الإنتاج، إذا كان `PRICEBOT_GUIDED_MASTER_REQUIRED=1`، يجب وجود:

```text
/opt/pricebot/products_master_v22_ready.xlsx
```

ويجب أن:

- يحتوي على عدد صفوف لا يقل عن `PRICEBOT_MIN_PRODUCTS_GUARD`، الافتراضي 1000.
- يطابق منتجات DB بنسبة لا تقل عن `PRICEBOT_MASTER_MIN_MATCH_RATIO`، الافتراضي 0.95.
- يحتوي أعمدة التصنيف اللازمة للقوائم.

إذا كان الملف صغيرًا أو demo أو لا يطابق DB، يفشل النشر ويعمل rollback.

## أوامر الفحص

```bash
python tools/diagnose_pricebot.py
./smoke_test_pricebot.sh
```

`smoke_test_pricebot.sh` يستخدم DB مؤقتة افتراضيًا. لا يلمس قاعدة الإنتاج إلا إذا مررت صراحة:

```bash
PRICEBOT_ALLOW_LIVE_SMOKE=1 ./smoke_test_pricebot.sh
```

## rollback يدوي

```bash
./rollback_pricebot.sh
```

أو:

```bash
./rollback_pricebot.sh /root/pricebot_backups/<backup_dir>
```
