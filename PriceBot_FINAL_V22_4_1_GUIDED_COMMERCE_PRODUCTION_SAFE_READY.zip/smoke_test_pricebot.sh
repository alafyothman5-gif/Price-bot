#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') | $*"; }

if [[ "${PRICEBOT_ALLOW_LIVE_SMOKE:-0}" != "1" ]]; then
  TMP="$(mktemp -d /tmp/pricebot_smoke_XXXXXX)"
  export PRICEBOT_DB_FILE="$TMP/smoke.db"
  export PRICEBOT_MIN_PRODUCTS_GUARD=1
  export PRICEBOT_SKIP_MIGRATION_BACKUP=1
  export PRICEBOT_PRODUCTION_MODE=0
  log "SMOKE_MODE=temp_db | db=$PRICEBOT_DB_FILE"
else
  : "${PRICEBOT_DB_FILE:=$ROOT/pricebot.db}"
  export PRICEBOT_DB_FILE
  export PRICEBOT_MIN_PRODUCTS_GUARD="${PRICEBOT_MIN_PRODUCTS_GUARD:-1000}"
  log "SMOKE_MODE=live_db_explicit | db=$PRICEBOT_DB_FILE"
fi

python -m compileall -q .
python -m pytest -q

python - <<'PYSEED'
import os
os.environ.setdefault('PRICEBOT_SKIP_MIGRATION_BACKUP','1')
import database
from services import guided_finder
database.init_db()
with database.get_db_connection() as conn:
    conn.execute("INSERT INTO products(product_id,name,normalized_name,brand,section,category,product_type,use_case,skin_type,body_area,aliases,ocr_keywords,image_ocr_keywords,price,available,quality_status,search_mode) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ('SM1','Smoke Iron','smoke iron','Smoke','supplements','supplements','iron','iron','','','iron','iron','iron','10','متوفر','verified','guided'))
    conn.execute("INSERT INTO products(product_id,name,normalized_name,brand,section,category,product_type,use_case,skin_type,body_area,aliases,ocr_keywords,image_ocr_keywords,price,available,quality_status,search_mode) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ('SM2','Smoke Face Cleanser','smoke face cleanser','Smoke','skin_care','skin_care','face_cleanser','acne','oily_skin','face','cleanser','cleanser','cleanser','20','متوفر','verified','guided'))
    conn.commit()
rows = guided_finder.build_guided_catalog_rows(database.load_products())
database.replace_guided_catalog_index(rows)
PYSEED

log "Rebuild search index"
if ! python tools/rebuild_search_index.py >/tmp/pricebot_smoke_search.log 2>&1; then
  cat /tmp/pricebot_smoke_search.log
  exit 1
fi
log "Rebuild product nav index"
if ! python tools/rebuild_product_nav_index.py >/tmp/pricebot_smoke_nav.log 2>&1; then
  cat /tmp/pricebot_smoke_nav.log
  exit 1
fi
log "Rebuild guided index"
if ! python tools/build_guided_catalog_index.py --db --write-db --report "$TMP/guided_report.xlsx" --min-products "${PRICEBOT_MIN_PRODUCTS_GUARD:-1}" >/tmp/pricebot_smoke_guided.log 2>&1; then
  cat /tmp/pricebot_smoke_guided.log
  exit 1
fi

log "PRICEBOT_V22_4_CLEAN_SMOKE_TEST_OK"
