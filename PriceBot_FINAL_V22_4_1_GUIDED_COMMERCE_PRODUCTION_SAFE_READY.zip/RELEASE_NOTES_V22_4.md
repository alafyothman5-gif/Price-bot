# Release Notes — PriceBot V22.4.1 Clean Production Safe

## سبب الإصدار

الإصدار السابق V22.4 كان يمر محليًا، لكنه لم يكن كافيًا للإنتاج بسبب ملفات قديمة داخل ZIP، deploy غير حقيقي من staging، rollback لا يحذف الملفات الجديدة، واحتمال أن يكون `guided_catalog_index` مبنيًا من Excel لكنه غير مستخدم فعليًا في ردود العملاء.

## الإصلاحات الأساسية

- تنظيف نسخة التسليم من سكربتات deploy القديمة وملفات الأوامر القديمة.
- جعل deploy يعمل من release/staging إلى `/opt/pricebot` بدل تشغيله من داخل مجلد التطبيق.
- استخدام `rsync --delete` مع استثناء الملفات الدائمة.
- rollback نظيف يعيد الكود القديم ولا يترك خليطًا من ملفات قديمة وجديدة.
- الحفاظ على `products_master_v22_ready.xlsx` وعدم حذفه أثناء deploy.
- Guided Commerce يستخدم `guided_catalog_index` فعليًا كمصدر القوائم، مع join على `products` للسعر والتوفر.
- رفض Excel صغير أو غير مطابق في الإنتاج.
- `diagnose_pricebot.py` أصبح read-only عبر SQLite `mode=ro` ولا يستدعي matcher أو conversation state.
- `smoke_test_pricebot.sh` لم يعد يخفي فشل rebuild ويعمل على DB مؤقتة افتراضيًا.
- `restore_last_good_db.py` يوقف الخدمة قبل restore ويتحقق من DB بعد restore.
- production startup يرفض إنشاء DB فارغة إذا كان `PRICEBOT_PRODUCTION_MODE=1` أو `PRICEBOT_STRICT_DB_STARTUP=1`.
- أوامر النظام مثل `السلام عليكم` و`القائمة` و`بحث باسم منتج` تتجاوز أي state قديم.
- brand-only أصبح ديناميكيًا من الكتالوج، مع منع الأكواد الرقمية مثل `123` من التحول إلى brand-only.
- حذف ذكر “بدائل دوائية” من الردود الآلية.
- منع skin type المخالف من الظهور بسبب use_case عام.
- إزالة `DELETE FROM products` من مسارات upload/admin واستبداله بمنطق staging/merge أكثر أمانًا.

## قواعد Guided Commerce

- القوائم العامة لا تعرض إلا المنتجات المتوفرة، ذات السعر، وذات quality/search mode مناسب.
- `exact_only` لا يظهر في القوائم العامة، لكنه يبقى قابلًا للبحث exact.
- `review_only / needs_review / unknown / partial` لا يظهر للعميل.
- القوائم مبنية من `guided_catalog_index` وليس من demo أو heuristic مؤقت.

## الملفات الأساسية

```text
deploy_pricebot_v22_4.sh
backup_pricebot.sh
rollback_pricebot.sh
smoke_test_pricebot.sh
tools/db_safety.py
tools/diagnose_pricebot.py
tools/restore_last_good_db.py
tools/rebuild_search_index.py
tools/rebuild_product_nav_index.py
tools/build_guided_catalog_index.py
acceptance_tests_final_v22_4_db_safety_guided.py
README_DEPLOY_V22_4.md
RELEASE_NOTES_V22_4.md
README_GUIDED_COMMERCE.md
```
