from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import re
import time
from collections import defaultdict, deque
from typing import Any, Deque, Dict, List, Optional, Tuple

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse

import config_env

# Load .env before resolving database path, WhatsApp tokens, or Gemini config.
config_env.load_environment()

import database
import vision_service
from normalizer import clean_query, normalize_text
from services.vision import ai_product_matcher

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN") or os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "الصيدلية")

TEXT_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_TEXT_QUEUE_MAXSIZE", os.getenv("PRICEBOT_QUEUE_MAXSIZE", "2000")) or 2000)
IMAGE_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_IMAGE_QUEUE_MAXSIZE", "500") or 500)
TEXT_WORKERS = int(os.getenv("PRICEBOT_TEXT_WORKERS", "8") or 8)
IMAGE_WORKERS = int(os.getenv("PRICEBOT_IMAGE_WORKERS", "3") or 3)
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "25") or 25)
RATE_LIMIT_IMAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_IMAGES", "6") or 6)
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60") or 60)
IMAGE_CONCURRENCY = int(os.getenv("PRICEBOT_IMAGE_CONCURRENCY", "4") or 4)
IMAGE_TOTAL_TIMEOUT = float(os.getenv("PRICEBOT_IMAGE_TOTAL_TIMEOUT_SECONDS", "18") or 18)

PRICEBOT_CURRENCY = os.getenv("PRICEBOT_CURRENCY", "د.ل")
NOT_FOUND_REPLY = os.getenv("PRICEBOT_NOT_FOUND_REPLY", "غير متوفر")
UNCLEAR_IMAGE_REPLY = os.getenv("PRICEBOT_UNCLEAR_IMAGE_REPLY", "لم أتعرف على المنتج. اكتب الاسم أو أرسل صورة أوضح.")
GREETING_REPLY = os.getenv("PRICEBOT_GREETING_REPLY", "اكتب اسم المنتج أو أرسل صورته.")
REQUIRE_GEMINI = str(os.getenv("PRICEBOT_REQUIRE_GEMINI_MATCHING", "1")).lower() in {"1", "true", "yes", "on"}
STRICT_EVIDENCE_GUARD = str(os.getenv("PRICEBOT_STRICT_TEXT_EVIDENCE_GUARD", "0")).lower() in {"1", "true", "yes", "on"}

app = FastAPI(title="PriceBot WhatsApp Only", docs_url=None, redoc_url=None, openapi_url=None)
text_queue: asyncio.Queue = asyncio.Queue(maxsize=TEXT_QUEUE_MAXSIZE)
image_queue: asyncio.Queue = asyncio.Queue(maxsize=IMAGE_QUEUE_MAXSIZE)
http_client: Optional[httpx.AsyncClient] = None
rate_buckets: Dict[str, Deque[float]] = defaultdict(deque)
image_rate_buckets: Dict[str, Deque[float]] = defaultdict(deque)
user_locks: Dict[str, asyncio.Lock] = {}
user_lock_last_seen: Dict[str, float] = {}
USER_LOCK_TTL_SECONDS = int(os.getenv("PRICEBOT_USER_LOCK_TTL_SECONDS", "900") or 900)
image_semaphore = asyncio.Semaphore(max(1, IMAGE_CONCURRENCY))


def log(event: str, **kw: Any) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["token", "secret", "authorization", "key"]):
            v = "HIDDEN"
        if k in {"phone", "to", "from_", "from"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _extract_candidate_texts(extracted: Dict[str, Any]) -> List[str]:
    parts: List[str] = []
    for key in [
        "query", "primary_title", "product_name", "product_family",
        "foreground_product_text", "foreground_text", "visible_text", "raw_vision_text",
        "brand", "form", "strength", "size", "pack",
    ]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    return parts


def _has_product_text(parts: List[str]) -> bool:
    combined = " ".join(str(p or "") for p in parts).strip()
    if not combined:
        return False
    if re.search(r"\d+\s*(?:mg|mcg|g|gm|ml|iu|%)\b", combined, flags=re.I):
        return True
    generic = {
        "image", "photo", "picture", "box", "pack", "package", "tablet", "tablets",
        "capsule", "capsules", "cream", "gel", "lotion", "syrup", "solution", "oral",
        "bottle", "label", "صوره", "صورة", "علبه", "علبة", "حبوب", "كبسولات", "شراب",
    }
    for token in re.findall(r"[a-zA-Z\u0600-\u06FF0-9%/+-]+", combined.lower()):
        t = token.strip(" -_+/")
        if len(t) >= 3 and t not in generic and re.search(r"[a-zA-Z\u0600-\u06FF]", t):
            return True
    return False


def _price_only(product: Dict[str, Any]) -> str:
    raw_price = str(product.get("price") or "").strip()
    currency = str(product.get("currency") or PRICEBOT_CURRENCY or "").strip()
    if not raw_price:
        return NOT_FOUND_REPLY
    # The owner requested price-only replies. Keep the response compact and avoid
    # product details, alternatives, booking text, catalog links, or buttons.
    return f"{raw_price} {currency}".strip()


def _is_greeting_or_empty(text: str) -> bool:
    n = normalize_text(text or "")
    return n in {
        "", "start", "ابدأ", "ابدا", "السلام عليكم", "سلام", "مرحبا", "اهلا", "هاي",
        "hello", "hi", "menu", "القائمه", "القائمة", "الرئيسيه", "الرئيسية",
    }


def _clean_product_query(text: str) -> str:
    raw = str(text or "").strip()
    cleaned = clean_query(raw).strip()
    return cleaned or raw


# ---------------------------------------------------------------------------
# Final WhatsApp customer UI
# ---------------------------------------------------------------------------
# WhatsApp buttons/lists are used instead of asking customers to type numbers.
# The bot starts with a welcome menu for any first Arabic/English text, then
# searches only after the customer chooses text or image search.
USER_MODES: Dict[str, str] = {}
MAX_LIST_ROWS = int(os.getenv("PRICEBOT_MAX_LIST_ROWS", "10") or 10)
MAX_LIST_MESSAGES = int(os.getenv("PRICEBOT_MAX_LIST_MESSAGES", "3") or 3)

BTN_SEARCH_TEXT = "BTN_SEARCH_TEXT"
BTN_SEARCH_IMAGE = "BTN_SEARCH_IMAGE"
UNSUPPORTED_MEDIA_TOKEN = "__UNSUPPORTED_MEDIA__"

PRODUCT_STOPWORDS = {
    "mg", "mcg", "g", "gm", "ml", "iu", "tab", "tabs", "tablet", "tablets",
    "cap", "caps", "capsule", "capsules", "syrup", "cream", "gel", "spray",
    "drop", "drops", "solution", "oral", "coated", "film", "enteric", "x",
    "pack", "box", "pcs", "piece", "دواء", "الدواء", "علبة", "علبه", "حبوب",
    "كبسول", "كبسولات", "شراب", "مرهم", "كريم", "جل", "قطرة", "بخاخ",
    "اقراص", "أقراص", "شريط", "حبة", "حبه",
}

PRESCRIPTION_HINTS = {
    "rx", "prescription", "doctor", "patient", "diagnosis", "dose", "dosage",
    "clinic", "hospital", "روشتة", "روشته", "وصفة", "وصفه", "دكتور", "طبيب",
    "عيادة", "عياده", "مريض", "المريض", "تشخيص", "جرعة", "الجرعة",
}

_DIGITS_TRANS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def _wa_text(body: str) -> Dict[str, Any]:
    return {"__wa_payload": {"type": "text", "text": {"body": str(body or "")[:3900]}}}


def _welcome_menu_payload() -> Dict[str, Any]:
    body = (
        f"مرحبًا بك في {PHARMACY_NAME} 🌿\n\n"
        "اختر طريقة البحث عن توفر وسعر الدواء أو المنتج:"
    )
    return {
        "__wa_payload": {
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": body},
                "action": {
                    "buttons": [
                        {"type": "reply", "reply": {"id": BTN_SEARCH_TEXT, "title": "بحث نص"}},
                        {"type": "reply", "reply": {"id": BTN_SEARCH_IMAGE, "title": "بحث بصورة"}},
                    ]
                },
            },
        }
    }


def _ask_text_payload() -> Dict[str, Any]:
    return _wa_text("اكتب اسم الدواء أو المنتج الآن.\nمثال: Panadol Extra")


def _ask_image_payload() -> Dict[str, Any]:
    return _wa_text("أرسل صورة واضحة لعلبة الدواء أو المنتج فقط.")


def _unavailable_payload() -> Dict[str, Any]:
    return _wa_text(
        "نعتذر، المنتج غير متوفر حاليًا في الصيدلية.\n"
        "يمكنك البحث باسم آخر أو إرسال صورة واضحة للمنتج."
    )


def _prescription_payload() -> Dict[str, Any]:
    return _wa_text(
        "عذرًا، لا يمكنني قراءة الروشتات الطبية.\n"
        "فضلاً أرسل صورة واضحة لعلبة الدواء أو المنتج فقط."
    )


def _unclear_image_payload() -> Dict[str, Any]:
    return _wa_text(
        "لم أتمكن من قراءة اسم المنتج من الصورة بوضوح.\n"
        "فضلاً أرسل صورة أوضح لواجهة العلبة أو اكتب اسم المنتج."
    )


def _product_name(product: Dict[str, Any]) -> str:
    return str(
        product.get("canonical_display_name")
        or product.get("name")
        or product.get("original_name")
        or ""
    ).strip()


def _product_price(product: Dict[str, Any]) -> str:
    raw_price = str(product.get("price") or "").strip()
    currency = str(product.get("currency") or PRICEBOT_CURRENCY or "").strip()
    if not raw_price:
        return ""
    return f"{raw_price} {currency}".strip()


def _product_available_payload(product: Dict[str, Any]) -> Dict[str, Any]:
    price = _product_price(product)
    if not price:
        return _unavailable_payload()
    return _wa_text(f"متوفر ✅\nالسعر: {price}")


def _short(value: str, limit: int) -> str:
    value = re.sub(r"\s+", " ", str(value or "")).strip()
    if not value:
        return "منتج"
    return value if len(value) <= limit else value[: max(1, limit - 1)].rstrip() + "…"


def _product_tokens(value: Any) -> List[str]:
    n = normalize_text(str(value or ""))
    raw = re.findall(r"[a-zA-Z0-9\u0600-\u06FF]+", n)
    out: List[str] = []
    seen = set()
    for token in raw:
        t = token.strip().lower().translate(_DIGITS_TRANS)
        if not t or t in PRODUCT_STOPWORDS:
            continue
        # Pure numbers such as 200 or 10 are too weak for product matching.
        # They caused unrelated products with the same strength/volume to appear
        # in image search results. Keep brand/product words as the matching core.
        if t.isdigit():
            continue
        if len(t) < 2:
            continue
        if t not in seen:
            out.append(t)
            seen.add(t)
    return out


def _product_haystack(product: Dict[str, Any]) -> str:
    fields = [
        "name", "original_name", "canonical_display_name", "brand", "company",
        "product_family", "active_ingredient", "form", "strength", "size", "pack",
        "barcode", "aliases", "ocr_keywords", "category", "subcategory", "main_section",
        "sub_section", "product_type", "medicine_form",
    ]
    return " ".join(str(product.get(f) or "") for f in fields)


def _dedupe_products(products: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for product in products:
        key = normalize_text(_product_name(product)) + "|" + str(product.get("price") or "").strip()
        if not key.strip("|") or key in seen:
            continue
        seen.add(key)
        out.append(product)
    return out


def _search_available_products(query: str, *, limit: int = 40) -> List[Dict[str, Any]]:
    q = _clean_product_query(query)
    q_norm = normalize_text(q)
    q_tokens = _product_tokens(q)
    q_compact = q_norm.replace(" ", "")
    if not q_norm and not q_tokens:
        return []

    results: List[Dict[str, Any]] = []
    for product in database.load_product_rows(visible_only=True):
        name = _product_name(product)
        if not name:
            continue
        name_norm = normalize_text(name)
        hay = normalize_text(_product_haystack(product))
        hay_tokens = set(_product_tokens(hay))
        hay_compact = hay.replace(" ", "")

        matched_tokens: List[str] = []
        for token in q_tokens:
            if token in hay_tokens or (len(token) >= 4 and token in hay_compact):
                matched_tokens.append(token)

        substring_hit = False
        if q_norm and name_norm:
            substring_hit = q_norm in name_norm or name_norm in q_norm
        if q_compact and len(q_compact) >= 4 and q_compact in hay_compact:
            substring_hit = True

        if not matched_tokens and not substring_hit:
            continue

        name_tokens = _product_tokens(name)
        score = 0
        if name_norm == q_norm:
            score += 10000
        if q_norm and q_norm in name_norm:
            score += 900
        if name_norm and name_norm in q_norm:
            score += 700
        if q_tokens:
            score += len(set(matched_tokens)) * 180
            if len(set(matched_tokens)) == len(set(q_tokens)):
                score += 420
        if q_tokens and name_tokens and q_tokens[0] == name_tokens[0]:
            score += 260
        extra_tokens = [t for t in name_tokens if t not in set(matched_tokens)]
        score -= min(len(extra_tokens) * 10, 120)

        item = dict(product)
        item["_score"] = score
        item["_name_token_count"] = len(name_tokens)
        results.append(item)

    results.sort(key=lambda x: (-int(x.get("_score") or 0), int(x.get("_name_token_count") or 99), len(_product_name(x)), _product_name(x).lower()))
    return _dedupe_products(results)[:limit]


def _should_show_list(query: str, candidates: List[Dict[str, Any]]) -> bool:
    if len(candidates) <= 1:
        return False
    q_norm = normalize_text(query)
    q_tokens = _product_tokens(query)
    exact = [p for p in candidates if normalize_text(_product_name(p)) == q_norm]
    if len(exact) == 1 and len(q_tokens) > 1:
        return False
    if len(q_tokens) <= 2:
        return True
    top = int(candidates[0].get("_score") or 0)
    second = int(candidates[1].get("_score") or 0)
    return (top - second) < 180


def _product_list_payloads(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payloads: List[Dict[str, Any]] = []
    shown_limit = max(1, MAX_LIST_ROWS) * max(1, MAX_LIST_MESSAGES)
    candidates = candidates[:shown_limit]
    if not candidates:
        return [_unavailable_payload()]

    chunks = [candidates[i:i + MAX_LIST_ROWS] for i in range(0, len(candidates), MAX_LIST_ROWS)]
    for idx, chunk in enumerate(chunks, start=1):
        rows = []
        for product in chunk:
            pid = int(product.get("id") or 0)
            name = _product_name(product)
            price = _product_price(product)
            rows.append({
                "id": f"PROD:{pid}",
                "title": _short(name, 24),
                "description": _short(f"{price} - {name}" if price else name, 72),
            })
        body = "وجدت أكثر من منتج متوفر بهذا الاسم. اختر المنتج المطلوب من القائمة:"
        if len(chunks) > 1:
            body += f"\nالقائمة {idx} من {len(chunks)}"
        payloads.append({
            "__wa_payload": {
                "type": "interactive",
                "interactive": {
                    "type": "list",
                    "body": {"text": body},
                    "action": {"button": "اختر المنتج", "sections": [{"title": "المنتجات المتوفرة", "rows": rows}]},
                },
            }
        })
    return payloads


def _looks_like_prescription(text: str) -> bool:
    n = normalize_text(text)
    return any(hint in n for hint in PRESCRIPTION_HINTS)


def _is_search_text_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_TEXT), "بحث نص", "بحث بنص", "نص", "1"}


def _is_search_image_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_IMAGE), "بحث صورة", "بحث بصورة", "صورة", "صوره", "2"}


def _is_product_selection(raw: str) -> bool:
    return str(raw or "").strip().startswith("PROD:")


async def _match_with_gemini(query: str, *, phone: str = "", source: str = "whatsapp_text") -> Optional[Dict[str, Any]]:
    query = str(query or "").strip()
    if not query:
        return None
    if REQUIRE_GEMINI and not config_env.resolve_openrouter_api_key():
        log("GEMINI_MATCHING_DISABLED", reason="missing_openrouter_api_key")
        return None

    ai_hit = await ai_product_matcher.match_extracted_text_to_product(query)
    if not bool(ai_hit.get("matched")):
        log("GEMINI_MATCH_FALSE", reason=ai_hit.get("reason"), source=source)
        return None

    try:
        product_id = int(ai_hit.get("product_id") or 0)
    except Exception:
        product_id = 0
    if not product_id:
        log("GEMINI_MATCH_REJECTED", reason="missing_product_id", source=source)
        return None

    product = database.get_product(product_id)
    if not product or not database.product_visible(product, guided=False):
        log("GEMINI_MATCH_REJECTED", reason="product_not_visible", product_id=product_id, source=source)
        return None

    # Gemini is the primary/only matcher. The optional local evidence guard is
    # disabled by default because bilingual pharmacy queries can be valid even
    # when their tokens do not overlap exactly with the Excel product name.
    if STRICT_EVIDENCE_GUARD:
        evidence = ai_product_matcher.validate_text_evidence_for_match(
            query,
            product.get("canonical_display_name") or product.get("name") or "",
        )
        if not evidence.get("passed"):
            log("GEMINI_MATCH_EVIDENCE_REJECTED", product_id=product_id, reason=evidence.get("reason"), source=source)
            return None

    try:
        database.record_search_log(
            product_id=product_id,
            product_name=product.get("canonical_display_name") or product.get("name") or "",
            user_id=phone,
            source=source,
        )
    except Exception as exc:
        log("SEARCH_LOG_WARNING", error=repr(exc))
    return product


async def process_text(phone: str, text: str) -> Any:
    raw = str(text or "").strip()

    if raw == UNSUPPORTED_MEDIA_TOKEN:
        return _prescription_payload()

    if _is_product_selection(raw):
        try:
            pid = int(raw.split(":", 1)[1])
        except Exception:
            pid = 0
        product = database.get_product(pid) if pid else None
        USER_MODES[phone] = "awaiting_text"
        if product and database.product_visible(product, guided=False):
            log("UI_PRODUCT_SELECTED", phone=phone, product_id=pid)
            return _product_available_payload(product)
        return _unavailable_payload()

    if _is_search_text_button(raw):
        USER_MODES[phone] = "awaiting_text"
        return _ask_text_payload()

    if _is_search_image_button(raw):
        USER_MODES[phone] = "awaiting_image"
        return _ask_image_payload()

    # First contact / any normal Arabic or English text before choosing a mode:
    # show the welcome menu with buttons, as requested.
    if USER_MODES.get(phone) != "awaiting_text":
        USER_MODES[phone] = "idle"
        return _welcome_menu_payload()

    query = _clean_product_query(raw)
    if not query:
        return _ask_text_payload()
    if _looks_like_prescription(query):
        return _prescription_payload()

    candidates = _search_available_products(query, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES)
    if not candidates:
        log("UI_TEXT_NOT_AVAILABLE", phone=phone, query=query[:120])
        USER_MODES[phone] = "awaiting_text"
        return _unavailable_payload()

    if _should_show_list(query, candidates):
        log("UI_TEXT_LIST", phone=phone, query=query[:120], count=len(candidates))
        return _product_list_payloads(candidates)

    product = candidates[0]
    USER_MODES[phone] = "awaiting_text"
    log("UI_TEXT_MATCH", phone=phone, product_id=product.get("id"), name=_product_name(product))
    return _product_available_payload(product)



def _vision_search_text(extracted: Dict[str, Any]) -> str:
    """Build a clean product-focused query from Gemini/Vision output.

    Do not search using the full raw OCR dump first. Raw label text contains
    weak tokens like 200, cream, balm, dermatologico, etc.; using it caused
    unrelated product lists. Prefer structured product fields and only fall back
    to raw text when nothing else exists.
    """
    priority_keys = [
        "query", "product_name", "primary_title", "product_family",
        "brand", "foreground_product_text", "foreground_text",
        "form", "strength", "size",
    ]
    parts: List[str] = []
    for key in priority_keys:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    focused = " ".join(parts).strip()
    if _product_tokens(focused):
        return focused
    fallback = str((extracted or {}).get("visible_text") or (extracted or {}).get("raw_vision_text") or "").strip()
    return fallback


def _strong_image_candidates(evidence_text: str, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Keep only products strongly supported by the image text.

    For image matching, a product must share distinctive tokens with the
    detected package name. A shared strength/volume number or generic dosage
    form is not enough.
    """
    q_tokens = _product_tokens(evidence_text)
    distinctive = [t for t in q_tokens if len(t) >= 3]
    if not distinctive:
        return []

    filtered: List[Dict[str, Any]] = []
    required = 1 if len(distinctive) == 1 else 2

    for product in candidates:
        hay_tokens = set(_product_tokens(_product_haystack(product)))
        name_tokens = set(_product_tokens(_product_name(product)))
        hit = [t for t in distinctive if t in hay_tokens]
        name_hit = [t for t in distinctive if t in name_tokens]

        if len(hit) >= required or (distinctive and distinctive[0] in name_tokens and len(hit) >= 1):
            item = dict(product)
            item["_image_hits"] = len(hit)
            item["_image_name_hits"] = len(name_hit)
            # Promote products matching more visible package tokens.
            item["_score"] = int(item.get("_score") or 0) + len(hit) * 350 + len(name_hit) * 250
            filtered.append(item)

    filtered.sort(key=lambda x: (-int(x.get("_image_hits") or 0), -int(x.get("_image_name_hits") or 0), -int(x.get("_score") or 0), len(_product_name(x))))
    return _dedupe_products(filtered)

async def process_image(phone: str, media_id: str) -> Any:
    log("IMAGE_RECEIVED", phone=phone)
    USER_MODES[phone] = "awaiting_image"
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return _unclear_image_payload()

    image_hash = hashlib.sha256(image_bytes or b"").hexdigest() if image_bytes else ""
    if not image_bytes:
        return _unclear_image_payload()

    try:
        cached = database.get_image_cache(image_hash=image_hash, media_id=media_id)
        if cached and cached.get("matched_product_id"):
            product = database.get_product(int(cached.get("matched_product_id") or 0))
            if product and database.product_visible(product, guided=False):
                log("IMAGE_EXACT_CACHE_HIT", product_id=product.get("id"))
                return _product_available_payload(product)
    except Exception as exc:
        log("IMAGE_CACHE_WARNING", error=repr(exc))

    try:
        async with image_semaphore:
            extracted = await asyncio.wait_for(
                vision_service.extract_product_from_image(image_bytes, mime),
                timeout=IMAGE_TOTAL_TIMEOUT,
            )
    except asyncio.TimeoutError:
        log("VISION_TIMEOUT", phone=phone)
        return _unclear_image_payload()
    except Exception as exc:
        log("VISION_ERROR", error=repr(exc))
        return _unclear_image_payload()

    parts = _extract_candidate_texts(extracted)
    evidence_text = _vision_search_text(extracted)
    raw_evidence_text = " ".join(parts).strip()
    if not evidence_text and not raw_evidence_text:
        return _prescription_payload()
    if _looks_like_prescription(evidence_text) or _looks_like_prescription(raw_evidence_text):
        log("VISION_PRESCRIPTION_REJECTED", text=(evidence_text or raw_evidence_text)[:160])
        return _prescription_payload()
    if extracted.get("status") != "OK" and not _has_product_text(parts):
        log("VISION_REJECTED", status=extracted.get("status"))
        return _prescription_payload()

    log("UI_IMAGE_EVIDENCE", text=evidence_text[:180])
    raw_candidates = _search_available_products(evidence_text, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES)
    candidates = _strong_image_candidates(evidence_text, raw_candidates)
    if not candidates:
        try:
            database.record_learning_event(
                customer_query=str(extracted.get("query") or ""),
                vision_text=evidence_text[:1000],
                decision="LOCAL_NO_MATCH",
                reason=str(extracted.get("status") or "no_match"),
                media_id=media_id,
                query_slots={**(extracted or {}), "image_hash": image_hash},
            )
        except Exception:
            pass
        return _unavailable_payload()

    # Image search should be strict. If there are several strong matches, send
    # one focused list only; do not flood the customer with unrelated pages.
    if len(candidates) > 1 and _should_show_list(evidence_text, candidates):
        focused = candidates[:MAX_LIST_ROWS]
        log("UI_IMAGE_LIST", phone=phone, text=evidence_text[:140], count=len(focused))
        return _product_list_payloads(focused[:MAX_LIST_ROWS])[:1]

    product = candidates[0]
    log("UI_IMAGE_MATCH", product_id=product.get("id"), name=_product_name(product))
    try:
        database.set_image_cache(
            image_hash=image_hash,
            media_id=media_id,
            extracted_slots=extracted or {},
            matched_product_id=int(product.get("id") or 0),
            decision="UI_IMAGE_MATCHED",
            confidence=str(extracted.get("confidence") or ""),
        )
    except Exception as exc:
        log("IMAGE_CACHE_SET_WARNING", error=repr(exc))
    return _product_available_payload(product)


def rate_limit_ok(phone: str, *, image: bool = False) -> bool:
    now = time.time()
    bucket = image_rate_buckets[phone] if image else rate_buckets[phone]
    while bucket and now - bucket[0] > RATE_LIMIT_WINDOW:
        bucket.popleft()
    limit = RATE_LIMIT_IMAGES if image else RATE_LIMIT_MESSAGES
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def cleanup_user_locks() -> None:
    now = time.time()
    stale = [phone for phone, ts in user_lock_last_seen.items() if now - ts > USER_LOCK_TTL_SECONDS]
    for phone in stale:
        lock = user_locks.get(phone)
        if lock is not None and lock.locked():
            continue
        user_locks.pop(phone, None)
        user_lock_last_seen.pop(phone, None)


def get_user_lock(phone: str) -> asyncio.Lock:
    cleanup_user_locks()
    lock = user_locks.get(phone)
    if lock is None:
        lock = asyncio.Lock()
        user_locks[phone] = lock
    user_lock_last_seen[phone] = time.time()
    return lock


def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET or not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


async def send_whatsapp_message(to_number: str, content: Any) -> bool:
    if not content:
        return False

    # Allow process_text/process_image to return multiple interactive list
    # messages when a generic name has more than 10 matching products.
    if isinstance(content, list):
        ok = True
        for item in content:
            ok = bool(await send_whatsapp_message(to_number, item)) and ok
            await asyncio.sleep(0.15)
        return ok

    if isinstance(content, dict) and "__wa_payload" in content:
        payload = dict(content["__wa_payload"])
        payload["messaging_product"] = "whatsapp"
        payload["to"] = to_number
    else:
        text = str(content or "")
        payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": text[:3900]}}

    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number)
        return True
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_ERROR", status=resp.status_code, response=resp.text[:500])
            return False
        return True
    except Exception as exc:
        log("SEND_EXCEPTION", error=repr(exc))
        return False


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not META_TOKEN:
        return b"", "image/jpeg"
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    assert http_client is not None
    meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
    meta.raise_for_status()
    info = meta.json()
    url = info.get("url", "")
    mime = info.get("mime_type", "image/jpeg")
    if not url:
        return b"", mime
    data = await http_client.get(url, headers=headers, timeout=20)
    data.raise_for_status()
    return data.content, mime


def extract_messages(payload: Dict[str, Any]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        br = inter.get("button_reply") or {}
                        text = br.get("id") or br.get("title") or ""
                    elif inter.get("type") == "list_reply":
                        lr = inter.get("list_reply") or {}
                        text = lr.get("id") or lr.get("title") or ""
                elif mtype in {"document", "audio", "video", "sticker"}:
                    text = UNSUPPORTED_MEDIA_TOKEN
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out


async def worker(worker_id: int, worker_queue: asyncio.Queue, queue_name: str) -> None:
    while True:
        item = await worker_queue.get()
        try:
            phone = item["phone"]
            is_image = bool(item.get("type") == "image" or item.get("media_id"))
            if not rate_limit_ok(phone, image=is_image):
                await send_whatsapp_message(phone, "طلبات كثيرة بسرعة. حاول بعد قليل.")
                continue
            if item.get("id") and not database.mark_processed(item.get("id")):
                continue
            async with get_user_lock(phone):
                user_lock_last_seen[phone] = time.time()
                if is_image:
                    reply = await process_image(phone, item.get("media_id", ""))
                else:
                    log("MESSAGE_RECEIVED", phone=phone, text=str(item.get("text", ""))[:100])
                    reply = await process_text(phone, item.get("text", ""))
                await send_whatsapp_message(phone, reply)
                user_lock_last_seen[phone] = time.time()
        except Exception as exc:
            log("WORKER_ERROR", worker=f"{queue_name}-{worker_id}", error=repr(exc))
            try:
                await send_whatsapp_message(item.get("phone", ""), "حدث خطأ. حاول مرة أخرى.")
            except Exception:
                pass
        finally:
            worker_queue.task_done()


@app.on_event("startup")
async def startup() -> None:
    global http_client
    database.init_db(run_production_guard=True)
    try:
        log("DB_PERFORMANCE_HARDENING", **database.apply_performance_hardening())
    except Exception as exc:
        log("DB_PERFORMANCE_HARDENING_WARNING", error=repr(exc))
    try:
        log("FINAL_SCHEMA", **database.ensure_final_hardening_schema())
    except Exception as exc:
        log("FINAL_SCHEMA_WARNING", error=repr(exc))
    try:
        log("RUNTIME_CLEANUP", **database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30)))
    except Exception as exc:
        log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
    http_client = httpx.AsyncClient()
    for i in range(TEXT_WORKERS):
        asyncio.create_task(worker(i + 1, text_queue, "text"))
    for i in range(IMAGE_WORKERS):
        asyncio.create_task(worker(i + 1, image_queue, "image"))
    log(
        "PRICEBOT_WHATSAPP_ONLY_STARTED",
        products=database.count_products(),
        text_workers=TEXT_WORKERS,
        image_workers=IMAGE_WORKERS,
        gemini="configured" if config_env.resolve_openrouter_api_key() else "missing_key",
        vision="enabled" if config_env.vision_enabled() else config_env.vision_disabled_reason(),
    )


@app.on_event("shutdown")
async def shutdown() -> None:
    if http_client:
        await http_client.aclose()


@app.get("/health")
def health() -> Dict[str, Any]:
    return {
        "ok": True,
        "service": "pricebot-whatsapp-only",
        "products_count": database.count_products(),
        "text_queue_size": text_queue.qsize(),
        "image_queue_size": image_queue.qsize(),
        "workers": TEXT_WORKERS + IMAGE_WORKERS,
        "gemini_configured": bool(config_env.resolve_openrouter_api_key()),
        "vision_enabled": config_env.vision_enabled(),
        "web_pages_enabled": False,
        "final_ui_enabled": True,
        "final_ui_version": "v3_confirm_learn_alias",
    }


@app.get("/")
def root() -> Dict[str, Any]:
    return {"ok": True, "service": "pricebot-whatsapp-only", "webhook": "/webhook", "web_pages_enabled": False, "final_ui_enabled": True}


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


def enqueue_message_fast(msg: Dict[str, str]) -> bool:
    try:
        queue = image_queue if (msg.get("type") == "image" or msg.get("media_id")) else text_queue
        queue.put_nowait(msg)
        return True
    except asyncio.QueueFull:
        log("QUEUE_FULL", phone=msg.get("phone"))
        return False


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    body = await request.body()
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        return PlainTextResponse("bad signature", status_code=403)
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json"}, status_code=400)
    queued = 0
    dropped = 0
    for msg in extract_messages(payload):
        if enqueue_message_fast(msg):
            queued += 1
        else:
            dropped += 1
    return {"ok": True, "queued": queued, "busy": dropped, "mode": "whatsapp_only"}


# ---------------------------------------------------------------------------
# V3 final customer flow: stateful text search + confirmation learning
# ---------------------------------------------------------------------------
# This block intentionally overrides the V2 process_text/process_image/search
# functions above. It keeps the WhatsApp-only deployment, but fixes:
# - generic text names return clickable lists;
# - specific text names return availability/price directly;
# - close aliases/synonyms ask for confirmation and then learn;
# - image OCR/Gemini matches ask confirmation instead of returning wrong lists;
# - confirmed image/text aliases are saved for future customers.

USER_CONFIRMATIONS: Dict[str, Dict[str, Any]] = {}
BTN_CONFIRM_YES = "CONFIRM_YES"
BTN_CONFIRM_NO = "CONFIRM_NO"
FINAL_UI_VERSION = "v3_confirm_learn_alias"


def _is_yes_text(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_CONFIRM_YES), "نعم", "اي", "أيوة", "ايوة", "تمام", "صح", "yes", "y", "ok", "1"}


def _is_no_text(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_CONFIRM_NO), "لا", "لأ", "مش هو", "غلط", "no", "n", "0"}


def _searchable_alias_map() -> Dict[int, List[str]]:
    out: Dict[int, List[str]] = {}
    try:
        for row in database.load_product_alias_rows(active_only=True):
            pid = int(row.get("product_id") or 0)
            alias = str(row.get("alias") or "").strip()
            if pid and alias:
                out.setdefault(pid, []).append(alias)
    except Exception as exc:
        log("ALIAS_ROWS_LOAD_WARNING", error=repr(exc))
    return out


def _split_alias_blob(value: Any) -> List[str]:
    text = str(value or "")
    parts = re.split(r"[|;,،]+", text)
    return [p.strip() for p in parts if p and p.strip()]


def _all_product_text(product: Dict[str, Any], alias_map: Optional[Dict[int, List[str]]] = None) -> str:
    pid = int(product.get("id") or 0)
    fields = [
        "name", "original_name", "canonical_display_name", "brand", "company",
        "product_family", "active_ingredient", "form", "strength", "size", "pack",
        "barcode", "aliases", "ocr_keywords", "category", "subcategory", "main_section",
        "sub_section", "product_type", "medicine_form",
    ]
    parts = [str(product.get(f) or "") for f in fields]
    if alias_map and pid in alias_map:
        parts.extend(alias_map.get(pid) or [])
    parts.extend(_split_alias_blob(product.get("aliases")))
    parts.extend(_split_alias_blob(product.get("ocr_keywords")))
    return " ".join(parts)


def _search_available_products(query: str, *, limit: int = 80) -> List[Dict[str, Any]]:
    """Robust visible-product search for text and confirmed image evidence.

    The function deliberately favors brand/name token overlap and keeps generic
    names such as Panadol broad so the UI can show a clickable list.
    """
    q = _clean_product_query(query)
    q_norm = normalize_text(q)
    q_tokens = _product_tokens(q)
    q_compact = q_norm.replace(" ", "")
    if not q_norm and not q_tokens:
        return []

    alias_map = _searchable_alias_map()
    results: List[Dict[str, Any]] = []
    q_set = set(q_tokens)

    for product in database.load_product_rows(visible_only=True):
        name = _product_name(product)
        if not name:
            continue
        name_norm = normalize_text(name)
        name_tokens = _product_tokens(name)
        hay = normalize_text(_all_product_text(product, alias_map))
        hay_compact = hay.replace(" ", "")
        hay_tokens = set(_product_tokens(hay))

        matched_tokens: List[str] = []
        for token in q_tokens:
            if token in hay_tokens or (len(token) >= 4 and token in hay_compact):
                matched_tokens.append(token)

        substring_hit = False
        if q_norm and name_norm:
            substring_hit = q_norm in name_norm or name_norm in q_norm
        if q_compact and len(q_compact) >= 4 and q_compact in hay_compact:
            substring_hit = True

        if not matched_tokens and not substring_hit:
            continue

        score = 0
        if name_norm == q_norm:
            score += 20000
        if q_norm and q_norm in name_norm:
            score += 1600
        if name_norm and name_norm in q_norm:
            score += 1400
        if q_tokens:
            unique_hits = len(set(matched_tokens))
            score += unique_hits * 280
            if unique_hits == len(q_set):
                score += 900
        if q_tokens and name_tokens and q_tokens[0] == name_tokens[0]:
            score += 900
        if len(q_tokens) == 1 and name_tokens:
            token = q_tokens[0]
            if name_tokens[0] == token:
                score += 1200
            elif token in name_tokens:
                score += 700
        # Prefer concise exact products, but do not hide variants for generic names.
        extra_tokens = [t for t in name_tokens if t not in set(matched_tokens)]
        score -= min(len(extra_tokens) * 6, 90)

        item = dict(product)
        item["_score"] = score
        item["_name_token_count"] = len(name_tokens)
        item["_matched_tokens"] = sorted(set(matched_tokens))
        results.append(item)

    results.sort(key=lambda x: (-int(x.get("_score") or 0), int(x.get("_name_token_count") or 99), len(_product_name(x)), _product_name(x).lower()))
    return _dedupe_products(results)[:limit]


def _exact_visible_product(query: str, candidates: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    q_norm = normalize_text(query)
    exact = [p for p in candidates if normalize_text(_product_name(p)) == q_norm]
    return exact[0] if len(exact) == 1 else None


def _is_generic_name_query(query: str, candidates: List[Dict[str, Any]]) -> bool:
    q_tokens = _product_tokens(query)
    if len(candidates) <= 1:
        return False
    # One/two-token brand or family names are intentionally broad.
    if len(q_tokens) <= 2:
        return True
    top = int(candidates[0].get("_score") or 0)
    second = int(candidates[1].get("_score") or 0)
    return (top - second) < 180


def _should_direct_match(query: str, product: Dict[str, Any], candidates: List[Dict[str, Any]]) -> bool:
    q_norm = normalize_text(query)
    name_norm = normalize_text(_product_name(product))
    q_tokens = _product_tokens(query)
    if not product:
        return False
    if name_norm == q_norm:
        return True
    if _is_generic_name_query(query, candidates):
        return False
    if len(q_tokens) >= 2 and q_norm and (q_norm in name_norm or name_norm in q_norm):
        return True
    top = int(product.get("_score") or 0)
    second = int(candidates[1].get("_score") or 0) if len(candidates) > 1 else 0
    return top >= 2200 and (top - second) >= 450


def _memory_lookup_product(query: str) -> Optional[Dict[str, Any]]:
    try:
        hit = database.lookup_safe_text_memory(query)
        if hit and hit.get("product"):
            product = hit.get("product")
            if product and database.product_visible(product, guided=False):
                return product
    except Exception as exc:
        log("MEMORY_LOOKUP_WARNING", error=repr(exc))
    try:
        alias_hit = database.lookup_product_by_alias_exact([query], ignore_articles=True)
        if alias_hit.get("status") == "EXACT_ALIAS_MATCH" and alias_hit.get("product"):
            product = alias_hit.get("product")
            if product and database.product_visible(product, guided=False):
                return product
    except Exception as exc:
        log("ALIAS_LOOKUP_WARNING", error=repr(exc))
    return None


def _confirm_payload(product: Dict[str, Any], query: str) -> Dict[str, Any]:
    name = _product_name(product)
    body = f"هل تقصد هذا المنتج؟\n{name}\n\nاختر نعم للتأكيد أو لا لإعادة البحث."
    return {
        "__wa_payload": {
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": body[:1000]},
                "action": {
                    "buttons": [
                        {"type": "reply", "reply": {"id": BTN_CONFIRM_YES, "title": "نعم"}},
                        {"type": "reply", "reply": {"id": BTN_CONFIRM_NO, "title": "لا"}},
                    ]
                },
            },
        }
    }


def _store_pending_confirmation(phone: str, product: Dict[str, Any], query: str, *, source: str, image_hash: str = "", media_id: str = "", extracted: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    USER_CONFIRMATIONS[phone] = {
        "product_id": int(product.get("id") or 0),
        "query": str(query or "")[:1000],
        "source": source,
        "image_hash": image_hash,
        "media_id": media_id,
        "extracted": dict(extracted or {}),
        "ts": time.time(),
    }
    return _confirm_payload(product, query)


def _specific_memory_phrase(text: str) -> str:
    toks = _product_tokens(text)
    if not toks:
        return str(text or "").strip()[:200]
    return " ".join(toks[:8])[:200]


def _learn_confirmed_mapping(phone: str, product: Dict[str, Any], pending: Dict[str, Any]) -> None:
    pid = int(product.get("id") or 0)
    if not pid:
        return
    raw_query = str(pending.get("query") or "").strip()
    source = str(pending.get("source") or "customer_confirmed")
    extracted = pending.get("extracted") or {}
    phrases: List[str] = []
    if raw_query:
        phrases.append(raw_query)
        phrases.append(_specific_memory_phrase(raw_query))
    for key in ["query", "product_name", "primary_title", "product_family", "foreground_product_text", "brand"]:
        value = str((extracted or {}).get(key) or "").strip()
        if value:
            phrases.append(value)
            phrases.append(_specific_memory_phrase(value))
    # Deduplicate before writing.
    seen = set()
    phrases = [p for p in phrases if p and not (normalize_text(p) in seen or seen.add(normalize_text(p)))]

    for phrase in phrases:
        try:
            database.add_safe_text_memory(phrase, pid, source=f"whatsapp_confirmed_{source}", user_key=phone)
        except Exception as exc:
            log("SAFE_MEMORY_SAVE_WARNING", error=repr(exc), phrase=phrase[:80])
        try:
            database.append_product_alias_or_ocr(pid, phrase, field="aliases")
            database.append_product_alias_or_ocr(pid, phrase, field="ocr_keywords")
        except Exception as exc:
            log("PRODUCT_ALIAS_SAVE_WARNING", error=repr(exc), phrase=phrase[:80])

    try:
        if pending.get("image_hash"):
            database.set_image_cache(
                image_hash=str(pending.get("image_hash") or ""),
                media_id=str(pending.get("media_id") or ""),
                extracted_slots=extracted or {"query": raw_query},
                matched_product_id=pid,
                decision="CUSTOMER_CONFIRMED_IMAGE_MATCH" if source.startswith("image") else "CUSTOMER_CONFIRMED_TEXT_MATCH",
                confidence="customer_confirmed",
            )
    except Exception as exc:
        log("CONFIRMED_IMAGE_CACHE_WARNING", error=repr(exc))

    try:
        database.record_search_log(product_id=pid, product_name=_product_name(product), user_id=phone, source=f"confirmed_{source}")
    except Exception:
        pass
    try:
        database.invalidate_runtime_caches()
    except Exception:
        pass


async def _handle_pending_confirmation(phone: str, raw: str) -> Optional[Any]:
    pending = USER_CONFIRMATIONS.get(phone)
    if not pending:
        return None
    # Keep pending for a reasonable period only.
    if time.time() - float(pending.get("ts") or 0) > 900:
        USER_CONFIRMATIONS.pop(phone, None)
        return None
    if _is_yes_text(raw):
        product = database.get_product(int(pending.get("product_id") or 0))
        USER_CONFIRMATIONS.pop(phone, None)
        if product and database.product_visible(product, guided=False):
            _learn_confirmed_mapping(phone, product, pending)
            USER_MODES[phone] = "awaiting_text"
            return _product_available_payload(product)
        return _unavailable_payload()
    if _is_no_text(raw):
        try:
            database.reject_safe_text_memory(str(pending.get("query") or ""), int(pending.get("product_id") or 0))
        except Exception:
            pass
        USER_CONFIRMATIONS.pop(phone, None)
        USER_MODES[phone] = "awaiting_text"
        return _wa_text("تمام. اكتب الاسم الصحيح للمنتج أو أرسل صورة أوضح للعلبة.")
    return None


def _resolve_text_to_reply(phone: str, query: str) -> Any:
    query = _clean_product_query(query)
    if not query:
        return _ask_text_payload()
    if _looks_like_prescription(query):
        return _prescription_payload()

    memory_product = _memory_lookup_product(query)
    if memory_product:
        USER_MODES[phone] = "awaiting_text"
        log("UI_TEXT_MEMORY_MATCH", phone=phone, product_id=memory_product.get("id"), query=query[:120])
        return _product_available_payload(memory_product)

    candidates = _search_available_products(query, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES)
    if candidates:
        exact = _exact_visible_product(query, candidates)
        if exact:
            USER_MODES[phone] = "awaiting_text"
            log("UI_TEXT_EXACT_MATCH", phone=phone, product_id=exact.get("id"), query=query[:120])
            return _product_available_payload(exact)
        if _is_generic_name_query(query, candidates):
            log("UI_TEXT_GENERIC_LIST", phone=phone, query=query[:120], count=len(candidates))
            return _product_list_payloads(candidates)
        top = candidates[0]
        if _should_direct_match(query, top, candidates):
            USER_MODES[phone] = "awaiting_text"
            log("UI_TEXT_DIRECT_MATCH", phone=phone, product_id=top.get("id"), query=query[:120])
            return _product_available_payload(top)
        log("UI_TEXT_CONFIRMATION", phone=phone, product_id=top.get("id"), query=query[:120])
        return _store_pending_confirmation(phone, top, query, source="text")

    # Last chance: ask Gemini matcher. Do not display price directly; confirm first.
    # This handles commercial names/aliases that are not literal Excel names.
    # The async Gemini matcher is used by the async process_text wrapper below.
    return None


async def process_text(phone: str, text: str) -> Any:
    raw = str(text or "").strip()

    pending_reply = await _handle_pending_confirmation(phone, raw)
    if pending_reply is not None:
        return pending_reply

    if raw == UNSUPPORTED_MEDIA_TOKEN:
        return _prescription_payload()

    if _is_product_selection(raw):
        try:
            pid = int(raw.split(":", 1)[1])
        except Exception:
            pid = 0
        product = database.get_product(pid) if pid else None
        USER_MODES[phone] = "awaiting_text"
        if product and database.product_visible(product, guided=False):
            log("UI_PRODUCT_SELECTED", phone=phone, product_id=pid)
            return _product_available_payload(product)
        return _unavailable_payload()

    if _is_search_text_button(raw):
        USER_MODES[phone] = "awaiting_text"
        USER_CONFIRMATIONS.pop(phone, None)
        return _ask_text_payload()

    if _is_search_image_button(raw):
        USER_MODES[phone] = "awaiting_image"
        USER_CONFIRMATIONS.pop(phone, None)
        return _ask_image_payload()

    if USER_MODES.get(phone) != "awaiting_text":
        USER_MODES[phone] = "idle"
        USER_CONFIRMATIONS.pop(phone, None)
        return _welcome_menu_payload()

    local_reply = _resolve_text_to_reply(phone, raw)
    if local_reply is not None:
        return local_reply

    try:
        gemini_product = await _match_with_gemini(raw, phone=phone, source="text_confirmation_candidate")
    except Exception as exc:
        log("TEXT_GEMINI_CANDIDATE_ERROR", error=repr(exc))
        gemini_product = None
    if gemini_product:
        return _store_pending_confirmation(phone, gemini_product, raw, source="text_gemini")

    USER_MODES[phone] = "awaiting_text"
    log("UI_TEXT_NOT_AVAILABLE", phone=phone, query=str(raw)[:120])
    return _unavailable_payload()


def _vision_search_text(extracted: Dict[str, Any]) -> str:
    """Build a focused but complete image query.

    V2 sometimes used only `brand` (e.g. RILASTIL) and ignored visible product
    family text (e.g. XEROLACT PB). V3 starts with structured fields, but when
    there are fewer than two strong product tokens it adds foreground/visible
    text to capture the actual product line.
    """
    primary_keys = ["query", "product_name", "primary_title", "product_family", "brand"]
    secondary_keys = ["foreground_product_text", "foreground_text", "visible_text", "raw_vision_text", "form", "strength", "size"]
    parts: List[str] = []
    for key in primary_keys:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    focused = " ".join(parts).strip()
    if len(_product_tokens(focused)) < 2:
        for key in secondary_keys:
            value = str((extracted or {}).get(key) or "").strip()
            if value and value not in parts:
                parts.append(value)
    # Keep token sequence but remove purely generic/number tokens.
    tokens = _product_tokens(" ".join(parts))
    return " ".join(tokens[:12]).strip() or " ".join(parts).strip()


def _strong_image_candidates(evidence_text: str, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    q_tokens = _product_tokens(evidence_text)
    distinctive = [t for t in q_tokens if len(t) >= 3]
    if not distinctive:
        return []
    filtered: List[Dict[str, Any]] = []
    # Images should be strict, but allow one very distinctive token when the
    # product family is uncommon (xerolact, bestra, depakin, etc.).
    required = 1 if len(distinctive) <= 2 else 2
    for product in candidates:
        hay_tokens = set(_product_tokens(_all_product_text(product, _searchable_alias_map())))
        name_tokens = set(_product_tokens(_product_name(product)))
        hit = [t for t in distinctive if t in hay_tokens]
        name_hit = [t for t in distinctive if t in name_tokens]
        if len(hit) >= required or len(name_hit) >= 1:
            item = dict(product)
            item["_image_hits"] = len(hit)
            item["_image_name_hits"] = len(name_hit)
            item["_score"] = int(item.get("_score") or 0) + len(hit) * 400 + len(name_hit) * 300
            filtered.append(item)
    filtered.sort(key=lambda x: (-int(x.get("_image_hits") or 0), -int(x.get("_image_name_hits") or 0), -int(x.get("_score") or 0), len(_product_name(x))))
    return _dedupe_products(filtered)


async def process_image(phone: str, media_id: str) -> Any:
    log("IMAGE_RECEIVED", phone=phone)
    USER_MODES[phone] = "awaiting_image"
    USER_CONFIRMATIONS.pop(phone, None)
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return _unclear_image_payload()
    image_hash = hashlib.sha256(image_bytes or b"").hexdigest() if image_bytes else ""
    if not image_bytes:
        return _unclear_image_payload()

    try:
        cached = database.get_image_cache(image_hash=image_hash, media_id=media_id)
        if cached and cached.get("matched_product_id"):
            product = database.get_product(int(cached.get("matched_product_id") or 0))
            if product and database.product_visible(product, guided=False):
                log("IMAGE_EXACT_CACHE_HIT", product_id=product.get("id"))
                return _product_available_payload(product)
    except Exception as exc:
        log("IMAGE_CACHE_WARNING", error=repr(exc))

    try:
        async with image_semaphore:
            extracted = await asyncio.wait_for(
                vision_service.extract_product_from_image(image_bytes, mime),
                timeout=IMAGE_TOTAL_TIMEOUT,
            )
    except asyncio.TimeoutError:
        log("VISION_TIMEOUT", phone=phone)
        return _unclear_image_payload()
    except Exception as exc:
        log("VISION_ERROR", error=repr(exc))
        return _unclear_image_payload()

    parts = _extract_candidate_texts(extracted)
    evidence_text = _vision_search_text(extracted)
    raw_evidence_text = " ".join(parts).strip()
    if not evidence_text and not raw_evidence_text:
        return _prescription_payload()
    if _looks_like_prescription(evidence_text) or _looks_like_prescription(raw_evidence_text):
        log("VISION_PRESCRIPTION_REJECTED", text=(evidence_text or raw_evidence_text)[:160])
        return _prescription_payload()
    if extracted.get("status") != "OK" and not _has_product_text(parts):
        log("VISION_REJECTED", status=extracted.get("status"))
        return _prescription_payload()

    # If this exact visual/text was learned from previous customer confirmation,
    # respond directly.
    memory_product = _memory_lookup_product(evidence_text)
    if memory_product:
        log("UI_IMAGE_MEMORY_MATCH", product_id=memory_product.get("id"), text=evidence_text[:120])
        return _product_available_payload(memory_product)

    log("UI_IMAGE_EVIDENCE", text=evidence_text[:180])
    raw_candidates = _search_available_products(evidence_text, limit=MAX_LIST_ROWS * MAX_LIST_MESSAGES)
    candidates = _strong_image_candidates(evidence_text, raw_candidates)

    if not candidates:
        # Try Gemini's text matcher as a confirmation candidate only.
        try:
            gemini_product = await _match_with_gemini(evidence_text or raw_evidence_text, phone=phone, source="image_confirmation_candidate")
        except Exception as exc:
            log("IMAGE_GEMINI_CANDIDATE_ERROR", error=repr(exc))
            gemini_product = None
        if gemini_product:
            return _store_pending_confirmation(phone, gemini_product, evidence_text or raw_evidence_text, source="image_gemini", image_hash=image_hash, media_id=media_id, extracted=extracted)
        try:
            database.record_learning_event(
                customer_query=str(extracted.get("query") or ""),
                vision_text=(evidence_text or raw_evidence_text)[:1000],
                decision="LOCAL_NO_MATCH",
                reason=str(extracted.get("status") or "no_match"),
                media_id=media_id,
                query_slots={**(extracted or {}), "image_hash": image_hash},
            )
        except Exception:
            pass
        return _unavailable_payload()

    product = candidates[0]
    # Image results should be confirmed unless the package text almost exactly
    # equals the product name or the image hash was already confirmed.
    name_norm = normalize_text(_product_name(product))
    ev_norm = normalize_text(evidence_text)
    if name_norm and (name_norm == ev_norm or name_norm in ev_norm):
        log("UI_IMAGE_DIRECT_MATCH", product_id=product.get("id"), name=_product_name(product))
        try:
            database.set_image_cache(
                image_hash=image_hash,
                media_id=media_id,
                extracted_slots=extracted or {},
                matched_product_id=int(product.get("id") or 0),
                decision="UI_IMAGE_DIRECT_MATCHED",
                confidence=str(extracted.get("confidence") or ""),
            )
        except Exception:
            pass
        return _product_available_payload(product)

    log("UI_IMAGE_CONFIRMATION", product_id=product.get("id"), name=_product_name(product), text=evidence_text[:140])
    return _store_pending_confirmation(phone, product, evidence_text or raw_evidence_text, source="image", image_hash=image_hash, media_id=media_id, extracted=extracted)

# Keep health visibility through startup logs even if the route was registered
# before this override block.
log("PRICEBOT_FINAL_UI_V3_PATCH_LOADED", version=FINAL_UI_VERSION)
