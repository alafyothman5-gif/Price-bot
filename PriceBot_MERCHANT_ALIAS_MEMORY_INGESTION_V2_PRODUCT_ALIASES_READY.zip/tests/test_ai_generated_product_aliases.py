from __future__ import annotations

import asyncio
import csv
from pathlib import Path

import database
from tools.import_product_aliases_from_csv import import_alias_csv


def _insert_product(conn, name: str, price: str = "10") -> int:
    cols = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
    payload = {c: "" for c in cols}
    payload.update({
        "merchant_id": "1",
        "name": name,
        "normalized_name": database.clean_alias_text(name),
        "price": price,
        "available": "true",
        "quality_status": "approved",
        "review_status": "approved",
        "search_mode": "sellable",
    })
    cur = conn.execute(
        f"INSERT INTO products({', '.join(chr(34)+c+chr(34) for c in cols)}, created_at, updated_at) VALUES({', '.join(['?']*len(cols))}, datetime('now'), datetime('now'))",
        [payload[c] for c in cols],
    )
    return int(cur.lastrowid)


def test_import_product_aliases_csv_and_unmatched(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_test.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        pid = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        _insert_product(conn, "Transition 10g", "20")
    csv_path = tmp_path / "aliases.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["original_name", "alias_text"])
        writer.writeheader()
        writer.writerow({"original_name": "Flagyl 125mg/5ml Oral Suspension 60ml", "alias_text": "FLAGYL 125mg/5ml oral suspension 60 ml"})
        writer.writerow({"original_name": "Missing Product", "alias_text": "missing alias"})
    stats = import_alias_csv(csv_path, tmp_path / "unmatched.csv")
    assert stats["aliases_inserted"] == 1
    assert stats["unmatched_products"] == 1
    with database.connect() as conn:
        row = conn.execute("SELECT product_id, alias_text, cleaned_alias, confidence, source, active FROM product_aliases WHERE cleaned_alias=?", (database.clean_alias_text("FLAGYL 125mg/5ml oral suspension 60 ml"),)).fetchone()
        assert row is not None
        assert int(row["product_id"]) == pid
        assert row["source"] == "ai_generated"
        assert int(row["active"]) == 1


def test_exact_alias_lookup_is_unique_and_does_not_cross_size(tmp_path):
    database.configure_db_path(str(tmp_path / "pricebot_alias_lookup.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        flagyl = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        transition10 = _insert_product(conn, "Transition 10g", "20")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_id, alias_text, cleaned_alias, confidence, source, active)
            VALUES(?,?,?,?, 'ai_generated', 1)
        """, (flagyl, "FLAGYL 125mg/5ml oral suspension 60 ml", database.clean_alias_text("FLAGYL 125mg/5ml oral suspension 60 ml"), 0.95))
        conn.execute("""
            INSERT INTO product_aliases(product_id, alias_text, cleaned_alias, confidence, source, active)
            VALUES(?,?,?,?, 'ai_generated', 1)
        """, (transition10, "Transition 10g", database.clean_alias_text("Transition 10g"), 0.95))
    hit = database.lookup_product_by_alias_exact(["FLAGYL 125mg/5ml oral suspension 60 ml"])
    assert hit["status"] == "EXACT_ALIAS_MATCH"
    assert int(hit["product"]["id"]) == flagyl
    miss = database.lookup_product_by_alias_exact(["Transition 4g"])
    assert miss["status"] == "NO_MATCH"


def test_image_alias_hit_requires_confirmation_before_price(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "pricebot_alias_image.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        pid = _insert_product(conn, "Flagyl 125mg/5ml Oral Suspension 60ml", "15")
        database.ensure_product_aliases_schema(conn)
        conn.execute("""
            INSERT INTO product_aliases(product_id, alias_text, cleaned_alias, confidence, source, active)
            VALUES(?,?,?,?, 'ai_generated', 1)
        """, (pid, "FLAGYL 125mg/5ml oral suspension 60 ml", database.clean_alias_text("FLAGYL 125mg/5ml oral suspension 60 ml"), 0.95))

    async def fake_send(*args, **kwargs):
        return True

    async def fake_download(media_id):
        return b"fake-image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "FLAGYL 125mg/5ml oral suspension 60 ml",
            "foreground_product_text": "FLAGYL 125mg/5ml oral suspension 60 ml",
            "primary_title": "Flagyl",
            "brand": "Flagyl",
            "form": "oral suspension",
            "strength": "125mg/5ml",
            "size": "60ml",
        }

    state = {}
    monkeypatch.setattr(app, "send_whatsapp_message", fake_send)
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = asyncio.run(app.process_image("218900000000", "media-flagyl"))
    assert "هل هذا المنتج" in reply
    assert "15" not in reply
    assert state.get("state") == "WAITING_FOR_IMAGE_CONFIRMATION"
    assert state.get("product_id") == pid
