# PriceBot Full Fix Report - 2026-06-22

## Scope
This package fixes the current operational defects without replacing `pricebot.db` or `.env`, and without changing the WhatsApp conversation/image recognition logic.

## Fixes applied

1. **Unified availability logic**
   - `products.available` and `products.is_available` are now synchronized.
   - Customer visibility now rejects any product where either explicit flag says unavailable.
   - Weekly missing products are hidden with:
     - `available='0'`
     - `is_available=0`
     - `search_mode='hidden'`
     - `review_status='stale_hidden'`
   - Products that reappear in a later weekly upload are restored with:
     - `available='1'`
     - `is_available=1`
     - `search_mode='sellable'`
     - `review_status='approved'`

2. **Smart weekly Excel upload**
   - Accepts Arabic and English headers.
   - Supported name headers include: `name`, `product`, `product name`, `اسم المنتج`, `اسم الصنف`, `اسم الدواء`, `المنتج`, `الصنف`.
   - Supported price headers include: `price`, `cost`, `unit price`, `selling price`, `السعر`, `سعر`, `التكلفة`, `القيمة`.
   - If no clear headers exist, column A is treated as name and column B as price.
   - Duplicate rows in the same file are merged; the last row wins.

3. **Weekly inventory behavior**
   - Existing product in the file: price is updated and the product becomes available.
   - New valid product in the file: inserted immediately as sellable.
   - Generic or ambiguous product: inserted as hidden/review-only, and added to the review queue.
   - Missing product in a confirmed full-inventory upload: marked unavailable only; never deleted.

4. **Protection against accidental partial uploads**
   - Merchant upload page now includes a checked confirmation box: “this is a full inventory file”.
   - If unchecked, missing products are not marked unavailable.
   - Safety threshold: if the file is too small compared with the current catalog, deactivation is skipped automatically unless `PRICEBOT_ALLOW_SMALL_FULL_UPLOAD=1` is set.
   - Default threshold is controlled by `PRICEBOT_FULL_UPLOAD_MIN_RATIO` and defaults to `0.20`.

5. **Aliases / search improvement**
   - Each uploaded product name is automatically inserted into `merchant_product_aliases` and `product_aliases` when the tables exist.
   - This improves future exact matching for short names and repeated weekly upload names.

6. **No default service restart after upload**
   - The importer now rebuilds and invalidates runtime indexes in-process.
   - `pricebot.service` is not restarted by default after Excel upload, reducing the chance of losing queued WhatsApp messages.
   - To restore the old behavior, set `PRICEBOT_DASHBOARD_RESTART_AFTER_UPLOAD=1`.

7. **Runtime index refresh**
   - Rebuilds the search index.
   - Rebuilds the product identity registry.
   - Invalidates and reloads the Excel-native matcher memory index.
   - Rebuilds guided commerce index.

8. **Database path compatibility**
   - `database.py` now supports both `PRICEBOT_DB_FILE` and `PRICEBOT_DB_PATH`.
   - `start_pricebot.sh` exports both variables for compatibility.
   - Added `start-pricebot.sh` as a compatible filename for deployments using the hyphenated script name.

9. **Review/staging visibility fixes**
   - Approved review items now set both `available='1'` and `is_available=1`.
   - Deleted/rejected temporary products now set both `available='0'` and `is_available=0`.
   - Catalog ingestion approval paths also restore products to sellable visibility.

## Validation performed

- Python syntax check passed for core modules:
  - `app.py`
  - `merchant.py`
  - `database.py`
  - `search_engine.py`
  - `product_identity.py`
  - `guided_commerce.py`
  - `catalog_ingestion/processor.py`
  - `services/matching/excel_native_matcher.py`
- Existing relevant tests passed:
  - `tests/test_weekly_smart_upload_inventory.py`
  - `tests/test_excel_native_engine.py`
- Manual SQLite simulation verified:
  - Price update works.
  - New product insertion works.
  - Missing product becomes unavailable and hidden.
  - Generic/review-only product is not customer-visible.
  - Uploaded alias insertion works.

## Deployment note

Do not overwrite server `.env` or `pricebot.db`. Use rsync excludes:

```bash
--exclude='.env' --exclude='pricebot.db'
```
