# PriceBot Patch Summary - 2026-06-22

## Files changed
- `merchant.py`
- `app.py`

## Implemented changes

### 1. Flexible Excel upload reader
`merchant.py` now detects product-name and price columns from the first Excel row using Arabic and English header keywords.

Supported product/name indicators include:
- `name`, `product`, `product name`, `item`, `description`, `trade name`
- `اسم المنتج`, `اسم الصنف`, `اسم الدواء`, `الاسم`, `منتج`, `الصنف`, `الدواء`, `الوصف`, `المادة`

Supported price/cost indicators include:
- `price`, `cost`, `unit price`, `selling price`, `retail`, `amount`, `value`
- `السعر`, `سعر`, `التكلفة`, `تكلفة`, `سعر البيع`, `القيمة`, `المبلغ`

Fallback behavior remains safe: if both columns are not detected in row 1, column A is treated as product name and column B as price.

### 2. Smart availability logic preserved
The weekly upload flow keeps the existing smart behavior:
- products present in the new upload are set as available with updated price;
- products missing from the upload are marked `is_available=0`;
- no product rows are deleted.

### 3. Automatic exact aliases from uploaded product names
Weekly uploads now guarantee that `product_aliases` exists before inserting self-aliases.
For each matched or newly inserted product, the uploaded product name is saved as an exact alias with:
- `product_id`
- `product_db_id`
- `alias_text`
- `alias` where available
- `normalized_alias`
- `alias_normalized`
- `cleaned_alias`
- `source='weekly_upload'`
- active/approved flags where available

This improves exact matching for names such as `Panadol` / `Panadol 500mg` without changing the image or conversation flow.

### 4. Runtime capacity defaults increased
`app.py` defaults were raised while keeping environment-variable overrides:
- `PRICEBOT_WORKERS`: default `10` instead of `4`
- `PRICEBOT_QUEUE_MAXSIZE`: default `2000` instead of `500`
- `PRICEBOT_IMAGE_CONCURRENCY`: default `8` instead of `3`

## Verification performed
- Syntax check: `python3 -m py_compile app.py merchant.py database.py search_engine.py matcher.py`
- Excel reader test with Arabic headers.
- Excel reader test with English headers.
- Excel reader fallback test with no headers.
- Temporary SQLite upload simulation confirming:
  - existing product price update;
  - new product insert;
  - missing product marked unavailable;
  - exact aliases inserted into `product_aliases`.

## Deployment command after pushing to GitHub
```bash
cd /opt/pricebot_clean && git pull origin main && sudo systemctl restart pricebot.service
```
