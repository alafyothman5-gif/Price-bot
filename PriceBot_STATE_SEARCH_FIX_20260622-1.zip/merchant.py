from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import tempfile
import time
import subprocess
import threading
import urllib.parse
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import qrcode
from fastapi import APIRouter, BackgroundTasks, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates

import database
from services.security import csrf
from tasks.catalog_tasks import catalog_stage_import
from catalog_ingestion.processor import (
    approve_review_item,
    job_report,
    pending_reviews,
    reject_review_item,
)
from services.catalog.staging_workflow import approve_staging_job, reject_staging_job

router = APIRouter()
templates = Jinja2Templates(directory="templates")
MERCHANT_USERNAME = os.getenv("PRICEBOT_MERCHANT_USERNAME") or os.getenv("MERCHANT_USERNAME") or "merchant"
MERCHANT_PASSWORD = os.getenv("PRICEBOT_MERCHANT_PASSWORD") or os.getenv("MERCHANT_PASSWORD") or os.getenv("MERCHANT_CODE", "")
MERCHANT_COOKIE = "pricebot_merchant_session"
MERCHANT_TTL_SECONDS = int(os.getenv("PRICEBOT_MERCHANT_SESSION_TTL_SECONDS", "21600") or 21600)
_RATE: Dict[str, list] = {}
DASHBOARD_COOKIE = "pricebot_dashboard_session"
DASHBOARD_TOKEN = (
    os.getenv("PRICEBOT_DASHBOARD_TOKEN")
    or os.getenv("MERCHANT_DASHBOARD_TOKEN")
    or os.getenv("PRICEBOT_MERCHANT_TOKEN")
    or MERCHANT_PASSWORD
    or ""
)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return forwarded or (request.client.host if request.client else "unknown")


def _rate_ok(request: Request, limit: int = 30, window: int = 60) -> bool:
    ip = _client_ip(request)
    now = time.time()
    bucket = _RATE.setdefault(ip, [])
    bucket[:] = [x for x in bucket if now - x < window]
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def _secret() -> bytes:
    key = os.getenv("PRICEBOT_MERCHANT_SESSION_SECRET") or os.getenv("PRICEBOT_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD") or MERCHANT_PASSWORD
    return (key or "missing-merchant-secret").encode("utf-8")


def _sign(payload: str) -> str:
    return hmac.new(_secret(), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _make_session(username: str) -> str:
    ts = str(int(time.time()))
    nonce = secrets.token_urlsafe(18)
    payload = f"{username}:{ts}:{nonce}"
    return f"{payload}:{_sign(payload)}"


def _session_ok(token: str) -> bool:
    try:
        username, ts, nonce, sig = (token or "").split(":", 3)
        payload = f"{username}:{ts}:{nonce}"
        return username == MERCHANT_USERNAME and hmac.compare_digest(sig, _sign(payload)) and time.time() - int(ts) <= MERCHANT_TTL_SECONDS
    except Exception:
        return False


def _require_auth(request: Request):
    if not _rate_ok(request):
        return PlainTextResponse("rate limited", status_code=429)
    if not _session_ok(request.cookies.get(MERCHANT_COOKIE, "")):
        return RedirectResponse("/merchant/login", status_code=303)
    return None


def _csrf_token(request: Request) -> str:
    return csrf.issue_token(request.cookies.get(MERCHANT_COOKIE, ""))


def _require_csrf(request: Request, token: str = ""):
    if not csrf.verify_token(token, request.cookies.get(MERCHANT_COOKIE, "")):
        database.audit_admin("merchant_csrf_rejected", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"path": str(request.url.path)})
        return PlainTextResponse("CSRF validation failed", status_code=403)
    return None


def _render(request: Request, template: str, context: Dict):
    context = dict(context)
    context.setdefault("csrf_token", _csrf_token(request))
    return templates.TemplateResponse(template, context)


def _merchant_id() -> int:
    return database.default_merchant_id()


def _merchant_nav(active: str = "dashboard") -> list[Dict]:
    items = [
        ("dashboard", "/merchant/dashboard", "📊", "الرئيسية"),
        ("upload", "/merchant/upload", "⬆️", "رفع Excel"),
        ("products", "/merchant/products", "📦", "المنتجات"),
        ("review", "/merchant/review", "🧾", "المراجعة"),
        ("analytics", "/merchant/analytics", "📈", "الإحصائيات"),
        ("settings", "/merchant/settings", "⚙️", "الإعدادات"),
        ("orders", "/merchant/orders", "🧾", "الطلبات"),
        ("share", "/merchant/share", "🔗", "رابط واتساب"),
    ]
    return [{"active": key == active, "href": href, "icon": icon, "label": label} for key, href, icon, label in items]


def _settings() -> Dict:
    return database.get_merchant_settings(_merchant_id())


def _whatsapp_link() -> str:
    import urllib.parse
    s = _settings()
    number = ''.join(ch for ch in str(s.get("whatsapp_number") or os.getenv("BOT_WHATSAPP_NUMBER") or os.getenv("WHATSAPP_PUBLIC_NUMBER") or os.getenv("ADMIN_NOTIFY_PHONE") or "") if ch.isdigit()) or "218000000000"
    pharmacy = s.get("pharmacy_name") or s.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")
    msg = s.get("qr_message") or f"السلام عليكم، أريد الاستفسار عن منتج من {pharmacy}"
    return f"https://wa.me/{number}?text={urllib.parse.quote(msg)}"


def _orders_count(status: str) -> int:
    try:
        return len(database.list_orders(status, 5000, merchant_id=_merchant_id()))
    except Exception:
        return 0




def _safe_value(fn, default=None, label: str = ""):
    try:
        return fn()
    except Exception as exc:
        print(f"MERCHANT_UI_SAFE_VALUE_ERROR | {label or getattr(fn, '__name__', 'call')} | {exc!r}", flush=True)
        return default


def _table_exists_safe(conn, table: str) -> bool:
    try:
        return bool(database.table_exists(conn, table))
    except Exception:
        return False


def _product_inventory_counts(mid: int) -> Dict[str, int]:
    def run():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "products"):
                return {"total": 0, "available": 0, "unavailable": 0, "needs_review": 0}
            cols = set(database.table_columns(conn, "products"))
            where = "WHERE merchant_id=?" if "merchant_id" in cols else ""
            params = (mid,) if where else ()
            total = int(conn.execute(f"SELECT COUNT(*) FROM products {where}", params).fetchone()[0])
            if "is_available" in cols:
                available = int(conn.execute(f"SELECT COUNT(*) FROM products {where} AND COALESCE(is_available,1)=1" if where else "SELECT COUNT(*) FROM products WHERE COALESCE(is_available,1)=1", params).fetchone()[0])
                unavailable = int(conn.execute(f"SELECT COUNT(*) FROM products {where} AND COALESCE(is_available,1)=0" if where else "SELECT COUNT(*) FROM products WHERE COALESCE(is_available,1)=0", params).fetchone()[0])
            else:
                available = total
                unavailable = 0
            if "needs_review" in cols:
                needs_review = int(conn.execute(f"SELECT COUNT(*) FROM products {where} AND COALESCE(needs_review,0)=1" if where else "SELECT COUNT(*) FROM products WHERE COALESCE(needs_review,0)=1", params).fetchone()[0])
            else:
                needs_review = 0
            return {"total": total, "available": available, "unavailable": unavailable, "needs_review": needs_review}
    return _safe_value(run, {"total": 0, "available": 0, "unavailable": 0, "needs_review": 0}, "product_inventory_counts")


def _last_upload_summary(mid: int) -> Dict[str, object]:
    def run():
        rows = database.list_product_upload_history(limit=1, merchant_id=mid)
        return rows[0] if rows else {}
    return _safe_value(run, {}, "last_upload_summary")


def _count_search_logs(days: int, mid: int) -> int:
    def run():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "search_logs"):
                return 0
            row = conn.execute(
                "SELECT COUNT(*) FROM search_logs WHERE merchant_id=? AND timestamp >= datetime('now', ?)",
                (mid, f"-{int(days)} days"),
            ).fetchone()
            return int(row[0] if row else 0)
    return _safe_value(run, 0, f"search_logs_{days}")


def _audit_count(pattern: str, days: int = 30) -> int:
    def run():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "audit_logs"):
                return 0
            row = conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE created_at >= datetime('now', ?) AND (event LIKE ? OR details LIKE ?)",
                (f"-{int(days)} days", f"%{pattern}%", f"%{pattern}%"),
            ).fetchone()
            return int(row[0] if row else 0)
    return _safe_value(run, 0, f"audit_{pattern}")


def _analytics_context(mid: int) -> Dict[str, object]:
    top_week = _safe_value(lambda: database.top_searched_products(days=7, limit=10, merchant_id=mid), [], "top_week")
    top_month = _safe_value(lambda: database.top_searched_products(days=30, limit=10, merchant_id=mid), [], "top_month")
    top_today = _safe_value(lambda: database.top_searched_products(days=1, limit=10, merchant_id=mid), [], "top_today")
    failed = _safe_value(lambda: _top_failed_queries(mid), [], "top_failed")
    metrics = {
        "search_today": _count_search_logs(1, mid),
        "search_week": _count_search_logs(7, mid),
        "image_checked": _audit_count("IMAGE", 30) + _audit_count("VISION", 30),
        "image_success": _audit_count("AI_IMAGE_PRODUCT_MATCH_CONFIRMATION_ONLY", 30),
        "exact_matches": _audit_count("EXACT_MATCH", 30),
        "confirmations": _audit_count("confirmation", 30) + _count_search_logs(30, mid),
        "low_confidence": _audit_count("LOW_CONFIDENCE", 30),
        "image_unclear": _audit_count("IMAGE_UNCLEAR", 30),
        "evidence_rejected": _audit_count("EVIDENCE_VALIDATOR_FAILED", 30),
    }
    checked = max(int(metrics["image_checked"] or 0), 0)
    success = max(int(metrics["image_success"] or 0), 0)
    metrics["image_success_rate"] = round((success / checked * 100), 1) if checked else None
    return {"top_today": top_today, "top_week": top_week, "top_month": top_month, "failed_queries": failed, "metrics": metrics}


def _top_failed_queries(mid: int) -> List[Dict[str, object]]:
    with database.connect() as conn:
        # Prefer learning inbox if present.
        if _table_exists_safe(conn, "learning_inbox"):
            cols = set(database.table_columns(conn, "learning_inbox"))
            query_col = "query" if "query" in cols else ("raw_query" if "raw_query" in cols else "")
            if query_col:
                rows = conn.execute(
                    f"SELECT {query_col} AS query, COUNT(*) AS hits FROM learning_inbox GROUP BY {query_col} ORDER BY hits DESC LIMIT 10"
                ).fetchall()
                return [database.dict_row(r) for r in rows]
        if _table_exists_safe(conn, "audit_logs"):
            rows = conn.execute(
                """
                SELECT substr(details,1,120) AS query, COUNT(*) AS hits
                FROM audit_logs
                WHERE event LIKE '%LOW_CONFIDENCE%' OR event LIKE '%NOT_AVAILABLE%' OR event LIKE '%EVIDENCE_VALIDATOR_FAILED%' OR details LIKE '%LOW_CONFIDENCE%'
                GROUP BY substr(details,1,120)
                ORDER BY hits DESC
                LIMIT 10
                """
            ).fetchall()
            return [database.dict_row(r) for r in rows]
        return []


def _merchant_dashboard_context(request: Request, *, msg: str = "", error: str = "") -> Dict[str, object]:
    mid = _merchant_id()
    inventory = _product_inventory_counts(mid)
    last_upload = _last_upload_summary(mid)
    analytics = _analytics_context(mid)
    uploads = _safe_value(lambda: database.list_product_upload_history(limit=5, merchant_id=mid), [], "uploads")
    review_items = _safe_value(lambda: database.list_review_queue(limit=8, merchant_id=mid), [], "review_items")
    return {
        "request": request,
        "title": "لوحة التاجر",
        "nav": _merchant_nav("dashboard"),
        "pharmacy_name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),
        "inventory": inventory,
        "last_upload": last_upload,
        "uploads": uploads,
        "review_items": review_items,
        "review_count": _safe_value(lambda: database.count_review_queue(merchant_id=mid), 0, "review_count"),
        "analytics": analytics,
        "top_week": analytics.get("top_week", []),
        "top_month": analytics.get("top_month", []),
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }


def _render_safe(request: Request, template: str, context: Dict, *, fallback_title: str = "PriceBot"):
    try:
        return _render(request, template, context)
    except Exception as exc:
        print(f"MERCHANT_UI_RENDER_ERROR | template={template} | error={exc!r}", flush=True)
        safe_message = str(exc)[:300]
        return HTMLResponse(
            f"""
            <!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
            <title>{fallback_title}</title><link rel='stylesheet' href='/static/css/enterprise.css'></head>
            <body><main class='main main-full' style='padding:24px'><section class='panel'>
            <h1>تعذر عرض الصفحة مؤقتاً</h1><p>تم تسجيل الخطأ في السجلات. الخدمة والبوت لم يتوقفا.</p>
            <p class='muted'>تفاصيل مختصرة: {safe_message}</p><a class='btn primary' href='/merchant/dashboard'>الرجوع للوحة</a>
            </section></main></body></html>
            """,
            status_code=200,
        )

def _dashboard_auth_ok(request: Request) -> bool:
    token = request.query_params.get("token") or ""
    cookie = request.cookies.get(DASHBOARD_COOKIE, "")
    if DASHBOARD_TOKEN and token and hmac.compare_digest(token, DASHBOARD_TOKEN):
        return True
    if DASHBOARD_TOKEN and cookie and hmac.compare_digest(cookie, _sign("dashboard:" + DASHBOARD_TOKEN)):
        return True
    return False


def _dashboard_response_with_cookie() -> RedirectResponse:
    resp = RedirectResponse("/dashboard", status_code=303)
    resp.set_cookie(
        DASHBOARD_COOKIE,
        _sign("dashboard:" + DASHBOARD_TOKEN),
        max_age=MERCHANT_TTL_SECONDS,
        httponly=True,
        secure=True,
        samesite="lax",
    )
    return resp


def _header_lookup_key(value: object) -> str:
    """Normalize an Excel header cell for loose Arabic/English matching."""
    text = str(value or "").strip().lower()
    if not text:
        return ""
    try:
        text = database.normalize_text(text)
    except Exception:
        pass
    # Keep Arabic/Latin letters and digits; collapse punctuation/line breaks.
    text = re.sub(r"[^0-9a-zA-Z\u0600-\u06FF]+", " ", text)
    return " ".join(text.split())


def _find_header_column(headers: List[str], groups: List[Tuple[str, ...]]) -> Optional[int]:
    """Return the first header index containing any configured keyword."""
    for group in groups:
        for idx, header in enumerate(headers):
            if not header:
                continue
            compact_header = header.replace(" ", "")
            for raw_keyword in group:
                keyword = _header_lookup_key(raw_keyword)
                if not keyword:
                    continue
                if keyword in header or keyword.replace(" ", "") in compact_header:
                    return idx
    return None


def _read_price_rows_from_upload(filename: str, data: bytes) -> List[Tuple[str, str]]:
    """Read product name/price rows from flexible .xlsx or .xls uploads.

    Header policy:
    - If row 1 contains a product-name column and a price/cost column, use them.
    - Otherwise, treat column A as product name and column B as price.
    """
    suffix = Path(filename or "").suffix.lower()
    rows: List[List[object]] = []
    if suffix == ".xlsx":
        from openpyxl import load_workbook
        wb = load_workbook(BytesIO(data), read_only=True, data_only=True)
        ws = wb.active
        rows = [[cell for cell in row] for row in ws.iter_rows(values_only=True)]
    elif suffix == ".xls":
        import xlrd
        book = xlrd.open_workbook(file_contents=data)
        sh = book.sheet_by_index(0)
        rows = [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)]
    else:
        raise ValueError("only .xlsx and .xls files are allowed")

    # Drop completely empty Excel rows before applying header/fallback detection.
    rows = [row for row in rows if any(str(cell or "").strip() for cell in row)]
    if not rows:
        return []

    header = [_header_lookup_key(x) for x in rows[0]]
    name_keywords = [
        ("product name", "product", "name", "item", "description", "trade name"),
        ("اسم المنتج", "اسم الصنف", "اسم الدواء", "الاسم", "منتج", "الصنف", "الدواء", "الوصف", "المادة"),
    ]
    price_keywords = [
        ("price", "cost", "unit price", "selling price", "retail", "amount", "value"),
        ("السعر", "سعر", "التكلفة", "تكلفة", "سعر البيع", "القيمة", "المبلغ"),
    ]
    detected_name_idx = _find_header_column(header, name_keywords)
    detected_price_idx = _find_header_column(header, price_keywords)

    if detected_name_idx is not None and detected_price_idx is not None and detected_name_idx != detected_price_idx:
        name_idx = detected_name_idx
        price_idx = detected_price_idx
        start = 1
    else:
        # Safe default requested by the merchant flow: first column name, second price.
        name_idx = 0
        price_idx = 1
        start = 0

    out: List[Tuple[str, str]] = []
    for row in rows[start:]:
        if len(row) <= max(name_idx, price_idx):
            continue
        name = str(row[name_idx] or "").strip()
        price = str(row[price_idx] or "").strip()
        if not name:
            continue
        out.append((name, price))
    return out


def _rebuild_runtime_indexes_safely() -> Dict[str, int]:
    stats: Dict[str, int] = {}
    try:
        from search_engine import rebuild_search_index
        stats["search_index"] = int(rebuild_search_index() or 0)
    except Exception as exc:
        stats["search_index_error"] = 1
        print(f"DASHBOARD_REBUILD_SEARCH_INDEX_WARNING {exc!r}", flush=True)
    try:
        import product_identity
        stats["identity_registry"] = int(product_identity.rebuild_product_identity_registry() or 0)
    except Exception as exc:
        stats["identity_registry_error"] = 1
        print(f"DASHBOARD_REBUILD_IDENTITY_WARNING {exc!r}", flush=True)
    try:
        from services.matching import excel_native_matcher
        excel_native_matcher.invalidate_memory_index()
        stats["excel_native_index"] = int(excel_native_matcher.preload_search_index() or 0)
    except Exception as exc:
        stats["excel_native_index_error"] = 1
        print(f"DASHBOARD_REBUILD_EXCEL_NATIVE_WARNING {exc!r}", flush=True)
    try:
        import guided_commerce
        stats["guided_index"] = int(guided_commerce.rebuild_guided_index() or 0)
    except Exception as exc:
        stats["guided_index_error"] = 1
        print(f"DASHBOARD_REBUILD_GUIDED_WARNING {exc!r}", flush=True)
    return stats


def _weekly_clean_name(value: object) -> str:
    return database.normalize_text(value or "")


def _weekly_unit_compact(value: str) -> str:
    text = _weekly_clean_name(value)
    # Only collapse spacing between a number and a unit. This handles safe cases
    # such as "125 mg" vs "125mg" without enabling broad fuzzy matching.
    text = re.sub(r"(\d+)\s+(mg|mcg|g|gm|ml|iu|%)\b", r"\1\2", text)
    return re.sub(r"\s+", " ", text).strip()


def _levenshtein_distance_limited(a: str, b: str, limit: int = 2) -> int:
    if abs(len(a) - len(b)) > limit:
        return limit + 1
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        row_min = i
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            val = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            cur.append(val)
            row_min = min(row_min, val)
        if row_min > limit:
            return limit + 1
        prev = cur
    return prev[-1]


def _find_very_close_weekly_candidate(cleaned: str, existing_rows: List[Dict[str, object]]) -> Tuple[object, str]:
    if not cleaned:
        return None, ""
    compact = _weekly_unit_compact(cleaned)
    hits: List[Tuple[Dict[str, object], str]] = []
    for row in existing_rows:
        existing_clean = str(row.get("cleaned_name") or "")
        existing_compact = _weekly_unit_compact(existing_clean)
        if existing_compact and existing_compact == compact:
            hits.append((row, "unit_spacing_exact"))
            continue
        # A very small typo allowance is only safe for reasonably long names.
        if len(compact) >= 8 and _levenshtein_distance_limited(compact, existing_compact, 2) <= 2:
            hits.append((row, "levenshtein<=2"))
    product_ids = {int(h[0].get("id") or 0) for h in hits if int(h[0].get("id") or 0)}
    if len(product_ids) == 1:
        return hits[0][0], hits[0][1]
    return None, "ambiguous_close_match" if len(product_ids) > 1 else ""


def _parse_weekly_price(value: object) -> Tuple[bool, str]:
    text = str(value or "").strip().replace(",", ".")
    if not text:
        return False, ""
    try:
        number = float(text)
        if number < 0:
            return False, ""
        if number.is_integer():
            return True, str(int(number))
        return True, f"{number:.2f}".rstrip("0").rstrip(".")
    except Exception:
        return False, ""


_WEEKLY_GENERIC_NAMES = {
    "cream", "gel", "lotion", "serum", "cleanser", "wash", "face wash", "sunscreen", "spf",
    "toner", "soap", "mask", "shampoo", "conditioner", "balm", "ointment", "spray", "solution",
    "suspension", "capsule", "capsules", "tablet", "tablets", "syrup", "drops", "غسول", "كريم",
    "جل", "لوشن", "سيروم", "صابون", "شامبو", "بخاخ", "محلول", "شراب", "حبوب", "قطرة",
}


def _weekly_name_needs_review(cleaned: str) -> bool:
    if not cleaned:
        return True
    if cleaned in _WEEKLY_GENERIC_NAMES:
        return True
    tokens = cleaned.split()
    if len(tokens) == 1 and (len(tokens[0]) < 4 or tokens[0] in _WEEKLY_GENERIC_NAMES):
        return True
    return False


def _ensure_weekly_upload_schema(conn: Any) -> None:
    """Add only the columns/tables needed by weekly import. No broad init_db."""
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA cache_size=-8000")
    if not database.table_exists(conn, "products"):
        raise RuntimeError("products table missing")
    # Ensure global exact aliases exist before weekly uploads write self-aliases.
    try:
        database.ensure_product_aliases_schema(conn)
    except Exception:
        pass
    database.add_column(conn, "products", "available", "TEXT DEFAULT '1'")
    database.add_column(conn, "products", "is_available", "INTEGER DEFAULT 1")
    database.add_column(conn, "products", "last_seen_in_upload", "TEXT")
    database.add_column(conn, "products", "needs_review", "INTEGER DEFAULT 0")
    database.add_column(conn, "products", "normalized_name", "TEXT DEFAULT ''")
    database.add_column(conn, "products", "original_name", "TEXT DEFAULT ''")
    database.add_column(conn, "products", "search_mode", "TEXT DEFAULT 'sellable'")
    database.add_column(conn, "products", "review_status", "TEXT DEFAULT 'approved'")
    database.add_column(conn, "products", "quality_status", "TEXT DEFAULT 'ok'")
    database.add_column(conn, "products", "updated_at", "TEXT")
    conn.execute("UPDATE products SET is_available=1 WHERE is_available IS NULL")
    conn.execute("UPDATE products SET available='1' WHERE (available IS NULL OR available='') AND COALESCE(is_available,1)=1")
    conn.execute("UPDATE products SET available='0' WHERE COALESCE(is_available,1)=0")
    conn.execute("UPDATE products SET needs_review=0 WHERE needs_review IS NULL")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_products_weekly_stock ON products(merchant_id, is_available, needs_review)")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS upload_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            merchant_id INTEGER DEFAULT 1,
            upload_time TEXT DEFAULT CURRENT_TIMESTAMP,
            filename TEXT DEFAULT '',
            total_rows INTEGER DEFAULT 0,
            new_products INTEGER DEFAULT 0,
            updated_products INTEGER DEFAULT 0,
            deactivated_products INTEGER DEFAULT 0,
            review_products INTEGER DEFAULT 0,
            status TEXT DEFAULT 'success',
            message TEXT DEFAULT ''
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS product_upload_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            merchant_id INTEGER DEFAULT 1,
            filename TEXT DEFAULT '',
            products_count INTEGER DEFAULT 0,
            backup_path TEXT DEFAULT '',
            status TEXT DEFAULT 'success',
            message TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS review_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            merchant_id INTEGER DEFAULT 1,
            product_name TEXT DEFAULT '',
            similar_existing_id INTEGER,
            temp_product_id INTEGER,
            uploaded_price TEXT DEFAULT '',
            reason TEXT DEFAULT '',
            candidates TEXT DEFAULT '',
            resolved INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            resolved_at TEXT
        )
    """)
    database.add_column(conn, "review_queue", "candidates", "TEXT DEFAULT ''")
    database.ensure_import_jobs_schema(conn)


def _load_weekly_alias_indexes(conn: Any, merchant_id: int) -> Tuple[Dict[str, List[int]], Dict[str, List[int]]]:
    product_aliases: Dict[str, List[int]] = {}
    merchant_aliases: Dict[str, List[int]] = {}
    if database.table_exists(conn, "product_aliases"):
        cols = set(database.table_columns(conn, "product_aliases"))
        pid_col = "product_db_id" if "product_db_id" in cols else ("product_id" if "product_id" in cols else "")
        alias_cols = [c for c in ["normalized_alias", "cleaned_alias", "alias", "alias_text", "alias_normalized"] if c in cols]
        active_clause = ""
        if "approved" in cols:
            active_clause += " AND COALESCE(approved,1)=1"
        if "active" in cols:
            active_clause += " AND COALESCE(active,1)=1"
        if pid_col and alias_cols:
            select_cols = ", ".join([pid_col] + alias_cols)
            rows = conn.execute(f"SELECT {select_cols} FROM product_aliases WHERE {pid_col} IS NOT NULL {active_clause}").fetchall()
            for row in rows:
                try:
                    pid = int(row[pid_col] or 0)
                except Exception:
                    pid = 0
                if not pid:
                    continue
                for col in alias_cols:
                    key = _weekly_clean_name(row[col])
                    if key:
                        product_aliases.setdefault(key, []).append(pid)
    if database.table_exists(conn, "merchant_product_aliases"):
        cols = set(database.table_columns(conn, "merchant_product_aliases"))
        pid_col = "product_id" if "product_id" in cols else "product_db_id" if "product_db_id" in cols else ""
        alias_cols = [c for c in ["normalized_raw_name", "normalized_name", "raw_name"] if c in cols]
        if pid_col and alias_cols:
            where = "WHERE 1=1"
            params: List[Any] = []
            if "merchant_id" in cols:
                where += " AND merchant_id=?"
                params.append(int(merchant_id))
            if "is_active" in cols:
                where += " AND COALESCE(is_active,1)=1"
            select_cols = ", ".join([pid_col] + alias_cols)
            for row in conn.execute(f"SELECT {select_cols} FROM merchant_product_aliases {where}", params).fetchall():
                try:
                    pid = int(row[pid_col] or 0)
                except Exception:
                    pid = 0
                if not pid:
                    continue
                for col in alias_cols:
                    key = _weekly_clean_name(row[col])
                    if key:
                        merchant_aliases.setdefault(key, []).append(pid)
    return product_aliases, merchant_aliases


def _insert_uploaded_alias_if_possible(conn: Any, product_id: int, alias_text: str, merchant_id: int) -> None:
    cleaned = _weekly_clean_name(alias_text)
    if not cleaned:
        return
    # Merchant memory is safest for exact future weekly uploads.
    if database.table_exists(conn, "merchant_product_aliases"):
        cols = set(database.table_columns(conn, "merchant_product_aliases"))
        values = {}
        if "merchant_id" in cols:
            values["merchant_id"] = int(merchant_id)
        if "raw_name" in cols:
            values["raw_name"] = str(alias_text or "")[:500]
        if "normalized_raw_name" in cols:
            values["normalized_raw_name"] = cleaned
        if "product_id" in cols:
            values["product_id"] = int(product_id)
        if "source" in cols:
            values["source"] = "weekly_upload"
        if "last_seen_at" in cols:
            values["last_seen_at"] = "__NOW__"
        if "is_active" in cols:
            values["is_active"] = 1
        if values and ("product_id" in values or "product_db_id" in values):
            try:
                col_sql = ",".join(values.keys())
                exprs = []
                params = []
                for v in values.values():
                    if v == "__NOW__":
                        exprs.append("datetime('now')")
                    else:
                        exprs.append("?")
                        params.append(v)
                conn.execute(f"INSERT OR IGNORE INTO merchant_product_aliases({col_sql}) VALUES({','.join(exprs)})", params)
            except Exception:
                pass
    if database.table_exists(conn, "product_aliases"):
        cols = set(database.table_columns(conn, "product_aliases"))
        values = {}
        if "product_db_id" in cols:
            values["product_db_id"] = int(product_id)
        if "product_id" in cols:
            values["product_id"] = int(product_id)
        if "alias" in cols:
            values["alias"] = str(alias_text or "")[:500]
        if "alias_text" in cols:
            values["alias_text"] = str(alias_text or "")[:500]
        if "normalized_alias" in cols:
            values["normalized_alias"] = cleaned
        if "alias_normalized" in cols:
            values["alias_normalized"] = cleaned
        if "cleaned_alias" in cols:
            values["cleaned_alias"] = cleaned
        if "confidence" in cols:
            values["confidence"] = 0.95
        if "source" in cols:
            values["source"] = "weekly_upload"
        if "approved" in cols:
            values["approved"] = 1
        if "active" in cols:
            values["active"] = 1
        if values:
            try:
                col_sql = ",".join(values.keys())
                placeholders = ",".join("?" for _ in values)
                conn.execute(f"INSERT OR IGNORE INTO product_aliases({col_sql}) VALUES({placeholders})", list(values.values()))
            except Exception:
                pass


def _reports_dir_for_job(job_id: Optional[int]) -> Path:
    base = database.get_db_path().parent / "import_reports"
    if job_id:
        base = base / f"job_{int(job_id)}"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _write_xlsx(path: Path, headers: List[str], rows: List[Dict[str, Any]]) -> None:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(headers)
    for row in rows:
        ws.append([row.get(h, "") for h in headers])
    ws.freeze_panes = "A2"
    for col_cells in ws.columns:
        try:
            width = min(max(len(str(c.value or "")) for c in col_cells) + 2, 60)
            ws.column_dimensions[col_cells[0].column_letter].width = width
        except Exception:
            pass
    wb.save(path)


def _write_import_reports(job_id: Optional[int], summary: Dict[str, Any], updated: List[Dict[str, Any]], new: List[Dict[str, Any]], review: List[Dict[str, Any]], invalid: List[Dict[str, Any]], duplicates: List[Dict[str, Any]]) -> Path:
    out = _reports_dir_for_job(job_id)
    summary_rows = [{"metric": k, "value": v} for k, v in summary.items() if not isinstance(v, (list, dict))]
    _write_xlsx(out / "import_summary.xlsx", ["metric", "value"], summary_rows)
    _write_xlsx(out / "updated_products.xlsx", ["product_id", "old_name", "uploaded_name", "old_price", "new_price", "decision", "reason"], updated)
    _write_xlsx(out / "new_products.xlsx", ["product_id", "name", "price", "decision"], new)
    _write_xlsx(out / "review_required.xlsx", ["uploaded_name", "price", "reason", "candidates"], review)
    _write_xlsx(out / "invalid_rows.xlsx", ["row_number", "name", "price", "reason"], invalid)
    _write_xlsx(out / "duplicate_rows.xlsx", ["name", "price", "decision", "reason"], duplicates)
    return out


def _smart_weekly_products_upload(rows: List[Tuple[str, str]], filename: str, job_id: Optional[int] = None, full_inventory_upload: bool = True) -> Dict[str, object]:
    """Weekly stock upload with progress, reports, and no DELETE/replace-all.

    Rules:
    - name|price only.
    - Known identity => UPDATE_PRICE, never conflict.
    - Valid new product => INSERT_NEW_PRODUCT immediately.
    - Ambiguous/generic/unsafe => review_queue.
    - Missing from a confirmed full-inventory upload => available=0/is_available=0 only, never delete.
    - Partial uploads can skip deactivation to avoid hiding the whole catalog by mistake.
    """
    if not rows:
        raise ValueError("file contains no product rows")
    mid = _merchant_id()
    started = time.time()
    backup = database.backup_db("before_weekly_smart_upload")
    total_input_rows = len(rows)
    now_seen_ids: set[int] = set()
    matched_existing = 0
    price_updated = 0
    inserted_new = 0
    review_required = 0
    invalid_rows_count = 0
    duplicate_merged = 0
    skipped_rows = 0
    auto_close_matches = 0

    updated_report: List[Dict[str, Any]] = []
    new_report: List[Dict[str, Any]] = []
    review_report: List[Dict[str, Any]] = []
    invalid_report: List[Dict[str, Any]] = []
    duplicate_report: List[Dict[str, Any]] = []

    # Last duplicate row wins. Same product same price is merged. Same identity
    # different price uses last price with a warning, not PRICE_CONFLICT.
    dedup: Dict[str, Tuple[int, str, str]] = {}
    seen_first_price: Dict[str, str] = {}
    for idx, (name, price) in enumerate(rows, start=1):
        clean = _weekly_clean_name(name)
        if not clean:
            skipped_rows += 1
            continue
        ok_price, safe_price = _parse_weekly_price(price)
        if not ok_price:
            invalid_rows_count += 1
            invalid_report.append({"row_number": idx, "name": str(name or ""), "price": str(price or ""), "reason": "invalid price"})
            continue
        if clean in dedup:
            duplicate_merged += 1
            old_price = seen_first_price.get(clean, "")
            reason = "duplicate same price merged" if str(old_price) == str(safe_price) else "duplicate different price: last row wins"
            duplicate_report.append({"name": str(name or ""), "price": safe_price, "decision": "DUPLICATE_LAST_ROW_USED", "reason": reason})
        else:
            seen_first_price[clean] = str(safe_price)
        dedup[clean] = (idx, str(name or "").strip(), safe_price)

    if job_id:
        database.update_import_job(job_id, status="PROCESSING", progress_percent=15, total_rows=total_input_rows, processed_rows=0, summary=f"تم تنظيف {len(dedup)} منتج صالح من {total_input_rows} صف")

    with database.connect() as conn:
        _ensure_weekly_upload_schema(conn)
        product_cols = set(database.table_columns(conn, "products"))
        existing = []
        for r in conn.execute("SELECT id, name, price, merchant_id FROM products WHERE merchant_id=?", (mid,)).fetchall():
            d = database.dict_row(r)
            d["cleaned_name"] = _weekly_clean_name(d.get("name") or "")
            existing.append(d)
        by_clean: Dict[str, List[Dict[str, object]]] = {}
        by_id: Dict[int, Dict[str, object]] = {}
        for row in existing:
            pid = int(row.get("id") or 0)
            if pid:
                by_id[pid] = row
            by_clean.setdefault(str(row.get("cleaned_name") or ""), []).append(row)
        product_aliases, merchant_aliases = _load_weekly_alias_indexes(conn, mid)

        def update_existing(pid: int, uploaded_name: str, new_price: str, matched_reason: str = "exact") -> None:
            nonlocal matched_existing, price_updated, auto_close_matches
            row = by_id.get(int(pid), {})
            old_price = database.safe_price(row.get("price") if row else "")
            matched_existing += 1
            if str(old_price) != str(new_price):
                price_updated += 1
            vals = {
                "price": new_price,
                "available": "1",
                "is_available": 1,
                "last_seen_in_upload": "__NOW__",
                "needs_review": 0,
                "review_status": "approved",
                "search_mode": "sellable",
                "quality_status": "ok",
                "updated_at": "__NOW__",
            }
            sets = []
            params = []
            for col, val in vals.items():
                if col not in product_cols:
                    continue
                if val == "__NOW__":
                    sets.append(f'{col}=datetime(\'now\')')
                else:
                    sets.append(f'{col}=?')
                    params.append(val)
            if sets:
                conn.execute(f"UPDATE products SET {', '.join(sets)} WHERE id=? AND merchant_id=?", params + [int(pid), mid])
            now_seen_ids.add(int(pid))
            _insert_uploaded_alias_if_possible(conn, int(pid), uploaded_name, mid)
            if matched_reason != "exact":
                auto_close_matches += 1
            updated_report.append({
                "product_id": int(pid),
                "old_name": row.get("name", ""),
                "uploaded_name": uploaded_name,
                "old_price": old_price,
                "new_price": new_price,
                "decision": "UPDATE_PRICE" if str(old_price) != str(new_price) else "PRICE_UNCHANGED",
                "reason": matched_reason,
            })

        def insert_new_product(uploaded_name: str, price: str, needs_review: bool, reason: str = "") -> int:
            nonlocal inserted_new, review_required
            insert_vals = {
                "merchant_id": mid,
                "name": uploaded_name,
                "normalized_name": database.normalize_text(uploaded_name),
                "original_name": uploaded_name,
                "price": price,
                "available": "0" if needs_review else "1",
                "is_available": 0 if needs_review else 1,
                "last_seen_in_upload": "__NOW__",
                "needs_review": 1 if needs_review else 0,
                "currency": "LYD",
                "quality_status": "needs_review" if needs_review else "ok",
                "review_status": "needs_review" if needs_review else "approved",
                "search_mode": "review_only" if needs_review else "sellable",
                "created_at": "__NOW__",
                "updated_at": "__NOW__",
            }
            cols = [c for c in insert_vals if c in product_cols]
            col_sql = ",".join(f'"{c}"' for c in cols)
            exprs = []
            params = []
            for c in cols:
                if insert_vals[c] == "__NOW__":
                    exprs.append("datetime('now')")
                else:
                    exprs.append("?")
                    params.append(insert_vals[c])
            cur = conn.execute(f"INSERT INTO products({col_sql}) VALUES({','.join(exprs)})", params)
            pid = int(cur.lastrowid)
            if "stable_product_code" in product_cols:
                prefix = (os.getenv("PRICEBOT_STABLE_CODE_PREFIX", "PB") or "PB").strip().upper()[:8] or "PB"
                conn.execute("UPDATE products SET stable_product_code=? WHERE id=?", (f"{prefix}-{pid:06d}", pid))
            by_id[pid] = {"id": pid, "name": uploaded_name, "price": price, "cleaned_name": _weekly_clean_name(uploaded_name)}
            by_clean.setdefault(_weekly_clean_name(uploaded_name), []).append(by_id[pid])
            now_seen_ids.add(pid)
            inserted_new += 1
            _insert_uploaded_alias_if_possible(conn, pid, uploaded_name, mid)
            if needs_review:
                review_required += 1
                candidates = ""
                conn.execute(
                    """
                    INSERT INTO review_queue(merchant_id, product_name, similar_existing_id, temp_product_id, uploaded_price, reason, candidates, resolved, created_at)
                    VALUES(?,?,?,?,?,?,?,0,CURRENT_TIMESTAMP)
                    """,
                    (mid, uploaded_name, None, pid, price, reason or "needs identity review", candidates),
                )
                review_report.append({"uploaded_name": uploaded_name, "price": price, "reason": reason or "needs identity review", "candidates": candidates})
            else:
                new_report.append({"product_id": pid, "name": uploaded_name, "price": price, "decision": "INSERT_NEW_PRODUCT"})
            return pid

        def add_review_only(uploaded_name: str, price: str, reason: str, candidate_ids: List[int]) -> None:
            nonlocal review_required
            review_required += 1
            candidates = []
            for cid in candidate_ids[:8]:
                r = by_id.get(int(cid), {})
                if r:
                    candidates.append(f"{cid}: {r.get('name','')} - {r.get('price','')}")
            candidate_text = " | ".join(candidates)
            temp_id = insert_new_product(uploaded_name, price, True, reason)
            # insert_new_product already inserted a queue row. Update candidates for latest row.
            try:
                conn.execute("UPDATE review_queue SET similar_existing_id=?, candidates=? WHERE temp_product_id=? AND merchant_id=?", (int(candidate_ids[0]) if candidate_ids else None, candidate_text, temp_id, mid))
            except Exception:
                pass
            if review_report:
                review_report[-1]["candidates"] = candidate_text

        items = list(dedup.items())
        total_work = max(1, len(items))
        for pos, (clean, (_row_idx, uploaded_name, price)) in enumerate(items, start=1):
            if job_id and (pos == 1 or pos % 500 == 0 or pos == total_work):
                pct = 15 + int((pos / total_work) * 65)
                database.update_import_job(job_id, progress_percent=min(pct, 80), processed_rows=pos, total_rows=total_input_rows, updated_existing_count=matched_existing, inserted_new_count=inserted_new, duplicate_merged_count=duplicate_merged, review_required_count=review_required, invalid_rows_count=invalid_rows_count, skipped_rows_count=skipped_rows, summary=f"تمت معالجة {pos}/{total_work} منتج")
                print(f"WEEKLY_UPLOAD_PROGRESS job_id={job_id} PROCESSED={pos} UPDATED={matched_existing} INSERTED={inserted_new} REVIEW={review_required} INVALID={invalid_rows_count}", flush=True)
            exact_hits = [h for h in by_clean.get(clean, []) if int(h.get("id") or 0)]
            if len(exact_hits) == 1:
                update_existing(int(exact_hits[0]["id"]), uploaded_name, price, "products.name exact")
                continue
            if len(exact_hits) > 1:
                # Same exact name duplicated in DB. If all prices match, choose canonical lowest id.
                prices = {database.safe_price(h.get("price")) for h in exact_hits}
                if len(prices) == 1:
                    canonical = sorted(exact_hits, key=lambda x: int(x.get("id") or 0))[0]
                    update_existing(int(canonical["id"]), uploaded_name, price, "duplicate exact same price: canonical lowest id")
                else:
                    add_review_only(uploaded_name, price, "multiple exact products with different prices", [int(h["id"]) for h in exact_hits])
                continue
            candidate_ids = []
            matched_by_alias = False
            for source_map, source_name in [(merchant_aliases, "merchant alias"), (product_aliases, "product alias")]:
                ids = sorted(set(int(x) for x in source_map.get(clean, []) if int(x or 0)))
                if len(ids) == 1 and ids[0] in by_id:
                    update_existing(ids[0], uploaded_name, price, source_name)
                    matched_by_alias = True
                    candidate_ids = []
                    break
                if len(ids) > 1:
                    candidate_ids = ids
                    break
            if matched_by_alias:
                continue
            if candidate_ids:
                add_review_only(uploaded_name, price, "multiple alias candidates", candidate_ids)
                continue
            close, reason = _find_very_close_weekly_candidate(clean, existing)
            if close:
                update_existing(int(close["id"]), uploaded_name, price, reason or "very close safe match")
                continue
            if _weekly_name_needs_review(clean):
                insert_new_product(uploaded_name, price, True, "generic or too-short name")
            else:
                insert_new_product(uploaded_name, price, False, "")

        deactivated_products = 0
        deactivation_skipped_reason = ""
        if full_inventory_upload:
            existing_count = len(existing)
            processed_count = len(dedup)
            try:
                min_ratio = float(os.getenv("PRICEBOT_FULL_UPLOAD_MIN_RATIO", "0.20") or 0.20)
            except Exception:
                min_ratio = 0.20
            allow_small_full = str(os.getenv("PRICEBOT_ALLOW_SMALL_FULL_UPLOAD", "")).strip().lower() in {"1", "true", "yes", "on"}
            if existing_count >= 100 and processed_count < max(1, int(existing_count * min_ratio)) and not allow_small_full:
                deactivation_skipped_reason = f"skipped: upload rows {processed_count} below safety threshold {min_ratio:.0%} of existing catalog {existing_count}; set PRICEBOT_ALLOW_SMALL_FULL_UPLOAD=1 to override"
            else:
                ids = sorted(now_seen_ids)
                vals = {
                    "available": "0",
                    "is_available": 0,
                    "needs_review": 0,
                    "search_mode": "hidden",
                    "review_status": "stale_hidden",
                    "updated_at": "__NOW__",
                }
                sets = []
                params: List[object] = []
                for col, val in vals.items():
                    if col not in product_cols:
                        continue
                    if val == "__NOW__":
                        sets.append(f"{col}=datetime('now')")
                    else:
                        sets.append(f'{col}=?')
                        params.append(val)
                if sets:
                    if ids:
                        placeholders = ",".join("?" for _ in ids)
                        cur = conn.execute(
                            f"UPDATE products SET {', '.join(sets)} WHERE merchant_id=? AND id NOT IN ({placeholders}) AND (COALESCE(is_available,1)<>0 OR COALESCE(available,'1') NOT IN ('0','false','no','unavailable','غير متوفر'))",
                            params + [mid] + ids,
                        )
                    else:
                        cur = conn.execute(
                            f"UPDATE products SET {', '.join(sets)} WHERE merchant_id=? AND (COALESCE(is_available,1)<>0 OR COALESCE(available,'1') NOT IN ('0','false','no','unavailable','غير متوفر'))",
                            params + [mid],
                        )
                    deactivated_products = int(cur.rowcount or 0)
        else:
            deactivation_skipped_reason = "skipped: partial upload mode"
        for table in ["product_search_index", "guided_catalog_index", "product_identity_registry"]:
            if database.table_exists(conn, table):
                conn.execute(f'DELETE FROM "{table}"')

    if job_id:
        database.update_import_job(job_id, progress_percent=85, summary="إعادة بناء الفهارس")
    index_stats = _rebuild_runtime_indexes_safely()
    duration = round(time.time() - started, 2)
    summary = {
        "filename": filename,
        "total_rows": total_input_rows,
        "processed_rows": len(dedup),
        "matched_existing": matched_existing,
        "price_updated": price_updated,
        "inserted_new": inserted_new,
        "duplicate_merged": duplicate_merged,
        "review_required": review_required,
        "invalid_rows": invalid_rows_count,
        "skipped_rows": skipped_rows,
        "marked_unavailable": deactivated_products,
        "deactivation_skipped_reason": deactivation_skipped_reason,
        "full_inventory_upload": bool(full_inventory_upload),
        "duration_seconds": duration,
        "backup": str(backup),
    }
    report_dir = _write_import_reports(job_id, summary, updated_report, new_report, review_report, invalid_report, duplicate_report)
    message = (
        f"matched_existing={matched_existing}; price_updated={price_updated}; inserted_new={inserted_new}; "
        f"duplicate_merged={duplicate_merged}; marked_unavailable={deactivated_products}; "
        f"deactivation_skipped={deactivation_skipped_reason or 'no'}; "
        f"needs_review={review_required}; invalid_rows={invalid_rows_count}; report_path={report_dir}; indexes={index_stats}"
    )
    database.record_weekly_upload_history(
        filename=filename,
        total_rows=total_input_rows,
        new_products=inserted_new,
        updated_products=matched_existing,
        deactivated_products=deactivated_products,
        review_products=review_required,
        status="success",
        message=message,
        merchant_id=mid,
    )
    return {
        "count": total_input_rows,
        "processed_rows": len(dedup),
        "backup": str(backup),
        "matched_existing": matched_existing,
        "price_updated": price_updated,
        "updated_products": matched_existing,
        "inserted_new": inserted_new,
        "new_products": inserted_new,
        "duplicate_merged": duplicate_merged,
        "deactivated_products": deactivated_products,
        "marked_unavailable": deactivated_products,
        "deactivation_skipped_reason": deactivation_skipped_reason,
        "full_inventory_upload": bool(full_inventory_upload),
        "review_products": review_required,
        "review_required": review_required,
        "invalid_rows": invalid_rows_count,
        "errors": invalid_rows_count,
        "skipped_rows": skipped_rows,
        "duration_seconds": duration,
        "report_path": str(report_dir),
        "report_paths": {
            "summary": str(report_dir / "import_summary.xlsx"),
            "updated": str(report_dir / "updated_products.xlsx"),
            "new": str(report_dir / "new_products.xlsx"),
            "review": str(report_dir / "review_required.xlsx"),
            "invalid": str(report_dir / "invalid_rows.xlsx"),
            "duplicates": str(report_dir / "duplicate_rows.xlsx"),
        },
        "index_stats": index_stats,
    }


def _restart_pricebot_service() -> str:
    """Restart is opt-in after upload.

    The importer now rebuilds/invalidate runtime indexes in-process.  Avoiding a
    default systemd restart prevents losing messages that are already queued in
    asyncio memory during a busy WhatsApp period.
    """
    if str(os.getenv("PRICEBOT_DASHBOARD_SKIP_RESTART", "")).strip().lower() in {"1", "true", "yes", "on"}:
        return "restart skipped by PRICEBOT_DASHBOARD_SKIP_RESTART"
    if str(os.getenv("PRICEBOT_DASHBOARD_RESTART_AFTER_UPLOAD", "")).strip().lower() not in {"1", "true", "yes", "on"}:
        return "restart skipped: runtime indexes rebuilt in-process"
    try:
        result = subprocess.run(["sudo", "systemctl", "restart", "pricebot.service"], text=True, capture_output=True, timeout=30)
        if result.returncode == 0:
            return "pricebot.service restarted"
        return f"restart warning: {result.stderr or result.stdout}"[:500]
    except Exception as exc:
        return f"restart warning: {exc!r}"



@router.get("/dashboard", response_class=HTMLResponse)
def legacy_dashboard_redirect(request: Request, token: str = ""):
    """Backward-compatible legacy dashboard URL.

    The new merchant UI uses /merchant/login and /merchant/dashboard.  A valid
    token may bootstrap a merchant session, but /dashboard never renders the old
    fragile template directly, which prevents 502 from stale dashboard code.
    """
    if token and DASHBOARD_TOKEN and hmac.compare_digest(token, DASHBOARD_TOKEN):
        resp = RedirectResponse("/merchant/dashboard", status_code=303)
        resp.set_cookie(MERCHANT_COOKIE, _make_session(MERCHANT_USERNAME), max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
        return resp
    if _session_ok(request.cookies.get(MERCHANT_COOKIE, "")):
        return RedirectResponse("/merchant/dashboard", status_code=303)
    return RedirectResponse("/merchant/login", status_code=303)


@router.post("/dashboard/upload")
async def legacy_dashboard_upload_redirect(request: Request, file: UploadFile = File(...), csrf_token: str = Form("")):
    # Keep old forms working. New UI posts to /merchant/upload.
    return await merchant_upload_post(request, file=file, csrf_token=csrf_token)


@router.get("/admin/dashboard", response_class=HTMLResponse)
def pharmacy_admin_dashboard_alias(request: Request, token: str = "", msg: str = "", error: str = ""):
    if token and DASHBOARD_TOKEN and hmac.compare_digest(token, DASHBOARD_TOKEN):
        resp = RedirectResponse("/admin/dashboard", status_code=303)
        resp.set_cookie(DASHBOARD_COOKIE, _sign("dashboard:" + DASHBOARD_TOKEN), max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
        return resp
    # The admin router owns /admin.  This alias exists only for old links when
    # the admin module does not provide /admin/dashboard in older deployments.
    return RedirectResponse("/admin", status_code=303)


@router.post("/admin/upload")
async def pharmacy_admin_upload_alias(request: Request, file: UploadFile = File(...), csrf_token: str = Form("")):
    return await merchant_upload_post(request, file=file, csrf_token=csrf_token)


@router.post("/admin/review/resolve")
def dashboard_review_resolve(
    request: Request,
    item_id: int = Form(...),
    action: str = Form(...),
    existing_product_id: str = Form(""),
    csrf_token: str = Form(""),
):
    # Accept either merchant session or legacy dashboard token cookie.
    if not (_session_ok(request.cookies.get(MERCHANT_COOKIE, "")) or _dashboard_auth_ok(request)):
        return RedirectResponse("/merchant/login", status_code=303)
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        eid = int(existing_product_id) if str(existing_product_id or "").strip().isdigit() else None
        if not eid and action == "merge_suggested":
            eid = int(suggested_product_id) if str(suggested_product_id or "").strip().isdigit() else None
            action = "link_existing"
        if not eid and str(action or "") == "link_existing" and str(product_search or "").strip():
            q = _weekly_clean_name(product_search)
            with database.connect() as conn:
                rows = conn.execute("SELECT id, name FROM products WHERE merchant_id=? AND lower(trim(name))=? ORDER BY id LIMIT 2", (_merchant_id(), str(product_search or "").strip().lower())).fetchall()
                if not rows and q:
                    rows = conn.execute("SELECT id, name FROM products WHERE merchant_id=? AND normalized_name=? ORDER BY id LIMIT 2", (_merchant_id(), q)).fetchall()
                if not rows and q:
                    like = "%" + q.replace("%", "") + "%"
                    rows = conn.execute("SELECT id, name FROM products WHERE merchant_id=? AND lower(name) LIKE ? ORDER BY length(name), id LIMIT 2", (_merchant_id(), like)).fetchall()
                if len(rows) == 1:
                    eid = int(rows[0]["id"])
                elif len(rows) > 1:
                    raise ValueError("وجدت أكثر من منتج مشابه. اكتب اسمًا أدق أو اختر المقترح.")
        database.resolve_review_queue_item(int(item_id), action, existing_product_id=eid, merchant_id=_merchant_id())
        _rebuild_runtime_indexes_safely()
        return RedirectResponse("/merchant/review?msg=" + urllib.parse.quote("✅ تم تحديث عنصر المراجعة."), status_code=303)
    except Exception as exc:
        return RedirectResponse("/merchant/review?error=" + urllib.parse.quote(str(exc)[:250]), status_code=303)


@router.get("/merchant/login", response_class=HTMLResponse)
def login(request: Request, error: str = ""):
    warning = "" if MERCHANT_PASSWORD else "اضبط PRICEBOT_MERCHANT_USERNAME و PRICEBOT_MERCHANT_PASSWORD في .env."
    return templates.TemplateResponse("login.html", {"request": request, "title": "Merchant Login", "heading": "دخول التاجر", "subtitle": "إدارة الطلبات والكتالوج ورابط واتساب.", "error": error, "warning": warning})


@router.post("/merchant/login")
def do_login(request: Request, username: str = Form(...), password: str = Form(...)):
    if not _rate_ok(request, limit=10, window=60):
        return PlainTextResponse("rate limited", status_code=429)
    if not MERCHANT_PASSWORD or username != MERCHANT_USERNAME or not hmac.compare_digest(password, MERCHANT_PASSWORD):
        database.audit_admin("merchant_login_failed", actor=username, ip=_client_ip(request))
        return RedirectResponse("/merchant/login?error=بيانات الدخول غير صحيحة", status_code=303)
    token = _make_session(username)
    database.audit_admin("merchant_login_ok", actor=username, ip=_client_ip(request), details={"merchant_id": _merchant_id()})
    resp = RedirectResponse("/merchant/dashboard", status_code=303)
    resp.set_cookie(MERCHANT_COOKIE, token, max_age=MERCHANT_TTL_SECONDS, httponly=True, secure=True, samesite="lax")
    return resp


@router.post("/merchant/logout")
def logout(request: Request, csrf_token: str = Form("")):
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    resp = RedirectResponse("/merchant/login", status_code=303)
    resp.delete_cookie(MERCHANT_COOKIE)
    return resp



@router.get("/merchant", response_class=HTMLResponse)
def merchant_home_redirect(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return RedirectResponse("/merchant/dashboard", status_code=303)


@router.get("/merchant/dashboard", response_class=HTMLResponse)
def merchant_dashboard(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    context = _merchant_dashboard_context(request, msg=msg, error=error)
    return _render_safe(request, "merchant_dashboard_professional.html", context, fallback_title="لوحة التاجر")



@router.get("/merchant/upload", response_class=HTMLResponse)
def merchant_upload_page(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    context = {
        "request": request,
        "title": "رفع قائمة الأسعار",
        "nav": _merchant_nav("upload"),
        "uploads": _safe_value(lambda: database.list_product_upload_history(limit=5, merchant_id=_merchant_id()), [], "upload_page_history"),
        "import_jobs": _safe_value(lambda: database.list_import_jobs(limit=5, merchant_id=_merchant_id()), [], "import_jobs"),
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_upload.html", context, fallback_title="رفع Excel")



def _job_storage_dir() -> Path:
    try:
        base = database.get_db_path().parent / "import_jobs"
    except Exception:
        base = Path(tempfile.gettempdir()) / "pricebot_import_jobs"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _process_weekly_upload_job(job_id: int, saved_path: str, filename: str, full_inventory_upload: bool = True) -> None:
    """Background weekly upload job with import lock and progress polling.

    The HTTP request returns immediately.  The job survives page navigation and
    writes progress to import_jobs.  The bot may keep serving read-only product
    lookups while writes are guarded by import.lock/system job status.
    """
    database.set_import_lock(job_id)
    try:
        database.update_import_job(job_id, status="PROCESSING", progress_percent=3, summary="⏳ جاري تجهيز الملف...", started_at="__NOW__")
        path = Path(saved_path)
        data = path.read_bytes()
        rows = _read_price_rows_from_upload(filename, data)
        database.update_import_job(job_id, progress_percent=10, total_rows=len(rows), processed_rows=0, summary=f"تمت قراءة {len(rows)} صف من Excel")
        result = _smart_weekly_products_upload(rows, filename, job_id=job_id, full_inventory_upload=full_inventory_upload)
        summary = (
            f"✅ تم تحديث الكتالوج بنجاح | "
            f"matched_existing={result.get('matched_existing', 0)} | "
            f"price_updated={result.get('price_updated', 0)} | "
            f"inserted_new={result.get('inserted_new', result.get('new_products', 0))} | "
            f"duplicate_merged={result.get('duplicate_merged', 0)} | "
            f"marked_unavailable={result.get('marked_unavailable', result.get('deactivated_products', 0))} | "
            f"deactivation_skipped={result.get('deactivation_skipped_reason') or 'no'} | "
            f"needs_review={result.get('review_required', result.get('review_products', 0))} | "
            f"invalid_rows={result.get('invalid_rows', 0)}"
        )
        restart_msg = _restart_pricebot_service()
        database.update_import_job(
            job_id,
            status="DONE",
            progress_percent=100,
            processed_rows=int(result.get("processed_rows") or result.get("count") or 0),
            total_rows=int(result.get("count") or 0),
            updated_existing_count=int(result.get("matched_existing") or 0),
            inserted_new_count=int(result.get("inserted_new") or result.get("new_products") or 0),
            duplicate_merged_count=int(result.get("duplicate_merged") or 0),
            review_required_count=int(result.get("review_required") or result.get("review_products") or 0),
            invalid_rows_count=int(result.get("invalid_rows") or 0),
            skipped_rows_count=int(result.get("skipped_rows") or result.get("marked_unavailable") or result.get("deactivated_products") or 0),
            summary=f"{summary} | {restart_msg}",
            result_summary_json=json.dumps(result, ensure_ascii=False, default=str),
            report_path=str(result.get("report_path") or ""),
        )
        print(f"WEEKLY_UPLOAD_JOB_DONE | job_id={job_id} | {summary} | report={result.get('report_path')}", flush=True)
    except Exception as exc:
        print(f"WEEKLY_UPLOAD_JOB_FAILED | job_id={job_id} | {exc!r}", flush=True)
        try:
            database.update_import_job(job_id, status="FAILED", progress_percent=100, error_message=repr(exc), summary="فشل الرفع")
            database.record_weekly_upload_history(
                filename=filename,
                total_rows=0,
                new_products=0,
                updated_products=0,
                deactivated_products=0,
                review_products=0,
                status="failed",
                message=repr(exc),
                merchant_id=_merchant_id(),
            )
        except Exception:
            pass
    finally:
        database.clear_import_lock()


@router.get("/merchant/job/{job_id}", response_class=HTMLResponse)
def merchant_job_page(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "import_job")
    context = {"request": request, "title": "حالة الاستيراد", "nav": _merchant_nav("upload"), "job": job, "csrf_token": _csrf_token(request)}
    return _render_safe(request, "merchant_import_job.html", context, fallback_title="حالة الاستيراد")


@router.get("/merchant/job_status/{job_id}")
def merchant_job_status(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "import_job_status")
    return job or {"status": "NOT_FOUND"}


@router.get("/merchant/job/{job_id}/report/{report_name}")
def merchant_job_report_download(request: Request, job_id: int, report_name: str):
    auth = _require_auth(request)
    if auth:
        return auth
    allowed = {"import_summary.xlsx", "updated_products.xlsx", "new_products.xlsx", "review_required.xlsx", "invalid_rows.xlsx", "duplicate_rows.xlsx"}
    safe_name = Path(report_name).name
    if safe_name not in allowed:
        return PlainTextResponse("not found", status_code=404)
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "import_job_report")
    report_path = Path(str((job or {}).get("report_path") or ""))
    if not report_path.exists() or not report_path.is_dir():
        return PlainTextResponse("report not ready", status_code=404)
    target = (report_path / safe_name).resolve()
    try:
        if not str(target).startswith(str(report_path.resolve())) or not target.exists():
            return PlainTextResponse("not found", status_code=404)
        return StreamingResponse(target.open("rb"), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="{safe_name}"'})
    except Exception:
        return PlainTextResponse("not found", status_code=404)


@router.get("/admin/job_status/{job_id}")
def admin_job_status(request: Request, job_id: int):
    # Compatibility endpoint requested for polling.  It uses the same merchant
    # session guard here because this router owns merchant/admin dashboard UI.
    auth = _require_auth(request)
    if auth:
        return auth
    job = _safe_value(lambda: database.get_import_job(int(job_id), merchant_id=_merchant_id()), {}, "admin_import_job_status")
    return job or {"status": "NOT_FOUND"}


@router.get("/admin/import-jobs/{job_id}/status")
def admin_import_job_status_alias(request: Request, job_id: int):
    # Endpoint name requested by the new polling UI/spec.  It returns JSON and
    # never runs the import inside the request.
    return admin_job_status(request, job_id)

@router.get("/merchant/import-jobs/{job_id}/status")
def merchant_import_job_status_alias(request: Request, job_id: int):
    return merchant_job_status(request, job_id)



def _smart_weekly_products_dry_run(rows: List[Tuple[str, str]], filename: str, full_inventory_upload: bool = True) -> Dict[str, Any]:
    """Read-only weekly upload preview.

    It estimates update/new/review/deactivation impact without writing products,
    aliases, review_queue, upload history, backups, or import jobs.
    """
    mid = _merchant_id()
    total_rows = len(rows or [])
    dedup: Dict[str, Tuple[int, str, str]] = {}
    invalid: List[Dict[str, Any]] = []
    duplicates = 0
    skipped = 0
    for idx, (name, price) in enumerate(rows or [], start=1):
        clean = _weekly_clean_name(name)
        if not clean:
            skipped += 1
            continue
        ok, parsed_price = _parse_weekly_price(price)
        if not ok:
            invalid.append({"row_number": idx, "name": str(name or ""), "price": str(price or ""), "reason": "invalid price"})
            continue
        if clean in dedup:
            duplicates += 1
        dedup[clean] = (idx, str(name or "").strip(), parsed_price)

    result: Dict[str, Any] = {
        "filename": filename,
        "total_rows": total_rows,
        "processed_rows": len(dedup),
        "invalid_rows": len(invalid),
        "duplicate_merged": duplicates,
        "skipped_rows": skipped,
        "matched_existing": 0,
        "price_changed": 0,
        "new_products": 0,
        "review_required_estimate": 0,
        "marked_unavailable_estimate": 0,
        "deactivation_skipped_reason": "",
        "invalid_preview": invalid[:25],
        "new_preview": [],
        "updated_preview": [],
        "review_preview": [],
        "full_inventory_upload": bool(full_inventory_upload),
    }
    with database.connect() as conn:
        existing = []
        if database.table_exists(conn, "products"):
            for r in conn.execute("SELECT id, name, price, merchant_id FROM products WHERE merchant_id=?", (mid,)).fetchall():
                d = database.dict_row(r)
                d["cleaned_name"] = _weekly_clean_name(d.get("name") or "")
                existing.append(d)
        by_clean: Dict[str, List[Dict[str, Any]]] = {}
        by_id: Dict[int, Dict[str, Any]] = {}
        for row in existing:
            pid = int(row.get("id") or 0)
            if pid:
                by_id[pid] = row
            by_clean.setdefault(str(row.get("cleaned_name") or ""), []).append(row)
        product_aliases, merchant_aliases = _load_weekly_alias_indexes(conn, mid)
        seen_ids: set[int] = set()
        for clean, (_, uploaded_name, price) in dedup.items():
            exact = by_clean.get(clean) or []
            alias_ids = product_aliases.get(clean) or merchant_aliases.get(clean) or []
            match_id = 0
            reason = ""
            if len(exact) == 1:
                match_id = int(exact[0].get("id") or 0)
                reason = "exact_name"
            elif len(alias_ids) == 1:
                match_id = int(alias_ids[0])
                reason = "confirmed_alias"
            elif len(exact) > 1 or len(set(alias_ids)) > 1:
                result["review_required_estimate"] += 1
                result["review_preview"].append({"name": uploaded_name, "price": price, "reason": "ambiguous match"})
                continue
            if match_id and match_id in by_id:
                seen_ids.add(match_id)
                row = by_id[match_id]
                result["matched_existing"] += 1
                old_price = database.safe_price(row.get("price"))
                if str(old_price) != str(price):
                    result["price_changed"] += 1
                if len(result["updated_preview"]) < 25:
                    result["updated_preview"].append({"product_id": match_id, "name": row.get("name"), "old_price": old_price, "new_price": price, "reason": reason})
            else:
                # Conservative preview: short/generic names likely require review; specific names are new.
                tokens = [t for t in re.findall(r"[A-Za-z\u0600-\u06FF0-9%/+-]+", uploaded_name) if len(t) >= 3]
                if len(tokens) < 2 and not re.search(r"\d", uploaded_name):
                    result["review_required_estimate"] += 1
                    if len(result["review_preview"]) < 25:
                        result["review_preview"].append({"name": uploaded_name, "price": price, "reason": "generic/short name"})
                else:
                    result["new_products"] += 1
                    if len(result["new_preview"]) < 25:
                        result["new_preview"].append({"name": uploaded_name, "price": price})
        if full_inventory_upload:
            existing_count = len(existing)
            processed_count = len(dedup)
            try:
                min_ratio = float(os.getenv("PRICEBOT_FULL_UPLOAD_MIN_RATIO", "0.20") or 0.20)
            except Exception:
                min_ratio = 0.20
            allow_small_full = str(os.getenv("PRICEBOT_ALLOW_SMALL_FULL_UPLOAD", "")).strip().lower() in {"1", "true", "yes", "on"}
            if existing_count >= 100 and processed_count < max(1, int(existing_count * min_ratio)) and not allow_small_full:
                result["deactivation_skipped_reason"] = f"skipped: upload rows {processed_count} below {min_ratio:.0%} of existing catalog {existing_count}"
                result["marked_unavailable_estimate"] = 0
            else:
                result["marked_unavailable_estimate"] = max(0, existing_count - len(seen_ids))
        else:
            result["deactivation_skipped_reason"] = "skipped: partial upload mode"
    return result


@router.post("/merchant/upload", response_class=HTMLResponse)
async def merchant_upload_post(request: Request, file: UploadFile = File(...), csrf_token: str = Form(""), full_inventory_upload: str = Form("1"), action: str = Form("apply")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    filename = file.filename or "products.xlsx"
    suffix = Path(filename).suffix.lower()
    if suffix not in {".xlsx", ".xls"}:
        return RedirectResponse("/merchant/upload?error=" + urllib.parse.quote("يسمح فقط بملفات xlsx أو xls"), status_code=303)
    try:
        data = await file.read()
        if not data:
            return RedirectResponse("/merchant/upload?error=" + urllib.parse.quote("الملف فارغ"), status_code=303)
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", filename)[:180] or "upload.xlsx"
        saved_path = _job_storage_dir() / f"{int(time.time())}_{secrets.token_hex(4)}_{safe_name}"
        saved_path.write_bytes(data)
        full_upload = str(full_inventory_upload).strip().lower() in {"1", "true", "yes", "on"}
        if str(action or "").strip().lower() == "dry_run":
            rows = _read_price_rows_from_upload(filename, data)
            preview = _smart_weekly_products_dry_run(rows, filename, full_inventory_upload=full_upload)
            return _render_safe(
                request,
                "merchant_upload_dry_run.html",
                {
                    "request": request,
                    "title": "معاينة الرفع",
                    "nav": _merchant_nav("upload"),
                    "preview": preview,
                    "csrf_token": _csrf_token(request),
                },
                fallback_title="معاينة الرفع",
            )
        job_id = database.create_import_job(filename, str(saved_path), job_type="weekly_upload", merchant_id=_merchant_id())
        threading.Thread(target=_process_weekly_upload_job, args=(int(job_id), str(saved_path), filename, full_upload), daemon=True).start()
        return RedirectResponse(f"/merchant/job/{int(job_id)}", status_code=303)
    except Exception as exc:
        print(f"MERCHANT_WEEKLY_UPLOAD_QUEUE_ERROR | {exc!r}", flush=True)
        return RedirectResponse("/merchant/upload?error=" + urllib.parse.quote(str(exc)[:250]), status_code=303)


def _preview_products(needs_review: object = None, limit: int = 20, only_new_seen: bool = False) -> List[Dict[str, object]]:
    with database.connect() as conn:
        if not _table_exists_safe(conn, "products"):
            return []
        cols = set(database.table_columns(conn, "products"))
        where = ["merchant_id=?"] if "merchant_id" in cols else []
        params: List[object] = [_merchant_id()] if "merchant_id" in cols else []
        if needs_review is not None and "needs_review" in cols:
            where.append("COALESCE(needs_review,0)=?")
            params.append(1 if needs_review else 0)
        if only_new_seen and "last_seen_in_upload" in cols:
            where.append("last_seen_in_upload >= datetime('now','-2 hours')")
        sql_where = ("WHERE " + " AND ".join(where)) if where else ""
        order = "ORDER BY id DESC"
        rows = conn.execute(f"SELECT * FROM products {sql_where} {order} LIMIT ?", params + [int(limit or 20)]).fetchall()
        return [database.dict_row(r) for r in rows]


@router.get("/merchant/review", response_class=HTMLResponse)
def merchant_review_page(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    items = _safe_value(lambda: database.list_review_queue(limit=100, merchant_id=_merchant_id()), [], "review_page")
    review_products = _safe_value(lambda: _preview_products(needs_review=True, limit=100), [], "review_products")
    context = {
        "request": request,
        "title": "قائمة المراجعة",
        "nav": _merchant_nav("review"),
        "items": items,
        "review_products": review_products,
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_review.html", context, fallback_title="قائمة المراجعة")


@router.post("/merchant/review/resolve")
def merchant_review_resolve(
    request: Request,
    item_id: int = Form(...),
    action: str = Form(...),
    existing_product_id: str = Form(""),
    suggested_product_id: str = Form(""),
    product_search: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        eid = int(existing_product_id) if str(existing_product_id or "").strip().isdigit() else None
        if not eid and action == "merge_suggested":
            eid = int(suggested_product_id) if str(suggested_product_id or "").strip().isdigit() else None
            action = "link_existing"
        if not eid and str(action or "") == "link_existing" and str(product_search or "").strip():
            q = _weekly_clean_name(product_search)
            with database.connect() as conn:
                rows = conn.execute("SELECT id, name FROM products WHERE merchant_id=? AND lower(trim(name))=? ORDER BY id LIMIT 2", (_merchant_id(), str(product_search or "").strip().lower())).fetchall()
                if not rows and q:
                    rows = conn.execute("SELECT id, name FROM products WHERE merchant_id=? AND normalized_name=? ORDER BY id LIMIT 2", (_merchant_id(), q)).fetchall()
                if not rows and q:
                    like = "%" + q.replace("%", "") + "%"
                    rows = conn.execute("SELECT id, name FROM products WHERE merchant_id=? AND lower(name) LIKE ? ORDER BY length(name), id LIMIT 2", (_merchant_id(), like)).fetchall()
                if len(rows) == 1:
                    eid = int(rows[0]["id"])
                elif len(rows) > 1:
                    raise ValueError("وجدت أكثر من منتج مشابه. اكتب اسمًا أدق أو اختر المقترح.")
        database.resolve_review_queue_item(int(item_id), action, existing_product_id=eid, merchant_id=_merchant_id())
        _rebuild_runtime_indexes_safely()
        return RedirectResponse("/merchant/review?msg=" + urllib.parse.quote("✅ تم تحديث عنصر المراجعة."), status_code=303)
    except Exception as exc:
        return RedirectResponse("/merchant/review?error=" + urllib.parse.quote(str(exc)[:250]), status_code=303)


@router.get("/merchant/analytics", response_class=HTMLResponse)
def merchant_analytics_page(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    context = {
        "request": request,
        "title": "الإحصائيات",
        "nav": _merchant_nav("analytics"),
        "analytics": _analytics_context(_merchant_id()),
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_analytics.html", context, fallback_title="الإحصائيات")


@router.get("/merchant/settings", response_class=HTMLResponse)
def merchant_settings_page(request: Request, msg: str = "", error: str = ""):
    auth = _require_auth(request)
    if auth:
        return auth
    context = {
        "request": request,
        "title": "إعدادات الصيدلية",
        "nav": _merchant_nav("settings"),
        "settings": _settings(),
        "whatsapp_link": _whatsapp_link(),
        "msg": msg,
        "error": error,
        "csrf_token": _csrf_token(request),
    }
    return _render_safe(request, "merchant_settings.html", context, fallback_title="الإعدادات")


@router.get("/merchant/logout")
def logout_get(request: Request):
    resp = RedirectResponse("/merchant/login", status_code=303)
    resp.delete_cookie(MERCHANT_COOKIE)
    return resp


@router.get("/merchant/catalog", response_class=HTMLResponse)
def merchant_catalog_redirect(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return RedirectResponse("/merchant/upload", status_code=303)


@router.get("/merchant/orders", response_class=HTMLResponse)
def merchant_orders(request: Request, status: str = "pending"):
    auth = _require_auth(request)
    if auth:
        return auth
    if status not in {"pending", "confirmed", "done", "rejected"}:
        status = "pending"
    return _render(request, "merchant_orders.html", {"request": request, "title": "Merchant Orders", "nav": _merchant_nav("orders"), "orders": database.list_orders(status, 300, merchant_id=_merchant_id()), "status": status})


@router.post("/merchant/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str, csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status, merchant_id=_merchant_id())
    database.audit_admin("merchant_order_status_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"order_id": order_id, "status": status, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/orders", status_code=303)


@router.get("/merchant/share", response_class=HTMLResponse)
def merchant_share(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    return _render(request, "merchant_share.html", {"request": request, "title": "QR & Link", "nav": _merchant_nav("share"), "whatsapp_link": _whatsapp_link(), "settings": _settings()})


@router.post("/merchant/settings")
def merchant_settings_update(
    request: Request,
    pharmacy_name: str = Form(""),
    whatsapp_number: str = Form(""),
    qr_message: str = Form(""),
    working_hours: str = Form("24 ساعة"),
    delivery_enabled: str = Form("0"),
    currency: str = Form("LYD"),
    welcome_text: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    database.update_merchant_settings(_merchant_id(), pharmacy_name, whatsapp_number, qr_message, working_hours, delivery_enabled, currency, welcome_text)
    database.audit_admin("merchant_settings_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/settings?msg=" + urllib.parse.quote("✅ تم حفظ الإعدادات"), status_code=303)


@router.get("/merchant/qr.png")
def merchant_qr(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    img = qrcode.make(_whatsapp_link())
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


@router.get("/merchant/catalog", response_class=HTMLResponse)
def merchant_catalog(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    jobs = database.list_catalog_import_jobs(20)
    reviews = pending_reviews(limit=80)
    return _render(request, "merchant_catalog.html", {"request": request, "title": "Merchant Catalog", "nav": _merchant_nav("catalog"), "jobs": jobs, "reviews": reviews})


@router.post("/merchant/catalog/upload")
async def merchant_catalog_upload(request: Request, background_tasks: BackgroundTasks, file: UploadFile = File(...), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    suffix = Path(file.filename or "upload.xlsx").suffix or ".xlsx"
    tmpdir = Path(tempfile.mkdtemp(prefix="pricebot_merchant_catalog_"))
    excel_path = tmpdir / ("upload" + suffix)
    excel_path.write_bytes(await file.read())
    job_id = database.create_catalog_import_job(file.filename or "upload.xlsx", str(excel_path), status="queued")
    database.update_catalog_import_job(job_id, job_type="merchant_staging_import", merchant_id=_merchant_id(), requires_approval=1, report_text="Merchant upload queued for staging. Production unchanged until admin approval.")
    if os.getenv("PRICEBOT_USE_CELERY", "").lower() in {"1", "true", "yes", "on"}:
        try:
            catalog_stage_import.delay(int(job_id), str(excel_path), int(_merchant_id()))
        except Exception:
            background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(_merchant_id()))
    else:
        background_tasks.add_task(catalog_stage_import, int(job_id), str(excel_path), int(_merchant_id()))
    database.audit_admin("merchant_catalog_staging_queued", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"job_id": job_id, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/catalog", status_code=303)


@router.get("/merchant/catalog/jobs/{job_id}", response_class=HTMLResponse)
def merchant_catalog_job(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth:
        return auth
    report = job_report(int(job_id))
    return _render(request, "merchant_catalog_job.html", {"request": request, "title": f"Catalog Job #{job_id}", "nav": _merchant_nav("catalog"), "job_id": job_id, "report": report})


@router.post("/merchant/catalog/jobs/{job_id}/approve")
def merchant_catalog_job_approve(
    request: Request,
    job_id: int,
    csrf_token: str = Form(""),
    full_inventory_upload: str = Form(""),
    mark_missing_unavailable: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        approve_staging_job(
            int(job_id),
            actor=MERCHANT_USERNAME,
            full_inventory_upload=str(full_inventory_upload).lower() in {"1", "true", "yes", "on"},
            mark_missing_unavailable=str(mark_missing_unavailable).lower() in {"1", "true", "yes", "on"},
        )
    except Exception as exc:
        database.audit_admin("merchant_catalog_approve_failed", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"job_id": job_id, "error": repr(exc)})
        return PlainTextResponse(f"approval failed: {type(exc).__name__}: {exc}", status_code=500)
    return RedirectResponse(f"/merchant/catalog/jobs/{job_id}", status_code=303)


@router.post("/merchant/catalog/jobs/{job_id}/reject")
def merchant_catalog_job_reject(request: Request, job_id: int, reason: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    reject_staging_job(int(job_id), actor=MERCHANT_USERNAME, reason=reason)
    return RedirectResponse("/merchant/catalog", status_code=303)


@router.post("/merchant/catalog/review/{review_id}/approve")
def merchant_catalog_review_approve(
    request: Request,
    review_id: int,
    suggested_brand: str = Form(""),
    suggested_family: str = Form(""),
    suggested_category: str = Form(""),
    suggested_form: str = Form(""),
    suggested_strength: str = Form(""),
    suggested_size: str = Form(""),
    suggested_pack: str = Form(""),
    suggested_aliases: str = Form(""),
    review_notes: str = Form(""),
    resolved_product_id: str = Form(""),
    apply_price: str = Form(""),
    csrf_token: str = Form(""),
):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    try:
        approve_review_item(
            int(review_id),
            actor=MERCHANT_USERNAME,
            suggested_brand=suggested_brand,
            suggested_family=suggested_family,
            suggested_category=suggested_category,
            suggested_form=suggested_form,
            suggested_strength=suggested_strength,
            suggested_size=suggested_size,
            suggested_pack=suggested_pack,
            suggested_aliases=suggested_aliases,
            review_notes=review_notes,
            resolved_product_id=resolved_product_id,
            apply_price=apply_price,
        )
    except Exception as exc:
        database.audit_admin("merchant_review_approve_failed", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"review_id": review_id, "error": repr(exc)})
        return PlainTextResponse(f"review approval failed: {type(exc).__name__}: {exc}", status_code=500)
    referer = request.headers.get("referer") or "/merchant/catalog"
    return RedirectResponse(referer, status_code=303)


@router.post("/merchant/catalog/review/{review_id}/reject")
def merchant_catalog_review_reject(request: Request, review_id: int, reason: str = Form(""), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    reject_review_item(int(review_id), actor=MERCHANT_USERNAME, reason=reason)
    referer = request.headers.get("referer") or "/merchant/catalog"
    return RedirectResponse(referer, status_code=303)


@router.get("/merchant/learning", response_class=HTMLResponse)
def merchant_learning(request: Request):
    auth = _require_auth(request)
    if auth:
        return auth
    items = database.list_learning_inbox("pending", 100)
    return _render(request, "merchant_learning.html", {"request": request, "title": "Merchant Learning", "nav": _merchant_nav("learning"), "items": items})



@router.get("/merchant/products", response_class=HTMLResponse)
def merchant_products(request: Request, q: str = "", availability: str = "all", review: str = "all"):
    auth = _require_auth(request)
    if auth:
        return auth
    def load_products():
        with database.connect() as conn:
            if not _table_exists_safe(conn, "products"):
                return []
            cols = set(database.table_columns(conn, "products"))
            where = []
            params: List[object] = []
            if "merchant_id" in cols:
                where.append("merchant_id=?")
                params.append(_merchant_id())
            nq = q.strip()
            if nq:
                key = f"%{database.normalize_text(nq)}%"
                if "normalized_name" in cols:
                    where.append("(normalized_name LIKE ? OR name LIKE ?)")
                    params.extend([key, f"%{nq}%"])
                else:
                    where.append("name LIKE ?")
                    params.append(f"%{nq}%")
            if availability == "available" and "is_available" in cols:
                where.append("COALESCE(is_available,1)=1")
            elif availability == "unavailable" and "is_available" in cols:
                where.append("COALESCE(is_available,1)=0")
            if review == "needs_review" and "needs_review" in cols:
                where.append("COALESCE(needs_review,0)=1")
            elif review == "approved" and "needs_review" in cols:
                where.append("COALESCE(needs_review,0)=0")
            sql_where = "WHERE " + " AND ".join(where) if where else ""
            rows = conn.execute(f"SELECT * FROM products {sql_where} ORDER BY id DESC LIMIT 300", params).fetchall()
            return [database.dict_row(r) for r in rows]
    products = _safe_value(load_products, [], "merchant_products")
    return _render_safe(request, "merchant_products.html", {
        "request": request,
        "title": "المنتجات",
        "nav": _merchant_nav("products"),
        "products": products,
        "q": q,
        "availability": availability,
        "review": review,
        "csrf_token": _csrf_token(request),
    }, fallback_title="المنتجات")


@router.post("/merchant/products/{product_id}/price")
def merchant_product_price(request: Request, product_id: int, price: str = Form(...), csrf_token: str = Form("")):
    auth = _require_auth(request)
    if auth:
        return auth
    bad = _require_csrf(request, csrf_token)
    if bad:
        return bad
    with database.connect() as conn:
        conn.execute("UPDATE products SET price=?, updated_at=datetime('now') WHERE id=? AND merchant_id=?", (price.strip(), int(product_id), _merchant_id()))
    database.audit_admin("merchant_product_price_update", actor=MERCHANT_USERNAME, ip=_client_ip(request), details={"product_id": product_id, "merchant_id": _merchant_id()})
    return RedirectResponse("/merchant/products", status_code=303)
