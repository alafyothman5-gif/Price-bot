from __future__ import annotations

"""Unified candidate safety filter for text and Vision results."""

from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any, Iterable, List, Sequence, Set, Tuple

from normalizer import compact_normalize, normalize_text
from query_slots import canonical_form
from services.catalog.identity_generation import WEAK_TOKENS



def _token_similar(a: str, b: str) -> bool:
    a = normalize_text(a)
    b = normalize_text(b)
    if not a or not b:
        return False
    if a == b or a in b or b in a:
        return True
    if len(a) < 5 or len(b) < 5:
        return False
    return SequenceMatcher(None, a, b).ratio() >= 0.84


def _token_in_text(token: str, text: str) -> bool:
    token = normalize_text(token)
    text = normalize_text(text)
    if not token or not text:
        return False
    if token in text or token in compact_normalize(text):
        return True
    return any(_token_similar(token, part) for part in text.split())

CATEGORY_COMPAT = {
    "medicine": {"medicine", "ادويه", "ادوية", "أدوية"},
    "cosmetic": {"cosmetic", "عنايه", "عناية", "عناية بالبشرة", "عنايه بالبشره", "عناية بالشعر", "personal_care"},
    "supplement": {"supplement", "مكمل", "مكملات", "مكملات وفيتامينات"},
}


@dataclass
class SafetyDecision:
    products: List[Any] = field(default_factory=list)
    rejected: List[Tuple[str, str]] = field(default_factory=list)
    strong_tokens: List[str] = field(default_factory=list)


class CandidateSafetyFilter:
    def __init__(self, weak_tokens: Iterable[str] | None = None) -> None:
        self.weak_tokens: Set[str] = {normalize_text(x) for x in (weak_tokens or WEAK_TOKENS) if normalize_text(x)}

    def strong_tokens(self, query: Any) -> List[str]:
        out: List[str] = []
        for t in normalize_text(query).split():
            if not t or t in self.weak_tokens:
                continue
            if canonical_form(t):
                continue
            if t.isdigit():
                continue
            if len(t) <= 2 and not any(ch.isdigit() for ch in t):
                continue
            if t not in out:
                out.append(t)
        return out

    @staticmethod
    def _name(ip: Any) -> str:
        return str(getattr(ip, "name", "") or getattr(ip, "product", {}).get("name", "") or "")

    @staticmethod
    def _brand(ip: Any) -> str:
        return normalize_text(getattr(ip, "brand", "") or getattr(ip, "product", {}).get("brand", "") or "")

    @staticmethod
    def _category(ip: Any) -> str:
        return normalize_text(getattr(ip, "category", "") or getattr(ip, "product", {}).get("category", "") or getattr(ip, "product", {}).get("main_section", "") or "")

    @staticmethod
    def _form(ip: Any) -> str:
        prod = getattr(ip, "product", {}) or {}
        return canonical_form(getattr(ip, "form", "") or prod.get("form") or prod.get("product_type") or prod.get("medicine_form") or prod.get("name") or "")

    @staticmethod
    def _identity_text(ip: Any) -> str:
        return normalize_text(getattr(ip, "identity_text", "") or " ".join(str((getattr(ip, "product", {}) or {}).get(k) or "") for k in ["name", "brand", "product_family", "aliases", "ocr_keywords"]))

    @staticmethod
    def _identity_compact(ip: Any) -> str:
        return compact_normalize(CandidateSafetyFilter._identity_text(ip))

    def _category_ok(self, requested_category: str, ip: Any) -> bool:
        requested_category = normalize_text(requested_category)
        if not requested_category:
            return True
        cat = self._category(ip)
        if not cat:
            return True
        allowed = CATEGORY_COMPAT.get(requested_category, {requested_category})
        return cat in {normalize_text(x) for x in allowed}

    def filter(self, query: Any, candidates: Sequence[Any], *, requested_brand: str = "", requested_family: str = "", requested_form: str = "", requested_category: str = "", exact_allowed: bool = False, limit: int = 5) -> SafetyDecision:
        q = normalize_text(query)
        qcompact = compact_normalize(q)
        strong = self.strong_tokens(q)
        requested_brand = normalize_text(requested_brand)
        requested_family = normalize_text(requested_family)
        requested_form = canonical_form(requested_form) or normalize_text(requested_form)
        kept: List[Any] = []
        rejected: List[Tuple[str, str]] = []
        for ip in candidates:
            name = self._name(ip)
            hay = self._identity_text(ip)
            hayc = self._identity_compact(ip)
            brand = self._brand(ip)
            if requested_brand and requested_brand not in {brand} and requested_brand not in hay.split() and requested_brand not in hay:
                rejected.append((name, f"brand_mismatch:{requested_brand}")); continue
            if requested_family:
                fam_tokens = [t for t in self.strong_tokens(requested_family) if t != requested_brand]
                if fam_tokens and not all(_token_in_text(t, hay) or t in hayc for t in fam_tokens):
                    rejected.append((name, "family_mismatch")); continue
            if requested_form:
                pf = self._form(ip)
                if pf and pf != requested_form and not ({pf, requested_form} <= {"syrup", "suspension"}):
                    rejected.append((name, f"form_mismatch:{requested_form}!={pf}")); continue
            if not self._category_ok(requested_category, ip):
                rejected.append((name, f"category_mismatch:{requested_category}")); continue
            # Exact registered keys may pass if they also survived brand/form/category locks.
            exact_keys = getattr(ip, "exact_keys", set()) or set()
            exact_hit = exact_allowed and (q in exact_keys or qcompact in exact_keys or q == normalize_text(name) or qcompact == compact_normalize(name))
            if exact_hit:
                kept.append(ip); continue
            hits = [t for t in strong if _token_in_text(t, hay) or t in hayc]
            # Weak-only candidates are never allowed to survive.
            if not strong:
                rejected.append((name, "weak_tokens_only")); continue
            if len(strong) == 1:
                t = strong[0]
                if requested_brand and t in {requested_brand, brand}:
                    kept.append(ip); continue
                if t == brand or t == normalize_text(name):
                    kept.append(ip); continue
                rejected.append((name, f"single_token_not_identity:{t}")); continue
            if all(_token_in_text(t, hay) or t in hayc for t in strong):
                kept.append(ip); continue
            # Same brand + same family is safe even if OCR contains extra marketing words.
            if requested_brand and len(hits) >= 2:
                kept.append(ip); continue
            rejected.append((name, "strong_tokens_not_satisfied"))
        # Dedupe and cap 1-5 candidates.
        out: List[Any] = []
        seen = set()
        for ip in kept:
            pid = getattr(ip, "product_id", None) or (getattr(ip, "product", {}) or {}).get("id") or id(ip)
            if pid in seen:
                continue
            seen.add(pid)
            out.append(ip)
            if len(out) >= limit:
                break
        return SafetyDecision(products=out, rejected=rejected[:30], strong_tokens=strong)
