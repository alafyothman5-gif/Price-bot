from __future__ import annotations

import pytest

import database
from services.vision import ai_product_matcher


def test_evidence_validator_rejects_semantic_skin_match_without_text_overlap():
    result = ai_product_matcher.validate_text_evidence_for_match(
        "Evolsin Ekzem Neurodermitis Creme",
        "ACM sensitelial",
    )
    assert result["passed"] is False
    assert "acm" in result.get("missing_tokens", [])
    assert "sensitelial" in result.get("missing_tokens", [])


def test_evidence_validator_allows_flagyl_and_hemazym():
    assert ai_product_matcher.validate_text_evidence_for_match(
        "flagyl 125mg 5ml metronidazole oral suspension 60 ml",
        "Flagyl 125mg",
    )["passed"] is True
    assert ai_product_matcher.validate_text_evidence_for_match(
        "Hemazym Liposomal Iron Folic Acid",
        "Hemazym",
    )["passed"] is True


@pytest.mark.asyncio
async def test_ai_matcher_evidence_guard_blocks_wrong_confirmation(monkeypatch, tmp_path):
    import app

    database.configure_db_path(str(tmp_path / "evidence_guard.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        cur = conn.execute(
            "INSERT INTO products(name, normalized_name, price, available, quality_status, review_status, search_mode) VALUES(?,?,?,?,?,?,?)",
            ("ACM sensitelial", "acm sensitelial", "99", "1", "approved", "approved", "sellable"),
        )
        product_id = int(cur.lastrowid)

    async def fake_download(media_id):
        return b"image", "image/jpeg"

    async def fake_extract(image_bytes, mime):
        return {
            "status": "OK",
            "query": "Evolsin Ekzem Neurodermitis Creme",
            "foreground_product_text": "Evolsin Ekzem Neurodermitis Creme",
            "raw_vision_text": "Evolsin Ekzem Neurodermitis Creme",
            "confidence": 0.95,
        }

    async def fake_ai(text):
        return {"matched": True, "product_id": product_id, "name": "ACM sensitelial", "source": "test_ai"}

    state = {}
    monkeypatch.setattr(app, "download_whatsapp_media", fake_download)
    monkeypatch.setattr(app.vision_service, "extract_product_from_image", fake_extract)
    monkeypatch.setattr(app.ai_product_matcher, "match_extracted_text_to_product", fake_ai)
    monkeypatch.setattr(app.database, "get_image_cache", lambda *a, **k: None)
    monkeypatch.setattr(app.database, "set_state", lambda phone, payload: state.update(payload))

    reply = await app.process_image("218900000013", "media-evolsin")
    assert "هل هذا المنتج" not in reply
    assert "ACM" not in reply
    assert "غير موجود" in reply or "لم أجد" in reply
    assert state.get("pending_product_id") is None


def test_search_log_statistics(tmp_path):
    database.configure_db_path(str(tmp_path / "dashboard_stats.db"))
    database.init_db(run_production_guard=False)
    database.record_search_log(1, "Hemazym", "u1")
    database.record_search_log(1, "Hemazym", "u2")
    database.record_search_log(2, "Flagyl", "u3")
    rows = database.top_searched_products(days=7, limit=10)
    assert rows[0]["product_name"] == "Hemazym"
    assert int(rows[0]["hits"]) == 2
