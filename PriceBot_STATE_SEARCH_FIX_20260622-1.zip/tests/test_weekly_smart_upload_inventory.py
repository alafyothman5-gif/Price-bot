from __future__ import annotations

import database
import merchant
import orders


def _insert_product(conn, name: str, price: str = "10") -> int:
    cur = conn.execute(
        """
        INSERT INTO products(merchant_id, name, normalized_name, original_name, price, available, is_available, needs_review, quality_status, review_status, search_mode, currency)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (1, name, database.normalize_text(name), name, price, "1", 1, 0, "ok", "approved", "sellable", "LYD"),
    )
    return int(cur.lastrowid)


def test_weekly_upload_updates_price_marks_missing_and_inserts_clear_new(tmp_path, monkeypatch):
    database.configure_db_path(str(tmp_path / "weekly.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        flagyl = _insert_product(conn, "Flagyl 125mg", "10")
        missing = _insert_product(conn, "Hemazym", "20")

    monkeypatch.setattr(merchant, "_rebuild_runtime_indexes_safely", lambda: {"search_index": 0})
    result = merchant._smart_weekly_products_upload([
        ("Flagyl 125mg", "12"),
        ("New Mystery Product", "77"),
    ], "weekly.xlsx")

    assert result["updated_products"] == 1
    assert result["new_products"] == 1
    assert result["review_products"] == 0
    assert result["deactivated_products"] == 1

    flagyl_row = database.get_product(flagyl)
    missing_row = database.get_product(missing)
    assert flagyl_row["price"] == "12"
    assert database.truthy(flagyl_row["is_available"])
    assert not database.truthy(missing_row["is_available"])
    assert "غير متوفر" in orders.format_product_details(missing_row)

    reviews = database.list_review_queue(limit=10)
    assert len(reviews) == 0
    inserted = [p for p in database.load_product_rows() if p.get("name") == "New Mystery Product"][0]
    assert not database.truthy(inserted["needs_review"])
    assert database.truthy(inserted["is_available"])


def test_review_queue_approve_new_unblocks_product(tmp_path, monkeypatch):
    database.configure_db_path(str(tmp_path / "review.db"))
    database.init_db(run_production_guard=False)
    monkeypatch.setattr(merchant, "_rebuild_runtime_indexes_safely", lambda: {"search_index": 0})
    merchant._smart_weekly_products_upload([("cream", "30")], "weekly.xlsx")
    item = database.list_review_queue(limit=1)[0]
    database.resolve_review_queue_item(int(item["id"]), "approve_new")
    product = database.get_product(int(item["temp_product_id"]))
    assert not database.truthy(product["needs_review"])
    assert database.truthy(product["is_available"])
    assert "متوفر" in orders.format_product_details(product)


def test_very_close_upload_match_unit_spacing(tmp_path, monkeypatch):
    database.configure_db_path(str(tmp_path / "spacing.db"))
    database.init_db(run_production_guard=False)
    with database.connect() as conn:
        flagyl = _insert_product(conn, "Flagyl 125mg", "10")
    monkeypatch.setattr(merchant, "_rebuild_runtime_indexes_safely", lambda: {"search_index": 0})
    result = merchant._smart_weekly_products_upload([("Flagyl 125 mg", "15")], "weekly.xlsx")
    assert result["updated_products"] == 1
    assert result["new_products"] == 0
    assert database.get_product(flagyl)["price"] == "15"
