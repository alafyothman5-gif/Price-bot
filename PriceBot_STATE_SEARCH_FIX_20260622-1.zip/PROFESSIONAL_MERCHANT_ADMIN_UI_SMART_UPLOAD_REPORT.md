# PriceBot Professional Merchant/Admin UI + Smart Upload Report

## New unified routes

Merchant:
- `/merchant/login` — Arabic username/password login; no token in normal merchant URL.
- `/merchant/dashboard` — main merchant dashboard with inventory, upload, review and analytics cards.
- `/merchant/upload` — weekly smart Excel upload using the existing smart upload workflow. It does **not** delete products and does **not** replace `pricebot.db`.
- `/merchant/products` — product search and filters: available, unavailable, needs_review.
- `/merchant/review` — review queue and products needing review.
- `/merchant/analytics` — top searched products, image stats, low confidence and evidence rejected counters. Empty tables render safely.
- `/merchant/settings` — pharmacy name, hours, WhatsApp, delivery state, currency and welcome text.
- `/merchant/logout` — logout.

Admin:
- `/admin/login`
- `/admin/dashboard`
- `/admin/review`
- `/admin/uploads`
- `/admin/system`

Legacy redirects kept safe:
- `/merchant` -> `/merchant/dashboard`
- `/dashboard` -> merchant login/dashboard; valid legacy token can bootstrap a merchant session.
- `/merchant/catalog` -> `/merchant/upload`

## Safety guarantees

- No `DELETE FROM products` was added.
- Weekly upload updates prices, inserts new rows, and marks missing rows `is_available=0` only.
- `pricebot.db` is not included in the ZIP.
- `.env`, `venv`, `__pycache__`, backups and uploads are excluded.
- Image matching path was not changed: AI Gemini Product Matcher, Evidence Validator, `IMAGE_TEXT_FIRST`, `pending_product_id`, and no-direct-price-from-image remain intact.
- `product_aliases` is not deleted or modified by the UI changes.
- Dashboard routes render safe fallback HTML if a template or query fails, avoiding 502 caused by UI errors.

## Tests run in sandbox

```text
python -m compileall . -q
PYTHONPATH=. pytest -q tests/test_ai_image_gemini_product_matcher.py tests/test_dashboard_and_evidence_validator.py tests/test_weekly_smart_upload_inventory.py tests/test_catalog_ingestion_safe_exact.py tests/test_catalog_ingestion_v2_acceptance.py tests/test_production_safe_image_policy.py tests/test_self_learning_visual_overlay.py
```

Result:

```text
25 passed, 4 warnings
```

The warnings are existing FastAPI `on_event` deprecation warnings and are unrelated to this UI work.

## Deployment note

Deploy code-only to `/opt/pricebot_clean`. Keep the existing `/opt/pricebot_clean/pricebot.db`, `.env`, and `uploads/` on the server. Do not replace the database.
