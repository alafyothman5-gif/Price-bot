#!/usr/bin/env python3
"""Standalone safe importer for product_aliases.

This script intentionally does NOT call database.init_db().  It connects
straight to SQLite, reads the existing schema dynamically, reads products only,
and fills whatever alias columns exist in product_aliases.

Expected CSV columns:
  original_name, alias_text
or:
  original_name, aliases_text

Production usage can manage the service lock:
  sudo ./venv/bin/python tools/import_product_aliases_safe.py \
    --csv data/aliases/product_aliases_from_pricelist.csv \
    --db-path /opt/pricebot_clean/pricebot.db \
    --unmatched /opt/pricebot_clean/unmatched.csv
"""
from __future__ import annotations

import argparse
import csv
import gzip
import os
import re
import sqlite3
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Dict, Iterable, List, Tuple


def clean_text(value: object) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"[\u064B-\u065F\u0670]", "", text)
    text = text.replace("ـ", "")
    text = text.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789"))
    text = re.sub(r"[^0-9a-z\u0600-\u06FF%/+.-]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def split_aliases(value: str) -> List[str]:
    raw = str(value or "")
    parts = re.split(r"[|;\n]+", raw)
    out: List[str] = []
    seen = set()
    for part in parts:
        alias = part.strip()
        key = clean_text(alias)
        if alias and key and key not in seen:
            seen.add(key)
            out.append(alias)
    return out


def open_text(path: Path):
    if str(path).lower().endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8-sig", newline="")
    return path.open("r", encoding="utf-8-sig", newline="")


def read_csv_rows(path: Path) -> Iterable[Dict[str, str]]:
    with open_text(path) as fh:
        sample = fh.read(8192)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample)
        except Exception:
            dialect = csv.excel
        reader = csv.DictReader(fh, dialect=dialect)
        headers = {str(h or "").strip() for h in (reader.fieldnames or [])}
        if "original_name" not in headers or not ({"alias_text", "aliases_text"} & headers):
            raise SystemExit("CSV must contain original_name and alias_text or aliases_text")
        for row in reader:
            yield {str(k or "").strip(): str(v or "").strip() for k, v in row.items()}


def table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    return [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]


def ensure_alias_table(conn: sqlite3.Connection) -> List[str]:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS product_aliases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_db_id INTEGER,
            product_id INTEGER,
            alias TEXT DEFAULT '',
            normalized_alias TEXT DEFAULT '',
            alias_text TEXT DEFAULT '',
            cleaned_alias TEXT DEFAULT '',
            confidence REAL DEFAULT 0.95,
            source TEXT DEFAULT 'ai_generated',
            approved INTEGER DEFAULT 1,
            active INTEGER DEFAULT 1,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cols = set(table_columns(conn, "product_aliases"))
    for col, ddl in {
        "product_db_id": "INTEGER",
        "product_id": "INTEGER",
        "alias": "TEXT DEFAULT ''",
        "normalized_alias": "TEXT DEFAULT ''",
        "alias_text": "TEXT DEFAULT ''",
        "cleaned_alias": "TEXT DEFAULT ''",
        "confidence": "REAL DEFAULT 0.95",
        "source": "TEXT DEFAULT 'ai_generated'",
        "approved": "INTEGER DEFAULT 1",
        "active": "INTEGER DEFAULT 1",
        "is_active": "INTEGER DEFAULT 1",
        "created_at": "TEXT",
        "updated_at": "TEXT",
    }.items():
        if col not in cols:
            conn.execute(f"ALTER TABLE product_aliases ADD COLUMN {col} {ddl}")
    return table_columns(conn, "product_aliases")


def load_product_map(conn: sqlite3.Connection) -> Dict[str, List[Tuple[int, str]]]:
    out: Dict[str, List[Tuple[int, str]]] = {}
    for pid, name, price in conn.execute("SELECT id, name, price FROM products"):
        key = clean_text(name)
        if key:
            out.setdefault(key, []).append((int(pid), str(price or "")))
    return out


def choose_product(ids_prices: List[Tuple[int, str]]) -> Tuple[int | None, str]:
    if not ids_prices:
        return None, "no_exact_products_name_match"
    if len(ids_prices) == 1:
        return ids_prices[0][0], "exact"
    prices = {str(p or "").strip() for _, p in ids_prices}
    if len(prices) == 1:
        return min(pid for pid, _ in ids_prices), "duplicate_same_price_canonical_min_id"
    return None, f"ambiguous_same_name_different_prices:{ids_prices[:10]}"


def alias_exists(conn: sqlite3.Connection, cols: List[str], product_id: int, cleaned_alias: str) -> bool:
    product_col = "product_db_id" if "product_db_id" in cols else "product_id"
    alias_col = "normalized_alias" if "normalized_alias" in cols else ("cleaned_alias" if "cleaned_alias" in cols else "alias")
    row = conn.execute(f"SELECT id FROM product_aliases WHERE {product_col}=? AND {alias_col}=? LIMIT 1", (int(product_id), cleaned_alias)).fetchone()
    return bool(row)


def insert_alias(conn: sqlite3.Connection, cols: List[str], product_id: int, alias: str, source: str = "ai_generated") -> bool:
    cleaned = clean_text(alias)
    if not cleaned or alias_exists(conn, cols, product_id, cleaned):
        return False
    values = {
        "product_db_id": product_id,
        "product_id": product_id,
        "alias": alias,
        "normalized_alias": cleaned,
        "alias_text": alias,
        "cleaned_alias": cleaned,
        "alias_normalized": cleaned,
        "confidence": 0.95,
        "source": source,
        "approved": 1,
        "active": 1,
        "is_active": 1,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    insert_cols = [c for c in cols if c in values]
    placeholders = ",".join(["?"] * len(insert_cols))
    conn.execute(
        f"INSERT INTO product_aliases({','.join(insert_cols)}) VALUES({placeholders})",
        [values[c] for c in insert_cols],
    )
    return True


def systemctl(action: str, service: str) -> None:
    try:
        subprocess.run(["sudo", "systemctl", action, service], check=False, timeout=30)
    except Exception as exc:
        print(f"SERVICE_{action.upper()}_WARNING={exc!r}", flush=True)


def fuser_check(db_path: Path) -> None:
    try:
        p = subprocess.run(["fuser", str(db_path)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10)
        out = (p.stdout or "").strip()
        print(f"FUSER_OUTPUT={out or 'none'}", flush=True)
    except Exception as exc:
        print(f"FUSER_WARNING={exc!r}", flush=True)


def wait_health(url: str, seconds: int = 60) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as resp:
                if resp.status == 200:
                    print("HEALTH_OK=1", flush=True)
                    return True
        except Exception:
            time.sleep(2)
    print("HEALTH_OK=0", flush=True)
    return False


def import_aliases(csv_path: Path, db_path: Path, unmatched_path: Path, dry_run: bool = False) -> Dict[str, int]:
    stats = {"rows": 0, "inserted": 0, "existing": 0, "skipped": 0, "unmatched": 0, "ambiguous": 0}
    unmatched_rows: List[Dict[str, str]] = []
    conn = sqlite3.connect(str(db_path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=5000")
    try:
        cols = ensure_alias_table(conn)
        before = conn.execute("SELECT COUNT(*) FROM product_aliases").fetchone()[0]
        product_map = load_product_map(conn)
        for row in read_csv_rows(csv_path):
            stats["rows"] += 1
            original = row.get("original_name", "")
            aliases_value = row.get("alias_text") or row.get("aliases_text") or ""
            aliases = split_aliases(aliases_value)
            if not original or not aliases:
                stats["skipped"] += 1
                unmatched_rows.append({"original_name": original, "alias_text": aliases_value, "reason": "missing_original_or_alias"})
                continue
            pid, reason = choose_product(product_map.get(clean_text(original), []))
            if not pid:
                if reason.startswith("ambiguous"):
                    stats["ambiguous"] += 1
                else:
                    stats["unmatched"] += 1
                unmatched_rows.append({"original_name": original, "alias_text": aliases_value, "reason": reason})
                continue
            for alias in aliases:
                if dry_run:
                    stats["inserted"] += 1
                else:
                    if insert_alias(conn, cols, pid, alias):
                        stats["inserted"] += 1
                    else:
                        stats["existing"] += 1
            if stats["rows"] % 1000 == 0:
                print(f"INSERTED_SO_FAR={stats['inserted']} SKIPPED={stats['skipped']} UNMATCHED={stats['unmatched']} AMBIGUOUS={stats['ambiguous']}", flush=True)
                if not dry_run:
                    conn.commit()
        if not dry_run:
            conn.commit()
        after = conn.execute("SELECT COUNT(*) FROM product_aliases").fetchone()[0]
        stats["aliases_before"] = int(before)
        stats["aliases_after"] = int(after)
    finally:
        conn.close()
    unmatched_path.parent.mkdir(parents=True, exist_ok=True)
    with unmatched_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["original_name", "alias_text", "reason"])
        writer.writeheader()
        writer.writerows(unmatched_rows)
    print(
        "IMPORT_SUMMARY "
        f"aliases_before={stats.get('aliases_before',0)} aliases_after={stats.get('aliases_after',0)} "
        f"actually_added={stats['inserted']} unmatched={stats['unmatched']} ambiguous={stats['ambiguous']} skipped={stats['skipped']}",
        flush=True,
    )
    return stats


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Safe standalone product_aliases importer")
    parser.add_argument("--csv", required=True)
    parser.add_argument("--db-path", default=os.getenv("PRICEBOT_DB_PATH", "/opt/pricebot_clean/pricebot.db"))
    parser.add_argument("--unmatched", default="/opt/pricebot_clean/unmatched.csv")
    parser.add_argument("--service", default="pricebot.service")
    parser.add_argument("--health-url", default="http://127.0.0.1:8090/health")
    parser.add_argument("--no-manage-service", action="store_true", help="Do not stop/start systemd service")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    db_path = Path(args.db_path)
    manage = not args.no_manage_service
    if manage:
        systemctl("stop", args.service)
        time.sleep(3)
        fuser_check(db_path)
    try:
        import_aliases(Path(args.csv), db_path, Path(args.unmatched), dry_run=bool(args.dry_run))
    finally:
        if manage:
            systemctl("start", args.service)
            wait_health(args.health_url, seconds=60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
