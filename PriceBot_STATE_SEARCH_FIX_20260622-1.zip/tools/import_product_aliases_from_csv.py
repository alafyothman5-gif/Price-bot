#!/usr/bin/env python3
"""Compatibility wrapper for the safe standalone alias importer.

Use tools/import_product_aliases_safe.py directly for production.  This wrapper
is kept so older deployment notes do not call the previous init_db-based import
path that could lock production during large imports.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tools.import_product_aliases_safe import main

if __name__ == "__main__":
    raise SystemExit(main())
