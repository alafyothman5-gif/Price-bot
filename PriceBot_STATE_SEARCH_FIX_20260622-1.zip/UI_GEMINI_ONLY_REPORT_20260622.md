# PriceBot UI + Gemini-only Patch - 2026-06-22

## Customer WhatsApp UI
- Replaced the entry list menu with a simpler 3-button menu:
  - بحث بالاسم
  - بحث بالصورة
  - الأقسام
- Simplified Arabic welcome, search, image, help, and pharmacy-info messages.
- Kept product browsing, clarification, product details, and image confirmation flows intact.

## Gemini-only AI policy
- Enforced Gemini-only model selection for all OpenRouter AI calls.
- If any `.env` value sets a non-Gemini model, the code safely falls back to `google/gemini-2.5-flash-lite`.
- The same Gemini policy applies to:
  - text/product matching AI used after image OCR,
  - image/Vision extraction,
  - catalog enrichment during Excel import.

## Safety
- No database schema change.
- No change to WhatsApp webhook verification.
- No change to price/inventory update logic.
- No change to image confirmation requirement before displaying price.
