# PriceBot Final Production Hardening - 2026-06-22

This package is built on `PriceBot_GEMINI_SAFE_ECONOMY_MODE_20260622` and adds the remaining production controls without changing the core WhatsApp conversation logic or Gemini-first accuracy policy.

## Added

1. Stable product codes
   - Adds `products.stable_product_code`.
   - Backfills existing products with deterministic codes such as `PB-000001`.
   - New products inserted by weekly upload receive a stable code when the column exists.

2. Memory review dashboard
   - `/admin/memory`
   - Shows confirmed safe text memory and exact-image memory.
   - Allows disabling wrong text/image memory bindings.

3. Metrics dashboard
   - `/admin/metrics`
   - Shows product counts, active memory, exact-image memory, learning/review pending, and estimated Gemini savings.

4. Excel dry run
   - Merchant upload page now includes “معاينة فقط بدون تعديل”.
   - Calculates expected updates/new products/review/deactivation impact without writing to the database.

5. Backup and rollback dashboard
   - `/admin/backups`
   - Create manual DB backup.
   - Restore selected backup with explicit `RESTORE` confirmation.

6. Security status page
   - `/admin/security`
   - Read-only status for admin password, merchant password, Meta signature settings, and DB path.

7. Safe image rate guard
   - Separate image rate limit from text rate limit.
   - Does not change product recognition accuracy; it only throttles excessive image spam.

## Accuracy policy retained

- Gemini remains active for new/ambiguous image and text cases.
- No fuzzy image similarity is used for automatic recognition.
- Exact image cache is used only for identical images and still asks for confirmation before showing price.
- Safe text memory is used only for confirmed, specific text phrases and still asks for confirmation.

## Files touched

- `app.py`
- `database.py`
- `merchant.py`
- `admin.py`
- `templates/merchant_upload.html`
- `templates/merchant_upload_dry_run.html`
- `templates/admin_memory.html`
- `templates/admin_metrics.html`
- `templates/admin_backups.html`
- `templates/admin_security.html`
