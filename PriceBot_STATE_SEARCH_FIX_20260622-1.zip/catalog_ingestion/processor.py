from __future__ import annotations

"""Safe exact-match Catalog Ingestion processor.

Rules enforced here:
- Uploads are staged first; production prices are untouched until approval.
- No fuzzy matching is used for price updates.
- Only Merchant Alias exact matches or Master Exact matches can update price.
- Unknown/ambiguous rows go to admin review.
- Last duplicate row wins inside the same upload.
"""

import csv
import json
import os
import re
import sqlite3
import threading
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import openpyxl

import database
from .db import audit_conn, ensure_schema
from .normalizer import normalize_arabic_name
from .pricing import parse_price, same_price

SAFE_DECISIONS = {"KNOWN_MERCHANT_ALIAS", "MASTER_EXACT_MATCH", "SAFE_IDENTITY_MATCH", "PRICE_UNCHANGED"}
REVIEW_DECISIONS = {"AMBIGUOUS_REVIEW", "NEW_PRODUCT_REVIEW"}
INVALID_DECISION = "INVALID_ROW"
DUPLICATE_DECISION = "DUPLICATE_LAST_ROW_USED"
UNSAFE_DECISION = "UNSAFE_REJECTED"

UNSAFE_SINGLE_TOKENS = {
    "غسول", "كريم", "شراب", "حبوب", "قطرة", "بخاخ", "محلول",
    "cream", "gel", "lotion", "syrup", "tablets", "tablet", "drops",
    "serum", "tonic", "wash", "cleanser", "shampoo", "spray",
    "solution", "suspension", "capsules", "capsule",
}
FORM_TOKENS = {
    "cream", "gel", "lotion", "syrup", "tablets", "tablet", "drops", "serum", "tonic",
    "wash", "cleanser", "shampoo", "spray", "solution", "suspension", "capsules", "capsule",
    "ointment", "ampoule", "injection", "suppository", "sachet", "sachets",
}
FORM_EQUIV = {
    "syrup": {"syrup", "suspension"},
    "suspension": {"syrup", "suspension"},
    "tablet": {"tablet", "tablets"},
    "tablets": {"tablet", "tablets"},
    "capsule": {"capsule", "capsules"},
    "capsules": {"capsule", "capsules"},
    "cleanser": {"cleanser", "wash"},
    "wash": {"cleanser", "wash"},
}
IDENTITY_STOP_TOKENS = FORM_TOKENS | {
    "plus", "extra", "advance", "advanced", "forte", "kids", "baby", "adult",
    "mg", "mcg", "ml", "g", "iu", "percent", "pct", "%",
}


def _dict(row: Any) -> Dict[str, Any]:
    return database.dict_row(row) or {}


def _json(data: Any) -> str:
    return json.dumps(data or {}, ensure_ascii=False, default=str)


def _old_ui_status(status: str) -> str:
    return {
        "UPLOADED": "queued",
        "PROCESSING": "staging_processing",
        "PENDING_PREVIEW": "ready_for_approval",
        "APPROVED": "approved",
        "PARTIALLY_APPROVED": "approved_partial",
        "FAILED": "failed",
        "ROLLED_BACK": "failed",
        "REJECTED": "cancelled",
    }.get(status, str(status or "").lower())


def _mirror_old_job(job_id: int, status: str, summary: Dict[str, Any] | None = None, error: str = "") -> None:
    summary = summary or {}
    text = _json({"catalog_ingestion": status, "summary": summary, "error": error})
    try:
        database.update_catalog_import_job(
            int(job_id),
            status=_old_ui_status(status),
            updated=int(summary.get("safe_updates_count") or 0),
            added=int(summary.get("new_count") or 0),
            duplicate_conflicts=int(summary.get("duplicate_count") or 0),
            needs_review=int(summary.get("review_count") or 0),
            report_text=text[-8000:],
            error_text=error,
            verified=1 if status in {"PENDING_PREVIEW", "APPROVED", "PARTIALLY_APPROVED"} else 0,
            acceptance_passed=1 if status in {"PENDING_PREVIEW", "APPROVED", "PARTIALLY_APPROVED"} else 0,
        )
    except Exception:
        pass


def _set_job_status(job_id: int, status: str, *, summary: Dict[str, Any] | None = None, error: str = "") -> None:
    ensure_schema()
    summary = summary or {}
    report = _json({"status": status, "summary": summary, "error": error})
    with database.connect() as conn:
        fields = ["status=?", "updated_at=datetime('now')", "report_json=?"]
        params: List[Any] = [status, report]
        if status == "PROCESSING":
            fields.append("started_at=datetime('now')")
        if status in {"PENDING_PREVIEW", "FAILED", "APPROVED", "PARTIALLY_APPROVED", "ROLLED_BACK", "REJECTED"}:
            fields.append("finished_at=datetime('now')")
        if error:
            fields.append("error_text=?")
            params.append(error)
        for k in ["rows_total", "safe_updates_count", "unchanged_count", "review_count", "new_count", "invalid_count", "duplicate_count"]:
            if k in summary:
                fields.append(f"{k}=?")
                params.append(int(summary.get(k) or 0))
        params.append(int(job_id))
        conn.execute(f"UPDATE catalog_upload_jobs SET {', '.join(fields)} WHERE id=?", params)
    _mirror_old_job(job_id, status, summary, error)


def create_upload_job(job_id: int, merchant_id: int, filename: str, file_path: str) -> None:
    ensure_schema()
    with database.connect() as conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO catalog_upload_jobs(
                id, merchant_id, filename, file_path, status, created_at, updated_at
            ) VALUES(?,?,?,?, 'UPLOADED', datetime('now'), datetime('now'))
            """,
            (int(job_id), int(merchant_id or 1), filename or Path(file_path).name, str(file_path)),
        )
    _mirror_old_job(job_id, "UPLOADED", {})


def _read_excel_rows(excel_path: str) -> List[Dict[str, Any]]:
    path = Path(excel_path)
    suffix = path.suffix.lower()
    rows: List[Dict[str, Any]] = []
    if suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            data = list(reader)
        start = 1 if data and any(str(x).strip().lower() in {"name", "product", "price", "اسم", "السعر"} for x in data[0][:2]) else 0
        for idx, row in enumerate(data[start:], start=start + 1):
            if not row or len(row) < 2:
                continue
            rows.append({"row_number": idx, "raw_name": str(row[0] or "").strip(), "raw_price": str(row[1] or "").strip()})
        return [r for r in rows if r["raw_name"]]

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    ws = wb.active
    values = list(ws.iter_rows(values_only=True))
    if not values:
        return []
    first = [str(x or "").strip().lower() for x in values[0][:2]]
    start_index = 1 if first and ("name" in first[0] or "price" in " ".join(first) or "اسم" in first[0]) else 0
    for zero_idx, row in enumerate(values[start_index:], start=start_index):
        raw_name = str((row[0] if len(row) > 0 else "") or "").strip()
        raw_price = row[1] if len(row) > 1 else ""
        if not raw_name:
            continue
        rows.append({"row_number": zero_idx + 1, "raw_name": raw_name, "raw_price": raw_price})
    return rows


def _load_merchant_aliases(conn: Any, merchant_id: int) -> Dict[str, int]:
    out: Dict[str, int] = {}
    if not database.table_exists(conn, "merchant_product_aliases"):
        return out
    for r in conn.execute(
        "SELECT normalized_raw_name, product_id FROM merchant_product_aliases WHERE merchant_id=? AND is_active=1",
        (int(merchant_id),),
    ).fetchall():
        key = str(r[0] or "")
        if key:
            out[key] = int(r[1])
    return out


def _product_price(conn: Any, product_id: int) -> str:
    row = conn.execute("SELECT price FROM products WHERE id=?", (int(product_id),)).fetchone()
    return str(row[0] if row else "")


def _load_master_exact_index(conn: Any) -> tuple[Dict[str, set[int]], Dict[str, set[int]], Dict[int, Dict[str, Any]]]:
    exact: Dict[str, set[int]] = defaultdict(set)
    token_index: Dict[str, set[int]] = defaultdict(set)
    product_rows: Dict[int, Dict[str, Any]] = {}
    if database.table_exists(conn, "products"):
        cols = {r[1] for r in conn.execute('PRAGMA table_info("products")').fetchall()}
        wanted = [
            "id", "name", "normalized_name", "aliases", "original_name", "brand", "product_family",
            "form", "medicine_form", "product_type", "strength", "size", "pack", "active_ingredient",
        ]
        selected = [c for c in wanted if c in cols]
        rows = conn.execute(f"SELECT {', '.join(selected)} FROM products").fetchall() if selected else []
        for row in rows:
            data = _dict(row)
            product_id = int(data.get("id") or 0)
            if not product_id:
                continue
            product_rows[product_id] = data
            candidates = [data.get("name"), data.get("normalized_name"), data.get("aliases"), data.get("original_name")]
            for value in candidates:
                if not value:
                    continue
                pieces = [str(value)]
                if "|" in str(value):
                    pieces.extend(str(value).split("|"))
                for piece in pieces:
                    norm = normalize_arabic_name(piece)
                    if norm:
                        exact[norm].add(product_id)
                        for tok in norm.split():
                            if len(tok) >= 3 and not tok.isdigit():
                                token_index[tok].add(product_id)
    if database.table_exists(conn, "product_aliases"):
        cols = {r[1] for r in conn.execute('PRAGMA table_info("product_aliases")').fetchall()}
        pid_expr = "COALESCE(product_id, product_db_id)" if {"product_id", "product_db_id"}.issubset(cols) else ("product_id" if "product_id" in cols else "product_db_id")
        alias_cols = []
        if "alias_normalized" in cols:
            alias_cols.append("alias_normalized")
        if "normalized_alias" in cols:
            alias_cols.append("normalized_alias")
        if "alias" in cols:
            alias_cols.append("alias")
        if alias_cols:
            where = "WHERE COALESCE(is_active, approved, 1)=1" if "is_active" in cols else "WHERE COALESCE(approved,1)=1"
            for r in conn.execute(f"SELECT {pid_expr} AS pid, {', '.join(alias_cols)} FROM product_aliases {where}").fetchall():
                product_id = int(r[0] or 0)
                if not product_id:
                    continue
                for value in list(r)[1:]:
                    norm = normalize_arabic_name(value)
                    if norm:
                        exact[norm].add(product_id)
                        for tok in norm.split():
                            if len(tok) >= 3 and not tok.isdigit():
                                token_index[tok].add(product_id)
    return exact, token_index, product_rows


def _measure_tokens(value: str) -> set[str]:
    out: set[str] = set()
    for tok in normalize_arabic_name(value).split():
        if re.fullmatch(r"\d+(?:\.\d+)?", tok):
            out.add(tok)
        elif re.fullmatch(r"\d+(?:\.\d+)?(?:ml|mcg|g|iu|%)", tok):
            out.add(tok)
    return out


def _product_identity(product: Dict[str, Any]) -> Dict[str, Any]:
    text = " ".join(str(product.get(k) or "") for k in [
        "name", "normalized_name", "aliases", "original_name", "brand", "product_family",
        "form", "medicine_form", "product_type", "strength", "size", "pack", "active_ingredient",
    ])
    norm_text = normalize_arabic_name(text)
    tokens = [t for t in norm_text.split() if t]
    brand = normalize_arabic_name(product.get("brand") or "").split()
    brand_token = brand[0] if brand else (tokens[0] if tokens else "")
    forms = {t for t in tokens if t in FORM_TOKENS}
    measures = _measure_tokens(" ".join(str(product.get(k) or "") for k in ["strength", "size", "pack", "name", "original_name"]))
    family_tokens = [t for t in tokens if t != brand_token and t not in IDENTITY_STOP_TOKENS and not t.isdigit() and not _measure_tokens(t)]
    return {"brand": brand_token, "forms": forms, "measures": measures, "family_tokens": set(family_tokens), "tokens": set(tokens), "text": norm_text}


def _query_identity(normalized_name: str, product_rows: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    tokens = [t for t in normalized_name.split() if t]
    product_brands: set[str] = set()
    for p in product_rows.values():
        ident = _product_identity(p)
        if ident["brand"]:
            product_brands.add(ident["brand"])
    brand = next((t for t in tokens if t in product_brands), "")
    forms = {t for t in tokens if t in FORM_TOKENS}
    measures = _measure_tokens(normalized_name)
    family_tokens = [t for t in tokens if t != brand and t not in IDENTITY_STOP_TOKENS and not t.isdigit() and t not in measures]
    return {"brand": brand, "forms": forms, "measures": measures, "family_tokens": set(family_tokens), "tokens": set(tokens)}


def _forms_overlap(query_forms: set[str], product_forms: set[str]) -> bool:
    if not query_forms:
        return True
    if not product_forms:
        return False
    expanded_q: set[str] = set()
    expanded_p: set[str] = set()
    for f in query_forms:
        expanded_q.update(FORM_EQUIV.get(f, {f}))
    for f in product_forms:
        expanded_p.update(FORM_EQUIV.get(f, {f}))
    return bool(expanded_q & expanded_p)


def _safe_identity_match(normalized_name: str, token_index: Dict[str, set[int]], product_rows: Dict[int, Dict[str, Any]]) -> tuple[str, Optional[int], str] | None:
    q = _query_identity(normalized_name, product_rows)
    brand = q["brand"]
    if not brand:
        return None
    has_family = bool(q["family_tokens"])
    has_form = bool(q["forms"])
    has_measure = bool(q["measures"])
    if not ((brand and has_family) or (brand and has_form and has_measure)):
        return None

    # Use token_index as the candidate scope, then enforce exact slot filters.
    candidate_ids: set[int] = set()
    for tok in q["tokens"]:
        candidate_ids.update(token_index.get(tok, set()))
    if not candidate_ids:
        candidate_ids = set(product_rows)

    matches: list[int] = []
    for pid in sorted(candidate_ids):
        product = product_rows.get(pid)
        if not product:
            continue
        ident = _product_identity(product)
        if ident["brand"] != brand and brand not in ident["tokens"]:
            continue
        if q["family_tokens"] and not q["family_tokens"].issubset(ident["family_tokens"] | ident["tokens"]):
            continue
        if q["forms"] and not _forms_overlap(q["forms"], ident["forms"]):
            continue
        if q["measures"] and not q["measures"].issubset(ident["measures"] | ident["tokens"]):
            continue
        matches.append(pid)

    if len(matches) == 1:
        return "SAFE_IDENTITY_MATCH", matches[0], "brand/identity slots matched one product"
    if len(matches) > 1:
        return "AMBIGUOUS_REVIEW", None, f"safe identity slots match multiple products: {matches[:10]}"
    return None

def _match_row(normalized_name: str, merchant_aliases: Dict[str, int], master_exact: Dict[str, set[int]], token_index: Dict[str, set[int]], product_rows: Dict[int, Dict[str, Any]] | None = None) -> tuple[str, Optional[int], str]:
    product_rows = product_rows or {}
    tokens_all = normalized_name.split()
    if len(tokens_all) == 1 and tokens_all[0] in UNSAFE_SINGLE_TOKENS:
        return UNSAFE_DECISION, None, "generic form/type word — too ambiguous to match"

    if normalized_name in merchant_aliases:
        return "KNOWN_MERCHANT_ALIAS", merchant_aliases[normalized_name], "exact merchant alias memory"
    ids = master_exact.get(normalized_name, set())
    if len(ids) == 1:
        return "MASTER_EXACT_MATCH", next(iter(ids)), "exact master alias/product name"
    if len(ids) > 1:
        return "AMBIGUOUS_REVIEW", None, f"exact name maps to multiple products: {sorted(ids)[:10]}"

    safe = _safe_identity_match(normalized_name, token_index, product_rows)
    if safe is not None:
        return safe

    # Still no price update. This only classifies non-exact but recognizable
    # names as review candidates so the admin sees useful evidence.
    tokens = [t for t in normalized_name.split() if len(t) >= 3 and not t.isdigit()]
    token_hits: set[int] = set()
    for tok in tokens:
        token_hits.update(token_index.get(tok, set()))
    if len(token_hits) >= 1:
        return "AMBIGUOUS_REVIEW", None, f"name not exact; appears in {len(token_hits)} product(s)"
    return "NEW_PRODUCT_REVIEW", None, "no trusted exact alias/name match"

def _insert_staging(conn: Any, *, job_id: int, merchant_id: int, row_number: int, raw_name: str, normalized_name: str,
                    raw_price: Any, parsed_price: str = "", matched_product_id: int | None = None, decision: str,
                    reason: str, old_price: str = "", new_price: str = "", is_safe: bool = False,
                    duplicate_winner_row: int | None = None) -> int:
    cur = conn.execute(
        """
        INSERT INTO catalog_staging_items(
            job_id, merchant_id, row_number, raw_name, normalized_name, raw_price, parsed_price,
            matched_product_id, decision, reason, old_price, new_price, is_safe_to_apply, duplicate_winner_row,
            created_at, updated_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'))
        """,
        (int(job_id), int(merchant_id), int(row_number), raw_name, normalized_name, str(raw_price or ""), parsed_price,
         matched_product_id, decision, reason, old_price, new_price, 1 if is_safe else 0, duplicate_winner_row),
    )
    return int(cur.lastrowid)


def _insert_review(conn: Any, *, job_id: int, merchant_id: int, staging_item_id: int, raw_name: str,
                   normalized_name: str, price: str, issue_type: str, reason: str) -> None:
    row_json = _json({"raw_name": raw_name, "normalized_name": normalized_name, "price": price, "reason": reason})
    conn.execute(
        """
        INSERT INTO catalog_review_items(
            merchant_id, job_id, staging_item_id, raw_name, normalized_name, price, issue_type, status,
            notes, severity, row_json, price_new, review_notes, created_at, updated_at
        ) VALUES(?,?,?,?,?,?,?, 'PENDING', ?, 'review', ?, ?, ?, datetime('now'), datetime('now'))
        """,
        (int(merchant_id), int(job_id), int(staging_item_id), raw_name, normalized_name, price, issue_type,
         reason, row_json, price, reason),
    )


def create_and_verify_staging_job(job_id: int, excel_path: str, merchant_id: int = 1) -> Dict[str, Any]:
    """Read Excel, stage rows, classify safe/review items, and produce preview."""
    ensure_schema()
    merchant_id = int(merchant_id or 1)
    try:
        job = database.get_catalog_import_job(int(job_id)) or {}
        create_upload_job(int(job_id), merchant_id, job.get("filename") or Path(excel_path).name, excel_path)
        _set_job_status(job_id, "PROCESSING")
        rows = _read_excel_rows(excel_path)
        normalized_rows: List[Dict[str, Any]] = []
        for r in rows:
            normalized_rows.append({**r, "normalized_name": normalize_arabic_name(r["raw_name"])})
        last_by_name: Dict[str, int] = {}
        for i, r in enumerate(normalized_rows):
            if r["normalized_name"]:
                last_by_name[r["normalized_name"]] = i

        summary = Counter()
        summary["rows_total"] = len(normalized_rows)
        examples: List[Dict[str, Any]] = []

        with database.connect() as conn:
            conn.execute("DELETE FROM catalog_staging_items WHERE job_id=?", (int(job_id),))
            conn.execute("DELETE FROM catalog_review_items WHERE job_id=? AND status IN ('PENDING','pending')", (int(job_id),))
            merchant_aliases = _load_merchant_aliases(conn, merchant_id)
            master_exact, token_index, product_rows = _load_master_exact_index(conn)

            for idx, row in enumerate(normalized_rows):
                raw_name = row["raw_name"]
                normalized = row["normalized_name"]
                raw_price = row["raw_price"]
                if not normalized:
                    sid = _insert_staging(conn, job_id=job_id, merchant_id=merchant_id, row_number=row["row_number"], raw_name=raw_name,
                                          normalized_name=normalized, raw_price=raw_price, decision=INVALID_DECISION,
                                          reason="empty name after normalization")
                    summary["invalid_count"] += 1
                else:
                    try:
                        parsed_price = parse_price(raw_price)
                    except Exception as exc:
                        sid = _insert_staging(conn, job_id=job_id, merchant_id=merchant_id, row_number=row["row_number"], raw_name=raw_name,
                                              normalized_name=normalized, raw_price=raw_price, decision=INVALID_DECISION,
                                              reason=str(exc))
                        summary["invalid_count"] += 1
                        if len(examples) < 60:
                            examples.append({"row_number": row["row_number"], "raw_name": raw_name, "raw_price": str(raw_price), "decision": INVALID_DECISION, "reason": str(exc)})
                        continue

                    winner_idx = last_by_name.get(normalized)
                    if winner_idx is not None and winner_idx != idx:
                        winner_row = normalized_rows[winner_idx]["row_number"]
                        sid = _insert_staging(conn, job_id=job_id, merchant_id=merchant_id, row_number=row["row_number"], raw_name=raw_name,
                                              normalized_name=normalized, raw_price=raw_price, parsed_price=parsed_price,
                                              decision=DUPLICATE_DECISION, reason=f"duplicate normalized name; row {winner_row} wins",
                                              duplicate_winner_row=winner_row)
                        summary["duplicate_count"] += 1
                        if len(examples) < 60:
                            examples.append({"row_number": row["row_number"], "raw_name": raw_name, "raw_price": str(raw_price), "decision": DUPLICATE_DECISION, "reason": f"row {winner_row} wins"})
                        continue

                    decision, product_id, reason = _match_row(normalized, merchant_aliases, master_exact, token_index, product_rows)
                    is_safe = decision in {"KNOWN_MERCHANT_ALIAS", "MASTER_EXACT_MATCH", "SAFE_IDENTITY_MATCH"} and product_id is not None
                    old_price = _product_price(conn, product_id) if product_id else ""
                    if is_safe:
                        if same_price(old_price, parsed_price):
                            summary["unchanged_count"] += 1
                            reason += "; price unchanged"
                        else:
                            summary["safe_updates_count"] += 1
                    elif decision == "AMBIGUOUS_REVIEW":
                        summary["review_count"] += 1
                    elif decision == "NEW_PRODUCT_REVIEW":
                        summary["new_count"] += 1
                        summary["review_count"] += 1

                    sid = _insert_staging(conn, job_id=job_id, merchant_id=merchant_id, row_number=row["row_number"], raw_name=raw_name,
                                          normalized_name=normalized, raw_price=raw_price, parsed_price=parsed_price,
                                          matched_product_id=product_id, decision=decision, reason=reason,
                                          old_price=old_price, new_price=parsed_price, is_safe=is_safe)
                    if decision in REVIEW_DECISIONS:
                        _insert_review(conn, job_id=job_id, merchant_id=merchant_id, staging_item_id=sid, raw_name=raw_name,
                                       normalized_name=normalized, price=parsed_price,
                                       issue_type="AMBIGUOUS" if decision == "AMBIGUOUS_REVIEW" else "NEW_PRODUCT",
                                       reason=reason)
                    if len(examples) < 60:
                        examples.append({"row_number": row["row_number"], "raw_name": raw_name, "raw_price": str(raw_price),
                                         "parsed_price": parsed_price, "matched_product_id": product_id, "decision": decision, "reason": reason})

        summary_dict = {k: int(summary.get(k) or 0) for k in ["rows_total", "safe_updates_count", "unchanged_count", "review_count", "new_count", "invalid_count", "duplicate_count"]}
        report = {"summary": summary_dict, "examples": examples, "rules": {"matching": "exact aliases only; no fuzzy", "production_write": "approval only"}}
        _set_job_status(job_id, "PENDING_PREVIEW", summary=summary_dict)
        with database.connect() as conn:
            conn.execute("UPDATE catalog_upload_jobs SET report_json=? WHERE id=?", (_json(report), int(job_id)))
        return report
    except Exception as exc:
        _set_job_status(job_id, "FAILED", error=f"{type(exc).__name__}: {exc}")
        raise


def start_background_processing(job_id: int, excel_path: str, merchant_id: int = 1) -> None:
    thread = threading.Thread(target=create_and_verify_staging_job, args=(int(job_id), str(excel_path), int(merchant_id or 1)), daemon=True)
    thread.start()


def approve_staging_job(job_id: int, actor: str = "merchant", **_: Any) -> Dict[str, Any]:
    """Apply safe staging rows only, after backup and explicit approval."""
    ensure_schema()
    job_id = int(job_id)
    backup = ""
    try:
        if not database.IS_POSTGRES and database.get_db_path().exists():
            backup = str(database.backup_db("before_catalog_ingestion_approve"))
        with database.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            job = _dict(conn.execute("SELECT * FROM catalog_upload_jobs WHERE id=?", (job_id,)).fetchone())
            if not job:
                raise RuntimeError("CATALOG_UPLOAD_JOB_NOT_FOUND")
            if job.get("status") not in {"PENDING_PREVIEW", "PARTIALLY_APPROVED"}:
                raise RuntimeError(f"JOB_NOT_READY_FOR_APPROVAL: {job.get('status')}")
            rows = conn.execute(
                """
                SELECT * FROM catalog_staging_items
                WHERE job_id=? AND is_safe_to_apply=1 AND matched_product_id IS NOT NULL
                ORDER BY id
                """,
                (job_id,),
            ).fetchall()
            applied = 0
            unchanged = 0
            for row in rows:
                r = _dict(row)
                product_id = int(r.get("matched_product_id") or 0)
                old_price = str(r.get("old_price") or _product_price(conn, product_id))
                new_price = str(r.get("new_price") or r.get("parsed_price") or "")
                change_type = "PRICE_UNCHANGED" if same_price(old_price, new_price) else "UPDATE_PRICE"
                if change_type == "UPDATE_PRICE":
                    conn.execute(
                        "UPDATE products SET price=?, available='1', is_available=1, needs_review=0, search_mode='sellable', review_status='approved', last_seen_at=datetime('now'), updated_at=datetime('now') WHERE id=?",
                        (new_price, product_id),
                    )
                    applied += 1
                else:
                    conn.execute("UPDATE products SET available='1', is_available=1, needs_review=0, search_mode='sellable', review_status='approved', last_seen_at=datetime('now'), updated_at=datetime('now') WHERE id=?", (product_id,))
                    unchanged += 1
                conn.execute(
                    """
                    INSERT INTO merchant_product_aliases(
                        merchant_id, raw_name, normalized_raw_name, product_id, source,
                        last_seen_at, last_seen_in_upload_id, is_active, created_at, updated_at
                    ) VALUES(?,?,?,?,?,datetime('now'),?,1,datetime('now'),datetime('now'))
                    ON CONFLICT(merchant_id, normalized_raw_name) WHERE is_active=1 DO UPDATE SET
                        raw_name=excluded.raw_name,
                        product_id=excluded.product_id,
                        source=CASE WHEN merchant_product_aliases.source='admin_review' THEN merchant_product_aliases.source ELSE excluded.source END,
                        last_seen_at=datetime('now'),
                        last_seen_in_upload_id=excluded.last_seen_in_upload_id,
                        updated_at=datetime('now')
                    """,
                    (int(r.get("merchant_id") or job.get("merchant_id") or 1), r.get("raw_name") or "", r.get("normalized_name") or "",
                     product_id, "auto_identity" if r.get("decision") == "SAFE_IDENTITY_MATCH" else "auto_exact", job_id),
                )
                audit_conn(conn, merchant_id=int(r.get("merchant_id") or job.get("merchant_id") or 1), product_id=product_id,
                           old_price=old_price, new_price=new_price, upload_job_id=job_id, staging_item_id=int(r.get("id") or 0),
                           changed_by=actor, change_type=change_type,
                           details={"decision": r.get("decision"), "raw_name": r.get("raw_name")})
            pending = int(conn.execute("SELECT COUNT(*) FROM catalog_review_items WHERE job_id=? AND status='PENDING'", (job_id,)).fetchone()[0])
            final_status = "PARTIALLY_APPROVED" if pending else "APPROVED"
            conn.execute(
                "UPDATE catalog_upload_jobs SET status=?, approved_at=datetime('now'), approved_by=?, backup_path=?, updated_at=datetime('now') WHERE id=?",
                (final_status, actor, backup, job_id),
            )
        summary = _summary_for_job(job_id)
        _mirror_old_job(job_id, final_status, summary)
        return {"ok": True, "job_id": job_id, "status": final_status, "updated": applied, "unchanged": unchanged, "pending_review": pending, "backup": backup}
    except Exception as exc:
        try:
            _set_job_status(job_id, "ROLLED_BACK", error=f"{type(exc).__name__}: {exc}")
        except Exception:
            pass
        raise


approve_ingestion_job = approve_staging_job


def reject_staging_job(job_id: int, actor: str = "merchant", reason: str = "") -> Dict[str, Any]:
    ensure_schema()
    with database.connect() as conn:
        conn.execute("UPDATE catalog_upload_jobs SET status='REJECTED', error_text=?, updated_at=datetime('now') WHERE id=?", (reason or "rejected", int(job_id)))
        conn.execute("UPDATE catalog_review_items SET status='REJECTED', notes=?, updated_at=datetime('now') WHERE job_id=? AND status='PENDING'", (reason or "job rejected", int(job_id)))
    _mirror_old_job(int(job_id), "REJECTED", {}, reason)
    return {"ok": True, "job_id": int(job_id)}


def _summary_for_job(job_id: int) -> Dict[str, int]:
    with database.connect() as conn:
        row = _dict(conn.execute("SELECT * FROM catalog_upload_jobs WHERE id=?", (int(job_id),)).fetchone())
        if row:
            return {k: int(row.get(k) or 0) for k in ["rows_total", "safe_updates_count", "unchanged_count", "review_count", "new_count", "invalid_count", "duplicate_count"]}
        return {}


def job_report(job_id: int) -> Dict[str, Any]:
    ensure_schema()
    with database.connect() as conn:
        job = _dict(conn.execute("SELECT * FROM catalog_upload_jobs WHERE id=?", (int(job_id),)).fetchone())
        if not job:
            old = database.get_catalog_import_job(int(job_id)) or {}
            job = {"id": job_id, "status": old.get("status"), "report_json": old.get("report_text") or "{}"}
        decisions = [_dict(r) for r in conn.execute("SELECT decision, COUNT(*) AS n FROM catalog_staging_items WHERE job_id=? GROUP BY decision ORDER BY n DESC", (int(job_id),)).fetchall()]
        examples = [_dict(r) for r in conn.execute("SELECT * FROM catalog_staging_items WHERE job_id=? ORDER BY id LIMIT 150", (int(job_id),)).fetchall()]
        reviews = [_dict(r) for r in conn.execute("SELECT * FROM catalog_review_items WHERE job_id=? ORDER BY id LIMIT 150", (int(job_id),)).fetchall()]
    # Template compatibility expects report.upload.report_json.
    if isinstance(job.get("report_json"), str):
        job["report_json"] = job.get("report_json") or "{}"
    return {"upload": job, "decisions": decisions, "examples": examples, "reviews": reviews}


def pending_reviews(limit: int = 100, merchant_id: int | None = None) -> List[Dict[str, Any]]:
    ensure_schema()
    sql = "SELECT * FROM catalog_review_items WHERE status IN ('PENDING','pending')"
    params: List[Any] = []
    if merchant_id is not None:
        sql += " AND merchant_id=?"
        params.append(int(merchant_id))
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(int(limit))
    with database.connect() as conn:
        return [_dict(r) for r in conn.execute(sql, params).fetchall()]


def search_products(q: str, limit: int = 50) -> List[Dict[str, Any]]:
    """Admin review product lookup routed through the single matcher first.

    This page is for an admin to choose an existing product; the matcher result
    determines identity candidates.  A small exact SQL LIKE fallback remains only
    for admin navigation when no matcher candidates exist; it does not update
    prices or show customer results.
    """
    ensure_schema()
    query = str(q or "").strip()
    if not query:
        return []
    try:
        from services.matching.excel_native_matcher import match_text
        result = match_text(query)
        candidates: List[Dict[str, Any]] = []
        if result.product:
            candidates.append(result.product)
        candidates.extend(result.products or [])
        seen = set()
        out = []
        for p in candidates:
            pid = p.get("id")
            if not pid or pid in seen:
                continue
            seen.add(pid)
            out.append(p)
            if len(out) >= int(limit):
                return out
        if out:
            return out
    except Exception:
        pass

    # Admin-only navigation fallback: exact substring search over catalog fields.
    # It is not used for customer matching or price updates.
    nq = normalize_arabic_name(query)
    like1 = f"%{query}%"
    like2 = f"%{nq}%"
    with database.connect() as conn:
        if not database.table_exists(conn, "products"):
            return []
        rows = conn.execute(
            """
            SELECT id, name, price, brand, product_family, size, strength, form, normalized_name
            FROM products
            WHERE name LIKE ? OR normalized_name LIKE ? OR aliases LIKE ?
            ORDER BY name LIMIT ?
            """,
            (like1, like2, like1, int(limit)),
        ).fetchall()
        return [_dict(r) for r in rows]


def _insert_product_alias(conn: Any, product_id: int, raw_name: str, source: str = "admin_review") -> None:
    norm = normalize_arabic_name(raw_name)
    if not norm or not product_id:
        return
    conn.execute(
        """
        INSERT OR IGNORE INTO product_aliases(
            product_id, product_db_id, alias, alias_normalized, normalized_alias, source, is_active, approved, created_at, updated_at
        ) VALUES(?,?,?,?,?,?,1,1,datetime('now'),datetime('now'))
        """,
        (int(product_id), int(product_id), raw_name, norm, norm, source),
    )


def resolve_review_item(review_id: int, product_id: int, actor: str = "admin", apply_price: bool = False) -> Dict[str, Any]:
    ensure_schema()
    with database.connect() as conn:
        review = _dict(conn.execute("SELECT * FROM catalog_review_items WHERE id=?", (int(review_id),)).fetchone())
        if not review:
            raise RuntimeError("REVIEW_ITEM_NOT_FOUND")
        product = _dict(conn.execute("SELECT id, price FROM products WHERE id=?", (int(product_id),)).fetchone())
        if not product:
            raise RuntimeError("PRODUCT_NOT_FOUND")
        raw_name = review.get("raw_name") or ""
        normalized = review.get("normalized_name") or normalize_arabic_name(raw_name)
        merchant_id = int(review.get("merchant_id") or 1)
        job_id = int(review.get("job_id") or 0)
        _insert_product_alias(conn, int(product_id), raw_name, "admin_review")
        conn.execute(
            """
            INSERT INTO merchant_product_aliases(
                merchant_id, raw_name, normalized_raw_name, product_id, source,
                last_seen_at, last_seen_in_upload_id, is_active, created_at, updated_at
            ) VALUES(?,?,?,?, 'admin_review', datetime('now'), ?, 1, datetime('now'), datetime('now'))
            ON CONFLICT(merchant_id, normalized_raw_name) WHERE is_active=1 DO UPDATE SET
                raw_name=excluded.raw_name, product_id=excluded.product_id, source='admin_review',
                last_seen_at=datetime('now'), last_seen_in_upload_id=excluded.last_seen_in_upload_id, updated_at=datetime('now')
            """,
            (merchant_id, raw_name, normalized, int(product_id), job_id),
        )
        old_price = str(product.get("price") or "")
        new_price = str(review.get("price") or review.get("price_new") or "")
        if apply_price and new_price:
            conn.execute("UPDATE products SET price=?, available='1', is_available=1, needs_review=0, search_mode='sellable', review_status='approved', last_seen_at=datetime('now'), updated_at=datetime('now') WHERE id=?", (new_price, int(product_id)))
            audit_conn(conn, merchant_id=merchant_id, product_id=int(product_id), old_price=old_price, new_price=new_price,
                       upload_job_id=job_id, staging_item_id=review.get("staging_item_id"), changed_by=actor,
                       change_type="ADMIN_REVIEW_UPDATE_PRICE", details={"review_id": review_id, "raw_name": raw_name})
        conn.execute(
            """
            UPDATE catalog_review_items
            SET status='RESOLVED', resolved_product_id=?, matched_product_db_id=?, reviewed_by=?, reviewed_at=datetime('now'), updated_at=datetime('now')
            WHERE id=?
            """,
            (int(product_id), int(product_id), actor, int(review_id)),
        )
    return {"ok": True, "review_id": int(review_id), "product_id": int(product_id), "alias_learned": normalized}


def approve_review_item(review_id: int, actor: str = "admin", **fields: Any) -> Dict[str, Any]:
    """Compatibility wrapper.

    New safe path requires an explicit existing product id.  If a UI passes
    resolved_product_id/product_id/matched_product_id, this resolves and learns
    an alias.  It never guesses the product from free text.
    """
    pid = fields.get("resolved_product_id") or fields.get("product_id") or fields.get("matched_product_id")
    if not pid:
        raise RuntimeError("RESOLVED_PRODUCT_ID_REQUIRED_FOR_SAFE_REVIEW_APPROVAL")
    apply_price = str(fields.get("apply_price") or "").lower() in {"1", "true", "yes", "on"}
    return resolve_review_item(int(review_id), int(pid), actor=actor, apply_price=apply_price)


def reject_review_item(review_id: int, actor: str = "admin", reason: str = "") -> Dict[str, Any]:
    ensure_schema()
    with database.connect() as conn:
        review = _dict(conn.execute("SELECT * FROM catalog_review_items WHERE id=?", (int(review_id),)).fetchone())
        if not review:
            raise RuntimeError("REVIEW_ITEM_NOT_FOUND")
        conn.execute(
            """
            UPDATE catalog_review_items
            SET status='REJECTED', notes=?, review_notes=?, reviewed_by=?, reviewed_at=datetime('now'), updated_at=datetime('now')
            WHERE id=?
            """,
            (reason or "rejected", reason or "rejected", actor, int(review_id)),
        )
    return {"ok": True, "review_id": int(review_id)}


def create_product_from_review(review_id: int, actor: str = "admin", *, name: str = "", price: str = "", category: str = "", brand: str = "") -> Dict[str, Any]:
    """Admin-only explicit creation of a new product from a review row."""
    ensure_schema()
    with database.connect() as conn:
        review = _dict(conn.execute("SELECT * FROM catalog_review_items WHERE id=?", (int(review_id),)).fetchone())
        if not review:
            raise RuntimeError("REVIEW_ITEM_NOT_FOUND")
        raw_name = (name or review.get("raw_name") or "").strip()
        new_price = parse_price(price or review.get("price") or review.get("price_new") or "")
        normalized = normalize_arabic_name(raw_name)
        merchant_id = int(review.get("merchant_id") or 1)
        columns = [c for c in database.PRODUCT_COLUMNS if c not in {"created_at", "updated_at"}]
        payload = {c: "" for c in columns}
        payload.update({
            "merchant_id": str(merchant_id),
            "name": raw_name,
            "original_name": raw_name,
            "normalized_name": normalized,
            "brand": brand or "",
            "category": category or "",
            "main_section": category or "",
            "price": new_price,
            "available": "true",
            "search_mode": "sellable",
            "quality_status": "approved",
            "review_status": "approved",
            "aliases": raw_name,
        })
        quoted_cols = ", ".join(f'"{c}"' for c in columns)
        placeholders = ", ".join(["?"] * len(columns))
        cur = conn.execute(
            f"INSERT INTO products({quoted_cols}, created_at, updated_at) VALUES({placeholders}, datetime('now'), datetime('now'))",
            [payload.get(c, "") for c in columns],
        )
        product_id = int(cur.lastrowid)
        try:
            cols = set(database.table_columns(conn, "products"))
            sets = []
            if "available" in cols:
                sets.append("available='1'")
            if "is_available" in cols:
                sets.append("is_available=1")
            if "needs_review" in cols:
                sets.append("needs_review=0")
            if sets:
                conn.execute(f"UPDATE products SET {', '.join(sets)} WHERE id=?", (product_id,))
        except Exception:
            pass
        _insert_product_alias(conn, product_id, raw_name, "admin_new_product")
        conn.execute(
            """
            INSERT INTO merchant_product_aliases(
                merchant_id, raw_name, normalized_raw_name, product_id, source,
                last_seen_at, last_seen_in_upload_id, is_active, created_at, updated_at
            ) VALUES(?,?,?,?, 'admin_review_new_product', datetime('now'), ?, 1, datetime('now'), datetime('now'))
            """,
            (merchant_id, raw_name, normalized, product_id, int(review.get("job_id") or 0)),
        )
        conn.execute(
            """
            UPDATE catalog_review_items
            SET status='NEW_PRODUCT_CREATED', resolved_product_id=?, matched_product_db_id=?, reviewed_by=?, reviewed_at=datetime('now'), updated_at=datetime('now')
            WHERE id=?
            """,
            (product_id, product_id, actor, int(review_id)),
        )
        audit_conn(conn, merchant_id=merchant_id, product_id=product_id, old_price="", new_price=new_price,
                   upload_job_id=int(review.get("job_id") or 0), staging_item_id=review.get("staging_item_id"),
                   changed_by=actor, change_type="NEW_PRODUCT_CREATED", details={"review_id": review_id, "raw_name": raw_name})
    return {"ok": True, "review_id": int(review_id), "product_id": product_id}
