from typing import Dict, List

import config_env
import database
from normalizer import safe_price, normalize_text
from services.whatsapp.result_formatter import display_label, product_display_name, CATEGORY_LABELS as CUSTOMER_CATEGORY_LABELS, FORM_LABELS as CUSTOMER_FORM_LABELS, list_row_description

CATEGORY_LABELS = {**CUSTOMER_CATEGORY_LABELS, "مكملات": "مكملات غذائية"}
FORM_LABELS = {**CUSTOMER_FORM_LABELS, "skincare_cream": "كريم"}


def _ltr_value(value: object) -> str:
    return "\u2066" + str(value or "").strip() + "\u2069"

def _display_label(value: object, labels: Dict[str, str]) -> str:
    return display_label(value, labels)


def format_product_line(i: int, product: Dict) -> str:
    desc = list_row_description(product, include_price=False)
    suffix = f" — {desc}" if desc and desc != "اضغط لعرض التفاصيل" else ""
    return f"{i}. {product_display_name(product)}{suffix}"


def format_product_list(products: List[Dict], page: int = 0, page_size: int = 10) -> str:
    if not products:
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار."
    start = page * page_size
    chunk = products[start:start + page_size]
    lines = ["منتجات متوفرة:", ""]
    for i, p in enumerate(chunk, 1):
        lines.append(format_product_line(i, p))
    lines.append("")
    lines.append("اختر المنتج من القائمة التفاعلية لعرض التفاصيل.")
    lines.append('اكتب "القائمة" للرجوع للقائمة الرئيسية.')
    return "\n".join(lines)


def format_product_details(product: Dict) -> str:
    name = _ltr_value(product_display_name(product))
    if str(product.get("needs_review") or "").strip().lower() in {"1", "true", "yes", "on"}:
        return (
            f"🔍 {name}\n"
            "هذا المنتج يحتاج مراجعة قبل عرض السعر.\n"
            "يرجى اختيار منتج آخر أو التواصل مع الصيدلية."
        )
    if "is_available" in product and not database.truthy(product.get("is_available")):
        return (
            f"⚠️ {name}\n"
            "غير متوفر حالياً في الصيدلية."
        )
    price = _ltr_value(safe_price(product.get("price")))
    currency = (product.get("currency") or "د.ل").replace("LYD", "د.ل")
    return (
        f"✅ {name}\n"
        f"السعر: {price} {currency}\n"
        "متوفر حالياً.\n\n"
        "هل تحتاج مساعدة أخرى؟"
    )


def create_order(phone: str, product: Dict, quantity: int) -> int:
    return database.create_order(phone, product, quantity)


def format_my_orders(phone: str) -> str:
    rows = database.recent_orders_for_phone(phone, limit=5)
    if not rows:
        return "لا توجد طلبات مسجلة لك حاليًا."
    lines = ["آخر طلباتك:"]
    for r in rows:
        lines.append(f"#{r['id']} - {r['product_name']} - الكمية {r['quantity']} - الحالة: {r['status']}")
    return "\n".join(lines)
