# PriceBot All Issues Fix - 2026-06-22

This patch is built on top of `PriceBot_FINAL_PRODUCTION_HARDENING_20260622`.

## Fixed

1. WhatsApp button titles are now routed safely even when WhatsApp sends visible Arabic text instead of button IDs:
   - بحث بالاسم
   - بحث بالصورة
   - الأقسام
   - القائمة
   - بحث جديد

2. Generic brand/family searches no longer select one arbitrary product if multiple products exist:
   - Panadol
   - Bioderma
   - Rilastil
   - CeraVe
   - Cetaphil

3. Search result formatting was rebuilt to avoid Arabic/English/price direction overlap in WhatsApp.

4. Results now include direct actions for:
   - بحث جديد
   - بحث بالصورة
   - القائمة

5. Conservative fuzzy typo recovery was added for multi-token product names:
   - Ralistil xeroloact -> Rilastil Xerolact
   - similar brand + variant misspellings

6. Gemini text evidence validation is stricter and reciprocal. Gemini can still correct spelling, but cannot choose a wrong variant from the same brand based only on a shared brand token.

7. `start-pricebot.sh` now defaults to binding on `0.0.0.0` instead of `127.0.0.1`, allowing direct testing via `http://SERVER_IP:8090/merchant` if firewall permits. Existing `.env` can override with `PRICEBOT_HOST`.

## Not changed

- Database is not included and should not be overwritten.
- `.env` is not included for deployment overwrite.
- Gemini remains active for images and ambiguous/new text.
- Prices are still shown only after safe product resolution/confirmation.
