# PriceBot Gemini Safe Economy Mode - 2026-06-22

## Goal
Reduce repeated Gemini/OpenRouter calls without lowering recognition accuracy.

## Core safety rule
Gemini remains the authority for new or ambiguous text/image recognition. The bot only reuses memory when the evidence is exact and confirmed.

## Implemented

### 1. Exact image cache after user confirmation
- After a user confirms an image candidate, the bot stores the SHA-256 image hash with the matched product id.
- If the exact same image is sent again, the bot skips Gemini and asks the same confirmation question.
- It does not display price directly from an image cache hit.
- It does not use fuzzy or similar-image matching.

### 2. Conservative exact text memory
- Adds `safe_text_memory` table.
- Stores only specific confirmed text queries.
- Rejects generic one-word inputs such as `Panadol`.
- Uses exact normalized query lookup only.
- A text memory hit asks for user confirmation before showing product details.

### 3. Gemini fallback for text when local matching fails
- When local matching returns `LOW_CONFIDENCE` or `NOT_AVAILABLE`, Gemini can be used as a fallback.
- The Gemini result still requires user confirmation before product details are shown.
- Disable with `PRICEBOT_TEXT_GEMINI_FALLBACK=0`.

### 4. Image path preserved
- New product images still use Gemini vision + Gemini product matcher.
- Evidence validation remains in place.
- The bot still asks confirmation before showing price.

## What was deliberately not implemented
- No Gemini-generated product codes.
- No fuzzy visual memory for similar photos.
- No direct price display from image recognition.
- No automatic alias insertion into `product_aliases` from weak queries.

## Files changed
- `app.py`
- `database.py`
- `ui_flow.py`

## Validation
- Python syntax check passed for modified core files.
- Temporary SQLite smoke test passed:
  - generic `Panadol` rejected from safe text memory.
  - specific `Panadol Extra` accepted.
  - exact image cache stores `EXACT_IMAGE_CONFIRMED`.
