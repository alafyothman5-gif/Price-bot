# PriceBot Performance Hardening V1 - 2026-06-22

## Scope
This patch strengthens the existing PriceBot codebase without changing WhatsApp conversation logic, product pricing logic, Gemini-only AI behavior, merchant/admin routes, or the production database file.

## Added / Confirmed

### 1. SQLite hardening
- `journal_mode=WAL`
- `synchronous=NORMAL`
- `busy_timeout=30000`
- `temp_store=MEMORY`
- `cache_size=-20000`
- `mmap_size=268435456`
- `wal_autocheckpoint=1000`

### 2. Safe startup indexes
The patch creates indexes only when the table and all required columns exist. Missing optional tables are skipped safely.

Covered areas:
- Product visibility and search fields.
- Product aliases.
- Search index.
- Guided catalog browsing.
- Conversation state.
- Processed messages.
- Import jobs and review queue.
- Image cache / Gemini cache.
- Visual memory and learning inbox when present.

### 3. Query planner optimization
- `ANALYZE`
- `PRAGMA optimize`

### 4. Separate runtime queues
The in-process queue is split into:
- `text_queue` for normal name/menu messages.
- `image_queue` for image/Gemini work.

This prevents slow image processing from blocking fast text searches.

### 5. Health visibility
`/health` and `/health/deep` now expose text/image queue sizes and worker counts. Deep health includes SQLite performance settings.

## Environment variables
Optional overrides:

```env
PRICEBOT_TEXT_QUEUE_MAXSIZE=2000
PRICEBOT_IMAGE_QUEUE_MAXSIZE=1000
PRICEBOT_TEXT_WORKERS=10
PRICEBOT_IMAGE_WORKERS=4
```

## Safety
- Does not include or replace `.env`.
- Does not include or replace `pricebot.db`.
- Does not delete products.
- Does not change product prices.
- Does not affect another bot unless deployed into the other bot's folder manually.
