# PriceBot Performance Hardening V2 — Runtime Cache + Alias Cache

## الهدف
تقوية سرعة البحث اليومي بدون تغيير منطق واتساب، الأسعار، الصور، Gemini، أو قاعدة بيانات المنتجات.

## ما تم إضافته

1. Runtime Product Cache
   - كاش داخلي للمنتجات داخل ذاكرة التطبيق.
   - `database.get_product()` يستفيد من الكاش بعد تحميل الفهرس.
   - `database.load_product_rows()` يستخدم الكاش في مسار تحميل الكتالوج الكامل.
   - الكاش لا يكتب في قاعدة البيانات ولا يغير أي منتج.

2. Alias Cache
   - تحميل approved aliases من:
     - `product_aliases`
     - `merchant_product_aliases`
   - إضافتها إلى فهرس المطابقة داخل `excel_native_matcher` مرة واحدة عند warmup.
   - يقلل الاستعلامات المتكررة ويقوي التعرف على أسماء العملاء والمرادفات.

3. Product ID Map
   - إضافة فهرس داخلي `by_product_id` داخل matcher.
   - يقلل البحث الخطي داخل قائمة المنتجات عند التعامل مع product_id.

4. Token Inverted Index
   - إضافة فهرس داخلي للكلمات القوية `by_token`.
   - عند عدم وجود exact match، البحث بالكلمات لا يمسح كل الكتالوج في كل رسالة.

5. Cache Invalidation
   - عند إعادة بناء الفهارس أو رفع Excel يتم تفريغ runtime caches.
   - الكاش يُعاد تحميله تلقائياً بعد ذلك.

6. Health Diagnostics
   - `/health` و `/health/deep` يعرضان:
     - runtime cache status
     - matcher cache status
     - عدد المنتجات المحملة
     - عدد aliases المحملة
     - عمر الكاش بالثواني

## متغيرات بيئة اختيارية

- `PRICEBOT_RUNTIME_CACHE=1` لتفعيل الكاش. الافتراضي: مفعل.
- `PRICEBOT_RUNTIME_CACHE_TTL_SECONDS=3600` مدة صلاحية الكاش. ضع `0` لجعله مفتوحاً حتى invalidation.

## الأمان

- لا يتم حذف منتجات.
- لا يتم تعديل أسعار.
- لا يتم تغيير جدول المنتجات إلا عبر المسارات الموجودة سابقاً.
- قاعدة البيانات تبقى المصدر الوحيد للحقيقة.
- الكاش داخل الذاكرة فقط ويختفي عند restart.

## الاختبار

تم فحص syntax للملفات الأساسية، وتم اختبار مطابقة alias من جدول `product_aliases` على قاعدة SQLite مؤقتة.
