(function(){
  function qs(s,root){return (root||document).querySelector(s)}
  function qsa(s,root){return Array.prototype.slice.call((root||document).querySelectorAll(s))}
  function showLoading(){var el=qs('[data-loading]'); if(el){el.classList.add('show'); el.dataset.started=Date.now(); setTimeout(function(){el.classList.remove('show')},9000)}}
  function hideLoading(){var el=qs('[data-loading]'); if(el){el.classList.remove('show')}}
  function getStore(k){try{return localStorage.getItem(k)||''}catch(e){return ''}}
  function setStore(k,v){try{if(v){localStorage.setItem(k,v)}else{localStorage.removeItem(k)}}catch(e){}}
  function sendEvent(type,data){
    try{
      var payload=JSON.stringify({event:type,data:data||{},path:location.pathname+location.search,title:document.title});
      if(payload.length>3900){return}
      if(navigator.sendBeacon){
        var ok=navigator.sendBeacon('/catalog-event', new Blob([payload],{type:'application/json'}));
        if(ok){return}
      }
      fetch('/catalog-event',{method:'POST',headers:{'Content-Type':'application/json'},body:payload,keepalive:true,credentials:'same-origin'}).catch(function(){});
    }catch(e){}
  }
  function applyTheme(theme){document.documentElement.classList.remove('theme-dark','theme-light'); if(theme){document.documentElement.classList.add('theme-'+theme)}}
  var theme=getStore('pricebot-theme'); applyTheme(theme);
  window.addEventListener('pageshow',hideLoading);
  window.addEventListener('pagehide',hideLoading);
  window.addEventListener('DOMContentLoaded',function(){
    hideLoading();
    sendEvent('page_view',{path:location.pathname+location.search,title:document.title});
    var resultBox=document.querySelector('[data-results-count]'); if(resultBox && resultBox.getAttribute('data-results-count')==='0'){sendEvent('zero_results',{q:(new URLSearchParams(location.search)).get('q')||'',path:location.pathname+location.search});}

    qsa('img').forEach(function(img){img.addEventListener('error',function(){var box=img.closest('.product-image,.image'); if(box){box.classList.add('img-failed')} img.remove();},{once:true});});
    qsa('form.search').forEach(function(f){f.addEventListener('submit',function(){sendEvent('search_submit',{q:(qs('input[name=q]',f)||{}).value||'',category:(qs('select[name=category]',f)||{}).value||'',brand:(qs('select[name=brand]',f)||{}).value||'',availability:(qs('select[name=availability]',f)||{}).value||'',sort:(qs('select[name=sort]',f)||{}).value||''});showLoading();});});
    qsa('a').forEach(function(a){a.addEventListener('click',function(){var href=a.getAttribute('href')||''; if(href.indexOf('/order/')===0||href.indexOf('wa.me')>-1){sendEvent('order_or_whatsapp_click',{href:href,label:(a.textContent||'').trim()});} if(href && href.charAt(0)==='/' && !a.hasAttribute('target') && href.indexOf('#')!==0){showLoading();}});});
    qsa('select[data-autosubmit]').forEach(function(s){s.addEventListener('change',function(){sendEvent('filter_change',{name:s.name,value:s.value,path:location.pathname+location.search});showLoading(); s.form && s.form.submit();});});
    var btn=qs('[data-theme-toggle]'); if(btn){btn.setAttribute('aria-pressed',theme==='dark'?'true':'false'); btn.setAttribute('title',theme==='dark'?'الوضع الليلي مفعل':'تغيير الوضع الليلي'); btn.addEventListener('click',function(){var cur=getStore('pricebot-theme'); var next=cur==='dark'?'light':(cur==='light'?'':'dark'); setStore('pricebot-theme',next); btn.setAttribute('aria-pressed',next==='dark'?'true':'false'); btn.setAttribute('title',next==='dark'?'الوضع الليلي مفعل':'تغيير الوضع الليلي'); applyTheme(next);});}
    qsa('[data-copy-url]').forEach(function(copyBtn){copyBtn.addEventListener('click',function(){try{navigator.clipboard.writeText(location.href); copyBtn.textContent='تم نسخ الرابط'; sendEvent('copy_link',{});}catch(e){}});});
    qsa('[data-share]').forEach(function(shareBtn){shareBtn.addEventListener('click',function(){sendEvent('share',{}); if(navigator.share){navigator.share({title:document.title,url:location.href}).catch(function(){});}else{try{navigator.clipboard.writeText(location.href); shareBtn.textContent='تم نسخ الرابط'}catch(e){}}});});
  });
})();
