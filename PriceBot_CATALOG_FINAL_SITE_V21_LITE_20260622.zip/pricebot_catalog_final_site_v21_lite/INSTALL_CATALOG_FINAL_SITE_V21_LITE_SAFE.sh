#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%F_%H-%M-%S)"
BACKUP_DIR="$APP_DIR/backups/catalog-final-site-v21-lite-$STAMP"
cd "$APP_DIR"

echo "===== Backup current catalog files ====="
mkdir -p "$BACKUP_DIR/static"
cp -a catalog_web.py "$BACKUP_DIR/catalog_web.py" 2>/dev/null || true
cp -a app.py "$BACKUP_DIR/app.py" 2>/dev/null || true
cp -a static/catalog_app.css "$BACKUP_DIR/static/catalog_app.css" 2>/dev/null || true
cp -a static/catalog_app.js "$BACKUP_DIR/static/catalog_app.js" 2>/dev/null || true

echo "===== Check Python syntax ====="
python3 -m py_compile "$SRC_DIR/catalog_web.py"

echo "===== Install V2.1 LITE files ====="
mkdir -p "$APP_DIR/static"
cp -a "$SRC_DIR/catalog_web.py" "$APP_DIR/catalog_web.py"
cp -a "$SRC_DIR/catalog_app.css" "$APP_DIR/static/catalog_app.css"
cp -a "$SRC_DIR/catalog_app.js" "$APP_DIR/static/catalog_app.js"

# Optional assets: keep existing server assets if not included in this LITE package.
for asset in badr_logo.png favicon.ico icon-192.png icon-512.png; do
  if [ -f "$SRC_DIR/$asset" ]; then
    cp -a "$SRC_DIR/$asset" "$APP_DIR/static/$asset"
  elif [ -f "$APP_DIR/$asset" ] && [ ! -f "$APP_DIR/static/$asset" ]; then
    cp -a "$APP_DIR/$asset" "$APP_DIR/static/$asset" || true
  fi
done

echo "===== Prepare analytics DB, indexes, and FTS search ====="
python3 - <<'INNERPY'
import os, sqlite3
from pathlib import Path
try:
    import database
    db = os.getenv('PRICEBOT_DB_FILE') or os.getenv('PRICEBOT_DB_PATH') or str(getattr(database, 'DB_FILE', '') or '') or '/opt/pricebot_clean/pricebot.db'
except Exception:
    db = os.getenv('PRICEBOT_DB_FILE') or os.getenv('PRICEBOT_DB_PATH') or '/opt/pricebot_clean/pricebot.db'

db_path = Path(db).expanduser().resolve()
analytics = Path(os.getenv('PRICEBOT_ANALYTICS_DB_FILE') or os.getenv('PRICEBOT_ANALYTICS_DB_PATH') or db_path.with_name('catalog_analytics.db')).expanduser().resolve()
analytics.parent.mkdir(parents=True, exist_ok=True)

with sqlite3.connect(str(analytics), timeout=10) as conn:
    conn.execute('''
    CREATE TABLE IF NOT EXISTS catalog_analytics_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT NOT NULL,
        path TEXT,
        label TEXT,
        meta_json TEXT,
        referrer TEXT,
        user_agent TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
    ''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_catalog_analytics_type_time ON catalog_analytics_events(event_type, created_at)')
    conn.commit()
print('analytics db ok:', analytics)

text_cols = [
    'name','canonical_display_name','normalized_name','normalized_name_catalog','original_name',
    'product_id','brand','company','product_family','aliases','ocr_keywords','active_ingredient',
    'form','strength','size','pack','barcode','stable_product_code','category','main_section',
    'sub_section','sub_category'
]

with sqlite3.connect(str(db_path), timeout=30) as conn:
    conn.row_factory = sqlite3.Row
    cols = {r[1] for r in conn.execute('PRAGMA table_info(products)').fetchall()}
    if 'id' not in cols:
        raise SystemExit('products.id missing')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_products_id_catalog ON products(id)')
    for col in ['brand','company','category','main_section','is_available','available','price','updated_at','last_updated','created_at']:
        if col in cols:
            conn.execute(f'CREATE INDEX IF NOT EXISTS idx_products_catalog_{col} ON products("{col}")')
    try:
        conn.execute('DROP TABLE IF EXISTS products_catalog_fts')
        conn.execute("CREATE VIRTUAL TABLE products_catalog_fts USING fts5(search_text, tokenize='unicode61 remove_diacritics 2')")
        use_cols = [c for c in text_cols if c in cols]
        if use_cols:
            select_sql = ', '.join(['id'] + [f'"{c}"' for c in use_cols])
            for row in conn.execute(f'SELECT {select_sql} FROM products'):
                search_text = ' '.join(str(row[c]) for c in use_cols if row[c] is not None)[:4000]
                conn.execute('INSERT INTO products_catalog_fts(rowid, search_text) VALUES(?, ?)', (int(row['id']), search_text))
        conn.commit()
        print('fts ok')
    except Exception as e:
        print('fts skipped:', e)
    conn.commit()
print('product indexes ok')
INNERPY

echo "===== Ensure catalog router is included LAST ====="
python3 - <<'INNERPY'
from pathlib import Path
import re
p = Path('/opt/pricebot_clean/app.py')
s = p.read_text(encoding='utf-8', errors='ignore')
changed = False

# Import catalog_web if missing. Keep existing app/merchant/webhook order unchanged.
if not re.search(r'(?m)^\s*import\s+catalog_web\s*$', s) and 'from catalog_web import' not in s:
    matches = list(re.finditer(r'^(?:from\s+\S+\s+import\s+.+|import\s+.+)$', s, flags=re.M))
    if matches:
        pos = matches[-1].end()
        s = s[:pos] + '\nimport catalog_web' + s[pos:]
    else:
        s = 'import catalog_web\n' + s
    changed = True

# Remove any old catalog include from any position.
s2 = re.sub(r'^[ \t]*app\.include_router\(\s*catalog_web\.router\s*\)\s*(?:#.*)?\n?', '', s, flags=re.M)
s2 = re.sub(r'^[ \t]*app\.include_router\(\s*catalog_router\s*\)\s*(?:#.*)?\n?', '', s2, flags=re.M)
if s2 != s:
    s = s2
    changed = True

# Add catalog router after the last include_router only.
line = 'app.include_router(catalog_web.router)  # catalog website router: keep LAST to avoid shadowing merchant/webhook/API routes'
matches = list(re.finditer(r'^[ \t]*app\.include_router\([^\n]+\)\s*(?:#.*)?$', s, flags=re.M))
if matches:
    pos = matches[-1].end()
    s = s[:pos] + '\n' + line + s[pos:]
else:
    s = s.rstrip() + '\n\n# Catalog website router - keep last\n' + line + '\n'
changed = True

if changed:
    p.write_text(s, encoding='utf-8')
print('router ok: catalog_web.router included last')
INNERPY

echo "===== Safety checks: no catch-all in catalog_web.py ====="
if grep -q "full_path:path" "$APP_DIR/catalog_web.py"; then
  echo "ERROR: catch-all route still exists in catalog_web.py"
  exit 1
fi

echo "===== Restart PriceBot only ====="
sudo systemctl restart pricebot.service
sleep 8

echo "===== Local route checks ====="
for path in "/merchant" "/merchant/site-analytics" "/merchant/site-tools" "/merchant/rebuild-search" "/catalog" "/products?q=panadol" "/product/1" "/product/1-product-name" "/sitemap.xml" "/order/1"; do
  echo "--- $path"
  curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:8090$path" || true
done

echo "DONE. Open: /catalog?v=final-site-v21-lite"
echo "Backup saved to: $BACKUP_DIR"
