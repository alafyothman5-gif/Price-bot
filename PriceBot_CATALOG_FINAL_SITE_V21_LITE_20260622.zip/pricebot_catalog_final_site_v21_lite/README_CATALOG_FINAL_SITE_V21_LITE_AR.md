# PriceBot Catalog Final Site V2.1 LITE

هذه نسخة صغيرة الحجم مخصصة للرفع من الهاتف إلى GitHub عندما يرفض GitHub الملف الكبير.

## ماذا تحتوي؟

- `catalog_web.py`
- `catalog_app.css`
- `catalog_app.js`
- سكربت تركيب آمن

## ماذا لا تحتوي؟

لا تحتوي على صور اللوقو أو الأيقونات الكبيرة لتقليل الحجم. السكربت سيُبقي الصور الموجودة حالياً على السيرفر كما هي.

## الإصلاحات

- يجعل `catalog_web.router` آخر Router داخل `app.py`.
- يزيل أي include قديم للكتالوج قبل `merchant.router`.
- لا يحتوي على catch-all route من نوع `/{full_path:path}`.
- يضيف `/merchant/site-tools`.
- يمنع تكرار `product_view` من JavaScript؛ التسجيل يبقى من السيرفر فقط.
- يحافظ على `.env` و `pricebot.db` والمنتجات والأسعار والصور.

## هل يحتاج Migration؟

ينشئ أو يعيد بناء جداول مساعدة فقط إن أمكن:

- `products_catalog_fts`
- `catalog_meta`
- `catalog_analytics.db`

لا يغيّر بيانات المنتجات.

## التثبيت

بعد رفع الملف إلى GitHub، نفذ الأمر الموجود في رسالة ChatGPT.
