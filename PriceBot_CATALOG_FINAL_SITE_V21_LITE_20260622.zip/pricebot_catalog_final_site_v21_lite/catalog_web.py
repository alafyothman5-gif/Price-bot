from __future__ import annotations

import html
import json
import os
import re
import sqlite3
import time
import datetime
import secrets
from functools import lru_cache
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote, urlencode, urlparse

from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse, PlainTextResponse, FileResponse, JSONResponse, Response

import database

router = APIRouter()

PAGE_SIZE = int(os.getenv("PRICEBOT_CATALOG_PAGE_SIZE", "24") or 24)
BRAND_ASSET_VERSION = "badr-catalog-final-site-v2"
CACHE_TTL_SECONDS = int(os.getenv("PRICEBOT_CATALOG_CACHE_TTL", "120") or 120)
ANALYTICS_RATE_LIMIT_PER_MINUTE = int(os.getenv("PRICEBOT_CATALOG_EVENT_RATE_LIMIT", "30") or 30)
MAX_PAGE = int(os.getenv("PRICEBOT_CATALOG_MAX_PAGE", "250") or 250)
SITEMAP_PRODUCT_LIMIT = int(os.getenv("PRICEBOT_SITEMAP_PRODUCT_LIMIT", "50000") or 50000)
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
BRAND_LOGO_FILE = STATIC_DIR / "badr_logo.png"
FAVICON_FILE = STATIC_DIR / "favicon.ico"
CSS_FILE = STATIC_DIR / "catalog_app.css"
JS_FILE = STATIC_DIR / "catalog_app.js"
_CATEGORY_CACHE = {"ts": 0.0, "items": []}
_BRAND_CACHE = {"ts": 0.0, "items": []}
_COLUMNS_CACHE = {"ts": 0.0, "db_mtime": 0.0, "items": set()}
_EVENT_BUCKETS: dict[str, deque[float]] = defaultdict(deque)
_FTS_META_CACHE = {"checked_mtime": 0.0, "ok": False}

AVAILABLE_VALUES = {"1", "true", "yes", "y", "available", "in stock", "instock", "on", "متوفر", "متاح", "موجود"}
UNAVAILABLE_VALUES = {"0", "false", "no", "n", "unavailable", "out of stock", "out_of_stock", "out", "off", "نفد", "نفدت الكمية", "غير متوفر", "غير متاح", "غير موجود"}
SEARCH_SYNONYMS = {
    "بنادول": ["panadol", "paracetamol", "باراسيتامول"],
    "بندول": ["panadol", "paracetamol", "باراسيتامول"],
    "panadol": ["بنادول", "بندول", "paracetamol", "باراسيتامول"],
    "paracetamol": ["panadol", "بنادول", "باراسيتامول"],
    "باراسيتامول": ["paracetamol", "panadol", "بنادول"],
    "سيرافي": ["cerave", "cera ve"],
    "سرافي": ["cerave", "cera ve"],
    "cerave": ["سيرافي", "سرافي", "cera ve"],
    "مسكن": ["painkiller", "analgesic", "panadol", "paracetamol"],
    "painkiller": ["مسكن", "analgesic"],
    "كريم": ["cream"],
    "كريم شمس": ["sunscreen", "sun screen", "spf"],
    "sunscreen": ["كريم شمس", "spf", "sun screen"],
}

TEXT_COLUMNS = [
    "name", "canonical_display_name", "normalized_name", "normalized_name_catalog", "original_name",
    "product_id", "brand", "company", "product_family", "aliases", "ocr_keywords", "active_ingredient",
    "form", "strength", "size", "pack", "barcode", "stable_product_code", "category", "main_section",
    "sub_section", "sub_category",
]

IMAGE_COLUMNS = [
    "catalog_image_url", "image_url", "photo_url", "product_image", "main_image", "image_path", "photo_path", "picture",
]

BRAND_CASE = {
    "panadol": "Panadol", "cerave": "CeraVe", "cera ve": "CeraVe", "rilastil": "Rilastil",
    "xerolact": "Xerolact", "aspirin": "Aspirin", "aspiriem": "Aspirin", "aspirim": "Aspirin",
    "parol": "Parol", "bioderma": "Bioderma", "uriage": "Uriage", "laroche": "La Roche-Posay",
    "la roche": "La Roche-Posay", "eucerin": "Eucerin", "vichy": "Vichy", "cetaphil": "Cetaphil",
}

CATEGORY_KEYWORDS = {
    "medicine": ["panadol", "parol", "aspirin", "aspiriem", "ibuprofen", "ketofan", "adol", "tablet", "tab", "capsule", "cap", "syrup", "mg", "قرص", "كبسول", "شراب"],
    "cosmetic": ["cerave", "rilastil", "bioderma", "eucerin", "vichy", "cetaphil", "cream", "lotion", "xerolact", "skin", "spf", "sunscreen", "كريم", "لوشن", "بشرة"],
    "supplement": ["vitamin", "omega", "zinc", "magnesium", "supplement", "فيتامين", "مكمل"],
    "device": ["meter", "device", "thermometer", "جهاز", "قياس"],
}

BAD_NAME_WORDS = {"info", "infos", "information", "details", "detail", "item", "product", "منتج"}


def _h(value: object) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def _security_headers(content_type: str | None = None, csp_nonce: str = "") -> Dict[str, str]:
    script_src = "'self'" + (f" 'nonce-{csp_nonce}'" if csp_nonce else "")
    image_hosts = " ".join("https://" + h for h in sorted(_allowed_image_hosts()) if h and not h.startswith("http"))
    img_src = "'self' data:" + ((" " + image_hosts) if image_hosts else "")
    csp = (
        "default-src 'self'; "
        f"img-src {img_src}; "
        f"script-src {script_src}; "
        "style-src 'self'; "
        "connect-src 'self'; "
        "form-action 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "object-src 'none'"
    )
    headers = {
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
        "Content-Security-Policy": csp,
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    }
    if content_type:
        headers["Content-Type"] = content_type
    return headers


def _html_response(doc: str, status_code: int = 200, csp_nonce: str = "") -> HTMLResponse:
    return HTMLResponse(doc, status_code=status_code, headers=_security_headers("text/html; charset=utf-8", csp_nonce=csp_nonce))


def _plain_response(text: str, status_code: int = 200, media_type: str = "text/plain; charset=utf-8") -> PlainTextResponse:
    return PlainTextResponse(text, status_code=status_code, media_type=media_type, headers=_security_headers())


def _json_response(data: Dict[str, object], status_code: int = 200) -> JSONResponse:
    return JSONResponse(data, status_code=status_code, headers=_security_headers())


def _now_date(days: int = 0) -> str:
    return (datetime.date.today() + datetime.timedelta(days=days)).isoformat()


def _stock_updated_at() -> str:
    # لا نعتمد على mtime قاعدة البيانات لأن التحليلات قد تكتب في قاعدة منفصلة أو قد تغيّر وقت الملف.
    try:
        with _connect() as conn:
            cols = _columns(conn)
            for col in ("stock_updated_at", "inventory_updated_at", "updated_at", "last_updated", "price_updated_at"):
                if col in cols:
                    value = conn.execute(
                        f"SELECT MAX(NULLIF(TRIM(CAST({_ident(col)} AS TEXT)), '')) FROM products"
                    ).fetchone()[0]
                    if value:
                        return str(value)[:16]
    except Exception:
        pass
    try:
        return datetime.datetime.fromtimestamp(_db_file().stat().st_mtime).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return "غير محدد"


def _allowed_image_hosts() -> set[str]:
    raw = os.getenv("PRICEBOT_ALLOWED_IMAGE_HOSTS", "")
    return {h.strip().lower() for h in raw.split(",") if h.strip()}


def _valid_http_image_url(src: str) -> bool:
    if not src:
        return False
    if src.startswith("/"):
        return not src.startswith("//")
    try:
        parsed = urlparse(src)
        if parsed.scheme != "https" or not parsed.netloc:
            return False
        allowed = _allowed_image_hosts()
        return bool(allowed) and (parsed.hostname or "").lower() in allowed
    except Exception:
        return False


def _analytics_db_file() -> Path:
    raw = os.getenv("PRICEBOT_ANALYTICS_DB_FILE") or os.getenv("PRICEBOT_ANALYTICS_DB_PATH")
    if raw:
        return Path(raw).expanduser().resolve()
    return _db_file().with_name("catalog_analytics.db")


def _db_file() -> Path:
    raw = (
        os.getenv("PRICEBOT_DB_FILE")
        or os.getenv("PRICEBOT_DB_PATH")
        or str(getattr(database, "DB_FILE", "") or "")
        or "/opt/pricebot_clean/pricebot.db"
    )
    return Path(raw).expanduser().resolve()


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{_db_file()}?mode=ro", uri=True, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    try:
        conn.create_function("catalog_price_number", 1, lambda v: _clean_price_float(v) if _clean_price_float(v) is not None else None)
    except Exception:
        pass
    return conn


def _connect_write() -> sqlite3.Connection:
    conn = sqlite3.connect(str(_db_file()), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _columns(conn: sqlite3.Connection) -> set[str]:
    try:
        mtime = _db_file().stat().st_mtime
        now = time.time()
        cached = _COLUMNS_CACHE.get("items") or set()
        if cached and _COLUMNS_CACHE.get("db_mtime") == mtime and now - float(_COLUMNS_CACHE.get("ts") or 0) < 300:
            return set(cached)
        cols = {str(r["name"]) for r in conn.execute("PRAGMA table_info(products)").fetchall()}
        _COLUMNS_CACHE.update({"ts": now, "db_mtime": mtime, "items": cols})
        return cols
    except Exception:
        return set()


def _first_existing(cols: set[str], candidates: Iterable[str]) -> Optional[str]:
    for col in candidates:
        if col in cols:
            return col
    return None


def _coalesce(cols: set[str], candidates: Iterable[str], fallback: str = "") -> str:
    parts = [f"NULLIF(TRIM(CAST({_ident(c)} AS TEXT)), '')" for c in candidates if c in cols]
    if fallback:
        parts.append("?")
    elif parts:
        parts.append("''")
    else:
        return "''"
    return parts[0] if len(parts) == 1 else "COALESCE(" + ", ".join(parts) + ")"



def _availability_columns(cols: set[str]) -> List[str]:
    return [c for c in ("is_available", "available", "in_stock", "stock_available") if c in cols]


def _availability_sql_expr(cols: set[str]) -> str:
    checks: List[str] = []
    yes = "(" + ",".join(repr(v) for v in sorted(AVAILABLE_VALUES)) + ")"
    no = "(" + ",".join(repr(v) for v in sorted(UNAVAILABLE_VALUES)) + ")"
    for col in _availability_columns(cols):
        val = f"LOWER(TRIM(CAST({_ident(col)} AS TEXT)))"
        checks.append(
            f"CASE WHEN {val} IN {yes} THEN 1 "
            f"WHEN {val} IN {no} THEN 0 "
            f"WHEN CAST({_ident(col)} AS TEXT) GLOB '[0-9]*' AND CAST({_ident(col)} AS REAL) > 0 THEN 1 "
            "ELSE NULL END"
        )
    if not checks:
        return "NULL"
    if len(checks) == 1:
        return checks[0]
    return "COALESCE(" + ",".join(checks) + ")"


def _availability_filter_condition(cols: set[str], status: str = "") -> str:
    status = (status or "").strip().lower()
    expr = _availability_sql_expr(cols)
    if status in {"available", "in_stock", "متوفر"}:
        return f"({expr}) = 1"
    if status in {"unavailable", "out", "out_of_stock", "نفد", "غير متوفر"}:
        return f"({expr}) = 0"
    if status in {"unknown", "uncertain"}:
        return f"({expr}) IS NULL"
    return "1=1"


def _availability_status(value: object) -> Optional[bool]:
    if value is None:
        return None
    raw = str(value).strip().lower()
    if raw in AVAILABLE_VALUES:
        return True
    if raw in UNAVAILABLE_VALUES:
        return False
    try:
        return bool(int(float(raw)))
    except Exception:
        return None


def _availability_label(value: object) -> Tuple[str, str, str]:
    status = _availability_status(value)
    if status is True:
        return "متوفر", "available", "https://schema.org/InStock"
    if status is False:
        return "نفد المخزون", "unavailable", "https://schema.org/OutOfStock"
    return "يُؤكد التوفر", "unknown", "https://schema.org/LimitedAvailability"


def _select_sql(cols: set[str]) -> Tuple[str, List[object]]:
    params: List[object] = []

    def cp(candidates: Iterable[str], fallback: str) -> str:
        expr = _coalesce(cols, candidates, fallback)
        if fallback:
            params.append(fallback)
        return expr

    name_expr = cp(["canonical_display_name", "name", "original_name", "product_id"], "Product")
    category_expr = cp(["category", "main_section", "section", "sub_section", "sub_category"], "")
    brand_expr = cp(["brand", "company", "product_family"], "")
    image_expr = cp(IMAGE_COLUMNS, "")
    price_expr = _ident("price") if "price" in cols else "NULL"
    currency_expr = _ident("currency") if "currency" in cols else "'LYD'"
    updated_expr = _coalesce(cols, ["updated_at", "last_updated", "price_updated_at", "created_at"], "")
    active_expr = _coalesce(cols, ["active_ingredient", "ingredient", "المادة_الفعالة"], "")
    form_expr = _coalesce(cols, ["form", "dosage_form", "shape"], "")
    strength_expr = _coalesce(cols, ["strength", "dose", "concentration"], "")
    size_expr = _coalesce(cols, ["size", "pack", "volume", "unit_size"], "")
    barcode_expr = _coalesce(cols, ["barcode", "bar_code", "ean", "sku", "stable_product_code", "product_id"], "")
    availability_expr = _availability_sql_expr(cols)
    return f"""
        id,
        {name_expr} AS display_name,
        {category_expr} AS category,
        {brand_expr} AS brand,
        {image_expr} AS image_url,
        {price_expr} AS price,
        {currency_expr} AS currency,
        {availability_expr} AS available_value,
        {updated_expr} AS updated_at,
        {active_expr} AS active_ingredient,
        {form_expr} AS form,
        {strength_expr} AS strength,
        {size_expr} AS size,
        {barcode_expr} AS barcode
    """, params

def _format_price(price: object, currency: object) -> str:
    value = _clean_price_float(price)
    if value is None:
        return "السعر يحتاج تأكيد"
    cur = str(currency or os.getenv("PRICEBOT_DEFAULT_CURRENCY", "LYD") or "LYD").strip()
    shown = str(int(value)) if float(value).is_integer() else f"{value:.2f}".rstrip("0").rstrip(".")
    return f"{shown} {cur}"


def _price_number(row: Dict[str, object]) -> float:
    val = _clean_price_float(row.get("price"))
    if val is None or val <= 0:
        return 10**12
    return val


def _smart_title_ascii(text: str) -> str:
    def fix_token(match: re.Match[str]) -> str:
        token = match.group(0)
        low = token.lower()
        if low in BRAND_CASE:
            return BRAND_CASE[low]
        if re.fullmatch(r"[A-Z]{2,}|[a-z]{1,2}", token):
            return token.upper() if len(token) <= 3 else token.capitalize()
        if re.search(r"\d", token):
            return token.upper().replace("MG", "mg").replace("ML", "ml")
        return token[:1].upper() + token[1:].lower()
    return re.sub(r"[A-Za-z][A-Za-z0-9+-]*", fix_token, text)


def _clean_product_name(value: object, brand: object = "", category: object = "") -> str:
    raw = str(value or "").strip()
    if not raw:
        return "منتج صيدلية"
    text = html.unescape(raw)
    text = text.replace("_", " ").replace("|", " ").replace("/", " / ")
    text = re.sub(r"\s+", " ", text).strip(" -–—,،.;:")
    words = text.split()
    while len(words) > 1 and words[-1].lower().strip(".:,،؛") in BAD_NAME_WORDS:
        words.pop()
    text = " ".join(words)
    text = re.sub(r"\binfo\b", "", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip(" -–—,،.;:")
    text = re.sub(r"\baspiriem\b|\baspirim\b|\basprien\b", "Aspirin", text, flags=re.I)
    text = re.sub(r"\bparol\b", "Parol", text, flags=re.I)
    text = re.sub(r"\bpanadol\b", "Panadol", text, flags=re.I)
    text = re.sub(r"\bcerave\b|\bcera\s+ve\b", "CeraVe", text, flags=re.I)
    text = re.sub(r"\brilastil\b", "Rilastil", text, flags=re.I)
    text = re.sub(r"\bxerolact\b", "Xerolact", text, flags=re.I)
    text = re.sub(r"(\d)\s*(mg|mcg|g|ml|iu|%)\b", lambda m: f"{m.group(1)} {m.group(2).lower()}", text, flags=re.I)
    text = re.sub(r"\b(tab|tabs|tablet|tablets)\b", "أقراص", text, flags=re.I)
    text = re.sub(r"\b(cap|caps|capsule|capsules)\b", "كبسولات", text, flags=re.I)
    text = _smart_title_ascii(text)
    text = re.sub(r"\s+", " ", text).strip(" -–—,،.;:")
    return text or "منتج صيدلية"


def _clean_brand(value: object, display_name: object = "") -> str:
    raw = str(value or "").strip()
    low = raw.lower()
    hay = f"{raw} {display_name}".lower()
    for key, shown in BRAND_CASE.items():
        if low == key or re.search(rf"\b{re.escape(key)}\b", hay):
            return shown
    if not raw:
        return ""
    raw = re.sub(r"\binfo\b", "", raw, flags=re.I).strip(" -–—,،.;:")
    return _smart_title_ascii(raw)


def _effective_category(raw_category: object, display_name: object = "", brand: object = "") -> str:
    raw = str(raw_category or "").strip()
    n = raw.lower()
    hay = f"{display_name} {brand} {raw}".lower()
    if not raw or n in {"other", "others", "أخرى", "اخرى", "misc", "unknown", "عام"}:
        for cat, words in CATEGORY_KEYWORDS.items():
            if any(w in hay for w in words):
                return cat
    return raw


def _search_blob_sql(cols: set[str]) -> str:
    parts = []
    for c in ["canonical_display_name", "name", "original_name", "brand", "company", "category", "main_section", "active_ingredient", "barcode"]:
        if c in cols:
            parts.append(f"LOWER(CAST({_ident(c)} AS TEXT))")
    if not parts:
        return "''"
    return "LOWER(" + " || ' ' || ".join(parts) + ")"


def _effective_category_sql(cols: set[str]) -> str:
    raw = _coalesce(cols, ["category", "main_section", "section", "sub_section", "sub_category"], "")
    blob = _search_blob_sql(cols)
    medicine = " OR ".join([f"{blob} LIKE '%{w}%'" for w in ["panadol", "parol", "aspirin", "aspiriem", "ibuprofen", "ketofan", "tablet", "capsule", "syrup", "mg", "قرص", "كبسول", "شراب"]])
    cosmetic = " OR ".join([f"{blob} LIKE '%{w}%'" for w in ["cerave", "rilastil", "bioderma", "eucerin", "vichy", "cetaphil", "cream", "lotion", "xerolact", "skin", "spf", "كريم", "لوشن", "بشرة"]])
    supplement = " OR ".join([f"{blob} LIKE '%{w}%'" for w in ["vitamin", "omega", "zinc", "magnesium", "supplement", "فيتامين", "مكمل"]])
    device = " OR ".join([f"{blob} LIKE '%{w}%'" for w in ["meter", "device", "thermometer", "جهاز", "قياس"]])
    raw_l = f"LOWER(TRIM(CAST(({raw}) AS TEXT)))"
    return f"CASE WHEN {raw_l} IN ('', 'other', 'others', 'misc', 'unknown', 'عام', 'أخرى', 'اخرى') THEN CASE WHEN ({medicine}) THEN 'medicine' WHEN ({cosmetic}) THEN 'cosmetic' WHEN ({supplement}) THEN 'supplement' WHEN ({device}) THEN 'device' ELSE 'other' END ELSE {raw_l} END"


def _fts_query_from_groups(groups: List[List[str]]) -> str:
    parts: List[str] = []
    for group in groups:
        terms: List[str] = []
        for token in group:
            clean = re.sub(r"[^A-Za-z0-9_\u0600-\u06FF]+", "", token)[:32]
            if clean:
                terms.append(clean + "*")
        if terms:
            parts.append("(" + " OR ".join(terms[:8]) + ")")
    return " AND ".join(parts[:8])


def _fts_query(tokens: List[str]) -> str:
    parts: List[str] = []
    for token in tokens:
        clean = re.sub(r"[^A-Za-z0-9_\u0600-\u06FF]+", "", token)[:32]
        if clean:
            parts.append(clean + "*")
    return " AND ".join(parts)


def rebuild_products_fts() -> Tuple[bool, str]:
    try:
        with _connect_write() as conn:
            cols = _columns(conn)
            if "id" not in cols:
                return False, "products.id missing"
            use_cols = [c for c in TEXT_COLUMNS if c in cols]
            conn.execute("CREATE TABLE IF NOT EXISTS catalog_meta (key TEXT PRIMARY KEY, value TEXT)")
            conn.execute("DROP TABLE IF EXISTS products_catalog_fts")
            conn.execute("CREATE VIRTUAL TABLE products_catalog_fts USING fts5(search_text, tokenize='unicode61 remove_diacritics 2')")
            if use_cols:
                select_sql = ", ".join(["id"] + [_ident(c) for c in use_cols])
                for row in conn.execute(f"SELECT {select_sql} FROM products"):
                    parts = []
                    for c in use_cols:
                        v = row[c]
                        if v is not None:
                            parts.append(_normalize_arabic(str(v)))
                    search_text = " ".join(parts)[:4000]
                    conn.execute("INSERT INTO products_catalog_fts(rowid, search_text) VALUES(?, ?)", (int(row["id"]), search_text))
            conn.execute("INSERT OR REPLACE INTO catalog_meta(key,value) VALUES('products_fts_db_mtime', ?)", (str(_db_file().stat().st_mtime),))
            conn.execute("INSERT OR REPLACE INTO catalog_meta(key,value) VALUES('products_fts_rebuilt_at', datetime('now'))")
            conn.commit()
        _FTS_META_CACHE.update({"checked_mtime": _db_file().stat().st_mtime, "ok": True})
        return True, "rebuilt"
    except Exception as exc:
        return False, str(exc)[:240]


def _ensure_products_fts_current() -> None:
    try:
        mtime = _db_file().stat().st_mtime
        if _FTS_META_CACHE.get("ok") and _FTS_META_CACHE.get("checked_mtime") == mtime:
            return
        with sqlite3.connect(str(_db_file()), timeout=5) as conn:
            row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='catalog_meta'").fetchone()
            stored = None
            if row:
                got = conn.execute("SELECT value FROM catalog_meta WHERE key='products_fts_db_mtime'").fetchone()
                stored = got[0] if got else None
            fts = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='products_catalog_fts'").fetchone()
        if (not fts) or str(stored or "") != str(mtime):
            rebuild_products_fts()
        else:
            _FTS_META_CACHE.update({"checked_mtime": mtime, "ok": True})
    except Exception:
        pass


def _fts_available(conn: sqlite3.Connection) -> bool:
    try:
        row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='products_catalog_fts'").fetchone()
        return bool(row)
    except Exception:
        return False


def _display_product(product: Dict[str, object]) -> Dict[str, object]:
    item = dict(product)
    raw_name = item.get("display_name")
    raw_brand = item.get("brand")
    clean_name = _clean_product_name(raw_name, raw_brand, item.get("category"))
    clean_brand = _clean_brand(raw_brand, clean_name)
    clean_category = _effective_category(item.get("category"), clean_name, clean_brand)
    item["display_name"] = clean_name
    item["brand"] = clean_brand
    item["category"] = clean_category
    return item


def _name_quality_score(row: Dict[str, object]) -> int:
    name = str(row.get("display_name") or "").lower()
    brand = str(row.get("brand") or "").lower()
    category = str(row.get("category") or "").lower()
    score = 0
    if name and len(name) >= 4:
        score += 20
    if brand:
        score += 8
    if category not in {"", "other", "others", "unknown", "misc"}:
        score += 8
    if row.get("image_url"):
        score += 7
    try:
        if float(str(row.get("price") or "0").replace(",", "")) > 0:
            score += 5
    except Exception:
        pass
    if " info" in f" {name} " or name.endswith("info"):
        score -= 12
    if any(x in name for x in ["aspirin", "panadol", "parol", "cerave", "rilastil", "bioderma", "cetaphil"]):
        score += 10
    return score


def _tokens(query: str) -> List[str]:
    return _expanded_tokens(query)


def _score(row: Dict[str, object], tokens: List[str]) -> int:
    name = str(row.get("display_name") or "").lower()
    brand = str(row.get("brand") or "").lower()
    category = str(row.get("category") or "").lower()
    hay = " ".join(str(v or "") for v in row.values()).lower()
    score = 0
    for token in tokens:
        if token in name:
            score += 8
        if token in brand:
            score += 5
        if token in category:
            score += 2
        if token in hay:
            score += 1
    score += sum(1 for token in tokens if token in hay) * 4
    return score


def _merchant_settings() -> Dict[str, object]:
    try:
        return database.get_merchant_settings()
    except Exception:
        return {
            "name": os.getenv("PHARMACY_NAME", "صيدلية بدر"),
            "pharmacy_name": os.getenv("PHARMACY_NAME", "صيدلية بدر"),
            "whatsapp_number": os.getenv("BOT_WHATSAPP_NUMBER", ""),
        }


def _pharmacy_name() -> str:
    settings = _merchant_settings()
    return str(settings.get("pharmacy_name") or settings.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر"))


def _whatsapp_number() -> str:
    settings = _merchant_settings()
    raw = str(settings.get("whatsapp_number") or os.getenv("WHATSAPP_PUBLIC_NUMBER") or os.getenv("BOT_WHATSAPP_NUMBER") or os.getenv("ADMIN_NOTIFY_PHONE") or "")
    return re.sub(r"\D+", "", raw)


def _whatsapp_link(message: str) -> str:
    number = _whatsapp_number()
    if number:
        return f"https://wa.me/{number}?text={quote(message)}"
    return "/contact?whatsapp_not_configured=1"


def _public_base_url(request: Optional[Request] = None) -> str:
    raw = os.getenv("PUBLIC_BASE_URL") or os.getenv("PRICEBOT_PUBLIC_BASE_URL") or os.getenv("APP_PUBLIC_URL")
    if raw:
        return str(raw).rstrip("/")
    if request is not None:
        host = request.headers.get("host") or request.url.netloc
        # لا نثق في X-Forwarded-Host إلا إذا فُعّل صراحةً من البيئة.
        if os.getenv("PRICEBOT_TRUST_PROXY_HEADERS", "0") == "1":
            host = request.headers.get("x-forwarded-host") or host
        host = re.sub(r"[^A-Za-z0-9.:-]", "", str(host or ""))
        trusted = {h.strip().lower() for h in os.getenv("PRICEBOT_TRUSTED_HOSTS", "").split(",") if h.strip()}
        host_only = host.split(":", 1)[0].lower()
        if trusted and host_only not in trusted:
            host = next(iter(trusted))
        proto = "https" if request.url.scheme == "https" or os.getenv("PRICEBOT_FORCE_HTTPS", "1") == "1" else request.url.scheme
        return f"{proto}://{host}".rstrip("/")
    return ""


def _absolute_url(path_or_url: str, request: Optional[Request] = None) -> str:
    val = str(path_or_url or "")
    if val.startswith(("http://", "https://")):
        return val
    base = _public_base_url(request)
    if not base:
        return val
    return base + (val if val.startswith("/") else "/" + val)


def _product_path(product: Dict[str, object] | object) -> str:
    if isinstance(product, dict):
        product_id = product.get("id")
        name = str(product.get("display_name") or product.get("name") or "product")
    else:
        product_id = product
        name = "product"
    return f"/product/{product_id}-{_slugify(name)}"


def _product_url(product_id: object, request: Optional[Request] = None, product: Optional[Dict[str, object]] = None) -> str:
    return _absolute_url(_product_path(product if product is not None else product_id), request)


def _order_message(product: Dict[str, object], request: Optional[Request] = None) -> str:
    product_id = product.get("id")
    name = str(product.get("display_name") or "Product").strip()
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    parts = [
        f"السلام عليكم، أريد طلب هذا المنتج من {_pharmacy_name()}:",
        f"المنتج: {name}",
        f"السعر الظاهر: {price}",
        f"رقم المنتج: {product_id}",
    ]
    if brand:
        parts.append(f"البراند: {brand}")
    if category:
        parts.append(f"القسم: {_display_category_label(category)}")
    parts.extend([f"رابط المنتج: {_product_url(product_id, request, product)}", "يرجى تأكيد التوفر والسعر النهائي."])
    return "\n".join(parts)


def _image_src(value: object) -> str:
    src = str(value or "").strip()
    if not src:
        return ""
    # أمنياً: نمنع data: و http:// لتجنب payloads و mixed content على HTTPS.
    if src.startswith("data:") or src.startswith("http://"):
        return ""
    if src.startswith("https://"):
        return src if _valid_http_image_url(src) else ""
    if src.startswith("/"):
        return src if not src.startswith("//") else ""
    return "/static/" + src.lstrip("/")

def _display_category_label(name: str) -> str:
    raw = (name or "").strip()
    n = raw.lower()
    mapping = {
        "medicine": "أدوية", "medicines": "أدوية", "drug": "أدوية", "drugs": "أدوية",
        "cosmetic": "عناية بالبشرة", "cosmetics": "عناية بالبشرة", "skin": "عناية بالبشرة", "skincare": "عناية بالبشرة",
        "supplement": "مكملات", "supplements": "مكملات", "vitamin": "مكملات", "vitamins": "مكملات",
        "device": "أجهزة", "devices": "أجهزة", "other": "أخرى",
    }
    return mapping.get(n, raw or "قسم")


def _icon(name: str, cls: str = "icon") -> str:
    icons = {
        "search": '<svg class="{c}" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.5-3.5"></path></svg>',
        "home": '<svg class="{c}" viewBox="0 0 24 24"><path d="M3 11.5 12 4l9 7.5"></path><path d="M5 10.5V20h14v-9.5"></path><path d="M9 20v-6h6v6"></path></svg>',
        "grid": '<svg class="{c}" viewBox="0 0 24 24"><rect x="4" y="4" width="6" height="6" rx="1"></rect><rect x="14" y="4" width="6" height="6" rx="1"></rect><rect x="4" y="14" width="6" height="6" rx="1"></rect><rect x="14" y="14" width="6" height="6" rx="1"></rect></svg>',
        "category": '<svg class="{c}" viewBox="0 0 24 24"><path d="M4 5h16"></path><path d="M4 12h16"></path><path d="M4 19h16"></path><circle cx="8" cy="5" r="1.8"></circle><circle cx="16" cy="12" r="1.8"></circle><circle cx="10" cy="19" r="1.8"></circle></svg>',
        "wa": '<svg class="{c}" viewBox="0 0 24 24"><path d="M20 11.5A8 8 0 0 1 8.4 18.7L4 20l1.4-4.2A8 8 0 1 1 20 11.5Z"></path><path d="M9 8.8c.4 2.3 2 4.1 4.3 5.2l1.2-1.1 2 .8c.1 1.1-.7 2-1.8 2-3.8-.1-7.1-3.4-7.3-7.2 0-1.1.9-1.9 2-1.8l.8 2.1L9 8.8Z"></path></svg>',
        "user": '<svg class="{c}" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"></circle><path d="M4 21c1.8-4 5-6 8-6s6.2 2 8 6"></path></svg>',
        "moon": '<svg class="{c}" viewBox="0 0 24 24"><path d="M20 15.5A8.5 8.5 0 0 1 8.5 4a7 7 0 1 0 11.5 11.5Z"></path></svg>',
        "pill": '<svg class="{c}" viewBox="0 0 24 24"><path d="M10 21 21 10a5 5 0 0 0-7-7L3 14a5 5 0 0 0 7 7Z"></path><path d="m8 8 8 8"></path></svg>',
        "skin": '<svg class="{c}" viewBox="0 0 24 24"><path d="M8 21h8"></path><path d="M9 21V9a3 3 0 0 1 6 0v12"></path><path d="M10 5h4"></path><path d="M18 9c2 2 2 5 0 7"></path></svg>',
        "bottle": '<svg class="{c}" viewBox="0 0 24 24"><path d="M9 3h6v4l2 2v11H7V9l2-2V3Z"></path><path d="M9 13h6"></path></svg>',
        "device": '<svg class="{c}" viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="3"></rect><path d="M9 9h6"></path><path d="M12 13v3"></path></svg>',
        "check": '<svg class="{c}" viewBox="0 0 24 24"><path d="m5 13 4 4L19 7"></path></svg>',
        "truck": '<svg class="{c}" viewBox="0 0 24 24"><path d="M3 7h11v10H3z"></path><path d="M14 11h4l3 3v3h-7z"></path><circle cx="7" cy="19" r="2"></circle><circle cx="17" cy="19" r="2"></circle></svg>',
        "lock": '<svg class="{c}" viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"></rect><path d="M8 10V7a4 4 0 0 1 8 0v3"></path></svg>',
        "badge": '<svg class="{c}" viewBox="0 0 24 24"><circle cx="12" cy="8" r="5"></circle><path d="m8 13-2 8 6-3 6 3-2-8"></path></svg>',
        "back": '<svg class="{c}" viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"></path></svg>',
        "info": '<svg class="{c}" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M12 10v7"></path><path d="M12 7h.01"></path></svg>',
    }
    return icons.get(name, icons["grid"]).replace("{c}", cls)


def _category_icon(name: str) -> str:
    n = (name or "").lower()
    if any(x in n for x in ["cosmetic", "skin", "beauty", "تجميل", "بشرة"]):
        return _icon("skin")
    if any(x in n for x in ["medicine", "drug", "دواء", "ادوية", "أدوية"]):
        return _icon("pill")
    if any(x in n for x in ["supplement", "vitamin", "فيتامين", "مكمل"]):
        return _icon("bottle")
    if any(x in n for x in ["device", "meter", "جهاز", "أجهزة"]):
        return _icon("device")
    return _icon("grid")



def _categories() -> List[Dict[str, object]]:
    now = time.time()
    cached = _CATEGORY_CACHE.get("items") or []
    if cached and now - float(_CATEGORY_CACHE.get("ts") or 0) < CACHE_TTL_SECONDS:
        return cached  # type: ignore[return-value]
    try:
        with _connect() as conn:
            cols = _columns(conn)
            if "id" not in cols:
                return []
            cat_expr = _effective_category_sql(cols)
            rows = conn.execute(
                f"SELECT {cat_expr} AS category_key, COUNT(*) AS c FROM products GROUP BY category_key ORDER BY c DESC LIMIT 80"
            ).fetchall()
            result = [{"name": str(r["category_key"] or "other"), "count": int(r["c"] or 0)} for r in rows]
    except Exception:
        result = []
    _CATEGORY_CACHE["ts"] = now
    _CATEGORY_CACHE["items"] = result
    return result



def _brand_options(limit: int = 40) -> List[str]:
    now = time.time()
    cached = _BRAND_CACHE.get("items") or []
    if cached and now - float(_BRAND_CACHE.get("ts") or 0) < CACHE_TTL_SECONDS:
        return cached[:limit]  # type: ignore[index]
    try:
        with _connect() as conn:
            cols = _columns(conn)
            brand_col = _first_existing(cols, ["brand", "company", "product_family"])
            if not brand_col:
                return []
            rows = conn.execute(
                f"SELECT {_ident(brand_col)} AS brand, COUNT(*) AS c FROM products WHERE {_ident(brand_col)} IS NOT NULL AND TRIM(CAST({_ident(brand_col)} AS TEXT)) != '' GROUP BY {_ident(brand_col)} ORDER BY c DESC LIMIT ?",
                [limit * 2],
            ).fetchall()
            seen = set()
            brands = []
            for r in rows:
                b = _clean_brand(r["brand"])
                key = b.lower()
                if b and key not in seen:
                    seen.add(key)
                    brands.append(b)
                if len(brands) >= limit:
                    break
            _BRAND_CACHE["ts"] = now
            _BRAND_CACHE["items"] = brands
            return brands
    except Exception:
        return []


def _clean_price_float(value: object) -> Optional[float]:
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    raw = raw.replace("٫", ".").replace("،", ",")
    raw = re.sub(r"(?i)\b(lyd|ld|د\.?ل|دينار|ل\.د)\b", "", raw)
    raw = re.sub(r"[^0-9.,]", "", raw).strip(".,")
    if not raw:
        return None
    if "," in raw and "." in raw:
        last_comma = raw.rfind(",")
        last_dot = raw.rfind(".")
        dec = "," if last_comma > last_dot else "."
        thou = "." if dec == "," else ","
        raw = raw.replace(thou, "").replace(dec, ".")
    elif "," in raw:
        parts = raw.split(",")
        if len(parts) == 2 and 1 <= len(parts[1]) <= 2:
            raw = parts[0] + "." + parts[1]
        else:
            raw = raw.replace(",", "")
    elif "." in raw:
        parts = raw.split(".")
        if len(parts) > 2:
            raw = "".join(parts[:-1]) + "." + parts[-1] if 1 <= len(parts[-1]) <= 2 else "".join(parts)
    try:
        val = float(raw)
        if val <= 0:
            return None
        return val
    except Exception:
        return None


def _price_sql_expr(cols: set[str]) -> str:
    return 'catalog_price_number("price")' if "price" in cols else "NULL"


def _normalize_arabic(text: str) -> str:
    text = re.sub(r"[\u064B-\u065F\u0670]", "", text or "")
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ى", "ي").replace("ة", "ه")
    text = re.sub(r"\s+", " ", text)
    return text.strip().lower()


def _search_token_groups(query: str) -> List[List[str]]:
    q = _normalize_arabic(query)
    raw_tokens = [t for t in re.findall(r"[A-Za-z0-9_\u0600-\u06FF%+.-]+", q) if len(t) >= 2][:8]
    groups: List[List[str]] = []
    full_syns = SEARCH_SYNONYMS.get(q, [])
    for token in raw_tokens:
        vals = [token]
        vals.extend(SEARCH_SYNONYMS.get(token, []))
        vals.extend(full_syns if len(raw_tokens) <= 2 else [])
        if token in {"سيرافي", "سرافي"}:
            vals.extend(["cerave", "cera ve"])
        if token in {"بنادول", "بندول"}:
            vals.extend(["panadol", "paracetamol"])
        clean_vals: List[str] = []
        seen = set()
        for v in vals:
            vv = _normalize_arabic(str(v))
            if vv and vv not in seen:
                seen.add(vv)
                clean_vals.append(vv)
        if clean_vals:
            groups.append(clean_vals[:8])
    return groups


def _expanded_tokens(query: str) -> List[str]:
    out: List[str] = []
    seen = set()
    for group in _search_token_groups(query):
        for token in group:
            if token not in seen:
                seen.add(token)
                out.append(token)
    return out[:24]


def _sort_products(products: List[Dict[str, object]], tokens: List[str], sort: str) -> List[Dict[str, object]]:
    sort = (sort or "relevance").strip()
    if sort == "price_asc":
        return sorted(products, key=lambda row: (_price_number(row), -_name_quality_score(row), str(row.get("display_name") or "")))
    if sort == "price_desc":
        return sorted(products, key=lambda row: (-_price_number(row) if _price_number(row) < 10**12 else 10**12, -_name_quality_score(row), str(row.get("display_name") or "")))
    if sort == "name":
        return sorted(products, key=lambda row: (str(row.get("display_name") or "").lower(), -_name_quality_score(row)))
    if sort == "newest":
        return sorted(products, key=lambda row: -int(row.get("id") or 0))
    if tokens:
        return sorted(products, key=lambda row: (-_score(row, tokens), -_name_quality_score(row), str(row.get("display_name") or "")))
    return sorted(products, key=lambda row: (-_name_quality_score(row), str(row.get("display_name") or "")))



def _query_products(q: str = "", category: str = "", page: int = 1, sort: str = "available", brand: str = "", availability: str = "", price_min: str = "", price_max: str = "") -> Tuple[List[Dict[str, object]], int]:
    q = (q or "").strip()
    category = (category or "").strip()
    brand = (brand or "").strip()
    availability = (availability or "").strip()
    page = min(max(int(page or 1), 1), MAX_PAGE)
    groups = _search_token_groups(q)
    if q and not groups:
        return [], 0
    offset = (page - 1) * PAGE_SIZE
    try:
        if q:
            _ensure_products_fts_current()
        with _connect() as conn:
            cols = _columns(conn)
            if "id" not in cols:
                return [], 0
            select_part, select_params = _select_sql(cols)
            where = ["1=1"]
            where_params: List[object] = []
            from_sql = "products"
            fts_q = _fts_query_from_groups(groups)
            use_fts = bool(groups and fts_q and _fts_available(conn))
            if use_fts:
                from_sql = "products JOIN products_catalog_fts ON products_catalog_fts.rowid = products.id"
                where.append("products_catalog_fts MATCH ?")
                where_params.append(fts_q)
            cat_expr = _effective_category_sql(cols)
            if category:
                where.append(f"({cat_expr}) = ?")
                where_params.append(category.lower())
            brand_col = _first_existing(cols, ["brand", "company", "product_family"])
            if brand and brand_col:
                brand_vals = [brand.lower()] + SEARCH_SYNONYMS.get(_normalize_arabic(brand), [])
                brand_group = []
                for bv in brand_vals[:6]:
                    brand_group.append(f"LOWER(CAST({_ident(brand_col)} AS TEXT)) LIKE ?")
                    where_params.append(f"%{_normalize_arabic(str(bv))}%")
                where.append("(" + " OR ".join(brand_group) + ")")
            av_expr = _availability_sql_expr(cols)
            av_cond = _availability_filter_condition(cols, availability)
            if av_cond != "1=1":
                where.append(av_cond)
            pmin = _clean_price_float(price_min)
            pmax = _clean_price_float(price_max)
            if pmin is not None and pmax is not None and pmin > pmax:
                pmin, pmax = pmax, pmin
            price_expr = _price_sql_expr(cols)
            if "price" in cols and pmin is not None:
                where.append(f"{price_expr} IS NOT NULL AND {price_expr} >= ?")
                where_params.append(pmin)
            if "price" in cols and pmax is not None:
                where.append(f"{price_expr} IS NOT NULL AND {price_expr} <= ?")
                where_params.append(pmax)
            search_cols = [col for col in TEXT_COLUMNS if col in cols]
            order_params: List[object] = []
            relevance_score = "0"
            if groups and not use_fts and search_cols:
                score_parts: List[str] = []
                name_col = _first_existing(cols, ["canonical_display_name", "name", "original_name"])
                for group in groups:
                    group_parts: List[str] = []
                    for token in group:
                        like = f"%{token}%"
                        for col in search_cols:
                            group_parts.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                            where_params.append(like)
                        if name_col:
                            score_parts.append(f"CASE WHEN LOWER(CAST({_ident(name_col)} AS TEXT)) LIKE ? THEN 80 ELSE 0 END")
                            order_params.append(like)
                        if brand_col:
                            score_parts.append(f"CASE WHEN LOWER(CAST({_ident(brand_col)} AS TEXT)) LIKE ? THEN 35 ELSE 0 END")
                            order_params.append(like)
                    where.append("(" + " OR ".join(group_parts) + ")")
                relevance_score = " + ".join(score_parts) if score_parts else "0"
            where_sql = " AND ".join(f"({w})" for w in where)
            image_expr = _coalesce(cols, IMAGE_COLUMNS, "")
            availability_rank = f"CASE WHEN ({av_expr})=1 THEN 2 WHEN ({av_expr}) IS NULL THEN 1 ELSE 0 END"
            image_rank = f"CASE WHEN NULLIF(TRIM(CAST(({image_expr}) AS TEXT)), '') IS NOT NULL THEN 1 ELSE 0 END"
            price_rank = f"CASE WHEN {price_expr} IS NOT NULL THEN 1 ELSE 0 END" if "price" in cols else "0"
            order_sql = f"{availability_rank} DESC, {image_rank} DESC, id DESC"
            if sort in {"relevance", "available", ""} and q:
                if use_fts:
                    order_sql = f"{availability_rank} DESC, {image_rank} DESC, {price_rank} DESC, bm25(products_catalog_fts) ASC, products.id DESC"
                else:
                    order_sql = f"{availability_rank} DESC, ({relevance_score}) DESC, {image_rank} DESC, {price_rank} DESC, id DESC"
            elif sort in {"available", ""}:
                order_sql = f"{availability_rank} DESC, {image_rank} DESC, id DESC"
            elif sort == "price_asc" and "price" in cols:
                order_sql = f"CASE WHEN {price_expr} IS NULL THEN 1 ELSE 0 END, {price_expr} ASC, {availability_rank} DESC, id DESC"
            elif sort == "price_desc" and "price" in cols:
                order_sql = f"CASE WHEN {price_expr} IS NULL THEN 1 ELSE 0 END, {price_expr} DESC, {availability_rank} DESC, id DESC"
            elif sort == "name":
                name_col = _first_existing(cols, ["canonical_display_name", "name", "original_name"])
                if name_col:
                    order_sql = f"LOWER(CAST({_ident(name_col)} AS TEXT)) ASC, {availability_rank} DESC, id DESC"
            elif sort == "newest":
                upd = _first_existing(cols, ["updated_at", "last_updated", "created_at"])
                order_sql = f"{_ident(upd)} DESC, id DESC" if upd else "id DESC"
            total = int(conn.execute(f"SELECT COUNT(*) FROM {from_sql} WHERE {where_sql}", where_params).fetchone()[0] or 0)
            rows = conn.execute(
                f"SELECT {select_part} FROM {from_sql} WHERE {where_sql} ORDER BY {order_sql} LIMIT ? OFFSET ?",
                list(select_params) + where_params + order_params + [PAGE_SIZE, offset],
            ).fetchall()
            return [_display_product(dict(row)) for row in rows], total
    except Exception:
        return _query_products_like_fallback(q, category, page, sort, brand, availability, price_min, price_max)


def _query_products_like_fallback(q: str = "", category: str = "", page: int = 1, sort: str = "available", brand: str = "", availability: str = "", price_min: str = "", price_max: str = "") -> Tuple[List[Dict[str, object]], int]:
    try:
        with _connect() as conn:
            cols = _columns(conn)
            if "id" not in cols:
                return [], 0
            select_part, select_params = _select_sql(cols)
            where = ["1=1"]
            params: List[object] = []
            cat_expr = _effective_category_sql(cols)
            if category:
                where.append(f"({cat_expr}) = ?")
                params.append(category.lower())
            if availability:
                where.append(_availability_filter_condition(cols, availability))
            search_cols = [col for col in TEXT_COLUMNS if col in cols]
            for group in _search_token_groups(q):
                group_sql = []
                for token in group:
                    like = f"%{token}%"
                    for col in search_cols:
                        group_sql.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                        params.append(like)
                if group_sql:
                    where.append("(" + " OR ".join(group_sql) + ")")
            pmin = _clean_price_float(price_min)
            pmax = _clean_price_float(price_max)
            if pmin is not None and pmax is not None and pmin > pmax:
                pmin, pmax = pmax, pmin
            price_expr = _price_sql_expr(cols)
            if "price" in cols and pmin is not None:
                where.append(f"{price_expr} IS NOT NULL AND {price_expr} >= ?")
                params.append(pmin)
            if "price" in cols and pmax is not None:
                where.append(f"{price_expr} IS NOT NULL AND {price_expr} <= ?")
                params.append(pmax)
            av_expr = _availability_sql_expr(cols)
            order = f"CASE WHEN ({av_expr})=1 THEN 2 WHEN ({av_expr}) IS NULL THEN 1 ELSE 0 END DESC, id DESC"
            offset = (min(max(int(page or 1), 1), MAX_PAGE)-1)*PAGE_SIZE
            where_sql = " AND ".join(f"({w})" for w in where)
            total = int(conn.execute(f"SELECT COUNT(*) FROM products WHERE {where_sql}", params).fetchone()[0] or 0)
            rows = conn.execute(f"SELECT {select_part} FROM products WHERE {where_sql} ORDER BY {order} LIMIT ? OFFSET ?", list(select_params)+params+[PAGE_SIZE, offset]).fetchall()
            return [_display_product(dict(r)) for r in rows], total
    except Exception:
        return [], 0


def _get_product(product_id: int) -> Optional[Dict[str, object]]:
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return None
        select_part, params = _select_sql(cols)
        row = conn.execute(
            f"SELECT {select_part} FROM products WHERE id=? LIMIT 1",
            params + [int(product_id)],
        ).fetchone()
        return _display_product(dict(row)) if row else None


def _similar_products(product: Dict[str, object], limit: int = 4) -> List[Dict[str, object]]:
    pid = int(product.get("id") or 0)
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    items: List[Dict[str, object]] = []
    if brand:
        items, _ = _query_products(brand=brand, page=1, sort="relevance")
    if len(items) < limit and category:
        more, _ = _query_products(category=category, page=1, sort="relevance")
        items.extend(more)
    seen = {pid}
    out: List[Dict[str, object]] = []
    for p in items:
        item_id = int(p.get("id") or 0)
        if item_id and item_id not in seen:
            seen.add(item_id)
            out.append(p)
        if len(out) >= limit:
            break
    return out

def _search_form(q: str = "", category: str = "", compact: bool = False, sort: str = "available", brand: str = "", availability: str = "", price_min: str = "", price_max: str = "") -> str:
    options = ['<option value="">كل الأقسام</option>']
    for item in _categories():
        name = str(item.get("name") or "")
        selected = " selected" if name == category else ""
        options.append(f'<option value="{_h(name)}"{selected}>{_h(_display_category_label(name))} ({_h(item.get("count"))})</option>')
    sort_options = [("available", "المتوفر أولاً"), ("relevance", "الأقرب"), ("price_asc", "الأرخص"), ("price_desc", "الأغلى"), ("newest", "الأحدث"), ("name", "الأبجدي")]
    sort_html = "".join(f'<option value="{_h(k)}"{" selected" if k == sort else ""}>{_h(v)}</option>' for k, v in sort_options)
    av_options = [("", "كل حالات التوفر"), ("available", "متوفر"), ("unavailable", "نفد المخزون"), ("unknown", "يُؤكد التوفر")]
    av_html = "".join(f'<option value="{_h(k)}"{" selected" if k == availability else ""}>{_h(v)}</option>' for k, v in av_options)
    brand_options = ['<option value="">كل البراندات</option>']
    for b in _brand_options():
        brand_options.append(f'<option value="{_h(b)}"{" selected" if b == brand else ""}>{_h(b)}</option>')
    cls = "search-panel compact" if compact else "search-panel"
    placeholder = "ابحث عن دواء أو منتج أو باركود" if compact else "ابحث عن المنتجات... Panadol / CeraVe / barcode"
    advanced = "" if compact else (
        f'<label class="sr-only" for="catalog-brand">البراند</label><select id="catalog-brand" name="brand">{"".join(brand_options)}</select>'
        f'<label class="sr-only" for="catalog-availability">التوفر</label><select id="catalog-availability" name="availability">{av_html}</select>'
        f'<label class="sr-only" for="catalog-price-min">أقل سعر</label><input id="catalog-price-min" class="price-filter" name="price_min" value="{_h(price_min)}" inputmode="decimal" placeholder="أقل سعر">'
        f'<label class="sr-only" for="catalog-price-max">أعلى سعر</label><input id="catalog-price-max" class="price-filter" name="price_max" value="{_h(price_max)}" inputmode="decimal" placeholder="أعلى سعر">'
        '<a class="clear-filters" href="/products">مسح الفلاتر</a>'
    )
    return f"""
    <section class="{cls}">
      <form class="search" action="/products" method="get" data-search-form>
        <div class="search-input-wrap"><label class="sr-only" for="catalog-q">بحث</label><span class="search-icon">{_icon('search')}</span><input id="catalog-q" name="q" value="{_h(q)}" placeholder="{_h(placeholder)}" autocomplete="off" dir="auto"></div>
        <label class="sr-only" for="catalog-category">القسم</label><select id="catalog-category" name="category">{"".join(options)}</select>
        <label class="sr-only" for="catalog-sort">الترتيب</label><select id="catalog-sort" class="sort-select" name="sort" data-autosubmit>{sort_html}</select>
        {advanced}
        <button type="submit">بحث</button>
      </form>
    </section>
    """

def _category_tiles(limit: int = 5) -> str:
    cats = _categories()[:max(limit - 1, 0)]
    tiles = [f'<a class="cat-pill" href="/products"><span class="cat-line-icon">{_icon("grid")}</span><strong>الكل</strong></a>']
    for item in cats:
        name = str(item.get("name") or "")
        href = "/products?" + urlencode({"category": name})
        tiles.append(f"""
        <a class="cat-pill" href="{_h(href)}"><span class="cat-line-icon">{_category_icon(name)}</span><strong dir="auto">{_h(_display_category_label(name))}</strong></a>
        """)
    return '<section class="category-strip" aria-label="تصنيفات المنتجات">' + ''.join(tiles) + '</section>'


def _category_chips(active: str = "") -> str:
    items = _categories()[:16]
    if not items:
        return ""
    all_cls = "chip active" if not active else "chip"
    chips = [f'<a class="{all_cls}" href="/products">الكل</a>']
    for item in items:
        name = str(item.get("name") or "")
        cls = "chip active" if name == active else "chip"
        href = "/products?" + urlencode({"category": name})
        chips.append(f'<a class="{cls}" href="{_h(href)}" dir="auto">{_h(_display_category_label(name))}</a>')
    return '<div class="chips" aria-label="الأقسام">' + ''.join(chips) + '</div>'





def _slugify(text: str) -> str:
    text = (text or "").strip().lower()
    text = re.sub(r"[^a-z0-9\u0600-\u06FF]+", "-", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text[:80] or "product"
def _product_card(product: Dict[str, object], mode: str = "list") -> str:
    product_id = product.get("id")
    product = _display_product(product)
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    availability_text, availability_cls, _ = _availability_label(product.get("available_value"))
    img = _image_src(product.get("image_url"))
    if img:
        img_html = f'<img src="{_h(img)}" alt="{_h(name)}" loading="lazy" decoding="async" width="220" height="160" sizes="(max-width: 640px) 45vw, 220px">'
    else:
        img_html = '<div class="no-img"><span>Rx</span><small>صورة المنتج قريباً</small></div>'
    cat_label = _display_category_label(category) if category else "منتج"
    brand_html = f'<span dir="auto">{_h(brand)}</span>' if brand else f'<span>{_h(_pharmacy_name())}</span>'
    cls = "product-card tile-card" if mode == "tile" else "product-card"
    order_btn = f'<a class="wa-order" href="/order/{_h(product_id)}" target="_blank" rel="noopener">{_icon("wa")} اطلب</a>' if availability_cls == "available" else f'<a class="wa-order muted" href="/contact">استفسر عن التوفر</a>'
    return f"""
    <article class="{cls}" data-product-id="{_h(product_id)}">
      <div class="card-top"><span class="available-badge {availability_cls}">{_h(availability_text)}</span><span class="product-code">#{_h(product_id)}</span></div>
      <a class="product-image" href="{_h(_product_path(product))}" aria-label="تفاصيل {_h(name)}">{img_html}<div class="no-img fallback"><span>Rx</span><small>الصورة غير متاحة</small></div></a>
      <div class="product-info">
        <div class="product-meta"><span>{_h(cat_label)}</span>{brand_html}</div>
        <a class="product-name" href="{_h(_product_path(product))}" dir="auto">{_h(name)}</a>
        <div class="product-bottom"><div class="product-price { 'price-missing' if price.startswith('السعر') else ''}">{_h(price)}</div></div>
        <div class="product-actions">
          {order_btn}
          <a class="details-link" href="{_h(_product_path(product))}">تفاصيل</a>
        </div>
      </div>
    </article>
    """


def _page_url(page: int, q: str = "", category: str = "", sort: str = "available", brand: str = "", availability: str = "", price_min: str = "", price_max: str = "") -> str:
    params = {"page": max(1, page)}
    for k, v in {"q": q, "category": category, "brand": brand, "availability": availability, "price_min": price_min, "price_max": price_max}.items():
        if v:
            params[k] = v
    if sort and sort != "available":
        params["sort"] = sort
    return "/products?" + urlencode(params)


def _pagination(page: int, page_count: int, q: str = "", category: str = "", sort: str = "relevance", brand: str = "", availability: str = "", price_min: str = "", price_max: str = "") -> str:
    if page_count <= 1:
        return ""
    page = max(1, min(page, page_count))
    nums = {1, page_count, page, page - 1, page + 1}
    if page <= 3:
        nums.update([2, 3])
    if page >= page_count - 2:
        nums.update([page_count - 1, page_count - 2])
    nums = sorted(n for n in nums if 1 <= n <= page_count)
    parts: List[str] = []
    if page > 1:
        parts.append(f'<a class="page-btn" rel="prev" href="{_h(_page_url(page - 1, q, category, sort, brand, availability, price_min, price_max))}" aria-label="السابق">{_icon("back")}</a>')
    last = 0
    for n in nums:
        if last and n - last > 1:
            parts.append('<span class="page-summary">…</span>')
        cls = "page-btn active" if n == page else "page-btn"
        aria = ' aria-current="page"' if n == page else ""
        parts.append(f'<a class="{cls}"{aria} href="{_h(_page_url(n, q, category, sort, brand, availability, price_min, price_max))}">{n}</a>')
        last = n
    if page < page_count:
        parts.append(f'<a class="page-btn" rel="next" href="{_h(_page_url(page + 1, q, category, sort, brand, availability, price_min, price_max))}" aria-label="التالي">{_icon("back")}</a>')
    parts.append(f'<span class="page-summary">الصفحة {page} من {page_count}</span>')
    return '<nav class="pagination" aria-label="ترقيم الصفحات">' + ''.join(parts) + '</nav>'

def _suggestion_links(q: str) -> str:
    popular = ["Panadol", "CeraVe", "Parol", "Aspirin", "Rilastil", "Bioderma"]
    low = (q or "").lower()
    if "asp" in low:
        popular.insert(0, "Aspirin")
    if "cera" in low or "سيرا" in low:
        popular.insert(0, "CeraVe")
    if "pan" in low:
        popular.insert(0, "Panadol")
    seen: set[str] = set()
    links: List[str] = []
    for item in popular:
        if item.lower() in seen:
            continue
        seen.add(item.lower())
        links.append(f'<a href="/products?q={_h(quote(item))}">{_h(item)}</a>')
    return '<div class="suggestions">' + ''.join(links) + '</div>'


def _products_section(q: str = "", category: str = "", page: int = 1, sort: str = "available", brand: str = "", availability: str = "", price_min: str = "", price_max: str = "") -> str:
    products, total = _query_products(q=q, category=category, page=page, sort=sort, brand=brand, availability=availability, price_min=price_min, price_max=price_max)
    page_count = max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    cards = "".join(_product_card(p) for p in products)
    if not cards:
        cards = (
            '<div class="no-results"><strong>لم نجد منتجات مطابقة</strong>',
            '<span>جرّب اسم البراند فقط، أو كلمة أبسط من اسم المنتج، أو امسح الفلاتر.</span>',
            _suggestion_links(q),
            '<div class="detail-actions"><a class="btn" href="/products">عرض كل المنتجات</a><a class="btn secondary" href="/contact">تواصل معنا</a></div></div>'
        )
        cards = "".join(cards)
    title = f'نتائج البحث عن: <span dir="auto">{_h(q)}</span>' if q else "كل المنتجات"
    active_filters = []
    if category: active_filters.append("القسم: " + _display_category_label(category))
    if brand: active_filters.append("البراند: " + brand)
    if availability: active_filters.append("التوفر: " + availability)
    if price_min or price_max: active_filters.append("السعر: " + (price_min or "0") + " - " + (price_max or "∞"))
    filters_html = '<div class="active-filters">' + ''.join(f'<span>{_h(x)}</span>' for x in active_filters) + '</div>' if active_filters else ''
    return f"""
    {_search_form(q=q, category=category, sort=sort, brand=brand, availability=availability, price_min=price_min, price_max=price_max)}
    {_category_chips(category)}
    {filters_html}
    <div class="section-head"><div><h2>{title}</h2><p>عدد النتائج: {_h(total)} | الصفحة {_h(min(page, page_count))} من {_h(page_count)} | آخر تحديث للمخزون: {_h(_stock_updated_at())}</p></div></div>
    <div class="grid product-list" data-results-count="{_h(total)}">{cards}</div>
    {_pagination(page, page_count, q, category, sort, brand, availability, price_min, price_max)}
    """

def _bottom_nav(active: str = "home") -> str:
    def item(key: str, href: str, icon: str, label: str, external: bool = False) -> str:
        cls = "active" if active == key else ""
        target = ' target="_blank" rel="noopener"' if external else ""
        aria = ' aria-current="page"' if active == key else ""
        return f'<a class="{cls}" href="{_h(href)}"{target}{aria}><span class="nav-icon">{_icon(icon)}</span><small>{label}</small></a>'
    return '<nav class="bottom-nav" aria-label="التنقل السفلي">' + ''.join([
        item("home", "/catalog", "home", "الرئيسية"),
        item("products", "/products", "grid", "المنتجات"),
        item("categories", "/categories", "category", "التصنيفات"),
        item("whatsapp", _whatsapp_link(f"السلام عليكم، أريد الاستفسار عن منتجات {_pharmacy_name()}."), "wa", "واتساب", True),
        item("contact", "/contact", "user", "تواصل"),
    ]) + '</nav>'


def _meta_description(title: str) -> str:
    return f"{title} من {_pharmacy_name()}. ابحث عن المنتجات، راجع السعر والتوفر، واطلب بسهولة عبر واتساب."


def _json_script(data: Dict[str, object]) -> str:
    return '<script type="application/ld+json" nonce="__CSP_NONCE__">' + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + '</script>'


def _shell(
    request: Request,
    title: str,
    body: str,
    active: str = "home",
    description: str = "",
    canonical_path: str = "",
    og_image: str = "",
    json_ld: str = "",
    robots: str = "index,follow",
    status_code: int = 200,
) -> HTMLResponse:
    pharmacy = _pharmacy_name()
    nonce = secrets.token_urlsafe(18)
    desc = description or _meta_description(title)
    canonical = _absolute_url(canonical_path or request.url.path, request)
    image = _absolute_url(og_image or f"/badr-logo.png?v={BRAND_ASSET_VERSION}", request)
    page_title = f"{title} | {pharmacy}"
    org_json = _json_script({
        "@context": "https://schema.org",
        "@type": "Pharmacy",
        "name": pharmacy,
        "url": _absolute_url("/catalog", request),
        "logo": _absolute_url(f"/badr-logo.png?v={BRAND_ASSET_VERSION}", request),
        "potentialAction": {"@type": "SearchAction", "target": _absolute_url("/products?q={search_term_string}", request), "query-input": "required name=search_term_string"},
    })
    doc = f"""<!doctype html>
<html lang="ar" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_h(page_title)}</title>
<meta name="description" content="{_h(desc)}"><meta name="robots" content="{_h(robots)}">
<link rel="canonical" href="{_h(canonical)}"><link rel="icon" href="/favicon.ico?v={BRAND_ASSET_VERSION}"><link rel="manifest" href="/manifest.webmanifest?v={BRAND_ASSET_VERSION}">
<meta property="og:type" content="website"><meta property="og:locale" content="ar_AR"><meta property="og:site_name" content="{_h(pharmacy)}"><meta property="og:title" content="{_h(page_title)}"><meta property="og:description" content="{_h(desc)}"><meta property="og:url" content="{_h(canonical)}"><meta property="og:image" content="{_h(image)}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{_h(page_title)}"><meta name="twitter:description" content="{_h(desc)}"><meta name="twitter:image" content="{_h(image)}">
<link rel="stylesheet" href="/catalog-assets/app.css?v={BRAND_ASSET_VERSION}">
{org_json}{json_ld}
</head><body>
<header class="app-header"><div class="app-header-inner"><a class="top-icon" href="/categories" aria-label="التصنيفات"><span class="menu-lines"><i></i><i></i><i></i></span></a><a class="brand-link" href="/catalog" aria-label="{_h(pharmacy)}"><img src="/badr-logo.png?v={BRAND_ASSET_VERSION}" alt="{_h(pharmacy)}" width="230" height="142"></a><div class="top-actions"><button class="top-icon theme-toggle" type="button" data-theme-toggle aria-label="تغيير الوضع الليلي" aria-pressed="false">{_icon('moon')}</button><a class="top-icon" href="{_h(_whatsapp_link(f'السلام عليكم، أريد الاستفسار عن منتجات {pharmacy}.'))}" target="_blank" rel="noopener" aria-label="واتساب">{_icon('wa')}</a></div></div></header>
<main class="wrap">{body}<div class="footer">الأسعار والتوفر حسب آخر تحديث من الصيدلية، ويتم تأكيد الطلب عبر واتساب قبل التجهيز.</div></main>{_bottom_nav(active)}<div class="loading-overlay" data-loading role="status" aria-live="polite"><span class="loader"></span> جارٍ التحميل...</div><script src="/catalog-assets/app.js?v={BRAND_ASSET_VERSION}" nonce="{nonce}" defer></script></body></html>"""
    doc = doc.replace("__CSP_NONCE__", nonce)
    return _html_response(doc, status_code=status_code, csp_nonce=nonce)


def _merchant_auth_response(request: Request):
    try:
        from merchant import _require_auth  # type: ignore
    except Exception:
        return _html_response('<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><body><h1>غير مصرح</h1><p>تعذر تحميل نظام تسجيل دخول التاجر. الصفحة مغلقة حمايةً للبيانات.</p></body></html>', status_code=403)
    try:
        return _require_auth(request)
    except Exception:
        return _html_response('<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><body><h1>غير مصرح</h1><p>فشل التحقق من الدخول.</p></body></html>', status_code=403)

def _ensure_analytics_table() -> None:
    try:
        with sqlite3.connect(str(_analytics_db_file()), timeout=5) as conn:
            conn.row_factory = sqlite3.Row
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS catalog_analytics_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    path TEXT,
                    label TEXT,
                    meta_json TEXT,
                    referrer TEXT,
                    user_agent TEXT,
                    created_at TEXT NOT NULL DEFAULT (datetime('now'))
                )
                """
            )
            conn.commit()
    except Exception:
        pass


def _write_event(event_type: str, path: str = "", label: str = "", meta: Optional[Dict[str, object]] = None, request: Optional[Request] = None) -> None:
    try:
        _ensure_analytics_table()
        with sqlite3.connect(str(_analytics_db_file()), timeout=5) as conn:
            conn.execute(
                "INSERT INTO catalog_analytics_events(event_type,path,label,meta_json,referrer,user_agent) VALUES(?,?,?,?,?,?)",
                (
                    str(event_type or "event")[:80],
                    str(path or "")[:500],
                    str(label or "")[:240],
                    json.dumps(meta or {}, ensure_ascii=False)[:1000],
                    "",
                    "",
                ),
            )
            conn.commit()
    except Exception:
        pass


@router.get("/catalog-assets/app.css")
def catalog_css_asset():
    if CSS_FILE.exists():
        return FileResponse(str(CSS_FILE), media_type="text/css; charset=utf-8", headers={**_security_headers(), "Cache-Control": "public, max-age=31536000, immutable"})
    return _plain_response("catalog css not found", status_code=404)


@router.get("/catalog-assets/app.js")
def catalog_js_asset():
    if JS_FILE.exists():
        return FileResponse(str(JS_FILE), media_type="application/javascript; charset=utf-8", headers={**_security_headers(), "Cache-Control": "public, max-age=31536000, immutable"})
    return _plain_response("catalog js not found", status_code=404)


@router.get("/badr-logo.png")
def badr_logo_asset():
    if BRAND_LOGO_FILE.exists():
        return FileResponse(str(BRAND_LOGO_FILE), media_type="image/png", headers={**_security_headers(), "Cache-Control": "public, max-age=31536000, immutable"})
    return _plain_response("logo not found", status_code=404)


@router.get("/favicon.ico")
def favicon_asset():
    if FAVICON_FILE.exists():
        return FileResponse(str(FAVICON_FILE), media_type="image/x-icon", headers={**_security_headers(), "Cache-Control": "public, max-age=31536000, immutable"})
    return _plain_response("favicon not found", status_code=404)


@router.get("/catalog-assets/icon-192.png")
def icon_192_asset():
    f = STATIC_DIR / "icon-192.png"
    if f.exists():
        return FileResponse(str(f), media_type="image/png", headers={**_security_headers(), "Cache-Control": "public, max-age=31536000, immutable"})
    return _plain_response("icon not found", status_code=404)


@router.get("/catalog-assets/icon-512.png")
def icon_512_asset():
    f = STATIC_DIR / "icon-512.png"
    if f.exists():
        return FileResponse(str(f), media_type="image/png", headers={**_security_headers(), "Cache-Control": "public, max-age=31536000, immutable"})
    return _plain_response("icon not found", status_code=404)


@router.get("/catalog-health")
def catalog_health(request: Request):
    client = (request.client.host if request.client else "") or ""
    if client not in {"127.0.0.1", "::1", "localhost"}:
        return _json_response({"ok": False}, status_code=404)
    return _json_response({"ok": True, "service": "pricebot-catalog"})


def _same_origin_request(request: Request) -> bool:
    host = (request.headers.get("host") or request.url.netloc or "").split(":", 1)[0].lower()
    for header in ("origin", "referer"):
        raw = request.headers.get(header) or ""
        if raw:
            try:
                parsed = urlparse(raw)
                return (parsed.hostname or "").lower() == host
            except Exception:
                return False
    return False


@router.post("/catalog-event")
async def catalog_event(request: Request):
    if not _same_origin_request(request):
        return _json_response({"ok": False}, status_code=403)
    client = (request.client.host if request.client else "unknown") or "unknown"
    now = time.time()
    # تنظيف دوري حتى لا تكبر الذاكرة مع IPs قديمة.
    for key in list(_EVENT_BUCKETS.keys())[:200]:
        bucket = _EVENT_BUCKETS[key]
        while bucket and now - bucket[0] > 90:
            bucket.popleft()
        if not bucket:
            _EVENT_BUCKETS.pop(key, None)
    bucket = _EVENT_BUCKETS[client]
    while bucket and now - bucket[0] > 60:
        bucket.popleft()
    if len(bucket) >= ANALYTICS_RATE_LIMIT_PER_MINUTE:
        return _json_response({"ok": False, "rate_limited": True}, status_code=429)
    bucket.append(now)
    if int(request.headers.get("content-length") or 0) > 4096:
        return _json_response({"ok": False}, status_code=413)
    try:
        payload = await request.json()
    except Exception:
        return _json_response({"ok": False}, status_code=400)
    event_type = str(payload.get("event") or payload.get("event_type") or "event")[:80]
    if event_type not in {"page_view", "search_submit", "product_view", "order_or_whatsapp_click", "share", "copy_link", "filter_change", "zero_results"}:
        return _json_response({"ok": False}, status_code=400)
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    path = str(payload.get("path") or "")[:300]
    label = str(data.get("q") or data.get("label") or payload.get("title") or "")[:180]
    _write_event(event_type, path, label, data, request)
    return _json_response({"ok": True})


@router.get("/robots.txt")
def robots_txt(request: Request):
    base = _public_base_url(request)
    text = "User-agent: *\nDisallow: /merchant\nDisallow: /catalog-event\nDisallow: /catalog-health\nDisallow: /order/\nDisallow: /products?\nAllow: /catalog\nAllow: /products\nAllow: /product/\nAllow: /categories\nSitemap: " + base + "/sitemap.xml\n"
    return PlainTextResponse(text, media_type="text/plain; charset=utf-8", headers=_security_headers())


@router.get("/manifest.webmanifest")
def web_manifest(request: Request):
    pharmacy = _pharmacy_name()
    return JSONResponse({
        "name": pharmacy,
        "short_name": pharmacy,
        "start_url": "/catalog",
        "display": "standalone",
        "dir": "rtl",
        "lang": "ar",
        "background_color": "#ffffff",
        "theme_color": "#18b9df",
        "icons": [
            {"src": "/catalog-assets/icon-192.png?v=" + BRAND_ASSET_VERSION, "sizes": "192x192", "type": "image/png"},
            {"src": "/catalog-assets/icon-512.png?v=" + BRAND_ASSET_VERSION, "sizes": "512x512", "type": "image/png"},
        ],
    }, headers={**_security_headers(), "Cache-Control": "public, max-age=86400"})


@router.get("/sitemap.xml")
def sitemap_xml(request: Request):
    base = _public_base_url(request)
    static_paths = ["/catalog", "/products", "/categories", "/about", "/faq", "/privacy", "/terms", "/delivery-policy", "/contact"]
    urls: List[Tuple[str, str, str]] = [(base + p, _now_date(0), "0.8") for p in static_paths]
    try:
        with _connect() as conn:
            cols = _columns(conn)
            select_part, params = _select_sql(cols)
            rows = conn.execute(f"SELECT {select_part} FROM products ORDER BY id DESC LIMIT ?", params + [SITEMAP_PRODUCT_LIMIT]).fetchall()
            for row in rows:
                p = _display_product(dict(row))
                name = str(p.get("display_name") or "product")
                lastmod = str(p.get("updated_at") or _stock_updated_at() or _now_date(0))[:10]
                urls.append((base + _product_path(p), lastmod, "0.6"))
    except Exception:
        pass
    body = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for loc, lastmod, priority in urls:
        body.append(f"<url><loc>{_h(loc)}</loc><lastmod>{_h(lastmod)}</lastmod><priority>{priority}</priority></url>")
    body.append("</urlset>")
    return Response("\n".join(body), media_type="application/xml; charset=utf-8", headers=_security_headers())


@router.get("/")
def root_catalog_redirect():
    return RedirectResponse("/catalog", status_code=302)


@router.get("/catalog", response_class=HTMLResponse)
def catalog_home(request: Request) -> HTMLResponse:
    products = _query_products(page=1, sort="available")[0][:8]
    product_cards = "".join(_product_card(p, mode="tile") for p in products)
    if not product_cards:
        product_cards = '<div class="empty">لا توجد منتجات متاحة حالياً. ارفع ملف Excel من لوحة التاجر.</div>'
    body = f"""
    {_search_form(compact=True)}
    <section class="hero-card"><div class="hero-copy"><h1>كتالوج الصيدلية</h1><p>ابحث عن المنتج، راجع السعر والتوفر، ثم اطلبه مباشرة عبر واتساب.</p><a class="hero-cta" href="{_h(_whatsapp_link(f'السلام عليكم، أريد الطلب من {_pharmacy_name()}.'))}" target="_blank" rel="noopener">اطلب الآن عبر واتساب <span class="icon-wrap">{_icon('wa')}</span></a></div><div class="hero-art" aria-hidden="true"><div class="med-basket"><i class="med-item r1"></i><i class="med-item small r2"></i><i class="med-item r3"></i><b class="shield">{_icon('check')}</b></div></div></section>
    <div class="hero-dots"><i></i><i></i><i></i><i></i></div>
    {_category_tiles(5)}
    <div class="section-head"><div><h2>مختارات من الكتالوج</h2><p>منتجات مختارة حسب جودة البيانات وآخر تحديث للمخزون</p></div><a class="view-all" href="/products">عرض الكل</a></div>
    <div class="grid home-grid">{product_cards}</div>
    <section class="trust-strip"><div class="trust-item">{_icon('check')}<b>مصادر موثوقة</b><small>تأكيد قبل الطلب</small></div><div class="trust-item">{_icon('grid')}<b>تحديث مستمر</b><small>للأسعار والتوفر</small></div><div class="trust-item">{_icon('wa')}<b>طلب عبر واتساب</b><small>تأكيد قبل التجهيز</small></div><div class="trust-item">{_icon('badge')}<b>دعم صيدلي</b><small>للاستفسار قبل الطلب</small></div></section>
    """
    return _shell(request, "كتالوج المنتجات", body, active="home", description=f"كتالوج {_pharmacy_name()} للبحث عن المنتجات ومعرفة السعر والتوفر وطلب المنتجات عبر واتساب.", canonical_path="/catalog")


@router.get("/products", response_class=HTMLResponse)
def products_page(request: Request, q: str = Query("", max_length=140), category: str = Query("", max_length=160), page: int = Query(1, ge=1), sort: str = Query("available", max_length=32), brand: str = Query("", max_length=120), availability: str = Query("", max_length=32), price_min: str = Query("", max_length=32), price_max: str = Query("", max_length=32)) -> HTMLResponse:
    title = "نتائج البحث" if q else "المنتجات"
    desc = f"نتائج البحث عن {q} في كتالوج {_pharmacy_name()}." if q else f"كل المنتجات في كتالوج {_pharmacy_name()} مع الأسعار والطلب عبر واتساب."
    params = {k: v for k, v in {"q": q, "category": category, "brand": brand, "availability": availability, "price_min": price_min, "price_max": price_max, "page": page if page > 1 else "", "sort": sort if sort != "available" else ""}.items() if v}
    robots = "noindex,follow" if params or page > 10 else "index,follow"
    return _shell(request, title, _products_section(q=q, category=category, page=page, sort=sort, brand=brand, availability=availability, price_min=price_min, price_max=price_max), active="products", description=desc, canonical_path="/products", robots=robots)


@router.get("/categories", response_class=HTMLResponse)
def categories_page(request: Request) -> HTMLResponse:
    cards = ['<a class="contact-card category-page-card" href="/products"><strong>كل المنتجات</strong><small>عرض كامل الكتالوج</small></a>']
    for item in _categories():
        name = str(item.get("name") or "")
        href = "/products?" + urlencode({"category": name})
        cards.append(f'<a class="contact-card category-page-card" href="{_h(href)}"><span class="cat-line-icon">{_category_icon(name)}</span><strong>{_h(_display_category_label(name))}</strong><small>{_h(item.get("count"))} منتج</small></a>')
    body = f'<div class="section-head"><div><h2>التصنيفات</h2><p>اختر قسماً لعرض منتجاته.</p></div></div><section class="categories-page-grid">{"".join(cards)}</section>'
    return _shell(request, "التصنيفات", body, active="categories", description=f"تصنيفات منتجات {_pharmacy_name()}.", canonical_path="/categories")


def _render_product_detail(request: Request, product_id: int) -> HTMLResponse:
    product = _get_product(product_id)
    if not product:
        body = f"""
        <a class="btn secondary mobile-back" href="/products">{_icon('back')} رجوع للمنتجات</a>
        <section class="not-found-card"><h1>المنتج غير موجود</h1><p>الرابط غير صحيح، أو أن المنتج لم يعد ضمن الكتالوج الحالي.</p>{_search_form(compact=True)}<div class="detail-actions"><a class="btn" href="/products">تصفح المنتجات</a><a class="btn secondary" href="/contact">تواصل مع الصيدلية</a></div></section>
        """
        return _shell(request, "المنتج غير موجود", body, active="products", description=f"المنتج غير موجود في كتالوج {_pharmacy_name()}.", canonical_path=f"/product/{product_id}", robots="noindex,follow", status_code=404)
    product = _display_product(product)
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    availability_text, availability_cls, schema_availability = _availability_label(product.get("available_value"))
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}" width="420" height="320" decoding="async" fetchpriority="high"><div class="no-img fallback"><span>Rx</span><small>الصورة غير متاحة</small></div>' if img else '<div class="no-img"><span>Rx</span><small>صورة المنتج قريباً</small></div>'
    similar = _similar_products(product, limit=4)
    similar_html = "".join(_product_card(p) for p in similar)
    similar_section = f'<section class="similar-products"><div class="section-head"><div><h2>منتجات مشابهة</h2><p>اقتراحات من نفس البراند أو القسم.</p></div></div><div class="similar-grid">{similar_html}</div></section>' if similar_html else ""
    description = (f"{name} في كتالوج {_pharmacy_name()} بسعر {price}. يتم تأكيد التوفر والسعر النهائي عبر واتساب." if not price.startswith("السعر") else f"{name} في كتالوج {_pharmacy_name()}. السعر والتوفر يتم تأكيدهما عبر واتساب.")
    price_val = _price_number(product)
    currency = str(product.get("currency") or "LYD")
    image_abs = _absolute_url(img or f"/badr-logo.png?v={BRAND_ASSET_VERSION}", request)
    can_order = _availability_status(product.get("available_value")) is True
    order_label = "اطلب عبر واتساب" if can_order else "استفسر عن التوفر"
    order_href = f"/order/{product_id}" if can_order else "/contact?product_id=" + str(product_id) + "&availability=inquiry"
    badge_icon = _icon("check") if can_order else _icon("info")
    canonical_path = _product_path(product)
    product_json = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": name,
        "image": [image_abs],
        "description": description,
        "brand": {"@type": "Brand", "name": brand or _pharmacy_name()},
        "category": _display_category_label(category) if category else "Pharmacy Product",
        "sku": str(product_id),
        "url": _absolute_url(canonical_path, request),
    }
    if price_val < 10**12:
        product_json["offers"] = {"@type": "Offer", "url": _absolute_url(canonical_path, request), "priceCurrency": currency, "price": price_val, "availability": schema_availability, "seller": {"@type": "Pharmacy", "name": _pharmacy_name()}}
    body = f"""
    <nav class="breadcrumb" aria-label="المسار"><a href="/catalog">الرئيسية</a><span>/</span><a href="/products">المنتجات</a><span>/</span><b>{_h(name)}</b></nav>
    <a class="btn secondary mobile-back" href="/products">{_icon('back')} رجوع للمنتجات</a>
    <section class="detail" data-product-detail="{_h(product_id)}"><div class="image">{img_html}</div><div><h1 dir="auto">{_h(name)}</h1><div class="product-price {'price-missing' if price.startswith('السعر') else ''}">{_h(price)}</div><div class="badge {availability_cls}">{badge_icon} {_h(availability_text)}</div><div class="info-list"><p>رقم المنتج: <b>{_h(product_id)}</b></p><p>القسم: <b>{_h(_display_category_label(category)) if category else 'غير محدد'}</b></p><p>البراند: <b>{_h(brand) if brand else _h(_pharmacy_name())}</b></p><p>المادة الفعالة: <b>{_h(product.get("active_ingredient") or "غير محدد")}</b></p><p>الشكل/التركيز: <b>{_h(product.get("form") or "غير محدد")} {_h(product.get("strength") or "")}</b></p><p>الحجم/العبوة: <b>{_h(product.get("size") or "غير محدد")}</b></p><p>الباركود/SKU: <b>{_h(product.get("barcode") or product_id)}</b></p></div><div class="product-advice"><b>معلومات مهمة:</b><br>هذا الكتالوج لعرض السعر والتوفر فقط. يتم تأكيد المنتج والسعر النهائي داخل واتساب قبل تجهيز الطلب. لا تستخدم أي دواء دون استشارة الصيدلي أو الطبيب عند الحاجة.</div><div class="order-note">يتم تأكيد السعر والتوفر النهائي عبر واتساب قبل تجهيز الطلب.</div><div class="detail-actions"><a class="btn" href="{_h(order_href)}" target="_blank" rel="noopener">{_icon('wa')} {order_label}</a><button class="btn secondary" type="button" data-share>مشاركة المنتج</button><button class="btn secondary" type="button" data-copy-url>نسخ الرابط</button><a class="btn secondary" href="/products">رجوع للمنتجات</a></div></div></section>
    {similar_section}
    """
    _write_event("product_view", canonical_path, name, {"product_id": product_id}, request)
    return _shell(request, name, body, active="products", description=description, canonical_path=canonical_path, og_image=img or f"/badr-logo.png?v={BRAND_ASSET_VERSION}", json_ld=_json_script(product_json))


@router.get("/product/{product_path}", response_class=HTMLResponse)
def product_detail(request: Request, product_path: str) -> HTMLResponse:
    m = re.match(r"^(\d+)(?:-|$)", str(product_path or ""))
    if not m:
        return not_found_page(request, product_path)
    product_id = int(m.group(1))
    product = _get_product(product_id)
    if not product:
        return _render_product_detail(request, product_id)
    canonical_path = _product_path(product)
    if str(product_path) != canonical_path.rsplit("/", 1)[-1]:
        return RedirectResponse(canonical_path, status_code=301)
    return _render_product_detail(request, product_id)


@router.get("/order/{product_id}")
def order_product(request: Request, product_id: int):
    product = _get_product(product_id)
    if not product:
        return RedirectResponse(f"/contact?product_id={int(product_id)}&missing=1", status_code=302)
    status = _availability_status(product.get("available_value"))
    if status is not True:
        # لا نفتح رسالة طلب لمنتج غير متوفر أو غير مؤكد؛ نوجه المستخدم للاستفسار فقط.
        return RedirectResponse(f"/contact?product_id={int(product_id)}&availability=inquiry", status_code=302)
    _write_event("order_or_whatsapp_click", _product_path(product), str(product.get("display_name") or product_id), {"product_id": product_id}, request)
    return RedirectResponse(_whatsapp_link(_order_message(product, request)), status_code=302)


@router.get("/contact", response_class=HTMLResponse)
def contact_page(request: Request) -> HTMLResponse:
    pharmacy = _pharmacy_name()
    wa = _whatsapp_link(f"السلام عليكم، أريد التواصل مع {pharmacy}.")
    body = f"""
    <section class="contact-card"><h1>تواصل مع {pharmacy}</h1><p>للطلبات والاستفسارات، استخدم واتساب. الأسعار والتوفر يتم تأكيدهما قبل تجهيز الطلب. إذا لم يفتح واتساب، استخدم رقم الصيدلية المعلن داخل لوحة التاجر.</p><div class="detail-actions"><a class="btn" href="{_h(wa)}" target="_blank" rel="noopener">{_icon('wa')} فتح واتساب</a><a class="btn secondary" href="/products">تصفح المنتجات</a></div><div class="customer-notice">هذا الموقع كتالوج عرض وطلب عبر واتساب، وليس بوابة دفع إلكتروني حالياً.</div></section>
    <div class="contact-grid"><div class="contact-card"><strong>طريقة الطلب</strong><p>ابحث عن المنتج، افتح التفاصيل، ثم اضغط اطلب عبر واتساب.</p></div><div class="contact-card"><strong>التوفر</strong><p>حالة التوفر مبنية على آخر ملف منتجات مرفوع من الصيدلية.</p></div><div class="contact-card"><strong>التأكيد</strong><p>يتم تأكيد السعر والتوفر النهائيين داخل محادثة واتساب.</p></div></div>
    """
    return _shell(request, "تواصل معنا", body, active="contact", description=f"تواصل مع {pharmacy} للطلب والاستفسار عبر واتساب.", canonical_path="/contact")


@router.get("/about", response_class=HTMLResponse)
def about_page(request: Request) -> HTMLResponse:
    pharmacy = _pharmacy_name()
    body = f'<section class="contact-card"><h1>من نحن</h1><p>{_h(pharmacy)} كتالوج صيدلية لعرض المنتجات والأسعار المبدئية والتواصل عبر واتساب قبل تجهيز الطلب.</p></section>'
    return _shell(request, "من نحن", body, active="contact", description=f"نبذة عن {pharmacy}.", canonical_path="/about")


@router.get("/faq", response_class=HTMLResponse)
def faq_page(request: Request) -> HTMLResponse:
    body = '<section class="contact-card"><h1>الأسئلة الشائعة</h1><p><b>هل السعر نهائي؟</b><br>يتم تأكيد السعر والتوفر عبر واتساب قبل تجهيز الطلب.</p><p><b>هل الموقع فيه دفع إلكتروني؟</b><br>حالياً الموقع كتالوج وطلب عبر واتساب فقط.</p><p><b>ماذا لو المنتج غير متوفر؟</b><br>يمكنك التواصل للاستفسار عن البدائل.</p></section>'
    return _shell(request, "الأسئلة الشائعة", body, active="contact", canonical_path="/faq")


@router.get("/privacy", response_class=HTMLResponse)
def privacy_page(request: Request) -> HTMLResponse:
    body = '<section class="contact-card"><h1>سياسة الخصوصية</h1><p>نستخدم بيانات تقنية محدودة لتحسين الكتالوج مثل نوع الحدث، المسار، كلمة البحث، المرجع التقريبي، ونوع المتصفح. لا يتم بيع بيانات المستخدمين ولا مشاركة المحادثات مع المعلنين.</p></section>'
    return _shell(request, "سياسة الخصوصية", body, active="contact", canonical_path="/privacy")


@router.get("/terms", response_class=HTMLResponse)
def terms_page(request: Request) -> HTMLResponse:
    body = '<section class="contact-card"><h1>الشروط والتنبيه</h1><p>الموقع كتالوج عرض فقط. الأسعار والتوفر قد تتغير ويتم تأكيدهما عبر واتساب قبل تجهيز الطلب. لا تستخدم أي دواء دون استشارة مختص عند الحاجة.</p></section>'
    return _shell(request, "الشروط والتنبيه", body, active="contact", canonical_path="/terms")


@router.get("/delivery-policy", response_class=HTMLResponse)
def delivery_policy_page(request: Request) -> HTMLResponse:
    body = '<section class="contact-card"><h1>سياسة التوصيل والاسترجاع</h1><p>تفاصيل التوصيل والاسترجاع يتم تأكيدها عبر واتساب حسب المدينة ونوع المنتج وحالة الطلب.</p></section>'
    return _shell(request, "سياسة التوصيل والاسترجاع", body, active="contact", canonical_path="/delivery-policy")


@router.post("/merchant/rebuild-search")
def merchant_rebuild_search(request: Request):
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    ok, msg = rebuild_products_fts()
    return _json_response({"ok": ok, "message": msg})


@router.get("/merchant/rebuild-search", response_class=HTMLResponse)
def merchant_rebuild_search_page(request: Request) -> HTMLResponse:
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    ok, msg = rebuild_products_fts()
    body = f'<section class="contact-card"><h1>إعادة بناء البحث</h1><p>{_h(msg)}</p><div class="detail-actions"><a class="btn" href="/products">اختبار البحث</a><a class="btn secondary" href="/merchant/site-analytics">الإحصائيات</a></div></section>'
    return _shell(request, "إعادة بناء البحث", body, robots="noindex,nofollow")


@router.get("/merchant/site-tools", response_class=HTMLResponse)
def merchant_site_tools(request: Request) -> HTMLResponse:
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    body = f"""
    <div class="section-head"><div><h2>أدوات الموقع</h2><p>روابط تشغيل وإدارة كتالوج الصيدلية.</p></div></div>
    <section class="contact-grid">
      <a class="contact-card tool-card" href="/catalog"><strong>فتح موقع العميل</strong><p>معاينة الصفحة الرئيسية للكتالوج.</p></a>
      <a class="contact-card tool-card" href="/products"><strong>كل المنتجات</strong><p>اختبار البحث والفلاتر وترتيب المنتجات.</p></a>
      <a class="contact-card tool-card" href="/categories"><strong>التصنيفات</strong><p>عرض أقسام الكتالوج كما يراها العميل.</p></a>
      <a class="contact-card tool-card" href="/merchant/rebuild-search"><strong>إعادة بناء البحث</strong><p>تحديث فهرس FTS بعد رفع أو تعديل المنتجات.</p></a>
      <a class="contact-card tool-card" href="/merchant/site-analytics"><strong>إحصائيات الموقع</strong><p>مشاهدات، كلمات بحث، وضغطات واتساب.</p></a>
      <a class="contact-card tool-card" href="/sitemap.xml"><strong>Sitemap</strong><p>فحص روابط المنتجات لمحركات البحث.</p></a>
    </section>
    """
    return _shell(request, "أدوات الموقع", body, active="contact", robots="noindex,nofollow")


@router.get("/merchant/site-analytics", response_class=HTMLResponse)
def merchant_site_analytics(request: Request) -> HTMLResponse:
    auth = _merchant_auth_response(request)
    if auth:
        return auth
    _ensure_analytics_table()
    try:
        with sqlite3.connect(str(_analytics_db_file()), timeout=5) as conn:
            conn.row_factory = sqlite3.Row
            total_views = int(conn.execute("SELECT COUNT(*) FROM catalog_analytics_events WHERE event_type='page_view'").fetchone()[0] or 0)
            searches = int(conn.execute("SELECT COUNT(*) FROM catalog_analytics_events WHERE event_type='search_submit'").fetchone()[0] or 0)
            orders = int(conn.execute("SELECT COUNT(*) FROM catalog_analytics_events WHERE event_type IN ('order_click','order_or_whatsapp_click')").fetchone()[0] or 0)
            today = int(conn.execute("SELECT COUNT(*) FROM catalog_analytics_events WHERE date(created_at)=date('now')").fetchone()[0] or 0)
            top_pages = conn.execute("SELECT path, COUNT(*) c FROM catalog_analytics_events WHERE event_type='page_view' GROUP BY path ORDER BY c DESC LIMIT 10").fetchall()
            top_searches = conn.execute("SELECT json_extract(meta_json,'$.q') q, COUNT(*) c FROM catalog_analytics_events WHERE event_type='search_submit' AND COALESCE(json_extract(meta_json,'$.q'),'')!='' GROUP BY q ORDER BY c DESC LIMIT 10").fetchall()
    except Exception:
        total_views = searches = orders = today = 0
        top_pages = []
        top_searches = []
    stats = f'<section class="analytics-grid"><div class="analytics-card"><b>{total_views}</b><p>مشاهدات الصفحات</p></div><div class="analytics-card"><b>{searches}</b><p>عمليات البحث</p></div><div class="analytics-card"><b>{orders}</b><p>ضغطات واتساب/طلب</p></div><div class="analytics-card"><b>{today}</b><p>أحداث اليوم</p></div></section>'
    pages_html = ''.join(f'<p><b>{_h(r["c"])}</b> — <span dir="ltr">{_h(r["path"])}</span></p>' for r in top_pages) or '<p>لا توجد بيانات بعد.</p>'
    search_html = ''.join(f'<p><b>{_h(r["c"])}</b> — <span dir="auto">{_h(r["q"])}</span></p>' for r in top_searches) or '<p>لا توجد بيانات بحث بعد.</p>'
    body = f'<div class="section-head"><div><h2>إحصائيات الموقع</h2><p>إحصاءات داخلية خفيفة بدون خدمات خارجية.</p></div><div class="detail-actions"><a class="btn secondary" href="/merchant/rebuild-search">إعادة بناء البحث</a><a class="btn secondary" href="/merchant/site-tools">أدوات الموقع</a></div></div>{stats}<div class="contact-grid"><div class="contact-card"><h3>أكثر الصفحات زيارة</h3>{pages_html}</div><div class="contact-card"><h3>أكثر كلمات البحث</h3>{search_html}</div><div class="contact-card"><h3>ملاحظة الخصوصية</h3><p>يتم تسجيل نوع الحدث، المسار، كلمة البحث، المرجع التقريبي، ونوع المتصفح لتحسين الكتالوج والحماية من السبام.</p></div></div>'
    return _shell(request, "إحصائيات الموقع", body, active="contact", robots="noindex,nofollow")

