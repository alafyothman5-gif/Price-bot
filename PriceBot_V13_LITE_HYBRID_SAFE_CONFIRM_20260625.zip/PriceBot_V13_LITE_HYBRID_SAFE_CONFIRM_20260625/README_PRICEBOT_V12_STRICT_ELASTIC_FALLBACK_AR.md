# PriceBot V12 — Strict Elastic Fallback Layer

هذه النسخة تبني فوق V11 وتضيف طبقة مطابقة مرنة مقاومة للفشل قبل إرجاع "غير متوفر".

## التعديل الأساسي

تم تعديل `app.py` لإضافة منطق المحاولة المتسلسلة للنصوص والصور:

1. المحاولة الأولى: `semantic_matcher.match(raw_query)`.
2. المحاولة الثانية: استخراج اسم/كلمة قوية مثل `Xerolact` ثم إعادة المحاولة.
3. المحاولة الثالثة: بحث جزئي مباشر في PostgreSQL/SQLite داخل:
   - `products.name`
   - `products.normalized_name`
   - `products.product_family`
   - `products.aliases`
   - `products.original_name`
   - `products.brand`
   - جدول `product_aliases` إن كان موجوداً
4. إذا وجد المنتج في قاعدة البيانات، يتم أخذ الاسم الكامل وإعادة تمريره إلى `semantic_matcher.match(full_product_name)`.
5. لا يتم عرض "غير متوفر" إلا بعد فشل جميع المحاولات.

## سجلات جديدة

- `TEXT_RETRY_PRIMARY`
- `TEXT_RETRY_PRIMARY_FAILED`
- `TEXT_DB_PARTIAL_HIT`
- `TEXT_DB_PARTIAL_MISS`
- `TEXT_DB_PARTIAL_FAILED`
- `IMAGE_DB_PARTIAL_HIT`
- `IMAGE_DB_PARTIAL_MISS`
- `IMAGE_DB_PARTIAL_FAILED`

## أمر الفحص بعد الرفع

```bash
cd /opt/pricebot-whatsapp-gemini
source .venv/bin/activate
python3 -m py_compile app.py vision_service.py services/vision/evidence_validator.py semantic_matcher.py database.py
sudo systemctl restart pricebot-whatsapp-gemini
sudo systemctl status pricebot-whatsapp-gemini --no-pager -l
```

## اختبار مقترح

أرسل نصاً ناقصاً مثل:

```text
Xerolact
```

أو صورة منتج واضحة. في السجلات يجب أن يظهر أحد المسارات التالية:

- `TEXT_SEMANTIC_DIRECT` أو `TEXT_SEMANTIC_CONFIRM`
- أو `TEXT_RETRY_PRIMARY` ثم نجاح
- أو `TEXT_DB_PARTIAL_HIT` ثم نجاح

