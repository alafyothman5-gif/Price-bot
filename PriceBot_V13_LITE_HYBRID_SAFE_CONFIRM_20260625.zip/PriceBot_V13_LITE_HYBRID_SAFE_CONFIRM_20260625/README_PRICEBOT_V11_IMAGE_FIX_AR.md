# PriceBot V11 — Image Identity Fix

هذه النسخة تضيف إصلاحاً حاسماً لمسار الصور فقط:

- `vision_service.py` يستخرج `product_identity` نظيفاً بدلاً من تمرير OCR طويل.
- `app.py` يسجل `VISION_EXTRACTED` ويستخدم الاستعلام النظيف للمطابقة.
- إذا فشل قرار الصورة بـ `unavailable`، يتم تنفيذ Retry تلقائي باسم قصير مثل `primary_name`.
- لم يتم تعديل `semantic_matcher.py` أو قاعدة البيانات.

## التشغيل

```bash
cd /opt/pricebot-whatsapp-gemini
source .venv/bin/activate
python3 -m py_compile app.py vision_service.py services/vision/evidence_validator.py
sudo systemctl restart pricebot-whatsapp-gemini
sudo journalctl -u pricebot-whatsapp-gemini -f --since "1 minute ago" -o cat | grep --line-buffered -E "VISION_EXTRACTED|IMAGE_RETRY_FALLBACK|SEMANTIC_RETRIEVED|GEMINI_VERIFIED|IMAGE_SEMANTIC_DIRECT|IMAGE_SEMANTIC_CONFIRM|IMAGE_SEMANTIC_UNAVAILABLE"
```

## سجلات متوقعة

```json
{"event":"VISION_EXTRACTED","product_identity":"Hemazym Liposomal","primary_name":"Hemazym"}
{"event":"IMAGE_RETRY_FALLBACK","original_query":"...","fallback_query":"Hemazym"}
{"event":"IMAGE_SEMANTIC_CONFIRM","product_id":4781}
```
