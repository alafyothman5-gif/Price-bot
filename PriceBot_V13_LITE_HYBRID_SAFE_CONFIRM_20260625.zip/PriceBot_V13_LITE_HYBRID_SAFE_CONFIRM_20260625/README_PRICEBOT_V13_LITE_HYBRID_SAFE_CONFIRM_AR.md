# PriceBot V13-lite — Hybrid Safe Confirm

هذه النسخة مبنية فوق V12 وتضيف طبقة مطابقة هجينة آمنة بدون تغيير أبعاد الـ embeddings وبدون Reranker محلي وبدون جدول مرادفات جماعي.

## الهدف

تقليل ردود "غير متوفر" الوهمية، مع منع السعر الخاطئ عند الأسماء الغامضة مثل CeraVe وLa Roche وPanadol.

## التغييرات الأساسية

1. تفعيل `pg_trgm` في PostgreSQL داخل تهيئة `semantic_matcher`.
2. إنشاء فهارس GIN Trigram تلقائياً على الأعمدة الموجودة فقط:
   - `name`
   - `normalized_name`
   - `original_name`
   - `brand`
   - `product_family`
   - `aliases`
3. إضافة Hybrid Retrieval داخل `semantic_matcher.py`:
   - pgvector semantic retrieval
   - pg_trgm / ILIKE textual retrieval
   - دمج النتائج بـ RRF بسيط وإزالة التكرار
4. Gemini يبقى الحكم النهائي ولا يتم اختيار أول نتيجة من قاعدة البيانات كقرار نهائي.
5. Direct صار أكثر أماناً افتراضياً: `PRICEBOT_GEMINI_DIRECT_CONFIDENCE=0.90`.
6. الاستعلامات القصيرة أو الغامضة تتحول إلى Confirm بدلاً من عرض السعر مباشرة إذا وجدت عدة منتجات قريبة.
7. DB partial fallback في `app.py` صار يعرض قائمة/تأكيد للمستخدم بدلاً من إجبار أول نتيجة على التطابق.

## سجلات جديدة

- `HYBRID_RETRIEVED`
- `HYBRID_RETRIEVAL_EMPTY`
- `TEXTUAL_RETRIEVAL_ERROR`
- `TRIGRAM_INDEX_WARNING`
- `TEXT_DB_PARTIAL_CANDIDATES`
- `IMAGE_DB_PARTIAL_CANDIDATES`

## فحص بعد الرفع

```bash
cd /opt/pricebot-whatsapp-gemini
source .venv/bin/activate
python3 -m py_compile app.py semantic_matcher.py vision_service.py services/vision/evidence_validator.py database.py
sudo systemctl restart pricebot-whatsapp-gemini
curl -s http://127.0.0.1:8090/health | python3 -m json.tool
```

يجب أن تظهر:

```json
"matcher": "v13_lite_hybrid_semantic_gemini"
```

## ملاحظات مهمة

- هذه النسخة لا تستخدم `sentence-transformers`.
- هذه النسخة لا تغير `vector(1536)`.
- هذه النسخة لا تنشئ `product_synonyms`.
- هذه النسخة لا تعرض أول نتيجة ILIKE كسعر مباشر.
- عند الغموض، الخيار الآمن هو زر تأكيد أو قائمة منتجات.
