import html
import os
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, PlainTextResponse

import database

router = APIRouter()
ADMIN_KEY = os.getenv("ADMIN_KEY", "change_me")


def _authorized(request: Request) -> bool:
    return request.query_params.get("key") == ADMIN_KEY


def _layout(title: str, body: str) -> str:
    return f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>
<title>{html.escape(title)}</title><style>body{{font-family:Arial,sans-serif;margin:30px;background:#f7f7f7}}table{{border-collapse:collapse;background:white;width:100%}}td,th{{border:1px solid #ddd;padding:8px}}.card{{background:white;padding:16px;border-radius:10px;margin-bottom:16px}}</style></head><body>{body}</body></html>"""


@router.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request):
    if not _authorized(request):
        return HTMLResponse("Unauthorized", status_code=401)
    products = database.count_products()
    pending = database.list_orders("pending", 50)
    rows = "".join(
        f"<tr><td>{o['id']}</td><td>{html.escape(o['phone'])}</td><td>{html.escape(o['product_name'])}</td><td>{o['quantity']}</td><td>{html.escape(o['price'])}</td><td>{html.escape(o['status'])}</td></tr>"
        for o in pending
    ) or "<tr><td colspan='6'>لا توجد طلبات معلقة</td></tr>"
    body = f"<div class='card'><h2>لوحة PriceBot</h2><p>عدد المنتجات: {products}</p><p>Integrity: {html.escape(database.integrity_check())}</p></div><div class='card'><h3>الطلبات المعلقة</h3><table><tr><th>#</th><th>الهاتف</th><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الحالة</th></tr>{rows}</table></div>"
    return _layout("PriceBot Admin", body)


@router.post("/admin/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str):
    if not _authorized(request):
        return PlainTextResponse("Unauthorized", status_code=401)
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status)
    return {"ok": True}
