# PriceBot Safe Matching Testing

Run full tests:

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot_clean/pricebot.db
```

The tests verify:

- menu flow
- booking disabled
- brand/family guard
- cosmetic type guard
- cross-category guard
- medicine variant resolver
- duplicate price safety
- Vision slot matching
- generic image rejection
- no random alternatives

Critical expected cases:

```text
Rilastil xerolact PB متوفر => NOT_AVAILABLE
Cerave Hydrating Cleanser => not lotion/moisturizer/cream/serum
Amoclan syrup => no supplement syrup
Flagyl 500mg => ASK_CLARIFICATION if duplicate prices
Janumet 50/1000mg => ASK_CLARIFICATION if duplicate prices
Cipralex 10mg => ASK_CLARIFICATION if duplicate prices
Pro-D3 50,000 IU vitamin k2 15 capsules => EXACT_MATCH Pro-D3
Ovanice Female Fertility 90 capsules 850mg => EXACT_MATCH Ovanice
cream tube 50ml => LOW_CONFIDENCE or IMAGE_UNCLEAR
```


## Runtime safety checks

The latest build was tested with:

```bash
python3 -m compileall .
python3 tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/test.sqlite --dry-run
python3 tools/import_master_excel.py products_master_ready.xlsx --db-path /tmp/test.sqlite
python3 tools/verify_production.py --db-path /tmp/test.sqlite --excel-path products_master_ready.xlsx
python3 tools/run_acceptance_tests.py --db-path /tmp/test.sqlite
```

Expected acceptance summary:

```text
UI_ACCEPTANCE_PASS=23
SAFE_MATCHING_ACCEPTANCE_PASS=41
ACCEPTANCE_TESTS_ALL_PASS=64
```

## READY-2 deploy fixes

- `start_pricebot.sh` uses `exec "$APP_DIR/venv/bin/python" -m uvicorn app:app --host "$HOST" --port "$PORT"`.
- `clean_install_pricebot.sh` builds the DB in an external temporary path, verifies it, then copies it to `/opt/pricebot_clean/pricebot.db`.
- `/health` is lightweight and does not call `integrity_check`; `/deep-health` and `/health/deep` run deep diagnostics.
- Per-user async locks are implemented in `app.py` to serialize messages per phone number.
