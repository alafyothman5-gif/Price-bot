#!/usr/bin/env python3
import argparse
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import database
import guided_commerce
from search_engine import search_product


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Read-only production verification for PriceBot.")
    p.add_argument("excel_path_positional", nargs="?", default="", help="Optional Excel path for backward compatibility")
    p.add_argument("--db-path", default="", help="SQLite DB path to verify. Example: /tmp/test.sqlite")
    p.add_argument("--excel-path", default="", help="Path to products_master_ready.xlsx")
    return p.parse_args()


def run(cmd, timeout=4):
    try:
        out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        return out.returncode, out.stdout.strip()
    except Exception as exc:
        return 999, f"{type(exc).__name__}: {exc}"


def timed(label, fn):
    start = time.perf_counter()
    try:
        result = fn()
        ok = True
    except Exception as exc:
        result = f"ERROR {type(exc).__name__}: {exc}"
        ok = False
    ms = int((time.perf_counter() - start) * 1000)
    print(f"{label}: {'OK' if ok else 'FAIL'} {ms}ms {result}")
    return ok


def excel_info(path: Path):
    if not path.exists():
        return "missing"
    try:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        found_row = 0
        headers = []
        for r in range(1, min(15, ws.max_row) + 1):
            vals = [str(v or '').strip() for v in next(ws.iter_rows(min_row=r, max_row=r, values_only=True))]
            if 'product_id' in vals and 'name' in vals and 'price' in vals:
                found_row = r
                headers = vals
                break
        rows = max(0, ws.max_row - found_row) if found_row else 0
        wb.close()
        return f"exists rows≈{rows} columns={len([h for h in headers if h])} header_row={found_row or 'not_found'}"
    except Exception as exc:
        return f"error {type(exc).__name__}: {exc}"


def schema_status(table: str, required: list[str]) -> str:
    try:
        with database.connect() as conn:
            if not database.table_exists(conn, table):
                return f"{table}=MISSING"
            cols = set(database.table_columns(conn, table))
            missing = [c for c in required if c not in cols]
            if missing:
                return f"{table}=WARNING missing={missing}"
            return f"{table}=OK"
    except Exception as exc:
        return f"{table}=ERROR {type(exc).__name__}: {exc}"


def main() -> int:
    args = parse_args()
    if args.db_path:
        database.configure_db_path(args.db_path)
    database.set_read_only_mode(True)
    db_path = database.get_db_path()
    excel_raw = args.excel_path or args.excel_path_positional or '/opt/pricebot/products_master_ready.xlsx'
    excel_path = Path(excel_raw).expanduser()
    print("VERIFY_READ_ONLY=1")
    print(f"DB_PATH_SOURCE={getattr(database, 'DB_PATH_SOURCE', 'unknown')}")
    print(f"DB path: {db_path}")
    print(f"DB exists: {db_path.exists()}")
    try:
        # verify is read-only: do not call init_db and do not create tables.
        integrity = database.integrity_check()
        products = database.count_products()
        search_count = database.count_table('product_search_index')
        guided_count = database.count_table('guided_catalog_index')
    except Exception as exc:
        print(f"db_read: FAIL {type(exc).__name__}: {exc}")
        integrity = "failed"
        products = 0
        search_count = 0
        guided_count = 0
    print(f"integrity_check: {integrity}")
    print(f"products count: {products}")
    print(f"Excel: {excel_path} => {excel_info(excel_path)}")
    print(f"search index count: {search_count}")
    print(f"guided index count: {guided_count}")
    print("schema processed_messages:", schema_status('processed_messages', ['message_id']))
    print("schema conversation_state:", schema_status('conversation_state', ['phone', 'state_json']))
    print("schema product_search_index:", schema_status('product_search_index', ['key', 'kind', 'product_db_id']))
    print("schema guided_catalog_index:", schema_status('guided_catalog_index', ['product_db_id', 'main_section', 'sub_section', 'visible']))
    if database.count_table('product_nav_index') == 0:
        print('schema product_nav_index: WARNING optional_missing_or_empty')
    else:
        print('schema product_nav_index:', schema_status('product_nav_index', []))

    code, out = run(['systemctl', 'is-active', 'pricebot'], timeout=3)
    print(f"service status: {out if out else code}")
    code, out = run(['bash', '-lc', 'curl -fsS --max-time 3 http://127.0.0.1:8090/health || true'], timeout=5)
    print(f"health_light: {out[:300] if out else 'not reachable'}")
    code, out = run(['bash', '-lc', 'curl -fsS --max-time 5 http://127.0.0.1:8090/health/deep || true'], timeout=7)
    print(f"health_deep: {out[:500] if out else 'not reachable'}")

    timed('sample exact search Photoblok 50+', lambda: search_product('Photoblok 50+').status)
    timed('guided main menu', lambda: ', '.join(guided_commerce.available_main_sections()[:5]) or 'empty')
    timed('guided menu timing', lambda: guided_commerce.format_main_menu().split('\n')[0])

    final_ok = str(integrity).lower() == 'ok' and int(products or 0) > 0
    print(f"VERIFY_PRODUCTION_{'OK' if final_ok else 'WARNING'}")
    return 0 if final_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
