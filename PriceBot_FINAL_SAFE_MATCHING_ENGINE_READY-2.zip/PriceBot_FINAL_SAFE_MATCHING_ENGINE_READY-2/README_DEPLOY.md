# PriceBot FINAL SAFE MATCHING ENGINE Deploy

## Package
`PriceBot_FINAL_SAFE_MATCHING_ENGINE_READY.zip`

This ZIP does not contain:

- `.env`
- `pricebot.db`
- `venv/`
- backups
- secrets
- old ZIP files

## Clean install
Upload the ZIP to the server, then run:

```bash
cd /tmp
unzip PriceBot_FINAL_SAFE_MATCHING_ENGINE_READY.zip
cd PriceBot_FINAL_SAFE_MATCHING_ENGINE_READY
sudo ./clean_install_pricebot.sh
```

The script is designed for PriceBot only. It does not touch MedMCQ.

## Manual verification
After install:

```bash
cd /opt/pricebot_clean
./venv/bin/python -m compileall .
./venv/bin/python tools/verify_production.py --db-path /opt/pricebot_clean/pricebot.db --excel-path /opt/pricebot_clean/products_master_ready.xlsx
./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot_clean/pricebot.db
sudo systemctl restart pricebot
sudo systemctl status pricebot --no-pager -l
```

Webhook test:

```bash
TOKEN="$(grep -E '^META_VERIFY_TOKEN=' /opt/pricebot_clean/.env | cut -d= -f2-)" && curl -i "https://46.101.148.246.sslip.io/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=${TOKEN}&hub.challenge=PING"
```

Expected:

```text
HTTP 200
PING
```

## Import policy
Import is explicit only and requires `--db-path`:

```bash
./venv/bin/python tools/import_master_excel.py /opt/pricebot_clean/products_master_ready.xlsx --db-path /opt/pricebot_clean/pricebot.db --dry-run
./venv/bin/python tools/import_master_excel.py /opt/pricebot_clean/products_master_ready.xlsx --db-path /opt/pricebot_clean/pricebot.db
```

The importer does not delete products. It upserts Excel rows and hides stale old products.


## Latest runtime safety changes

- Clean install builds `pricebot.db` in `/tmp` first, verifies it, then copies it into `/opt/pricebot_clean/pricebot.db`.
- `start_pricebot.sh` uses `$APP_DIR/venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 8090`.
- `/health` is lightweight. Deep DB diagnostics are available at `/health/deep`.
- Per-user locks are enabled to protect conversation state under multiple workers.

Health checks:

```bash
curl -sS http://127.0.0.1:8090/health
curl -sS http://127.0.0.1:8090/health/deep
```

## READY-2 deploy fixes

- `start_pricebot.sh` uses `exec "$APP_DIR/venv/bin/python" -m uvicorn app:app --host "$HOST" --port "$PORT"`.
- `clean_install_pricebot.sh` builds the DB in an external temporary path, verifies it, then copies it to `/opt/pricebot_clean/pricebot.db`.
- `/health` is lightweight and does not call `integrity_check`; `/deep-health` and `/health/deep` run deep diagnostics.
- Per-user async locks are implemented in `app.py` to serialize messages per phone number.
