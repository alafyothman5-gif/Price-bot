import os
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import database
import search_engine
import ui_flow
import conversation_state as cs


def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)


def names(products):
    return [str(p.get('name') or '') for p in products]


def assert_no_forbidden(products, forbidden, msg):
    joined = ' | '.join(names(products)).lower()
    for word in forbidden:
        assert_true(word.lower() not in joined, f"{msg}: forbidden {word} in {joined}")


def main():
    db_path = os.environ.get('PRICEBOT_DB_PATH') or '/tmp/pricebot_acceptance.sqlite'
    database.configure_db_path(db_path)
    database.init_db(run_production_guard=False)
    phone='acceptance_safe_user'
    database.clear_state(phone)

    # UI basics and booking disabled
    r=ui_flow.handle_text(phone,'مرحبا'); assert_true('ابدأ' in r, 'greeting')
    r=ui_flow.handle_text(phone,'ابدأ'); assert_true('البحث عن منتج' in r and 'تصفح الأقسام' in r, 'main menu')
    r=ui_flow.handle_text(phone,'1'); assert_true('البحث بالاسم' in r and 'البحث بالصورة' in r, 'search submenu')
    r=ui_flow.handle_text(phone,'1'); assert_true('اكتب اسم المنتج' in r, 'search prompt')

    # Vision long text should resolve to the exact product, not raw token failure.
    cases_exact = {
        'Pro-D3 50,000 IU vitamin k2 15 capsules': 'Pro-D3',
        'Pro Bio Pro-D3 50,000 IU Vitamin K2': 'Pro-D3',
        'Ovanice Female Fertility 90 capsules 850mg': 'Ovanice',
        'Pro-D3 50,000 IU': 'Pro-D3',
        'Ovanice': 'Ovanice',
    }
    for q, expected_name in cases_exact.items():
        result = search_engine.search_product(q)
        assert_true(result.status == 'EXACT_MATCH', f'{q} expected exact got {result.status}')
        assert_true(result.product and expected_name.lower() in (result.product.get('name') or '').lower(), f'{q} wrong product {result.product}')
        assert_true(result.product.get('price'), f'{q} no price')

    # Brand/family guard: do not show other Rilastil products.
    result=search_engine.search_product('Rilastil xerolact PB متوفر')
    assert_true(result.status == 'NOT_AVAILABLE', f'rilastil expected not available got {result.status}')
    assert_true(not result.products, 'rilastil must not list other products')

    # Cosmetic type guard.
    result=search_engine.search_product('Cerave Hydrating Cleanser')
    assert_true(result.status in {'EXACT_MATCH','NOT_AVAILABLE','COSMETIC_ALTERNATIVES'}, f'cerave cleanser status {result.status}')
    assert_no_forbidden(result.products, ['moisturizing lotion','moisturising lotion','serum','cream 454'], 'cerave cleanser type guard')
    for p in result.products:
        form=(p.get('form') or '').lower()
        name=(p.get('name') or '').lower()
        assert_true('cleanser' in form or 'cleanser' in name or 'micellair' in name, f'non-cleanser alternative {p.get("name")}')

    # Cross-category guard.
    result=search_engine.search_product('Amoclan syrup')
    assert_true(result.status in {'ASK_CLARIFICATION','EXACT_MATCH','NOT_AVAILABLE'}, f'amoclan status {result.status}')
    assert_no_forbidden(result.products, ['vitamin syrup'], 'amoclan no supplement syrup')
    for p in result.products:
        assert_true((p.get('category') or '') == 'medicine', f'amoclan non-medicine {p.get("name")}')

    # Medicine variants and duplicates.
    result=search_engine.search_product('فلاجيل')
    assert_true(result.status == 'ASK_CLARIFICATION', 'flagyl brand only should clarify')
    result=search_engine.search_product('فلاجيل شراب')
    assert_true(result.status in {'EXACT_MATCH','ASK_CLARIFICATION','NOT_AVAILABLE'}, 'flagyl syrup status')
    for p in result.products:
        assert_true((p.get('form') or '') in {'syrup','suspension'}, f'flagyl syrup wrong form {p.get("name")}')
    for q in ['Flagyl 500mg','Janumet 50/1000mg','Cipralex 10mg']:
        result=search_engine.search_product(q)
        assert_true(result.status == 'ASK_CLARIFICATION', f'{q} duplicate conflict should clarify, got {result.status}')
        assert_true(result.products, f'{q} should provide reviewed choices, not first price')

    # Vision slot matcher.
    result=search_engine.search_from_vision_slots({'brand':'Pro-D3','product_name':'Pro-D3','strength':'50,000 IU','pack':'15 capsules','visible_text':'Pro-D3 50,000 IU vitamin k2 15 capsules','confidence':0.92})
    assert_true(result.status == 'EXACT_MATCH' and 'Pro-D3' in result.product.get('name',''), 'vision prod3')
    result=search_engine.search_from_vision_slots({'brand':'Ovanice','product_name':'Ovanice Female Fertility','strength':'850mg','pack':'90 capsules','visible_text':'Ovanice Female Fertility 90 capsules 850mg','confidence':0.9})
    assert_true(result.status == 'EXACT_MATCH' and 'Ovanice' in result.product.get('name',''), 'vision ovanice')
    result=search_engine.search_from_vision_slots({'brand':'','product_name':'cream tube','size':'50ml','visible_text':'cream tube 50ml','confidence':0.9})
    assert_true(result.status in {'LOW_CONFIDENCE','IMAGE_UNCLEAR'}, f'generic image should not match {result.status}')

    print('SAFE_MATCHING_ACCEPTANCE_PASS=41')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
