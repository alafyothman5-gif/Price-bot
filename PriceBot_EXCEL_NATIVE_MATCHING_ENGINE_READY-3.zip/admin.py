from __future__ import annotations

import hashlib
import hmac
import html
import os
import re
import secrets
import shutil
import subprocess
import tempfile
import time
import sys
from pathlib import Path
from typing import Dict

from fastapi import APIRouter, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse

import database
try:
    import product_identity
    import search_engine
except Exception:
    product_identity = None
    search_engine = None

router = APIRouter()
ADMIN_KEY = os.getenv("ADMIN_KEY", "").strip()
SESSION_COOKIE = "pricebot_admin_session"
SESSION_TTL_SECONDS = int(os.getenv("PRICEBOT_ADMIN_SESSION_TTL_SECONDS", "21600") or 21600)
_RATE: Dict[str, list] = {}


def _is_strong_admin_key(value: str) -> bool:
    if not value or value in {"change_me", "admin", "password", "123456"}:
        return False
    return len(value) >= 16


def validate_admin_config(strict: bool = True) -> None:
    if strict and not _is_strong_admin_key(ADMIN_KEY):
        raise RuntimeError("ADMIN_SECURITY_REFUSED: set a strong ADMIN_KEY in .env; default/change_me is forbidden")


def _sign(payload: str) -> str:
    key = (ADMIN_KEY or "missing").encode("utf-8")
    return hmac.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _make_session() -> str:
    ts = str(int(time.time()))
    nonce = secrets.token_urlsafe(16)
    payload = f"{ts}:{nonce}"
    return f"{payload}:{_sign(payload)}"


def _session_ok(token: str) -> bool:
    try:
        ts, nonce, sig = (token or "").split(":", 2)
        payload = f"{ts}:{nonce}"
        if not hmac.compare_digest(sig, _sign(payload)):
            return False
        return time.time() - int(ts) <= SESSION_TTL_SECONDS
    except Exception:
        return False


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return forwarded or (request.client.host if request.client else "unknown")


def _rate_ok(request: Request, limit: int = 20, window: int = 60) -> bool:
    ip = _client_ip(request)
    now = time.time()
    bucket = _RATE.setdefault(ip, [])
    bucket[:] = [x for x in bucket if now - x < window]
    if len(bucket) >= limit:
        return False
    bucket.append(now)
    return True


def _authorized(request: Request) -> bool:
    if not _is_strong_admin_key(ADMIN_KEY):
        return False
    return _session_ok(request.cookies.get(SESSION_COOKIE, ""))


def _require_auth(request: Request):
    if not _rate_ok(request):
        return PlainTextResponse("rate limited", status_code=429)
    if not _authorized(request):
        return RedirectResponse("/admin/login", status_code=303)
    return None


def _layout(title: str, body: str) -> str:
    return f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>
<title>{html.escape(title)}</title><style>
body{{font-family:Arial,sans-serif;margin:30px;background:#f7f7f7;color:#222}}table{{border-collapse:collapse;background:white;width:100%}}td,th{{border:1px solid #ddd;padding:8px;vertical-align:top}}.card{{background:white;padding:16px;border-radius:10px;margin-bottom:16px;box-shadow:0 1px 4px #ddd}}input,select,button{{padding:8px;margin:4px}}button{{cursor:pointer}}.danger{{color:#9b111e}}.ok{{color:#087b32}}pre{{white-space:pre-wrap;max-height:220px;overflow:auto}}
a{{color:#0645ad}}</style></head><body>{body}</body></html>"""


@router.get("/admin/login", response_class=HTMLResponse)
def admin_login_form(request: Request):
    if not _is_strong_admin_key(ADMIN_KEY):
        return HTMLResponse("ADMIN_KEY غير مضبوط أو ضعيف. اضبط ADMIN_KEY قوي في .env ثم أعد التشغيل.", status_code=503)
    body = """
    <div class='card'><h2>تسجيل دخول لوحة PriceBot</h2>
    <form method='post' action='/admin/login'>
      <input type='password' name='admin_key' placeholder='ADMIN_KEY' autofocus />
      <button type='submit'>دخول</button>
    </form></div>
    """
    return _layout("Admin Login", body)


@router.post("/admin/login")
def admin_login(request: Request, admin_key: str = Form(...)):
    if not _rate_ok(request, limit=8, window=60):
        return PlainTextResponse("rate limited", status_code=429)
    if not _is_strong_admin_key(ADMIN_KEY) or not hmac.compare_digest(admin_key, ADMIN_KEY):
        database.audit_admin("admin_login_failed", ip=_client_ip(request))
        return PlainTextResponse("Unauthorized", status_code=401)
    database.audit_admin("admin_login_ok", ip=_client_ip(request))
    resp = RedirectResponse("/admin", status_code=303)
    resp.set_cookie(SESSION_COOKIE, _make_session(), httponly=True, secure=False, samesite="lax", max_age=SESSION_TTL_SECONDS)
    return resp


@router.post("/admin/logout")
def admin_logout(request: Request):
    resp = RedirectResponse("/admin/login", status_code=303)
    resp.delete_cookie(SESSION_COOKIE)
    return resp


@router.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request):
    auth = _require_auth(request)
    if auth: return auth
    products = database.count_products()
    identity_count = database.count_table("product_identity_registry")
    learning_pending = database.count_table("learning_inbox")
    catalog_jobs = database.list_catalog_import_jobs(10)
    jobs = "".join(f"<tr><td>{j['id']}</td><td>{html.escape(j.get('filename') or '')}</td><td>{html.escape(j.get('status') or '')}</td><td>{html.escape(j.get('created_at') or '')}</td></tr>" for j in catalog_jobs) or "<tr><td colspan='4'>لا توجد عمليات رفع</td></tr>"
    body = f"""
    <div class='card'><h2>لوحة PriceBot</h2>
    <p>عدد المنتجات: {products}</p><p>Product Identity Registry: {identity_count}</p>
    <p>Learning Inbox: <a href='/admin/learning'>فتح الصندوق</a> ({learning_pending})</p>
    <p>Catalog Import: <a href='/admin/catalog'>رفع Excel جديد</a></p>
    <form method='post' action='/admin/logout'><button>خروج</button></form></div>
    <div class='card'><h3>آخر عمليات الكتالوج</h3><table><tr><th>#</th><th>الملف</th><th>الحالة</th><th>التاريخ</th></tr>{jobs}</table></div>
    """
    return _layout("PriceBot Admin", body)


@router.get("/admin/learning", response_class=HTMLResponse)
def learning_inbox(request: Request):
    auth = _require_auth(request)
    if auth: return auth
    items = database.list_learning_inbox("pending", 100)
    rows = []
    for item in items:
        candidates = html.escape(str(item.get("candidate_products") or ""))[:1000]
        rows.append(f"""
        <tr>
          <td>{item.get('id')}</td>
          <td>{html.escape(item.get('customer_query') or '')}</td>
          <td>{html.escape(item.get('vision_text') or item.get('raw_vision_text') or '')[:500]}</td>
          <td>{html.escape(item.get('decision') or '')}<br>{html.escape(item.get('reason') or '')}</td>
          <td><pre>{candidates}</pre></td>
          <td>
            <form method='post' action='/admin/learning/{item.get('id')}/approve'>
              <input name='product_db_id' placeholder='product DB id' />
              <select name='field'><option value='aliases'>alias</option><option value='ocr_keywords'>ocr_keyword</option></select>
              <button type='submit'>اعتماد وتعليم</button>
            </form>
            <form method='post' action='/admin/learning/{item.get('id')}/not-in-catalog'><button type='submit'>غير موجود في الكتالوج</button></form>
            <form method='post' action='/admin/learning/{item.get('id')}/ignore'><button type='submit'>تجاهل</button></form>
          </td>
        </tr>
        """)
    body = f"""
    <div class='card'><h2>Learning Inbox</h2><p>الفشل أو LOW_CONFIDENCE أو NOT_AVAILABLE يُسجل هنا. بعد اعتماد alias/OCR يعاد بناء الفهارس بدون restart.</p></div>
    <table><tr><th>#</th><th>query</th><th>vision text</th><th>decision/reason</th><th>candidates</th><th>admin action</th></tr>{''.join(rows) or "<tr><td colspan='6'>لا توجد عناصر pending</td></tr>"}</table>
    """
    return _layout("Learning Inbox", body)


@router.post("/admin/learning/{learning_id}/approve")
def approve_learning(request: Request, learning_id: int, product_db_id: int = Form(...), field: str = Form("aliases")):
    auth = _require_auth(request)
    if auth: return auth
    try:
        database.approve_learning_alias(int(learning_id), int(product_db_id), field=field)
        if product_identity: product_identity.rebuild_product_identity_registry()
        if search_engine: search_engine.rebuild_search_index(); search_engine.invalidate_memory_index()
        database.audit_admin("learning_approved", ip=_client_ip(request), details={"learning_id": learning_id, "product_db_id": product_db_id, "field": field})
    except Exception as exc:
        return PlainTextResponse(f"failed: {type(exc).__name__}: {exc}", status_code=400)
    return RedirectResponse("/admin/learning", status_code=303)


@router.post("/admin/learning/{learning_id}/not-in-catalog")
def learning_not_in_catalog(request: Request, learning_id: int):
    auth = _require_auth(request)
    if auth: return auth
    database.update_learning_status(learning_id, "not_in_catalog", "not_in_catalog")
    database.audit_admin("learning_not_in_catalog", ip=_client_ip(request), details={"learning_id": learning_id})
    return RedirectResponse("/admin/learning", status_code=303)


@router.post("/admin/learning/{learning_id}/ignore")
def learning_ignore(request: Request, learning_id: int):
    auth = _require_auth(request)
    if auth: return auth
    database.update_learning_status(learning_id, "ignored", "ignore")
    database.audit_admin("learning_ignored", ip=_client_ip(request), details={"learning_id": learning_id})
    return RedirectResponse("/admin/learning", status_code=303)


@router.get("/admin/catalog", response_class=HTMLResponse)
def catalog_form(request: Request):
    auth = _require_auth(request)
    if auth: return auth
    jobs = database.list_catalog_import_jobs(20)
    rows = "".join(f"<tr><td>{j['id']}</td><td>{html.escape(j.get('filename') or '')}</td><td>{html.escape(j.get('status') or '')}</td><td><pre>{html.escape((j.get('report_text') or '')[:800])}</pre></td><td><form method='post' action='/admin/catalog/{j['id']}/approve'><button>Approve</button></form><form method='post' action='/admin/catalog/{j['id']}/cancel'><button>Cancel</button></form></td></tr>" for j in jobs) or "<tr><td colspan='5'>لا توجد عمليات</td></tr>"
    body = f"""
    <div class='card'><h2>رفع Excel جديد</h2>
    <p>يتم بناء DB staging خارج الإنتاج وتشغيل verify قبل أي اعتماد.</p>
    <form method='post' action='/admin/catalog/upload' enctype='multipart/form-data'>
      <input type='file' name='file' accept='.xlsx,.xls' />
      <button type='submit'>رفع وفحص staging</button>
    </form></div>
    <table><tr><th>#</th><th>file</th><th>status</th><th>report</th><th>action</th></tr>{rows}</table>
    """
    return _layout("Catalog Import", body)


@router.post("/admin/catalog/upload")
async def catalog_upload(request: Request, file: UploadFile = File(...)):
    auth = _require_auth(request)
    if auth: return auth
    suffix = Path(file.filename or "upload.xlsx").suffix or ".xlsx"
    tmpdir = Path(tempfile.mkdtemp(prefix="pricebot_catalog_"))
    excel_path = tmpdir / ("upload" + suffix)
    staging_db = tmpdir / "staging_pricebot.db"
    content = await file.read()
    excel_path.write_bytes(content)
    job_id = database.create_catalog_import_job(file.filename or "upload.xlsx", str(staging_db), status="staging_started")
    root = Path(__file__).resolve().parent
    py = Path(os.getenv("PRICEBOT_APP_DIR", str(root))) / "venv" / "bin" / "python"
    if not py.exists(): py = Path(sys.executable)
    def run(cmd):
        return subprocess.run([str(py)] + cmd, cwd=str(root), text=True, capture_output=True, timeout=600)
    dry = run(["tools/import_master_excel.py", str(excel_path), "--db-path", str(staging_db), "--dry-run"])
    imp = run(["tools/import_master_excel.py", str(excel_path), "--db-path", str(staging_db)]) if dry.returncode == 0 else dry
    verify = run(["tools/verify_production.py", "--db-path", str(staging_db), "--excel-path", str(excel_path)]) if imp.returncode == 0 else imp
    report = "\n---DRY RUN---\n" + dry.stdout[-4000:] + dry.stderr[-1000:] + "\n---IMPORT---\n" + imp.stdout[-4000:] + imp.stderr[-1000:] + "\n---VERIFY---\n" + verify.stdout[-4000:] + verify.stderr[-1000:]
    status = "ready_for_approval" if dry.returncode == 0 and imp.returncode == 0 and verify.returncode == 0 else "failed"
    database.update_catalog_import_job(job_id, status=status, report_text=report, staging_db_path=str(staging_db))
    database.audit_admin("catalog_upload_staged", ip=_client_ip(request), details={"job_id": job_id, "status": status})
    return RedirectResponse("/admin/catalog", status_code=303)


@router.post("/admin/catalog/{job_id}/approve")
def catalog_approve(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth: return auth
    job = database.get_catalog_import_job(job_id)
    if not job or job.get("status") != "ready_for_approval":
        return PlainTextResponse("job not ready", status_code=400)
    staging = Path(job.get("staging_db_path") or "")
    if not staging.exists():
        return PlainTextResponse("staging db missing", status_code=400)
    backup = database.backup_db("before_catalog_admin_approve") if database.get_db_path().exists() else None
    shutil.copy2(staging, database.get_db_path())
    rebuild_notes = []
    try:
        if product_identity:
            product_identity.rebuild_product_identity_registry()
            rebuild_notes.append("identity_registry_rebuilt")
        if search_engine:
            search_engine.rebuild_search_index()
            search_engine.invalidate_memory_index()
            rebuild_notes.append("search_index_rebuilt_cache_cleared")
        try:
            import guided_commerce
            guided_commerce.rebuild_guided_index()
            rebuild_notes.append("guided_index_rebuilt")
        except Exception as exc:
            rebuild_notes.append(f"guided_index_warning:{type(exc).__name__}")
    except Exception as exc:
        database.audit_admin("catalog_approve_rebuild_failed", ip=_client_ip(request), details={"job_id": job_id, "error": repr(exc)})
        return PlainTextResponse(f"approved db copy failed during rebuild: {type(exc).__name__}: {exc}", status_code=500)
    database.update_catalog_import_job(job_id, status="approved", report_text=(job.get("report_text") or "") + f"\nAPPROVED backup={backup} rebuild={rebuild_notes}")
    database.audit_admin("catalog_approved", ip=_client_ip(request), details={"job_id": job_id, "backup": str(backup), "rebuild": rebuild_notes})
    return RedirectResponse("/admin/catalog", status_code=303)


@router.post("/admin/catalog/{job_id}/cancel")
def catalog_cancel(request: Request, job_id: int):
    auth = _require_auth(request)
    if auth: return auth
    database.update_catalog_import_job(job_id, status="cancelled")
    database.audit_admin("catalog_cancelled", ip=_client_ip(request), details={"job_id": job_id})
    return RedirectResponse("/admin/catalog", status_code=303)


@router.post("/admin/orders/{order_id}/{status}")
def update_order(request: Request, order_id: int, status: str):
    auth = _require_auth(request)
    if auth: return auth
    if status not in {"pending", "confirmed", "rejected", "done"}:
        return PlainTextResponse("bad status", status_code=400)
    database.update_order_status(order_id, status)
    database.audit_admin("order_status_update", ip=_client_ip(request), details={"order_id": order_id, "status": status})
    return {"ok": True}
