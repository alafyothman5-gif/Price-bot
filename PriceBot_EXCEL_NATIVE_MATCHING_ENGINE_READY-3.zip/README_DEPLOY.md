# PriceBot Excel Native Deploy

Default production target for this release:

```bash
/opt/pricebot_clean
```

Do not deploy this release by calling `tools/import_master_excel.py` manually. The accepted production path is Excel Native:

```bash
tools/rebuild_database_from_any_excel.py
```

## Clean install

From the extracted release directory on the server:

```bash
sudo PRICEBOT_TARGET_DIR=/opt/pricebot_clean PRICEBOT_SERVICE_NAME=pricebot.service ./clean_install_pricebot.sh
```

The clean installer will:

1. Back up the existing `.env`, service file, and DB if present.
2. Copy release files to `/opt/pricebot_clean`.
3. Create a venv and install requirements.
4. Compile Python files.
5. Build a new temp DB using:

```bash
./venv/bin/python tools/rebuild_database_from_any_excel.py --excel /opt/pricebot_clean/products_master_ready.xlsx --db-path <tmp_db>
```

6. Run verification and acceptance tests on the temp DB.
7. Swap the DB only after success.
8. Run verification and acceptance tests again on `/opt/pricebot_clean/pricebot.db`.
9. Restart `pricebot.service`.

## Required acceptance after clean install

```bash
cd /opt/pricebot_clean
PRICEBOT_MATCH_LOG=0 ./venv/bin/python tools/run_acceptance_tests.py --db-path /opt/pricebot_clean/pricebot.db
```

Expected highlights:

```text
PROPOLI vision -> EXACT_MATCH
Hemazym vision -> EXACT_MATCH
Mari Female vision -> EXACT_MATCH
MEBO Scar vision -> EXACT_MATCH
فلاجيل شراب -> syrup/suspension only
Panadol -> ASK_CLARIFICATION
```

Expected native index scale with the included Excel:

```text
products_count=5791
product_identity_registry=5791
product_search_index≈92817
guided_catalog_index≈3558
```

## Rebuild catalog later without full clean install

```bash
cd /opt/pricebot_clean
PRICEBOT_TARGET_DIR=/opt/pricebot_clean PRICEBOT_SERVICE_NAME=pricebot.service ./tools/install_excel_native_rebuild.sh /opt/pricebot_clean/products_master_ready.xlsx
```

The script supports other target directories through `PRICEBOT_TARGET_DIR`; it is not hardcoded to `/opt/pricebot`.

## Files intentionally excluded from the ZIP

```text
.env
pricebot.db
venv
backups
__pycache__
secrets
```
