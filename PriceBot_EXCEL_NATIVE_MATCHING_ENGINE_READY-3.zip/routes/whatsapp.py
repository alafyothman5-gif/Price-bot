"""WhatsApp routes are currently mounted in app.py for deployment compatibility."""
