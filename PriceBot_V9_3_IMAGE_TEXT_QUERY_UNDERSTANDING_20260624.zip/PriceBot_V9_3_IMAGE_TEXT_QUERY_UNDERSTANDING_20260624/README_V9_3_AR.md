# PriceBot V9.3 Image Text Query Understanding

نسخة جاهزة للرفع على GitHub والتركيب فوق السيرفر الحالي.

## تحتوي على
- كل تعديلات V9.2 Text Query Understanding.
- إصلاح جديد لمسار الصورة حتى يستخدم نفس طبقة فهم النص قبل المطابقة.
- لا تحتوي على `.env` الحقيقي.
- لا تحتوي على قاعدة بيانات.

## لا تغير
- PostgreSQL الموجود على السيرفر.
- Redis/Valkey.
- Caddy.
- ملف البيئة `.env` الحقيقي.

## ملف مهم
`app/README_IMAGE_TEXT_QUERY_UNDERSTANDING_AR.md`
