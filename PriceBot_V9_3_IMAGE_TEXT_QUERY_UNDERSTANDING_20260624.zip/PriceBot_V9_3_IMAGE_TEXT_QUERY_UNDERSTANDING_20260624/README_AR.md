# PriceBot V9.1 Server Final — Code Only

هذه نسخة كود فقط مأخوذة من السيرفر الحالي بعد كل تعديلات التيرمنل.

## مهم
هذه النسخة لا تحتوي:
- قاعدة البيانات PostgreSQL.
- ملف `pricebot.db`.
- ملف `.env` الحقيقي.
- مفاتيح WhatsApp / Meta / Gemini / OpenRouter.

## الحالة الحالية على السيرفر وقت التصدير
- الخدمة: `pricebot-whatsapp-gemini.service`
- المسار: `/opt/pricebot_whatsapp_gemini`
- المنفذ: `127.0.0.1:8090`
- قاعدة البيانات: PostgreSQL محلي
- Redis/Valkey: مفعّل
- المنتجات الحالية مأخوذة من `current_products.xlsx`
- سكربت التحديث الدوري:
  `bash /opt/pricebot_whatsapp_gemini/scripts/sync_products_from_github.sh`

## آخر تعديلات موجودة
- PostgreSQL بدل SQLite.
- تنظيف قاعدة المنتجات وجعلها من Excel الحالي فقط.
- سكربت مزامنة من GitHub Excel.
- Redis state/rate limit.
- Queue safety.
- Health V9.
- إصلاحات PostgreSQL compatibility.
- إصلاح عرض السعر العلمي إن كان موجودًا.
- محاولات تحسين فهم الجمل العربية والبحث الصوتي.

## ملاحظة
قاعدة البيانات بقيت على السيرفر، وهذا الملف مخصص للتطوير المستقبلي فقط.
