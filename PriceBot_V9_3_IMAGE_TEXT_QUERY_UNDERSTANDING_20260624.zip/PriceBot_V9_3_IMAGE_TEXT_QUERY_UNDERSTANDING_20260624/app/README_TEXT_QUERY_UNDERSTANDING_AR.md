# تطوير فهم رسائل الزبائن العربية/العامية

تمت إضافة طبقة `Text Query Understanding` في مسار البحث النصي الحقيقي داخل `app.py` قبل تنفيذ قرار “غير متوفر”.

## الملفات المعدلة/المضافة

- `app.py`
  - إضافة استخراج الاستعلام من جملة الزبون قبل `product_index.search`.
  - البحث يتم بالترتيب عبر الاستعلامات المستخرجة ثم النص الأصلي ثم الترشيحات الصوتية من المنتجات المتوفرة.
  - إضافة logging للتشخيص:
    - `TEXT_QUERY_EXTRACTED`
    - `TEXT_QUERY_MATCH`
    - `TEXT_QUERY_SEARCH_ERROR`
  - دعم البحث حتى لو كتب الزبون سؤال المنتج مباشرة قبل الضغط على زر “بحث باسم دواء”.

- `text_query_understanding.py`
  - دالة عامة:
    - `extract_product_query_from_customer_text(text: str) -> list[str]`
  - حذف stopwords عربية/إنجليزية.
  - توليد Latin phonetic variants للنص العربي.
  - مقارنة phonetic عامة مع المنتجات المتوفرة داخل `ProductIndex`، بدون hardcoded product aliases.

- `scripts/test_arabic_text_query.py`
  - سكربت اختبار داخلي لا يرسل WhatsApp ولا يغير قاعدة البيانات.
  - يطبع candidates والنتائج المطابقة من PostgreSQL/ProductIndex.

## ملاحظات مهمة

- لم يتم تغيير Gemini/Vision.
- لم يتم تغيير شكل رسائل WhatsApp.
- لم يتم تعديل قاعدة البيانات.
- لا توجد إضافات منتجات hardcoded.
- المطابقة الصوتية تعتمد فقط على المنتجات المتوفرة المحملة من PostgreSQL عبر `ProductIndex`.

## تشغيل الاختبار على السيرفر

من داخل مجلد التطبيق:

```bash
cd /root/pricebot/app  # أو مسار التطبيق الفعلي
source .venv/bin/activate
python scripts/test_arabic_text_query.py
```

يجب أن تظهر حالات مثل:

- `متوفر عندكم اموكلان` → نفس نتيجة `Amoclan`
- `نبي سعر فيروكسيل` → نفس نتيجة `Feroxyl` إذا موجود
- `عندكم بندول` → `Panadol` إذا موجود
