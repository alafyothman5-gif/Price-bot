# PriceBot WhatsApp Final UI

هذه النسخة نهائية حسب المطلوب:

- WhatsApp فقط، بدون صفحات ويب أو لوحة كتالوج.
- عند أول رسالة من الزبون، سواء عربية أو إنجليزية، يرسل البوت رسالة ترحيب مع زرين:
  - بحث نص
  - بحث بصورة
- بحث النص:
  - يطلب اسم الدواء.
  - إذا الاسم عام مثل Panadol يعرض قائمة WhatsApp قابلة للضغط لاختيار المنتج.
  - إذا الاسم محدد يرجع: متوفر والسعر.
  - إذا غير متوفر يرجع رسالة اعتذار واضحة.
- بحث الصورة:
  - يطلب صورة واضحة لعلبة الدواء أو المنتج فقط.
  - يستخرج اسم المنتج بالصورة عبر Vision/Gemini ثم يطابقه مع قاعدة المنتجات المتوفرة.
  - إذا المنتج متوفر يرجع السعر.
  - إذا الصورة روشتة أو ليست صورة منتج، يطلب صورة علبة الدواء فقط.
- يدعم اختيار المنتج من قائمة WhatsApp Interactive List، بدون كتابة رقم.

## التشغيل

انسخ ملفات المشروع إلى السيرفر، واحفظ ملف `.env` وقاعدة البيانات الحالية.

مثال:

```bash
cd /opt/pricebot_whatsapp_gemini
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8090
```

## متطلبات مهمة في .env

يجب أن تكون مفاتيح WhatsApp وOpenRouter/Gemini موجودة:

- WHATSAPP_ACCESS_TOKEN أو META_TOKEN
- WHATSAPP_PHONE_NUMBER_ID أو PHONE_NUMBER_ID
- WHATSAPP_VERIFY_TOKEN أو VERIFY_TOKEN
- OPENROUTER_API_KEY أو AI_OPENROUTER_KEY أو GEMINI_KEY حسب الإعداد الحالي
- PRICEBOT_DB_FILE أو PRICEBOT_DB_PATH يشير إلى قاعدة المنتجات الصحيحة
