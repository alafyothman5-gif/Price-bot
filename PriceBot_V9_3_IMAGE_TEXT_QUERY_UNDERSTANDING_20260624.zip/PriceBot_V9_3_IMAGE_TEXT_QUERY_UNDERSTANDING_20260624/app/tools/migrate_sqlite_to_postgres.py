#!/usr/bin/env python3
"""Migrate the existing PriceBot SQLite database to PostgreSQL.

This tool is intentionally conservative:
- It never deletes the source SQLite file.
- It creates/updates the PostgreSQL schema through database.init_db().
- It copies every user table discovered in SQLite, preserving integer ids.
- It can replace destination rows only when --replace is explicitly passed.
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple


def quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def map_sqlite_type(sqlite_type: str, pk: bool = False) -> str:
    t = (sqlite_type or "TEXT").upper()
    if pk:
        return "BIGINT PRIMARY KEY"
    if "INT" in t:
        return "BIGINT"
    if any(x in t for x in ["REAL", "FLOA", "DOUB"]):
        return "DOUBLE PRECISION"
    if any(x in t for x in ["NUM", "DEC"]):
        return "NUMERIC"
    if "BLOB" in t:
        return "BYTEA"
    return "TEXT"


def sqlite_tables(conn: sqlite3.Connection) -> List[str]:
    rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
    return [str(r[0]) for r in rows]


def sqlite_columns(conn: sqlite3.Connection, table: str) -> List[Dict[str, Any]]:
    rows = conn.execute(f"PRAGMA table_info({quote_ident(table)})").fetchall()
    return [{"cid": r[0], "name": r[1], "type": r[2], "notnull": r[3], "default": r[4], "pk": bool(r[5])} for r in rows]


def pg_table_exists(pg, table: str) -> bool:
    row = pg.execute("SELECT to_regclass(%s) AS reg", (table,)).fetchone()
    return bool(row and list(row.values())[0])


def pg_columns(pg, table: str) -> List[str]:
    rows = pg.execute("SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s", (table,)).fetchall()
    out = []
    for row in rows:
        if isinstance(row, dict):
            out.append(str(row.get("column_name")))
        else:
            out.append(str(row[0]))
    return out


def ensure_pg_table(pg, table: str, columns: List[Dict[str, Any]]) -> None:
    if not pg_table_exists(pg, table):
        defs = []
        has_pk = False
        for col in columns:
            name = col["name"]
            pk = bool(col.get("pk")) and name == "id"
            has_pk = has_pk or pk
            defs.append(f"{quote_ident(name)} {map_sqlite_type(col.get('type') or 'TEXT', pk=pk)}")
        if not defs:
            return
        pg.execute(f"CREATE TABLE IF NOT EXISTS {quote_ident(table)} ({', '.join(defs)})")
    existing = set(pg_columns(pg, table))
    for col in columns:
        name = str(col["name"])
        if name not in existing:
            pg.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(name)} {map_sqlite_type(col.get('type') or 'TEXT', pk=False)}")


def copy_table(sqlite_conn: sqlite3.Connection, pg, table: str, columns: List[str], batch_size: int = 1000) -> int:
    if not columns:
        return 0
    qcols = ", ".join(quote_ident(c) for c in columns)
    placeholders = ", ".join(["%s"] * len(columns))
    insert_sql = f"INSERT INTO {quote_ident(table)} ({qcols}) VALUES ({placeholders}) ON CONFLICT DO NOTHING"
    offset = 0
    total = 0
    sqlite_conn.row_factory = sqlite3.Row
    while True:
        rows = sqlite_conn.execute(f"SELECT {qcols} FROM {quote_ident(table)} LIMIT ? OFFSET ?", (batch_size, offset)).fetchall()
        if not rows:
            break
        payload = [tuple(row[c] for c in columns) for row in rows]
        pg.executemany(insert_sql, payload)
        total += len(payload)
        offset += len(payload)
    return total


def reset_sequence(pg, table: str) -> None:
    try:
        row = pg.execute(f"SELECT MAX(id) AS max_id FROM {quote_ident(table)}").fetchone()
        max_id = 0
        if row:
            max_id = int((row.get("max_id") if isinstance(row, dict) else row[0]) or 0)
        pg.execute("SELECT setval(pg_get_serial_sequence(%s, 'id'), %s, true)", (table, max_id if max_id > 0 else 1))
    except Exception:
        pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sqlite", required=True, help="Existing pricebot.db path")
    ap.add_argument("--postgres", required=True, help="PostgreSQL DATABASE_URL")
    ap.add_argument("--replace", action="store_true", help="Truncate destination tables before copying")
    ap.add_argument("--min-products", type=int, default=int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000))
    args = ap.parse_args()

    sqlite_path = Path(args.sqlite).expanduser().resolve()
    if not sqlite_path.exists():
        raise SystemExit(f"SQLITE_NOT_FOUND: {sqlite_path}")

    os.environ["DATABASE_URL"] = args.postgres
    os.environ.setdefault("PRICEBOT_PRODUCTION_MODE", "0")
    os.environ.setdefault("PRICEBOT_STRICT_DB_STARTUP", "0")
    os.environ.setdefault("PRICEBOT_REQUIRE_POSTGRES_PRODUCTION", "0")

    app_dir = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(app_dir))

    import database  # noqa: E402

    if not database.IS_POSTGRES:
        raise SystemExit("POSTGRES_URL_NOT_ACTIVE")

    sqlite_conn = sqlite3.connect(str(sqlite_path))
    sqlite_conn.row_factory = sqlite3.Row

    database.init_db(run_production_guard=False)
    copied = {}
    with database.connect() as pg:
        if args.replace:
            tables = sqlite_tables(sqlite_conn)
            for table in reversed(tables):
                try:
                    if pg_table_exists(pg, table):
                        pg.execute(f"TRUNCATE TABLE {quote_ident(table)} RESTART IDENTITY CASCADE")
                except Exception:
                    pass
        for table in sqlite_tables(sqlite_conn):
            cols_meta = sqlite_columns(sqlite_conn, table)
            if not cols_meta:
                continue
            ensure_pg_table(pg, table, cols_meta)
            cols = [c["name"] for c in cols_meta]
            copied[table] = copy_table(sqlite_conn, pg, table, cols)
            if "id" in cols:
                reset_sequence(pg, table)
        try:
            database.apply_performance_hardening(pg)
        except Exception as exc:
            print("POSTGRES_HARDENING_WARNING", repr(exc))

    product_count = 0
    with database.connect() as pg:
        try:
            row = pg.execute("SELECT COUNT(*) AS count FROM products").fetchone()
            product_count = int((row.get("count") if isinstance(row, dict) else row[0]) or 0)
        except Exception:
            pass
    if product_count < args.min_products:
        raise SystemExit(f"MIGRATION_PRODUCTS_GUARD_FAILED products={product_count} min={args.min_products}")
    print("MIGRATION_OK")
    print("products", product_count)
    for table, count in sorted(copied.items()):
        print(f"copied.{table}={count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# PRICEBOT_V9_POSTGRES_DATETIME_HOTFIX_OK


# PRICEBOT_V9_POSTGRES_BOOLEAN_DATETIME_HOTFIX_OK


# PRICEBOT_MANUAL_V9_POSTGRES_HOTFIX_OK
