# PriceBot WhatsApp Only

هذه نسخة مخففة من البوت:

- لا توجد صفحة إلكترونية للكتالوج.
- لا توجد لوحة تاجر أو لوحة أدمن داخل FastAPI.
- المسارات المتاحة فقط:
  - `/webhook` و`/webhook/whatsapp` لاستقبال واتساب.
  - `/health` للفحص.
  - `/` يرجع JSON بسيط فقط.
- مطابقة المنتجات تتم عبر Gemini/OpenRouter فقط.
- رد البوت عند وجود المنتج هو السعر فقط، بدون اسم المنتج وبدون أزرار وبدون بدائل.

## المتغيرات المهمة

ضعها في `.env`:

```env
PRICEBOT_DB_PATH=/opt/pricebot_whatsapp_gemini/pricebot.db
WHATSAPP_VERIFY_TOKEN=...
WHATSAPP_ACCESS_TOKEN=...
WHATSAPP_PHONE_NUMBER_ID=...
OPENROUTER_API_KEY=...
OPENROUTER_MODEL=google/gemini-2.5-flash-lite
OPENROUTER_TEXT_MODEL=google/gemini-2.5-flash-lite
OPENROUTER_IMAGE_MATCH_MODEL=google/gemini-2.5-flash-lite
OPENROUTER_VISION_MODEL=google/gemini-2.5-flash-lite
PRICEBOT_REQUIRE_GEMINI_MATCHING=1
PRICEBOT_STRICT_TEXT_EVIDENCE_GUARD=0
PRICEBOT_CURRENCY=د.ل
```

## التشغيل

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8090 --proxy-headers
```

## ملاحظات

يجب نقل قاعدة البيانات الحالية `pricebot.db` إلى المسار المحدد في `PRICEBOT_DB_PATH`. هذه النسخة لا تحتوي على صفحة رفع Excel، لأن المطلوب بوت واتساب فقط.
