"""Gemini-only product matcher for PriceBot WhatsApp.

Matches user text or product-image evidence against the current visible products
table by asking the configured OpenRouter/Gemini model to return strict JSON.
No local/fuzzy search engine is used for customer matching.
"""
from __future__ import annotations

import json
import os
import re
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional

import httpx

import config_env
import database
from normalizer import normalize_text

MATCH_PROMPT = (
    'You are a strict pharmacy product matching assistant. Given a customer query or OCR text and a list of available products (id, name), determine whether the text clearly and uniquely matches exactly one product from the list. Return ONLY a JSON object: {"matched": true, "product_id": <id>, "name": "<name>"} if you are confident. If the text is generic, ambiguous, only a category, only an ingredient, or does not uniquely identify one product, return ONLY {"matched": false}. Do not guess. Use only the provided products list.'
)

GENERIC_OFFLINE_WORDS = {
    "cream", "gel", "lotion", "cleanser", "wash", "face", "facial", "serum", "toner",
    "sunscreen", "spf", "moisturizer", "shampoo", "conditioner", "soap", "mask", "balm",
    "tablet", "tablets", "capsule", "capsules", "syrup", "solution", "suspension", "oral",
    "mg", "ml", "g", "gm", "pack", "box", "bottle", "low", "ph",
}

EVIDENCE_VALIDATOR_STOPWORDS = GENERIC_OFFLINE_WORDS | {
    "the", "and", "or", "for", "with", "without", "plus", "extra", "new", "original",
    "creme", "ointment", "spray", "drop", "drops", "injection", "injectable", "ampoule",
    "كريم", "جل", "غسول", "شراب", "حبوب", "اقراص", "كبسولات", "قطرة", "بخاخ",
}


def _log(event: str, **kw: Any) -> None:
    safe: List[str] = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": config_env.openrouter_gemini_model([
            "OPENROUTER_IMAGE_MATCH_MODEL",
            "OPENROUTER_TEXT_MODEL",
            "OPENROUTER_MODEL",
        ]),
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def _extract_json_object(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {"matched": False}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {"matched": False}
    except Exception:
        pass
    match = re.search(r"\{.*\}", raw, flags=re.DOTALL)
    if not match:
        return {"matched": False}
    try:
        data = json.loads(match.group(0))
        return data if isinstance(data, dict) else {"matched": False}
    except Exception:
        return {"matched": False}


def _safe_product_payload(products: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    seen = set()
    for p in products:
        try:
            pid = int(p.get("id") or 0)
        except Exception:
            pid = 0
        name = str(p.get("name") or "").strip()
        if not pid or not name or pid in seen:
            continue
        seen.add(pid)
        payload.append({"id": pid, "name": name})
    return payload


def _tokens(text: str) -> List[str]:
    norm = normalize_text(text or "")
    return re.findall(r"[a-zA-Z0-9%/+-]+|[\u0600-\u06FF]+", norm)


def _looks_generic_name(name: str) -> bool:
    toks = [t for t in _tokens(name) if t not in {"the", "a", "an", "and", "or", "for"}]
    if not toks:
        return True
    strong = [t for t in toks if t not in GENERIC_OFFLINE_WORDS and not re.fullmatch(r"\d+", t)]
    return len(strong) == 0


def _offline_safe_exact_match(extracted_text: str, products: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Safe deterministic fallback for tests/offline mode only.

    It is intentionally conservative and only accepts clear product-name evidence;
    generic product names/descriptors are rejected. Production matching uses the
    OpenRouter/Gemini call when an API key is configured.
    """
    text_norm = normalize_text(extracted_text or "")
    text_compact = re.sub(r"\s+", "", text_norm)
    if not text_norm:
        return {"matched": False, "reason": "no_text"}

    candidates: List[Dict[str, Any]] = []
    for p in products:
        name = str(p.get("name") or "")
        if _looks_generic_name(name):
            continue
        name_norm = normalize_text(name)
        if not name_norm:
            continue
        name_compact = re.sub(r"\s+", "", name_norm)
        name_tokens = [t for t in _tokens(name) if t not in GENERIC_OFFLINE_WORDS]
        # Exact/contained full-name evidence.
        if name_norm == text_norm or (len(name_norm) >= 5 and name_norm in text_norm) or (len(name_compact) >= 5 and name_compact in text_compact):
            candidates.append(p)
            continue
        # Conservative token evidence: all strong product-name tokens appear in the OCR text.
        if name_tokens and len(name_tokens) >= 2 and all(t in text_norm.split() or t in text_compact for t in name_tokens):
            candidates.append(p)

    unique: Dict[int, Dict[str, Any]] = {}
    for p in candidates:
        try:
            unique[int(p.get("id") or 0)] = p
        except Exception:
            pass
    if len(unique) == 1:
        p = next(iter(unique.values()))
        return {"matched": True, "product_id": int(p["id"]), "name": p.get("name"), "source": "offline_safe_exact"}
    if len(unique) > 1:
        return {"matched": False, "reason": "ambiguous_offline", "candidate_ids": list(unique.keys())[:10]}
    return {"matched": False, "reason": "no_offline_match"}



def evidence_tokens_for_product_name(name: str) -> List[str]:
    """Important non-generic tokens that must be evidenced in image text.

    Used as a guard above Gemini so semantic similarity cannot match a product
    whose name has no textual overlap with the photographed label.
    """
    out: List[str] = []
    seen = set()
    for token in _tokens(name or ""):
        t = token.strip().lower()
        if len(t) < 3:
            continue
        if t in EVIDENCE_VALIDATOR_STOPWORDS:
            continue
        if re.fullmatch(r"\d+", t):
            continue
        if t not in seen:
            out.append(t)
            seen.add(t)
    return out


def _token_close(a: str, b: str) -> bool:
    a = normalize_text(a or "")
    b = normalize_text(b or "")
    if not a or not b:
        return False
    if a == b or a in b or b in a:
        return True
    if len(a) < 5 or len(b) < 5:
        return False
    return SequenceMatcher(None, a, b).ratio() >= 0.84


def _token_supported(token: str, evidence_tokens: List[str], evidence_compact: str) -> bool:
    token = normalize_text(token or "")
    if not token:
        return False
    if token in evidence_tokens or token in evidence_compact:
        return True
    return any(_token_close(token, e) for e in evidence_tokens)


def validate_text_evidence_for_match(image_text: str, product_name: str) -> Dict[str, Any]:
    """Return pass/fail for whether text evidence supports the selected product.

    Gemini may understand spelling mistakes, but it must not select a different
    variant from the same brand based only on one shared brand token.  Therefore
    the guard uses reciprocal approximate token coverage: product tokens must be
    evidenced in the user/OCR text, and multi-token user text must also be
    represented in the selected product name.
    """
    product_tokens = evidence_tokens_for_product_name(product_name or "")
    if not product_tokens:
        return {"passed": False, "missing_tokens": [], "matched_tokens": [], "reason": "no_product_evidence_tokens"}
    image_norm = normalize_text(image_text or "")
    image_tokens = [t for t in _tokens(image_norm) if len(t) >= 3 and t not in EVIDENCE_VALIDATOR_STOPWORDS and not re.fullmatch(r"\d+", t)]
    image_compact = re.sub(r"\s+", "", image_norm)

    matched: List[str] = []
    for token in product_tokens:
        if _token_supported(token, image_tokens, image_compact):
            matched.append(token)
    missing = [t for t in product_tokens if t not in matched]

    # Require more than a brand-only overlap when both sides contain variants.
    required_product_hits = 1 if len(product_tokens) == 1 else min(2, len(product_tokens))
    product_ok = len(matched) >= required_product_hits

    query_matched = [t for t in image_tokens if any(_token_close(t, pt) for pt in product_tokens)]
    required_query_hits = 1 if len(image_tokens) <= 1 else min(2, len(image_tokens))
    query_ok = len(query_matched) >= required_query_hits

    passed = bool(product_ok and query_ok)
    reason = "ok" if passed else "insufficient_variant_evidence"
    return {
        "passed": passed,
        "missing_tokens": missing,
        "matched_tokens": matched,
        "product_tokens": product_tokens,
        "query_tokens": image_tokens,
        "query_matched_tokens": query_matched,
        "reason": reason,
    }


async def match_extracted_text_to_product(extracted_text: str, products: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Return {matched: bool, product_id?, name?} using Gemini only."""
    text = str(extracted_text or "").strip()
    if not text:
        return {"matched": False, "reason": "empty_text"}

    product_rows = products if products is not None else database.load_product_rows(visible_only=True)
    product_payload = _safe_product_payload(product_rows)
    if not product_payload:
        return {"matched": False, "reason": "no_products"}

    cfg = _openrouter_config()
    if not cfg.get("api_key"):
        _log("GEMINI_PRODUCT_MATCH_DISABLED", reason="missing_openrouter_api_key")
        return {"matched": False, "reason": "missing_openrouter_api_key"}

    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": MATCH_PROMPT},
            {"role": "user", "content": json.dumps({"extracted_text": text, "products": product_payload}, ensure_ascii=False)},
        ],
        "temperature": 0,
        "max_tokens": 120,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    timeout = float(os.getenv("PRICEBOT_AI_IMAGE_MATCH_TIMEOUT_SECONDS", "12") or 12)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
            if resp.status_code >= 400:
                _log("GEMINI_PRODUCT_MATCH_ERROR", status=resp.status_code)
                return {"matched": False, "reason": "ai_http_error"}
            content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as exc:
        _log("GEMINI_PRODUCT_MATCH_ERROR", status=type(exc).__name__)
        return {"matched": False, "reason": "ai_exception"}

    data = _extract_json_object(content)
    if not bool(data.get("matched")):
        return {"matched": False, "reason": "ai_not_matched"}
    try:
        pid = int(data.get("product_id") or 0)
    except Exception:
        pid = 0
    if not pid:
        return {"matched": False, "reason": "ai_missing_product_id"}
    by_id = {int(p["id"]): p for p in product_payload}
    product = by_id.get(pid)
    if not product:
        _log("GEMINI_PRODUCT_MATCH_REJECTED_UNKNOWN_PRODUCT", product_id=pid)
        return {"matched": False, "reason": "ai_unknown_product_id"}
    return {"matched": True, "product_id": pid, "name": product["name"], "source": "gemini", "raw": data}
