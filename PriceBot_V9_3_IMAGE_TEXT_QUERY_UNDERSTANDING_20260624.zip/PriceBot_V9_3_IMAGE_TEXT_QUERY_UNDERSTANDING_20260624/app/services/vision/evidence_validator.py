from __future__ import annotations

"""Production-safe validation layer for AI Vision evidence.

The matcher must not search with all OCR text.  This module accepts either a
strict JSON payload from Vision or a raw model response, then returns only the
front/primary product evidence that is allowed to affect matching.
"""

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from normalizer import normalize_text

INGREDIENT_NOISE = {
    "folic", "folic acid", "vitamin", "vitamin b12", "b12", "iron", "zinc",
    "collagen", "hyaluronic", "hyaluronic acid", "spf", "niacinamide",
    "ceramide", "ceramides", "retinol", "caffeine", "paracetamol",
    "magnesium", "calcium", "omega", "dha", "epa", "biotin", "keratin",
    "acid", "sodium", "potassium", "chloride", "extract", "aqua", "water",
    "fragrance", "perfume", "glycerin", "panthenol", "allantoin",
}

BACKGROUND_HINTS = {
    "background", "shelf", "ingredient", "ingredients", "composition", "contains",
    "with", "plus", "supports", "health", "skin", "face", "body", "new", "daily",
    "laboratoires", "laboratoire", "dermatologique", "dermatological", "made in",
}

WEAK_TITLE_WORDS = {
    "cream", "gel", "lotion", "serum", "cleanser", "wash", "foam", "skin", "face",
    "body", "tablet", "capsules", "capsule", "syrup", "suspension", "drops", "spray",
    "tube", "box", "bottle", "mg", "ml", "g", "plus", "forte", "kids", "baby",
}

STRUCTURED_KEYS = {
    "foreground_product_text", "primary_title", "brand", "product_family", "form",
    "strength", "size", "pack", "background_text", "raw_vision_text", "confidence",
    # Backward-compatible keys emitted by older prompts.
    "main_visible_product", "product_name", "visible_text",
}

YES_NO_STATUSES = {"OK", "BAD_JSON_TITLE_ONLY", "IMAGE_UNCLEAR", "LOW_CONFIDENCE"}


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return " ".join(_as_text(v) for v in value if v is not None).strip()
    return str(value).strip()


def _find_json_object(raw: str) -> Tuple[Dict[str, Any], bool]:
    if not raw:
        return {}, False
    try:
        value = json.loads(raw)
        return (value if isinstance(value, dict) else {}), True
    except Exception:
        pass
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        try:
            value = json.loads(raw[start:end + 1])
            return (value if isinstance(value, dict) else {}), True
        except Exception:
            return {}, False
    return {}, False


def parse_vision_response(raw_response: str) -> Dict[str, Any]:
    data, ok = _find_json_object(raw_response or "")
    if ok:
        data["_json_ok"] = True
        return data
    title = detect_primary_title_from_raw(raw_response or "")
    if title:
        return {
            "_json_ok": False,
            "status": "BAD_JSON_TITLE_ONLY",
            "primary_title": title,
            "foreground_product_text": title,
            "raw_vision_text": raw_response or "",
            "confidence": 0.70,
        }
    return {
        "_json_ok": False,
        "status": "IMAGE_UNCLEAR",
        "raw_vision_text": raw_response or "",
        "confidence": 0.0,
    }


def detect_primary_title_from_raw(raw: str) -> str:
    """Best-effort title detector for bad JSON.

    It is intentionally conservative.  The returned title can be used only for a
    confirmation question, never for price display.
    """
    lines = [re.sub(r"[^A-Za-z0-9\-\s]+", " ", x).strip() for x in (raw or "").splitlines()]
    lines = [re.sub(r"\s+", " ", x) for x in lines if x.strip()]
    candidates: List[str] = []
    for line in lines[:8]:
        if len(line) < 3 or len(line) > 60:
            continue
        words = line.split()
        if not words:
            continue
        upper_ratio = sum(1 for ch in line if ch.isalpha() and ch.isupper()) / max(1, sum(1 for ch in line if ch.isalpha()))
        strong_words = [w for w in words if normalize_text(w) not in WEAK_TITLE_WORDS and len(w) > 2]
        if upper_ratio >= 0.55 and strong_words:
            candidates.append(line)
    if candidates:
        # Prefer the earliest short title.
        candidates.sort(key=lambda x: (len(x.split()) > 5, len(x)))
        return candidates[0]
    # Inline fallback: quoted/labelled product-like token.
    m = re.search(r"(?:product|title|name)\s*[:=]\s*([A-Z][A-Z0-9\- ]{2,50})", raw or "", flags=re.I)
    if m:
        return re.sub(r"\s+", " ", m.group(1)).strip()
    return ""


def _contains_noise_only(text: str) -> bool:
    n = normalize_text(text)
    if not n:
        return True
    words = n.split()
    if not words:
        return True
    strong = [w for w in words if w not in WEAK_TITLE_WORDS and not w.isdigit() and len(w) > 2]
    if not strong:
        return True
    joined = " ".join(words)
    if joined in INGREDIENT_NOISE:
        return True
    return False


def _remove_ingredient_noise(text: str) -> str:
    n = normalize_text(text)
    if not n:
        return ""
    # Remove multi-word ingredient phrases first.
    cleaned = f" {n} "
    for phrase in sorted(INGREDIENT_NOISE, key=len, reverse=True):
        p = normalize_text(phrase)
        if not p:
            continue
        cleaned = re.sub(r"(?<!\w)" + re.escape(p) + r"(?!\w)", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def _confidence(data: Dict[str, Any]) -> float:
    try:
        return float(data.get("confidence") or 0)
    except Exception:
        return 0.0


@dataclass
class VisionEvidence:
    status: str
    query: str = ""
    message: str = ""
    slots: Dict[str, Any] = field(default_factory=dict)
    needs_confirmation_only: bool = False


def validate_vision_payload(data: Dict[str, Any]) -> VisionEvidence:
    data = dict(data or {})
    raw_status = str(data.get("status") or "").strip()
    if raw_status == "BAD_JSON_TITLE_ONLY":
        title = _as_text(data.get("primary_title") or data.get("foreground_product_text"))
        if title:
            return VisionEvidence(
                status="OK",
                query=title,
                needs_confirmation_only=True,
                message=f"هل تقصد {title}؟",
                slots={
                    **data,
                    "foreground_product_text": title,
                    "primary_title": title,
                    "main_visible_product": title,
                    "product_name": title,
                    "visible_text": title,
                    "query": title,
                    "confidence": str(data.get("confidence") or 0.70),
                    "vision_validation": "bad_json_title_only",
                },
            )
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة لم تُقرأ بشكل كافٍ. اكتب اسم المنتج من فضلك.", slots=data)

    conf = _confidence(data)
    if conf < 0.75:
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة غير كافية، أرسل صورة أوضح للمنتج أو اكتب اسمه.", slots=data)

    foreground = _as_text(data.get("foreground_product_text") or data.get("main_visible_product") or data.get("visible_text"))
    primary = _as_text(data.get("primary_title") or data.get("product_name") or data.get("main_visible_product"))
    brand = _as_text(data.get("brand"))
    family = _as_text(data.get("product_family"))
    background = _as_text(data.get("background_text"))
    raw_vision = _as_text(data.get("raw_vision_text") or data.get("visible_text"))

    trusted_parts: List[str] = []
    if primary and not _contains_noise_only(primary):
        trusted_parts.append(primary)
    if foreground and foreground != primary and not _contains_noise_only(foreground):
        trusted_parts.append(foreground)
    if not trusted_parts and brand and family:
        trusted_parts.append(" ".join([brand, family]))
    if not trusted_parts:
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة غير كافية، أرسل صورة أوضح للمنتج أو اكتب اسمه.", slots=data)

    # Ignore background and ingredient terms entirely.  If the only usable text is
    # background/ingredients, refuse image matching.
    allowed_query = _remove_ingredient_noise(" ".join(trusted_parts))
    if not allowed_query or _contains_noise_only(allowed_query):
        return VisionEvidence(status="IMAGE_UNCLEAR", message="الصورة غير كافية، أرسل صورة أوضح للمنتج أو اكتب اسمه.", slots=data)

    bg_norm = normalize_text(background)
    fg_norm = normalize_text(allowed_query)
    if bg_norm and fg_norm and fg_norm in bg_norm and not foreground and not primary:
        return VisionEvidence(status="IMAGE_UNCLEAR", message="النص المقروء يظهر كخلفية وليس اسم المنتج. أرسل صورة أوضح للواجهة الأمامية.", slots=data)

    slots = {
        **data,
        "foreground_product_text": foreground or allowed_query,
        "primary_title": primary or allowed_query,
        "main_visible_product": primary or foreground or allowed_query,
        "product_name": primary or family or allowed_query,
        "visible_text": allowed_query,
        "background_text": background,
        "raw_vision_text": raw_vision,
        "query": allowed_query,
        "confidence": str(conf),
        "vision_validation": "foreground_primary_only",
    }
    for key in ["form", "strength", "size", "pack", "brand", "product_family"]:
        if key in data:
            slots[key] = data.get(key)
    return VisionEvidence(status="OK", query=allowed_query, slots=slots)


__all__ = [
    "INGREDIENT_NOISE",
    "VisionEvidence",
    "detect_primary_title_from_raw",
    "parse_vision_response",
    "validate_vision_payload",
]
