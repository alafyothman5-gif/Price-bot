from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from normalizer import normalize_text

# Customer intent/greeting/filler words.  These are removed before product search.
# They are intentionally generic and do not contain product-specific aliases.
ARABIC_STOPWORDS = {
    "السلام", "عليكم", "سلام", "مرحبا", "هلا", "اهلا", "اهلاً", "أهلا", "أهلاً",
    "عندكم", "عندك", "لديكم", "معاكم", "في", "فيه", "ف", "هل", "يوجد", "لقيت", "نلقى",
    "متوفر", "متوفره", "متوفرة", "موجود", "موجوده", "موجودة", "موجودين",
    "نبي", "نريد", "ابي", "أبي", "ابى", "نبى", "اريد", "أريد", "بدّي", "بدي", "بغيت",
    "سعر", "السعر", "اسعار", "الاسعار", "كم", "بكم", "قداش", "شن", "شنو", "شني",
    "دواء", "الدوا", "الدواء", "علاج", "المنتج", "منتج", "الصنف", "صنف",
    "حبوب", "كبسول", "كبسولة", "كبسولات", "شراب", "قطرة", "قطره", "بخاخ", "مرهم", "كريم", "جل",
    "لو", "لا", "من", "فضلك", "لو سمحت", "بالله", "باللهي", "ممكن", "رجاء", "رجاءً",
    "هذا", "هذه", "هدا", "هدي", "هادا", "هادي", "صيدلية", "الصيدلية", "صيدليتكم",
}

ENGLISH_STOPWORDS = {
    "hi", "hello", "hey", "salam", "please", "pls", "price", "prices", "available", "availability",
    "do", "you", "have", "has", "is", "are", "in", "stock", "need", "want", "wanted", "looking",
    "for", "medicine", "medication", "drug", "product", "item", "pharmacy", "store", "how", "much",
    "the", "a", "an", "your", "can", "i", "we", "get", "buy", "find",
}

# Keep these as product tokens; ProductIndex already treats dosage/form words carefully.
MIN_TOKEN_LEN = 2
MAX_CANDIDATES = 80

ARABIC_TO_LATIN_CHOICES: Dict[str, Tuple[str, ...]] = {
    "ا": ("a", ""), "أ": ("a", ""), "إ": ("e", "i", "a", ""), "آ": ("a", ""), "ٱ": ("a", ""),
    "ب": ("b", "p"), "پ": ("p", "b"),
    "ت": ("t",), "ث": ("th", "s"),
    "ج": ("j", "g"), "چ": ("ch", "j"),
    "ح": ("h",), "خ": ("kh", "k"),
    "د": ("d",), "ذ": ("z", "th"),
    "ر": ("r",), "ز": ("z", "s"),
    "س": ("s",), "ش": ("sh",),
    "ص": ("s",), "ض": ("d",), "ط": ("t",), "ظ": ("z",),
    "ع": ("", "a"), "غ": ("gh", "g"),
    "ف": ("f", "v"), "ڤ": ("v", "f"),
    "ق": ("k", "q"), "ك": ("c", "k"), "ک": ("c", "k"),
    "ل": ("l",), "م": ("m",), "ن": ("n",),
    "ه": ("h",), "ة": ("a", "h"),
    "و": ("o", "u", "w"),
    "ي": ("e", "i", "y"), "ى": ("a", "y", "i"), "ئ": ("e", "i", "y"), "ؤ": ("o", "u", "w"),
    "ء": ("",),
}

DIACRITICS_RE = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
TOKEN_RE = re.compile(r"[a-zA-Z0-9]+|[\u0600-\u06FF]+")
ARABIC_RE = re.compile(r"[\u0600-\u06FF]")


def _dedupe(values: Iterable[str], limit: int = MAX_CANDIDATES) -> List[str]:
    out: List[str] = []
    seen = set()
    for value in values:
        v = re.sub(r"\s+", " ", str(value or "")).strip()
        if not v:
            continue
        key = normalize_text(v)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(v)
        if len(out) >= limit:
            break
    return out


def _strip_arabic_noise(text: str) -> str:
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = DIACRITICS_RE.sub("", text)
    text = text.replace("ـ", "")
    return text


def _normalize_token(token: str) -> str:
    token = _strip_arabic_noise(token)
    token = normalize_text(token)
    return token.strip()


def _token_without_article(token: str) -> str:
    token = _normalize_token(token)
    if token.startswith("ال") and len(token) > 4:
        return token[2:]
    return token


def _is_stopword(token: str) -> bool:
    t = _normalize_token(token)
    if not t:
        return True
    t_no_al = _token_without_article(t)
    return t in ARABIC_STOPWORDS or t_no_al in ARABIC_STOPWORDS or t in ENGLISH_STOPWORDS


def _meaningful_tokens(text: str) -> List[str]:
    text = _strip_arabic_noise(text).replace("؟", " ")
    raw_tokens = TOKEN_RE.findall(text)
    kept: List[str] = []
    for raw in raw_tokens:
        token = _normalize_token(raw)
        if not token:
            continue
        token_no_al = _token_without_article(token)
        if _is_stopword(token) or _is_stopword(token_no_al):
            continue
        token = token_no_al if token_no_al and token_no_al not in ARABIC_STOPWORDS else token
        if len(token) < MIN_TOKEN_LEN and not re.search(r"\d", token):
            continue
        kept.append(token)
    return kept


def _token_windows(tokens: Sequence[str]) -> List[str]:
    if not tokens:
        return []
    # The whole cleaned query is the safest first candidate.  Suffix windows help when
    # customers add residual words before the product name.
    out = [" ".join(tokens)]
    max_window = min(6, len(tokens))
    for size in range(max_window - 1, 0, -1):
        suffix = " ".join(tokens[-size:])
        if suffix:
            out.append(suffix)
    # Keep individual tokens in original order as a last fallback.
    out.extend(tokens)
    return _dedupe(out, limit=20)


def _has_arabic(value: str) -> bool:
    return bool(ARABIC_RE.search(str(value or "")))


def _latinize_arabic_token(token: str, max_variants: int = 48) -> List[str]:
    token = _strip_arabic_noise(str(token or "").strip())
    if not token:
        return []

    variants = [""]
    i = 0
    while i < len(token):
        if token[i : i + 2] == "لا":
            repls = ("la",)
            i += 2
        else:
            ch = token[i]
            repls = ARABIC_TO_LATIN_CHOICES.get(ch)
            i += 1
        if repls is None:
            repls = (ch.lower(),) if ch.isascii() else ("",)
        next_variants: List[str] = []
        for base in variants:
            for repl in repls:
                next_variants.append(base + repl)
        variants = _dedupe(next_variants, limit=max_variants)

    expanded: List[str] = []
    for value in variants:
        v = re.sub(r"[^a-zA-Z0-9]+", "", value.lower())
        if not v:
            continue
        forms = {
            v,
            v.replace("k", "c"),
            v.replace("c", "k"),
            v.replace("q", "k"),
            v.replace("ph", "f"),
            v.replace("oo", "o"),
            v.replace("ou", "o"),
            v.replace("ks", "x"),
            v.replace("cs", "x"),
            v.replace("b", "p"),
        }
        # Common Arabic phonetic ambiguity: words may omit a leading Latin vowel.
        if not v.startswith(("a", "e", "i", "o", "u")):
            forms.add("a" + v)
        expanded.extend(forms)
    return _dedupe(expanded, limit=max_variants)


def _latinize_candidate(candidate: str, max_variants: int = 48) -> List[str]:
    tokens = str(candidate or "").split()
    if not tokens or not any(_has_arabic(t) for t in tokens):
        return []

    options: List[List[str]] = []
    for token in tokens:
        if _has_arabic(token):
            opts = _latinize_arabic_token(token, max_variants=16)
        else:
            opts = [token.lower()]
        if not opts:
            opts = [""]
        options.append(opts[:12])

    combos = [""]
    for opts in options:
        next_combos: List[str] = []
        for base in combos:
            for opt in opts:
                value = (base + " " + opt).strip()
                if value:
                    next_combos.append(value)
        combos = _dedupe(next_combos, limit=max_variants)
    return _dedupe(combos, limit=max_variants)


def extract_product_query_from_customer_text(text: str) -> List[str]:
    """Extract ordered product-query candidates from a customer sentence.

    The function is generic: it removes customer intent/price/greeting words,
    normalizes Arabic spelling noise, and emits Latin phonetic variants for Arabic
    product-name tokens.  It does not contain hardcoded product aliases.
    """
    raw = str(text or "").strip()
    if not raw:
        return []

    tokens = _meaningful_tokens(raw)
    base_candidates = _token_windows(tokens)
    if not base_candidates:
        cleaned_raw = normalize_text(raw)
        base_candidates = [cleaned_raw] if cleaned_raw else []

    variants: List[str] = []
    variants.extend(base_candidates)
    for candidate in base_candidates:
        variants.extend(_latinize_candidate(candidate, max_variants=48))

    # General Latin spelling equivalences, still product-agnostic.
    extra: List[str] = []
    for value in variants:
        v = str(value or "").lower().strip()
        if not v or _has_arabic(v):
            continue
        extra.extend([
            v.replace("k", "c"),
            v.replace("c", "k"),
            v.replace("q", "k"),
            v.replace("ph", "f"),
            v.replace("ks", "x"),
            v.replace("cs", "x"),
        ])
    variants.extend(extra)
    return _dedupe(variants, limit=MAX_CANDIDATES)


def phonetic_key(value: Any) -> str:
    """Language-agnostic comparison key for Arabic phonetic ↔ Latin product names."""
    text = _strip_arabic_noise(str(value or "")).lower()
    # Normalize Arabic first, but preserve ك/ق → k and ب → p/b equivalence through replacements below.
    latin_parts: List[str] = []
    for ch in text:
        choices = ARABIC_TO_LATIN_CHOICES.get(ch)
        if choices:
            # Use the first/key-safe choice; equivalence cleanup below collapses variants.
            latin_parts.append(choices[0])
        else:
            latin_parts.append(ch)
    s = "".join(latin_parts)
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("ph", "f")
    # Soft Latin C before e/i/y is commonly pronounced like S: Cetamol ↔ سيتامول.
    s = re.sub(r"c(?=[eiy])", "s", s)
    s = s.replace("q", "k").replace("c", "k")
    s = s.replace("x", "ks")
    s = s.replace("b", "p")
    s = re.sub(r"[^a-z0-9]+", "", s)
    # Remove vowels to bridge missing Arabic vowels: panadol ↔ بندول, amoclan ↔ موكلان.
    s = re.sub(r"[aeiou]", "", s)
    s = re.sub(r"(.)\1+", r"\1", s)
    return s


def _similarity(qkey: str, pkey: str) -> float:
    if not qkey or not pkey:
        return 0.0
    if qkey == pkey:
        return 1.0
    if len(qkey) >= 4 and (qkey in pkey or pkey in qkey):
        return 0.94 if abs(len(qkey) - len(pkey)) <= 5 else 0.90
    return SequenceMatcher(None, qkey, pkey).ratio()


@dataclass(frozen=True)
class InventoryPhoneticMatch:
    query: str
    product_name: str
    score: float
    query_key: str
    product_key: str


def _product_display_name(product: Dict[str, Any]) -> str:
    return str(
        product.get("canonical_display_name")
        or product.get("name")
        or product.get("original_name")
        or ""
    ).strip()


def _product_family_query(product: Dict[str, Any]) -> str:
    name = _product_display_name(product)
    fields = [
        str(product.get("product_family") or "").strip(),
        str(product.get("brand") or "").strip(),
        name,
    ]
    for field in fields:
        toks = _meaningful_tokens(field)
        if toks:
            # A first meaningful token usually gives the existing matcher a family-level query,
            # so multiple concentrations/pack sizes are listed instead of randomly choosing one.
            return toks[0]
    return name


_CATALOG_CACHE: Dict[str, Any] = {"signature": None, "entries": []}


def _catalog_entries(product_index: Any) -> List[Tuple[str, str, List[str]]]:
    products = getattr(product_index, "products", {}) or {}
    signature = (id(product_index), round(float(getattr(product_index, "loaded_at", 0.0) or 0.0), 3), len(products))
    if _CATALOG_CACHE.get("signature") == signature:
        return list(_CATALOG_CACHE.get("entries") or [])

    entries: List[Tuple[str, str, List[str]]] = []
    for product in products.values():
        if not isinstance(product, dict):
            continue
        display = _product_display_name(product)
        if not display:
            continue
        family_query = _product_family_query(product) or display
        searchable_values = [
            display,
            family_query,
            str(product.get("name") or ""),
            str(product.get("original_name") or ""),
            str(product.get("canonical_display_name") or ""),
            str(product.get("brand") or ""),
            str(product.get("product_family") or ""),
            str(product.get("aliases") or ""),
            str(product.get("ocr_keywords") or ""),
        ]
        keys: List[str] = []
        for value in searchable_values:
            for token_candidate in _token_windows(_meaningful_tokens(value)) or [normalize_text(value)]:
                key = phonetic_key(token_candidate)
                if len(key) >= 3:
                    keys.append(key)
        keys = _dedupe(keys, limit=30)
        if keys:
            entries.append((family_query, display, keys))
    _CATALOG_CACHE["signature"] = signature
    _CATALOG_CACHE["entries"] = list(entries)
    return entries


def inventory_phonetic_candidates(
    product_index: Any,
    query_candidates: Sequence[str],
    *,
    max_results: int = 8,
    min_score: float = 0.88,
) -> List[InventoryPhoneticMatch]:
    """Return safe inventory-backed phonetic query strings.

    Only products already loaded into ProductIndex are considered.  ProductIndex is
    built from visible/available products, so this function cannot return products
    outside the current available catalog.
    """
    entries = _catalog_entries(product_index)
    if not entries:
        return []

    best_by_query: Dict[str, InventoryPhoneticMatch] = {}
    for candidate in query_candidates or []:
        c = normalize_text(candidate)
        if not c or c in ARABIC_STOPWORDS or c in ENGLISH_STOPWORDS:
            continue
        qkey = phonetic_key(c)
        if len(qkey) < 3:
            continue
        for family_query, display, keys in entries:
            best_key_score = 0.0
            best_key = ""
            for pkey in keys:
                score = _similarity(qkey, pkey)
                if score > best_key_score:
                    best_key_score = score
                    best_key = pkey
            if best_key_score < min_score:
                continue
            existing = best_by_query.get(family_query)
            if existing is None or best_key_score > existing.score:
                best_by_query[family_query] = InventoryPhoneticMatch(
                    query=family_query,
                    product_name=display,
                    score=round(best_key_score, 4),
                    query_key=qkey,
                    product_key=best_key,
                )

    ranked = sorted(best_by_query.values(), key=lambda m: (-m.score, len(m.query), m.query.lower()))
    if not ranked:
        return []

    # Avoid guessing when a different family is nearly tied at a weak score.
    if len(ranked) >= 2 and ranked[0].score < 0.96 and (ranked[0].score - ranked[1].score) < 0.035:
        return []

    return ranked[:max_results]


def build_text_search_candidates(text: str, product_index: Any | None = None) -> List[str]:
    """Build the full ordered query list used by the text path.

    Includes the original text for legacy behavior, extracted product text,
    transliteration variants, and optional inventory-backed phonetic candidates.
    """
    raw = str(text or "").strip()
    extracted = extract_product_query_from_customer_text(raw)
    candidates: List[str] = []
    if raw:
        candidates.append(raw)
    candidates.extend(extracted)
    if product_index is not None:
        matches = inventory_phonetic_candidates(product_index, extracted or [raw])
        candidates.extend(m.query for m in matches)
    return _dedupe(candidates, limit=MAX_CANDIDATES)
