from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Dict, Optional

try:  # optional dependency
    import redis.asyncio as redis_async  # type: ignore
except Exception:  # pragma: no cover
    redis_async = None

_TRUE = {"1", "true", "yes", "on", "enabled", "enable"}


def _env_true(name: str, default: bool = False) -> bool:
    value = str(os.getenv(name, "") or "").strip().lower()
    if not value:
        return default
    return value in _TRUE


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _json_loads(value: Any) -> Optional[Dict[str, Any]]:
    if value is None:
        return None
    if isinstance(value, bytes):
        value = value.decode("utf-8", "ignore")
    try:
        data = json.loads(str(value))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


class RuntimeState:
    """Runtime state with Redis/Valkey as the production backend.

    When REDIS_URL is configured, Redis is treated as the authoritative backend
    by default. The process does not silently fall back to per-worker memory
    unless PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK=1 is explicitly set.
    """

    def __init__(self, namespace: str = "pricebot", mode_ttl: int = 7200, confirmation_ttl: int = 900, lock_ttl: int = 35) -> None:
        self.namespace = namespace.strip() or "pricebot"
        self.mode_ttl = int(mode_ttl or 7200)
        self.confirmation_ttl = int(confirmation_ttl or 900)
        self.lock_ttl = int(lock_ttl or 35)
        self.redis_url = os.getenv("REDIS_URL", "").strip()
        self.allow_memory_fallback = _env_true("PRICEBOT_ALLOW_MEMORY_STATE_FALLBACK", False)
        self.redis = None
        self.enabled = False
        self.last_error = ""
        self.last_connect_ts = 0.0
        self.last_ok_ts = 0.0
        self._next_reconnect_ts = 0.0
        self._reconnect_lock = asyncio.Lock()
        self._memory: Dict[str, tuple[float, Any]] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._last_cleanup = 0.0

    @property
    def redis_required(self) -> bool:
        return bool(self.redis_url) and not self.allow_memory_fallback

    def key(self, suffix: str) -> str:
        return f"{self.namespace}:{suffix}"

    def _mark_redis_down(self, exc: Exception | str) -> None:
        self.enabled = False
        self.last_error = str(exc)[:300]
        self._next_reconnect_ts = time.time() + float(os.getenv("PRICEBOT_REDIS_RECONNECT_SECONDS", "5") or 5)

    async def connect(self) -> None:
        self.last_connect_ts = time.time()
        self.last_error = ""
        if not self.redis_url:
            self.redis = None
            self.enabled = False
            self.last_error = "REDIS_URL_not_configured"
            return
        if redis_async is None:
            self.redis = None
            self.enabled = False
            self.last_error = "redis_python_package_missing"
            return
        try:
            if self.redis is not None:
                try:
                    await self.redis.aclose()
                except Exception:
                    pass
            socket_timeout = float(os.getenv("PRICEBOT_REDIS_SOCKET_TIMEOUT_SECONDS", "2") or 2)
            self.redis = redis_async.from_url(
                self.redis_url,
                decode_responses=True,
                socket_timeout=socket_timeout,
                socket_connect_timeout=socket_timeout,
                health_check_interval=30,
            )
            await self.redis.ping()
            self.enabled = True
            self.last_ok_ts = time.time()
            self.last_error = ""
        except Exception as exc:
            self.redis = None
            self._mark_redis_down(exc)

    async def ensure_redis(self) -> bool:
        if self.enabled and self.redis is not None:
            return True
        now = time.time()
        if now < self._next_reconnect_ts:
            return False
        async with self._reconnect_lock:
            if self.enabled and self.redis is not None:
                return True
            if time.time() < self._next_reconnect_ts:
                return False
            await self.connect()
            return bool(self.enabled and self.redis is not None)

    async def close(self) -> None:
        if self.redis is not None:
            try:
                await self.redis.aclose()
            except Exception:
                pass
        self.enabled = False

    def _memory_get_json(self, key: str) -> Optional[Dict[str, Any]]:
        item = self._memory.get(key)
        if not item:
            return None
        expires, value = item
        if expires and expires < time.time():
            self._memory.pop(key, None)
            return None
        return value if isinstance(value, dict) else None

    def _memory_set_json(self, key: str, value: Dict[str, Any], ttl: int) -> None:
        self._memory[key] = (time.time() + max(1, int(ttl or 60)), dict(value))

    def _memory_allowed(self) -> bool:
        return (not self.redis_url) or self.allow_memory_fallback

    def _raise_if_no_memory_fallback(self) -> None:
        if not self._memory_allowed():
            raise RuntimeError(f"Redis state unavailable and memory fallback is disabled: {self.last_error or 'unknown_error'}")

    async def get_json(self, suffix: str) -> Optional[Dict[str, Any]]:
        key = self.key(suffix)
        if await self.ensure_redis():
            try:
                assert self.redis is not None
                value = await self.redis.get(key)
                self.last_ok_ts = time.time()
                return _json_loads(value)
            except Exception as exc:
                self._mark_redis_down(exc)
        self._raise_if_no_memory_fallback()
        return self._memory_get_json(key)

    async def set_json(self, suffix: str, value: Dict[str, Any], ttl: int) -> None:
        key = self.key(suffix)
        ttl = max(1, int(ttl or 60))
        if await self.ensure_redis():
            try:
                assert self.redis is not None
                await self.redis.set(key, _json_dumps(value), ex=ttl)
                self.last_ok_ts = time.time()
                return
            except Exception as exc:
                self._mark_redis_down(exc)
        self._raise_if_no_memory_fallback()
        self._memory_set_json(key, value, ttl)

    async def delete(self, suffix: str) -> None:
        key = self.key(suffix)
        if await self.ensure_redis():
            try:
                assert self.redis is not None
                await self.redis.delete(key)
                self.last_ok_ts = time.time()
                return
            except Exception as exc:
                self._mark_redis_down(exc)
        self._raise_if_no_memory_fallback()
        self._memory.pop(key, None)

    async def get_mode(self, phone: str) -> str:
        data = await self.get_json(f"mode:{phone}")
        return str((data or {}).get("mode") or "idle")

    async def set_mode(self, phone: str, mode: str) -> None:
        await self.set_json(f"mode:{phone}", {"mode": str(mode or "idle"), "ts": time.time()}, self.mode_ttl)

    async def get_confirmation(self, phone: str) -> Optional[Dict[str, Any]]:
        return await self.get_json(f"confirm:{phone}")

    async def set_confirmation(self, phone: str, data: Dict[str, Any]) -> None:
        payload = dict(data or {})
        payload["ts"] = time.time()
        await self.set_json(f"confirm:{phone}", payload, self.confirmation_ttl)

    async def clear_confirmation(self, phone: str) -> None:
        await self.delete(f"confirm:{phone}")

    async def cleanup_memory(self) -> None:
        now = time.time()
        if now - self._last_cleanup < 60:
            return
        self._last_cleanup = now
        expired = [k for k, (exp, _v) in self._memory.items() if exp and exp < now]
        for key in expired:
            self._memory.pop(key, None)
        unlocked = [k for k, lock in self._locks.items() if not lock.locked()]
        if len(unlocked) > 1000:
            for key in unlocked[: len(unlocked) - 1000]:
                self._locks.pop(key, None)

    @asynccontextmanager
    async def user_lock(self, phone: str) -> AsyncIterator[None]:
        """Cross-process Redis lock when available; memory lock only when fallback is allowed."""
        phone = str(phone or "unknown")
        if await self.ensure_redis():
            assert self.redis is not None
            lock = self.redis.lock(self.key(f"lock:{phone}"), timeout=self.lock_ttl, blocking_timeout=8)
            acquired = False
            try:
                acquired = await lock.acquire()
                self.last_ok_ts = time.time()
                yield
            except Exception as exc:
                self._mark_redis_down(exc)
                raise
            finally:
                if acquired:
                    try:
                        await lock.release()
                    except Exception:
                        pass
            return

        self._raise_if_no_memory_fallback()
        lock = self._locks.setdefault(phone, asyncio.Lock())
        async with lock:
            yield

    def health(self) -> Dict[str, Any]:
        return {
            "redis_url_configured": bool(self.redis_url),
            "redis_state_enabled": bool(self.enabled),
            "redis_required": bool(self.redis_required),
            "memory_state_fallback_allowed": bool(self.allow_memory_fallback),
            "redis_last_error": self.last_error,
            "redis_last_ok_age_seconds": round(time.time() - self.last_ok_ts, 2) if self.last_ok_ts else None,
            "memory_state_keys": len(self._memory),
            "memory_locks": len(self._locks),
        }


class TtlRateLimiter:
    """In-memory TTL rate limiter with periodic cleanup, not per-request sweeping."""

    def __init__(self, window_seconds: int, default_limit: int) -> None:
        from collections import deque
        self.deque_type = deque
        self.window_seconds = int(window_seconds or 60)
        self.default_limit = int(default_limit or 60)
        self.buckets: Dict[str, Any] = {}

    def allow(self, key: str, limit: Optional[int] = None) -> bool:
        now = time.time()
        limit = int(limit or self.default_limit)
        bucket = self.buckets.get(key)
        if bucket is None:
            bucket = self.deque_type()
            self.buckets[key] = bucket
        cutoff = now - self.window_seconds
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= limit:
            return False
        bucket.append(now)
        return True

    def cleanup(self) -> None:
        now = time.time()
        cutoff = now - self.window_seconds
        empty = []
        for key, bucket in self.buckets.items():
            while bucket and bucket[0] < cutoff:
                bucket.popleft()
            if not bucket:
                empty.append(key)
        for key in empty:
            self.buckets.pop(key, None)

    def health(self) -> Dict[str, Any]:
        return {"backend": "memory", "window_seconds": self.window_seconds, "memory_buckets": len(self.buckets)}


class RedisTtlRateLimiter:
    """Redis fixed-window limiter shared across uvicorn workers.

    Uses INCR + EXPIRE with automatic key expiry, so no long-lived cleanup is
    required for normal operation. If Redis is required and unavailable, it fails
    closed by default; set PRICEBOT_RATE_LIMIT_FAIL_OPEN=1 to allow traffic.
    """

    def __init__(self, state: RuntimeState, bucket_name: str, window_seconds: int, default_limit: int) -> None:
        self.state = state
        self.bucket_name = str(bucket_name or "rate")
        self.window_seconds = max(1, int(window_seconds or 60))
        self.default_limit = int(default_limit or 60)
        self.fail_open = _env_true("PRICEBOT_RATE_LIMIT_FAIL_OPEN", False)
        self.memory = TtlRateLimiter(self.window_seconds, self.default_limit)
        self.last_error = ""
        self.last_backend = "redis" if state.redis_url else "memory"

    def _key(self, key: str, now: Optional[float] = None) -> str:
        now = time.time() if now is None else now
        slot = int(now // self.window_seconds)
        raw = str(key or "unknown").replace(" ", "_")[:160]
        return self.state.key(f"rate:{self.bucket_name}:{raw}:{slot}")

    async def allow(self, key: str, limit: Optional[int] = None) -> bool:
        limit = int(limit or self.default_limit)
        if await self.state.ensure_redis():
            try:
                assert self.state.redis is not None
                redis_key = self._key(key)
                count = await self.state.redis.incr(redis_key)
                if int(count) == 1:
                    await self.state.redis.expire(redis_key, self.window_seconds * 2 + 10)
                self.state.last_ok_ts = time.time()
                self.last_backend = "redis"
                return int(count) <= limit
            except Exception as exc:
                self.last_error = str(exc)[:300]
                self.state._mark_redis_down(exc)

        if self.state.redis_required and not self.fail_open:
            self.last_backend = "redis_unavailable_fail_closed"
            return False

        self.last_backend = "memory_fail_open" if self.state.redis_url else "memory"
        return self.memory.allow(key, limit)

    def cleanup(self) -> None:
        self.memory.cleanup()

    def health(self) -> Dict[str, Any]:
        return {
            "backend": self.last_backend,
            "window_seconds": self.window_seconds,
            "default_limit": self.default_limit,
            "fail_open": self.fail_open,
            "last_error": self.last_error,
            "memory_buckets": len(self.memory.buckets),
        }
