#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

APP_DIR = Path(__file__).resolve().parents[1]
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

import config_env  # noqa: E402

config_env.load_environment()

from matcher_index import ProductIndex, product_name, product_price  # noqa: E402
from text_query_understanding import (  # noqa: E402
    extract_product_query_from_customer_text,
    inventory_phonetic_candidates,
)

TEST_CASES = [
    "متوفر عندكم اموكلان",
    "هل عندكم إموكلان؟",
    "عندكم amoclan",
    "نبي سعر فيروكسيل",
    "هل في عندكم فيروكسيل",
    "عندكم بندول",
    "كم سعر panadol",
    "السلام عليكم عندكم amoclan",
]


def _dedupe(values: List[str]) -> List[str]:
    out: List[str] = []
    seen = set()
    for value in values:
        v = " ".join(str(value or "").split()).strip()
        if not v:
            continue
        key = v.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(v)
    return out


async def _search_first(index: ProductIndex, queries: List[str]) -> Tuple[str, List[Dict[str, Any]]]:
    for query in queries:
        rows = await index.search(query, limit=10)
        if rows:
            return query, rows
    return "", []


async def main() -> int:
    index = ProductIndex(ttl_seconds=1)
    try:
        await index.refresh(force=True)
    except Exception as exc:
        print(f"DB/INDEX LOAD ERROR: {exc!r}")
        print("تأكد أن السكربت يعمل من داخل السيرفر الذي يحتوي PostgreSQL وملف .env الصحيح.")
        return 2

    print(f"Loaded available products: {len(index.products)}")
    print("-" * 80)

    for text in TEST_CASES:
        extracted = extract_product_query_from_customer_text(text)
        phonetic = inventory_phonetic_candidates(index, extracted or [text], max_results=5)
        search_queries = _dedupe([text] + extracted + [m.query for m in phonetic])
        matched_query, rows = await _search_first(index, search_queries)

        print(f"INPUT: {text}")
        print(f"EXTRACTED_CANDIDATES: {extracted}")
        if phonetic:
            print("PHONETIC_INVENTORY_CANDIDATES:")
            for m in phonetic:
                print(f"  - query={m.query!r} product={m.product_name!r} score={m.score}")
        else:
            print("PHONETIC_INVENTORY_CANDIDATES: []")

        if rows:
            print(f"FOUND: YES via query={matched_query!r} count={len(rows)}")
            for p in rows[:5]:
                print(f"  - {product_name(p)} | {product_price(p)} | score={p.get('_score')}")
            if len(rows) > 5:
                print(f"  ... +{len(rows) - 5} more")
        else:
            print("FOUND: NO")
        print("-" * 80)

    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
