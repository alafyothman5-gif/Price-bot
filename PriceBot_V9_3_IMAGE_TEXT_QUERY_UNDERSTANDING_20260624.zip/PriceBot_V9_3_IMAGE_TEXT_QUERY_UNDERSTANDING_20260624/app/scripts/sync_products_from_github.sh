#!/usr/bin/env bash
set -e

APP_DIR="/opt/pricebot_whatsapp_gemini"
SERVICE="pricebot-whatsapp-gemini"
REPO="https://github.com/alafyothman5-gif/Price-bot.git"
WORK="/root/pricebot_periodic_products_sync"

apt-get update >/dev/null
apt-get install -y git >/dev/null

cd "$APP_DIR"
. "$APP_DIR/.venv/bin/activate"
pip install -q openpyxl psycopg[binary]

rm -rf "$WORK"
git clone --depth 1 "$REPO" "$WORK" >/dev/null 2>&1

EXCEL="$(find "$WORK" -type f -name 'current_products.xlsx' | head -n1)"
if [ -z "$EXCEL" ]; then
  echo "ERROR: current_products.xlsx not found"
  exit 1
fi

BACKUP="/root/PRICEBOT_SAFE_BACKUPS/periodic_excel_sync_before_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
cp "$APP_DIR/.env" "$BACKUP/.env"
sudo -u postgres pg_dump pricebot > "$BACKUP/pricebot_postgres_before_periodic_sync.sql"

python "$APP_DIR/scripts/sync_current_products_from_github.py" --excel "$EXCEL" --mode sync

systemctl restart "$SERVICE"

echo "PERIODIC_SYNC_DONE"
