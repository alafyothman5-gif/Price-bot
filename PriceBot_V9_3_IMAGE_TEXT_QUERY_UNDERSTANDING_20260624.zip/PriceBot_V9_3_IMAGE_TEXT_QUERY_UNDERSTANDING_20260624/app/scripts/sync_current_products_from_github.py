#!/usr/bin/env python3
import argparse
import hashlib
import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import psycopg
from openpyxl import load_workbook


APP_DIR = Path("/opt/pricebot_whatsapp_gemini")
ENV_PATH = APP_DIR / ".env"


def read_env(path: Path) -> dict:
    env = {}
    for line in path.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def norm_name(x) -> str:
    if x is None:
        return ""
    s = str(x).strip().lower()
    s = re.sub(r"[\u064b-\u065f\u0670]", "", s)
    s = re.sub(r"[^\w\u0600-\u06FF]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def norm_price(x) -> str:
    if x is None:
        return ""
    s = str(x).strip()
    s = s.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩٫٬", "0123456789.."))
    s = re.sub(r"[^\d.]+", "", s)
    if not s:
        return ""
    try:
        d = Decimal(s)
        out = format(d.quantize(Decimal("0.001")).normalize(), "f")
        if "." in out:
            out = out.rstrip("0").rstrip(".")
        return out
    except InvalidOperation:
        return s


def read_excel(path: Path):
    wb = load_workbook(path, read_only=True, data_only=True)
    best = []

    for ws in wb.worksheets:
        rows = []
        for row in ws.iter_rows(values_only=True):
            if not row or len(row) < 2:
                continue

            raw_name = row[0]
            raw_price = row[1]

            name = str(raw_name).strip() if raw_name is not None else ""
            price = norm_price(raw_price)
            n = norm_name(name)

            if not n or n in {"name", "product", "item", "description", "اسم", "الصنف", "المنتج"}:
                continue

            if not price:
                continue

            rows.append({
                "name": name,
                "normalized_name": n,
                "price": price,
            })

        if len(rows) > len(best):
            best = rows

    # dedupe by normalized name: last row wins
    dedup = {}
    for r in best:
        dedup[r["normalized_name"]] = r

    return list(dedup.values())


def db_url():
    env = read_env(ENV_PATH)
    url = (
        env.get("DATABASE_URL")
        or env.get("POSTGRES_URL")
        or env.get("POSTGRES_DSN")
        or env.get("PRICEBOT_DATABASE_URL")
    )
    if not url:
        raise SystemExit("ERROR: PostgreSQL URL not found in .env")
    return url


def get_columns(conn):
    rows = conn.execute("""
        SELECT column_name, data_type, is_nullable, column_default
        FROM information_schema.columns
        WHERE table_schema='public' AND table_name='products'
        ORDER BY ordinal_position
    """).fetchall()

    return {
        r[0]: {
            "type": r[1],
            "nullable": r[2] == "YES",
            "default": r[3],
        }
        for r in rows
    }


def coerce(value, colinfo):
    typ = colinfo["type"]

    if value is None:
        if typ in {"integer", "bigint", "smallint"}:
            return 0
        if typ == "boolean":
            return False
        if typ in {"numeric", "real", "double precision"}:
            return Decimal("0")
        if "timestamp" in typ:
            return datetime.now()
        return ""

    if typ in {"integer", "bigint", "smallint"}:
        try:
            return int(value)
        except Exception:
            return 0

    if typ in {"numeric", "real", "double precision"}:
        try:
            return Decimal(str(value))
        except Exception:
            return Decimal("0")

    if typ == "boolean":
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "y", "available", "متوفر"}

    if "timestamp" in typ:
        if isinstance(value, datetime):
            return value
        return datetime.now()

    return str(value)


def build_product_values(cols, product_id: int, row: dict, available: bool = True):
    n = row["normalized_name"]
    price = row["price"]
    name = row["name"]
    stable = hashlib.sha1(n.encode("utf-8")).hexdigest()[:18]
    now = datetime.now()

    values = {}

    for c, info in cols.items():
        if c == "id":
            values[c] = product_id
        elif c == "name":
            values[c] = name
        elif c == "normalized_name":
            values[c] = n
        elif c == "canonical_display_name":
            values[c] = name
        elif c == "original_name":
            values[c] = name
        elif c == "price":
            values[c] = price
        elif c in {"current_price", "sale_price"}:
            values[c] = price
        elif c == "currency":
            values[c] = "LYD"
        elif c in {"is_available", "available"}:
            values[c] = available if info["type"] == "boolean" else ("1" if available else "0")
        elif c == "hidden":
            values[c] = False if info["type"] == "boolean" else "0"
        elif c == "visible":
            values[c] = True if info["type"] == "boolean" else "1"
        elif c == "is_searchable":
            values[c] = True if info["type"] == "boolean" else "1"
        elif c == "needs_review":
            values[c] = False if info["type"] == "boolean" else "0"
        elif c in {"merchant_id", "branch_id"}:
            values[c] = "1"
        elif c == "product_id":
            values[c] = f"excel-{stable}"
        elif c in {"identity_key", "stable_product_code", "barcode"}:
            values[c] = f"excel-{stable}"
        elif c in {"source", "source_file"}:
            values[c] = "current_products.xlsx"
        elif c in {"created_at", "updated_at", "last_seen_at", "last_seen_in_upload"}:
            values[c] = now
        else:
            if not info["nullable"] and not info["default"]:
                if info["type"] == "boolean":
                    values[c] = False
                elif info["type"] in {"integer", "bigint", "smallint"}:
                    values[c] = 0
                elif info["type"] in {"numeric", "real", "double precision"}:
                    values[c] = Decimal("0")
                elif "timestamp" in info["type"]:
                    values[c] = now
                else:
                    values[c] = ""
            else:
                continue

    return {c: coerce(v, cols[c]) for c, v in values.items()}


def insert_product(conn, cols, product_id, row):
    values = build_product_values(cols, product_id, row, True)
    columns = list(values.keys())
    placeholders = ", ".join(["%s"] * len(columns))
    col_sql = ", ".join([f'"{c}"' for c in columns])
    sql = f'INSERT INTO products ({col_sql}) VALUES ({placeholders})'
    conn.execute(sql, [values[c] for c in columns])


def update_existing(conn, cols, product_id, row):
    values = build_product_values(cols, product_id, row, True)
    values.pop("id", None)

    if not values:
        return

    assignments = ", ".join([f'"{c}"=%s' for c in values])
    sql = f'UPDATE products SET {assignments} WHERE id=%s'
    conn.execute(sql, list(values.values()) + [product_id])


def clear_product_caches(conn):
    tables = [
        "product_aliases",
        "visual_product_memory",
        "exact_image_confirmations",
        "image_cache",
        "image_product_cache",
        "review_queue",
        "products_catalog_fts",
        "products_catalog_fts_data",
        "products_catalog_fts_idx",
        "products_catalog_fts_content",
        "products_catalog_fts_docsize",
        "products_catalog_fts_config",
    ]

    existing = {
        r[0]
        for r in conn.execute(
            "SELECT tablename FROM pg_tables WHERE schemaname='public'"
        ).fetchall()
    }

    for t in tables:
        if t in existing:
            try:
                conn.execute(f'TRUNCATE TABLE "{t}" RESTART IDENTITY CASCADE')
                print(f"cleared.{t}")
            except Exception as e:
                print(f"skip_clear.{t}: {e}")


def set_unavailable_all(conn, cols):
    assignments = {}

    if "is_available" in cols:
        assignments["is_available"] = False
    if "available" in cols:
        assignments["available"] = False if cols["available"]["type"] == "boolean" else "0"
    if "hidden" in cols:
        assignments["hidden"] = True if cols["hidden"]["type"] == "boolean" else "1"
    if "visible" in cols:
        assignments["visible"] = False if cols["visible"]["type"] == "boolean" else "0"
    if "is_searchable" in cols:
        assignments["is_searchable"] = False if cols["is_searchable"]["type"] == "boolean" else "0"
    if "updated_at" in cols:
        assignments["updated_at"] = datetime.now()

    if assignments:
        sql = "UPDATE products SET " + ", ".join([f'"{c}"=%s' for c in assignments])
        conn.execute(sql, list(assignments.values()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--excel", required=True)
    ap.add_argument("--mode", choices=["reset", "sync"], default="sync")
    args = ap.parse_args()

    excel = Path(args.excel)
    products = read_excel(excel)

    print("EXCEL_PRODUCTS:", len(products))

    if not (4500 <= len(products) <= 6500):
        raise SystemExit(f"ERROR: unexpected Excel product count: {len(products)}")

    url = db_url()

    with psycopg.connect(url, connect_timeout=5) as conn:
        cols = get_columns(conn)

        with conn.transaction():
            clear_product_caches(conn)

            if args.mode == "reset":
                conn.execute('TRUNCATE TABLE products RESTART IDENTITY CASCADE')

                for idx, row in enumerate(products, start=1):
                    insert_product(conn, cols, idx, row)

            else:
                set_unavailable_all(conn, cols)

                rows = conn.execute('SELECT id, normalized_name, name FROM products ORDER BY id').fetchall()
                by_norm = {}
                for pid, normalized_name, name in rows:
                    n = norm_name(normalized_name) or norm_name(name)
                    if n and n not in by_norm:
                        by_norm[n] = pid

                next_id = conn.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM products').fetchone()[0]

                inserted = 0
                updated = 0

                for row in products:
                    n = row["normalized_name"]
                    pid = by_norm.get(n)

                    if pid:
                        update_existing(conn, cols, pid, row)
                        updated += 1
                    else:
                        insert_product(conn, cols, next_id, row)
                        next_id += 1
                        inserted += 1

                print("UPDATED:", updated)
                print("INSERTED:", inserted)

        total = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        available = conn.execute("""
            SELECT COUNT(*) FROM products
            WHERE LOWER(COALESCE(is_available::text,'')) IN ('1','true','yes','y','available','متوفر')
        """).fetchone()[0]

        print("FINAL_TOTAL:", total)
        print("FINAL_AVAILABLE:", available)
        print("FINAL_UNAVAILABLE:", total - available)

        if args.mode == "reset":
            if abs(total - len(products)) > 5 or abs(available - len(products)) > 5:
                raise SystemExit("ERROR: reset count mismatch")
        else:
            if abs(available - len(products)) > 5:
                raise SystemExit("ERROR: sync available count mismatch")

    print("SYNC_RESULT=OK")


if __name__ == "__main__":
    main()


# PRICEBOT_PRICE_FORMAT_FIXED
