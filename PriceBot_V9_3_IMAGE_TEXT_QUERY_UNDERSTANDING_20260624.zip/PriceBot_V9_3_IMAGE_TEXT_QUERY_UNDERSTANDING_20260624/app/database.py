import json
import os
import re
import shutil
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from normalizer import normalize_text, split_multi, truthy, safe_price

BASE_DIR = Path(__file__).resolve().parent
DATABASE_URL_RAW = (os.getenv("DATABASE_URL") or os.getenv("POSTGRES_DSN") or "").strip()
IS_POSTGRES = DATABASE_URL_RAW.startswith(("postgres://", "postgresql://"))


def _sqlite_path_from_database_url(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    # Accept a direct sqlite path because some deploy/test environments set
    # DATABASE_URL=/tmp/test.sqlite instead of a URL.
    if value.startswith("/") or value.startswith("./") or value.startswith("../"):
        return value
    if value.startswith("sqlite:///"):
        # sqlite:////opt/pricebot/pricebot.db -> /opt/pricebot/pricebot.db
        return value.replace("sqlite:///", "", 1)
    if value.startswith("sqlite://"):
        # sqlite://relative.db -> relative.db
        return value.replace("sqlite://", "", 1)
    return ""


def resolve_db_path(explicit_path: str = "") -> Path:
    """Resolve DB path safely.

    Priority:
    1. explicit_path / --db-path
    2. PRICEBOT_DB_FILE (legacy systemd deployments)
    3. PRICEBOT_DB_PATH
    4. DATABASE_URL when it is a sqlite path or direct sqlite file path
    5. /opt/pricebot/pricebot.db as the last production fallback

    The resolver intentionally does not default to BASE_DIR/pricebot.db, because
    production ZIPs must never create or carry a database inside the project.
    """
    raw = (explicit_path or "").strip()
    if raw:
        source = "--db-path"
    else:
        raw = (os.getenv("PRICEBOT_DB_FILE") or "").strip()
        if raw:
            source = "PRICEBOT_DB_FILE"
        else:
            raw = (os.getenv("PRICEBOT_DB_PATH") or "").strip()
            if raw:
                source = "PRICEBOT_DB_PATH"
            else:
                raw = _sqlite_path_from_database_url(os.getenv("DATABASE_URL", ""))
                if raw:
                    source = "DATABASE_URL"
                else:
                    raw = "/opt/pricebot/pricebot.db"
                    source = "fallback:/opt/pricebot/pricebot.db"
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    return path.resolve(), source


DB_FILE, DB_PATH_SOURCE = resolve_db_path()
BACKUPS_DIR = DB_FILE.parent / "backups"
READ_ONLY_MODE = False

# Performance Hardening V2: lightweight runtime cache for hot product and alias
# reads.  The database remains the source of truth; caches are read-through,
# in-process only, and are invalidated after imports/reindexing.
_PRODUCT_ROWS_CACHE: Optional[List[Dict[str, Any]]] = None
_PRODUCT_BY_ID_CACHE: Dict[int, Dict[str, Any]] = {}
_PRODUCT_CACHE_LOADED_AT: float = 0.0
_ALIAS_ROWS_CACHE: Optional[List[Dict[str, Any]]] = None
_ALIAS_CACHE_LOADED_AT: float = 0.0


def _runtime_cache_enabled() -> bool:
    return str(os.getenv("PRICEBOT_RUNTIME_CACHE", "1")).strip().lower() not in {"0", "false", "no", "off"}


def _runtime_cache_ttl() -> int:
    try:
        return int(os.getenv("PRICEBOT_RUNTIME_CACHE_TTL_SECONDS", "3600") or 3600)
    except Exception:
        return 3600


def _cache_fresh(loaded_at: float) -> bool:
    if not loaded_at:
        return False
    ttl = _runtime_cache_ttl()
    return ttl <= 0 or (time.time() - loaded_at) <= ttl


def invalidate_runtime_caches() -> None:
    """Clear in-process product/alias caches without touching SQLite."""
    global _PRODUCT_ROWS_CACHE, _PRODUCT_BY_ID_CACHE, _PRODUCT_CACHE_LOADED_AT, _ALIAS_ROWS_CACHE, _ALIAS_CACHE_LOADED_AT
    _PRODUCT_ROWS_CACHE = None
    _PRODUCT_BY_ID_CACHE = {}
    _PRODUCT_CACHE_LOADED_AT = 0.0
    _ALIAS_ROWS_CACHE = None
    _ALIAS_CACHE_LOADED_AT = 0.0


def runtime_cache_stats() -> Dict[str, Any]:
    return {
        "enabled": _runtime_cache_enabled(),
        "ttl_seconds": _runtime_cache_ttl(),
        "products_loaded": bool(_PRODUCT_ROWS_CACHE is not None and _cache_fresh(_PRODUCT_CACHE_LOADED_AT)),
        "products_count": len(_PRODUCT_ROWS_CACHE or []),
        "product_by_id_count": len(_PRODUCT_BY_ID_CACHE),
        "aliases_loaded": bool(_ALIAS_ROWS_CACHE is not None and _cache_fresh(_ALIAS_CACHE_LOADED_AT)),
        "aliases_count": len(_ALIAS_ROWS_CACHE or []),
        "products_age_seconds": round(time.time() - _PRODUCT_CACHE_LOADED_AT, 2) if _PRODUCT_CACHE_LOADED_AT else None,
        "aliases_age_seconds": round(time.time() - _ALIAS_CACHE_LOADED_AT, 2) if _ALIAS_CACHE_LOADED_AT else None,
    }


def set_read_only_mode(enabled: bool = True) -> None:
    global READ_ONLY_MODE
    READ_ONLY_MODE = bool(enabled)


def configure_db_path(path: str) -> None:
    """Override DB path at runtime for safe tools and tests."""
    global DB_FILE, DB_PATH_SOURCE, BACKUPS_DIR
    DB_FILE, DB_PATH_SOURCE = resolve_db_path(path)
    BACKUPS_DIR = DB_FILE.parent / "backups"
    invalidate_runtime_caches()

PRODUCT_COLUMNS = [
    "merchant_id", "product_id", "identity_key", "name", "normalized_name", "brand", "company", "category", "main_section", "sub_section", "subcategory", "section", "product_family",
    "form", "product_type", "active_ingredient", "strength", "size", "pack", "barcode", "aliases",
    "ocr_keywords", "use_case", "skin_type", "body_area", "age_group", "gender", "medicine_form",
    "medicine_route", "available", "price", "currency", "search_mode", "quality_status", "is_substitutable",
    "substitution_group_id", "review_status", "review_notes", "source_serial", "original_name",
]
TEXT_COLUMNS = {c: "TEXT DEFAULT ''" for c in PRODUCT_COLUMNS}
# SQLite does not allow ALTER TABLE ... ADD COLUMN with non-constant
# defaults such as CURRENT_TIMESTAMP. These timestamp columns are therefore
# added without defaults during migrations. Insert/update code is responsible
# for writing datetime('now'), and init_db backfills old rows idempotently.
TEXT_COLUMNS.update({
    "created_at": "TEXT",
    "updated_at": "TEXT",
})

VISIBLE_REVIEW = {"", "ok", "ready", "approved", "valid"}
VISIBLE_QUALITY = {"", "ok", "ready", "approved", "verified", "partial", "good"}
HIDDEN_SEARCH_MODES = {"review_only", "needs_review", "unknown", "hidden"}
GUIDED_HIDDEN_SEARCH_MODES = HIDDEN_SEARCH_MODES | {"exact_only"}


def _env_true(name: str) -> bool:
    return str(os.getenv(name, "")).strip().lower() in {"1", "true", "yes", "on", "production"}


def _min_products_guard() -> int:
    try:
        return int(os.getenv("PRICEBOT_MIN_PRODUCTS_GUARD", "1000") or 1000)
    except Exception:
        return 1000


def get_db_path() -> Path:
    return DB_FILE


def import_lock_path() -> Path:
    return DB_FILE.parent / "import.lock"


def set_import_lock(job_id: int = 0) -> None:
    try:
        path = import_lock_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(job_id or "import") + "\n" + datetime.utcnow().isoformat(), encoding="utf-8")
    except Exception:
        pass


def clear_import_lock() -> None:
    try:
        import_lock_path().unlink(missing_ok=True)
    except Exception:
        pass


def import_in_progress() -> bool:
    try:
        if import_lock_path().exists():
            return True
    except Exception:
        pass
    try:
        with connect() as conn:
            if not table_exists(conn, "import_jobs"):
                return False
            row = conn.execute("SELECT 1 FROM import_jobs WHERE UPPER(status) IN ('PENDING','UPLOADED','PROCESSING') LIMIT 1").fetchone()
            return bool(row)
    except Exception:
        return False


class CompatRow(dict):
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


def _to_compat_row(row):
    if row is None:
        return None
    if isinstance(row, CompatRow):
        return row
    if isinstance(row, dict):
        return CompatRow(row)
    return row


class PgCursorCompat:
    def __init__(self, cur):
        self.cur = cur
        self.lastrowid = None
        self.rowcount = -1

    def fetchone(self):
        return _to_compat_row(self.cur.fetchone())

    def fetchall(self):
        return [_to_compat_row(r) for r in self.cur.fetchall()]

    def __iter__(self):
        for r in self.cur:
            yield _to_compat_row(r)


class PgConnectionCompat:
    def __init__(self, conn):
        self.conn = conn

    def _translate(self, sql: str, params=None):
        import re
        text = str(sql)
        stripped = text.strip()
        upper = stripped.upper()
        if upper.startswith("PRAGMA"):
            return None, params
        # SQLite DDL compatibility.
        text = text.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
        text = text.replace("AUTOINCREMENT", "")
        text = re.sub(r"\\bBOOLEAN\\s+DEFAULT\\s+1\\b", "BOOLEAN DEFAULT TRUE", text, flags=re.I)
        text = re.sub(r"\\bBOOLEAN\\s+DEFAULT\\s+0\\b", "BOOLEAN DEFAULT FALSE", text, flags=re.I)
        # SQLite current-time helpers.
        text = text.replace("datetime('now', ? || ' seconds')", "to_char(CURRENT_TIMESTAMP + (%s || ' seconds')::interval, 'YYYY-MM-DD HH24:MI:SS')")
        text = text.replace("datetime('now', ?)", "to_char(CURRENT_TIMESTAMP + (%s)::interval, 'YYYY-MM-DD HH24:MI:SS')")
        text = text.replace("datetime('now','+6 hours')", "to_char(CURRENT_TIMESTAMP + interval '6 hours', 'YYYY-MM-DD HH24:MI:SS')")
        text = text.replace("datetime('now', '+6 hours')", "to_char(CURRENT_TIMESTAMP + interval '6 hours', 'YYYY-MM-DD HH24:MI:SS')")
        text = text.replace("datetime('now')", "to_char(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS')")
        # INSERT OR IGNORE -> ON CONFLICT DO NOTHING.
        if upper.startswith("INSERT OR IGNORE INTO"):
            text = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT INTO", text, flags=re.I)
            if " ON CONFLICT " not in text.upper():
                text += " ON CONFLICT DO NOTHING"
        # INSERT OR REPLACE is only used for derived indexes. Since callers clear
        # those tables first, plain INSERT is sufficient and avoids SQLite-only syntax.
        if upper.startswith("INSERT OR REPLACE INTO"):
            text = re.sub(r"INSERT\s+OR\s+REPLACE\s+INTO", "INSERT INTO", text, flags=re.I)
        # Placeholder conversion after literal date helper rewrites.
        out = []
        in_single = False
        for ch in text:
            if ch == "'":
                in_single = not in_single
                out.append(ch)
            elif ch == "?" and not in_single:
                out.append("%s")
            else:
                out.append(ch)
        text = "".join(out)
        return text, params

    def execute(self, sql: str, params: Sequence[Any] = ()):  # sqlite-like API
        translated, params = self._translate(sql, params)
        wrapper = PgCursorCompat(self.conn.cursor())
        if translated is None:
            wrapper.rowcount = -1
            return wrapper
        # Add RETURNING id for simple inserts where code expects lastrowid.
        needs_last_id = translated.strip().upper().startswith("INSERT INTO") and "RETURNING" not in translated.upper() and "ON CONFLICT DO NOTHING" not in translated.upper()
        exec_sql = translated + " RETURNING id" if needs_last_id else translated
        try:
            wrapper.cur.execute(exec_sql, params or ())
        except Exception:
            if needs_last_id:
                wrapper.cur.execute(translated, params or ())
            else:
                raise
        wrapper.rowcount = wrapper.cur.rowcount
        try:
            if needs_last_id:
                row = wrapper.cur.fetchone()
                if row:
                    row = _to_compat_row(row)
                    wrapper.lastrowid = row[0]
        except Exception:
            pass
        return wrapper

    def executemany(self, sql: str, seq_of_params):
        translated, _ = self._translate(sql, ())
        wrapper = PgCursorCompat(self.conn.cursor())
        if translated is None:
            return wrapper
        wrapper.cur.executemany(translated, seq_of_params)
        wrapper.rowcount = wrapper.cur.rowcount
        return wrapper

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()


@contextmanager
def connect() -> Iterable[Any]:
    if IS_POSTGRES:
        try:
            import psycopg
            from psycopg.rows import dict_row as pg_dict_row
        except Exception as exc:
            raise RuntimeError("POSTGRES_PRODUCTION_REQUIRES_psycopg_binary") from exc
        if READ_ONLY_MODE:
            # Read-only enforcement is database/role-level for PostgreSQL.
            pass
        conn = psycopg.connect(DATABASE_URL_RAW, row_factory=pg_dict_row, autocommit=False)
        compat = PgConnectionCompat(conn)
        try:
            yield compat
            if not READ_ONLY_MODE:
                compat.commit()
        except Exception:
            if not READ_ONLY_MODE:
                compat.rollback()
            raise
        finally:
            compat.close()
        return

    if READ_ONLY_MODE:
        if not DB_FILE.exists():
            raise FileNotFoundError(f"DB not found for read-only connection: {DB_FILE}")
        uri = f"file:{DB_FILE}?mode=ro"
        conn = sqlite3.connect(uri, timeout=30, uri=True)
    else:
        DB_FILE.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_FILE), timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA foreign_keys=ON")
        # Performance hardening for SQLite production deployments.
        # These PRAGMAs are connection-local or idempotent and safe for existing DBs.
        try:
            conn.execute("PRAGMA temp_store=MEMORY")
            conn.execute("PRAGMA cache_size=-20000")  # ~20MB page cache per connection.
            conn.execute("PRAGMA mmap_size=268435456")  # Best-effort 256MB mmap window.
        except Exception:
            pass
        if not READ_ONLY_MODE:
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.execute("PRAGMA wal_autocheckpoint=1000")
            except Exception:
                pass
        yield conn
        if not READ_ONLY_MODE:
            conn.commit()
    except Exception:
        if not READ_ONLY_MODE:
            conn.rollback()
        raise
    finally:
        conn.close()


def dict_row(row: Optional[Any]) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    return {k: row[k] for k in row.keys()}


def table_exists(conn: Any, table: str) -> bool:
    if IS_POSTGRES:
        row = conn.execute("SELECT to_regclass(%s) AS exists", (table,)).fetchone()
        return bool(row and row[0])
    return bool(conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def table_columns(conn: Any, table: str) -> List[str]:
    if not table_exists(conn, table):
        return []
    if IS_POSTGRES:
        rows = conn.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s ORDER BY ordinal_position",
            (table,),
        ).fetchall()
        return [str(r[0]) for r in rows]
    return [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()]




def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _create_index_if_columns_exist(conn: Any, index_name: str, table: str, columns: Sequence[str]) -> bool:
    """Create an index only when the target table and all columns exist.

    The function is intentionally defensive because deployed databases may have
    schema differences from older PriceBot builds. Missing optional tables/fields
    are skipped instead of failing startup.
    """
    if not table_exists(conn, table):
        return False
    available = set(table_columns(conn, table))
    if not all(c in available for c in columns):
        return False
    quoted_table = _quote_ident(table)
    quoted_cols = ", ".join(_quote_ident(c) for c in columns)
    conn.execute(f"CREATE INDEX IF NOT EXISTS {_quote_ident(index_name)} ON {quoted_table} ({quoted_cols})")
    return True


def apply_performance_hardening(conn: Optional[Any] = None) -> Dict[str, Any]:
    """Apply idempotent SQLite speed/stability tuning.

    This is the first production hardening layer:
    - WAL/normal sync/busy timeout for fewer lock errors.
    - Wider search/import/runtime indexes.
    - ANALYZE/optimize so SQLite planner uses fresh statistics.

    It never deletes products, never changes prices, and never modifies .env.
    """
    stats: Dict[str, Any] = {"ok": True, "created_or_verified_indexes": 0, "skipped": 0, "journal_mode": ""}

    def _run(active_conn: Any) -> Dict[str, Any]:
        if IS_POSTGRES:
            stats["engine"] = "postgres"
            return stats
        stats["engine"] = "sqlite"
        try:
            row = active_conn.execute("PRAGMA journal_mode=WAL").fetchone()
            stats["journal_mode"] = str(row[0] if row else "")
            active_conn.execute("PRAGMA synchronous=NORMAL")
            active_conn.execute("PRAGMA busy_timeout=30000")
            active_conn.execute("PRAGMA temp_store=MEMORY")
            active_conn.execute("PRAGMA cache_size=-20000")
            active_conn.execute("PRAGMA mmap_size=268435456")
            active_conn.execute("PRAGMA wal_autocheckpoint=1000")
        except Exception as exc:
            stats["pragma_warning"] = repr(exc)

        index_specs = [
            # Customer search and product visibility.
            ("idx_perf_products_visible_search", "products", ["available", "is_available", "search_mode", "review_status"]),
            ("idx_perf_products_name_available", "products", ["normalized_name", "available", "is_available"]),
            ("idx_perf_products_identity", "products", ["identity_key"]),
            ("idx_perf_products_brand", "products", ["brand"]),
            ("idx_perf_products_family", "products", ["product_family"]),
            ("idx_perf_products_active_ingredient", "products", ["active_ingredient"]),
            ("idx_perf_products_upload_seen", "products", ["merchant_id", "last_seen_in_upload"]),
            ("idx_perf_products_review", "products", ["merchant_id", "needs_review", "review_status"]),
            ("idx_perf_products_sections", "products", ["merchant_id", "main_section", "sub_section"]),
            ("idx_perf_products_category_sub", "products", ["merchant_id", "category", "subcategory"]),
            # Alias matching.
            ("idx_perf_alias_cleaned_active", "product_aliases", ["cleaned_alias", "active"]),
            ("idx_perf_alias_normalized_active", "product_aliases", ["normalized_alias", "active"]),
            ("idx_perf_alias_text_active", "product_aliases", ["alias_text", "active"]),
            ("idx_perf_alias_product_active", "product_aliases", ["product_id", "active"]),
            # Search and guided catalog browsing.
            ("idx_perf_search_key_kind", "product_search_index", ["key", "kind"]),
            ("idx_perf_search_product", "product_search_index", ["product_db_id"]),
            ("idx_perf_guided_visible", "guided_catalog_index", ["visible", "main_section", "sub_section"]),
            ("idx_perf_guided_product", "guided_catalog_index", ["product_db_id"]),
            # Runtime tables.
            ("idx_perf_conversation_expiry", "conversation_state", ["expires_at"]),
            ("idx_perf_conversation_updated", "conversation_state", ["updated_at"]),
            ("idx_perf_processed_created", "processed_messages", ["created_at"]),
            ("idx_perf_import_status_created", "import_jobs", ["merchant_id", "status", "created_at"]),
            ("idx_perf_review_status_created", "review_queue", ["merchant_id", "resolved", "created_at"]),
            # Image/Gemini cache.
            ("idx_perf_image_cache_hash", "image_cache", ["image_hash"]),
            ("idx_perf_image_cache_media_updated", "image_cache", ["media_id", "updated_at"]),
            ("idx_perf_image_cache_decision", "image_cache", ["decision", "updated_at"]),
            ("idx_perf_image_product_cache_hash", "image_product_cache", ["image_hash"]),
            ("idx_perf_safe_text_memory_query_active", "safe_text_memory", ["normalized_query", "active"]),
            ("idx_perf_safe_text_memory_product_active", "safe_text_memory", ["product_id", "active"]),
            ("idx_perf_image_product_cache_media_updated", "image_product_cache", ["media_id", "updated_at"]),
            # Visual memory tables vary by build; skipped safely when absent.
            ("idx_perf_visual_memory_product", "visual_memory", ["product_id"]),
            ("idx_perf_visual_memory_hash", "visual_memory", ["image_hash"]),
            ("idx_perf_visual_memory_merchant", "visual_memory", ["merchant_id"]),
            ("idx_perf_learning_status_created", "learning_inbox", ["status", "created_at"]),
        ]
        for spec in index_specs:
            try:
                if _create_index_if_columns_exist(active_conn, *spec):
                    stats["created_or_verified_indexes"] += 1
                else:
                    stats["skipped"] += 1
            except Exception as exc:
                stats.setdefault("index_warnings", []).append({"index": spec[0], "error": repr(exc)})
        try:
            active_conn.execute("ANALYZE")
        except Exception as exc:
            stats["analyze_warning"] = repr(exc)
        try:
            active_conn.execute("PRAGMA optimize")
        except Exception:
            pass
        return stats

    if conn is not None:
        return _run(conn)
    with connect() as owned_conn:
        return _run(owned_conn)


def sqlite_performance_status() -> Dict[str, Any]:
    """Return lightweight SQLite performance settings for /health/deep."""
    if IS_POSTGRES:
        return {"engine": "postgres"}
    with connect() as conn:
        def scalar(sql: str) -> Any:
            try:
                row = conn.execute(sql).fetchone()
                return row[0] if row else None
            except Exception as exc:
                return f"error:{exc!r}"
        return {
            "engine": "sqlite",
            "db_path": str(DB_FILE),
            "journal_mode": scalar("PRAGMA journal_mode"),
            "synchronous": scalar("PRAGMA synchronous"),
            "busy_timeout": scalar("PRAGMA busy_timeout"),
            "cache_size": scalar("PRAGMA cache_size"),
            "mmap_size": scalar("PRAGMA mmap_size"),
            "wal_autocheckpoint": scalar("PRAGMA wal_autocheckpoint"),
        }

def _sqlite_safe_add_column_type(ddl_type: str) -> str:
    """Return an ADD COLUMN-safe declaration for SQLite migrations.

    SQLite rejects ALTER TABLE ... ADD COLUMN when the column has a
    non-constant default such as CURRENT_TIMESTAMP, CURRENT_DATE,
    CURRENT_TIME, or expression defaults. CREATE TABLE may still use those
    defaults, but migrations must not.
    """
    ddl = str(ddl_type or "TEXT").strip() or "TEXT"
    upper = ddl.upper()
    non_constant_defaults = ("CURRENT_TIMESTAMP", "CURRENT_DATE", "CURRENT_TIME")
    if " DEFAULT " in upper and any(token in upper for token in non_constant_defaults):
        before_default = upper.split(" DEFAULT ", 1)[0].strip()
        for affinity in ("INTEGER", "REAL", "NUMERIC", "BLOB", "TEXT"):
            if affinity in before_default.split():
                return affinity
        return "TEXT"
    return ddl


def _pg_column_type(ddl_type: str) -> str:
    ddl = str(ddl_type or "TEXT").strip() or "TEXT"
    ddl = ddl.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
    ddl = ddl.replace("AUTOINCREMENT", "")
    return ddl


def add_column(conn: Any, table: str, col: str, ddl_type: str) -> None:
    if col not in table_columns(conn, table):
        if IS_POSTGRES:
            conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}" {_pg_column_type(ddl_type)}')
        else:
            safe_type = _sqlite_safe_add_column_type(ddl_type)
            conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}" {safe_type}')




def clean_alias_text(value: object, ignore_articles: bool = False) -> str:
    """Clean alias strings for exact alias matching.

    This is intentionally stricter than fuzzy search: lowercase, Unicode/Arabic
    normalization through normalize_text(), punctuation removal, and whitespace
    collapse only.  It does not perform approximate matching.
    """
    text = normalize_text(value)
    if ignore_articles and text:
        text = " ".join(t for t in text.split() if t not in {"the", "a", "an"})
    return " ".join(text.split()).strip()


def ensure_product_aliases_schema(conn: Any) -> None:
    """Create/upgrade product_aliases without touching products.

    Required fields for the uploaded AI alias dictionary are: product_id,
    alias_text, cleaned_alias, confidence, source, active.  Older PriceBot
    builds also used alias/alias_normalized/normalized_alias/is_active, so those
    columns remain available for existing Catalog Ingestion code.
    """
    conn.execute("""
        CREATE TABLE IF NOT EXISTS product_aliases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            alias_text TEXT,
            cleaned_alias TEXT,
            confidence REAL DEFAULT 0.95,
            source TEXT DEFAULT 'ai_generated',
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    for col, ddl in {
        "product_id": "INTEGER",
        "product_db_id": "INTEGER",
        "alias_text": "TEXT",
        "cleaned_alias": "TEXT",
        "confidence": "REAL DEFAULT 0.95",
        "source": "TEXT DEFAULT 'ai_generated'",
        "active": "INTEGER DEFAULT 1",
        "alias": "TEXT DEFAULT ''",
        "alias_normalized": "TEXT",
        "normalized_alias": "TEXT DEFAULT ''",
        "is_active": "INTEGER DEFAULT 1",
        "approved": "INTEGER DEFAULT 1",
        "created_at": "TEXT",
        "updated_at": "TEXT",
    }.items():
        add_column(conn, "product_aliases", col, ddl)
    # Keep old/new column names synchronized for exact lookups.
    try:
        conn.execute("UPDATE product_aliases SET product_db_id=COALESCE(product_db_id, product_id) WHERE product_db_id IS NULL AND product_id IS NOT NULL")
        conn.execute("UPDATE product_aliases SET product_id=COALESCE(product_id, product_db_id) WHERE product_id IS NULL AND product_db_id IS NOT NULL")
        conn.execute("UPDATE product_aliases SET alias_text=COALESCE(NULLIF(alias_text,''), alias) WHERE (alias_text IS NULL OR alias_text='') AND alias<>''")
        conn.execute("UPDATE product_aliases SET alias=COALESCE(NULLIF(alias,''), alias_text) WHERE (alias IS NULL OR alias='') AND alias_text<>''")
        conn.execute("UPDATE product_aliases SET cleaned_alias=COALESCE(NULLIF(cleaned_alias,''), alias_normalized, normalized_alias) WHERE (cleaned_alias IS NULL OR cleaned_alias='')")
        conn.execute("UPDATE product_aliases SET alias_normalized=COALESCE(NULLIF(alias_normalized,''), cleaned_alias, normalized_alias) WHERE (alias_normalized IS NULL OR alias_normalized='')")
        conn.execute("UPDATE product_aliases SET normalized_alias=COALESCE(NULLIF(normalized_alias,''), cleaned_alias, alias_normalized) WHERE (normalized_alias IS NULL OR normalized_alias='')")
        conn.execute("UPDATE product_aliases SET active=COALESCE(active, is_active, approved, 1) WHERE active IS NULL")
        conn.execute("UPDATE product_aliases SET is_active=COALESCE(is_active, active, approved, 1) WHERE is_active IS NULL")
    except Exception:
        pass
    conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_cleaned ON product_aliases(cleaned_alias, active)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_product ON product_aliases(product_id, active)")
    try:
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_product_aliases_ai_active ON product_aliases(product_id, cleaned_alias, source) WHERE active=1")
    except Exception:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_aliases_ai_active_nonunique ON product_aliases(product_id, cleaned_alias, source, active)")



def lookup_product_by_alias_exact(texts: Sequence[object], ignore_articles: bool = False) -> Dict[str, Any]:
    """Return one product for exact alias match, or an ambiguity/no-match result.

    The image path uses this only as a confirmation candidate.  It never displays
    price directly from an alias hit.
    """
    cleaned_values = []
    seen = set()
    for value in texts or []:
        clean = clean_alias_text(value, ignore_articles=False)
        if clean and clean not in seen:
            cleaned_values.append(clean); seen.add(clean)
        if ignore_articles:
            clean2 = clean_alias_text(value, ignore_articles=True)
            if clean2 and clean2 not in seen:
                cleaned_values.append(clean2); seen.add(clean2)
    if not cleaned_values:
        return {"status": "NO_MATCH", "cleaned_values": []}
    placeholders = ",".join("?" for _ in cleaned_values)
    with connect() as conn:
        if not table_exists(conn, "product_aliases"):
            return {"status": "NO_MATCH", "cleaned_values": cleaned_values}
        ensure_product_aliases_schema(conn)
        rows = conn.execute(f"""
            SELECT pa.*, p.name AS product_name
            FROM product_aliases pa
            JOIN products p ON p.id = pa.product_id
            WHERE COALESCE(pa.active, pa.is_active, pa.approved, 1)=1
              AND pa.cleaned_alias IN ({placeholders})
            ORDER BY pa.confidence DESC, pa.id ASC
        """, tuple(cleaned_values)).fetchall()
        matches = [dict_row(r) for r in rows if r]
        product_ids = sorted({int(m.get("product_id") or 0) for m in matches if int(m.get("product_id") or 0)})
        if not product_ids:
            return {"status": "NO_MATCH", "cleaned_values": cleaned_values}
        if len(product_ids) > 1:
            return {"status": "AMBIGUOUS", "product_ids": product_ids, "matches": matches, "cleaned_values": cleaned_values}
        product = get_product(product_ids[0])
        if not product:
            return {"status": "NO_MATCH", "cleaned_values": cleaned_values}
        return {"status": "EXACT_ALIAS_MATCH", "product": product, "matches": matches, "cleaned_values": cleaned_values}

def integrity_check() -> str:
    if IS_POSTGRES:
        with connect() as conn:
            conn.execute("SELECT 1")
        return "ok"
    if not DB_FILE.exists():
        return "missing"
    with connect() as conn:
        row = conn.execute("PRAGMA integrity_check").fetchone()
        return str(row[0] if row else "failed")


def validate_production_db_or_fail(min_products: Optional[int] = None) -> None:
    if not (_env_true("PRICEBOT_PRODUCTION_MODE") or _env_true("PRICEBOT_STRICT_DB_STARTUP")):
        return
    min_products = _min_products_guard() if min_products is None else int(min_products)
    if IS_POSTGRES:
        with connect() as conn:
            if not table_exists(conn, "products"):
                raise RuntimeError("PRODUCTION_DB_STARTUP_FAILED | postgres products_table_missing")
            count = conn.execute("SELECT COUNT(*) AS count FROM products").fetchone()[0]
            if int(count) < min_products:
                raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | postgres products={count} | min={min_products}")
        return
    if _env_true("PRICEBOT_REQUIRE_POSTGRES_PRODUCTION"):
        raise RuntimeError("PRODUCTION_REQUIRES_POSTGRES_DATABASE_URL")
    if not DB_FILE.exists():
        raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | db_missing | {DB_FILE}")
    with DB_FILE.open("rb") as fh:
        if fh.read(16) != b"SQLite format 3\x00":
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | not_sqlite | {DB_FILE}")
    with connect() as conn:
        result = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if str(result).lower() != "ok":
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | integrity={result}")
        if not table_exists(conn, "products"):
            raise RuntimeError("PRODUCTION_DB_STARTUP_FAILED | products_table_missing")
        count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count < min_products:
            raise RuntimeError(f"PRODUCTION_DB_STARTUP_FAILED | products={count} | min={min_products}")


def init_db(run_production_guard: bool = True) -> None:
    if run_production_guard:
        validate_production_db_or_fail()
    with connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL DEFAULT '')")
        for col, ddl in TEXT_COLUMNS.items():
            add_column(conn, "products", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_norm ON products(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_product_id ON products(product_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)")
        # Weekly stock-tracking columns. These are additive only; weekly uploads
        # never delete products and never replace pricebot.db.
        add_column(conn, "products", "is_available", "INTEGER DEFAULT 1")
        add_column(conn, "products", "last_seen_in_upload", "TEXT")
        add_column(conn, "products", "needs_review", "INTEGER DEFAULT 0")
        conn.execute("UPDATE products SET is_available=1 WHERE is_available IS NULL")
        conn.execute("UPDATE products SET available='1' WHERE (available IS NULL OR available='') AND COALESCE(is_available,1)=1")
        conn.execute("UPDATE products SET available='0' WHERE COALESCE(is_available,1)=0")
        conn.execute("UPDATE products SET needs_review=0 WHERE needs_review IS NULL")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_merchant ON products(merchant_id, available)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_products_weekly_stock ON products(merchant_id, is_available, needs_review)")

        # AI/generated product aliases used by Vision confirmation.
        # This table is additive and safe for existing deployments: no product
        # rows are deleted or rewritten, and legacy alias columns are preserved
        # for Catalog Ingestion compatibility.
        ensure_product_aliases_schema(conn)
        # Idempotent timestamp backfill for old/existing product rows after
        # SQLite-safe ADD COLUMN migrations. No DROP/DELETE is used.
        product_cols = set(table_columns(conn, "products"))
        if "created_at" in product_cols:
            conn.execute("UPDATE products SET created_at=datetime('now') WHERE created_at IS NULL OR created_at=''")
        if "updated_at" in product_cols:
            conn.execute("UPDATE products SET updated_at=datetime('now') WHERE updated_at IS NULL OR updated_at=''")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_search_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL,
                kind TEXT NOT NULL,
                product_db_id INTEGER NOT NULL,
                weight INTEGER DEFAULT 0,
                UNIQUE(key, kind, product_db_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_index_key ON product_search_index(key)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS guided_catalog_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                main_section TEXT NOT NULL,
                sub_section TEXT DEFAULT '',
                product_type TEXT DEFAULT '',
                use_case TEXT DEFAULT '',
                skin_type TEXT DEFAULT '',
                body_area TEXT DEFAULT '',
                age_group TEXT DEFAULT '',
                visible INTEGER DEFAULT 1,
                sort_name TEXT DEFAULT '',
                UNIQUE(product_db_id, main_section, sub_section, skin_type)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_guided_main ON guided_catalog_index(main_section, sub_section, visible)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversation_state (
                phone TEXT PRIMARY KEY,
                state_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            )
        """)
        add_column(conn, "conversation_state", "created_at", "TEXT")
        add_column(conn, "conversation_state", "expires_at", "TEXT")
        conn.execute("UPDATE conversation_state SET created_at=COALESCE(NULLIF(created_at,''), datetime('now')) WHERE created_at IS NULL OR created_at=''")
        conn.execute("UPDATE conversation_state SET expires_at=datetime('now','+6 hours') WHERE expires_at IS NULL OR expires_at=''")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT NOT NULL,
                product_db_id INTEGER,
                product_name TEXT DEFAULT '',
                quantity INTEGER DEFAULT 1,
                price TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        for col, ddl in {
            "merchant_id": "INTEGER DEFAULT 1",
            "customer_name": "TEXT DEFAULT ''",
            "notes": "TEXT DEFAULT ''",
        }.items():
            add_column(conn, "orders", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_orders_merchant_status ON orders(merchant_id, status, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS search_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_id INTEGER,
                product_name TEXT DEFAULT '',
                user_id TEXT DEFAULT '',
                source TEXT DEFAULT 'whatsapp_confirmation',
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_logs_product_time ON search_logs(merchant_id, product_id, timestamp)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_search_logs_time ON search_logs(timestamp)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_upload_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                filename TEXT DEFAULT '',
                products_count INTEGER DEFAULT 0,
                backup_path TEXT DEFAULT '',
                status TEXT DEFAULT 'success',
                message TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_product_upload_history_time ON product_upload_history(merchant_id, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS upload_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                upload_time TEXT DEFAULT CURRENT_TIMESTAMP,
                filename TEXT DEFAULT '',
                total_rows INTEGER DEFAULT 0,
                new_products INTEGER DEFAULT 0,
                updated_products INTEGER DEFAULT 0,
                deactivated_products INTEGER DEFAULT 0,
                review_products INTEGER DEFAULT 0,
                status TEXT DEFAULT 'success',
                message TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_upload_history_time ON upload_history(merchant_id, upload_time)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS import_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                job_type TEXT DEFAULT 'weekly_upload',
                filename TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                status TEXT DEFAULT 'UPLOADED',
                progress INTEGER DEFAULT 0,
                inserted INTEGER DEFAULT 0,
                updated INTEGER DEFAULT 0,
                skipped INTEGER DEFAULT 0,
                unmatched INTEGER DEFAULT 0,
                ambiguous INTEGER DEFAULT 0,
                summary TEXT DEFAULT '',
                error TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                finished_at TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_import_jobs_status ON import_jobs(merchant_id, status, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS review_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER DEFAULT 1,
                product_name TEXT DEFAULT '',
                similar_existing_id INTEGER,
                temp_product_id INTEGER,
                uploaded_price TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                resolved INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                resolved_at TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_review_queue_status ON review_queue(merchant_id, resolved, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS processed_messages (
                message_id TEXT PRIMARY KEY,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS dynamic_synonyms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                target TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(source, target)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_dynamic_synonyms_source ON dynamic_synonyms(source, enabled)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS image_product_cache (
                image_hash TEXT PRIMARY KEY,
                media_id TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                confidence TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_image_cache_media ON image_product_cache(media_id)")


        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_identity_registry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_db_id INTEGER NOT NULL,
                product_id TEXT DEFAULT '',
                identity_key TEXT NOT NULL,
                canonical_name TEXT DEFAULT '',
                normalized_name TEXT DEFAULT '',
                compact_name TEXT DEFAULT '',
                brand TEXT DEFAULT '',
                product_family TEXT DEFAULT '',
                form TEXT DEFAULT '',
                strength TEXT DEFAULT '',
                size TEXT DEFAULT '',
                pack TEXT DEFAULT '',
                barcode TEXT DEFAULT '',
                aliases TEXT DEFAULT '',
                ocr_keywords TEXT DEFAULT '',
                category TEXT DEFAULT '',
                search_policy TEXT DEFAULT 'sellable_exact',
                duplicate_group TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(product_db_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_norm ON product_identity_registry(normalized_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_compact ON product_identity_registry(compact_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_barcode ON product_identity_registry(barcode)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_brand_family ON product_identity_registry(brand, product_family)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_identity_key ON product_identity_registry(identity_key)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS learning_inbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_query TEXT DEFAULT '',
                vision_text TEXT DEFAULT '',
                candidate_products TEXT DEFAULT '[]',
                decision TEXT DEFAULT '',
                reason TEXT DEFAULT '',
                admin_action TEXT DEFAULT '',
                selected_product_id INTEGER,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_learning_inbox_status ON learning_inbox(status, created_at)")
        # Idempotent schema upgrades for production learning/catalog/admin safety.
        for col, ddl in {
            "image_id": "TEXT DEFAULT ''",
            "media_id": "TEXT DEFAULT ''",
            "raw_vision_text": "TEXT DEFAULT ''",
            "main_visible_product": "TEXT DEFAULT ''",
            "background_text": "TEXT DEFAULT ''",
            "query_slots": "TEXT DEFAULT '{}'",
            "rejected_candidates": "TEXT DEFAULT '[]'",
            "created_by": "TEXT DEFAULT ''",
            "merchant_id": "INTEGER DEFAULT 1",
        }.items():
            add_column(conn, "learning_inbox", col, ddl)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                actor TEXT DEFAULT '',
                ip TEXT DEFAULT '',
                details TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_admin_audit_event ON admin_audit_log(event, created_at)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                role TEXT DEFAULT 'owner',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_roles (
                role TEXT PRIMARY KEY,
                permissions TEXT DEFAULT '[]',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_hash TEXT UNIQUE NOT NULL,
                username TEXT DEFAULT 'owner',
                role TEXT DEFAULT 'owner',
                ip TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT
            )
        """)
        for _role, _perms in {
            'owner': ['*'],
            'admin': ['catalog:*', 'learning:*', 'orders:*', 'users:*', 'merchants:*'],
            'pharmacist': ['learning:*', 'orders:*', 'products:edit', 'catalog:upload'],
            'viewer': ['read:*'],
        }.items():
            conn.execute("INSERT OR IGNORE INTO admin_roles(role, permissions) VALUES(?, ?)", (_role, json.dumps(_perms)))
        add_column(conn, "admin_users", "merchant_id", "INTEGER DEFAULT 1")
        add_column(conn, "admin_users", "password_salt", "TEXT DEFAULT ''")
        add_column(conn, "admin_users", "password_hash", "TEXT DEFAULT ''")
        add_column(conn, "admin_users", "display_name", "TEXT DEFAULT ''")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS merchants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL DEFAULT '',
                slug TEXT UNIQUE DEFAULT '',
                whatsapp_number TEXT DEFAULT '',
                phone_number_id TEXT DEFAULT '',
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("INSERT OR IGNORE INTO merchants(id, name, slug, whatsapp_number, active) VALUES(1, ?, 'default', '', 1)", (os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"),))

        # Self-Learning Visual Overlay tables. These are derived layers only;
        # they do not edit products or the source Excel.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS visual_product_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                image_signature TEXT NOT NULL,
                canonical_name TEXT NOT NULL,
                excel_name TEXT NOT NULL,
                product_id INTEGER,
                brand TEXT,
                form TEXT,
                strength TEXT,
                size TEXT,
                confidence INTEGER DEFAULT 1,
                last_seen_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            )
        """)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_visual_signature ON visual_product_memory(merchant_id, image_signature)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_visual_product_memory_product ON visual_product_memory(product_id, confidence)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS product_identity_overlay (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id INTEGER NOT NULL,
                original_excel_name TEXT NOT NULL,
                normalized_excel_name TEXT NOT NULL,
                brand TEXT,
                canonical_name TEXT NOT NULL,
                form TEXT,
                strength TEXT,
                size TEXT,
                pack TEXT,
                source TEXT DEFAULT 'auto_learned',
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (merchant_id) REFERENCES merchants(id)
            )
        """)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_overlay_unique ON product_identity_overlay(merchant_id, normalized_excel_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_overlay_active ON product_identity_overlay(merchant_id, is_active, brand, form, strength, size)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS merchant_settings (
                merchant_id INTEGER PRIMARY KEY,
                pharmacy_name TEXT DEFAULT '',
                whatsapp_number TEXT DEFAULT '',
                qr_message TEXT DEFAULT '',
                working_hours TEXT DEFAULT '24 ساعة',
                delivery_enabled INTEGER DEFAULT 0,
                currency TEXT DEFAULT 'LYD',
                welcome_text TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        for col, ddl in {
            "working_hours": "TEXT DEFAULT '24 ساعة'",
            "delivery_enabled": "INTEGER DEFAULT 0",
            "currency": "TEXT DEFAULT 'LYD'",
            "welcome_text": "TEXT DEFAULT ''",
        }.items():
            add_column(conn, "merchant_settings", col, ddl)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_review_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                merchant_id INTEGER DEFAULT 1,
                issue_type TEXT DEFAULT '',
                severity TEXT DEFAULT 'review',
                row_json TEXT DEFAULT '{}',
                duplicate_key TEXT DEFAULT '',
                price_old TEXT DEFAULT '',
                price_new TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_review_job ON catalog_review_items(job_id, status, issue_type)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_import_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT DEFAULT '',
                staging_db_path TEXT DEFAULT '',
                status TEXT DEFAULT 'uploaded',
                added INTEGER DEFAULT 0,
                updated INTEGER DEFAULT 0,
                duplicate_conflicts INTEGER DEFAULT 0,
                needs_review INTEGER DEFAULT 0,
                unclassified INTEGER DEFAULT 0,
                missing_form_strength_size INTEGER DEFAULT 0,
                report_text TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_catalog_import_status ON catalog_import_jobs(status, created_at)")
        for col, ddl in {
            "job_type": "TEXT DEFAULT ''",
            "started_at": "TEXT",
            "finished_at": "TEXT",
            "error_text": "TEXT DEFAULT ''",
            "merchant_id": "INTEGER DEFAULT 1",
            "requires_approval": "INTEGER DEFAULT 1",
            "verified": "INTEGER DEFAULT 0",
            "acceptance_passed": "INTEGER DEFAULT 0",
            "approval_user": "TEXT DEFAULT ''",
            "approved_at": "TEXT",
        }.items():
            add_column(conn, "catalog_import_jobs", col, ddl)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS catalog_import_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                report_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Preferred name requested by the production spec. Keep the old
        # image_product_cache table for backward compatibility.
        conn.execute("""
            CREATE TABLE IF NOT EXISTS image_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                image_hash TEXT UNIQUE,
                media_id TEXT DEFAULT '',
                extracted_slots TEXT DEFAULT '{}',
                matched_product_id INTEGER,
                decision TEXT DEFAULT '',
                confidence TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_image_cache_media ON image_cache(media_id)")

        # Gemini Safe Economy Mode: conservative exact-memory layer.
        # It never stores fuzzy image similarity and never bypasses user confirmation.
        ensure_safe_economy_schema(conn)

        # Idempotent startup hardening: PRAGMAs + search/runtime indexes + ANALYZE.
        apply_performance_hardening(conn)


def backup_db(label: str = "manual") -> Path:
    if IS_POSTGRES:
        # PostgreSQL production imports are transactional.  This marker records
        # the migration/import point without pretending to create a SQLite file.
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        marker = BACKUPS_DIR / f"postgres_transactional_backup_marker_{label}_{stamp}.txt"
        marker.write_text("PostgreSQL import uses transaction rollback plus migrated source backup.\n", encoding="utf-8")
        return marker
    if not DB_FILE.exists():
        raise FileNotFoundError(f"DB not found: {DB_FILE}")
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = BACKUPS_DIR / f"pricebot_{label}_{stamp}.db"
    src = sqlite3.connect(str(DB_FILE), timeout=30)
    dst = sqlite3.connect(str(backup), timeout=30)
    try:
        src.backup(dst)
    finally:
        src.close(); dst.close()
    return backup


def restore_db_from_backup(backup_path: Path) -> None:
    if IS_POSTGRES:
        raise RuntimeError("POSTGRES_RESTORE_USES_DATABASE_BACKUP_TOOLING_NOT_SQLITE_COPY")
    backup_path = Path(backup_path)
    if not backup_path.exists():
        raise FileNotFoundError(str(backup_path))
    test = sqlite3.connect(str(backup_path), timeout=10)
    try:
        res = test.execute("PRAGMA integrity_check").fetchone()[0]
        if str(res).lower() != "ok":
            raise RuntimeError(f"backup integrity failed: {res}")
    finally:
        test.close()
    if DB_FILE.exists():
        emergency = backup_db("before_restore")
        print(f"PRE_RESTORE_BACKUP={emergency}")
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(backup_path, DB_FILE)


def audit(event: str, details: Any = None) -> None:
    try:
        payload = json.dumps(details or {}, ensure_ascii=False, default=str)
        with connect() as conn:
            if table_exists(conn, "audit_logs"):
                conn.execute("INSERT INTO audit_logs(event, details) VALUES(?, ?)", (event, payload))
            if table_exists(conn, "admin_audit_log"):
                conn.execute("INSERT INTO admin_audit_log(event, details) VALUES(?, ?)", (event, payload))
    except Exception:
        pass

def audit_admin(event: str, actor: str = "admin", ip: str = "", details: Any = None) -> None:
    try:
        payload = json.dumps(details or {}, ensure_ascii=False, default=str)
        with connect() as conn:
            conn.execute("INSERT INTO admin_audit_log(event, actor, ip, details) VALUES(?,?,?,?)", (event, actor, ip, payload))
    except Exception:
        pass


def _name_not_garbage(name: object) -> bool:
    n = normalize_text(name)
    if len(n) < 2:
        return False
    # Pure 1-2 digit fragments and obvious placeholders are not sellable by search.
    if n in {"unknown", "غير معروف", "غير مصنف", "none", "null", "na"}:
        return False
    return True


def _availability_flag(value: object) -> Optional[bool]:
    """Return True/False for explicit stock flags, or None when blank/unknown."""
    if value is None:
        return None
    raw = str(value).strip()
    if raw == "":
        return None
    n = normalize_text(raw)
    if n in {"1", "true", "yes", "y", "on", "متوفر", "موجود", "available", "ok", "نعم"}:
        return True
    if n in {"0", "false", "no", "n", "off", "غير متوفر", "غير موجود", "unavailable", "hidden", "لا"}:
        return False
    try:
        return float(raw) != 0
    except Exception:
        return None


def product_stock_available(product: Dict[str, Any]) -> bool:
    """Single source of truth for stock visibility.

    Older code used products.available while weekly uploads used
    products.is_available.  A product is customer-visible only when all explicit
    availability flags are positive.  Blank legacy flags are ignored so rows
    with is_available=1 are not hidden just because available is empty.
    """
    flags: List[bool] = []
    if "is_available" in product:
        flag = _availability_flag(product.get("is_available"))
        if flag is not None:
            flags.append(flag)
    if "available" in product:
        flag = _availability_flag(product.get("available"))
        if flag is not None:
            flags.append(flag)
    if any(flag is False for flag in flags):
        return False
    if flags:
        return True
    return True


def product_visible(product: Dict[str, Any], guided: bool = False) -> bool:
    """Return whether a product can be shown to customers.

    Exact search is allowed for sellable rows from the final Excel even if
    review_status is still needs_review. Guided browsing stays stricter: it
    requires usable category/subcategory so unclassified items do not pollute
    commercial menus.
    """
    if not product_stock_available(product):
        return False
    if not str(product.get("price") or "").strip():
        return False
    if not _name_not_garbage(product.get("name") or product.get("original_name")):
        return False

    quality = normalize_text(product.get("quality_status"))
    review = normalize_text(product.get("review_status"))
    search_mode = normalize_text(product.get("search_mode"))

    if review in {"unknown", "stale_hidden", "hidden"}:
        return False
    if quality in {"unknown", "bad", "invalid", "hidden"}:
        return False
    if search_mode in (GUIDED_HIDDEN_SEARCH_MODES if guided else HIDDEN_SEARCH_MODES):
        return False

    if guided:
        cat = normalize_text(product.get("category") or product.get("main_section") or product.get("section"))
        sub = normalize_text(product.get("subcategory") or product.get("sub_section") or product.get("section") or product.get("product_type"))
        if cat in {"", "unknown", "غير معروف", "غير مصنف"}:
            return False
        if sub in {"", "unknown", "unclassified", "غير معروف", "غير مصنف"}:
            return False
    return True


def count_products() -> int:
    with connect() as conn:
        if not table_exists(conn, "products"):
            return 0
        return int(conn.execute("SELECT COUNT(*) FROM products").fetchone()[0])


def count_table(table: str) -> int:
    with connect() as conn:
        if not table_exists(conn, table):
            return 0
        return int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])


def _load_all_product_rows_uncached() -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "products"):
            return []
        rows = [dict_row(r) for r in conn.execute("SELECT * FROM products ORDER BY name").fetchall()]
    return [r for r in rows if r]


def _get_all_product_rows_cached() -> List[Dict[str, Any]]:
    global _PRODUCT_ROWS_CACHE, _PRODUCT_BY_ID_CACHE, _PRODUCT_CACHE_LOADED_AT
    if not _runtime_cache_enabled():
        return _load_all_product_rows_uncached()
    if _PRODUCT_ROWS_CACHE is None or not _cache_fresh(_PRODUCT_CACHE_LOADED_AT):
        rows = _load_all_product_rows_uncached()
        _PRODUCT_ROWS_CACHE = rows
        _PRODUCT_BY_ID_CACHE = {}
        for p in rows:
            try:
                _PRODUCT_BY_ID_CACHE[int(p.get("id") or 0)] = dict(p)
            except Exception:
                pass
        _PRODUCT_CACHE_LOADED_AT = time.time()
    return _PRODUCT_ROWS_CACHE or []


def get_product(product_db_id: int) -> Optional[Dict[str, Any]]:
    try:
        pid = int(product_db_id)
    except Exception:
        return None
    if _runtime_cache_enabled() and _PRODUCT_BY_ID_CACHE and _cache_fresh(_PRODUCT_CACHE_LOADED_AT):
        cached = _PRODUCT_BY_ID_CACHE.get(pid)
        return dict(cached) if cached else None
    with connect() as conn:
        row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        product = dict_row(row)
        if product and _runtime_cache_enabled():
            _PRODUCT_BY_ID_CACHE[pid] = dict(product)
        return product


def load_product_rows(limit: Optional[int] = None, visible_only: bool = False, guided: bool = False) -> List[Dict[str, Any]]:
    # The hot path uses the full catalog.  Preserve exact legacy behavior for
    # explicit LIMIT calls, because older code expected LIMIT before filtering.
    if limit is not None:
        sql = "SELECT * FROM products ORDER BY name"
        sql += f" LIMIT {int(limit)}"
        with connect() as conn:
            rows = [dict_row(r) for r in conn.execute(sql).fetchall()]
        rows = [r for r in rows if r]
    else:
        rows = [dict(r) for r in _get_all_product_rows_cached()]
    if visible_only:
        rows = [r for r in rows if product_visible(r, guided=guided)]
    return rows


def load_product_alias_rows(merchant_id: Optional[int] = None, active_only: bool = True) -> List[Dict[str, Any]]:
    """Load product/merchant aliases as normalized rows for in-memory matching.

    This is a read-only adapter over legacy alias schemas.  It never creates or
    changes aliases; it only exposes approved rows to the matcher cache.
    """
    global _ALIAS_ROWS_CACHE, _ALIAS_CACHE_LOADED_AT
    if _runtime_cache_enabled() and _ALIAS_ROWS_CACHE is not None and _cache_fresh(_ALIAS_CACHE_LOADED_AT):
        rows = _ALIAS_ROWS_CACHE
    else:
        rows: List[Dict[str, Any]] = []
        with connect() as conn:
            if table_exists(conn, "product_aliases"):
                cols = set(table_columns(conn, "product_aliases"))
                pid_col = "product_id" if "product_id" in cols else ("product_db_id" if "product_db_id" in cols else "")
                alias_cols = [c for c in ["alias_text", "alias", "cleaned_alias", "normalized_alias", "alias_normalized"] if c in cols]
                active_terms = []
                for c in ["active", "is_active", "approved"]:
                    if c in cols:
                        active_terms.append(f"COALESCE({c},1)=1")
                where = "WHERE " + " AND ".join([pid_col + " IS NOT NULL"] + active_terms) if pid_col else ""
                if pid_col and alias_cols:
                    select_cols = ", ".join([pid_col + " AS product_id"] + alias_cols)
                    for row in conn.execute(f"SELECT {select_cols} FROM product_aliases {where}").fetchall():
                        d = dict_row(row) or {}
                        aliases = []
                        for c in alias_cols:
                            aliases.extend(split_multi(d.get(c)))
                        for alias in aliases:
                            a = str(alias or "").strip()
                            if a:
                                rows.append({"product_id": int(d.get("product_id") or 0), "alias": a, "source": "product_aliases"})
            if table_exists(conn, "merchant_product_aliases"):
                cols = set(table_columns(conn, "merchant_product_aliases"))
                if "product_id" in cols:
                    alias_cols = [c for c in ["raw_name", "normalized_raw_name"] if c in cols]
                    clauses = ["product_id IS NOT NULL"]
                    params: List[Any] = []
                    if active_only and "is_active" in cols:
                        clauses.append("COALESCE(is_active,1)=1")
                    if merchant_id is not None and "merchant_id" in cols:
                        clauses.append("merchant_id=?")
                        params.append(int(merchant_id))
                    if alias_cols:
                        select_cols = ", ".join(["product_id"] + alias_cols)
                        for row in conn.execute(f"SELECT {select_cols} FROM merchant_product_aliases WHERE {' AND '.join(clauses)}", tuple(params)).fetchall():
                            d = dict_row(row) or {}
                            aliases = []
                            for c in alias_cols:
                                aliases.extend(split_multi(d.get(c)))
                            for alias in aliases:
                                a = str(alias or "").strip()
                                if a:
                                    rows.append({"product_id": int(d.get("product_id") or 0), "alias": a, "source": "merchant_product_aliases"})
        if _runtime_cache_enabled():
            _ALIAS_ROWS_CACHE = rows
            _ALIAS_CACHE_LOADED_AT = time.time()
    if merchant_id is None:
        return [dict(r) for r in rows if r.get("product_id") and r.get("alias")]
    # product_aliases are global; merchant_product_aliases were already filtered
    # when loaded from DB.  Keep global aliases available to all merchants.
    return [dict(r) for r in rows if r.get("product_id") and r.get("alias")]


def find_by_exact_index(key: str, kinds: Sequence[str]) -> List[Dict[str, Any]]:
    if not key:
        return []
    placeholders = ",".join("?" for _ in kinds)
    with connect() as conn:
        rows = conn.execute(f"""
            SELECT p.*, i.kind, i.weight
            FROM product_search_index i
            JOIN products p ON p.id = i.product_db_id
            WHERE i.key=? AND i.kind IN ({placeholders})
            ORDER BY i.weight DESC, p.name
            LIMIT 30
        """, (key, *kinds)).fetchall()
        return [dict_row(r) for r in rows]


def search_candidates_by_tokens(query_tokens: Sequence[str], limit: int = 20) -> List[Dict[str, Any]]:
    """Safe legacy token lookup.

    Compatibility path only. It rejects weak single tokens and never performs
    a broad 10k substring scan across the whole catalog.
    """
    clean = [normalize_text(t) for t in query_tokens if normalize_text(t)]
    clean = [t for t in clean if t and (len(t) >= 4 or any(ch.isdigit() for ch in t))]
    if not clean:
        return []
    if len(clean) == 1 and clean[0] in {"pro", "scar", "tab", "cap", "syr", "supp", "d"}:
        return []
    with connect() as conn:
        rows = conn.execute("""
            SELECT * FROM products
            WHERE available IS NOT NULL
            ORDER BY name
            LIMIT 2000
        """).fetchall()
        out = []
        for row in rows:
            p = dict_row(row)
            if not product_visible(p, guided=False):
                continue
            hay = normalize_text(" ".join(str(p.get(c) or "") for c in ["name", "aliases", "brand", "product_family", "active_ingredient", "form", "strength", "size", "barcode"]))
            hay_words = set(hay.split())
            hay_compact = hay.replace(" ", "")
            if all(t in hay_words or (len(t) >= 5 and t in hay_compact) for t in clean):
                name_words = set(normalize_text(p.get("name")).split())
                score = sum(10 for t in clean if t in name_words) + sum(4 for t in clean if t in hay_words)
                p["_score"] = score
                out.append(p)
        out.sort(key=lambda x: (-int(x.get("_score") or 0), str(x.get("name") or "")))
        return out[:limit]



def replace_product_identity_registry(entries: List[Tuple]) -> int:
    """Replace identity registry atomically from the current products table.

    Does not touch the products table.  It only refreshes the derived identity
    layer used by exact-first matching.
    """
    with connect() as conn:
        conn.execute("DELETE FROM product_identity_registry")
        conn.executemany("""
            INSERT OR REPLACE INTO product_identity_registry(
                product_db_id, product_id, identity_key, canonical_name, normalized_name, compact_name,
                brand, product_family, form, strength, size, pack, barcode, aliases, ocr_keywords,
                category, search_policy, duplicate_group, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
        """, entries)
        return int(conn.execute("SELECT COUNT(*) FROM product_identity_registry").fetchone()[0])


def load_product_identity_registry() -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "product_identity_registry"):
            return []
        rows = conn.execute("SELECT * FROM product_identity_registry ORDER BY canonical_name").fetchall()
        return [dict_row(r) for r in rows if r]


def identity_registry_count() -> int:
    return count_table("product_identity_registry")


def get_products_by_ids(ids: Sequence[int]) -> List[Dict[str, Any]]:
    clean = []
    for value in ids:
        try:
            clean.append(int(value))
        except Exception:
            pass
    if not clean:
        return []
    placeholders = ",".join("?" for _ in clean)
    with connect() as conn:
        rows = conn.execute(f"SELECT * FROM products WHERE id IN ({placeholders})", tuple(clean)).fetchall()
        by_id = {int(r["id"]): dict_row(r) for r in rows}
        return [by_id[i] for i in clean if i in by_id]


def record_learning_event(customer_query: str = "", vision_text: str = "", candidate_products: Any = None, decision: str = "", reason: str = "", image_id: str = "", media_id: str = "", main_visible_product: str = "", background_text: str = "", query_slots: Any = None, rejected_candidates: Any = None) -> int:
    candidate_products = candidate_products or []
    rejected_candidates = rejected_candidates or []
    query_slots = query_slots or {}
    try:
        payload = json.dumps(candidate_products, ensure_ascii=False, default=str)
    except Exception:
        payload = "[]"
    try:
        slots_payload = json.dumps(query_slots, ensure_ascii=False, default=str)
    except Exception:
        slots_payload = "{}"
    try:
        rejected_payload = json.dumps(rejected_candidates, ensure_ascii=False, default=str)
    except Exception:
        rejected_payload = "[]"
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO learning_inbox(
                customer_query, vision_text, raw_vision_text, candidate_products, decision, reason, status,
                image_id, media_id, main_visible_product, background_text, query_slots, rejected_candidates
            ) VALUES(?,?,?,?,? ,?,'pending',?,?,?,?,?,?)
        """, (
            str(customer_query or "")[:1000], str(vision_text or "")[:2000], str(vision_text or "")[:2000],
            payload[:5000], str(decision or "")[:80], str(reason or "")[:500],
            str(image_id or "")[:200], str(media_id or "")[:200], str(main_visible_product or "")[:500],
            str(background_text or "")[:1000], slots_payload[:4000], rejected_payload[:4000],
        ))
        return int(cur.lastrowid)


def list_learning_inbox(status: str = "pending", limit: int = 100) -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "learning_inbox"):
            return []
        rows = conn.execute("SELECT * FROM learning_inbox WHERE status=? ORDER BY id DESC LIMIT ?", (status, int(limit))).fetchall()
        return [dict_row(r) for r in rows if r]


def append_product_alias_or_ocr(product_db_id: int, value: str, field: str = "aliases") -> None:
    field = "ocr_keywords" if field == "ocr_keywords" else "aliases"
    value = str(value or "").strip()
    if not value:
        return
    with connect() as conn:
        row = conn.execute(f"SELECT {field} FROM products WHERE id=?", (int(product_db_id),)).fetchone()
        if not row:
            raise ValueError("product_not_found")
        existing = str(row[0] or "")
        parts = [x.strip() for x in existing.replace(";", "|").replace(",", "|").split("|") if x.strip()]
        if value not in parts:
            parts.append(value)
        conn.execute(f"UPDATE products SET {field}=?, updated_at=datetime('now') WHERE id=?", (" | ".join(parts), int(product_db_id)))


def approve_learning_alias(learning_id: int, product_db_id: int, field: str = "aliases") -> None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM learning_inbox WHERE id=?", (int(learning_id),)).fetchone()
        if not row:
            raise ValueError("learning_event_not_found")
        d = dict_row(row)
    learned = (d.get("customer_query") or d.get("vision_text") or "").strip()
    append_product_alias_or_ocr(int(product_db_id), learned, field=field)
    with connect() as conn:
        conn.execute("""
            UPDATE learning_inbox
            SET admin_action=?, selected_product_id=?, status='approved', updated_at=datetime('now')
            WHERE id=?
        """, (f"add_{field}", int(product_db_id), int(learning_id)))




def update_learning_status(learning_id: int, status: str, action: str = "") -> None:
    with connect() as conn:
        conn.execute("UPDATE learning_inbox SET status=?, admin_action=?, updated_at=datetime('now') WHERE id=?", (status, action or status, int(learning_id)))

def create_catalog_import_job(filename: str, staging_db_path: str, status: str = "uploaded", report_text: str = "") -> int:
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO catalog_import_jobs(filename, staging_db_path, status, report_text, created_at, updated_at)
            VALUES(?,?,?,?,datetime('now'),datetime('now'))
        """, (filename, staging_db_path, status, report_text))
        return int(cur.lastrowid)

def update_catalog_import_job(job_id: int, **fields: Any) -> None:
    allowed = {"status", "added", "updated", "duplicate_conflicts", "needs_review", "unclassified", "missing_form_strength_size", "report_text", "staging_db_path", "job_type", "started_at", "finished_at", "error_text", "merchant_id", "requires_approval", "verified", "acceptance_passed", "approval_user", "approved_at"}
    clean = {k: v for k, v in fields.items() if k in allowed}
    if not clean:
        return
    assignments = ", ".join(f"{k}=?" for k in clean) + ", updated_at=datetime('now')"
    with connect() as conn:
        conn.execute(f"UPDATE catalog_import_jobs SET {assignments} WHERE id=?", (*clean.values(), int(job_id)))

def list_catalog_import_jobs(limit: int = 30) -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "catalog_import_jobs"):
            return []
        rows = conn.execute("SELECT * FROM catalog_import_jobs ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict_row(r) for r in rows if r]

def get_catalog_import_job(job_id: int) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "catalog_import_jobs"):
            return None
        return dict_row(conn.execute("SELECT * FROM catalog_import_jobs WHERE id=?", (int(job_id),)).fetchone())

def cleanup_old_runtime_rows(days: int = 30) -> Dict[str, int]:
    stats: Dict[str, int] = {}
    with connect() as conn:
        if table_exists(conn, "processed_messages"):
            cur = conn.execute("DELETE FROM processed_messages WHERE created_at < datetime('now', ?)", (f"-{int(days)} days",))
            stats["processed_messages_deleted"] = int(cur.rowcount or 0)
        if table_exists(conn, "conversation_state"):
            cur = conn.execute("DELETE FROM conversation_state WHERE expires_at IS NOT NULL AND expires_at < datetime('now')")
            stats["conversation_state_deleted"] = int(cur.rowcount or 0)
        for table in ["image_product_cache", "image_cache"]:
            if table_exists(conn, table):
                cur = conn.execute(f"DELETE FROM {table} WHERE updated_at < datetime('now', ?)", (f"-{int(days)} days",))
                stats[f"{table}_deleted"] = int(cur.rowcount or 0)
        if table_exists(conn, "learning_inbox"):
            cur = conn.execute("DELETE FROM learning_inbox WHERE status IN ('approved','ignored','not_in_catalog') AND updated_at < datetime('now', '-90 days')")
            stats["learning_inbox_archived_deleted"] = int(cur.rowcount or 0)
    return stats

def find_identity_registry(kind: str, key: str, limit: int = 80) -> List[Dict[str, Any]]:
    key = normalize_text(key)
    if not key or not table_exists_safe("product_identity_registry"):
        return []
    compact = key.replace(" ", "")
    with connect() as conn:
        if kind == "barcode":
            rows = conn.execute("SELECT * FROM product_identity_registry WHERE barcode=? LIMIT ?", (key, int(limit))).fetchall()
        elif kind == "normalized_name":
            rows = conn.execute("SELECT * FROM product_identity_registry WHERE normalized_name=? LIMIT ?", (key, int(limit))).fetchall()
        elif kind == "compact_name":
            rows = conn.execute("SELECT * FROM product_identity_registry WHERE compact_name=? LIMIT ?", (compact or key, int(limit))).fetchall()
        elif kind == "brand_family":
            toks = [t for t in key.split() if t]
            if len(toks) >= 2:
                brand, fam = toks[0], " ".join(toks[1:])
                rows = conn.execute("""
                    SELECT * FROM product_identity_registry
                    WHERE brand=? AND (product_family=? OR product_family LIKE ? OR normalized_name LIKE ? OR aliases LIKE ?)
                    LIMIT ?
                """, (brand, fam, f"%{fam}%", f"%{brand}%{fam}%", f"%{brand}%{fam}%", int(limit))).fetchall()
            else:
                rows = []
        else:
            # aliases and ocr_keywords are normalized pipe-separated blobs.  LIKE
            # is used only inside the exact-first identity registry, then product
            # slots still pass form/strength/size verification in search_engine.
            col = "ocr_keywords" if kind == "ocr_keyword" else "aliases"
            rows = conn.execute(f"""
                SELECT * FROM product_identity_registry
                WHERE {col}=? OR {col} LIKE ? OR {col} LIKE ? OR {col} LIKE ?
                LIMIT ?
            """, (key, f"%| {key}%", f"%{key} |%", f"%{key}%", int(limit))).fetchall()
        return [dict_row(r) for r in rows if r]


def table_exists_safe(table: str) -> bool:
    try:
        with connect() as conn:
            return table_exists(conn, table)
    except Exception:
        return False


def replace_search_index(entries: List[Tuple[str, str, int, int]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM product_search_index")
        conn.executemany("INSERT OR IGNORE INTO product_search_index(key, kind, product_db_id, weight) VALUES(?,?,?,?)", entries)
        return int(conn.execute("SELECT COUNT(*) FROM product_search_index").fetchone()[0])


def replace_guided_index(entries: List[Tuple[int, str, str, str, str, str, str, str, int, str]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM guided_catalog_index")
        conn.executemany("""
            INSERT OR IGNORE INTO guided_catalog_index(
                product_db_id, main_section, sub_section, product_type, use_case, skin_type, body_area, age_group, visible, sort_name
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
        """, entries)
        return int(conn.execute("SELECT COUNT(*) FROM guided_catalog_index").fetchone()[0])


def guided_products(main_section: str, sub_section: str = "", skin_type: str = "", page: int = 0, page_size: int = 10) -> List[Dict[str, Any]]:
    params: List[Any] = [main_section]
    filters = "g.visible=1 AND g.main_section=?"
    if sub_section:
        filters += " AND g.sub_section=?"
        params.append(sub_section)
    if skin_type:
        filters += " AND (g.skin_type=? OR g.skin_type='' OR g.skin_type='unknown')"
        params.append(skin_type)
    params.extend([int(page_size), int(page) * int(page_size)])
    with connect() as conn:
        rows = conn.execute(f"""
            SELECT p.*, g.main_section, g.sub_section, g.skin_type AS guided_skin_type
            FROM guided_catalog_index g
            JOIN products p ON p.id = g.product_db_id
            WHERE {filters}
            ORDER BY g.sort_name
            LIMIT ? OFFSET ?
        """, params).fetchall()
        out = []
        for row in rows:
            p = dict_row(row)
            if p and product_visible(p, guided=True):
                out.append(p)
        return out


def guided_count(main_section: str, sub_section: str = "") -> int:
    params: List[Any] = [main_section]
    filters = "visible=1 AND main_section=?"
    if sub_section:
        filters += " AND sub_section=?"
        params.append(sub_section)
    with connect() as conn:
        return int(conn.execute(f"SELECT COUNT(*) FROM guided_catalog_index WHERE {filters}", params).fetchone()[0])


def _state_ttl_seconds() -> int:
    try:
        return int(os.getenv("PRICEBOT_STATE_TTL_SECONDS", "21600") or 21600)
    except Exception:
        return 21600


def cleanup_expired_states() -> int:
    with connect() as conn:
        if not table_exists(conn, "conversation_state"):
            return 0
        cols = set(table_columns(conn, "conversation_state"))
        if "expires_at" not in cols:
            return 0
        cur = conn.execute("DELETE FROM conversation_state WHERE expires_at IS NOT NULL AND expires_at!='' AND expires_at < datetime('now')")
        return int(cur.rowcount or 0)


def get_state(phone: str) -> Dict[str, Any]:
    with connect() as conn:
        if not table_exists(conn, "conversation_state"):
            return {}
        cols = set(table_columns(conn, "conversation_state"))
        if "expires_at" in cols:
            row = conn.execute("SELECT state_json, expires_at FROM conversation_state WHERE phone=?", (phone,)).fetchone()
            if not row:
                return {}
            expires_at = str(row[1] or "")
            if expires_at:
                expired = conn.execute("SELECT CASE WHEN ? < datetime('now') THEN 1 ELSE 0 END", (expires_at,)).fetchone()[0]
                if int(expired or 0):
                    conn.execute("DELETE FROM conversation_state WHERE phone=?", (phone,))
                    return {}
            payload = row[0]
        else:
            row = conn.execute("SELECT state_json FROM conversation_state WHERE phone=?", (phone,)).fetchone()
            if not row:
                return {}
            payload = row[0]
        try:
            state = json.loads(payload or "{}")
            return state if isinstance(state, dict) else {}
        except Exception:
            return {}


def set_state(phone: str, state: Dict[str, Any]) -> None:
    payload = json.dumps(state or {}, ensure_ascii=False)
    ttl = _state_ttl_seconds()
    with connect() as conn:
        cols = set(table_columns(conn, "conversation_state"))
        if "expires_at" in cols and "created_at" in cols:
            conn.execute("""
                INSERT INTO conversation_state(phone, state_json, created_at, updated_at, expires_at)
                VALUES(?, ?, datetime('now'), datetime('now'), datetime('now', ? || ' seconds'))
                ON CONFLICT(phone) DO UPDATE SET
                    state_json=excluded.state_json,
                    updated_at=datetime('now'),
                    expires_at=datetime('now', ? || ' seconds')
            """, (phone, payload, str(ttl), str(ttl)))
        else:
            conn.execute("""
                INSERT INTO conversation_state(phone, state_json, updated_at) VALUES(?,?,datetime('now'))
                ON CONFLICT(phone) DO UPDATE SET state_json=excluded.state_json, updated_at=datetime('now')
            """, (phone, payload))


def clear_state(phone: str) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM conversation_state WHERE phone=?", (phone,))


def mark_processed(message_id: str) -> bool:
    if not message_id:
        return True
    try:
        with connect() as conn:
            conn.execute("INSERT INTO processed_messages(message_id) VALUES(?)", (message_id,))
        return True
    except sqlite3.IntegrityError:
        return False


def default_merchant_id() -> int:
    try:
        return int(os.getenv("PRICEBOT_DEFAULT_MERCHANT_ID", "1") or 1)
    except Exception:
        return 1


def create_order(phone: str, product: Dict[str, Any], quantity: int = 1, merchant_id: Optional[int] = None) -> int:
    quantity = max(1, int(quantity or 1))
    mid = int(merchant_id or product.get("merchant_id") or default_merchant_id())
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO orders(merchant_id, phone, product_db_id, product_name, quantity, price, status)
            VALUES(?,?,?,?,?,?,'pending')
        """, (mid, phone, product.get("id"), product.get("name") or "", quantity, safe_price(product.get("price"))))
        return int(cur.lastrowid)


def list_orders(status: str = "pending", limit: int = 100, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders WHERE merchant_id=? AND status=? ORDER BY id DESC LIMIT ?", (mid, status, int(limit))).fetchall()
        return [dict_row(r) for r in rows]


def recent_orders_for_phone(phone: str, limit: int = 5, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        rows = conn.execute("SELECT * FROM orders WHERE merchant_id=? AND phone=? ORDER BY id DESC LIMIT ?", (mid, phone, int(limit))).fetchall()
        return [dict_row(r) for r in rows]


def update_order_status(order_id: int, status: str, merchant_id: Optional[int] = None) -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        conn.execute("UPDATE orders SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND merchant_id=?", (status, int(order_id), mid))




def record_search_log(product_id: int, product_name: str = "", user_id: str = "", merchant_id: Optional[int] = None, source: str = "whatsapp_confirmation") -> None:
    """Record a successful user-confirmed product lookup for merchant analytics."""
    try:
        pid = int(product_id or 0)
    except Exception:
        pid = 0
    if not pid:
        return
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "search_logs"):
            return
        conn.execute(
            """
            INSERT INTO search_logs(merchant_id, product_id, product_name, user_id, source, timestamp)
            VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
            """,
            (mid, pid, str(product_name or "")[:500], str(user_id or "")[:100], str(source or "whatsapp_confirmation")[:100]),
        )


def top_searched_products(days: int = 7, limit: int = 10, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """Return top confirmed products from search_logs for dashboard statistics."""
    mid = int(merchant_id or default_merchant_id())
    days = max(1, int(days or 7))
    limit = max(1, min(50, int(limit or 10)))
    with connect() as conn:
        if not table_exists(conn, "search_logs"):
            return []
        rows = conn.execute(
            """
            SELECT s.product_id AS product_id, COALESCE(NULLIF(s.product_name,''), p.name, '') AS product_name, COUNT(*) AS hits
            FROM search_logs s
            LEFT JOIN products p ON p.id=s.product_id
            WHERE s.merchant_id=? AND s.timestamp >= datetime('now', ?)
            GROUP BY s.product_id, COALESCE(NULLIF(s.product_name,''), p.name, '')
            ORDER BY hits DESC, product_name
            LIMIT ?
            """,
            (mid, f"-{days} days", limit),
        ).fetchall()
        return [dict_row(r) for r in rows]


def record_product_upload(filename: str, products_count: int, backup_path: str = "", status: str = "success", message: str = "", merchant_id: Optional[int] = None) -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "product_upload_history"):
            return
        conn.execute(
            """
            INSERT INTO product_upload_history(merchant_id, filename, products_count, backup_path, status, message, created_at)
            VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
            """,
            (mid, str(filename or "")[:300], int(products_count or 0), str(backup_path or "")[:1000], str(status or "")[:50], str(message or "")[:1000]),
        )


def list_product_upload_history(limit: int = 5, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        limit_i = int(limit or 5)
        if table_exists(conn, "upload_history"):
            rows = conn.execute(
                """
                SELECT id, filename, total_rows AS products_count, status, message, upload_time AS created_at,
                       new_products, updated_products, deactivated_products, review_products
                FROM upload_history
                WHERE merchant_id=?
                ORDER BY id DESC
                LIMIT ?
                """,
                (mid, limit_i),
            ).fetchall()
            return [dict_row(r) for r in rows]
        if not table_exists(conn, "product_upload_history"):
            return []
        rows = conn.execute(
            "SELECT * FROM product_upload_history WHERE merchant_id=? ORDER BY id DESC LIMIT ?",
            (mid, limit_i),
        ).fetchall()
        return [dict_row(r) for r in rows]


def record_weekly_upload_history(
    *,
    filename: str,
    total_rows: int,
    new_products: int,
    updated_products: int,
    deactivated_products: int,
    review_products: int,
    status: str = "success",
    message: str = "",
    merchant_id: Optional[int] = None,
) -> None:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if table_exists(conn, "upload_history"):
            conn.execute(
                """
                INSERT INTO upload_history(merchant_id, filename, total_rows, new_products, updated_products, deactivated_products, review_products, status, message, upload_time)
                VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                """,
                (mid, str(filename or "")[:300], int(total_rows or 0), int(new_products or 0), int(updated_products or 0), int(deactivated_products or 0), int(review_products or 0), str(status or "")[:50], str(message or "")[:1000]),
            )
        # Keep the previous dashboard table populated for backwards compatibility.
        if table_exists(conn, "product_upload_history"):
            conn.execute(
                """
                INSERT INTO product_upload_history(merchant_id, filename, products_count, backup_path, status, message, created_at)
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                """,
                (mid, str(filename or "")[:300], int(total_rows or 0), "", str(status or "")[:50], str(message or "")[:1000]),
            )



def ensure_import_jobs_schema(conn: Any) -> None:
    """Create/upgrade import_jobs without destructive migrations.

    The weekly Excel importer is a real background job.  These columns provide
    progress polling, a clear merchant summary, and report downloads while
    keeping compatibility with older dashboard fields (inserted/updated/etc.).
    """
    conn.execute("""
        CREATE TABLE IF NOT EXISTS import_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            merchant_id INTEGER DEFAULT 1,
            job_type TEXT DEFAULT 'weekly_upload',
            filename TEXT DEFAULT '',
            file_path TEXT DEFAULT '',
            status TEXT DEFAULT 'PENDING',
            progress INTEGER DEFAULT 0,
            progress_percent INTEGER DEFAULT 0,
            total_rows INTEGER DEFAULT 0,
            processed_rows INTEGER DEFAULT 0,
            updated_existing_count INTEGER DEFAULT 0,
            inserted_new_count INTEGER DEFAULT 0,
            duplicate_merged_count INTEGER DEFAULT 0,
            review_required_count INTEGER DEFAULT 0,
            invalid_rows_count INTEGER DEFAULT 0,
            skipped_rows_count INTEGER DEFAULT 0,
            inserted INTEGER DEFAULT 0,
            updated INTEGER DEFAULT 0,
            skipped INTEGER DEFAULT 0,
            unmatched INTEGER DEFAULT 0,
            ambiguous INTEGER DEFAULT 0,
            summary TEXT DEFAULT '',
            error TEXT DEFAULT '',
            error_message TEXT DEFAULT '',
            result_summary_json TEXT DEFAULT '',
            report_path TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            started_at TEXT,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            finished_at TEXT
        )
    """)
    existing = set(table_columns(conn, "import_jobs"))
    for col, ddl in {
        "merchant_id": "INTEGER DEFAULT 1",
        "job_type": "TEXT DEFAULT 'weekly_upload'",
        "filename": "TEXT DEFAULT ''",
        "file_path": "TEXT DEFAULT ''",
        "status": "TEXT DEFAULT 'PENDING'",
        "progress": "INTEGER DEFAULT 0",
        "progress_percent": "INTEGER DEFAULT 0",
        "total_rows": "INTEGER DEFAULT 0",
        "processed_rows": "INTEGER DEFAULT 0",
        "updated_existing_count": "INTEGER DEFAULT 0",
        "inserted_new_count": "INTEGER DEFAULT 0",
        "duplicate_merged_count": "INTEGER DEFAULT 0",
        "review_required_count": "INTEGER DEFAULT 0",
        "invalid_rows_count": "INTEGER DEFAULT 0",
        "skipped_rows_count": "INTEGER DEFAULT 0",
        "inserted": "INTEGER DEFAULT 0",
        "updated": "INTEGER DEFAULT 0",
        "skipped": "INTEGER DEFAULT 0",
        "unmatched": "INTEGER DEFAULT 0",
        "ambiguous": "INTEGER DEFAULT 0",
        "summary": "TEXT DEFAULT ''",
        "error": "TEXT DEFAULT ''",
        "error_message": "TEXT DEFAULT ''",
        "result_summary_json": "TEXT DEFAULT ''",
        "report_path": "TEXT DEFAULT ''",
        "created_at": "TEXT",
        "started_at": "TEXT",
        "updated_at": "TEXT",
        "finished_at": "TEXT",
    }.items():
        if col not in existing:
            add_column(conn, "import_jobs", col, ddl)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_import_jobs_status ON import_jobs(merchant_id, status, created_at)")

def create_import_job(filename: str, file_path: str, job_type: str = "weekly_upload", merchant_id: Optional[int] = None) -> int:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        ensure_import_jobs_schema(conn)
        cur = conn.execute(
            """
            INSERT INTO import_jobs(merchant_id, job_type, filename, file_path, status, progress, created_at, updated_at)
            VALUES(?,?,?,?, 'PENDING', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """,
            (mid, str(job_type or "weekly_upload")[:80], str(filename or "")[:300], str(file_path or "")[:1000]),
        )
        return int(cur.lastrowid)


def update_import_job(job_id: int, **fields: Any) -> None:
    allowed = {
        "status", "progress", "progress_percent", "total_rows", "processed_rows",
        "updated_existing_count", "inserted_new_count", "duplicate_merged_count",
        "review_required_count", "invalid_rows_count", "skipped_rows_count",
        "inserted", "updated", "skipped", "unmatched", "ambiguous", "summary",
        "error", "error_message", "file_path", "filename", "result_summary_json",
        "report_path", "started_at",
    }
    clean = {k: v for k, v in fields.items() if k in allowed}
    if "progress" in clean and "progress_percent" not in clean:
        clean["progress_percent"] = clean["progress"]
    if "progress_percent" in clean and "progress" not in clean:
        clean["progress"] = clean["progress_percent"]
    if "updated_existing_count" in clean and "updated" not in clean:
        clean["updated"] = clean["updated_existing_count"]
    if "inserted_new_count" in clean and "inserted" not in clean:
        clean["inserted"] = clean["inserted_new_count"]
    if "review_required_count" in clean and "unmatched" not in clean:
        clean["unmatched"] = clean["review_required_count"]
    if "skipped_rows_count" in clean and "skipped" not in clean:
        clean["skipped"] = clean["skipped_rows_count"]
    if "error_message" in clean and "error" not in clean:
        clean["error"] = clean["error_message"]
    if "error" in clean and "error_message" not in clean:
        clean["error_message"] = clean["error"]
    if not clean:
        return
    assignments = []
    params: List[Any] = []
    for k, v in clean.items():
        if v == "__NOW__":
            assignments.append(f"{k}=CURRENT_TIMESTAMP")
        else:
            assignments.append(f"{k}=?")
            params.append(v)
    assignments.append("updated_at=CURRENT_TIMESTAMP")
    status = str(clean.get("status") or "").upper()
    if status == "PROCESSING":
        assignments.append("started_at=COALESCE(started_at, CURRENT_TIMESTAMP)")
    if status in {"DONE", "FAILED"}:
        assignments.append("finished_at=CURRENT_TIMESTAMP")
    with connect() as conn:
        ensure_import_jobs_schema(conn)
        conn.execute(f"UPDATE import_jobs SET {', '.join(assignments)} WHERE id=?", params + [int(job_id)])

def get_import_job(job_id: int, merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        ensure_import_jobs_schema(conn)
        row = conn.execute("SELECT * FROM import_jobs WHERE id=? AND merchant_id=?", (int(job_id), mid)).fetchone()
        return dict_row(row) or {}


def list_import_jobs(limit: int = 10, merchant_id: Optional[int] = None) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        ensure_import_jobs_schema(conn)
        rows = conn.execute("SELECT * FROM import_jobs WHERE merchant_id=? ORDER BY id DESC LIMIT ?", (mid, int(limit or 10))).fetchall()
        return [dict_row(r) for r in rows]

def list_review_queue(limit: int = 50, merchant_id: Optional[int] = None, include_resolved: bool = False) -> List[Dict[str, Any]]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "review_queue"):
            return []
        where = "rq.merchant_id=?" if include_resolved else "rq.merchant_id=? AND COALESCE(rq.resolved,0)=0"
        rows = conn.execute(
            f"""
            SELECT rq.*, p.name AS similar_existing_name, tp.name AS temp_product_name
            FROM review_queue rq
            LEFT JOIN products p ON p.id=rq.similar_existing_id
            LEFT JOIN products tp ON tp.id=rq.temp_product_id
            WHERE {where}
            ORDER BY rq.id DESC
            LIMIT ?
            """,
            (mid, int(limit or 50)),
        ).fetchall()
        return [dict_row(r) for r in rows]


def count_review_queue(merchant_id: Optional[int] = None) -> int:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "review_queue"):
            return 0
        return int(conn.execute("SELECT COUNT(*) FROM review_queue WHERE merchant_id=? AND COALESCE(resolved,0)=0", (mid,)).fetchone()[0])


def resolve_review_queue_item(item_id: int, action: str, existing_product_id: Optional[int] = None, merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    action = str(action or "").strip().lower()
    with connect() as conn:
        row = conn.execute("SELECT * FROM review_queue WHERE id=? AND merchant_id=?", (int(item_id), mid)).fetchone()
        item = dict_row(row)
        if not item:
            raise ValueError("review item not found")
        temp_id = int(item.get("temp_product_id") or 0)
        if action == "approve_new":
            if not temp_id:
                raise ValueError("review item has no temporary product")
            conn.execute(
                """
                UPDATE products SET needs_review=0, is_available=1, available='1', review_status='approved', search_mode='sellable', quality_status='ok', updated_at=datetime('now')
                WHERE id=? AND merchant_id=?
                """,
                (temp_id, mid),
            )
        elif action == "delete":
            if temp_id:
                conn.execute(
                    "UPDATE products SET is_available=0, available='0', needs_review=1, search_mode='hidden', review_status='hidden', updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (temp_id, mid),
                )
        elif action == "link_existing":
            target_id = int(existing_product_id or item.get("similar_existing_id") or 0)
            if not target_id:
                raise ValueError("existing product id is required")
            uploaded_price = str(item.get("uploaded_price") or "").strip()
            if uploaded_price:
                conn.execute(
                    "UPDATE products SET price=?, is_available=1, available='1', needs_review=0, review_status='approved', search_mode='sellable', last_seen_in_upload=datetime('now'), updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (safe_price(uploaded_price), target_id, mid),
                )
            else:
                conn.execute(
                    "UPDATE products SET is_available=1, available='1', needs_review=0, review_status='approved', search_mode='sellable', last_seen_in_upload=datetime('now'), updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (target_id, mid),
                )
            if temp_id:
                conn.execute(
                    "UPDATE products SET is_available=0, available='0', needs_review=1, search_mode='hidden', review_status='hidden', updated_at=datetime('now') WHERE id=? AND merchant_id=?",
                    (temp_id, mid),
                )
        else:
            raise ValueError("unsupported review action")
        conn.execute("UPDATE review_queue SET resolved=1, resolved_at=CURRENT_TIMESTAMP WHERE id=? AND merchant_id=?", (int(item_id), mid))
        return item


def get_merchant(merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        row = conn.execute("SELECT * FROM merchants WHERE id=?", (mid,)).fetchone()
        return dict_row(row) or {"id": mid, "name": os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية"), "whatsapp_number": os.getenv("BOT_WHATSAPP_NUMBER", "")}


def get_merchant_settings(merchant_id: Optional[int] = None) -> Dict[str, Any]:
    mid = int(merchant_id or default_merchant_id())
    with connect() as conn:
        if not table_exists(conn, "merchant_settings"):
            return get_merchant(mid)
        row = conn.execute("SELECT * FROM merchant_settings WHERE merchant_id=?", (mid,)).fetchone()
        data = dict_row(row) or {}
        merchant = get_merchant(mid)
        return {**merchant, **data, "merchant_id": mid}


def update_merchant_settings(merchant_id: int, pharmacy_name: str = "", whatsapp_number: str = "", qr_message: str = "", working_hours: str = "24 ساعة", delivery_enabled: object = 0, currency: str = "LYD", welcome_text: str = "") -> None:
    mid = int(merchant_id or default_merchant_id())
    delivery = 1 if truthy(delivery_enabled) else 0
    with connect() as conn:
        # Additive migration for older DBs. No data deletion.
        for col, ddl in {
            "working_hours": "TEXT DEFAULT '24 ساعة'",
            "delivery_enabled": "INTEGER DEFAULT 0",
            "currency": "TEXT DEFAULT 'LYD'",
            "welcome_text": "TEXT DEFAULT ''",
        }.items():
            add_column(conn, "merchant_settings", col, ddl)
        conn.execute("""
            INSERT INTO merchant_settings(merchant_id, pharmacy_name, whatsapp_number, qr_message, working_hours, delivery_enabled, currency, welcome_text, updated_at)
            VALUES(?,?,?,?,?,?,?,?,datetime('now'))
            ON CONFLICT(merchant_id) DO UPDATE SET
                pharmacy_name=excluded.pharmacy_name, whatsapp_number=excluded.whatsapp_number,
                qr_message=excluded.qr_message, working_hours=excluded.working_hours,
                delivery_enabled=excluded.delivery_enabled, currency=excluded.currency,
                welcome_text=excluded.welcome_text, updated_at=datetime('now')
        """, (mid, str(pharmacy_name or ""), str(whatsapp_number or ""), str(qr_message or ""), str(working_hours or "24 ساعة"), delivery, str(currency or "LYD"), str(welcome_text or "")))
        conn.execute("UPDATE merchants SET name=COALESCE(NULLIF(?,''), name), whatsapp_number=COALESCE(NULLIF(?,''), whatsapp_number), updated_at=datetime('now') WHERE id=?", (str(pharmacy_name or ""), str(whatsapp_number or ""), mid))


def create_catalog_review_item(job_id: int, row: Dict[str, Any], issue_type: str, duplicate_key: str = "", price_old: str = "", price_new: str = "", merchant_id: Optional[int] = None, severity: str = "review") -> int:
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO catalog_review_items(job_id, merchant_id, issue_type, severity, row_json, duplicate_key, price_old, price_new, status)
            VALUES(?,?,?,?,?,?,?,?, 'pending')
        """, (int(job_id or 0), int(merchant_id or default_merchant_id()), issue_type, severity, json.dumps(row or {}, ensure_ascii=False, default=str), duplicate_key, str(price_old or ""), str(price_new or "")))
        return int(cur.lastrowid)


def list_catalog_review_items(job_id: Optional[int] = None, status: str = "pending", limit: int = 200) -> List[Dict[str, Any]]:
    with connect() as conn:
        if not table_exists(conn, "catalog_review_items"):
            return []
        if job_id:
            rows = conn.execute("SELECT * FROM catalog_review_items WHERE job_id=? AND status=? ORDER BY id DESC LIMIT ?", (int(job_id), status, int(limit))).fetchall()
        else:
            rows = conn.execute("SELECT * FROM catalog_review_items WHERE status=? ORDER BY id DESC LIMIT ?", (status, int(limit))).fetchall()
        return [dict_row(r) for r in rows if r]


def get_image_cache(image_hash: str = "", media_id: str = "") -> Optional[Dict[str, Any]]:
    if not image_hash and not media_id:
        return None
    with connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if not table_exists(conn, table):
                continue
            if image_hash:
                row = conn.execute(f"SELECT * FROM {table} WHERE image_hash=?", (image_hash,)).fetchone()
            else:
                row = conn.execute(f"SELECT * FROM {table} WHERE media_id=? ORDER BY updated_at DESC LIMIT 1", (media_id,)).fetchone()
            found = dict_row(row)
            if found:
                return found
        return None


def clear_image_cache() -> int:
    """Clear stored image-to-product decisions after Learning Inbox approvals."""
    deleted = 0
    with connect() as conn:
        for table in ["image_cache", "image_product_cache"]:
            if not table_exists(conn, table):
                continue
            try:
                cur = conn.execute(f"DELETE FROM {table}")
                deleted += int(cur.rowcount or 0)
            except Exception:
                continue
    return deleted


def set_image_cache(image_hash: str, media_id: str, extracted_slots: Dict[str, Any], matched_product_id: Optional[int], decision: str, confidence: str = "") -> None:
    if not image_hash:
        return
    payload = json.dumps(extracted_slots or {}, ensure_ascii=False)
    with connect() as conn:
        for table in ["image_product_cache", "image_cache"]:
            if not table_exists(conn, table):
                continue
            conn.execute(
                f"""
                INSERT INTO {table}(image_hash, media_id, extracted_slots, matched_product_id, decision, confidence, created_at, updated_at)
                VALUES(?,?,?,?,?,?,datetime('now'),datetime('now'))
                ON CONFLICT(image_hash) DO UPDATE SET
                    media_id=excluded.media_id,
                    extracted_slots=excluded.extracted_slots,
                    matched_product_id=excluded.matched_product_id,
                    decision=excluded.decision,
                    confidence=excluded.confidence,
                    updated_at=datetime('now')
                """,
                (image_hash, media_id or "", payload, matched_product_id, decision or "", confidence or ""),
            )


# ---------------- Gemini Safe Economy Mode ----------------
# Conservative exact-memory helpers.  This layer reduces repeated Gemini calls
# without allowing fuzzy self-learning to display prices directly.
SAFE_ECONOMY_IMAGE_DECISIONS = {"EXACT_IMAGE_CONFIRMED", "VISUAL_MEMORY_APPROVED"}
_SAFE_MEMORY_GENERIC_WORDS = {
    "cream", "gel", "lotion", "cleanser", "wash", "face", "facial", "serum", "toner",
    "sunscreen", "spf", "moisturizer", "shampoo", "conditioner", "soap", "mask", "balm",
    "tablet", "tablets", "capsule", "capsules", "syrup", "solution", "suspension", "oral",
    "mg", "ml", "g", "gm", "pack", "box", "bottle", "new", "original", "plus",
    "كريم", "جل", "غسول", "شراب", "حبوب", "اقراص", "أقراص", "كبسولات", "قطرة", "بخاخ",
    "علبة", "صورة", "المنتج", "دواء",
}


def ensure_safe_economy_schema(conn: Any) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS safe_text_memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            normalized_query TEXT UNIQUE,
            raw_query TEXT DEFAULT '',
            product_id INTEGER NOT NULL,
            source TEXT DEFAULT 'gemini_safe_economy',
            confirmed_count INTEGER DEFAULT 1,
            rejected_count INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            last_user_key TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_safe_text_memory_query_active ON safe_text_memory(normalized_query, active)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_safe_text_memory_product_active ON safe_text_memory(product_id, active)")


def _safe_memory_tokens(text: object) -> List[str]:
    norm = clean_alias_text(text)
    return re.findall(r"[\w%/+-]+", norm, flags=re.UNICODE)


def _safe_memory_strong_tokens(text: object) -> List[str]:
    out: List[str] = []
    seen = set()
    for token in _safe_memory_tokens(text):
        t = str(token or "").strip().lower()
        if len(t) < 2:
            continue
        if t in _SAFE_MEMORY_GENERIC_WORDS:
            continue
        if re.fullmatch(r"\d+", t):
            continue
        if t not in seen:
            out.append(t)
            seen.add(t)
    return out


def _safe_memory_measures(text: object) -> List[str]:
    norm = clean_alias_text(text)
    return re.findall(r"\b\d+\s*(?:mg|mcg|g|gm|ml|iu|%)\b|\b\d{2,}\b", norm, flags=re.IGNORECASE)


def safe_memory_alias_allowed(raw_query: object, product: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Strictly decide whether an exact text can be remembered.

    The memory is used only to pre-fill a confirmation candidate, not to show
    price directly.  Still, generic one-word inputs such as "panadol" are rejected.
    """
    clean = clean_alias_text(raw_query)
    if not clean or len(clean) < 4:
        return {"allowed": False, "reason": "too_short", "normalized_query": clean}
    if not product or not int(product.get("id") or 0):
        return {"allowed": False, "reason": "missing_product", "normalized_query": clean}
    qstrong = _safe_memory_strong_tokens(clean)
    measures = _safe_memory_measures(clean)
    if len(qstrong) < 2 and not measures:
        return {"allowed": False, "reason": "too_generic_one_token", "normalized_query": clean, "tokens": qstrong}
    product_text = " ".join(str(product.get(k) or "") for k in ["name", "canonical_display_name", "brand", "product_family", "strength", "size", "pack", "form"])
    pnorm = clean_alias_text(product_text)
    pcompact = re.sub(r"\s+", "", pnorm)
    qcompact = re.sub(r"\s+", "", clean)
    if not any(t in pnorm.split() or t in pcompact for t in qstrong):
        return {"allowed": False, "reason": "no_product_token_overlap", "normalized_query": clean, "tokens": qstrong}

    # Reject if this exact memory phrase appears compatible with multiple visible products.
    try:
        rows = load_product_rows(visible_only=True, guided=False)
    except Exception:
        rows = []
    compatible: List[int] = []
    qset = set(qstrong)
    for row in rows:
        try:
            pid = int(row.get("id") or 0)
        except Exception:
            pid = 0
        if not pid:
            continue
        hay = clean_alias_text(" ".join(str(row.get(k) or "") for k in ["name", "canonical_display_name", "brand", "product_family", "strength", "size", "pack", "form", "aliases", "barcode"]))
        hcompact = re.sub(r"\s+", "", hay)
        token_ok = qset and all((t in hay.split() or t in hcompact) for t in qset)
        measure_ok = all(m.lower().replace(" ", "") in hcompact for m in measures) if measures else True
        if token_ok and measure_ok:
            compatible.append(pid)
            if len(set(compatible)) > 1:
                break
    if len(set(compatible)) > 1 and int(product.get("id") or 0) not in set(compatible[:1]):
        return {"allowed": False, "reason": "ambiguous_visible_products", "normalized_query": clean, "compatible": compatible[:5]}
    if len(set(compatible)) > 1:
        return {"allowed": False, "reason": "ambiguous_visible_products", "normalized_query": clean, "compatible": compatible[:5]}
    return {"allowed": True, "reason": "specific_exact_memory", "normalized_query": clean, "tokens": qstrong, "measures": measures}


def add_safe_text_memory(raw_query: object, product_id: int, source: str = "gemini_safe_economy", user_key: str = "") -> Dict[str, Any]:
    raw = str(raw_query or "").strip()
    if not raw or not product_id:
        return {"saved": False, "reason": "empty"}
    product = get_product(int(product_id))
    check = safe_memory_alias_allowed(raw, product)
    if not check.get("allowed"):
        return {"saved": False, **check}
    clean = str(check.get("normalized_query") or clean_alias_text(raw))
    with connect() as conn:
        ensure_safe_economy_schema(conn)
        conn.execute(
            """
            INSERT INTO safe_text_memory(normalized_query, raw_query, product_id, source, confirmed_count, active, last_user_key, created_at, updated_at)
            VALUES(?,?,?,?,1,1,?,datetime('now'),datetime('now'))
            ON CONFLICT(normalized_query) DO UPDATE SET
                product_id=excluded.product_id,
                raw_query=excluded.raw_query,
                source=excluded.source,
                confirmed_count=confirmed_count + 1,
                active=1,
                last_user_key=excluded.last_user_key,
                updated_at=datetime('now')
            """,
            (clean, raw, int(product_id), source or "gemini_safe_economy", str(user_key or "")),
        )
    return {"saved": True, "normalized_query": clean, "product_id": int(product_id), "source": source}


def lookup_safe_text_memory(raw_query: object) -> Optional[Dict[str, Any]]:
    clean = clean_alias_text(raw_query)
    if not clean:
        return None
    with connect() as conn:
        if not table_exists(conn, "safe_text_memory"):
            return None
        ensure_safe_economy_schema(conn)
        row = conn.execute(
            """
            SELECT * FROM safe_text_memory
            WHERE normalized_query=? AND COALESCE(active,1)=1 AND COALESCE(confirmed_count,0) >= 1
            ORDER BY confirmed_count DESC, updated_at DESC LIMIT 1
            """,
            (clean,),
        ).fetchone()
        d = dict_row(row)
    if not d:
        return None
    product = get_product(int(d.get("product_id") or 0))
    if not product or not product_visible(product, guided=False):
        return None
    return {"memory": d, "product": product, "normalized_query": clean}


def reject_safe_text_memory(raw_query: object, product_id: int = 0) -> None:
    clean = clean_alias_text(raw_query)
    if not clean:
        return
    with connect() as conn:
        if not table_exists(conn, "safe_text_memory"):
            return
        ensure_safe_economy_schema(conn)
        if product_id:
            conn.execute(
                "UPDATE safe_text_memory SET rejected_count=COALESCE(rejected_count,0)+1, active=CASE WHEN COALESCE(rejected_count,0)+1 >= 2 THEN 0 ELSE active END, updated_at=datetime('now') WHERE normalized_query=? AND product_id=?",
                (clean, int(product_id)),
            )
        else:
            conn.execute(
                "UPDATE safe_text_memory SET rejected_count=COALESCE(rejected_count,0)+1, active=CASE WHEN COALESCE(rejected_count,0)+1 >= 2 THEN 0 ELSE active END, updated_at=datetime('now') WHERE normalized_query=?",
                (clean,),
            )


def safe_economy_stats() -> Dict[str, Any]:
    with connect() as conn:
        out: Dict[str, Any] = {"safe_text_memory": 0, "exact_image_confirmed": 0}
        if table_exists(conn, "safe_text_memory"):
            row = conn.execute("SELECT COUNT(*) FROM safe_text_memory WHERE COALESCE(active,1)=1").fetchone()
            out["safe_text_memory"] = int(row[0] if row else 0)
        if table_exists(conn, "image_cache"):
            row = conn.execute("SELECT COUNT(*) FROM image_cache WHERE decision='EXACT_IMAGE_CONFIRMED'").fetchone()
            out["exact_image_confirmed"] = int(row[0] if row else 0)
        return out


# cleanup_old_runtime_rows defined above with image/cache cleanup



# ---------------- Final Production Hardening ----------------
def _stable_code_prefix() -> str:
    return (os.getenv("PRICEBOT_STABLE_CODE_PREFIX", "PB") or "PB").strip().upper()[:8] or "PB"


def _format_stable_product_code(product_id: int) -> str:
    return f"{_stable_code_prefix()}-{int(product_id):06d}"


def ensure_final_hardening_schema(conn: Any = None) -> Dict[str, Any]:
    """Add final production-safe management structures.

    Additive only: no products, prices, stock flags, or secrets are changed.
    """
    stats: Dict[str, Any] = {"ok": True, "stable_codes_backfilled": 0, "indexes": 0}

    def run(c: Any) -> Dict[str, Any]:
        if table_exists(c, "products"):
            add_column(c, "products", "stable_product_code", "TEXT DEFAULT ''")
            add_column(c, "products", "barcode_verified", "INTEGER DEFAULT 0")
            rows = c.execute("SELECT id FROM products WHERE stable_product_code IS NULL OR stable_product_code='' ORDER BY id ASC").fetchall()
            for row in rows:
                pid = int(row[0] if not hasattr(row, "keys") else row["id"])
                c.execute("UPDATE products SET stable_product_code=? WHERE id=?", (_format_stable_product_code(pid), pid))
                stats["stable_codes_backfilled"] += 1
            try:
                c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_products_stable_product_code ON products(stable_product_code)")
                c.execute("CREATE INDEX IF NOT EXISTS idx_products_barcode_verified ON products(barcode, barcode_verified)")
                stats["indexes"] += 2
            except Exception as exc:
                stats["index_warning"] = repr(exc)

        c.execute("""
            CREATE TABLE IF NOT EXISTS memory_review_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_type TEXT NOT NULL,
                memory_id INTEGER,
                action TEXT NOT NULL,
                actor TEXT DEFAULT '',
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_memory_review_audit_type_time ON memory_review_audit(memory_type, created_at)")

        c.execute("""
            CREATE TABLE IF NOT EXISTS bot_metrics_daily (
                day TEXT PRIMARY KEY,
                text_messages INTEGER DEFAULT 0,
                image_messages INTEGER DEFAULT 0,
                gemini_calls INTEGER DEFAULT 0,
                safe_text_hits INTEGER DEFAULT 0,
                exact_image_hits INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        return stats

    if conn is not None:
        return run(conn)
    with connect() as owned:
        return run(owned)


def assign_stable_product_code(product_id: int) -> str:
    pid = int(product_id or 0)
    if pid <= 0:
        return ""
    code = _format_stable_product_code(pid)
    with connect() as conn:
        if not table_exists(conn, "products"):
            return ""
        add_column(conn, "products", "stable_product_code", "TEXT DEFAULT ''")
        row = conn.execute("SELECT stable_product_code FROM products WHERE id=?", (pid,)).fetchone()
        if not row:
            return ""
        current = row[0] if not hasattr(row, "keys") else row["stable_product_code"]
        if current:
            return str(current)
        conn.execute("UPDATE products SET stable_product_code=? WHERE id=?", (code, pid))
    return code


def list_memory_review_items(limit: int = 100, offset: int = 0, include_inactive: bool = False) -> Dict[str, Any]:
    """Return conservative memory bindings for admin review."""
    ensure_final_hardening_schema()
    limit = max(1, min(int(limit or 100), 500))
    offset = max(0, int(offset or 0))
    out: Dict[str, Any] = {"safe_text_memory": [], "exact_image_memory": [], "counts": {}}
    with connect() as conn:
        if table_exists(conn, "safe_text_memory"):
            where = "" if include_inactive else "WHERE COALESCE(m.active,1)=1"
            rows = conn.execute(f"""
                SELECT m.*, p.name AS product_name, p.price AS product_price, p.available, p.is_available, p.stable_product_code
                FROM safe_text_memory m
                LEFT JOIN products p ON p.id=m.product_id
                {where}
                ORDER BY m.updated_at DESC, m.id DESC
                LIMIT ? OFFSET ?
            """, (limit, offset)).fetchall()
            out["safe_text_memory"] = [dict_row(r) for r in rows]
            out["counts"]["safe_text_active"] = int(conn.execute("SELECT COUNT(*) FROM safe_text_memory WHERE COALESCE(active,1)=1").fetchone()[0])
        if table_exists(conn, "image_cache"):
            where = "WHERE decision IN ('EXACT_IMAGE_CONFIRMED','VISUAL_MEMORY_APPROVED')"
            if not include_inactive:
                where += " AND COALESCE(matched_product_id,0)>0"
            rows = conn.execute(f"""
                SELECT ic.id, ic.image_hash, ic.media_id, ic.matched_product_id, ic.decision, ic.confidence, ic.updated_at, ic.created_at,
                       p.name AS product_name, p.price AS product_price, p.available, p.is_available, p.stable_product_code
                FROM image_cache ic
                LEFT JOIN products p ON p.id=ic.matched_product_id
                {where}
                ORDER BY ic.updated_at DESC, ic.id DESC
                LIMIT ? OFFSET ?
            """, (limit, offset)).fetchall()
            out["exact_image_memory"] = [dict_row(r) for r in rows]
            out["counts"]["exact_image_active"] = int(conn.execute("SELECT COUNT(*) FROM image_cache WHERE decision IN ('EXACT_IMAGE_CONFIRMED','VISUAL_MEMORY_APPROVED') AND COALESCE(matched_product_id,0)>0").fetchone()[0])
    return out


def disable_safe_text_memory_by_id(memory_id: int, actor: str = "admin", reason: str = "manual_review") -> bool:
    ensure_final_hardening_schema()
    with connect() as conn:
        if not table_exists(conn, "safe_text_memory"):
            return False
        cur = conn.execute("UPDATE safe_text_memory SET active=0, updated_at=datetime('now') WHERE id=?", (int(memory_id),))
        conn.execute(
            "INSERT INTO memory_review_audit(memory_type, memory_id, action, actor, details) VALUES(?,?,?,?,?)",
            ("safe_text_memory", int(memory_id), "disable", actor or "admin", reason or "manual_review"),
        )
        return bool(cur.rowcount)


def delete_exact_image_memory_by_id(memory_id: int, actor: str = "admin", reason: str = "manual_review") -> bool:
    ensure_final_hardening_schema()
    with connect() as conn:
        if not table_exists(conn, "image_cache"):
            return False
        cur = conn.execute(
            "UPDATE image_cache SET matched_product_id=NULL, decision='DISABLED_BY_ADMIN', updated_at=datetime('now') WHERE id=?",
            (int(memory_id),),
        )
        conn.execute(
            "INSERT INTO memory_review_audit(memory_type, memory_id, action, actor, details) VALUES(?,?,?,?,?)",
            ("exact_image_memory", int(memory_id), "disable", actor or "admin", reason or "manual_review"),
        )
        return bool(cur.rowcount)


def final_dashboard_metrics() -> Dict[str, Any]:
    ensure_final_hardening_schema()
    with connect() as conn:
        def scalar(sql: str, params: Sequence[Any] = ()) -> int:
            try:
                row = conn.execute(sql, tuple(params)).fetchone()
                return int((row[0] if row else 0) or 0)
            except Exception:
                return 0
        metrics: Dict[str, Any] = {
            "products_total": scalar("SELECT COUNT(*) FROM products") if table_exists(conn, "products") else 0,
            "products_available": scalar("SELECT COUNT(*) FROM products WHERE COALESCE(is_available,1)=1") if table_exists(conn, "products") else 0,
            "stable_codes": scalar("SELECT COUNT(*) FROM products WHERE stable_product_code IS NOT NULL AND stable_product_code<>''") if table_exists(conn, "products") and "stable_product_code" in table_columns(conn, "products") else 0,
            "safe_text_memory_active": scalar("SELECT COUNT(*) FROM safe_text_memory WHERE COALESCE(active,1)=1") if table_exists(conn, "safe_text_memory") else 0,
            "safe_text_memory_disabled": scalar("SELECT COUNT(*) FROM safe_text_memory WHERE COALESCE(active,1)=0") if table_exists(conn, "safe_text_memory") else 0,
            "exact_image_confirmed": scalar("SELECT COUNT(*) FROM image_cache WHERE decision IN ('EXACT_IMAGE_CONFIRMED','VISUAL_MEMORY_APPROVED') AND COALESCE(matched_product_id,0)>0") if table_exists(conn, "image_cache") else 0,
            "gemini_savings_estimate": 0,
            "learning_pending": scalar("SELECT COUNT(*) FROM learning_inbox WHERE status='pending'") if table_exists(conn, "learning_inbox") else 0,
            "review_pending": scalar("SELECT COUNT(*) FROM review_queue WHERE COALESCE(resolved,0)=0") if table_exists(conn, "review_queue") else 0,
            "last_uploads": [],
        }
        metrics["gemini_savings_estimate"] = metrics["safe_text_memory_active"] + metrics["exact_image_confirmed"]
        if table_exists(conn, "product_upload_history"):
            rows = conn.execute("SELECT * FROM product_upload_history ORDER BY id DESC LIMIT 5").fetchall()
            metrics["last_uploads"] = [dict_row(r) for r in rows]
        return metrics


def list_database_backups(limit: int = 20) -> List[Dict[str, Any]]:
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    items: List[Dict[str, Any]] = []
    for path in sorted(BACKUPS_DIR.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)[: max(1, int(limit or 20))]:
        try:
            st = path.stat()
            items.append({"name": path.name, "path": str(path), "size": st.st_size, "mtime": datetime.fromtimestamp(st.st_mtime).isoformat(sep=" ", timespec="seconds")})
        except Exception:
            pass
    return items


def create_manual_backup(label: str = "manual_admin") -> Dict[str, Any]:
    path = backup_db(label or "manual_admin")
    return {"ok": True, "name": Path(path).name, "path": str(path)}


def restore_backup_by_name(name: str) -> Dict[str, Any]:
    safe_name = Path(str(name or "")).name
    if not safe_name or safe_name != str(name or ""):
        raise ValueError("invalid backup name")
    candidate = (BACKUPS_DIR / safe_name).resolve()
    if BACKUPS_DIR.resolve() not in candidate.parents and candidate != BACKUPS_DIR.resolve():
        raise ValueError("invalid backup path")
    restore_db_from_backup(candidate)
    invalidate_runtime_caches()
    return {"ok": True, "restored": safe_name}


# ============================================================
# V9 Production Database Layer: PostgreSQL pool, managed migrations,
# and PostgreSQL hardening.  These definitions intentionally appear at
# the end of the module so the existing app code keeps using the same
# public function names while gaining pooled PostgreSQL behavior.
# ============================================================
_PG_POOL = None
_PG_POOL_LAST_ERROR = ""


def _pg_pool_enabled() -> bool:
    return IS_POSTGRES and str(os.getenv("PRICEBOT_POSTGRES_POOL_ENABLED", "1")).strip().lower() not in {"0", "false", "no", "off"}


def _pg_pool_size(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, str(default)) or default))
    except Exception:
        return default


def _get_pg_pool():
    global _PG_POOL, _PG_POOL_LAST_ERROR
    if not IS_POSTGRES or not _pg_pool_enabled():
        return None
    if _PG_POOL is not None:
        return _PG_POOL
    try:
        from psycopg.rows import dict_row as pg_dict_row
        from psycopg_pool import ConnectionPool
        _PG_POOL = ConnectionPool(
            conninfo=DATABASE_URL_RAW,
            min_size=_pg_pool_size("PRICEBOT_POSTGRES_POOL_MIN", 1),
            max_size=_pg_pool_size("PRICEBOT_POSTGRES_POOL_MAX", 10),
            kwargs={"row_factory": pg_dict_row, "autocommit": False},
            timeout=float(os.getenv("PRICEBOT_POSTGRES_POOL_TIMEOUT_SECONDS", "10") or 10),
            open=True,
        )
        _PG_POOL_LAST_ERROR = ""
        return _PG_POOL
    except Exception as exc:
        _PG_POOL_LAST_ERROR = repr(exc)
        if str(os.getenv("PRICEBOT_POSTGRES_POOL_REQUIRED", "0")).strip().lower() in {"1", "true", "yes", "on"}:
            raise
        return None


def close_database_pool() -> None:
    global _PG_POOL
    if _PG_POOL is not None:
        try:
            _PG_POOL.close()
        finally:
            _PG_POOL = None


@contextmanager
def connect() -> Iterable[Any]:
    if IS_POSTGRES:
        try:
            import psycopg
            from psycopg.rows import dict_row as pg_dict_row
        except Exception as exc:
            raise RuntimeError("POSTGRES_PRODUCTION_REQUIRES_psycopg_binary") from exc
        pool = _get_pg_pool()
        if pool is not None:
            with pool.connection() as raw_conn:
                compat = PgConnectionCompat(raw_conn)
                try:
                    yield compat
                    if not READ_ONLY_MODE:
                        compat.commit()
                except Exception:
                    if not READ_ONLY_MODE:
                        compat.rollback()
                    raise
            return
        raw_conn = psycopg.connect(DATABASE_URL_RAW, row_factory=pg_dict_row, autocommit=False)
        compat = PgConnectionCompat(raw_conn)
        try:
            yield compat
            if not READ_ONLY_MODE:
                compat.commit()
        except Exception:
            if not READ_ONLY_MODE:
                compat.rollback()
            raise
        finally:
            compat.close()
        return

    if READ_ONLY_MODE:
        if not DB_FILE.exists():
            raise FileNotFoundError(f"DB not found for read-only connection: {DB_FILE}")
        uri = f"file:{DB_FILE}?mode=ro"
        conn = sqlite3.connect(uri, timeout=30, uri=True)
    else:
        DB_FILE.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_FILE), timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            conn.execute("PRAGMA temp_store=MEMORY")
            conn.execute("PRAGMA cache_size=-20000")
            conn.execute("PRAGMA mmap_size=268435456")
        except Exception:
            pass
        if not READ_ONLY_MODE:
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.execute("PRAGMA wal_autocheckpoint=1000")
            except Exception:
                pass
        yield conn
        if not READ_ONLY_MODE:
            conn.commit()
    except Exception:
        if not READ_ONLY_MODE:
            conn.rollback()
        raise
    finally:
        conn.close()


def ensure_schema_migrations(conn: Any) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version TEXT PRIMARY KEY,
            description TEXT DEFAULT '',
            applied_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)


def _migration_applied(conn: Any, version: str) -> bool:
    ensure_schema_migrations(conn)
    row = conn.execute("SELECT version FROM schema_migrations WHERE version=?", (version,)).fetchone()
    return bool(row)


def _mark_migration(conn: Any, version: str, description: str) -> None:
    ensure_schema_migrations(conn)
    conn.execute("INSERT OR IGNORE INTO schema_migrations(version, description, applied_at) VALUES(?, ?, datetime('now'))", (version, description))


def apply_managed_migrations(conn: Optional[Any] = None) -> Dict[str, Any]:
    stats: Dict[str, Any] = {"ok": True, "applied": [], "engine": "postgres" if IS_POSTGRES else "sqlite"}

    def _run(active_conn: Any) -> Dict[str, Any]:
        ensure_schema_migrations(active_conn)
        migrations = [
            ("20260624_0900_v9_schema_migrations", "Managed migration ledger for production upgrades."),
            ("20260624_0910_v9_postgres_ready", "PostgreSQL-ready schema and cache/index hardening."),
        ]
        for version, description in migrations:
            if not _migration_applied(active_conn, version):
                _mark_migration(active_conn, version, description)
                stats["applied"].append(version)
        return stats

    if conn is not None:
        return _run(conn)
    with connect() as active:
        return _run(active)


def _postgres_index_specs() -> List[Tuple[str, str, Sequence[str]]]:
    return [
        ("idx_pg_products_visible_search", "products", ["available", "is_available", "search_mode", "review_status"]),
        ("idx_pg_products_norm_available", "products", ["normalized_name", "available", "is_available"]),
        ("idx_pg_products_identity", "products", ["identity_key"]),
        ("idx_pg_products_brand", "products", ["brand"]),
        ("idx_pg_products_family", "products", ["product_family"]),
        ("idx_pg_products_barcode", "products", ["barcode"]),
        ("idx_pg_alias_cleaned_active", "product_aliases", ["cleaned_alias", "active"]),
        ("idx_pg_alias_product_active", "product_aliases", ["product_id", "active"]),
        ("idx_pg_safe_text_memory_query_active", "safe_text_memory", ["normalized_query", "active"]),
        ("idx_pg_safe_text_memory_product_active", "safe_text_memory", ["product_id", "active"]),
        ("idx_pg_image_cache_hash", "image_cache", ["image_hash"]),
        ("idx_pg_image_cache_media_updated", "image_cache", ["media_id", "updated_at"]),
        ("idx_pg_conversation_expiry", "conversation_state", ["expires_at"]),
        ("idx_pg_processed_created", "processed_messages", ["created_at"]),
    ]


def apply_postgres_hardening(conn: Any) -> Dict[str, Any]:
    stats: Dict[str, Any] = {"engine": "postgres", "ok": True, "created_or_verified_indexes": 0, "skipped": 0}
    for spec in _postgres_index_specs():
        try:
            if _create_index_if_columns_exist(conn, *spec):
                stats["created_or_verified_indexes"] += 1
            else:
                stats["skipped"] += 1
        except Exception as exc:
            stats.setdefault("index_warnings", []).append({"index": spec[0], "error": repr(exc)})
    try:
        conn.execute("ANALYZE")
    except Exception as exc:
        stats["analyze_warning"] = repr(exc)
    try:
        apply_managed_migrations(conn)
    except Exception as exc:
        stats["migration_warning"] = repr(exc)
    return stats


_original_sqlite_apply_performance_hardening = apply_performance_hardening


def apply_performance_hardening(conn: Optional[Any] = None) -> Dict[str, Any]:
    if IS_POSTGRES:
        if conn is not None:
            return apply_postgres_hardening(conn)
        with connect() as active:
            return apply_postgres_hardening(active)
    return _original_sqlite_apply_performance_hardening(conn)


def database_engine_info() -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "engine": "postgres" if IS_POSTGRES else "sqlite",
        "postgres": bool(IS_POSTGRES),
        "sqlite_path": str(DB_FILE) if not IS_POSTGRES else None,
        "db_path_source": DB_PATH_SOURCE,
        "postgres_pool_enabled": bool(IS_POSTGRES and _pg_pool_enabled()),
        "postgres_pool_last_error": _PG_POOL_LAST_ERROR,
    }
    if IS_POSTGRES:
        info["database_url_configured"] = bool(DATABASE_URL_RAW)
        pool = _PG_POOL
        if pool is not None:
            try:
                info["postgres_pool_stats"] = dict(pool.get_stats())
            except Exception:
                info["postgres_pool_stats"] = "unavailable"
    return info


def schema_migration_versions() -> List[str]:
    try:
        with connect() as conn:
            if not table_exists(conn, "schema_migrations"):
                return []
            rows = conn.execute("SELECT version FROM schema_migrations ORDER BY version").fetchall()
            return [str(dict_row(r).get("version") if dict_row(r) else "") for r in rows]
    except Exception:
        return []


# PRICEBOT_V9_POSTGRES_DATETIME_HOTFIX_OK


# PRICEBOT_V9_POSTGRES_BOOLEAN_DATETIME_HOTFIX_OK


# PRICEBOT_MANUAL_V9_POSTGRES_HOTFIX_OK


# PRICEBOT_POSTGRES_COLLATE_NOCASE_HOTFIX
# PostgreSQL compatibility guard: SQLite COLLATE NOCASE is not valid in PostgreSQL.
def _pricebot_strip_sqlite_collations_for_postgres(sql):
    try:
        import re as _re
        sql = _re.sub(r"\s+COLLATE\s+NOCASE\b", "", sql, flags=_re.I)
        sql = _re.sub(r"\s+COLLATE\s+RTRIM\b", "", sql, flags=_re.I)
        sql = _re.sub(r"\s+COLLATE\s+BINARY\b", "", sql, flags=_re.I)
        return sql
    except Exception:
        return sql


# PRICEBOT_POSTGRES_AUTO_ROLLBACK_PATCH
# Prevent PostgreSQL connections from staying in "transaction aborted" state.
try:
    import psycopg as _pb_psycopg
    from psycopg.errors import InFailedSqlTransaction as _pb_InFailedSqlTransaction

    _pb_old_cursor_execute = _pb_psycopg.Cursor.execute

    def _pb_safe_cursor_execute(self, query, params=None, *args, **kwargs):
        try:
            return _pb_old_cursor_execute(self, query, params, *args, **kwargs)
        except Exception:
            try:
                if getattr(self, "connection", None) is not None:
                    self.connection.rollback()
            except Exception:
                pass
            raise

    if not getattr(_pb_psycopg.Cursor.execute, "_pricebot_safe_rollback", False):
        _pb_safe_cursor_execute._pricebot_safe_rollback = True
        _pb_psycopg.Cursor.execute = _pb_safe_cursor_execute

except Exception as exc:
    print("PRICEBOT_POSTGRES_AUTO_ROLLBACK_PATCH_INIT_ERROR", repr(exc))
