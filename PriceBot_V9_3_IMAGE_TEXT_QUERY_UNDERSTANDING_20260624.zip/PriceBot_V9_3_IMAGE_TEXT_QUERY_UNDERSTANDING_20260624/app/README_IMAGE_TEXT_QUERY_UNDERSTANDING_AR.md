# PriceBot V9.3 — Image Flow Uses Text Query Understanding

هذه النسخة مبنية على V9.2 وتضيف إصلاحًا لمسار البحث بالصورة.

## المشكلة التي عولجت
كان البحث النصي يجد المنتج عند كتابة الاسم يدويًا مثل:

`Hemazym`

لكن صورة نفس المنتج كانت ترجع:

`غير متوفر حاليًا في الصيدلية`

لأن مسار الصورة كان يبحث بالنص الخام المستخرج من Gemini/Vision مثل:

`Liposomal Hemazym Iron Supplement 30 Capsules`

بدل أن يمرره على طبقة فهم النص التي تستخرج اسم المنتج الأساسي.

## التعديل
داخل `process_image()` في `app.py`:

- يتم أخذ `evidence` الناتج من Gemini/Vision.
- يتم جمع كل الحقول النصية المهمة من الصورة.
- يتم تمريرها إلى نفس مسار البحث النصي:
  - `extract_product_query_from_customer_text()`
  - `_search_text_query_candidates()`
  - `inventory_phonetic_candidates()`
- يتم تسجيل لوجات تشخيصية:
  - `IMAGE_TEXT_QUERY_MATCH`
  - `IMAGE_TEXT_QUERY_NO_MATCH`
  - `IMAGE_TEXT_QUERY_MEMORY`

## Acceptance Criteria
- صورة منتج `Hemazym` يجب أن تعطي نفس نتيجة كتابة `Hemazym`.
- النص الخام الطويل من الصورة لا يُبحث به مباشرة فقط.
- لا يوجد تغيير في Gemini/Vision نفسه.
- لا يوجد hardcoding لمنتج Hemazym.
- قاعدة البيانات لا تتغير بهذا التعديل.

## الإصدار
`v9_3_image_text_query_understanding_safe`
