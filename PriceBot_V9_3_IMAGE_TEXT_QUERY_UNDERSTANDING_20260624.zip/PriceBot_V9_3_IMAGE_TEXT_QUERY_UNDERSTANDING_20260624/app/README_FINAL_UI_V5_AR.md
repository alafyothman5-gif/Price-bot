# PriceBot WhatsApp Final UI V5 Scale

هذه النسخة لا تغيّر منطق Gemini/Vision، لكنها تعالج مشاكل الأداء والاستقرار:

- حالة المستخدمين والـ confirmations تدعم Redis عبر `REDIS_URL` مع TTL.
- عند عدم وجود Redis تعمل النسخة بذاكرة داخلية مع TTL كـ fallback، لكن للـ scaling الحقيقي استخدم Redis.
- تم حذف تكرار `_search_available_products` عبر App نظيف ومنطق بحث واحد.
- البحث يستخدم inverted index في الذاكرة بدل المرور على كل المنتجات في كل طلب.
- cleanup للـ rate limits والذاكرة يعمل Background كل 5 دقائق، وليس مع كل رسالة.
- إرسال واتساب فيه retry ثلاث محاولات مع exponential backoff.
- إرسال قوائم المنتجات يتم بدون `sleep` بين الرسائل.
- TTL فهرس المنتجات 5 دقائق افتراضيًا ويمكن تغييره بـ `PRICEBOT_PRODUCT_INDEX_TTL_SECONDS`.
- الصور لا تزال تعتمد على Gemini/Vision كما هي.

علامة التشغيل في `/health`:

```json
"final_ui_version": "v5_scale_redis_index_retry",
"matcher_index_enabled": true
```

للتحمل الأفضل مع 100 مستخدم، ثبّت Redis واضبط:

```env
REDIS_URL=redis://127.0.0.1:6379/0
```
