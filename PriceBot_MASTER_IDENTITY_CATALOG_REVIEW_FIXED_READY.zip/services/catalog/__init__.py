
# Master identity catalog lives in services.catalog.master_identity
