from __future__ import annotations

"""Excel-native deterministic matcher for PriceBot.

This engine treats the pharmacy Excel/database as the source of truth.  It does
not use global fuzzy fallback.  It returns a price only after a product identity
is uniquely resolved; generic family names ask for clarification when the catalog contains variants.
"""

import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import database
from normalizer import clean_query, compact_normalize, normalize_text, safe_price, split_multi
from query_slots import canonical_form, extract_packs, extract_sizes, extract_strengths, normalize_measure
from search_engine import SearchResult
from services.catalog.identity_generation import (
    WEAK_TOKENS as CATALOG_WEAK_TOKENS,
    BrandFamilyNormalizer,
    CatalogAliasGenerator,
    generated_aliases_for_product,
)
from services.learning.suggestion_engine import suggest_learning_candidates
from services.matching.candidate_safety_filter import CandidateSafetyFilter
from services.whatsapp.result_formatter import clarification_message

WEAK_TOKENS: Set[str] = set(CATALOG_WEAK_TOKENS) | {
    "the", "and", "for", "with", "new", "plus", "extra", "advance", "advanced",
    "cream", "creme", "gel", "ointment", "lotion", "serum", "cleanser", "wash", "foam",
    "moisturizer", "moisturizing", "shampoo", "conditioner", "spray", "oil", "mask",
    "tablet", "tablets", "tab", "tabs", "capsule", "capsules", "cap", "caps", "syr", "syrup",
    "susp", "suspension", "supp", "drop", "drops", "inj", "amp", "solution", "sachet", "sachets",
    "skin", "face", "body", "hair", "care", "support", "supports", "health", "supplement", "food",
    "iron", "vitamin", "vitamins", "female", "male", "adult", "baby", "infant", "tube",
    "mg", "mcg", "ml", "g", "iu", "i", "u", "d", "k", "b", "c", "pro", "scar",
    "كريم", "جل", "مرهم", "لوشن", "سيروم", "غسول", "شامبو", "بلسم", "بخاخ", "زيت",
    "اقراص", "حبوب", "كبسولات", "كبسول", "شراب", "قطرات", "حقن", "اكياس",
    "فيتامين", "حديد", "مكمل", "صحه", "بشره", "وجه", "جسم", "شعر",
}
WEAK_TOKENS.discard("scar")
WEAK_TOKENS.discard("pro")

MEASURE_TOKENS = {"mg", "mcg", "ml", "g", "iu", "tab", "tabs", "tablet", "tablets", "cap", "caps", "capsule", "capsules", "sachet", "sachets"}

FORM_EQUIV = {
    "syrup": {"syrup", "suspension"},
    "suspension": {"syrup", "suspension"},
    "cleanser": {"cleanser"},
    "cream": {"cream"},
    "ointment": {"ointment"},
    "capsule": {"capsule"},
    "tablet": {"tablet"},
}
COSMETIC_HARD_FORMS: Set[str] = {"cleanser", "cream", "ointment", "gel", "lotion", "serum", "moisturizer", "sunscreen", "shampoo", "conditioner", "spray", "oil", "mask", "toner"}

# Product-specific OCR aliases must not live in matcher code.
# They belong in the catalog, product_identity_registry, dynamic synonyms, or
# admin-approved learning tables.  Kept as an empty compatibility map.
KNOWN_VISION_ALIASES: Dict[str, str] = {}


# Generic-family detection is data-driven: if one short query maps to multiple
# catalog products, ask for clarification. No product names are hardcoded here.
GENERIC_FAMILY_WORDS: Set[str] = set()

# Product-specific low-confidence patterns are not allowed in matcher code.
IMAGE_LOW_CONFIDENCE_PATTERNS: List[Set[str]] = []

# Words that vision models often mislabel as a brand.  They are allowed to
# remain in the full OCR phrase, but must not be trusted as a brand-only query.
VISION_NON_BRAND_TOKENS: Set[str] = {
    "white", "black", "red", "blue", "green", "yellow", "petroleum", "cream", "creme",
    "gel", "jelly", "ointment", "lotion", "serum", "cleanser", "wash", "soap", "shampoo",
    "tablet", "capsule", "syrup", "suspension", "drops", "spray", "oil", "mask",
}

# Marketing/background OCR words that commonly appear on packages and should not
# dominate image matching.  They are removed only while building image candidate
# queries; the original OCR is still stored in diagnostics/learning.
VISION_OCR_NOISE_TOKENS: Set[str] = {
    "laboratoires", "laboratoire", "laboratory", "laboratories", "dermatologique",
    "dermatological", "physiologic", "physiological", "physiologique", "purif",
    "purifying", "purifies", "daily", "deep", "cleansing", "cleaning", "foam",
    "normal", "oily", "imperfections", "imperfection", "acne", "prone", "skin",
    "face", "body", "oiliness", "shine", "confidence", "source", "text", "visible",
    "background", "front", "pack", "package", "box", "tube", "jar", "bottle",
    "orb", "zorb", "optizorb", "easy", "swallow", "caplets", "caplet", "tablets",
    "tablet", "paracetamol", "caffeine", "film", "coated", "advance", "advanced",
    "plus", "new", "original", "orginal", "egy", "irland", "tunsia", "laboratoires",
}

# OCR fragment corrections must come from admin-approved learning/dynamic data,
# not hardcoded product-specific matcher rules.
VISION_OCR_FRAGMENT_FIXES: Dict[str, str] = {}


def _now() -> float:
    return time.time()


def _n(value: Any) -> str:
    return normalize_text(value)


def _compact(value: Any) -> str:
    return compact_normalize(value)


def _word_tokens(value: Any) -> List[str]:
    n = _n(value)
    return [t for t in n.split() if t]


def _strong_tokens(value: Any) -> List[str]:
    out: List[str] = []
    for t in _word_tokens(value):
        if t in WEAK_TOKENS:
            continue
        if len(t) <= 2 and not t.isdigit():
            continue
        if t.isdigit():
            # Standalone digits are weak unless part of a measure expression.
            continue
        if t not in out:
            out.append(t)
    return out


def _phrase_in(phrase: str, text: str) -> bool:
    phrase = _n(phrase)
    text = _n(text)
    if not phrase or not text:
        return False
    return f" {phrase} " in f" {text} "


def _measures(text: Any) -> Set[str]:
    vals = extract_strengths(text) + extract_sizes(text) + extract_packs(text)
    return {normalize_measure(x) for x in vals if normalize_measure(x)}


def _form_match(requested: str, product_form: str, product_text: str = "") -> bool:
    req = canonical_form(requested) or _n(requested)
    pf = canonical_form(product_form) or _n(product_form)
    if not req:
        return True
    if not pf and product_text:
        pf = canonical_form(product_text) or ""
    if req == pf:
        return True
    return bool(req in FORM_EQUIV and pf in FORM_EQUIV[req])


def _price_conflict(products: Sequence[Dict[str, Any]]) -> bool:
    prices = {safe_price(p.get("price")) for p in products if safe_price(p.get("price"))}
    return len(products) > 1 and len(prices) > 1


def _display_name(p: Dict[str, Any]) -> str:
    return str(p.get("canonical_display_name") or p.get("name") or p.get("original_name") or "").strip()


def _product_identity_key(p: Dict[str, Any]) -> Tuple[str, str, str, str, str, str, str]:
    return (
        _n(p.get("brand")) or (_word_tokens(p.get("name"))[0] if _word_tokens(p.get("name")) else ""),
        _n(p.get("product_family") or p.get("normalized_name") or p.get("name")),
        _n(p.get("category") or p.get("main_section") or p.get("section")),
        canonical_form(p.get("form") or p.get("medicine_form") or p.get("product_type") or p.get("name")) or "",
        normalize_measure(p.get("strength")),
        normalize_measure(p.get("size")),
        normalize_measure(p.get("pack")),
    )


@dataclass
class IndexedProduct:
    product: Dict[str, Any]
    product_id: int
    name: str
    brand: str
    family: str
    category: str
    form: str
    identity_text: str
    identity_compact: str
    exact_keys: Set[str] = field(default_factory=set)
    token_set: Set[str] = field(default_factory=set)
    strong_set: Set[str] = field(default_factory=set)
    measures: Set[str] = field(default_factory=set)
    identity_key: Tuple[str, str, str, str, str, str, str] = field(default_factory=tuple)


class ExcelNativeMatcher:
    def __init__(self) -> None:
        self.loaded_at = 0.0
        self.products: List[IndexedProduct] = []
        self.by_exact: Dict[str, List[IndexedProduct]] = {}
        self.by_brand: Dict[str, List[IndexedProduct]] = {}
        self.brand_names: Set[str] = set()
        self.identity_normalizer: Optional[BrandFamilyNormalizer] = None
        self.safety = CandidateSafetyFilter(WEAK_TOKENS)

    def invalidate(self) -> None:
        self.loaded_at = 0.0
        self.products = []
        self.by_exact = {}
        self.by_brand = {}
        self.brand_names = set()
        self.identity_normalizer = None

    def preload(self) -> int:
        self._load()
        return len(self.products)

    def _add_exact(self, key: str, ip: IndexedProduct) -> None:
        key = _n(key)
        if not key:
            return
        if len(key) <= 2:
            return
        toks = _word_tokens(key)
        if toks and not any((t not in WEAK_TOKENS and not t.isdigit() and len(t) > 2) for t in toks):
            return
        ip.exact_keys.add(key)
        self.by_exact.setdefault(key, []).append(ip)
        c = _compact(key)
        if c and c != key and len(c) >= 4:
            ip.exact_keys.add(c)
            self.by_exact.setdefault(c, []).append(ip)

    def _load(self) -> None:
        if self.loaded_at and self.products:
            return
        rows = database.load_product_rows(visible_only=True, guided=False)
        # Product Identity Overlay is a derived learning layer. It enriches
        # incomplete Excel names in memory only; it never edits products/Excel.
        try:
            from services.vision import visual_memory
            rows = visual_memory.enrich_product_rows(rows, merchant_id=1)
        except Exception:
            pass
        try:
            from services.catalog import master_identity
            rows = master_identity.enrich_product_rows(rows, merchant_id=1)
        except Exception:
            pass
        normalizer = BrandFamilyNormalizer(rows)
        generator = CatalogAliasGenerator(normalizer)
        self.identity_normalizer = normalizer
        products: List[IndexedProduct] = []
        self.by_exact = {}
        self.by_brand = {}
        self.brand_names = set()
        for raw_product in rows:
            p = normalizer.normalize_row(dict(raw_product))
            # Preserve operational columns while using brand-first identity fields.
            for k, v in raw_product.items():
                if k not in p or p.get(k) in {"", None}:
                    p[k] = v
            try:
                pid = int(p.get("id") or 0)
            except Exception:
                pid = 0
            if not pid:
                continue
            name = _display_name(p)
            if not name:
                continue
            brand = _n(p.get("brand"))
            if not brand or brand in {"unknown", "غير مصنف", "غير معروف", "unclassified"}:
                toks = _word_tokens(name)
                inferred = toks[0] if toks else ""
                # Do not create fake brands from generic OCR/display words such as WHITE or PETROLEUM.
                brand = inferred if inferred and inferred not in VISION_NON_BRAND_TOKENS else ""
            family = _n(p.get("product_family") or name)
            category = _n(p.get("category") or p.get("main_section") or p.get("section"))
            form = canonical_form(p.get("form") or p.get("medicine_form") or p.get("product_type") or name) or ""
            gen_aliases, gen_ocr = generator.identity_variations(p)
            generated_identity = gen_aliases + gen_ocr
            fields = [name, p.get("canonical_display_name"), p.get("normalized_name"), p.get("brand"), p.get("product_family"), p.get("active_ingredient"), p.get("aliases"), p.get("ocr_keywords"), p.get("barcode"), p.get("form"), p.get("strength"), p.get("size"), p.get("pack")] + generated_identity
            identity_text = _n(" ".join(str(x or "") for x in fields))
            token_set = set(_word_tokens(identity_text))
            strong_set = set(_strong_tokens(identity_text))
            measures = _measures(identity_text)
            ip = IndexedProduct(
                product=p,
                product_id=pid,
                name=name,
                brand=brand,
                family=family,
                category=category,
                form=form,
                identity_text=identity_text,
                identity_compact=_compact(identity_text),
                token_set=token_set,
                strong_set=strong_set,
                measures=measures,
                identity_key=_product_identity_key(p),
            )
            products.append(ip)
            if brand:
                self.brand_names.add(brand)
                self.by_brand.setdefault(brand, []).append(ip)
            # Exact resolvable names/aliases.  Single generic brand keys are
            # indexed but variant guard will force clarification when needed.
            self._add_exact(name, ip)
            self._add_exact(p.get("normalized_name"), ip)
            self._add_exact(p.get("brand"), ip)
            self._add_exact(p.get("product_family"), ip)
            self._add_exact(p.get("barcode"), ip)
            for field in [p.get("aliases"), p.get("ocr_keywords")]:
                for part in split_multi(field):
                    self._add_exact(part, ip)
            for part in generated_identity:
                self._add_exact(part, ip)
        # Remove duplicate references under same key/product.
        for key, vals in list(self.by_exact.items()):
            seen = set()
            dedup = []
            for ip in vals:
                if ip.product_id in seen:
                    continue
                seen.add(ip.product_id)
                dedup.append(ip)
            self.by_exact[key] = dedup
        self.products = products
        self.loaded_at = _now()

    def _record_learning(self, query: str, decision: str, reason: str, candidates: Sequence[IndexedProduct] = (), vision_text: str = "", slots: Optional[Dict[str, Any]] = None, rejected: Sequence[IndexedProduct] = (), candidate_payloads: Optional[Sequence[Dict[str, Any]]] = None) -> None:
        if str(os.getenv("PRICEBOT_LEARNING_ENABLED", "1")).lower() in {"0", "false", "no", "off"}:
            return
        try:
            database.record_learning_event(
                customer_query=query,
                vision_text=vision_text,
                candidate_products=list(candidate_payloads or [])[:15] if candidate_payloads is not None else [{"id": ip.product_id, "name": ip.name, "price": ip.product.get("price")} for ip in list(candidates)[:15]],
                rejected_candidates=[{"id": ip.product_id, "name": ip.name} for ip in list(rejected)[:20]],
                decision=decision,
                reason=reason,
                query_slots=slots or {},
            )
        except Exception:
            pass

    def _result(self, status: str, message: str = "", products: Sequence[IndexedProduct] = (), product: Optional[IndexedProduct] = None, diagnostics: Optional[Dict[str, Any]] = None, learn_query: str = "", learn_reason: str = "", vision_text: str = "") -> SearchResult:
        plist = [ip.product for ip in products]
        one = product.product if product else None
        res = SearchResult(status=status, message=message, products=plist, product=one, diagnostics=diagnostics or {})
        if status in {"NOT_AVAILABLE", "LOW_CONFIDENCE", "IMAGE_UNCLEAR"}:
            lq = learn_query or message
            suggestions = []
            if lq and not products and self.products:
                suggestions = suggest_learning_candidates(lq, [ip.product for ip in self.products], limit=5)
            self._record_learning(lq, status, learn_reason or status, products, vision_text=vision_text, slots=diagnostics or {}, candidate_payloads=suggestions or None)
        return res

    def _ask_message(self, products: Sequence[IndexedProduct], title: str = "🔎 وجدت أكثر من منتج قريب") -> str:
        return clarification_message([ip.product for ip in products[:10]], title=title)

    def _dedupe(self, items: Iterable[IndexedProduct], limit: int = 30) -> List[IndexedProduct]:
        out: List[IndexedProduct] = []
        seen: Set[int] = set()
        for ip in items:
            if ip.product_id in seen:
                continue
            seen.add(ip.product_id)
            out.append(ip)
            if len(out) >= limit:
                break
        return out

    def _ip_by_product_id(self, product_id: Any) -> Optional[IndexedProduct]:
        try:
            pid = int(product_id or 0)
        except Exception:
            return None
        if not pid:
            return None
        for ip in self.products:
            if ip.product_id == pid:
                return ip
        return None

    def _sort_candidates(self, q: str, cands: Iterable[IndexedProduct]) -> List[IndexedProduct]:
        qn = _n(q)
        qs = set(_strong_tokens(qn))
        qmeasures = _measures(qn)
        qform = canonical_form(qn)
        scored = []
        for ip in cands:
            score = 0
            if _n(ip.name) == qn or qn in ip.exact_keys or _compact(qn) in ip.exact_keys:
                score += 1000
            if qn and _phrase_in(qn, ip.identity_text):
                score += 300
            score += 30 * len(qs & ip.strong_set)
            score += 10 * len(qmeasures & ip.measures)
            if qform and _form_match(qform, ip.form, ip.identity_text):
                score += 80
            # Prefer shorter identities when exact enough.
            score -= min(len(ip.token_set), 80) // 10
            scored.append((score, ip.name.lower(), ip))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [ip for score, _name, ip in scored if score > 0]

    def _variant_scope(self, qn: str, strong: List[str]) -> List[IndexedProduct]:
        # Brand/family scope uses full token matching only, never substring.
        if not strong:
            return []
        first = strong[0]
        scoped: List[IndexedProduct] = []
        if first in self.by_brand:
            scoped.extend(self.by_brand[first])
        # Full phrase at start of identity/family/name.
        for ip in self.products:
            if ip.product_id in {x.product_id for x in scoped}:
                continue
            if ip.brand == first or _n(ip.name).startswith(first + " ") or (ip.family == first or ip.family.startswith(first + " ")):
                scoped.append(ip)
            elif qn and (_n(ip.name) == qn or _n(ip.name).startswith(qn + " ") or _phrase_in(qn, ip.family)):
                scoped.append(ip)
        return self._dedupe(scoped, 50)

    def _generic_variant_guard(self, qn: str, qform: str, qmeasures: Set[str], candidates: Sequence[IndexedProduct]) -> Optional[SearchResult]:
        strong = _strong_tokens(qn)
        if not strong:
            return None
        # Query is general if it has only brand/family token(s), no measure and no form.
        q_is_general = not qform and not qmeasures and (len(_word_tokens(qn)) == 1 or qn in GENERIC_FAMILY_WORDS)
        if not q_is_general:
            return None
        scope = self._variant_scope(qn, strong)
        if len(scope) > 1:
            return self._result(
                "ASK_CLARIFICATION",
                self._ask_message(scope, "يوجد أكثر من نوع/شكل لهذا الاسم. لا أستطيع عرض السعر قبل تحديد المنتج."),
                products=scope,
                diagnostics={"engine": "excel_native", "stage": "generic_variant_guard", "query": qn},
            )
        if len(candidates) > 1:
            return self._result(
                "ASK_CLARIFICATION",
                self._ask_message(candidates, "يوجد أكثر من نتيجة بنفس الاسم. اختر المنتج المطلوب."),
                products=candidates,
                diagnostics={"engine": "excel_native", "stage": "generic_exact_guard", "query": qn},
            )
        return None

    def _duplicate_guard(self, candidates: Sequence[IndexedProduct], qn: str) -> Optional[SearchResult]:
        if not candidates:
            return None
        by_key: Dict[Tuple[str, str, str, str, str, str, str], List[IndexedProduct]] = {}
        for ip in candidates:
            by_key.setdefault(ip.identity_key, []).append(ip)
        conflict_group: List[IndexedProduct] = []
        for group in by_key.values():
            if _price_conflict([g.product for g in group]):
                conflict_group = group
                break
        if conflict_group:
            return self._result(
                "ASK_CLARIFICATION",
                self._ask_message(conflict_group, "هذا المنتج موجود بأكثر من سعر في الملف ويحتاج مراجعة قبل عرض السعر."),
                products=conflict_group,
                diagnostics={"engine": "excel_native", "stage": "duplicate_price_conflict", "query": qn},
            )
        return None

    def _requested_brand_from_query(self, qn: str, strong: Sequence[str]) -> str:
        for token in strong:
            if token in self.brand_names:
                return token
        if self.identity_normalizer:
            brand, _display = self.identity_normalizer.detect_brand({"name": qn})
            if brand in self.brand_names:
                return brand
        return ""

    def _requested_family_from_query(self, qn: str, requested_brand: str) -> str:
        family = qn
        if requested_brand:
            family = re.sub(r"(^|\s)" + re.escape(requested_brand) + r"(?=\s|$)", " ", family).strip()
        # Remove form and measure words from family lock; OCR marketing extras are handled by safety.
        toks = [t for t in _strong_tokens(family) if t != requested_brand]
        return " ".join(toks[:4])

    def _finalize_candidates(self, q: str, cands: Sequence[IndexedProduct], reason: str = "") -> SearchResult:
        qn = _n(q)
        qform = canonical_form(qn)
        qmeasures = _measures(qn)
        strong = _strong_tokens(qn)
        requested_brand = self._requested_brand_from_query(qn, strong)
        requested_family = self._requested_family_from_query(qn, requested_brand)
        exact_allowed = reason in {"exact_key", "barcode_exact"}
        if not cands:
            return self._result("NOT_AVAILABLE", "لم أجد المنتج في قائمة الصيدلية حاليًا. إذا الاسم صحيح، سيتم تسجيله للمراجعة.", learn_query=q, learn_reason=reason or "no_candidates")
        cands = self._sort_candidates(qn, self._dedupe(cands, 50))
        safety = self.safety.filter(
            qn, cands,
            requested_brand=requested_brand,
            requested_family=requested_family if requested_brand else "",
            requested_form=qform,
            exact_allowed=exact_allowed,
            limit=5,
        )
        if safety.products:
            cands = safety.products
        elif not exact_allowed:
            if not safety.strong_tokens:
                return self._result("LOW_CONFIDENCE", "لم أتمكن من تحديد اسم المنتج بوضوح. اكتب الاسم كاملًا أو أرسل صورة أوضح للواجهة الأمامية.", learn_query=q, learn_reason="weak_tokens_only", diagnostics={"engine":"excel_native", "stage":"candidate_safety_filter", "rejected": safety.rejected})
            return self._result("NOT_AVAILABLE", "لم أجد المنتج في قائمة الصيدلية حاليًا. إذا الاسم صحيح، سيتم تسجيله للمراجعة.", learn_query=q, learn_reason="candidate_safety_rejected", diagnostics={"engine":"excel_native", "stage":"candidate_safety_filter", "rejected": safety.rejected})
        # Apply requested form and measures as hard filters when present.
        if qform:
            form_filtered = [ip for ip in cands if _form_match(qform, ip.form, ip.identity_text)]
            if form_filtered:
                cands = form_filtered
            else:
                # Form is a hard identity field.  syrup != tablet, cleanser != serum, etc.
                if len(cands) > 1:
                    return self._result("ASK_CLARIFICATION", self._ask_message(cands, "وجدت نفس العائلة لكن لم أجد نفس الشكل المطلوب بوضوح. اختر المنتج الصحيح إن كان موجودًا."), products=cands, diagnostics={"engine":"excel_native", "stage":"requested_form_mismatch", "requested_form": qform})
                return self._result("NOT_AVAILABLE", "لم أجد نفس الشكل المطلوب في قائمة الصيدلية حاليًا.", learn_query=q, learn_reason="requested_form_not_found", diagnostics={"requested_form": qform})
        if qmeasures:
            measure_filtered = [ip for ip in cands if qmeasures <= ip.measures or any(m in ip.identity_compact for m in qmeasures)]
            if measure_filtered:
                cands = measure_filtered
            else:
                # Strength/size/pack are hard identity fields.  Never sell the
                # closest product when the requested measure differs or is absent.
                if len(cands) > 1:
                    return self._result("ASK_CLARIFICATION", self._ask_message(cands, "وجدت نفس العائلة لكن لم أجد نفس التركيز/الحجم المطلوب بوضوح. اختر المنتج الصحيح إن كان موجودًا."), products=cands, diagnostics={"engine":"excel_native", "stage":"requested_measure_mismatch", "requested_measures": sorted(qmeasures)})
                return self._result("NOT_AVAILABLE", "لم أجد نفس التركيز أو الحجم المطلوب في قائمة الصيدلية حاليًا.", learn_query=q, learn_reason="requested_measure_not_found", diagnostics={"requested_measures": sorted(qmeasures)})
        dup = self._duplicate_guard(cands, qn)
        if dup:
            return dup
        generic = self._generic_variant_guard(qn, qform, qmeasures, cands)
        if generic:
            return generic
        if len(cands) == 1:
            ip = cands[0]
            # If the match is weak (only one weak/generic token), refuse.
            qs = set(_strong_tokens(qn))
            if not qs and not qmeasures and not qform:
                return self._result("LOW_CONFIDENCE", "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل أو أرسل صورة أوضح.", learn_query=q, learn_reason="weak_single_candidate")
            return self._result("EXACT_MATCH", product=ip, products=[ip], diagnostics={"engine": "excel_native", "stage": reason or "exact"})
        # If all candidates are same identity and same price, choose one. Otherwise clarify.
        identity_keys = {ip.identity_key for ip in cands}
        prices = {safe_price(ip.product.get("price")) for ip in cands if safe_price(ip.product.get("price"))}
        if len(identity_keys) == 1 and len(prices) == 1:
            return self._result("EXACT_MATCH", product=cands[0], products=[cands[0]], diagnostics={"engine":"excel_native", "stage":"same_identity_same_price"})
        return self._result("ASK_CLARIFICATION", self._ask_message(cands, "وجدت أكثر من منتج قريب. اختر المنتج المطلوب قبل عرض السعر."), products=cands, diagnostics={"engine":"excel_native", "stage":"multiple_candidates", "query": qn})

    def match_text(self, query: str) -> SearchResult:
        self._load()
        raw = str(query or "").strip()
        qn = clean_query(raw)
        qn = _n(qn)
        if not qn:
            return self._result("LOW_CONFIDENCE", "اكتب اسم المنتج أو أرسل صورة واضحة.", learn_query=raw, learn_reason="empty_query")
        # barcode exact.
        if re.fullmatch(r"\d{8,14}", qn):
            return self._finalize_candidates(raw, self.by_exact.get(qn, []), "barcode_exact")
        qcompact = _compact(qn)
        exact = []
        exact.extend(self.by_exact.get(qn, []))
        if qcompact != qn:
            exact.extend(self.by_exact.get(qcompact, []))
        exact = self._dedupe(exact, 50)
        if exact:
            return self._finalize_candidates(raw, exact, "exact_key")
        strong = _strong_tokens(qn)
        qform = canonical_form(qn)
        qmeasures = _measures(qn)
        if not strong and qmeasures:
            return self._result("LOW_CONFIDENCE", "لم أتمكن من تحديد المنتج من الحجم أو التركيز فقط. اكتب اسم المنتج كاملًا.", learn_query=raw, learn_reason="measure_only")
        if not strong and (qform or not qmeasures):
            return self._result("ASK_CLARIFICATION", "اكتب اسم المنتج مع النوع أو الشكل. لا أستطيع البحث بكلمة عامة فقط.", learn_query=raw, learn_reason="generic_or_type_only")
        # Brand/family scoped candidate search.  No full catalog substring fallback.
        scoped = self._variant_scope(qn, strong)
        if strong and len(strong) == 1 and len(scoped) > 1 and not qform and not qmeasures:
            return self._result("ASK_CLARIFICATION", self._ask_message(scoped, "يوجد أكثر من منتج بهذا الاسم. اختر المطلوب."), products=scoped, diagnostics={"engine":"excel_native", "stage":"single_token_scope"})
        if not scoped:
            # If first token is not a known brand/family, safe token scan using full tokens only.
            token_hits: List[IndexedProduct] = []
            for ip in self.products:
                if strong and set(strong).issubset(ip.token_set):
                    token_hits.append(ip)
            scoped = self._dedupe(token_hits, 50)
        else:
            # Within safe scope, require all strong tokens where possible.
            narrowed = [ip for ip in scoped if set(strong).issubset(ip.token_set) or _phrase_in(qn, ip.identity_text) or qcompact in ip.identity_compact]
            if narrowed:
                scoped = narrowed
        if not scoped:
            return self._result("NOT_AVAILABLE", "لم أجد المنتج في قائمة الصيدلية حاليًا. إذا الاسم صحيح، سيتم تسجيله للمراجعة.", learn_query=raw, learn_reason="no_safe_scoped_candidate")
        return self._finalize_candidates(raw, scoped, "scoped_token_match")

    def _vision_query(self, slots: Dict[str, Any]) -> Tuple[str, str]:
        # Image matching must use only validated foreground/title evidence.
        # Background and raw all-OCR text are deliberately excluded here.
        visible_candidates = [
            str(slots.get("foreground_product_text") or ""),
            str(slots.get("primary_title") or ""),
            str(slots.get("visible_text") or ""),
            str(slots.get("main_visible_product") or ""),
            str(slots.get("product_name") or ""),
            str(slots.get("product_family") or ""),
            str(slots.get("brand") or ""),
        ]
        visible = " ".join(x for x in visible_candidates if x.strip()).strip()
        n = _n(visible)
        c = _compact(visible)
        # Partial Remedica package without actual product name must not become NOT_AVAILABLE or random exact.
        vtokens = set(_word_tokens(n))
        for pattern in IMAGE_LOW_CONFIDENCE_PATTERNS:
            if pattern <= vtokens:
                return "", "low_confidence_partial_package"
        for key, target in KNOWN_VISION_ALIASES.items():
            if _compact(key) in c or key in n:
                # Preserve measures to resolve variants.
                measures = extract_strengths(visible) + extract_sizes(visible) + extract_packs(visible)
                form = canonical_form(visible)
                return " ".join([target, form or ""] + measures).strip(), "known_vision_identity"

        product_bits = []
        for k in ["main_visible_product", "product_name", "product_family", "form", "strength", "size", "pack"]:
            val = str(slots.get(k) or "").strip()
            if val:
                product_bits.append(val)
        brand = str(slots.get("brand") or "").strip()
        brand_norm = _n(brand)
        structured_parts = ([brand] if brand else []) + product_bits
        structured = " ".join(structured_parts).strip()

        # If structured output is brand-only, or the brand is actually a generic
        # package word, use the validated foreground phrase first.
        has_identity_slot = any(str(slots.get(k) or "").strip() for k in ["main_visible_product", "product_name", "product_family"])
        brand_only = bool(brand) and not product_bits and not has_identity_slot
        fake_brand_only = bool(brand_norm and brand_norm in VISION_NON_BRAND_TOKENS and not has_identity_slot)
        q = structured
        reason = "structured_vision_slots"
        if (brand_only or fake_brand_only or not _strong_tokens(structured)) and visible.strip():
            q = visible.strip()
            reason = "full_ocr_phrase_fallback"

        if q and not _strong_tokens(q):
            return "", "vision_weak_tokens_only"
        if q and _measures(q) and not _strong_tokens(q):
            return "", "vision_measure_only"
        return q, reason

    def _clean_vision_ocr_tokens(self, text: str) -> List[str]:
        """Return stable OCR identity tokens for image candidate generation.

        Raw OCR often contains marketing/background words and cut fragments.
        The matcher is intentionally strict, so this helper only prepares
        generic candidate text from validated foreground evidence.  Product-
        specific OCR corrections must come from catalog/learning data.
        """
        n = _n(text)
        if not n:
            return []
        raw_tokens = _word_tokens(n)
        ctx = set(raw_tokens)
        out: List[str] = []
        for token in raw_tokens:
            fixed = token
            if token in VISION_OCR_FRAGMENT_FIXES:
                replacement = VISION_OCR_FRAGMENT_FIXES[token]
                if replacement in ctx or replacement in n:
                    fixed = replacement
            if fixed in VISION_OCR_NOISE_TOKENS:
                continue
            if len(fixed) <= 1:
                continue
            if fixed not in out:
                out.append(fixed)
        return out

    def _append_candidate(self, candidates: List[Tuple[str, str]], query: str, reason: str) -> None:
        query = _n(query)
        if not query:
            return
        # Keep candidate strings usable.  Very long OCR text is reintroduced as
        # n-grams/brand candidates instead of one huge query.
        if len(query.split()) > 8 and reason not in {"structured_vision_slots", "known_vision_identity", "full_ocr_phrase_fallback"}:
            return
        key = _compact(query)
        if not key:
            return
        if any(_compact(q) == key for q, _r in candidates):
            return
        candidates.append((query, reason))

    def _vision_candidate_queries(self, slots: Dict[str, Any], base_query: str = "", base_reason: str = "") -> List[Tuple[str, str]]:
        """Build ordered candidate queries from structured vision slots + OCR.

        Images should not be matched by raw all-OCR text.  Candidate queries are
        generated only from validated foreground/title evidence and catalog
        aliases; product-specific fixes are not hardcoded here.
        """
        candidates: List[Tuple[str, str]] = []
        if base_query:
            self._append_candidate(candidates, base_query, base_reason or "base_vision_query")

        # Structured fields first when they contain real identity.
        brand = str(slots.get("brand") or "").strip()
        main = str(slots.get("main_visible_product") or "").strip()
        product_name = str(slots.get("product_name") or "").strip()
        family = str(slots.get("product_family") or "").strip()
        form = str(slots.get("form") or slots.get("product_type") or "").strip()
        measures = []
        for k in ["strength", "size", "pack"]:
            v = str(slots.get(k) or "").strip()
            if v:
                measures.append(v)
        identity_suffix = [form] + measures
        structured_candidates: List[Tuple[str, str]] = []
        # If Vision extracted hard identity fields (form/strength/size/pack),
        # do not test a bare title first.  A bare title can incorrectly bypass
        # the hard mismatch guard; include those fields in every title candidate.
        if main:
            structured_candidates.append((" ".join([main] + identity_suffix).strip(), "main_visible_product"))
        if product_name:
            structured_candidates.append((" ".join([product_name] + identity_suffix).strip(), "product_name"))
        # Never add a brand-only image candidate. Brand-only exact matches can
        # hide the useful foreground phrase and pick/clarify the wrong family.
        if brand and product_name:
            structured_candidates.append((" ".join([brand, product_name] + measures).strip(), "brand_product_name"))
        if brand and (family or form or measures):
            structured_candidates.append((" ".join([brand, family, form] + measures).strip(), "brand_family_form"))
        if family and brand:
            structured_candidates.append((" ".join([family, brand] + measures).strip(), "family_brand"))
        for q, reason in structured_candidates:
            self._append_candidate(candidates, q, reason)

        # Vision Evidence Validator already separated foreground from
        # background/ingredients.  Candidate generation must use foreground and
        # primary-title evidence only, never background text or raw all-OCR text.
        visible = " ".join(str(slots.get(k) or "") for k in ["foreground_product_text", "primary_title", "visible_text", "main_visible_product", "product_name", "product_family"] if slots.get(k)).strip()
        visible_norm = _n(visible)
        compact_visible = _compact(visible)

        tokens = self._clean_vision_ocr_tokens(visible)
        if tokens:
            cleaned = " ".join(tokens)
            self._append_candidate(candidates, cleaned, "cleaned_ocr")

            # Brand + nearby/important token candidates.  This is deliberately
            # scoped to known catalog brands to avoid global fuzzy matching.
            token_set = set(tokens)
            known_brands = [b for b in self.brand_names if len(b) > 2 and b not in VISION_OCR_NOISE_TOKENS and (b in token_set or _compact(b) in compact_visible)]
            for b in known_brands[:6]:
                important = [t for t in tokens if t != b and (t not in VISION_OCR_NOISE_TOKENS)]
                # Prefer stable product-family words from the current catalog.
                for width in [3, 2, 1]:
                    if len(important) >= width:
                        self._append_candidate(candidates, " ".join([b] + important[:width]), f"ocr_brand_plus_{width}")
                for t in important[:5]:
                    self._append_candidate(candidates, f"{b} {t}", "ocr_brand_token")
                    self._append_candidate(candidates, f"{t} {b}", "ocr_token_brand")

            # Sliding n-grams catch clean chunks even when OCR starts with a cut
            # fragment.  Longest chunks first.
            max_len = min(5, len(tokens))
            for width in range(max_len, 1, -1):
                for i in range(0, len(tokens) - width + 1):
                    gram = tokens[i:i + width]
                    if not gram:
                        continue
                    # Skip pure generic/form chunks unless they are exact phrase
                    # cases handled above.
                    if not any(t in self.brand_names for t in gram):
                        continue
                    self._append_candidate(candidates, " ".join(gram), f"ocr_ngram_{width}")

        return candidates[:40]

    def _vision_result_score(self, result: SearchResult) -> int:
        if result.status == "EXACT_MATCH" and result.product:
            return 100
        if result.status == "COSMETIC_ALTERNATIVES" and result.products:
            # Prefer more focused candidate lists over broad brand-only lists.
            return 70 - min(len(result.products), 30)
        if result.status == "ASK_CLARIFICATION" and result.products:
            return 60 - min(len(result.products), 30)
        if result.status == "LOW_CONFIDENCE":
            return 20
        return 0

    def match_vision_slots(self, slots: Dict[str, Any]) -> SearchResult:
        self._load()
        slots = slots or {}
        visible = str(slots.get("visible_text") or slots.get("raw_vision_text") or slots.get("main_visible_product") or "")
        # Self-learning visual memory is checked before normal OCR candidates.
        # It can only return a candidate for confirmation; app.py still blocks
        # direct price display until the user confirms.
        try:
            from services.vision import visual_memory
            memory = visual_memory.lookup_visual_memory(slots, merchant_id=1)
            if memory and memory.get("product_id"):
                ip = self._ip_by_product_id(memory.get("product_id"))
                if ip:
                    enriched = dict(ip.product)
                    for field in ["brand", "form", "strength", "size"]:
                        if memory.get(field):
                            enriched[field] = memory.get(field)
                    if memory.get("canonical_name"):
                        enriched["canonical_display_name"] = memory.get("canonical_name")
                    if visual_memory.strict_image_candidate_validator(slots, enriched):
                        ip.product.update(enriched)
                        return self._result(
                            "EXACT_MATCH",
                            product=ip,
                            products=[ip],
                            diagnostics={"engine": "excel_native", "stage": "visual_product_memory_hit", "image_signature": memory.get("image_signature")},
                        )
            master_products = []
            try:
                from services.catalog import master_identity
                master_products = master_identity.search_by_vision_slots(slots, merchant_id=1, limit=5)
            except Exception:
                master_products = []
            master_ips = [self._ip_by_product_id(p.get("id")) for p in master_products]
            master_ips = [ip for ip in master_ips if ip is not None]
            if len(master_ips) == 1:
                master_product = master_products[0] if master_products else master_ips[0].product
                if visual_memory.strict_image_candidate_validator(slots, master_product):
                    master_ips[0].product.update({k: v for k, v in master_product.items() if v not in (None, "")})
                    return self._result(
                        "EXACT_MATCH",
                        product=master_ips[0],
                        products=[master_ips[0]],
                        diagnostics={"engine": "excel_native", "stage": "products_master_identity_exact"},
                    )
                master_ips = []
            if len(master_ips) > 1:
                return self._result(
                    "LOW_CONFIDENCE",
                    "لم أتعرف على المنتج بدقة من الصورة. اكتب اسمه كاملًا من فضلك.",
                    learn_query=str(slots.get("query") or visible),
                    learn_reason="products_master_identity_ambiguous",
                    vision_text=visible,
                    diagnostics={"engine": "excel_native", "stage": "products_master_identity_ambiguous", "slots": slots},
                )
            overlay_products = visual_memory.find_overlay_products(slots, merchant_id=1, limit=5)
            overlay_ips = [self._ip_by_product_id(p.get("id")) for p in overlay_products]
            overlay_ips = [ip for ip in overlay_ips if ip is not None]
            if len(overlay_ips) == 1:
                overlay_product = overlay_products[0] if overlay_products else overlay_ips[0].product
                if visual_memory.strict_image_candidate_validator(slots, overlay_product):
                    overlay_ips[0].product.update({k: v for k, v in overlay_product.items() if v not in (None, "")})
                    return self._result(
                        "EXACT_MATCH",
                        product=overlay_ips[0],
                        products=[overlay_ips[0]],
                        diagnostics={"engine": "excel_native", "stage": "product_identity_overlay_exact"},
                    )
                overlay_ips = []
            if len(overlay_ips) > 1:
                return self._result(
                    "LOW_CONFIDENCE",
                    "لم أتعرف على المنتج بدقة من الصورة. اكتب اسمه كاملًا من فضلك.",
                    learn_query=str(slots.get("query") or visible),
                    learn_reason="product_identity_overlay_ambiguous",
                    vision_text=visible,
                    diagnostics={"engine": "excel_native", "stage": "product_identity_overlay_ambiguous", "slots": slots},
                )
        except Exception:
            pass
        try:
            conf = float(slots.get("confidence") or 1.0)
        except Exception:
            conf = 1.0
        query, reason = self._vision_query(slots)
        if conf < 0.60:
            return self._result("LOW_CONFIDENCE", "الصورة غير كافية لتحديد المنتج. أرسل صورة أوضح للواجهة الأمامية.", learn_query=query, learn_reason=reason or "vision_low_confidence", vision_text=visible, diagnostics={"engine":"excel_native", "stage": reason, "slots": slots})

        candidates = self._vision_candidate_queries(slots, query, reason)
        if not candidates:
            return self._result("LOW_CONFIDENCE", "الصورة غير كافية لتحديد المنتج. أرسل صورة أوضح للواجهة الأمامية.", learn_query=query, learn_reason=reason or "vision_no_candidates", vision_text=visible, diagnostics={"engine":"excel_native", "stage": reason, "slots": slots})

        best: Optional[SearchResult] = None
        best_query = ""
        best_reason = ""
        attempted: List[Dict[str, str]] = []
        for candidate_query, candidate_reason in candidates:
            result = self.match_text(candidate_query)
            attempted.append({"query": candidate_query, "reason": candidate_reason, "decision": result.status})
            if result.status == "EXACT_MATCH" and result.product:
                try:
                    from services.vision import visual_memory
                    validation = visual_memory.validate_image_candidate(slots, result.product)
                    if not validation.get("ok"):
                        attempted[-1]["strict_reject"] = str(validation.get("reason") or "strict_reject")
                        continue
                except Exception as exc:
                    attempted[-1]["strict_reject"] = "strict_validator_exception"
                    continue
                if result.diagnostics is None:
                    result.diagnostics = {}
                result.diagnostics.update({
                    "vision_query": candidate_query,
                    "vision_stage": candidate_reason,
                    "vision_candidates": attempted[:20],
                    "strict_image_candidate_validator": "passed",
                })
                return result
            if best is None or self._vision_result_score(result) > self._vision_result_score(best):
                best = result
                best_query = candidate_query
                best_reason = candidate_reason

        if best is None:
            return self._result("LOW_CONFIDENCE", "لم أتمكن من قراءة اسم المنتج بوضوح من الصورة. اكتب الاسم كاملًا أو أرسل صورة أوضح.", learn_query=query, learn_reason="vision_no_match_attempted", vision_text=visible, diagnostics={"engine":"excel_native", "stage":"vision_no_match_attempted", "slots": slots, "vision_candidates": attempted[:20]})

        # If a candidate produced clarification/list, return it instead of a false
        # NOT_AVAILABLE. This is important for variant-heavy families where OCR
        # may omit pack/country/size.
        if best.status in {"ASK_CLARIFICATION", "COSMETIC_ALTERNATIVES"}:
            try:
                from services.vision import visual_memory
                safe_products = [p for p in (best.products or []) if visual_memory.strict_image_candidate_validator(slots, p)]
            except Exception:
                safe_products = []
            if len(safe_products) == 1:
                ip = self._ip_by_product_id(safe_products[0].get("id"))
                if ip:
                    return self._result(
                        "EXACT_MATCH",
                        product=ip,
                        products=[ip],
                        diagnostics={"engine": "excel_native", "stage": "strict_image_candidate_single_after_filter", "vision_query": best_query, "vision_stage": best_reason, "vision_candidates": attempted[:20]},
                    )
            if len(safe_products) > 1:
                best.products = safe_products[:4]
                if best.diagnostics is None:
                    best.diagnostics = {}
                best.diagnostics.update({
                    "vision_query": best_query,
                    "vision_stage": best_reason,
                    "vision_candidates": attempted[:20],
                    "strict_image_candidate_validator": "filtered",
                })
                return best
            return self._result(
                "LOW_CONFIDENCE",
                "لم أتعرف على المنتج بدقة من الصورة. اكتب اسمه كاملًا من فضلك.",
                learn_query=best_query or query,
                learn_reason="strict_image_candidate_filter_removed_all",
                vision_text=visible,
                diagnostics={"engine": "excel_native", "stage": "strict_image_candidate_filter_removed_all", "slots": slots, "vision_candidates": attempted[:20]},
            )

        # For image-specific failures, persist raw visible text to learning inbox.
        self._record_learning(query=best_query or query, decision=best.status, reason="vision_candidates_failed", vision_text=visible, slots={**slots, "candidate_queries": attempted[:20]})
        if best.diagnostics is None:
            best.diagnostics = {}
        best.diagnostics.update({
            "vision_query": best_query or query,
            "vision_stage": best_reason or reason,
            "vision_candidates": attempted[:20],
        })
        return best


ENGINE = ExcelNativeMatcher()


def invalidate_memory_index() -> None:
    ENGINE.invalidate()


def preload_search_index() -> int:
    return ENGINE.preload()


def match_text(query: str) -> SearchResult:
    return ENGINE.match_text(query)


def match_vision_slots(slots: Dict[str, Any]) -> SearchResult:
    return ENGINE.match_vision_slots(slots)
