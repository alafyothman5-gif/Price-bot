# Deploy Safety Report

Target path: `/opt/pricebot_clean`

Health check: `http://127.0.0.1:8090/health`

The ZIP does not include:

- `.env`
- `pricebot.db`
- `venv`
- `__pycache__`
- `.pyc`
- backups
- uploads
- secrets

Database safety:

- New/updated tables are created with `CREATE TABLE IF NOT EXISTS` and `ALTER TABLE ... ADD COLUMN` only when missing.
- No migration deletes products.
- No migration truncates `products`.
- `products.name` and the merchant Excel remain unchanged.
- Master identity is a derived layer only.

New safety corrections:

- `identity_review_queue` now has `review_priority` and `review_action`.
- `products_master_identity` now has `review_priority`, `review_action`, and `duplicate_group_key`.
- `identity_duplicate_groups` groups duplicates so the admin is not flooded by duplicate rows.
- `MISSING_FORM_STRENGTH_SIZE` is not treated as manual review for cosmetics/devices.
- Visual-training upload/extract no longer requires `product_id`; link/approve requires product selection.

Required server-side run after deploy:

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/build_master_identity_catalog.py --output-dir identity_reports
sudo systemctl restart pricebot
curl -fsS http://127.0.0.1:8090/health
```

Expected deploy script success marker remains:

```text
DEPLOY_OK=1
```
