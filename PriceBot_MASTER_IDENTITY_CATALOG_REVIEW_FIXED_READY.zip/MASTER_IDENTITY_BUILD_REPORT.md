# Master Identity Build Report — Review Flood Fix

Status: sandbox code-level acceptance completed.

Important note: the real server database `/opt/pricebot_clean/pricebot.db` with `products_count=5791` is not included in this ZIP, by design. The report spreadsheets included in the ZIP are seed/placeholders. Generate the real reports on the server after deploy:

```bash
cd /opt/pricebot_clean
./venv/bin/python tools/build_master_identity_catalog.py --output-dir identity_reports
```

Fixes applied in this revision:

- `MISSING_FORM_STRENGTH_SIZE` no longer sends every cosmetic/device/non-variant item to manual review.
- Added `review_priority`: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW`.
- Added `review_action`: `MANUAL_REQUIRED`, `DUPLICATE_GROUP`, `QUALITY_REPORT_ONLY`, `AUTO_APPROVED`, `ADMIN_APPROVED`.
- Added `TOP_PRODUCTS_TO_REVIEW_FIRST.xlsx` output so admin starts with high-risk items instead of thousands of low-value rows.
- Duplicate identities are now grouped through `identity_duplicate_groups` and displayed/reported as groups.
- `/admin/identity` sorts by priority and supports top-review mode.
- `/admin/visual-training` upload/extract is now separate from approve/link, so `product_id` is not required during image upload.
- `/admin/visual-training/approve` validates `product_id` only at link/approval time and redirects instead of returning a JSON validation error for blank values.

Safety behavior:

- The builder does not edit `products.name`, prices, availability, or Excel files.
- Prices remain sourced from `products` / weekly Excel approval only.
- Images still require user confirmation before price/availability.
- Weak/incomplete identities such as `low ph cleanser` remain manual review when brand is missing.
- Quality-only metadata gaps stay in reports, not manual workload.

Sandbox tests:

```bash
python -m compileall . -q
PYTHONPATH=. pytest -q tests/test_production_safe_image_policy.py tests/test_self_learning_visual_overlay.py tests/test_open_data_alias_builder.py tests/test_catalog_ingestion_safe_exact.py tests/test_catalog_ingestion_v2_acceptance.py tests/test_master_identity_catalog.py
```

Result: `26 passed, 4 warnings`.
