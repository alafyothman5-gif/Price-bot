# Master Identity Catalog Diff Summary

Files added:

- `services/catalog/master_identity.py`
- `tools/build_master_identity_catalog.py`
- `templates/admin_identity_review.html`
- `templates/admin_visual_training.html`
- `tests/test_master_identity_catalog.py`
- `MASTER_IDENTITY_BUILD_REPORT.md`
- `VISION_IDENTITY_MATCHING_TESTS.txt`
- report seed spreadsheets: `identity_auto_approved.xlsx`, `identity_needs_review.xlsx`, `duplicate_identity_report.xlsx`, `missing_brand_report.xlsx`, `missing_form_strength_size_report.xlsx`, `weak_names_report.xlsx`, `alias_overlay_seed.xlsx`, `ocr_keywords_seed.xlsx`

Files modified:

- `database.py`: added `products_master_identity`, `identity_review_queue`, `ocr_keywords` schema with CREATE TABLE IF NOT EXISTS.
- `catalog_ingestion/db.py`: calls master identity schema creation after ingestion schema.
- `services/matching/excel_native_matcher.py`: enriches product rows from Master Identity and checks Master Identity before raw OCR fallback.
- `app.py`: ensures Master Identity schema at startup.
- `admin.py`: adds `/admin/identity` and `/admin/visual-training` routes.
- `README_DEPLOY.md`: added Master Identity deployment/run instructions.
- `deploy_pricebot_clean.sh`: compile check includes Master Identity files.

Unchanged safety constraints:

- No `.env` in ZIP.
- No `pricebot.db` in ZIP.
- No `venv`, `__pycache__`, `.pyc`, backups, uploads.
- No price from image before confirmation.
- No product row delete/truncate.
- No MedMCQ paths touched.
