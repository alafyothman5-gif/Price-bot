#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/pricebot_clean"
BACKUP_DIR="$(ls -dt "$APP_DIR"/backups/badr-brand-ui-* 2>/dev/null | head -n 1 || true)"
if [ -z "$BACKUP_DIR" ]; then echo "No backup found"; exit 1; fi
cp -a "$BACKUP_DIR/catalog_web.py" "$APP_DIR/catalog_web.py" 2>/dev/null || true
cp -a "$BACKUP_DIR/app.py" "$APP_DIR/app.py" 2>/dev/null || true
cp -a "$BACKUP_DIR/static/badr_logo.png" "$APP_DIR/static/badr_logo.png" 2>/dev/null || true
sudo systemctl restart pricebot.service
sleep 5
curl -s http://127.0.0.1:8090/catalog-health || true
echo "Rolled back from $BACKUP_DIR"
