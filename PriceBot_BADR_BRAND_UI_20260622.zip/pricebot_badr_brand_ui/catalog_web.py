from __future__ import annotations

import html
import os
import re
import sqlite3
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote, urlencode

from fastapi import APIRouter, Query
from fastapi.responses import HTMLResponse, RedirectResponse, PlainTextResponse, FileResponse, JSONResponse

import database

router = APIRouter()

PAGE_SIZE = int(os.getenv("PRICEBOT_CATALOG_PAGE_SIZE", "24") or 24)
MAX_SEARCH_ROWS = int(os.getenv("PRICEBOT_CATALOG_MAX_SEARCH_ROWS", "500") or 500)
BRAND_ASSET_VERSION = "badr-ui-1"
BRAND_LOGO_FILE = Path(__file__).resolve().parent / "static" / "badr_logo.png"

TEXT_COLUMNS = [
    "name", "canonical_display_name", "normalized_name", "normalized_name_catalog", "original_name",
    "product_id", "brand", "company", "product_family", "aliases", "ocr_keywords", "active_ingredient",
    "form", "strength", "size", "pack", "barcode", "stable_product_code", "category", "main_section",
    "sub_section", "sub_category",
]

IMAGE_COLUMNS = [
    "catalog_image_url", "image_url", "photo_url", "product_image", "main_image", "image_path", "photo_path", "picture",
]


def _h(value: object) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def _db_file() -> Path:
    raw = (
        os.getenv("PRICEBOT_DB_FILE")
        or os.getenv("PRICEBOT_DB_PATH")
        or str(getattr(database, "DB_FILE", "") or "")
        or "/opt/pricebot_clean/pricebot.db"
    )
    return Path(raw).expanduser().resolve()


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{_db_file()}?mode=ro", uri=True, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    return conn


def _ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _columns(conn: sqlite3.Connection) -> set[str]:
    try:
        return {str(r["name"]) for r in conn.execute("PRAGMA table_info(products)").fetchall()}
    except Exception:
        return set()


def _first_existing(cols: set[str], candidates: Iterable[str]) -> Optional[str]:
    for col in candidates:
        if col in cols:
            return col
    return None


def _coalesce(cols: set[str], candidates: Iterable[str], fallback: str = "") -> str:
    parts = [f"NULLIF(TRIM(CAST({_ident(c)} AS TEXT)), '')" for c in candidates if c in cols]
    if fallback:
        parts.append("?")
    elif parts:
        parts.append("''")
    else:
        return "''"
    return parts[0] if len(parts) == 1 else "COALESCE(" + ", ".join(parts) + ")"


def _available_condition(cols: set[str]) -> str:
    checks: List[str] = []
    if "is_available" in cols:
        checks.append("LOWER(CAST(COALESCE(NULLIF(TRIM(CAST(\"is_available\" AS TEXT)), ''), '0') AS TEXT)) IN ('1','true','yes','available','on')")
    if "available" in cols:
        checks.append("LOWER(CAST(COALESCE(NULLIF(TRIM(CAST(\"available\" AS TEXT)), ''), '0') AS TEXT)) IN ('1','true','yes','available','on')")
    return "(" + " OR ".join(checks) + ")" if checks else "1=1"


def _select_sql(cols: set[str]) -> Tuple[str, List[object]]:
    params: List[object] = []

    def cp(candidates: Iterable[str], fallback: str) -> str:
        expr = _coalesce(cols, candidates, fallback)
        if fallback:
            params.append(fallback)
        return expr

    name_expr = cp(["canonical_display_name", "name", "original_name", "product_id"], "Product")
    category_expr = cp(["category", "main_section", "section", "sub_section"], "")
    brand_expr = cp(["brand", "company", "product_family"], "")
    image_expr = cp(IMAGE_COLUMNS, "")
    price_expr = _ident("price") if "price" in cols else "NULL"
    currency_expr = _ident("currency") if "currency" in cols else "'LYD'"
    available_expr = _ident("is_available") if "is_available" in cols else (_ident("available") if "available" in cols else "1")
    return f"""
        id,
        {name_expr} AS display_name,
        {category_expr} AS category,
        {brand_expr} AS brand,
        {image_expr} AS image_url,
        {price_expr} AS price,
        {currency_expr} AS currency,
        {available_expr} AS available_value
    """, params


def _format_price(price: object, currency: object) -> str:
    if price is None or str(price).strip() == "":
        return "السعر غير متوفر"
    cur = str(currency or os.getenv("PRICEBOT_DEFAULT_CURRENCY", "LYD") or "LYD").strip()
    raw = str(price).replace(",", "").strip()
    try:
        value = float(raw)
        shown = str(int(value)) if value.is_integer() else f"{value:.2f}".rstrip("0").rstrip(".")
        return f"{shown} {cur}"
    except Exception:
        return f"{raw} {cur}".strip()


def _tokens(query: str) -> List[str]:
    query = (query or "").strip().lower()
    return [t for t in re.findall(r"[\w\u0600-\u06FF%+.-]+", query) if len(t) >= 2][:10]


def _score(row: Dict[str, object], tokens: List[str]) -> int:
    name = str(row.get("display_name") or "").lower()
    brand = str(row.get("brand") or "").lower()
    category = str(row.get("category") or "").lower()
    hay = " ".join(str(v or "") for v in row.values()).lower()
    score = 0
    for token in tokens:
        if token in name:
            score += 8
        if token in brand:
            score += 5
        if token in category:
            score += 2
        if token in hay:
            score += 1
    score += sum(1 for token in tokens if token in hay) * 4
    return score


def _merchant_settings() -> Dict[str, object]:
    try:
        return database.get_merchant_settings()
    except Exception:
        return {
            "name": os.getenv("PHARMACY_NAME", "صيدلية بدر"),
            "pharmacy_name": os.getenv("PHARMACY_NAME", "صيدلية بدر"),
            "whatsapp_number": os.getenv("BOT_WHATSAPP_NUMBER", ""),
        }


def _pharmacy_name() -> str:
    settings = _merchant_settings()
    return str(settings.get("pharmacy_name") or settings.get("name") or os.getenv("PHARMACY_NAME", "صيدلية بدر"))


def _whatsapp_number() -> str:
    settings = _merchant_settings()
    raw = str(
        settings.get("whatsapp_number")
        or os.getenv("WHATSAPP_PUBLIC_NUMBER")
        or os.getenv("BOT_WHATSAPP_NUMBER")
        or os.getenv("ADMIN_NOTIFY_PHONE")
        or ""
    )
    return re.sub(r"\D+", "", raw)


def _whatsapp_link(message: str) -> str:
    number = _whatsapp_number()
    if number:
        return f"https://wa.me/{number}?text={quote(message)}"
    return f"https://wa.me/?text={quote(message)}"


def _public_base_url() -> str:
    raw = os.getenv("PUBLIC_BASE_URL") or os.getenv("PRICEBOT_PUBLIC_BASE_URL") or os.getenv("APP_PUBLIC_URL") or "https://46.101.148.246.sslip.io"
    return str(raw).rstrip("/")


def _product_url(product_id: object) -> str:
    return f"{_public_base_url()}/product/{product_id}"


def _order_message(product: Dict[str, object]) -> str:
    product_id = product.get("id")
    name = str(product.get("display_name") or "Product").strip()
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    parts = [
        "السلام عليكم، أريد طلب هذا المنتج من صيدلية بدر:",
        f"المنتج: {name}",
        f"السعر الظاهر: {price}",
        f"رقم المنتج: {product_id}",
    ]
    if brand:
        parts.append(f"البراند: {brand}")
    if category:
        parts.append(f"القسم: {_display_category_label(category)}")
    parts.extend([f"رابط المنتج: {_product_url(product_id)}", "يرجى تأكيد التوفر والسعر النهائي."])
    return "\n".join(parts)


def _image_src(value: object) -> str:
    src = str(value or "").strip()
    if not src:
        return ""
    if src.startswith(("http://", "https://", "data:")):
        return src
    if src.startswith("/"):
        return src
    return "/static/" + src.lstrip("/")


def _display_category_label(name: str) -> str:
    raw = (name or "").strip()
    n = raw.lower()
    mapping = {
        "medicine": "أدوية", "medicines": "أدوية", "drug": "أدوية", "drugs": "أدوية",
        "cosmetic": "عناية بالبشرة", "cosmetics": "عناية بالبشرة", "skin": "عناية بالبشرة", "skincare": "عناية بالبشرة",
        "supplement": "مكملات", "supplements": "مكملات", "vitamin": "مكملات", "vitamins": "مكملات",
        "device": "أجهزة", "devices": "أجهزة", "other": "أخرى",
    }
    return mapping.get(n, raw or "قسم")


def _category_icon(name: str) -> str:
    n = (name or "").lower()
    if any(x in n for x in ["cosmetic", "skin", "beauty", "تجميل", "بشرة"]):
        return "♧"
    if any(x in n for x in ["medicine", "drug", "دواء", "ادوية", "أدوية"]):
        return "＋"
    if any(x in n for x in ["supplement", "vitamin", "فيتامين", "مكمل"]):
        return "▣"
    if any(x in n for x in ["device", "meter", "جهاز", "أجهزة"]):
        return "▤"
    return "▦"


def _categories() -> List[Dict[str, object]]:
    try:
        with _connect() as conn:
            cols = _columns(conn)
            cat_col = _first_existing(cols, ["category", "main_section", "section"])
            if not cat_col:
                return []
            rows = conn.execute(
                f"""
                SELECT {_ident(cat_col)} AS name, COUNT(*) AS count
                FROM products
                WHERE {_available_condition(cols)} AND {_ident(cat_col)} IS NOT NULL AND TRIM(CAST({_ident(cat_col)} AS TEXT)) != ''
                GROUP BY {_ident(cat_col)}
                ORDER BY count DESC, name COLLATE NOCASE
                LIMIT 60
                """
            ).fetchall()
            return [dict(row) for row in rows]
    except Exception:
        return []


def _query_products(q: str = "", category: str = "", page: int = 1) -> Tuple[List[Dict[str, object]], int]:
    q = (q or "").strip()
    category = (category or "").strip()
    page = max(int(page or 1), 1)
    tokens = _tokens(q)
    if q and not tokens:
        return [], 0
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return [], 0
        select_part, select_params = _select_sql(cols)
        where = [_available_condition(cols)]
        where_params: List[object] = []
        cat_col = _first_existing(cols, ["category", "main_section", "section"])
        if category and cat_col:
            where.append(f"CAST({_ident(cat_col)} AS TEXT) = ?")
            where_params.append(category)
        search_cols = [col for col in TEXT_COLUMNS if col in cols]
        if tokens and search_cols:
            parts: List[str] = []
            for token in tokens:
                like = f"%{token}%"
                for col in search_cols:
                    parts.append(f"LOWER(CAST({_ident(col)} AS TEXT)) LIKE ?")
                    where_params.append(like)
            where.append("(" + " OR ".join(parts) + ")")
        where_sql = " AND ".join(f"({w})" for w in where)
        if tokens:
            rows = conn.execute(
                f"SELECT {select_part} FROM products WHERE {where_sql} LIMIT ?",
                list(select_params) + where_params + [MAX_SEARCH_ROWS],
            ).fetchall()
            products = [dict(row) for row in rows]
            products.sort(key=lambda row: (-_score(row, tokens), str(row.get("display_name") or "")))
            total = len(products)
            start = (page - 1) * PAGE_SIZE
            return products[start:start + PAGE_SIZE], total
        total = int(conn.execute(f"SELECT COUNT(*) AS total FROM products WHERE {where_sql}", where_params).fetchone()["total"] or 0)
        rows = conn.execute(
            f"SELECT {select_part} FROM products WHERE {where_sql} ORDER BY id DESC LIMIT ? OFFSET ?",
            list(select_params) + where_params + [PAGE_SIZE, (page - 1) * PAGE_SIZE],
        ).fetchall()
        return [dict(row) for row in rows], total


def _get_product(product_id: int) -> Optional[Dict[str, object]]:
    with _connect() as conn:
        cols = _columns(conn)
        if "id" not in cols:
            return None
        select_part, params = _select_sql(cols)
        row = conn.execute(
            f"SELECT {select_part} FROM products WHERE id=? AND {_available_condition(cols)} LIMIT 1",
            params + [int(product_id)],
        ).fetchone()
        return dict(row) if row else None


def _search_form(q: str = "", category: str = "", compact: bool = False) -> str:
    options = ['<option value="">كل الأقسام</option>']
    for item in _categories():
        name = str(item.get("name") or "")
        selected = " selected" if name == category else ""
        options.append(f'<option value="{_h(name)}"{selected}>{_h(_display_category_label(name))} ({_h(item.get("count"))})</option>')
    cls = "search-panel compact" if compact else "search-panel"
    placeholder = "ابحث عن دواء أو منتج" if compact else "ابحث عن المنتجات... Panadol / CeraVe"
    return f"""
    <section class="{cls}">
      <form class="search" action="/products" method="get">
        <div class="search-input-wrap"><span class="search-icon">⌕</span><input name="q" value="{_h(q)}" placeholder="{_h(placeholder)}" autocomplete="off" dir="auto"></div>
        <select name="category">{''.join(options)}</select>
        <button type="submit">بحث</button>
      </form>
    </section>
    """


def _category_tiles(limit: int = 5) -> str:
    cats = _categories()[:max(limit - 1, 0)]
    tiles = ['<a class="cat-pill" href="/products"><span class="cat-line-icon">▦</span><strong>الكل</strong></a>']
    for item in cats:
        name = str(item.get("name") or "")
        href = "/products?" + urlencode({"category": name})
        tiles.append(f"""
        <a class="cat-pill" href="{_h(href)}"><span class="cat-line-icon">{_h(_category_icon(name))}</span><strong dir="auto">{_h(_display_category_label(name))}</strong></a>
        """)
    return '<section class="category-strip" aria-label="تصنيفات المنتجات">' + ''.join(tiles) + '</section>'


def _category_chips(active: str = "") -> str:
    items = _categories()[:16]
    if not items:
        return ""
    all_cls = "chip active" if not active else "chip"
    chips = [f'<a class="{all_cls}" href="/products">الكل</a>']
    for item in items:
        name = str(item.get("name") or "")
        cls = "chip active" if name == active else "chip"
        href = "/products?" + urlencode({"category": name})
        chips.append(f'<a class="{cls}" href="{_h(href)}" dir="auto">{_h(_display_category_label(name))}</a>')
    return '<div class="chips" aria-label="الأقسام">' + ''.join(chips) + '</div>'


def _product_card(product: Dict[str, object], mode: str = "list") -> str:
    product_id = product.get("id")
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}" loading="lazy">' if img else '<div class="no-img"><span>Rx</span><small>صورة قريباً</small></div>'
    meta_parts = [x for x in [brand, _display_category_label(category) if category else ""] if x]
    meta = " • ".join(meta_parts) if meta_parts else "منتج صيدلية"
    cls = "product-card tile-card" if mode == "tile" else "product-card"
    return f"""
    <article class="{cls}">
      <a class="fav" href="/product/{_h(product_id)}" aria-label="تفاصيل المنتج">♡</a>
      <span class="available-badge">متوفر</span>
      <a class="product-image" href="/product/{_h(product_id)}">{img_html}</a>
      <div class="product-info">
        <a class="product-name" href="/product/{_h(product_id)}" dir="auto">{_h(name)}</a>
        <div class="product-meta" dir="auto">{_h(meta)}</div>
        <div class="product-price">{_h(price)}</div>
        <a class="wa-order" href="/order/{_h(product_id)}" target="_blank" rel="noopener">اطلب عبر واتساب <span>☏</span></a>
      </div>
    </article>
    """


def _page_url(page: int, q: str = "", category: str = "") -> str:
    params = {"page": page}
    if q:
        params["q"] = q
    if category:
        params["category"] = category
    return "/products?" + urlencode(params)


def _products_section(q: str = "", category: str = "", page: int = 1) -> str:
    products, total = _query_products(q=q, category=category, page=page)
    page_count = max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    cards = "".join(_product_card(p) for p in products)
    if not cards:
        cards = '<div class="empty"><strong>لم نجد منتجات مطابقة</strong><br>جرّب كلمة أبسط مثل اسم البراند، أو اختر قسماً مختلفاً.</div>'
    prev_link = f'<a class="btn secondary" href="{_h(_page_url(page - 1, q, category))}">السابق</a>' if page > 1 else ""
    next_link = f'<a class="btn secondary" href="{_h(_page_url(page + 1, q, category))}">التالي</a>' if page < page_count else ""
    title = f'نتائج البحث عن: <span dir="auto">{_h(q)}</span>' if q else "كل المنتجات المتوفرة"
    return f"""
    {_search_form(q=q, category=category)}
    {_category_chips(category)}
    <div class="section-head"><div><h2>{title}</h2><p>عدد النتائج: {_h(total)} | الصفحة {_h(page)} من {_h(page_count)}</p></div></div>
    <div class="grid product-list">{cards}</div>
    <nav class="pagination">{prev_link}{next_link}</nav>
    """


def _bottom_nav(active: str = "home") -> str:
    def item(key: str, href: str, icon: str, label: str) -> str:
        cls = "active" if active == key else ""
        return f'<a class="{cls}" href="{_h(href)}"><span>{icon}</span><small>{label}</small></a>'
    return '<nav class="bottom-nav">' + ''.join([
        item("home", "/catalog", "⌂", "الرئيسية"),
        item("products", "/products", "▦", "المنتجات"),
        item("categories", "/products", "◫", "التصنيفات"),
        item("whatsapp", _whatsapp_link("السلام عليكم، أريد الاستفسار عن منتجات صيدلية بدر."), "☏", "واتساب"),
        item("contact", "/contact", "○", "تواصل"),
    ]) + '</nav>'


def _css() -> str:
    return """
    :root { --navy:#082c55; --navy2:#0b3a6d; --cyan:#3fc7e8; --cyan2:#1ea9d6; --bg:#f6fbff; --card:#ffffff; --text:#082c55; --muted:#6b7b8e; --line:#e3edf5; --green:#48c675; --shadow:0 18px 42px rgba(8,44,85,.09); --soft-shadow:0 8px 24px rgba(8,44,85,.06); }
    * { box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
    html { background:var(--bg); } body { margin:0; background:linear-gradient(180deg,#ffffff 0,#f7fcff 36%,#f5fbff 100%); color:var(--text); font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Tahoma,Arial,sans-serif; line-height:1.55; padding-bottom:90px; } a { color:inherit; text-decoration:none; } .wrap { width:min(1180px,100%); margin:auto; padding:0 18px; }
    .app-header { position:sticky; top:0; z-index:60; background:rgba(255,255,255,.94); backdrop-filter:blur(14px); border-bottom:1px solid rgba(227,237,245,.75); } .app-header-inner { height:118px; display:grid; grid-template-columns:56px 1fr 56px; align-items:center; gap:8px; padding:10px 18px 8px; direction:ltr; } .brand-link { justify-self:center; display:flex; align-items:center; justify-content:center; min-width:0; } .brand-link img { width:min(245px,60vw); max-height:92px; object-fit:contain; display:block; filter:drop-shadow(0 8px 16px rgba(8,44,85,.08)); }
    .top-icon { width:46px; height:46px; border:0; background:white; border-radius:18px; color:var(--navy); display:grid; place-items:center; font-size:27px; font-weight:950; box-shadow:var(--soft-shadow); position:relative; } .top-icon .dot { position:absolute; top:6px; right:7px; min-width:20px; height:20px; border-radius:999px; background:var(--cyan); color:white; display:grid; place-items:center; font-size:11px; border:2px solid white; } .menu-lines { width:25px; display:grid; gap:5px; } .menu-lines i { height:3px; border-radius:99px; background:var(--navy); display:block; }
    .search-panel { margin:14px 0 18px; } .search { background:white; border:1px solid var(--line); border-radius:26px; padding:10px; display:grid; grid-template-columns:1fr 190px 105px; gap:10px; box-shadow:var(--soft-shadow); } .search-panel.compact .search { grid-template-columns:1fr; border-radius:24px; padding:0; box-shadow:0 10px 24px rgba(8,44,85,.05); } .search-panel.compact select,.search-panel.compact button { display:none; } .search-input-wrap { position:relative; } .search-icon { position:absolute; inset-inline-start:20px; top:50%; transform:translateY(-50%); color:#50749a; font-size:28px; font-weight:900; } input,select,button { width:100%; border:1px solid var(--line); border-radius:18px; padding:14px; font-size:16px; background:#fff; color:var(--text); outline:none; } input { padding-inline-start:60px; direction:auto; min-height:58px; } .search-panel.compact input { border:0; border-radius:24px; min-height:64px; text-align:center; font-size:19px; } button,.btn { border:0; background:linear-gradient(135deg,var(--cyan),var(--cyan2)); color:white; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; border-radius:18px; padding:12px 14px; font-weight:950; text-align:center; box-shadow:0 10px 22px rgba(30,169,214,.22); } .btn.secondary { background:#eef7ff; color:var(--navy); box-shadow:none; }
    .hero-card { position:relative; min-height:250px; border-radius:34px; overflow:hidden; margin:14px 0 24px; background:radial-gradient(circle at 16% 20%,rgba(63,199,232,.26),transparent 34%),linear-gradient(135deg,#f0fbff 0,#ffffff 52%,#e9f8ff 100%); border:1px solid #dcecf8; box-shadow:var(--shadow); display:grid; grid-template-columns:1fr 1.08fr; align-items:center; padding:28px; isolation:isolate; } .hero-card:before { content:""; position:absolute; width:170px; height:170px; border-radius:45px; background:linear-gradient(135deg,rgba(63,199,232,.18),rgba(8,44,85,.05)); left:-45px; top:38px; transform:rotate(18deg); } .hero-copy { position:relative; z-index:2; text-align:right; } .hero-copy h1 { margin:0 0 12px; color:var(--navy); font-size:42px; line-height:1.12; letter-spacing:-.04em; } .hero-copy p { margin:0 0 22px; color:var(--navy2); font-size:20px; max-width:430px; } .hero-cta { display:inline-flex; align-items:center; gap:10px; min-width:230px; justify-content:center; background:linear-gradient(135deg,var(--cyan),var(--cyan2)); color:white; border-radius:999px; padding:14px 24px; font-size:18px; font-weight:950; box-shadow:0 14px 32px rgba(30,169,214,.25); } .hero-cta span { width:30px; height:30px; border-radius:50%; background:rgba(255,255,255,.25); display:grid; place-items:center; } .hero-art { position:relative; min-height:205px; display:grid; place-items:center; z-index:2; } .med-basket { width:205px; height:138px; border-radius:22px 22px 34px 34px; background:linear-gradient(180deg,#49c9eb,#139bd0); position:relative; box-shadow:0 24px 48px rgba(30,169,214,.22); display:flex; align-items:flex-start; justify-content:center; gap:10px; padding-top:26px; } .med-basket:after { content:""; position:absolute; left:22px; right:22px; bottom:24px; height:54px; background:repeating-linear-gradient(90deg,rgba(255,255,255,.25) 0 12px,transparent 12px 26px); border-radius:16px; } .med-item { width:34px; height:84px; border-radius:12px; background:white; box-shadow:0 8px 22px rgba(8,44,85,.12); position:relative; transform:rotate(var(--r)); } .med-item:before { content:"+"; position:absolute; inset:0; display:grid; place-items:center; color:var(--cyan2); font-size:26px; font-weight:950; } .med-item.small { height:62px; margin-top:15px; background:#eef9ff; } .shield { position:absolute; width:82px; height:82px; border-radius:24px; right:24px; bottom:-24px; background:linear-gradient(135deg,#ffffff,#e8f9ff); border:5px solid var(--cyan); box-shadow:0 16px 30px rgba(8,44,85,.13); display:grid; place-items:center; color:var(--cyan2); font-size:42px; font-weight:950; } .hero-dots { display:flex; justify-content:center; gap:10px; margin-top:-8px; margin-bottom:18px; } .hero-dots i { width:10px; height:10px; border-radius:50%; background:#c6d7e8; } .hero-dots i:first-child { width:22px; border-radius:999px; background:var(--navy); }
    .category-strip { display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:14px; margin:20px 0 32px; } .cat-pill { background:white; border:1px solid var(--line); border-radius:25px; min-height:116px; padding:16px 10px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; box-shadow:var(--soft-shadow); transition:.18s ease; } .cat-pill:hover { transform:translateY(-2px); border-color:rgba(63,199,232,.55); } .cat-line-icon { width:48px; height:48px; border-radius:16px; display:grid; place-items:center; color:var(--cyan2); border:2px solid rgba(30,169,214,.22); font-size:24px; font-weight:950; } .cat-pill strong { color:var(--navy); font-size:16px; white-space:nowrap; max-width:100%; overflow:hidden; text-overflow:ellipsis; }
    .chips { display:flex; gap:9px; overflow:auto; padding:8px 2px 12px; scrollbar-width:none; } .chips::-webkit-scrollbar { display:none; } .chip { flex:0 0 auto; background:white; border:1px solid var(--line); color:var(--navy); border-radius:999px; padding:9px 14px; font-size:14px; font-weight:900; box-shadow:0 5px 14px rgba(0,0,0,.04); } .chip.active { background:var(--navy); color:white; border-color:var(--navy); }
    .section-head { display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin:28px 0 16px; } .section-head h2 { margin:0; color:var(--navy); font-size:27px; letter-spacing:-.03em; } .section-head p,.product-meta,.meta { color:var(--muted); margin:4px 0 0; } .view-all { color:var(--cyan2); font-weight:900; }
    .grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(230px,1fr)); gap:16px; } .grid.home-grid { grid-template-columns:repeat(3,minmax(0,1fr)); } .product-card { position:relative; background:white; border:1px solid var(--line); border-radius:28px; padding:14px; box-shadow:var(--soft-shadow); min-width:0; overflow:hidden; } .product-card:after { content:""; position:absolute; inset:0; border-radius:28px; pointer-events:none; box-shadow:inset 0 0 0 1px rgba(255,255,255,.65); } .fav { position:absolute; top:15px; inset-inline-start:15px; width:34px; height:34px; border-radius:50%; background:white; border:1px solid #e4edf6; color:#7d9ab8; display:grid; place-items:center; z-index:2; font-size:21px; } .available-badge { position:absolute; top:15px; inset-inline-end:15px; z-index:2; background:var(--green); color:white; border-radius:999px; padding:5px 10px; font-size:12px; font-weight:950; } .product-image { height:160px; border-radius:22px; background:linear-gradient(180deg,#ffffff,#f5fbff); display:flex; align-items:center; justify-content:center; overflow:hidden; margin-bottom:12px; } .product-image img { width:100%; height:100%; object-fit:contain; display:block; } .no-img { width:100%; height:100%; display:grid; place-items:center; align-content:center; gap:8px; color:#8cb0ca; } .no-img span { width:72px; height:72px; border-radius:26px; background:linear-gradient(135deg,#e9f9ff,#ffffff); color:var(--cyan2); display:grid; place-items:center; font-size:26px; font-weight:950; border:1px solid #d5edf8; } .no-img small { font-size:12px; color:#93a6b7; } .product-info { text-align:center; } .product-name { display:block; color:var(--navy); font-size:16px; font-weight:950; line-height:1.38; min-height:44px; max-height:45px; overflow:hidden; overflow-wrap:anywhere; } .product-meta { font-size:13px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; min-height:20px; } .product-price { direction:ltr; color:var(--cyan2); font-size:22px; font-weight:950; margin:7px 0 10px; } .wa-order { width:100%; min-height:42px; border-radius:15px; background:linear-gradient(135deg,var(--cyan),var(--cyan2)); color:white; display:flex; align-items:center; justify-content:center; gap:8px; font-size:15px; font-weight:950; box-shadow:0 10px 20px rgba(30,169,214,.22); }
    .trust-strip { display:grid; grid-template-columns:repeat(4,1fr); margin:32px 0 26px; background:white; border:1px solid var(--line); border-radius:26px; box-shadow:var(--soft-shadow); overflow:hidden; } .trust-item { min-height:108px; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; gap:5px; padding:14px 10px; color:var(--navy); border-inline-start:1px solid var(--line); } .trust-item:first-child { border-inline-start:0; } .trust-item b { font-size:15px; } .trust-item small { color:var(--muted); font-size:12px; } .trust-item span { color:var(--cyan2); font-size:26px; line-height:1; }
    .empty { background:white; border:1px solid var(--line); border-radius:24px; padding:28px; text-align:center; color:var(--muted); box-shadow:var(--soft-shadow); } .pagination { display:flex; gap:10px; justify-content:center; padding:22px 0; } .footer { color:#7f90a3; text-align:center; font-size:13px; padding:18px 10px 28px; }
    .detail,.contact-card { background:white; border:1px solid var(--line); border-radius:28px; padding:18px; box-shadow:var(--soft-shadow); margin:18px 0; } .detail { display:grid; grid-template-columns:360px 1fr; gap:22px; align-items:start; } .detail .image { height:330px; border-radius:24px; background:#f7fcff; display:grid; place-items:center; overflow:hidden; } .detail .image img { width:100%; height:100%; object-fit:contain; } .detail h2 { margin:0 0 10px; color:var(--navy); font-size:28px; } .badge { display:inline-flex; align-items:center; background:#ecfdf3; color:#159447; border-radius:999px; padding:6px 10px; font-size:13px; font-weight:950; } .info-list { margin:18px 0; color:var(--muted); } .info-list p { margin:7px 0; } .order-note,.customer-notice { background:#f2fbff; border:1px solid #d8f1fb; border-radius:18px; padding:12px; color:var(--navy2); margin:12px 0; } .detail-actions { display:flex; gap:10px; flex-wrap:wrap; margin-top:14px; } .contact-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; }
    .bottom-nav { position:fixed; left:0; right:0; bottom:0; z-index:70; height:78px; background:rgba(255,255,255,.96); backdrop-filter:blur(14px); border-top:1px solid var(--line); display:grid; grid-template-columns:repeat(5,1fr); box-shadow:0 -12px 28px rgba(8,44,85,.08); } .bottom-nav a { display:flex; flex-direction:column; align-items:center; justify-content:center; gap:3px; color:#7891ad; font-weight:800; } .bottom-nav span { font-size:23px; line-height:1; } .bottom-nav small { font-size:12px; } .bottom-nav a.active { color:var(--cyan2); }
    @media (max-width:760px) { body { padding-bottom:84px; } .wrap { padding:0 16px; } .app-header-inner { height:112px; grid-template-columns:48px 1fr 48px; padding:8px 14px; } .brand-link img { width:min(210px,58vw); max-height:86px; } .top-icon { width:42px; height:42px; border-radius:16px; } .search { grid-template-columns:1fr; } .search select,.search button { display:block; } .search-panel.compact .search { grid-template-columns:1fr; } .hero-card { min-height:300px; grid-template-columns:1fr; padding:24px 20px; text-align:center; } .hero-copy { text-align:center; order:2; } .hero-copy h1 { font-size:35px; } .hero-copy p { font-size:18px; margin-inline:auto; } .hero-art { min-height:170px; order:1; } .med-basket { width:170px; height:112px; transform:scale(.92); } .shield { width:68px; height:68px; font-size:35px; right:10px; } .category-strip { grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; } .category-strip .cat-pill:first-child { grid-column:1/-1; } .cat-pill { min-height:86px; flex-direction:row; justify-content:center; } .grid.home-grid { display:flex; overflow-x:auto; gap:14px; padding:2px 2px 12px; scroll-snap-type:x mandatory; } .grid.home-grid .product-card { flex:0 0 72%; scroll-snap-align:start; } .grid:not(.home-grid) { grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; } .product-card { border-radius:24px; padding:10px; } .product-image { height:118px; border-radius:20px; } .product-name { font-size:14px; min-height:40px; max-height:42px; } .product-meta { font-size:12px; } .product-price { font-size:18px; } .wa-order { font-size:13px; min-height:39px; } .trust-strip { grid-template-columns:repeat(2,1fr); } .trust-item { min-height:92px; } .detail { grid-template-columns:1fr; } .detail .image { height:260px; } .contact-grid { grid-template-columns:1fr; } }
    """


def _shell(title: str, body: str, active: str = "home") -> HTMLResponse:
    pharmacy = _pharmacy_name()
    doc = """<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><title>__TITLE__ | __PHARMACY__</title><style>__CSS__</style></head>
<body>
<header class="app-header"><div class="app-header-inner"><a class="top-icon" href="/products" aria-label="القائمة"><span class="menu-lines"><i></i><i></i><i></i></span></a><a class="brand-link" href="/catalog" aria-label="صيدلية بدر"><img src="__LOGO__" alt="Badr Pharmacy"></a><a class="top-icon" href="__WA__" aria-label="واتساب">☏<span class="dot">1</span></a></div></header>
<main class="wrap">__BODY__<div class="footer">الأسعار والتوفر حسب آخر تحديث من الصيدلية، ويتم تأكيد الطلب عبر واتساب قبل التجهيز.</div></main>__NAV__</body></html>"""
    return HTMLResponse(
        doc.replace("__TITLE__", _h(title))
        .replace("__PHARMACY__", _h(pharmacy))
        .replace("__CSS__", _css())
        .replace("__LOGO__", f"/badr-logo.png?v={BRAND_ASSET_VERSION}")
        .replace("__WA__", _h(_whatsapp_link("السلام عليكم، أريد الاستفسار عن منتجات صيدلية بدر.")))
        .replace("__BODY__", body)
        .replace("__NAV__", _bottom_nav(active))
    )


@router.get("/badr-logo.png")
def badr_logo_asset():
    if BRAND_LOGO_FILE.exists():
        return FileResponse(str(BRAND_LOGO_FILE), media_type="image/png")
    return PlainTextResponse("logo not found", status_code=404)


@router.get("/catalog-health")
def catalog_health():
    try:
        with _connect() as conn:
            cols = _columns(conn)
            total = int(conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] or 0)
            available = int(conn.execute(f"SELECT COUNT(*) FROM products WHERE {_available_condition(cols)}").fetchone()[0] or 0)
        return JSONResponse({"ok": True, "service": "pricebot-catalog", "products_count": total, "available_count": available, "brand_ui": "badr-ui-1"})
    except Exception as exc:
        return JSONResponse({"ok": False, "error": repr(exc)}, status_code=500)


@router.get("/", response_class=HTMLResponse)
@router.get("/catalog", response_class=HTMLResponse)
def catalog_home() -> HTMLResponse:
    products = _query_products(page=1)[0][:12]
    product_cards = "".join(_product_card(p, mode="tile") for p in products)
    if not product_cards:
        product_cards = '<div class="empty">لا توجد منتجات متاحة حالياً. ارفع ملف Excel من لوحة التاجر.</div>'
    body = f"""
    {_search_form(compact=True)}
    <section class="hero-card"><div class="hero-copy"><h1>كتالوج الصيدلية</h1><p>ابحث، راجع السعر والتوفر، واطلب بسهولة عبر واتساب.</p><a class="hero-cta" href="{_h(_whatsapp_link('السلام عليكم، أريد الطلب من صيدلية بدر.'))}" target="_blank" rel="noopener">اطلب الآن عبر واتساب <span>☏</span></a></div><div class="hero-art" aria-hidden="true"><div class="med-basket"><i class="med-item" style="--r:-10deg"></i><i class="med-item small" style="--r:8deg"></i><i class="med-item" style="--r:13deg"></i><b class="shield">✓</b></div></div></section>
    <div class="hero-dots"><i></i><i></i><i></i><i></i></div>
    {_category_tiles(5)}
    <div class="section-head"><h2>منتجات مميزة</h2><a class="view-all" href="/products">عرض الكل ‹</a></div>
    <div class="grid home-grid">{product_cards}</div>
    <section class="trust-strip"><div class="trust-item"><span>✓</span><b>منتجات أصلية</b><small>100% مضمونة</small></div><div class="trust-item"><span>▣</span><b>تحديث مستمر</b><small>للأسعار والتوفر</small></div><div class="trust-item"><span>☏</span><b>طلب عبر واتساب</b><small>تأكيد قبل التجهيز</small></div><div class="trust-item"><span>⚕</span><b>صيدلية معتمدة</b><small>لخدمتك</small></div></section>
    """
    return _shell("كتالوج المنتجات", body, active="home")


@router.get("/products", response_class=HTMLResponse)
def products_page(q: str = Query("", max_length=140), category: str = Query("", max_length=160), page: int = Query(1, ge=1)) -> HTMLResponse:
    return _shell("المنتجات", _products_section(q=q, category=category, page=page), active="products")


@router.get("/product/{product_id}", response_class=HTMLResponse)
def product_detail(product_id: int) -> HTMLResponse:
    product = _get_product(product_id)
    if not product:
        return _shell("المنتج غير موجود", '<div class="empty">المنتج غير موجود أو غير متاح حالياً.</div>', active="products")
    name = str(product.get("display_name") or "Product")
    price = _format_price(product.get("price"), product.get("currency"))
    brand = str(product.get("brand") or "").strip()
    category = str(product.get("category") or "").strip()
    img = _image_src(product.get("image_url"))
    img_html = f'<img src="{_h(img)}" alt="{_h(name)}">' if img else '<div class="no-img"><span>Rx</span><small>صورة قريباً</small></div>'
    body = f"""
    <section class="detail"><div class="image">{img_html}</div><div><h2 dir="auto">{_h(name)}</h2><div class="product-price">{_h(price)}</div><div class="badge">متوفر</div><div class="info-list"><p>رقم المنتج: <b>{_h(product_id)}</b></p><p>القسم: <b>{_h(_display_category_label(category)) if category else 'غير محدد'}</b></p><p>البراند: <b>{_h(brand) if brand else 'غير محدد'}</b></p></div><div class="order-note">سيتم تأكيد السعر والتوفر النهائي عبر واتساب قبل تجهيز الطلب.</div><div class="detail-actions"><a class="btn" href="/order/{_h(product_id)}" target="_blank" rel="noopener">اطلب عبر واتساب</a><a class="btn secondary" href="/products">رجوع للمنتجات</a></div></div></section>
    """
    return _shell(name, body, active="products")


@router.get("/order/{product_id}")
def order_product(product_id: int):
    product = _get_product(product_id)
    if not product:
        return RedirectResponse(_whatsapp_link(f"السلام عليكم، أريد الاستفسار عن منتج رقم {product_id}، لكنه غير ظاهر كمُتاح في الموقع."), status_code=302)
    return RedirectResponse(_whatsapp_link(_order_message(product)), status_code=302)


@router.get("/contact", response_class=HTMLResponse)
def contact_page() -> HTMLResponse:
    wa = _whatsapp_link("السلام عليكم، أريد التواصل مع صيدلية بدر.")
    body = f"""
    <section class="contact-card"><h2>تواصل مع صيدلية بدر</h2><p>للطلبات والاستفسارات، استخدم واتساب. الأسعار والتوفر يتم تأكيدهما قبل تجهيز الطلب.</p><div class="detail-actions"><a class="btn" href="{_h(wa)}" target="_blank" rel="noopener">فتح واتساب</a><a class="btn secondary" href="/products">تصفح المنتجات</a></div><div class="customer-notice">هذا الموقع كتالوج عرض وطلب عبر واتساب، وليس بوابة دفع إلكتروني حالياً.</div></section>
    <div class="contact-grid"><div class="contact-card"><strong>طريقة الطلب</strong><p>ابحث عن المنتج، افتح التفاصيل، ثم اضغط اطلب عبر واتساب.</p></div><div class="contact-card"><strong>التوفر</strong><p>حالة التوفر مبنية على آخر ملف منتجات مرفوع من الصيدلية.</p></div><div class="contact-card"><strong>التأكيد</strong><p>يتم تأكيد السعر والتوفر النهائيين داخل محادثة واتساب.</p></div></div>
    """
    return _shell("تواصل معنا", body, active="contact")
