#!/usr/bin/env bash
set -euo pipefail
echo "=== catalog health ==="
curl -i http://127.0.0.1:8090/catalog-health || true
echo "=== logo ==="
curl -I http://127.0.0.1:8090/badr-logo.png || true
echo "=== catalog html sample ==="
curl -s http://127.0.0.1:8090/catalog?v=badr-ui-1 | grep -E "Badr Pharmacy|كتالوج الصيدلية|hero-card|badr-logo" | head -20 || true
echo "=== service ==="
sudo systemctl status pricebot.service --no-pager -l | head -35 || true
