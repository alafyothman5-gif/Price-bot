from __future__ import annotations

"""Arabic/English catalog name normalization.

The function in this file is the single source of truth for merchant-uploaded
names, master aliases, and exact-match lookups.  It deliberately does not use
fuzzy matching or probabilistic guessing.
"""

import re
import unicodedata

_ARABIC_DIGITS = str.maketrans({
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
    "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
})

_UNIT_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"\b(?:ملي\s*جرام|ملجم|مجم|mg|m\s*g)\b", "mg"),
    (r"\b(?:ميكرو\s*جرام|ميكروجرام|mcg|µg|ug)\b", "mcg"),
    (r"\b(?:جرام|جم|غم|g)\b", "g"),
    (r"\b(?:ملي\s*لتر|مللى|مللي|مل|ml|m\s*l)\b", "ml"),
    (r"\b(?:وحده\s*دوليه|وحدة\s*دولية|iu|i\s*u)\b", "iu"),
    (r"\b(?:بالمئه|بالمائة|%|percent)\b", "%"),
)

_STOP_WORDS = {
    "السعر", "سعر", "متوفر", "متوفره", "متوفرة", "عندكم", "موجود", "موجوده", "موجودة",
    "كم", "بكم", "بكام", "اريد", "أريد", "نبي", "ابي", "لو", "سمحت", "بالله", "please",
    "price", "available", "availability", "do", "you", "have",
}

_PUNCT_RE = re.compile(r"[^0-9a-zA-Z\u0600-\u06FF%]+")


def _strip_diacritics(text: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKD", text) if unicodedata.category(ch) != "Mn")


def normalize_arabic_name(raw: str) -> str:
    """Return a conservative normalized key for exact catalog matching.

    Steps are fixed by the PriceBot Catalog Ingestion specification:
    lowercase/strip, remove Arabic diacritics/tatweel, normalize Arabic letters,
    normalize Arabic digits, normalize whole-word units, remove request words,
    collapse spaces.
    """
    text = str(raw or "").lower().strip()
    text = _strip_diacritics(text)
    text = text.replace("ـ", "")
    text = text.translate(_ARABIC_DIGITS)
    text = re.sub("[أإآٱ]", "ا", text)
    text = text.replace("ة", "ه").replace("ى", "ي")
    text = text.replace("ؤ", "و").replace("ئ", "ي")

    # Normalize common Arabic comma/decimal forms before punctuation cleanup.
    text = text.replace("٫", ".").replace("،", " ").replace(",", " ")

    for pattern, replacement in _UNIT_PATTERNS:
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    # Keep decimals and unit adjacency readable: 500 mg -> 500mg, 200 ml -> 200ml.
    text = re.sub(r"(?<=\d)\s+(?=(?:mg|mcg|g|ml|iu|%)\b)", "", text, flags=re.I)
    text = _PUNCT_RE.sub(" ", text)

    tokens = [t for t in text.split() if t and t not in _STOP_WORDS]
    return " ".join(tokens).strip()
