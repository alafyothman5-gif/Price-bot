#!/usr/bin/env bash
set -Eeuo pipefail

TARGET="${PRICEBOT_TARGET_DIR:-/opt/pricebot_clean}"
SERVICE="${PRICEBOT_SERVICE:-pricebot.service}"
BACKUP_ROOT="${PRICEBOT_BACKUP_ROOT:-/opt/pricebot_backups}"
STAMP="$(date +%Y%m%d_%H%M%S)"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "$TARGET" != "/opt/pricebot_clean" ]]; then
  echo "ERROR: target must remain /opt/pricebot_clean unless PRICEBOT_TARGET_DIR is intentionally set. Current: $TARGET" >&2
  exit 1
fi

sudo mkdir -p "$BACKUP_ROOT/$STAMP"
if [[ -d "$TARGET" ]]; then
  sudo rsync -a --delete \
    --exclude 'venv/' --exclude '__pycache__/' --exclude '*.pyc' \
    "$TARGET/" "$BACKUP_ROOT/$STAMP/files/"
  if [[ -f "$TARGET/pricebot.db" ]]; then
    sudo sqlite3 "$TARGET/pricebot.db" ".backup '$BACKUP_ROOT/$STAMP/pricebot.db'" || sudo cp "$TARGET/pricebot.db" "$BACKUP_ROOT/$STAMP/pricebot.db"
  fi
fi

sudo systemctl stop "$SERVICE" || true

# Preserve runtime-only assets.
sudo mkdir -p "$TARGET"
for item in .env pricebot.db uploads; do
  if [[ -e "$TARGET/$item" ]]; then
    sudo mkdir -p "$BACKUP_ROOT/$STAMP/preserve"
    sudo cp -a "$TARGET/$item" "$BACKUP_ROOT/$STAMP/preserve/" || true
  fi
done

sudo rsync -a --delete \
  --exclude '.env' --exclude 'pricebot.db' --exclude 'venv/' --exclude '__pycache__/' --exclude '*.pyc' --exclude 'uploads/' \
  "$SRC_DIR/" "$TARGET/"

for item in .env pricebot.db uploads; do
  if [[ -e "$BACKUP_ROOT/$STAMP/preserve/$item" ]]; then
    sudo cp -a "$BACKUP_ROOT/$STAMP/preserve/$item" "$TARGET/"
  fi
done

cd "$TARGET"
./venv/bin/python -m py_compile app.py vision_service.py ui_flow.py matcher.py services/matching/excel_native_matcher.py services/vision/evidence_validator.py catalog_ingestion/*.py
./venv/bin/python tools/clear_image_cache.py || true
sudo systemctl start "$SERVICE"

HEALTH_URL="${PRICEBOT_HEALTH_URL:-http://127.0.0.1:8090/health}"
HEALTH_TIMEOUT_SECONDS="${PRICEBOT_HEALTH_TIMEOUT_SECONDS:-60}"
HEALTH_OK=0
for i in $(seq 1 "$HEALTH_TIMEOUT_SECONDS"); do
  if curl -fsS "$HEALTH_URL" >/dev/null; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done
if [[ "$HEALTH_OK" != "1" ]]; then
  echo "ERROR: health check failed after ${HEALTH_TIMEOUT_SECONDS}s: $HEALTH_URL" >&2
  sudo systemctl status "$SERVICE" --no-pager -l || true
  exit 1
fi

echo "DEPLOY_OK=1 backup=$BACKUP_ROOT/$STAMP target=$TARGET health=$HEALTH_URL"
