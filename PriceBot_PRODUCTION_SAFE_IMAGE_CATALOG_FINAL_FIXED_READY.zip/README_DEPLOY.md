# PriceBot Safe Deploy — `/opt/pricebot_clean`

This package is prepared for the current production layout only.

## Production layout

- Active directory: `/opt/pricebot_clean`
- Symlink: `/opt/pricebot -> /opt/pricebot_clean`
- SQLite database: `/opt/pricebot_clean/pricebot.db`
- systemd service: `pricebot.service`
- Local health check: `http://127.0.0.1:8090/health`

Do not create `/opt/pricebot` as an independent project directory. It must remain a symlink to `/opt/pricebot_clean`.

## Files that must never be committed or included in ZIP releases

- `.env`
- `pricebot.db`
- `venv/`
- `__pycache__/`
- backups
- uploaded customer/media files unless explicitly required

Secrets must stay only on the server inside `/opt/pricebot_clean/.env` or the server environment. Do not put secrets in GitHub.

## Safe deploy command

Upload/extract the ZIP into a temporary directory, then run from the extracted directory:

```bash
chmod +x deploy_pricebot_clean.sh clean_install_pricebot.sh
./deploy_pricebot_clean.sh
```

`clean_install_pricebot.sh` is only a wrapper around `deploy_pricebot_clean.sh`.

## What the deploy script does

1. Targets `/opt/pricebot_clean` only.
2. Creates a backup under `/opt/pricebot_backups/<timestamp>/`.
3. Preserves these live runtime items:
   - `/opt/pricebot_clean/.env`
   - `/opt/pricebot_clean/pricebot.db`
   - `/opt/pricebot_clean/uploads/`
4. Stops `pricebot.service`.
5. Replaces code files only.
6. Restores preserved runtime items.
7. Runs Python compile checks.
8. Clears only unsafe/unconfirmed image cache entries.
9. Starts `pricebot.service`.
10. Waits up to 60 seconds for `http://127.0.0.1:8090/health`.
11. Prints `DEPLOY_OK=1` on success.

## Database safety rules

The deploy script does not delete, recreate, or replace `/opt/pricebot_clean/pricebot.db`.

The Catalog Ingestion flow writes to staging first, then preview, then approval. It does not update production prices until safe rows are explicitly approved. Products missing from a weekly Excel upload are report-only and are not deleted or marked unavailable.

## Image safety rule

Images never display price or availability directly. Image flow is:

`Image -> Vision/OCR -> foreground/title validation -> safe candidate confirmation -> user confirmation/selection -> price/availability`

When uncertain, the bot asks for clarification or asks the customer to write the product name.
