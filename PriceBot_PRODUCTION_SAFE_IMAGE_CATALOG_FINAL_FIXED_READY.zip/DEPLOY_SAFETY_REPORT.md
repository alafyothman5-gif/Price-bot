# DEPLOY_SAFETY_REPORT

Release: `PriceBot_PRODUCTION_SAFE_IMAGE_CATALOG_FINAL_FIXED_READY`

## Production target

- Active dir: `/opt/pricebot_clean`
- Symlink: `/opt/pricebot -> /opt/pricebot_clean`
- Database: `/opt/pricebot_clean/pricebot.db`
- Service: `pricebot.service`
- Health: `http://127.0.0.1:8090/health`

## Deploy script changes

`deploy_pricebot_clean.sh` now:

- targets `/opt/pricebot_clean` only;
- creates a backup of current code and DB before deploy;
- preserves `.env`, `pricebot.db`, and `uploads/`;
- excludes `.env`, `pricebot.db`, `venv/`, `__pycache__/`, `*.pyc`, and `uploads/` from code replacement;
- does not delete products;
- does not replace the database;
- does not change the `/opt/pricebot` symlink;
- checks health at `http://127.0.0.1:8090/health`;
- waits up to 60 seconds for startup;
- prints `DEPLOY_OK=1` on success.

## Verification performed in sandbox

- `python -m compileall . -q` -> passed.
- `PYTHONPATH=. pytest -q tests/test_production_safe_image_policy.py` -> passed.
- `PYTHONPATH=. pytest -q tests/test_catalog_ingestion_safe_exact.py` -> passed.
- Custom isolated-catalog matching/image policy checks -> passed.

## Sandbox limitation

The live server database `/opt/pricebot_clean/pricebot.db` was not available inside this sandbox. Product-count assertions against the real 5791-row catalog must be run on the server after deployment. This ZIP does not include `pricebot.db`.
