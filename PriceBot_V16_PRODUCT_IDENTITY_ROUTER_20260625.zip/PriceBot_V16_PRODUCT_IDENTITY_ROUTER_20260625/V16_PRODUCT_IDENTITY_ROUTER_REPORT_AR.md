# تقرير V16

تم تحويل المطابقة إلى Product Identity Router:

1. إلغاء Gemini من المطابقة النصية.
2. إلغاء embeddings من المطابقة النصية.
3. اعتماد تنظيف النص + aliases + product/family terms.
4. fuzzy/substring لا يعطي سعر مباشر؛ فقط قائمة أو تأكيد.
5. direct فقط من exact product identity أو family unique.
6. الصور: Vision يستخرج النص ثم نفس Router يطابق.
7. systemd يعمل بـ workers 2.
8. لا تغييرات على مفاتيح .env.
