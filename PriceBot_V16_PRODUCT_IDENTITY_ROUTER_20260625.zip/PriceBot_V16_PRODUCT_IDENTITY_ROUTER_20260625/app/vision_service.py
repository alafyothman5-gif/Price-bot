import asyncio
import base64
import io
import json
import os
import re
from typing import Dict

import httpx
from PIL import Image

import config_env
from services.vision.evidence_validator import parse_vision_response, validate_vision_payload

GENERIC_IMAGE_WORDS = {
    "cream", "gel", "tube", "capsule", "capsules", "tablet", "tablets", "vitamin", "female", "face", "skin",
    "lotion", "syrup", "drops", "spray", "shampoo", "conditioner", "mg", "ml", "iu", "كريم", "جل", "حبوب",
    "فيتامين", "كبسولات", "شراب", "قطره", "بخاخ", "شامبو",
}

GENERIC_INGREDIENTS = {
    "folic acid", "iron", "zinc", "vitamin c", "vitamin d", "collagen",
    "hyaluronic acid", "spf", "omega 3", "calcium", "magnesium",
    "فوليك أسيد", "فوليك اسيد", "حديد", "زنك", "فيتامين سي", "فيتامين د",
}


def _clean_generic_identity(value: object) -> str:
    value = str(value or "").lower().replace("-", " ").replace("_", " ")
    value = re.sub(r"\s+", " ", value).strip(" .,:;،-_|/")
    return value


def _log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["key", "token", "secret", "authorization"]):
            v = "HIDDEN"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)


def _openrouter_config() -> Dict[str, str]:
    config_env.apply_openrouter_aliases()
    return {
        "api_key": config_env.resolve_openrouter_api_key(),
        "model": config_env.openrouter_gemini_model(["OPENROUTER_VISION_MODEL", "OPENROUTER_MODEL"]),
        "base_url": (os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").strip() or "https://openrouter.ai/api/v1").rstrip("/"),
    }


def build_query_from_slots(slots: Dict[str, str]) -> str:
    """Build the exact image query sent to semantic_matcher.

    V11 rule: use the clean product identity only.  Never build the matcher
    query from foreground/raw OCR paragraphs.  Keep only product identifiers:
    brand/name, variant/range, strength, size, form and pack.
    """
    slots = slots or {}

    def clean(value: object) -> str:
        value = str(value or "").replace("\\n", " ").replace("\r", " ")
        value = re.sub(r"\s+", " ", value).strip(" -_|:;,.،")
        return value

    def add(parts: list[str], seen: set[str], value: object) -> None:
        value = clean(value)
        if not value:
            return
        key = re.sub(r"\s+", " ", value.lower()).strip()
        if key and key not in seen:
            parts.append(value)
            seen.add(key)

    identity = clean(slots.get("product_identity"))
    if identity:
        return identity[:180].strip()

    parts: list[str] = []
    seen: set[str] = set()
    for key in ["primary_name", "primary_title", "product_name", "brand", "variant", "product_family", "form", "strength", "size", "pack"]:
        add(parts, seen, slots.get(key))
    return " ".join(parts).strip()[:180]


def _is_weak_visual_query(query: str, slots: Dict[str, str]) -> bool:
    # Only blocks empty/near-empty OCR. It never performs product matching.
    value = re.sub(r"\s+", " ", str(query or "")).strip()
    if not value:
        return True
    if str((slots or {}).get("primary_title") or (slots or {}).get("product_name") or "").strip():
        return False
    useful_parts = [p for p in re.findall(r"[A-Za-z0-9]+|[\u0600-\u06FF]+", value) if len(p) >= 3 and p.lower() not in GENERIC_IMAGE_WORDS]
    return len(useful_parts) < 2



def _resize_image_for_vision(image_bytes: bytes, mime_type: str = "image/jpeg") -> tuple[bytes, str]:
    """Resize image before Vision to reduce latency/cost and avoid timeouts."""
    if not image_bytes:
        return b"", mime_type or "image/jpeg"
    try:
        with Image.open(io.BytesIO(image_bytes)) as im:
            im = im.convert("RGB")
            max_width = int(os.getenv("PRICEBOT_VISION_MAX_WIDTH", "1024") or 1024)
            if im.width > max_width:
                ratio = max_width / float(im.width)
                im = im.resize((max_width, max(1, int(im.height * ratio))))
            out = io.BytesIO()
            quality = int(os.getenv("PRICEBOT_VISION_JPEG_QUALITY", "80") or 80)
            im.save(out, format="JPEG", quality=quality, optimize=True)
            return out.getvalue(), "image/jpeg"
    except Exception as exc:
        _log("VISION_RESIZE_WARNING", error=type(exc).__name__)
        return image_bytes, mime_type or "image/jpeg"

async def extract_product_from_image(image_bytes: bytes, mime_type: str = "image/jpeg") -> Dict[str, str]:
    if not image_bytes:
        return {"status": "IMAGE_UNCLEAR", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا."}

    cfg = _openrouter_config()
    if not config_env.vision_enabled():
        reason = config_env.vision_disabled_reason()
        _log("VISION_DISABLED_REASON", reason=reason)
        return {"status": "IMAGE_UNCLEAR", "message": "فحص الصور غير مفعّل حاليًا. اكتب اسم المنتج كاملًا."}

    _log("VISION_START")
    _log("VISION_PROVIDER", provider="Gemini/OpenRouter")
    _log("VISION_MODEL", model=cfg["model"])

    image_bytes, mime_type = _resize_image_for_vision(image_bytes, mime_type)
    data_url = f"data:{mime_type};base64," + base64.b64encode(image_bytes).decode("ascii")
    prompt = (
        "You are PriceBot V15 Vision Extractor. Return STRICT JSON only. "
        "Identify only the largest central/front product package. Ignore background products, shelves, reflections, side boxes, and visible nearby items. "
        "Do not infer a medicine from ingredients or therapeutic class. Do not guess. "
        "If the product name on the foreground package is not readable with high confidence, set product_identity to empty and confidence below 0.70. "
        "Required keys exactly: status, product_identity, primary_name, brand, variant, form, strength, size, pack, confidence, foreground_product_text, background_text, raw_vision_text. "
        "product_identity must contain only visible brand/product name plus visible variant/strength/size/form/pack. "
        "If multiple packages are visible, foreground_product_text must be text from the central package only; background_text may include ignored background text. "
        "Do not output generic ingredients only such as folic acid, iron, zinc, vitamin c, vitamin d, collagen, SPF, omega 3. "
        "If no exact foreground name is readable: status='LOW_CONFIDENCE', product_identity='', confidence=0.55."
    )
    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]}
        ],
        "temperature": 0,
        "max_tokens": 450,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    content = ""
    max_attempts = int(os.getenv("PRICEBOT_VISION_RETRY_ATTEMPTS", "3") or 3)
    delay = float(os.getenv("PRICEBOT_VISION_RETRY_BASE_DELAY_SECONDS", "0.5") or 0.5)
    transient_statuses = {408, 409, 425, 429, 500, 502, 503, 504}
    try:
        async with httpx.AsyncClient(timeout=float(os.getenv("PRICEBOT_VISION_TIMEOUT_SECONDS", "10") or 10)) as client:
            for attempt in range(1, max_attempts + 1):
                try:
                    resp = await client.post(f"{cfg['base_url']}/chat/completions", headers=headers, json=payload)
                    if resp.status_code < 400:
                        content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
                        break
                    _log("VISION_ERROR", provider="openrouter", attempt=attempt, status=resp.status_code, transient=resp.status_code in transient_statuses)
                    if resp.status_code not in transient_statuses:
                        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
                except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError) as exc:
                    _log("VISION_TRANSIENT_EXCEPTION", provider="openrouter", attempt=attempt, status=type(exc).__name__)
                if attempt < max_attempts:
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 5.0)
            if not content:
                return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}
    except Exception as exc:
        _log("VISION_ERROR", provider="openrouter", status=type(exc).__name__)
        return {"status": "IMAGE_UNCLEAR", "message": "تعذر فحص الصورة حاليًا. أرسل صورة أوضح أو اكتب اسم المنتج."}

    data = parse_vision_response(content)
    if not data.get("_json_ok", True):
        _log("VISION_WARNING", provider="openrouter", status="bad_json", recovered=bool(data.get("primary_title")))

    evidence = validate_vision_payload(data)
    if evidence.status != "OK":
        return {"status": evidence.status, "message": evidence.message or "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.", **(evidence.slots or {})}

    query = evidence.query or build_query_from_slots(evidence.slots)
    slots = dict(evidence.slots)
    if query and not slots.get("product_identity"):
        slots["product_identity"] = query

    # Reject generic ingredient-only identities; they are not safe product names.
    identity_clean = _clean_generic_identity(slots.get("product_identity"))
    if identity_clean and identity_clean in GENERIC_INGREDIENTS:
        _log("VISION_GENERIC_INGREDIENT_REJECTED", product_identity=str(slots.get("product_identity") or "")[:120])
        return {"status": "LOW_CONFIDENCE", "message": "الصورة غير واضحة. أرسل صورة للعلبة كاملة أو اكتب الاسم."}

    _log("VISION_EXTRACTED_IDENTITY", product_identity=str(slots.get("product_identity") or "")[:120], primary_name=str(slots.get("primary_name") or slots.get("primary_title") or "")[:80], query=query[:120])
    _log("VISION_CONFIDENCE", value=slots.get("confidence", ""))

    result = dict(slots)
    result["status"] = "OK"
    result["query"] = query
    if evidence.needs_confirmation_only:
        # Bad-JSON recovery is allowed only as a confirmation question; it must
        # not be rejected as weak and must never display price directly.
        result["needs_confirmation_only"] = True
        result["message"] = evidence.message
        return result
    if _is_weak_visual_query(query, evidence.slots):
        return {"status": "LOW_CONFIDENCE", "message": "الصورة غير واضحة بما يكفي. أرسل صورة أوضح للواجهة الأمامية للمنتج، أو اكتب اسم المنتج كاملًا.", **(evidence.slots or {})}
    return result
