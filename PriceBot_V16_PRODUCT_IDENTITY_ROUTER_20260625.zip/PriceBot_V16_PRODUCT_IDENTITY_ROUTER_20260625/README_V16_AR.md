# PriceBot V16 Product Identity Router

## الهدف
نظام مطابقة مجاني وحتمي:
- لا Gemini للنصوص.
- لا embeddings للنصوص.
- Gemini Vision للصور فقط لاستخراج النص.
- لا سعر مباشر إلا من تطابق هوية منتج واضح.
- الأسماء العامة مثل Panadol / باندول / لاروش تعرض قائمة.

## الملفات الأساسية
- `app/product_identity_router.py`
- `app/app.py`
- `app/semantic_matcher.py` يبقى legacy health/schema فقط، ولا يستخدم للمطابقة النصية.
- `DEPLOY_V16_PRODUCT_IDENTITY_ROUTER_COMMANDS.sh`

## الاختبار
- Panadol → قائمة
- باندول → قائمة
- Panadol Advance → سعر أو تأكيد إذا منتج واحد واضح
- اموكلان → Amoclan فقط أو غير متوفر
- منتج غير موجود → غير متوفر
