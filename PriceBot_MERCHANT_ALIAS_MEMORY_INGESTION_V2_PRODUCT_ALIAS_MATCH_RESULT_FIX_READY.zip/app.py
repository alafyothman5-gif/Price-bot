import asyncio
import hashlib
import hmac
import json
import os
import re
import time
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple

import httpx
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, PlainTextResponse

import config_env

# Load .env and legacy variable aliases before importing modules that resolve
# DB paths or AI/Vision configuration at import time.
config_env.load_environment()

import admin
import database
import guided_commerce
import matcher
import merchant
import orders
import portal
import vision_service
import ui_flow
import whatsapp_interactive
from search_engine import SearchResult
from services.vision import visual_memory
from normalizer import normalize_text
try:
    from tasks.text_tasks import process_text_message as celery_text_task
    from tasks.vision_tasks import process_vision_message as celery_vision_task
except Exception:
    celery_text_task = None
    celery_vision_task = None

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "صيدلية بدر البشرية")
ADMIN_NOTIFY_PHONE = re.sub(r"\D+", "", os.getenv("ADMIN_NOTIFY_PHONE", ""))
QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_QUEUE_MAXSIZE", "500"))
WORKERS = int(os.getenv("PRICEBOT_WORKERS", "4"))
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "25"))
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60"))

MAIN_MENU = ui_flow.MAIN_MENU_MESSAGE
START_WORDS = ui_flow.START_WORDS | ui_flow.GREETING_WORDS | ui_flow.MENU_WORDS

app = FastAPI(title="PriceBot Premium Enterprise UI")
app.mount("/static", StaticFiles(directory="static"), name="static")
app.include_router(portal.router)
app.include_router(admin.router)
app.include_router(merchant.router)
queue: asyncio.Queue = asyncio.Queue(maxsize=QUEUE_MAXSIZE)
http_client: Optional[httpx.AsyncClient] = None
rate_buckets: Dict[str, deque] = defaultdict(deque)
# Per-user locks prevent concurrent workers from processing multiple messages
# from the same WhatsApp number at the same time.  This protects conversation
# state, clarification options, and numbered choices from race conditions.
user_locks: Dict[str, asyncio.Lock] = {}
user_lock_last_seen: Dict[str, float] = {}
USER_LOCK_TTL_SECONDS = int(os.getenv("PRICEBOT_USER_LOCK_TTL_SECONDS", "900") or 900)
IMAGE_CONCURRENCY = int(os.getenv("PRICEBOT_IMAGE_CONCURRENCY", "3") or 3)
IMAGE_TOTAL_TIMEOUT = float(os.getenv("PRICEBOT_IMAGE_TOTAL_TIMEOUT_SECONDS", "15") or 15)
image_semaphore = asyncio.Semaphore(max(1, IMAGE_CONCURRENCY))


def log(event: str, **kw) -> None:
    safe = []
    for k, v in kw.items():
        if any(x in k.lower() for x in ["token", "secret", "authorization"]):
            v = "HIDDEN"
        if k in {"phone", "to", "from_"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        safe.append(f"{k}={v}")
    print(event + (" | " + " | ".join(safe) if safe else ""), flush=True)




def _vision_alias_candidate_texts(extracted: Dict) -> List[str]:
    """Foreground-only texts eligible for exact product_aliases lookup.

    Background and ingredients are intentionally excluded so an ingredient such
    as Folic Acid cannot override the real foreground product title.
    """
    parts: List[str] = []
    for key in [
        "query",
        "foreground_product_text",
        "foreground_text",
        "primary_title",
        "product_name",
    ]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    combo = " ".join(str((extracted or {}).get(k) or "").strip() for k in ["brand", "primary_title", "form", "strength", "size", "pack"] if str((extracted or {}).get(k) or "").strip())
    if combo and combo not in parts:
        parts.insert(0, combo)
    # raw_vision_text may contain ingredients/background. Use it only when no
    # background/ingredients were separately reported by the validator.
    if not str((extracted or {}).get("background_text") or "").strip() and not (extracted or {}).get("ingredients"):
        raw = str((extracted or {}).get("raw_vision_text") or "").strip()
        if raw and raw not in parts:
            parts.append(raw)
    return parts


def _image_confirmation_text(product: Dict, prefix: str = "هل هذا المنتج؟") -> str:
    name = product.get("canonical_display_name") or product.get("name") or "المنتج"
    details = []
    for key in ["form", "strength", "size", "pack"]:
        if product.get(key):
            details.append(str(product.get(key)))
    suffix = (" - " + " / ".join(details)) if details else ""
    return f"{prefix}\n\n1. {name}{suffix}\n\nاضغط نعم لعرض السعر والتوفر، أو لا لإرسال الاسم يدويًا."



def _vision_has_product_identity_evidence(extracted: Dict) -> bool:
    """Return True when Vision supplied more than a brand label.

    Image confirmation is allowed only for a real product candidate.  Brand-only
    OCR such as "LA ROCHE-POSAY" must become clarification/options, never a
    yes/no confirmation for a synthetic brand row.
    """
    if not extracted:
        return False
    product_keys = [
        "primary_title", "product_name", "product_family",
        "foreground_product_text", "foreground_text", "main_visible_product",
        "form", "strength", "size", "pack",
    ]
    brand = normalize_text(extracted.get("brand") or "")
    values = [str(extracted.get(k) or "").strip() for k in product_keys]
    for value in values:
        if not value:
            continue
        value_norm = normalize_text(value)
        # A repeated brand in title/foreground is still brand-only.
        if value_norm and value_norm != brand:
            return True
    return False


def _set_pending_image_product(phone: str, product: Dict, *, query: str, image_hash: str, media_id: str, extracted: Dict, source: str, **extra) -> None:
    pid = int(product.get("id") or 0)
    if not pid:
        return
    payload = {
        "state": "WAITING_FOR_IMAGE_CONFIRMATION",
        "pending_product_id": pid,
        # Keep product_id for backward-compatible UI payloads, but all "yes"
        # handling now reads pending_product_id first.
        "product_id": pid,
        "confirmation_query": product.get("canonical_display_name") or product.get("name") or query or "",
        "image_hash": image_hash,
        "media_id": media_id,
        "extracted_slots": extracted,
        "source": source,
    }
    payload.update({k: v for k, v in extra.items() if v is not None})
    database.set_state(phone, payload)
def rate_limit_ok(phone: str) -> bool:
    now = time.time()
    b = rate_buckets[phone]
    while b and now - b[0] > RATE_LIMIT_WINDOW:
        b.popleft()
    if len(b) >= RATE_LIMIT_MESSAGES:
        return False
    b.append(now)
    return True


def cleanup_user_locks() -> None:
    now = time.time()
    stale = [phone for phone, ts in user_lock_last_seen.items() if now - ts > USER_LOCK_TTL_SECONDS]
    for phone in stale:
        lock = user_locks.get(phone)
        if lock is not None and lock.locked():
            continue
        user_locks.pop(phone, None)
        user_lock_last_seen.pop(phone, None)
    if stale:
        log("USER_LOCK_CLEANUP", removed=len(stale), active=len(user_locks))


def get_user_lock(phone: str) -> asyncio.Lock:
    cleanup_user_locks()
    lock = user_locks.get(phone)
    if lock is None:
        lock = asyncio.Lock()
        user_locks[phone] = lock
    user_lock_last_seen[phone] = time.time()
    return lock


def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET:
        return False
    if not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


async def send_whatsapp_message(to_number: str, text: str) -> bool:
    if not text:
        return False
    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number, text=text[:120])
        return True
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": text[:3900]}}
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_ERROR", status=resp.status_code, response=resp.text[:200])
            return False
        return True
    except Exception as exc:
        log("SEND_EXCEPTION", error=repr(exc))
        return False


async def send_whatsapp_payload(to_number: str, payload: Dict) -> bool:
    if not META_TOKEN or not PHONE_ID:
        log("SEND_INTERACTIVE_SKIPPED_NO_META", to=to_number)
        return False
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    try:
        assert http_client is not None
        resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
        if resp.status_code >= 400:
            log("SEND_INTERACTIVE_ERROR", status=resp.status_code, response=resp.text[:200])
            return False
        return True
    except Exception as exc:
        log("SEND_INTERACTIVE_EXCEPTION", error=repr(exc))
        return False


async def send_reply_with_optional_interactive(to_number: str, text: str) -> bool:
    # Premium WhatsApp UI: all navigation and selection states are sent as
    # WhatsApp buttons/lists. Plain text remains only as a transport fallback
    # and for direct user search text / product photos.
    payload = None
    try:
        payload = ui_flow.build_interactive_payload(to_number, text)
    except Exception as exc:
        log("INTERACTIVE_BUILD_WARNING", error=repr(exc))
    if payload and await send_whatsapp_payload(to_number, payload):
        return True
    return await send_whatsapp_message(to_number, text)


async def notify_admin(text: str) -> None:
    if ADMIN_NOTIFY_PHONE:
        await send_whatsapp_message(ADMIN_NOTIFY_PHONE, text)


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not META_TOKEN:
        return b"", "image/jpeg"
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    assert http_client is not None
    meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
    meta.raise_for_status()
    info = meta.json()
    url = info.get("url", "")
    mime = info.get("mime_type", "image/jpeg")
    if not url:
        return b"", mime
    data = await http_client.get(url, headers=headers, timeout=20)
    data.raise_for_status()
    return data.content, mime


def extract_messages(payload: Dict) -> List[Dict]:
    out: List[Dict] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        text = (inter.get("button_reply") or {}).get("id") or (inter.get("button_reply") or {}).get("title") or ""
                    elif inter.get("type") == "list_reply":
                        text = (inter.get("list_reply") or {}).get("id") or (inter.get("list_reply") or {}).get("title") or ""
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out


def _number_choice(text: str) -> Optional[int]:
    t = normalize_text(text)
    if t.isdigit():
        n = int(t)
        if 1 <= n <= 999:
            return n
    return None


def _main_sections_for_state() -> List[str]:
    return guided_commerce.available_main_sections() or guided_commerce.MAIN_SECTIONS


def _sub_sections_for_state(main: str) -> List[str]:
    return guided_commerce.available_sub_sections(main)


def _products_by_ids(ids: List[int]) -> List[Dict]:
    out = []
    for pid in ids:
        p = database.get_product(int(pid))
        if p and database.product_visible(p, guided=False):
            out.append(p)
    return out


def _show_product_list(phone: str, products_list: List[Dict], page: int = 0) -> str:
    ids = [int(p["id"]) for p in products_list if p.get("id")]
    database.set_state(phone, {"mode": "product_list", "ids": ids, "page": page})
    return orders.format_product_list(products_list, page=page)


def _show_guided_products(phone: str, main: str, sub: str, skin_type: str = "", page: int = 0) -> str:
    # Load more than one page into state, but keep DB query bounded.
    plist = database.guided_products(main, sub, skin_type=skin_type, page=0, page_size=80)
    # Apply stricter skincare filter after DB index for safety.
    plist = [p for p in plist if guided_commerce.product_allowed_in_subsection(p, main, sub, skin_type)]
    if not plist:
        database.clear_state(phone)
        return "لا توجد منتجات متوفرة حاليًا في هذا الاختيار."
    return _show_product_list(phone, plist, page=page)


def _handle_search_result(phone: str, result) -> str:
    if result.status == "EXACT_MATCH" and result.product:
        database.set_state(phone, {"mode": "product_details", "product_id": int(result.product["id"])})
        return orders.format_product_details(result.product)
    if result.status == "COSMETIC_ALTERNATIVES" and result.products:
        return (result.message + "\n\n" if result.message else "") + _show_product_list(phone, result.products, page=0)
    if result.status == "ASK_CLARIFICATION":
        state = {"mode": "awaiting_clarification", "pending_query": ""}
        if result.products:
            state["candidate_ids"] = [int(p["id"]) for p in result.products if p.get("id")]
        database.set_state(phone, state)
        return result.message or "أحتاج تفاصيل أكثر قبل عرض السعر."
    if result.status == "NOT_AVAILABLE":
        database.clear_state(phone)
        return result.message or "المنتج المطلوب غير موجود في قائمة الصيدلية حاليًا."
    return result.message or "لم أستطع تحديد المنتج بدقة. اكتب الاسم الكامل."


async def process_text(phone: str, text: str) -> str:
    return ui_flow.handle_text(phone, text)


async def process_image(phone: str, media_id: str) -> str:
    log("IMAGE_RECEIVED", phone=phone)
    await send_whatsapp_message(phone, "🔍 جاري فحص الصورة، انتظر لحظات...")
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return "تعذر تحميل الصورة. الرجاء إرسال صورة أوضح أو كتابة اسم المنتج.\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."

    image_hash = hashlib.sha256(image_bytes or b"").hexdigest() if image_bytes else ""

    # Production-safe cache policy: trust only cache entries saved after explicit
    # user confirmation.  Older pre-confirmation image caches are ignored.
    cached = database.get_image_cache(image_hash=image_hash, media_id=media_id)
    if cached and cached.get("decision") == "VISUAL_MEMORY_APPROVED" and cached.get("matched_product_id"):
        # Even confirmed cache entries never display price directly from a new
        # image.  They only pre-fill the candidate and still require user
        # confirmation before product details are shown.
        log("VISION_CONFIRMED_CACHE_HIT_CONFIRMATION_ONLY", decision=cached.get("decision"))
        p = database.get_product(int(cached.get("matched_product_id")))
        if p and database.product_visible(p, guided=False):
            slots = {}
            try:
                slots = json.loads(cached.get("extracted_slots") or "{}") if isinstance(cached.get("extracted_slots"), str) else (cached.get("extracted_slots") or {})
            except Exception:
                slots = {}
            try:
                memory = visual_memory.lookup_visual_memory(slots or {}, merchant_id=int(p.get("merchant_id") or 1))
                if not (memory and int(memory.get("product_id") or 0) == int(p["id"])):
                    memory = None
            except Exception:
                memory = None
            if not memory:
                log("VISION_CACHE_IGNORED_NOT_APPROVED_MEMORY", decision=cached.get("decision"))
            else:
                _set_pending_image_product(
                    phone, p, query=p.get("canonical_display_name") or p.get("name") or "",
                    image_hash=image_hash, media_id=media_id, extracted=slots,
                    source="confirmed_image_cache_pending_confirmation",
                )
                name = p.get("canonical_display_name") or p.get("name") or "المنتج"
                return f"هل هذا المنتج؟\n\n1. {name}\n\nاكتب نعم أو 1 لعرض السعر والتوفر. اكتب لا لإرسال اسم المنتج يدويًا."

    try:
        async with image_semaphore:
            extracted = await asyncio.wait_for(
                vision_service.extract_product_from_image(image_bytes, mime),
                timeout=IMAGE_TOTAL_TIMEOUT,
            )
    except asyncio.TimeoutError:
        log("VISION_TIMEOUT", phone=phone)
        try:
            database.record_learning_event(
                customer_query="", vision_text="", decision="IMAGE_UNCLEAR",
                reason="vision_timeout", media_id=media_id,
                query_slots={"image_hash": image_hash},
            )
        except Exception:
            pass
        return "الصورة لم تُقرأ في الوقت المناسب. اكتب اسم المنتج من فضلك.\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."

    if extracted.get("status") != "OK":
        log("VISION_MATCH_DECISION", decision=extracted.get("status") or "IMAGE_UNCLEAR")
        try:
            database.record_learning_event(
                customer_query=str(extracted.get("query") or ""),
                vision_text=str(extracted.get("raw_vision_text") or extracted.get("visible_text") or ""),
                decision=extracted.get("status") or "IMAGE_UNCLEAR",
                reason=str(extracted.get("vision_validation") or extracted.get("message") or "vision_rejected"),
                media_id=media_id,
                main_visible_product=str(extracted.get("primary_title") or extracted.get("foreground_product_text") or ""),
                background_text=str(extracted.get("background_text") or ""),
                query_slots={**extracted, "image_hash": image_hash},
            )
        except Exception:
            pass
        return (extracted.get("message") or "الصورة غير واضحة. الرجاء إرسال صورة أوضح للواجهة الأمامية للمنتج.") + "\n\nاكتب \"القائمة\" للرجوع للقائمة الرئيسية."

    query = extracted.get("query", "")
    log("VISION_RESULT", extracted_name=query[:120], confidence=extracted.get("confidence", ""))
    brand_only_vision = bool(normalize_text(extracted.get("brand") or "")) and not _vision_has_product_identity_evidence(extracted)

    # Bad JSON recovery can only ask for user confirmation; no price is shown
    # from recovered raw text.
    if extracted.get("needs_confirmation_only"):
        database.set_state(phone, {
            "state": "WAITING_FOR_IMAGE_CONFIRMATION",
            "confirmation_query": query,
            "image_hash": image_hash,
            "media_id": media_id,
            "extracted_slots": extracted,
            "source": "bad_json_title_only",
        })
        return (extracted.get("message") or f"هل تقصد {query}؟") + "\n\nاكتب نعم للمتابعة أو لا لإرسال اسم المنتج يدويًا."

    # AI-generated alias lookup from foreground Vision text before LOW_CONFIDENCE.
    # Stages: exact normalized alias, alias contained in Vision text, then alias
    # tokens subset of Vision tokens.  This remains a confirmation shortcut only:
    # it never displays price or availability until the user confirms/selects.
    try:
        alias_hit = database.lookup_product_by_alias_image_text(_vision_alias_candidate_texts(extracted), ignore_articles=True)
    except Exception as exc:
        log("VISION_ALIAS_LOOKUP_WARNING", error=repr(exc))
        alias_hit = {"status": "ERROR"}
    if alias_hit.get("status") in {"PRODUCT_ALIAS_MATCH", "EXACT_ALIAS_MATCH", "EXACT_PRODUCT_ALIAS", "SINGLE_TOKEN_PRODUCT_ALIAS"} and alias_hit.get("product"):
        product_id = alias_hit.get("product_id") or alias_hit.get("product_db_id")
        product = alias_hit.get("product")
        if product_id and (not product or int(product.get("id") or 0) != int(product_id)):
            product = database.get_product(int(product_id)) or product
        if product and product.get("id") and database.product_visible(product, guided=False):
            _set_pending_image_product(
                phone, product, query=query, image_hash=image_hash, media_id=media_id,
                extracted=extracted, source="ai_generated_alias_pending_confirmation",
                alias_match_stage=alias_hit.get("match_stage"),
            )
            log("VISION_ALIAS_CONFIRMATION_ONLY", product_id=int(product["id"]), stage=alias_hit.get("match_stage"))
            return _image_confirmation_text(product)
    elif alias_hit.get("status") == "BRAND_ONLY":
        log("VISION_ALIAS_BRAND_ONLY_SKIPPED", brand=extracted.get("brand"), stage=alias_hit.get("match_stage"))
    elif alias_hit.get("status") == "AMBIGUOUS":
        products = [p for p in (alias_hit.get("products") or []) if p and p.get("id") and database.product_visible(p, guided=False)]
        if products:
            log("VISION_ALIAS_AMBIGUOUS_OPTIONS", product_ids=alias_hit.get("product_ids"), stage=alias_hit.get("match_stage"))
            return ui_flow.handle_search_result(
                phone,
                SearchResult(
                    "ASK_CLARIFICATION",
                    "وجدت أكثر من احتمال من نص الصورة. اختر المنتج الصحيح، ولن يظهر السعر إلا بعد الاختيار.",
                    products=products[:4],
                ),
                original_query=query,
            )
        log("VISION_ALIAS_AMBIGUOUS_IGNORED", product_ids=alias_hit.get("product_ids"), stage=alias_hit.get("match_stage"))

    result = matcher.match_vision_slots(extracted)
    log("VISION_MATCH_DECISION", decision=result.status)

    if brand_only_vision and result.status == "EXACT_MATCH":
        # A brand-only image can list products/ask, but must never become a
        # single confirmation.
        result = SearchResult(
            "ASK_CLARIFICATION",
            "الصورة أظهرت اسم العلامة فقط. اختر المنتج الكامل أو اكتب اسمه.",
            products=(result.products or ([result.product] if result.product else [])),
        )

    if result.products:
        result.products = result.products[:4]
    if result.status == "EXACT_MATCH" and result.product and result.product.get("id"):
        # Image exact identity still requires explicit confirmation before price.
        product = result.product
        _set_pending_image_product(
            phone, product, query=query, image_hash=image_hash, media_id=media_id,
            extracted=extracted, source="vision_exact_pending_confirmation",
        )
        return _image_confirmation_text(product)

    return ui_flow.handle_search_result(phone, result, original_query=query)


async def worker(worker_id: int) -> None:
    while True:
        item = await queue.get()
        try:
            phone = item["phone"]
            if not rate_limit_ok(phone):
                await send_whatsapp_message(phone, "وصلت رسائل كثيرة بسرعة. الرجاء المحاولة بعد قليل.")
                continue
            if item.get("id") and not database.mark_processed(item.get("id")):
                continue
            lock = get_user_lock(phone)
            async with lock:
                user_lock_last_seen[phone] = time.time()
                log("USER_LOCK_ACQUIRED", phone=phone, worker=worker_id)
                if item.get("type") == "image" or item.get("media_id"):
                    reply = await process_image(phone, item.get("media_id"))
                else:
                    log("MESSAGE_RECEIVED", phone=phone, text=str(item.get("text", ""))[:80])
                    reply = await process_text(phone, item.get("text", ""))
                await send_reply_with_optional_interactive(phone, reply)
                user_lock_last_seen[phone] = time.time()
        except Exception as exc:
            log("WORKER_ERROR", worker=worker_id, error=repr(exc))
            try:
                await send_whatsapp_message(item.get("phone", ""), "حدث خطأ مؤقت. الرجاء المحاولة مرة أخرى.")
            except Exception:
                pass
        finally:
            queue.task_done()


@app.on_event("startup")
async def startup() -> None:
    global http_client
    admin.validate_admin_config(strict=True)
    database.init_db(run_production_guard=True)
    try:
        visual_memory.ensure_schema()
    except Exception as exc:
        log("VISUAL_MEMORY_SCHEMA_WARNING", error=repr(exc))
    try:
        cleanup_stats = database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30))
        log("RUNTIME_CLEANUP", **cleanup_stats)
    except Exception as exc:
        log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
    try:
        matcher.preload_search_index()
    except Exception as exc:
        log("SEARCH_INDEX_PRELOAD_WARNING", error=repr(exc))
    http_client = httpx.AsyncClient()
    for i in range(WORKERS):
        asyncio.create_task(worker(i + 1))
    log("PRICEBOT_STARTED", workers=WORKERS, products=database.count_products(), vision="enabled" if config_env.vision_enabled() else config_env.vision_disabled_reason(), booking="enabled" if config_env.booking_enabled() else "disabled")


@app.on_event("shutdown")
async def shutdown() -> None:
    if http_client:
        await http_client.aclose()


@app.get("/health")
def health():
    # Lightweight liveness probe only. It intentionally avoids integrity_check
    # and index scans so monitoring cannot slow normal WhatsApp replies.
    # products_count is a simple COUNT(*) used for quick sanity only.
    return {
        "ok": True,
        "service": "pricebot",
        "status": "alive",
        "products_count": database.count_products(),
        "queue_size": queue.qsize(),
        "workers": WORKERS,
        "user_locks_active": len(user_locks),
    }


@app.get("/deep-health")
@app.get("/health/deep")
def deep_health():
    # Heavy diagnostics are kept separate from /health.
    return {
        "ok": True,
        "products_count": database.count_products(),
        "integrity": database.integrity_check(),
        "search_index_count": database.count_table("product_search_index"),
        "guided_index_count": database.count_table("guided_catalog_index"),
        "processed_messages_count": database.count_table("processed_messages"),
        "conversation_state_count": database.count_table("conversation_state"),
        "queue_size": queue.qsize(),
        "workers": WORKERS,
        "user_locks_active": len(user_locks),
    }


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


def _use_celery_workers() -> bool:
    return str(os.getenv("PRICEBOT_USE_CELERY", "")).strip().lower() in {"1", "true", "yes", "on"}


def enqueue_message_fast(msg: Dict) -> bool:
    """Queue message without blocking webhook processing.

    Production can enable PRICEBOT_USE_CELERY=1 to route work to Redis/Celery
    workers. Local/single-server deployments fall back to the in-process queue.
    """
    if _use_celery_workers():
        try:
            if (msg.get("type") == "image" or msg.get("media_id")) and celery_vision_task is not None:
                celery_vision_task.delay(msg)
                return True
            if celery_text_task is not None:
                celery_text_task.delay(msg)
                return True
        except Exception as exc:
            log("CELERY_ENQUEUE_WARNING", error=repr(exc))
    try:
        queue.put_nowait(msg)
        return True
    except asyncio.QueueFull:
        log("QUEUE_FULL", phone=msg.get("phone"))
        try:
            asyncio.create_task(send_whatsapp_message(msg.get("phone", ""), "النظام مشغول حاليًا. تم استلام رسالتك وسنحاول معالجتها بعد قليل."))
        except Exception:
            pass
        return False


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    body = await request.body()
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        return PlainTextResponse("bad signature", status_code=403)
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json"}, status_code=400)
    messages = extract_messages(payload)
    queued = 0
    dropped = 0
    for msg in messages:
        if enqueue_message_fast(msg):
            queued += 1
        else:
            dropped += 1
    return {"ok": True, "queued": queued, "busy": dropped, "worker_mode": "celery" if _use_celery_workers() else "in_process"}
