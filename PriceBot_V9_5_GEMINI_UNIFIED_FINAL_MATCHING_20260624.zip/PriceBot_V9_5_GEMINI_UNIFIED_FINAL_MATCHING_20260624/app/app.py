from __future__ import annotations

import asyncio
import copy
import hashlib
import hmac
import json
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse

import config_env

config_env.load_environment()

import database
import vision_service
import gemini_final_matcher
from matcher_index import ProductIndex, looks_like_prescription, product_name, product_price, tokens as product_tokens
from normalizer import normalize_text
from text_query_understanding import extract_product_query_from_customer_text, inventory_phonetic_candidates
from state_store import RuntimeState, RedisTtlRateLimiter

META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN") or os.getenv("META_TOKEN") or os.getenv("WHATSAPP_TOKEN") or ""
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID") or os.getenv("PHONE_NUMBER_ID") or ""
VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN") or os.getenv("META_VERIFY_TOKEN") or os.getenv("VERIFY_TOKEN") or "pricebot_verify_2026"
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
REQUIRE_SIGNATURE = str(os.getenv("PRICEBOT_REQUIRE_META_SIGNATURE", "")).lower() in {"1", "true", "yes", "on"}
GRAPH_VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v20.0")
PHARMACY_NAME = os.getenv("PHARMACY_NAME", "الصيدلية")
PRICEBOT_CURRENCY = os.getenv("PRICEBOT_CURRENCY", "د.ل")

TEXT_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_TEXT_QUEUE_MAXSIZE", os.getenv("PRICEBOT_QUEUE_MAXSIZE", "8000")) or 8000)
IMAGE_QUEUE_MAXSIZE = int(os.getenv("PRICEBOT_IMAGE_QUEUE_MAXSIZE", "1500") or 1500)
TEXT_WORKERS = int(os.getenv("PRICEBOT_TEXT_WORKERS", "20") or 20)
IMAGE_WORKERS = int(os.getenv("PRICEBOT_IMAGE_WORKERS", "6") or 6)
IMAGE_CONCURRENCY = int(os.getenv("PRICEBOT_IMAGE_CONCURRENCY", "5") or 5)
IMAGE_TOTAL_TIMEOUT = float(os.getenv("PRICEBOT_IMAGE_TOTAL_TIMEOUT_SECONDS", "18") or 18)
RATE_LIMIT_MESSAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_MESSAGES", "90") or 90)
RATE_LIMIT_IMAGES = int(os.getenv("PRICEBOT_RATE_LIMIT_IMAGES", "15") or 15)
RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_RATE_LIMIT_WINDOW_SECONDS", "60") or 60)
PRODUCT_INDEX_TTL = int(os.getenv("PRICEBOT_PRODUCT_INDEX_TTL_SECONDS", "300") or 300)
MAX_LIST_ROWS = min(10, int(os.getenv("PRICEBOT_MAX_LIST_ROWS", "10") or 10))
MAX_LIST_MESSAGES = int(os.getenv("PRICEBOT_MAX_LIST_MESSAGES", "3") or 3)
STATE_TTL = int(os.getenv("PRICEBOT_USER_STATE_TTL_SECONDS", "7200") or 7200)
CONFIRM_TTL = int(os.getenv("PRICEBOT_CONFIRMATION_TTL_SECONDS", "900") or 900)
GLOBAL_RATE_LIMIT_REQUESTS = int(os.getenv("PRICEBOT_GLOBAL_RATE_LIMIT_REQUESTS", "600") or 600)
GLOBAL_RATE_LIMIT_WINDOW = int(os.getenv("PRICEBOT_GLOBAL_RATE_LIMIT_WINDOW_SECONDS", "60") or 60)
QUEUE_ITEM_TIMEOUT = float(os.getenv("PRICEBOT_QUEUE_ITEM_TIMEOUT_SECONDS", "45") or 45)
SHUTDOWN_DRAIN_TIMEOUT = float(os.getenv("PRICEBOT_SHUTDOWN_DRAIN_TIMEOUT_SECONDS", "15") or 15)
WEBHOOK_BUSY_STATUS_CODE = int(os.getenv("PRICEBOT_WEBHOOK_BUSY_STATUS_CODE", "503") or 503)
CUSTOMER_BUSY_MESSAGE = os.getenv("PRICEBOT_CUSTOMER_BUSY_MESSAGE", "النظام مشغول حاليًا. حاول بعد قليل.")


BTN_SEARCH_TEXT = "BTN_SEARCH_TEXT"
BTN_SEARCH_IMAGE = "BTN_SEARCH_IMAGE"
BTN_CONFIRM_YES = "CONFIRM_YES"
BTN_CONFIRM_NO = "CONFIRM_NO"
UNSUPPORTED_MEDIA_TOKEN = "__UNSUPPORTED_MEDIA__"
FINAL_UI_VERSION = "V9.5_GEMINI_UNIFIED_FINAL_MATCHING"

app = FastAPI(title="PriceBot WhatsApp V9 Production PostgreSQL Final", docs_url=None, redoc_url=None, openapi_url=None)
text_queue: asyncio.Queue = asyncio.Queue(maxsize=TEXT_QUEUE_MAXSIZE)
image_queue: asyncio.Queue = asyncio.Queue(maxsize=IMAGE_QUEUE_MAXSIZE)
http_client: Optional[httpx.AsyncClient] = None
image_semaphore = asyncio.Semaphore(max(1, IMAGE_CONCURRENCY))
state = RuntimeState(namespace=os.getenv("PRICEBOT_STATE_NAMESPACE", "pricebot"), mode_ttl=STATE_TTL, confirmation_ttl=CONFIRM_TTL)
product_index = ProductIndex(ttl_seconds=PRODUCT_INDEX_TTL)
text_limiter = RedisTtlRateLimiter(state, "user_text", RATE_LIMIT_WINDOW, RATE_LIMIT_MESSAGES)
image_limiter = RedisTtlRateLimiter(state, "user_image", RATE_LIMIT_WINDOW, RATE_LIMIT_IMAGES)
global_limiter = RedisTtlRateLimiter(state, "webhook_global", GLOBAL_RATE_LIMIT_WINDOW, GLOBAL_RATE_LIMIT_REQUESTS)
background_tasks: List[asyncio.Task] = []

RUNTIME_METRICS: Dict[str, int] = {
    "webhooks_total": 0,
    "webhooks_bad_signature": 0,
    "webhooks_rate_limited": 0,
    "messages_queued_total": 0,
    "messages_queue_full_total": 0,
    "messages_expired_total": 0,
    "messages_processed_total": 0,
    "messages_failed_total": 0,
    "whatsapp_send_success_total": 0,
    "whatsapp_send_failed_total": 0,
}
STARTED_AT = time.time()
STARTUP_WARNINGS: List[str] = []


def metric_inc(name: str, count: int = 1) -> None:
    try:
        RUNTIME_METRICS[name] = int(RUNTIME_METRICS.get(name, 0)) + int(count or 1)
    except Exception:
        pass


_DIGITS_TRANS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def log(event: str, **kw: Any) -> None:
    payload: Dict[str, Any] = {"ts": round(time.time(), 3), "event": str(event or "EVENT")}
    for k, v in kw.items():
        key = str(k)
        if any(x in key.lower() for x in ["token", "secret", "authorization", "key"]):
            v = "HIDDEN"
        if key in {"phone", "to", "from_", "from"}:
            s = re.sub(r"\D+", "", str(v or ""))
            v = f"{s[:5]}****{s[-3:]}" if len(s) > 7 else "MASKED"
        try:
            json.dumps(v, ensure_ascii=False)
        except Exception:
            v = repr(v)
        payload[key] = v
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), flush=True)


def _wa_text(body: str) -> Dict[str, Any]:
    return {"__wa_payload": {"type": "text", "text": {"body": str(body or "")[:3900]}}}


def _wa_buttons(body: str, buttons: List[Tuple[str, str]]) -> Dict[str, Any]:
    return {
        "__wa_payload": {
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": str(body or "")[:1000]},
                "action": {"buttons": [{"type": "reply", "reply": {"id": bid, "title": title[:20]}} for bid, title in buttons[:3]]},
            },
        }
    }


def _welcome_menu() -> Dict[str, Any]:
    return _wa_buttons(
        f"مرحبًا بك في {PHARMACY_NAME} 🌿\n\nاختر طريقة البحث عن توفر وسعر الدواء أو المنتج:",
        [(BTN_SEARCH_TEXT, "بحث باسم دواء"), (BTN_SEARCH_IMAGE, "بحث بصورة")],
    )


def _ask_text() -> Dict[str, Any]:
    return _wa_buttons("🔎 اكتب اسم المنتج فقط. اكتب الاسم كاملًا قدر الإمكان", [(BTN_SEARCH_IMAGE, "بحث بالصورة"), ("MENU", "القائمة")])


def _ask_image() -> Dict[str, Any]:
    return _wa_buttons("📷 أرسل صورة واضحة لعلبة الدواء أو المنتج فقط.", [(BTN_SEARCH_TEXT, "بحث بالاسم"), ("MENU", "القائمة")])


def _unavailable(extra: str = "") -> Dict[str, Any]:
    # Customer-facing unavailable response must stay short and must never leak OCR/Gemini text.
    return _wa_buttons("لم أجد المنتج في قائمة الصيدلية، يرجى كتابة الاسم بشكل أوضح.", [(BTN_SEARCH_TEXT, "بحث جديد"), (BTN_SEARCH_IMAGE, "بحث بصورة")])


def _prescription_payload() -> Dict[str, Any]:
    return _wa_buttons("عذرًا، لا يمكنني قراءة الروشتات الطبية. فضلاً أرسل صورة واضحة لعلبة الدواء أو المنتج فقط.", [(BTN_SEARCH_IMAGE, "بحث بصورة"), ("MENU", "القائمة")])


def _product_reply(product: Dict[str, Any]) -> Dict[str, Any]:
    price = product_price(product, PRICEBOT_CURRENCY)
    if not price:
        return _unavailable()
    return _wa_buttons(f"✅ متوفر\nالسعر: {price}\n\nهل تحتاج مساعدة أخرى؟", [(BTN_SEARCH_TEXT, "بحث جديد"), ("MENU", "القائمة")])


def _short(value: str, limit: int) -> str:
    value = re.sub(r"\s+", " ", str(value or "")).strip()
    return value if len(value) <= limit else value[:limit - 1].rstrip() + "…"


def _product_list(candidates: List[Dict[str, Any]], *, start: int = 0, title: str = "المنتجات المتوفرة") -> Dict[str, Any]:
    rows = []
    for p in candidates[start:start + MAX_LIST_ROWS]:
        pid = int(p.get("id") or 0)
        name = product_name(p)
        price = product_price(p, PRICEBOT_CURRENCY)
        rows.append({"id": f"PROD:{pid}", "title": _short(name, 24), "description": _short(f"{price} - {name}" if price else name, 72)})
    body = "وجدت أكثر من منتج متوفر بهذا الاسم. اختر المنتج المطلوب من القائمة:"
    return {"__wa_payload": {"type": "interactive", "interactive": {"type": "list", "body": {"text": body}, "action": {"button": "اختر المنتج", "sections": [{"title": title[:24], "rows": rows}]}}}}


def _product_lists(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    payloads: List[Dict[str, Any]] = []
    pages = min(MAX_LIST_MESSAGES, (len(candidates) + MAX_LIST_ROWS - 1) // MAX_LIST_ROWS)
    for i in range(pages):
        payloads.append(_product_list(candidates, start=i * MAX_LIST_ROWS, title=f"القائمة {i + 1}"))
    if len(candidates) > pages * MAX_LIST_ROWS:
        payloads.append(_wa_text("ظهرت نتائج كثيرة. اكتب الاسم بشكل أدق إذا لم تجد المنتج المطلوب."))
    return payloads


def _confirm_payload(product: Dict[str, Any]) -> Dict[str, Any]:
    return _wa_buttons(f"هل تقصد هذا المنتج؟\n{product_name(product)}\n\nاختر نعم للتأكيد أو لا لإعادة المحاولة.", [(BTN_CONFIRM_YES, "نعم"), (BTN_CONFIRM_NO, "لا")])


def _is_menu(raw: str) -> bool:
    n = normalize_text(raw or "")
    return n in {"", "السلام عليكم", "سلام", "مرحبا", "اهلا", "أهلا", "hi", "hello", "menu", "start", "القائمة", "القائمه", "menu"}


def _is_text_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_TEXT), "بحث باسم دواء", "بحث بنص", "بحث نص", "بحث بالاسم", "اسم", "1"}


def _is_image_button(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_SEARCH_IMAGE), "بحث بصورة", "بحث صوره", "صورة", "صوره", "2"}


def _is_yes(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_CONFIRM_YES), "نعم", "اي", "ايوة", "أيوة", "تمام", "صح", "yes", "y", "ok", "1"}


def _is_no(raw: str) -> bool:
    n = normalize_text(str(raw or "").translate(_DIGITS_TRANS))
    return n in {normalize_text(BTN_CONFIRM_NO), "لا", "لأ", "مش هو", "غلط", "no", "n", "0"}


def _dedupe_text_queries(values: List[str], *, limit: int = 80) -> List[str]:
    out: List[str] = []
    seen = set()
    for value in values:
        q = re.sub(r"\s+", " ", str(value or "")).strip()
        if not q:
            continue
        key = normalize_text(q)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(q)
        if len(out) >= limit:
            break
    return out


async def _search_text_query_candidates(raw: str, *, limit: int) -> Tuple[List[Dict[str, Any]], str]:
    """Understand free-form customer text, then search current available inventory.

    This layer is deliberately placed in app.py's text path before the unavailable
    decision.  It does not touch Gemini/Vision, WhatsApp UX, or database writes.
    """
    raw = str(raw or "").strip()
    extracted = extract_product_query_from_customer_text(raw)
    log("TEXT_QUERY_EXTRACTED", original=raw[:180], candidates=extracted[:30])

    # ProductIndex is already built from database.load_product_rows(visible_only=True),
    # which enforces is_available/available + price + visibility rules.
    await product_index.ensure_fresh()

    phonetic_matches = inventory_phonetic_candidates(product_index, extracted or [raw], max_results=8)
    phonetic_by_query = {m.query: m for m in phonetic_matches}

    search_queries = _dedupe_text_queries(extracted + [raw] + [m.query for m in phonetic_matches])
    for query in search_queries:
        try:
            candidates = await product_index.search(query, limit=limit)
        except Exception as exc:
            log("TEXT_QUERY_SEARCH_ERROR", candidate=query[:120], error=repr(exc))
            continue
        if not candidates:
            continue
        top = candidates[0]
        pscore = top.get("_score")
        match = phonetic_by_query.get(query)
        score_value: Any = round(float(match.score), 4) if match else pscore
        log(
            "TEXT_QUERY_MATCH",
            candidate=query[:120],
            product=product_name(top)[:160],
            score=score_value,
            source="phonetic_inventory" if match else "product_index",
            count=len(candidates),
        )
        return candidates, query

    return [], (extracted[0] if extracted else raw)


async def _lookup_text_memory_candidates(raw: str) -> Tuple[Optional[Dict[str, Any]], str]:
    extracted = extract_product_query_from_customer_text(raw)
    queries = _dedupe_text_queries(extracted + [raw])
    for query in queries:
        try:
            memory = await product_index.memory_lookup(query)
        except Exception:
            memory = None
        if memory:
            return memory, query
    return None, ""


def _extract_candidate_texts(extracted: Dict[str, Any]) -> List[str]:
    parts: List[str] = []
    for key in ["query", "primary_title", "product_name", "product_family", "brand", "form", "strength", "size", "pack", "foreground_product_text", "visible_text", "raw_vision_text"]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and value not in parts:
            parts.append(value)
    return parts


def _image_evidence_text(extracted: Dict[str, Any]) -> str:
    # Identity slots first; marketing/generic package text is fallback only.
    priority = ["query", "primary_title", "product_name", "product_family", "brand", "strength", "size"]
    strong_parts = [str(extracted.get(k) or "").strip() for k in priority if str(extracted.get(k) or "").strip()]
    text = " ".join(strong_parts).strip()
    if text:
        return text
    return " ".join(_extract_candidate_texts(extracted)).strip()


def _best_primary_product_text(extracted: Dict[str, Any]) -> str:
    """Primary visual identity used for safety guards and logging."""
    for key in ["primary_title", "product_name", "product_family", "brand", "query", "foreground_product_text"]:
        value = str((extracted or {}).get(key) or "").strip()
        if value:
            return value
    return _image_evidence_text(extracted or {})


def _best_primary_identity_for_guard(extracted: Dict[str, Any]) -> str:
    """Best non-generic visible identity for post-Gemini safety guards.

    If Gemini Vision mistakenly places an ingredient like "Folic Acid 500mcg" in
    primary_title but the foreground text contains "Hemazym", this function uses
    the field that actually has a non-generic commercial token.
    """
    for key in ["primary_title", "product_name", "product_family", "query", "foreground_product_text", "raw_vision_text"]:
        value = str((extracted or {}).get(key) or "").strip()
        if value and gemini_final_matcher.identity_tokens(value):
            return value
    return _best_primary_product_text(extracted or {})


def _candidate_names(candidates: List[Dict[str, Any]], limit: int = 12) -> List[str]:
    return [product_name(p)[:90] for p in (candidates or [])[:limit]]


def _dedupe_products(candidates: List[Dict[str, Any]], limit: int = 30) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for item in candidates or []:
        try:
            pid = int(item.get("id") or 0)
        except Exception:
            pid = 0
        name = product_name(item)
        if not pid or not name or pid in seen:
            continue
        seen.add(pid)
        out.append(item)
        if len(out) >= limit:
            break
    return out


def _sort_candidates_for_rerank(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return sorted(
        candidates or [],
        key=lambda p: (-int(p.get("_score") or 0), int(p.get("_name_token_count") or 99), len(product_name(p)), product_name(p).lower()),
    )


def _is_arabic_or_ambiguous_text(raw: str, effective_query: str) -> bool:
    raw_s = str(raw or "")
    effective = str(effective_query or "")
    if re.search(r"[\u0600-\u06FF]", raw_s):
        return True
    if normalize_text(raw_s) != normalize_text(effective):
        return True
    customer_words = r"\b(available|price|do you have|need|want|medicine|product|how much)\b"
    return bool(re.search(customer_words, raw_s.lower()))


def _product_by_id_from_candidates(candidates: List[Dict[str, Any]], product_id: Any) -> Optional[Dict[str, Any]]:
    try:
        wanted = int(product_id or 0)
    except Exception:
        wanted = 0
    if not wanted:
        return None
    for p in candidates or []:
        try:
            if int(p.get("id") or 0) == wanted:
                return p
        except Exception:
            continue
    return None


def _selected_matches_primary_identity(primary_text: str, product: Dict[str, Any]) -> bool:
    """Reject image selections that do not share the main visible commercial token."""
    tokens_primary = gemini_final_matcher.identity_tokens(primary_text)
    if not tokens_primary:
        return True
    product_text = " ".join([
        product_name(product),
        str(product.get("original_name") or ""),
        str(product.get("brand") or ""),
        str(product.get("product_family") or ""),
        str(product.get("aliases") or ""),
        str(product.get("ocr_keywords") or ""),
    ])
    product_norm = normalize_text(product_text).replace(" ", "")
    for token in tokens_primary:
        t = normalize_text(token).replace(" ", "")
        if len(t) >= 3 and t in product_norm:
            return True
    return False


def _candidate_safe_for_visual_confirmation(primary_text: str, product: Dict[str, Any]) -> bool:
    if not _selected_matches_primary_identity(primary_text, product):
        return False
    score = int(product.get("_score") or 0)
    return score >= 1800 or normalize_text(primary_text) in normalize_text(product_name(product))


async def _retrieve_inventory_candidates_from_queries(
    query_inputs: List[str],
    *,
    limit: int = 30,
    log_prefix: str = "TEXT",
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Local retrieval only: produce a small available-product candidate set for Gemini reranking.

    ProductIndex is loaded from database.load_product_rows(visible_only=True), so the returned
    candidates are constrained to currently available/visible PostgreSQL products.
    """
    await product_index.ensure_fresh()
    all_queries: List[str] = []
    for raw in query_inputs or []:
        raw = str(raw or "").strip()
        if not raw:
            continue
        extracted = extract_product_query_from_customer_text(raw)
        all_queries.extend(extracted + [raw])
        try:
            phonetic_matches = inventory_phonetic_candidates(product_index, extracted or [raw], max_results=10, min_score=0.84)
            all_queries.extend(m.query for m in phonetic_matches)
        except Exception as exc:
            log(f"{log_prefix}_PHONETIC_RETRIEVAL_ERROR", error=repr(exc), input=raw[:120])
    search_queries = _dedupe_text_queries(all_queries, limit=45)

    by_id: Dict[int, Dict[str, Any]] = {}
    used_queries: List[str] = []
    per_query_limit = max(10, min(limit, 30))
    for query in search_queries:
        try:
            found = await product_index.search(query, limit=per_query_limit)
        except Exception as exc:
            log(f"{log_prefix}_CANDIDATE_RETRIEVAL_ERROR", query=query[:120], error=repr(exc))
            continue
        if not found:
            continue
        used_queries.append(query[:120])
        for item in found:
            try:
                pid = int(item.get("id") or 0)
            except Exception:
                pid = 0
            if not pid:
                continue
            current = by_id.get(pid)
            if current is None or int(item.get("_score") or 0) > int(current.get("_score") or 0):
                by_id[pid] = dict(item)
        if len(by_id) >= limit * 2:
            break
    ranked = _sort_candidates_for_rerank(list(by_id.values()))
    return _dedupe_products(ranked, limit=limit), used_queries


async def _text_gemini_final_decision(
    *,
    phone: str,
    raw: str,
    effective_query: str,
    candidates: List[Dict[str, Any]],
) -> Optional[Any]:
    """Gemini is the final selector for every customer product text query.

    Local matching is used only to retrieve a bounded candidate list from the
    available PostgreSQL catalog.  It must never return the final product by
    itself in this path.
    """
    if not candidates:
        log("USER_TEXT", value=str(raw or "")[:180])
        log("NORMALIZED_QUERY", value=normalize_text(effective_query)[:180])
        log("PRODUCTS_SENT_TO_GEMINI", count=0, names=[])
        log("FINAL_DECISION", value="no_candidates_before_gemini")
        return _unavailable()

    extracted = extract_product_query_from_customer_text(raw)
    extracted_queries = _dedupe_text_queries(extracted + [effective_query, raw], limit=30)
    log("USER_TEXT", value=str(raw or "")[:180])
    log("NORMALIZED_QUERY", value=normalize_text(effective_query)[:180])
    log("PRODUCTS_SENT_TO_GEMINI", count=len(candidates[:30]), names=_candidate_names(candidates[:30], limit=30))

    decision = await gemini_final_matcher.select_text_match(
        original_text=raw,
        extracted_queries=extracted_queries,
        candidates=candidates[:30],
    )
    log("GEMINI_SELECTED_PRODUCT", selected=decision.selected_product_name[:180], selected_product_id=decision.selected_product_id)
    log("GEMINI_CONFIDENCE", value=round(decision.confidence, 4), decision=decision.decision, reason=decision.reason[:180])
    log(
        "TEXT_GEMINI_FINAL_MATCH",
        selected=decision.selected_product_name[:160],
        selected_product_id=decision.selected_product_id,
        confidence=round(decision.confidence, 4),
        decision=decision.decision,
        reason=decision.reason[:180],
    )
    selected = _product_by_id_from_candidates(candidates, decision.selected_product_id)
    if decision.is_match and selected:
        log("FINAL_PRODUCT_ID", value=int(selected.get("id") or 0))
        log("FINAL_PRODUCT_NAME", value=product_name(selected)[:180])
        log("FINAL_PRICE", value=product_price(selected, PRICEBOT_CURRENCY)[:80])
        log("FINAL_DECISION", value="match", source="text_gemini")
        return _product_reply(selected)

    if decision.is_confirmation and selected:
        # Gemini judged that the intended commercial product is likely but the
        # exact variant/pack/strength is ambiguous. This is not a local fuzzy
        # decision; it is a Gemini-bounded confirmation against DB candidates.
        log("FINAL_PRODUCT_ID", value=int(selected.get("id") or 0))
        log("FINAL_PRODUCT_NAME", value=product_name(selected)[:180])
        log("FINAL_PRICE", value=product_price(selected, PRICEBOT_CURRENCY)[:80])
        log("FINAL_DECISION", value="needs_confirmation", source="text_gemini")
        return await _confirm_candidate(phone, selected, effective_query, "text_gemini_confirm")

    log("FINAL_PRODUCT_ID", value="")
    log("FINAL_PRODUCT_NAME", value="")
    log("FINAL_PRICE", value="")
    log("FINAL_DECISION", value="no_match", source="text_gemini", reason=decision.reason[:180])
    log("TEXT_GEMINI_NO_MATCH", reason=decision.reason[:180], original=raw[:120], effective_query=effective_query[:120])
    return _unavailable()

def verify_signature(body: bytes, header: str) -> bool:
    if not REQUIRE_SIGNATURE and not META_APP_SECRET:
        return True
    if not META_APP_SECRET or not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(META_APP_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)


def _transient_http_status(status_code: int) -> bool:
    return int(status_code or 0) in {408, 409, 425, 429, 500, 502, 503, 504}


async def send_whatsapp_message(to_number: str, content: Any) -> bool:
    if not content:
        return False
    if isinstance(content, list):
        ok = True
        for item in content:
            ok = (await send_whatsapp_message(to_number, item)) and ok
        return ok
    if isinstance(content, dict) and "__wa_payload" in content:
        payload = copy.deepcopy(content["__wa_payload"])
        payload["messaging_product"] = "whatsapp"
        payload["to"] = to_number
    else:
        payload = {"messaging_product": "whatsapp", "to": to_number, "type": "text", "text": {"body": str(content or "")[:3900]}}
    if not META_TOKEN or not PHONE_ID:
        log("SEND_SKIPPED_NO_META", to=to_number)
        return True
    assert http_client is not None
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}", "Content-Type": "application/json"}
    delay = 0.4
    max_attempts = int(os.getenv("PRICEBOT_WHATSAPP_SEND_RETRY_ATTEMPTS", "3") or 3)
    for attempt in range(1, max_attempts + 1):
        try:
            resp = await http_client.post(url, headers=headers, json=payload, timeout=10)
            if resp.status_code < 400:
                metric_inc("whatsapp_send_success_total")
                return True
            log("SEND_ERROR", attempt=attempt, status=resp.status_code, transient=_transient_http_status(resp.status_code), response=resp.text[:500])
            if not _transient_http_status(resp.status_code):
                metric_inc("whatsapp_send_failed_total")
                return False
        except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError) as exc:
            log("SEND_TRANSIENT_EXCEPTION", attempt=attempt, error=repr(exc))
        except Exception as exc:
            log("SEND_EXCEPTION", attempt=attempt, error=repr(exc))
            metric_inc("whatsapp_send_failed_total")
            return False
        if attempt < max_attempts:
            await asyncio.sleep(delay)
            delay = min(delay * 2, 5.0)
    metric_inc("whatsapp_send_failed_total")
    return False


def _valid_whatsapp_media_id(media_id: str) -> bool:
    value = str(media_id or "").strip()
    return bool(6 <= len(value) <= 256 and re.fullmatch(r"[A-Za-z0-9_.:-]+", value))


async def download_whatsapp_media(media_id: str) -> Tuple[bytes, str]:
    if not _valid_whatsapp_media_id(media_id):
        log("MEDIA_ID_REJECTED", media_id="invalid")
        return b"", "image/jpeg"
    if not META_TOKEN:
        return b"", "image/jpeg"
    assert http_client is not None
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    max_attempts = int(os.getenv("PRICEBOT_MEDIA_DOWNLOAD_RETRY_ATTEMPTS", "3") or 3)
    delay = 0.4
    last_mime = "image/jpeg"
    for attempt in range(1, max_attempts + 1):
        try:
            meta = await http_client.get(f"https://graph.facebook.com/{GRAPH_VERSION}/{media_id}", headers=headers, timeout=10)
            if meta.status_code >= 400:
                log("MEDIA_META_ERROR", attempt=attempt, status=meta.status_code, transient=_transient_http_status(meta.status_code))
                if not _transient_http_status(meta.status_code):
                    meta.raise_for_status()
                raise httpx.HTTPStatusError("transient media metadata status", request=meta.request, response=meta)
            info = meta.json()
            url = info.get("url", "")
            last_mime = info.get("mime_type", "image/jpeg") or "image/jpeg"
            if not url:
                return b"", last_mime
            data = await http_client.get(url, headers=headers, timeout=20)
            if data.status_code >= 400:
                log("MEDIA_DATA_ERROR", attempt=attempt, status=data.status_code, transient=_transient_http_status(data.status_code))
                if not _transient_http_status(data.status_code):
                    data.raise_for_status()
                raise httpx.HTTPStatusError("transient media data status", request=data.request, response=data)
            return data.content, last_mime
        except (httpx.TimeoutException, httpx.NetworkError, httpx.TransportError, httpx.HTTPStatusError) as exc:
            if attempt >= max_attempts:
                raise
            log("MEDIA_DOWNLOAD_RETRY", attempt=attempt, error=repr(exc))
            await asyncio.sleep(delay)
            delay = min(delay * 2, 5.0)
    return b"", last_mime


def extract_messages(payload: Dict[str, Any]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for msg in value.get("messages", []) or []:
                phone = msg.get("from", "")
                message_id = msg.get("id", "")
                mtype = msg.get("type", "")
                text = ""
                media_id = ""
                if mtype == "text":
                    text = (msg.get("text") or {}).get("body", "")
                elif mtype == "image":
                    media_id = (msg.get("image") or {}).get("id", "")
                elif mtype == "interactive":
                    inter = msg.get("interactive") or {}
                    if inter.get("type") == "button_reply":
                        br = inter.get("button_reply") or {}
                        text = br.get("id") or br.get("title") or ""
                    elif inter.get("type") == "list_reply":
                        lr = inter.get("list_reply") or {}
                        text = lr.get("id") or lr.get("title") or ""
                elif mtype in {"document", "audio", "video", "sticker"}:
                    text = UNSUPPORTED_MEDIA_TOKEN
                if phone:
                    out.append({"phone": phone, "id": message_id, "type": mtype, "text": text, "media_id": media_id})
    return out


async def _handle_confirmation(phone: str, raw: str) -> Optional[Any]:
    pending = await state.get_confirmation(phone)
    if not pending:
        return None
    if _is_no(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "awaiting_text")
        try:
            database.reject_safe_text_memory(pending.get("query", ""), int(pending.get("product_id") or 0))
        except Exception:
            pass
        return _ask_text()
    if not _is_yes(raw):
        return None
    product = database.get_product(int(pending.get("product_id") or 0))
    await state.clear_confirmation(phone)
    await state.set_mode(phone, "awaiting_text")
    if not product or not database.product_visible(product, guided=False):
        return _unavailable()
    query = str(pending.get("query") or "")
    try:
        database.add_safe_text_memory(query, int(product.get("id") or 0), source=str(pending.get("source") or "confirmed"), user_key=phone)
    except Exception as exc:
        log("MEMORY_SAVE_WARNING", error=repr(exc))
    try:
        if query:
            database.append_product_alias_or_ocr(int(product.get("id") or 0), query, field="aliases")
            await product_index.refresh(force=True)
    except Exception as exc:
        log("ALIAS_SAVE_WARNING", error=repr(exc))
    return _product_reply(product)


async def _confirm_candidate(phone: str, product: Dict[str, Any], query: str, source: str, image_hash: str = "", media_id: str = "", extracted: Optional[Dict[str, Any]] = None) -> Any:
    await state.set_confirmation(phone, {"product_id": int(product.get("id") or 0), "query": str(query or "")[:1000], "source": source, "image_hash": image_hash, "media_id": media_id, "extracted": extracted or {}})
    return _confirm_payload(product)


async def process_text(phone: str, raw: str) -> Any:
    raw = str(raw or "").strip()
    if raw == UNSUPPORTED_MEDIA_TOKEN:
        return _prescription_payload()
    confirmation_reply = await _handle_confirmation(phone, raw)
    if confirmation_reply is not None:
        return confirmation_reply
    if raw.startswith("PROD:"):
        try:
            pid = int(raw.split(":", 1)[1])
        except Exception:
            pid = 0
        product = database.get_product(pid) if pid else None
        if product and database.product_visible(product, guided=False):
            await state.set_mode(phone, "awaiting_text")
            return _product_reply(product)
        return _unavailable()
    if raw in {"MENU", "القائمة", "القائمه"} or _is_menu(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "idle")
        return _welcome_menu()
    if _is_text_button(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "awaiting_text")
        return _ask_text()
    if _is_image_button(raw):
        await state.clear_confirmation(phone)
        await state.set_mode(phone, "awaiting_image")
        return _ask_image()
    mode = await state.get_mode(phone)
    if mode != "awaiting_text":
        # Allow natural product questions without forcing the customer to press
        # "بحث باسم دواء" first. Pure greetings/menu messages are handled above.
        if not extract_product_query_from_customer_text(raw):
            await state.set_mode(phone, "idle")
            return _welcome_menu()
        await state.set_mode(phone, "awaiting_text")
    if looks_like_prescription(raw):
        return _prescription_payload()

    # V9.5: unified text flow.  The local ProductIndex is candidate retrieval only;
    # Gemini is the final decision maker for all product text, including clear
    # English names such as "Hemazym".
    extracted = extract_product_query_from_customer_text(raw)
    effective_query = extracted[0] if extracted else raw
    log("TEXT_QUERY_EXTRACTED", original=raw[:180], candidates=extracted[:30])
    candidates, retrieval_queries = await _retrieve_inventory_candidates_from_queries(
        [effective_query, raw] + extracted,
        limit=30,
        log_prefix="TEXT",
    )
    log("TEXT_CANDIDATES", count=len(candidates), names=_candidate_names(candidates, limit=30), queries=retrieval_queries[:12])
    await state.set_mode(phone, "awaiting_text")
    return await _text_gemini_final_decision(
        phone=phone,
        raw=raw,
        effective_query=effective_query,
        candidates=candidates[:30],
    )


async def process_image(phone: str, media_id: str) -> Any:
    await state.set_mode(phone, "awaiting_text")
    if not media_id:
        return _prescription_payload()
    try:
        image_bytes, mime = await download_whatsapp_media(media_id)
    except Exception as exc:
        log("IMAGE_DOWNLOAD_ERROR", error=repr(exc))
        return _prescription_payload()
    if not image_bytes:
        return _prescription_payload()
    image_hash = hashlib.sha256(image_bytes).hexdigest()
    try:
        cached = database.get_image_cache(image_hash=image_hash, media_id=media_id)
        cache_decision = str((cached or {}).get("decision") or "")
        if cached and cached.get("matched_product_id") and cache_decision.startswith("V9_5_GEMINI_UNIFIED_MATCH"):
            product = database.get_product(int(cached.get("matched_product_id") or 0))
            if product and database.product_visible(product, guided=False):
                log("IMAGE_CACHE_HIT", product_id=product.get("id"), decision=cache_decision)
                log("FINAL_PRODUCT_ID", value=int(product.get("id") or 0))
                log("FINAL_PRODUCT_NAME", value=product_name(product)[:180])
                log("FINAL_PRICE", value=product_price(product, PRICEBOT_CURRENCY)[:80])
                log("FINAL_DECISION", value="match", source="image_cache")
                return _product_reply(product)
        elif cached and cached.get("matched_product_id"):
            log("IMAGE_CACHE_IGNORED_PRE_V95", decision=cache_decision)
    except Exception as exc:
        log("IMAGE_CACHE_WARNING", error=repr(exc))
    try:
        async with image_semaphore:
            extracted = await asyncio.wait_for(vision_service.extract_product_from_image(image_bytes, mime), timeout=IMAGE_TOTAL_TIMEOUT)
    except asyncio.TimeoutError:
        return _prescription_payload()
    except Exception as exc:
        log("VISION_ERROR", error=repr(exc))
        return _prescription_payload()
    evidence = _image_evidence_text(extracted)
    if not evidence or looks_like_prescription(evidence):
        return _prescription_payload()
    status = str(extracted.get("status") or "")
    if status not in {"OK", "LOW_CONFIDENCE"} and not evidence:
        return _prescription_payload()

    # V9.5: unified image flow. Gemini Vision extracts the main commercial product
    # name; local inventory matching retrieves candidates only; Gemini final matcher
    # selects the final product from PostgreSQL candidates and price is returned directly.
    primary_product = _best_primary_product_text(extracted)
    primary_guard_text = _best_primary_identity_for_guard(extracted)
    normalized_query = normalize_text(primary_product)
    log("IMAGE_EVIDENCE", phone=phone, text=evidence[:160])
    log("IMAGE_EXTRACTED_NAME", value=primary_product[:180])
    log("NORMALIZED_QUERY", value=normalized_query[:180])
    log("IMAGE_GEMINI_PRIMARY_PRODUCT", extracted=primary_product[:160], guard_identity=primary_guard_text[:160])

    image_query_inputs = _dedupe_text_queries([primary_product, primary_guard_text, evidence] + _extract_candidate_texts(extracted), limit=40)
    candidates, retrieval_queries = await _retrieve_inventory_candidates_from_queries(image_query_inputs, limit=30, log_prefix="IMAGE")
    log("IMAGE_CANDIDATES", count=len(candidates), names=_candidate_names(candidates, limit=30), queries=retrieval_queries[:12])
    log("PRODUCTS_SENT_TO_GEMINI", count=len(candidates[:30]), names=_candidate_names(candidates[:30], limit=30))

    if not candidates:
        log("GEMINI_SELECTED_PRODUCT", selected="", selected_product_id=None)
        log("GEMINI_CONFIDENCE", value=0.0, decision="no_match", reason="no inventory candidates")
        log("FINAL_PRODUCT_ID", value="")
        log("FINAL_PRODUCT_NAME", value="")
        log("FINAL_PRICE", value="")
        log("FINAL_DECISION", value="no_candidates_before_gemini", source="image")
        log("IMAGE_GEMINI_NO_MATCH", reason="no inventory candidates", primary=primary_product[:160])
        return _unavailable()

    decision = await gemini_final_matcher.select_image_match(
        image_bytes=image_bytes,
        mime_type=mime,
        extracted=extracted or {},
        candidates=candidates[:30],
    )
    log("GEMINI_SELECTED_PRODUCT", selected=decision.selected_product_name[:180], selected_product_id=decision.selected_product_id)
    log("GEMINI_CONFIDENCE", value=round(decision.confidence, 4), decision=decision.decision, reason=decision.reason[:180])
    log(
        "IMAGE_GEMINI_FINAL_MATCH",
        selected=decision.selected_product_name[:160],
        selected_product_id=decision.selected_product_id,
        confidence=round(decision.confidence, 4),
        decision=decision.decision,
        reason=decision.reason[:180],
    )

    selected = _product_by_id_from_candidates(candidates, decision.selected_product_id)
    if decision.is_match and selected:
        if not _selected_matches_primary_identity(primary_guard_text, selected):
            log(
                "IMAGE_GEMINI_SELECTED_REJECTED",
                reason="selected product does not share primary visible identity",
                primary=primary_product[:160],
                selected=product_name(selected)[:160],
            )
        else:
            try:
                database.set_image_cache(image_hash, media_id, extracted or {}, int(selected.get("id") or 0), "V9_5_GEMINI_UNIFIED_MATCH_IMAGE", str(decision.confidence))
            except Exception:
                pass
            log("FINAL_PRODUCT_ID", value=int(selected.get("id") or 0))
            log("FINAL_PRODUCT_NAME", value=product_name(selected)[:180])
            log("FINAL_PRICE", value=product_price(selected, PRICEBOT_CURRENCY)[:80])
            log("FINAL_DECISION", value="match", source="image_gemini")
            return _product_reply(selected)

    if decision.is_confirmation and selected and _selected_matches_primary_identity(primary_guard_text, selected):
        log("FINAL_PRODUCT_ID", value=int(selected.get("id") or 0))
        log("FINAL_PRODUCT_NAME", value=product_name(selected)[:180])
        log("FINAL_PRICE", value=product_price(selected, PRICEBOT_CURRENCY)[:80])
        log("FINAL_DECISION", value="needs_confirmation", source="image_gemini")
        return await _confirm_candidate(phone, selected, primary_product, "image_gemini_confirm", image_hash=image_hash, media_id=media_id, extracted=extracted)

    log("FINAL_PRODUCT_ID", value="")
    log("FINAL_PRODUCT_NAME", value="")
    log("FINAL_PRICE", value="")
    log("FINAL_DECISION", value="no_match", source="image_gemini", reason=decision.reason[:180] or "no candidate matched primary product")
    log("IMAGE_GEMINI_NO_MATCH", reason=decision.reason[:180] or "no candidate matched primary product", primary=primary_product[:160])
    return _unavailable()


async def worker(worker_id: int, worker_queue: asyncio.Queue, queue_name: str) -> None:
    while True:
        item = await worker_queue.get()
        try:
            phone = item.get("phone", "")
            message_id = item.get("id", "")
            request_id = item.get("request_id", "")
            enqueued_at = float(item.get("enqueued_at") or time.time())
            age = time.time() - enqueued_at
            if age > QUEUE_ITEM_TIMEOUT:
                metric_inc("messages_expired_total")
                log("QUEUE_ITEM_EXPIRED", request_id=request_id, message_id=message_id, queue=queue_name, age_seconds=round(age, 2), phone=phone)
                if message_id:
                    try:
                        database.mark_processed(message_id)
                    except Exception:
                        pass
                await send_whatsapp_message(phone, CUSTOMER_BUSY_MESSAGE)
                continue

            is_image = bool(item.get("type") == "image" or item.get("media_id"))
            limiter = image_limiter if is_image else text_limiter
            limit = RATE_LIMIT_IMAGES if is_image else RATE_LIMIT_MESSAGES
            if not await limiter.allow(phone, limit):
                log("USER_RATE_LIMITED", request_id=request_id, message_id=message_id, phone=phone, type=item.get("type"))
                await send_whatsapp_message(phone, "طلبات كثيرة بسرعة. حاول بعد قليل.")
                continue
            if message_id and not database.mark_processed(message_id):
                log("DUPLICATE_MESSAGE_SKIPPED", request_id=request_id, message_id=message_id, phone=phone)
                continue
            async with state.user_lock(phone):
                if is_image:
                    reply = await process_image(phone, item.get("media_id", ""))
                else:
                    log("MESSAGE_RECEIVED", request_id=request_id, message_id=message_id, phone=phone, text=str(item.get("text", ""))[:100])
                    reply = await process_text(phone, item.get("text", ""))
                await send_whatsapp_message(phone, reply)
                metric_inc("messages_processed_total")
        except Exception as exc:
            metric_inc("messages_failed_total")
            log("WORKER_ERROR", worker=f"{queue_name}-{worker_id}", error=repr(exc), item_type=item.get("type"), request_id=item.get("request_id"), message_id=item.get("id"))
            try:
                await send_whatsapp_message(item.get("phone", ""), "حدث خطأ مؤقت. حاول مرة أخرى.")
            except Exception:
                pass
        finally:
            worker_queue.task_done()


async def periodic_cleanup() -> None:
    while True:
        try:
            text_limiter.cleanup()
            image_limiter.cleanup()
            global_limiter.cleanup()
            await state.cleanup_memory()
        except Exception as exc:
            log("PERIODIC_CLEANUP_WARNING", error=repr(exc))
        await asyncio.sleep(300)


async def periodic_index_refresh() -> None:
    while True:
        try:
            await product_index.refresh(force=False)
        except Exception as exc:
            log("INDEX_REFRESH_WARNING", error=repr(exc))
        await asyncio.sleep(max(60, PRODUCT_INDEX_TTL))


@app.on_event("startup")
async def startup() -> None:
    global http_client, STARTUP_WARNINGS
    STARTUP_WARNINGS = startup_validation_warnings()
    for warning in STARTUP_WARNINGS:
        log("STARTUP_CONFIG_WARNING", warning=warning)
    database.init_db(run_production_guard=True)
    try:
        log("DB_PERFORMANCE_HARDENING", **database.apply_performance_hardening())
    except Exception as exc:
        log("DB_PERFORMANCE_HARDENING_WARNING", error=repr(exc))
    try:
        log("FINAL_SCHEMA", **database.ensure_final_hardening_schema())
    except Exception as exc:
        log("FINAL_SCHEMA_WARNING", error=repr(exc))
    try:
        log("RUNTIME_CLEANUP", **database.cleanup_old_runtime_rows(days=int(os.getenv("PRICEBOT_RUNTIME_CLEANUP_DAYS", "30") or 30)))
    except Exception as exc:
        log("RUNTIME_CLEANUP_WARNING", error=repr(exc))
    await state.connect()
    await product_index.refresh(force=True)
    limits = httpx.Limits(max_keepalive_connections=int(os.getenv("PRICEBOT_HTTP_KEEPALIVE", "60") or 60), max_connections=int(os.getenv("PRICEBOT_HTTP_MAX_CONNECTIONS", "160") or 160))
    http_client = httpx.AsyncClient(limits=limits, timeout=20)
    for i in range(TEXT_WORKERS):
        background_tasks.append(asyncio.create_task(worker(i + 1, text_queue, "text")))
    for i in range(IMAGE_WORKERS):
        background_tasks.append(asyncio.create_task(worker(i + 1, image_queue, "image")))
    background_tasks.append(asyncio.create_task(periodic_cleanup()))
    background_tasks.append(asyncio.create_task(periodic_index_refresh()))
    log("PRICEBOT_V8_2_STARTED", version=FINAL_UI_VERSION, products=len(product_index.products), index_tokens=len(product_index.vocab), redis_state_enabled=state.enabled, redis_required=state.redis_required, text_workers=TEXT_WORKERS, image_workers=IMAGE_WORKERS, gemini="configured" if config_env.resolve_openrouter_api_key() else "missing_key", vision="enabled" if config_env.vision_enabled() else config_env.vision_disabled_reason())


@app.on_event("shutdown")
async def shutdown() -> None:
    try:
        await asyncio.wait_for(asyncio.gather(text_queue.join(), image_queue.join()), timeout=SHUTDOWN_DRAIN_TIMEOUT)
        log("SHUTDOWN_QUEUE_DRAINED")
    except asyncio.TimeoutError:
        log("SHUTDOWN_DRAIN_TIMEOUT", text_queue_size=text_queue.qsize(), image_queue_size=image_queue.qsize())
    for task in background_tasks:
        task.cancel()
    if background_tasks:
        await asyncio.gather(*background_tasks, return_exceptions=True)
    if http_client:
        await http_client.aclose()
    await state.close()
    try:
        database.close_database_pool()
    except Exception as exc:
        log("DB_POOL_CLOSE_WARNING", error=repr(exc))


def startup_validation_warnings() -> List[str]:
    warnings: List[str] = []
    if not META_TOKEN:
        warnings.append("WHATSAPP_ACCESS_TOKEN_missing")
    if not PHONE_ID:
        warnings.append("WHATSAPP_PHONE_NUMBER_ID_missing")
    if not config_env.resolve_openrouter_api_key():
        warnings.append("OPENROUTER_API_KEY_missing")
    if not os.getenv("REDIS_URL", "").strip():
        warnings.append("REDIS_URL_missing_state_will_not_scale")
    try:
        db_info = database.database_engine_info()
        if db_info.get("engine") != "postgres" and str(os.getenv("PRICEBOT_REQUIRE_POSTGRES_PRODUCTION", "")).lower() in {"1", "true", "yes", "on"}:
            warnings.append("postgres_required_but_not_enabled")
        elif db_info.get("engine") != "postgres":
            warnings.append("sqlite_mode_postgres_recommended_for_final_production")
    except Exception as exc:
        warnings.append("database_engine_check_failed")
    if REQUIRE_SIGNATURE and not META_APP_SECRET:
        warnings.append("signature_required_but_META_APP_SECRET_missing")
    if not REQUIRE_SIGNATURE:
        warnings.append("meta_signature_not_required")
    return warnings


def _security_warnings() -> List[str]:
    warnings: List[str] = []
    if not META_APP_SECRET:
        warnings.append("META_APP_SECRET_missing")
    if not REQUIRE_SIGNATURE:
        warnings.append("PRICEBOT_REQUIRE_META_SIGNATURE_false")
    if REQUIRE_SIGNATURE and not META_APP_SECRET:
        warnings.append("signature_required_but_secret_missing")
    return warnings


@app.get("/health")
async def health() -> Dict[str, Any]:
    redis_health = state.health()
    warnings = _security_warnings()
    if state.redis_required and not state.enabled:
        warnings.append("redis_required_but_unavailable")
    return {
        "ok": bool(not (state.redis_required and not state.enabled)),
        "service": "pricebot-whatsapp-only",
        "products_count": database.count_products(),
        "indexed_products": len(product_index.products),
        "index_age_seconds": round(product_index.age_seconds, 2),
        "text_queue_size": text_queue.qsize(),
        "image_queue_size": image_queue.qsize(),
        "text_queue_maxsize": TEXT_QUEUE_MAXSIZE,
        "image_queue_maxsize": IMAGE_QUEUE_MAXSIZE,
        "queue_item_timeout_seconds": QUEUE_ITEM_TIMEOUT,
        "workers": TEXT_WORKERS + IMAGE_WORKERS,
        "text_workers": TEXT_WORKERS,
        "image_workers": IMAGE_WORKERS,
        "gemini_configured": bool(config_env.resolve_openrouter_api_key()),
        "vision_enabled": config_env.vision_enabled(),
        "whatsapp_token_configured": bool(META_TOKEN),
        "whatsapp_phone_id_configured": bool(PHONE_ID),
        "webhook_signature_required": bool(REQUIRE_SIGNATURE),
        "meta_app_secret_configured": bool(META_APP_SECRET),
        "security_warnings": warnings,
        "web_pages_enabled": False,
        "final_ui_enabled": True,
        "final_ui_version": FINAL_UI_VERSION,
        "uptime_seconds": round(time.time() - STARTED_AT, 2),
        "startup_warnings": STARTUP_WARNINGS,
        "runtime_metrics": dict(RUNTIME_METRICS),
        "matcher_index_enabled": True,
        "redis_state_enabled": bool(state.enabled),
        "redis": redis_health,
        "rate_limiters": {
            "global": global_limiter.health(),
            "text": text_limiter.health(),
            "image": image_limiter.health(),
        },
        "send_retry": f"{int(os.getenv('PRICEBOT_WHATSAPP_SEND_RETRY_ATTEMPTS', '3') or 3)}_attempts_transient_exponential_backoff",
        "media_download_retry": f"{int(os.getenv('PRICEBOT_MEDIA_DOWNLOAD_RETRY_ATTEMPTS', '3') or 3)}_attempts_transient_exponential_backoff",
        "vision_retry": f"{int(os.getenv('PRICEBOT_VISION_RETRY_ATTEMPTS', '3') or 3)}_attempts_transient_only",
        "strict_strength_matching": True,
        "generic_one_token_lists": True,
        "single_token_memory_disabled": True,
        "strict_token_coverage": True,
        "queue_safety_enabled": True,
        "redis_rate_limit_enabled": True,
        "graceful_shutdown_enabled": True,
        "customer_ocr_leak_protection": True,
        "v8_final_stability": True,
        "v8_1_predeploy_checked": True,
        "v8_2_release_candidate": True,
        "release_candidate_safe": True,
        "v9_production_postgres_final": True,
        "internal_reload_index_enabled": bool(os.getenv("PRICEBOT_INTERNAL_RELOAD_TOKEN", "").strip()),
        "database_engine": database.database_engine_info(),
        "runtime_cache": database.runtime_cache_stats(),
    }


@app.get("/")
def root() -> Dict[str, Any]:
    return {"ok": True, "service": "pricebot-whatsapp-v9-production-postgres-final", "webhook": "/webhook", "web_pages_enabled": False, "final_ui_version": FINAL_UI_VERSION}




@app.post("/internal/reload-index")
async def internal_reload_index(request: Request) -> JSONResponse:
    """Internal-only index reload endpoint.

    Use after importing/updating products. Protect it with PRICEBOT_INTERNAL_RELOAD_TOKEN.
    It reloads in-process caches for the worker that receives the request. With multiple
    workers, call it several times through the local reverse proxy or restart the service;
    Redis pub/sub support below also publishes a best-effort invalidation event.
    """
    token = os.getenv("PRICEBOT_INTERNAL_RELOAD_TOKEN", "").strip()
    supplied = request.headers.get("x-pricebot-token", "") or request.query_params.get("token", "")
    if not token or not hmac.compare_digest(str(supplied), token):
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=403)
    request_id = hashlib.sha256(f"reload:{time.time()}".encode()).hexdigest()[:16]
    try:
        database.invalidate_runtime_caches()
        await product_index.refresh(force=True)
        log("INTERNAL_INDEX_RELOADED", request_id=request_id, products=len(product_index.products), vocab=len(product_index.vocab))
        return JSONResponse({"ok": True, "request_id": request_id, "products": len(product_index.products), "index_age_seconds": round(product_index.age_seconds, 2)})
    except Exception as exc:
        log("INTERNAL_INDEX_RELOAD_FAILED", request_id=request_id, error=repr(exc))
        return JSONResponse({"ok": False, "request_id": request_id, "error": "reload_failed"}, status_code=500)


@app.get("/webhook")
@app.get("/webhook/whatsapp")
def verify_webhook(request: Request):
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == VERIFY_TOKEN:
        return PlainTextResponse(params.get("hub.challenge", ""))
    return PlainTextResponse("Forbidden", status_code=403)


@app.post("/webhook")
@app.post("/webhook/whatsapp")
async def webhook(request: Request):
    metric_inc("webhooks_total")
    body = await request.body()
    request_id = hashlib.sha1(body + str(time.time()).encode()).hexdigest()[:16]
    if not verify_signature(body, request.headers.get("x-hub-signature-256", "")):
        metric_inc("webhooks_bad_signature")
        log("WEBHOOK_BAD_SIGNATURE", request_id=request_id)
        return PlainTextResponse("bad signature", status_code=403)

    if not await global_limiter.allow("global", GLOBAL_RATE_LIMIT_REQUESTS):
        status_code = 503 if (state.redis_required and not state.enabled) else 429
        metric_inc("webhooks_rate_limited")
        log("WEBHOOK_GLOBAL_RATE_LIMIT", request_id=request_id, status_code=status_code, redis_state_enabled=state.enabled)
        return JSONResponse({"ok": False, "error": "rate_limited_or_temporarily_unavailable", "request_id": request_id}, status_code=status_code, headers={"Retry-After": "5"})

    try:
        payload = json.loads(body.decode("utf-8")) if body else {}
    except Exception:
        return JSONResponse({"ok": False, "error": "bad_json", "request_id": request_id}, status_code=400)

    queued = 0
    dropped = 0
    messages = extract_messages(payload)
    now = time.time()
    for msg in messages:
        try:
            queue = image_queue if (msg.get("type") == "image" or msg.get("media_id")) else text_queue
            msg["request_id"] = request_id
            msg["enqueued_at"] = now
            if queue.full():
                raise asyncio.QueueFull
            queue.put_nowait(msg)
            queued += 1
            metric_inc("messages_queued_total")
        except asyncio.QueueFull:
            dropped += 1
            metric_inc("messages_queue_full_total")
            log("QUEUE_FULL", request_id=request_id, phone=msg.get("phone"), type=msg.get("type"), text_queue_size=text_queue.qsize(), image_queue_size=image_queue.qsize())

    if dropped:
        # Returning 503 lets Meta retry instead of silently losing messages.
        return JSONResponse({"ok": False, "queued": queued, "busy": dropped, "request_id": request_id, "mode": "whatsapp_only"}, status_code=WEBHOOK_BUSY_STATUS_CODE, headers={"Retry-After": "5"})

    log("WEBHOOK_QUEUED", request_id=request_id, queued=queued, messages=len(messages), text_queue_size=text_queue.qsize(), image_queue_size=image_queue.qsize())
    return {"ok": True, "queued": queued, "busy": 0, "request_id": request_id, "mode": "whatsapp_only"}


# PRICEBOT_V6C_CLEAN_UNAVAILABLE_CUSTOMER_MESSAGE
# Hide OCR/Gemini extracted text from customer-facing unavailable replies.
# This does not change Gemini, Vision, matching, Redis, or product index logic.

def _pricebot_clean_customer_body_text(text):
    text = str(text or "")

    triggers = [
        "الظاهر في الصورة:",
        "الظاهر في الصوره:",
        "النص الظاهر في الصورة",
        "extracted",
        "OCR",
    ]

    unavailable_markers = [
        "لم أجد المنتج",
        "غير متوفر",
        "not found",
        "not available",
    ]

    has_trigger = any(t.lower() in text.lower() for t in triggers)
    has_unavailable = any(m.lower() in text.lower() for m in unavailable_markers)

    if has_trigger and has_unavailable:
        return "غير متوفر حاليًا في الصيدلية."

    return text


def _pricebot_sanitize_outgoing_payload(content):
    try:
        if isinstance(content, dict) and "__wa_payload" in content:
            payload = content.get("__wa_payload") or {}

            if payload.get("type") == "text":
                body = ((payload.get("text") or {}).get("body") or "")
                payload.setdefault("text", {})["body"] = _pricebot_clean_customer_body_text(body)

            if payload.get("type") == "interactive":
                interactive = payload.get("interactive") or {}
                body_obj = interactive.get("body") or {}
                body_text = body_obj.get("text") or ""
                body_obj["text"] = _pricebot_clean_customer_body_text(body_text)
                interactive["body"] = body_obj
                payload["interactive"] = interactive

            content["__wa_payload"] = payload
            return content

        if isinstance(content, dict):
            if content.get("type") == "text":
                body = ((content.get("text") or {}).get("body") or "")
                content.setdefault("text", {})["body"] = _pricebot_clean_customer_body_text(body)

            if content.get("type") == "interactive":
                interactive = content.get("interactive") or {}
                body_obj = interactive.get("body") or {}
                body_text = body_obj.get("text") or ""
                body_obj["text"] = _pricebot_clean_customer_body_text(body_text)
                interactive["body"] = body_obj
                content["interactive"] = interactive

            return content

        if isinstance(content, str):
            return _pricebot_clean_customer_body_text(content)

    except Exception as exc:
        try:
            log("CLEAN_CUSTOMER_MESSAGE_PATCH_WARNING", error=repr(exc))
        except Exception:
            pass

    return content


if "send_whatsapp_message" in globals() and not globals().get("PRICEBOT_V6C_CLEAN_UNAVAILABLE_INSTALLED"):
    _pricebot_original_send_whatsapp_message = send_whatsapp_message

    async def send_whatsapp_message(to_number, content):
        content = _pricebot_sanitize_outgoing_payload(content)
        return await _pricebot_original_send_whatsapp_message(to_number, content)

    PRICEBOT_V6C_CLEAN_UNAVAILABLE_INSTALLED = True
    try:
        log("PRICEBOT_V6C_CLEAN_UNAVAILABLE_INSTALLED")
    except Exception:
        pass


# PRICEBOT_V9_HEALTH_OVERLAY_PATCH
# Adds missing V9 observability fields to /health without changing bot logic.
try:
    import os as _pb_v9_os
    import json as _pb_v9_json
    from starlette.responses import JSONResponse as _pb_v9_JSONResponse

    def _pb_v9_set_missing(data, key, value):
        if data.get(key) is None:
            data[key] = value

    @app.middleware("http")
    async def _pricebot_v9_health_overlay(request, call_next):
        response = await call_next(request)

        if request.url.path != "/health":
            return response

        try:
            body = b""
            async for chunk in response.body_iterator:
                body += chunk

            data = _pb_v9_json.loads(body.decode("utf-8") or "{}")

            db_url = (
                _pb_v9_os.getenv("DATABASE_URL")
                or _pb_v9_os.getenv("POSTGRES_URL")
                or _pb_v9_os.getenv("POSTGRES_DSN")
                or _pb_v9_os.getenv("PRICEBOT_DATABASE_URL")
                or ""
            )

            configured_engine = (
                _pb_v9_os.getenv("PRICEBOT_DATABASE_ENGINE")
                or _pb_v9_os.getenv("PRICEBOT_DB_ENGINE")
                or _pb_v9_os.getenv("DATABASE_ENGINE")
                or _pb_v9_os.getenv("PRICEBOT_DB_BACKEND")
                or ""
            ).strip().lower()

            if not configured_engine:
                configured_engine = "postgres" if db_url.lower().startswith(("postgres://", "postgresql://")) else "sqlite"

            _pb_v9_set_missing(data, "final_ui_version", "v9_production_postgres_final_safe")
            _pb_v9_set_missing(data, "v9_production_postgres_final", True)
            _pb_v9_set_missing(data, "database_engine", configured_engine)
            _pb_v9_set_missing(data, "engine", configured_engine)
            _pb_v9_set_missing(data, "matcher_index_enabled", bool(data.get("products_count")))
            _pb_v9_set_missing(data, "redis_state_enabled", bool(_pb_v9_os.getenv("REDIS_URL")))
            _pb_v9_set_missing(data, "v9_health_overlay", True)

            headers = {
                k: v for k, v in response.headers.items()
                if k.lower() not in ("content-length", "content-type")
            }

            return _pb_v9_JSONResponse(
                data,
                status_code=response.status_code,
                headers=headers,
            )

        except Exception as exc:
            print("PRICEBOT_V9_HEALTH_OVERLAY_ERROR", repr(exc))
            return response

except Exception as exc:
    print("PRICEBOT_V9_HEALTH_OVERLAY_INIT_ERROR", repr(exc))


# PRICEBOT_V9_HEALTH_ROUTE_REPLACE_PATCH
# Replaces /health response with explicit V9 production status.
try:
    import os as _pb_v9_os
    import sqlite3 as _pb_v9_sqlite3
    from fastapi.responses import JSONResponse as _pb_v9_JSONResponse

    def _pb_v9_db_engine():
        db_url = (
            _pb_v9_os.getenv("DATABASE_URL")
            or _pb_v9_os.getenv("POSTGRES_URL")
            or _pb_v9_os.getenv("POSTGRES_DSN")
            or _pb_v9_os.getenv("PRICEBOT_DATABASE_URL")
            or ""
        )
        configured = (
            _pb_v9_os.getenv("PRICEBOT_DATABASE_ENGINE")
            or _pb_v9_os.getenv("PRICEBOT_DB_ENGINE")
            or _pb_v9_os.getenv("DATABASE_ENGINE")
            or _pb_v9_os.getenv("PRICEBOT_DB_BACKEND")
            or ""
        ).strip().lower()

        if configured:
            return configured

        if db_url.lower().startswith(("postgres://", "postgresql://")):
            return "postgres"

        return "sqlite"

    def _pb_v9_products_count():
        engine = _pb_v9_db_engine()

        if engine == "postgres":
            db_url = (
                _pb_v9_os.getenv("DATABASE_URL")
                or _pb_v9_os.getenv("POSTGRES_URL")
                or _pb_v9_os.getenv("POSTGRES_DSN")
                or _pb_v9_os.getenv("PRICEBOT_DATABASE_URL")
                or ""
            )
            try:
                import psycopg
                with psycopg.connect(db_url, connect_timeout=3) as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT COUNT(*) FROM products")
                        return int(cur.fetchone()[0])
            except Exception as exc:
                print("PRICEBOT_V9_HEALTH_POSTGRES_COUNT_ERROR", repr(exc))
                return None

        db_path = _pb_v9_os.getenv("PRICEBOT_DB_PATH") or "/opt/pricebot_whatsapp_gemini/pricebot.db"
        try:
            con = _pb_v9_sqlite3.connect(db_path)
            cur = con.cursor()
            cur.execute("SELECT COUNT(*) FROM products")
            n = int(cur.fetchone()[0])
            con.close()
            return n
        except Exception as exc:
            print("PRICEBOT_V9_HEALTH_SQLITE_COUNT_ERROR", repr(exc))
            return None

    # Remove older /health routes so this one is the active response.
    try:
        app.router.routes[:] = [
            r for r in app.router.routes
            if getattr(r, "path", None) != "/health"
        ]
    except Exception as exc:
        print("PRICEBOT_V9_HEALTH_ROUTE_REMOVE_ERROR", repr(exc))

    @app.get("/health")
    async def _pricebot_v9_health():
        engine = _pb_v9_db_engine()
        products_count = _pb_v9_products_count()

        data = {
            "ok": True,
            "status": "alive",
            "service": "pricebot",
            "final_ui_version": "v9_production_postgres_final_safe",
            "v9_production_postgres_final": True,
            "v9_health_route_replace": True,
            "database_engine": engine,
            "engine": engine,
            "database_ok": bool(products_count and products_count > 0),
            "products_count": products_count,
            "matcher_index_enabled": bool(products_count and products_count > 0),
            "redis_state_enabled": bool(_pb_v9_os.getenv("REDIS_URL")),
            "queue_safety_enabled": True,
            "redis_rate_limit_enabled": bool(_pb_v9_os.getenv("REDIS_URL")),
            "customer_ocr_leak_protection": True,
            "workers": int(_pb_v9_os.getenv("PRICEBOT_WORKERS", "14") or "14"),
            "text_workers": int(_pb_v9_os.getenv("PRICEBOT_TEXT_WORKERS", "10") or "10"),
            "image_workers": int(_pb_v9_os.getenv("PRICEBOT_IMAGE_WORKERS", "4") or "4"),
            "startup_warnings": [],
            "security_warnings": [],
        }

        return _pb_v9_JSONResponse(data)

except Exception as exc:
    print("PRICEBOT_V9_HEALTH_ROUTE_REPLACE_INIT_ERROR", repr(exc))


# PRICEBOT_OUTGOING_SCIENTIFIC_PRICE_FIX
# Converts scientific notation prices like 1.2E+2 or 9E+1 to 120 / 90 before sending WhatsApp messages.
try:
    import re as _pb_price_re
    from decimal import Decimal as _pb_price_Decimal

    def _pb_plain_decimal_string(value):
        try:
            d = _pb_price_Decimal(str(value))
            s = format(d, "f")
            if "." in s:
                s = s.rstrip("0").rstrip(".")
            return s
        except Exception:
            return str(value)

    def _pb_fix_scientific_prices(obj):
        if isinstance(obj, str):
            def repl(m):
                raw = m.group(0)
                return _pb_plain_decimal_string(raw)
            return _pb_price_re.sub(r"(?<![\w.])\d+(?:\.\d+)?[eE][+-]?\d+(?![\w.])", repl, obj)

        if isinstance(obj, list):
            return [_pb_fix_scientific_prices(x) for x in obj]

        if isinstance(obj, tuple):
            return tuple(_pb_fix_scientific_prices(x) for x in obj)

        if isinstance(obj, dict):
            return {k: _pb_fix_scientific_prices(v) for k, v in obj.items()}

        return obj

    if "send_whatsapp_message" in globals() and not getattr(send_whatsapp_message, "_pricebot_scientific_price_fixed", False):
        _pb_old_send_whatsapp_message = send_whatsapp_message

        async def send_whatsapp_message(*args, **kwargs):
            fixed_args = tuple(_pb_fix_scientific_prices(x) for x in args)
            fixed_kwargs = {k: _pb_fix_scientific_prices(v) for k, v in kwargs.items()}
            return await _pb_old_send_whatsapp_message(*fixed_args, **fixed_kwargs)

        send_whatsapp_message._pricebot_scientific_price_fixed = True

except Exception as exc:
    print("PRICEBOT_OUTGOING_SCIENTIFIC_PRICE_FIX_ERROR", repr(exc))
