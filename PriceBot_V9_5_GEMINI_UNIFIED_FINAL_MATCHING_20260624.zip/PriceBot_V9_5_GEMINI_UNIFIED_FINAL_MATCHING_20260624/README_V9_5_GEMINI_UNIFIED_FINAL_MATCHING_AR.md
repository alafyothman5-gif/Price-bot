# PriceBot V9.5_GEMINI_UNIFIED_FINAL_MATCHING

هذا الإصدار يوحّد منطق مطابقة المنتج في النص والصورة:

```text
Image أو Text
→ استخراج اسم المنتج الرئيسي
→ Normalize name
→ جلب products candidates من PostgreSQL فقط
→ Gemini final matching against candidates
→ إرجاع المنتج المختار من قاعدة البيانات
→ عرض السعر مباشرة
```

## أهم التغييرات

1. **Gemini هو القرار النهائي للنص والصورة**
   - لم يعد `ProductIndex` أو أي fuzzy/local matcher يعطي المنتج النهائي للمستخدم.
   - المحلي يستخدم فقط لجلب candidates من المنتجات المتوفرة في PostgreSQL.

2. **مسار النص صار موحّدًا**
   - حتى النص الإنجليزي الواضح مثل `Hemazym` يدخل إلى Gemini final matcher بعد candidate retrieval.
   - الجمل العربية/العامية مثل `متوفر عندكم اموكلان` و `نبي سعر فيروكسيل` تمر بنفس المسار.

3. **مسار الصورة صار أكثر صرامة**
   - Gemini Vision يستخرج اسم المنتج الرئيسي فقط.
   - Gemini final matcher يختار من candidates فقط.
   - لا يتم قبول منتج خارج القائمة.
   - لا يتم قبول confidence أقل من `0.85` كعرض سعر مباشر.
   - لا يوجد fallback محلي يسأل تأكيد اعتمادًا على fuzzy score فقط.

4. **دعم Hemäzym / Hemazym**
   - تم تحسين `normalizer.py` لإزالة Latin diacritics.
   - مثال: `Hemäzym` يصبح `hemazym`.

5. **منع خطأ Hemazym / Folic Acid**
   - prompt النهائي يوضح أن `Folic Acid`, `Iron Supplement`, `Complex`, `Capsules` أو القوة/العبوة لا تعتبر اسم المنتج التجاري إذا كانت وصفًا أو مكوّنًا.
   - إذا المنتج الرئيسي هو `Hemazym` فلا يقبل اختيار `Folic Acid` كمنتج نهائي.

## ملفات معدلة / مضافة

- `app/app.py`
  - توحيد text flow و image flow.
  - Gemini final matching أصبح المسار النهائي قبل عرض السعر.
  - إضافة logs إلزامية.
  - تجاهل كاش الصور القديم قبل V9.5.

- `app/gemini_final_matcher.py`
  - تحديث prompt النهائي للنص والصورة.
  - إلزام Gemini بالاختيار من candidates فقط.
  - رفض أي `product_id` خارج candidates.

- `app/normalizer.py`
  - إزالة Latin diacritics: `Hemäzym` → `Hemazym`.

- `app/scripts/test_gemini_matching_flow.py`
  - اختبار لا يرسل واتساب.
  - لا يغيّر قاعدة البيانات.
  - يطبع extraction، candidates، وقرار Gemini النهائي.

## Logs الإلزامية

الأحداث التالية تظهر في اللوج أثناء المطابقة:

```text
IMAGE_EXTRACTED_NAME
USER_TEXT
NORMALIZED_QUERY
PRODUCTS_SENT_TO_GEMINI
GEMINI_SELECTED_PRODUCT
GEMINI_CONFIDENCE
FINAL_PRODUCT_ID
FINAL_PRODUCT_NAME
FINAL_PRICE
FINAL_DECISION
```

أمثلة إضافية:

```text
TEXT_QUERY_EXTRACTED
TEXT_CANDIDATES
TEXT_GEMINI_FINAL_MATCH
IMAGE_CANDIDATES
IMAGE_GEMINI_FINAL_MATCH
IMAGE_GEMINI_NO_MATCH
```

## طريقة الاختبار على السيرفر

من داخل مجلد التطبيق:

```bash
cd /root/pricebot/app
source .venv/bin/activate
python scripts/test_gemini_matching_flow.py
```

لتشغيل Gemini الحقيقي في final matching:

```bash
python scripts/test_gemini_matching_flow.py --live-gemini
```

لتجربة صورة فعلية مع Gemini Vision وGemini final matcher:

```bash
python scripts/test_gemini_matching_flow.py --image /path/to/hemazym.jpg --live-vision --live-gemini
```

## Acceptance Criteria

- `Hemazym` نصيًا يدخل إلى Gemini final matcher ثم يرجع سعر Hemazym إذا موجود.
- صورة `Hemazym / Hemäzym` ترجع Hemazym مباشرة إذا candidate موجود وثقة Gemini ≥ 0.85.
- لا يتم عرض `Folic Acid` بدل `Hemazym` إذا كان `Folic Acid` مكوّنًا أو وصفًا.
- `متوفر عندكم اموكلان` يرجع Amoclan إذا موجود ومتوفر في PostgreSQL.
- `نبي سعر فيروكسيل` يرجع Feroxyl إذا موجود ومتوفر في PostgreSQL.
- `متوفر عندكم بندول` يرجع Panadol فقط إذا موجود ومتوفر في PostgreSQL.
- إذا لا يوجد تطابق حقيقي داخل candidates، يرد البوت:

```text
لم أجد المنتج في قائمة الصيدلية، يرجى كتابة الاسم بشكل أوضح.
```
