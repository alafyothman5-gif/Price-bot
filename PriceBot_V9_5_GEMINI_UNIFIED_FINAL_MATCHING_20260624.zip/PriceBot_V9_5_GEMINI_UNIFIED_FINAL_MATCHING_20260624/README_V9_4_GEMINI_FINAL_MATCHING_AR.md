# PriceBot V9.4_GEMINI_MATCHING_FINAL

هذا الإصدار يعالج مشكلة مطابقة الصور التي كانت تسمح للـ local fuzzy matcher أن يصبح القرار النهائي بعد قراءة الصورة. في V9.4 أصبح المحلي مسؤولًا فقط عن جلب قائمة احتمالات صغيرة من PostgreSQL، بينما Gemini هو صاحب القرار النهائي في مسار الصور.

## التغيير الأساسي

المسار الجديد للصورة:

```text
Image
→ Gemini Vision يستخرج المنتج الرئيسي الظاهر في الصورة
→ ProductIndex/PostgreSQL يجلب candidates من المنتجات المتوفرة فقط
→ Gemini final matcher يختار من candidates فقط
→ البوت يرد بالسعر أو يسأل تأكيد أو يرجع غير متوفر
```

## الملفات الجديدة/المعدلة

- `app/gemini_final_matcher.py`
  - يرسل إلى Gemini قائمة candidates محدودة فقط.
  - يمنع اختيار أي منتج خارج القائمة.
  - يرفض أي match أقل من `0.85` confidence.
  - يرجع JSON decision داخليًا: `match`, `needs_confirmation`, `no_match`.

- `app/app.py`
  - تم تحديث `FINAL_UI_VERSION` إلى `V9.4_GEMINI_MATCHING_FINAL`.
  - تم تعديل `process_image()` بحيث لا يعتمد على local matcher كقرار نهائي.
  - تم تجاهل كاش الصور القديم قبل V9.4 حتى لا يرجع قرارًا خاطئًا مثل Folic Acid من صورة Hemazym.
  - تم إضافة candidate retrieval من PostgreSQL بحد أقصى 30 نتيجة.
  - تم إضافة Gemini final selector للصور.
  - تم إضافة Gemini final selector للنص العربي/العامي/الصوتي غير الواضح بعد candidate retrieval.

- `app/vision_service.py`
  - تم تحسين prompt الخاص بالصورة ليطلب التركيز على المنتج الأكبر/الأوضح في المقدمة.
  - تم التنبيه صراحةً على عدم اعتبار كلمات مثل `Folic Acid`, `Iron Supplement`, `Complex`, `Capsules` اسم منتج تجاري إذا كانت وصفًا أو مكونات.
  - المثال الحاكم: إذا كان المنتج الرئيسي `Hemazym` لا يجوز جعله `Folic Acid 500mcg`.

- `app/scripts/test_gemini_matching_flow.py`
  - سكربت اختبار لا يرسل رسائل واتساب.
  - لا يغيّر قاعدة البيانات.
  - يطبع استخراج النص، candidates، وقرار Gemini النهائي.

## ضمانات V9.4

- لا يتم إرسال كل المنتجات إلى Gemini.
- يتم إرسال أفضل 20–30 candidate فقط.
- كل candidates تأتي من PostgreSQL عبر `ProductIndex` المحمّل من المنتجات المتوفرة/الظاهرة فقط.
- Gemini ممنوع من اختيار منتج خارج candidates.
- إذا اختار Gemini منتجًا خارج القائمة، يتم رفض القرار.
- إذا كانت الثقة أقل من `0.85` لا يتم عرض السعر مباشرة.
- إذا كانت الصورة تحتوي أكثر من منتج والمنتج الرئيسي غير واضح، لا يتم التخمين.
- إذا اختار Gemini منتجًا لا يشارك اسم المنتج الرئيسي الظاهر في الصورة، يتم رفضه.

## Logs الجديدة

أمثلة:

```text
IMAGE_GEMINI_PRIMARY_PRODUCT extracted="Hemazym"
IMAGE_CANDIDATES count=12 names=[...]
IMAGE_GEMINI_FINAL_MATCH selected="Hemazym ..." confidence=0.93
IMAGE_GEMINI_NO_MATCH reason="no candidate matched primary product"
TEXT_QUERY_EXTRACTED original="متوفر عندكم اموكلان" candidates=["اموكلان","amoclan"]
TEXT_GEMINI_FINAL_MATCH selected="Amoclan ..." confidence=0.91
```

## تشغيل الاختبار على السيرفر

من داخل مجلد التطبيق:

```bash
cd /root/pricebot/app
source .venv/bin/activate
python scripts/test_gemini_matching_flow.py
```

الاختبار الافتراضي يستخدم mock selector حتى يثبت مسار:

```text
extract → candidate retrieval → final selector
```

ولا يستهلك Gemini.

لتجربة Gemini الحقيقي:

```bash
python scripts/test_gemini_matching_flow.py --live-gemini
```

لتجربة صورة فعلية:

```bash
python scripts/test_gemini_matching_flow.py --image /path/to/hemazym.jpg --live-gemini --live-vision
```

## Acceptance Criteria المغطاة

- صورة Hemazym لا يجب أن ترجع Folic Acid كقرار نهائي.
- إن لم يكن Gemini متأكدًا، لا يتم اختيار منتج عشوائي.
- النص الإنجليزي الواضح مثل `Hemazym` يبقى يعمل بالمسار السريع إذا كان match قويًا.
- النص العربي/العامي مثل `متوفر عندكم اموكلان` يمر عبر استخراج النص ثم candidate retrieval ثم Gemini final selector.
- لا توجد منتجات hardcoded.
- لا تغيير في قاعدة البيانات.
- لا تغيير في شكل رسائل واتساب.
